#!/bin/sh

if [ -z "$BASE_DIR" ] ; then
  PRG="$0"

  # need this for relative symlinks
  while [ -h "$PRG" ] ; do
    ls=`ls -ld "$PRG"`
    link=`expr "$ls" : '.*-> \(.*\)$'`
    if expr "$link" : '/.*' > /dev/null; then
      PRG="$link"
    else
      PRG="`dirname "$PRG"`/$link"
    fi
  done
  BASE_DIR=`dirname "$PRG"`/..

  # make it fully qualified
  BASE_DIR=`cd "$BASE_DIR" && pwd`
  #echo "Meta broker is at $BASE_DIR"
fi


LANG=zh_CN.UTF8
LC_ALL=zh_CN.UTF8
export LANG LC_ALL

#
papp_home=$BASE_DIR
#
LIB_PATH="${JAVA_HOME}:${papp_home}/lib/*:${papp_home}/ext/*:${papp_home}/classes/:${papp_home}/conf/"

#
exec ${JDK_HOME}/java -cp ${LIB_PATH} -Xms128m -Xmx512m -XX:CompileThreshold=8000 -XX:PermSize=64m -Dpapp.lib.dir=${papp_home}/ext  -Dpafa.log.home=${papp_home}/logs -Dpapp.web.root=${papp_home}/../ -Dpapp.protocols=dubbo,jetty -XX:MaxPermSize=512m -Xverify:none -da com.pingan.pafa.papp.PAppMain