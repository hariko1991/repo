package com.pingan.pafa.common.beans.map;

import java.util.HashMap;
import java.util.Map;

public class Bean2MapTests {
	

	public static void main(String args[]){
		BeanMapUtils BeanMapUtils=new BeanMapUtils();
		//{reqGwSystemId=648862, gwReqBisParams={body={1=2}, appHead={bizSeqNo=reqGwSystemId1701107852116501}}}
		Map appHead=new HashMap();
		appHead.put("bizSeqNo", "reqGwSystemId1701107852116501");
		Map body=new HashMap();
		body.put(1, 2);
		body.put("stu", new Stu());
		Map gwReqBisParams=new HashMap();
		
		gwReqBisParams.put("body", body);
		gwReqBisParams.put("appHead", appHead);
		
		Map data=new HashMap();
		data.put("reqGwSystemId", 648862);
		data.put("gwReqBisParams", gwReqBisParams);
		
		System.err.println(BeanMapUtils._toMap(data));
		
		
	}
}
