package com.pingan.pafa.common.beans.map;

public class Stu2 implements java.io.Serializable{
	
	public static final int a=1;
	
	public static int b=2;

	/**
	 *  
	 */
	private static final long serialVersionUID = 1L;

	private String name="nangua";
	
	private boolean isSex;
	
	private boolean abc;
	
	private Boolean abc1;
	
	private int age;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isSex() {
		return isSex;
	}

	public void setSex(boolean isSex) {
		this.isSex = isSex;
	}

	public boolean isAbc() {
		return abc;
	}

	public void setAbc(boolean abc) {
		this.abc = abc;
	}

	public Boolean getAbc1() {
		return abc1;
	}

	public void setAbc1(Boolean abc1) {
		this.abc1 = abc1;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
	
}
