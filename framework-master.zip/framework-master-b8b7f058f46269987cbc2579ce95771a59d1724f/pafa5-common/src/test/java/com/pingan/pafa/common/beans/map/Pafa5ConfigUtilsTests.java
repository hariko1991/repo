package com.pingan.pafa.common.beans.map;

import java.util.Properties;

import com.pingan.pafa.common.utils.Pafa5ConfigUtils;

public class Pafa5ConfigUtilsTests {

	public static void main(String args[]){
		Properties datas=new Properties();
		datas.put("name","王麻子");
		datas.put("abc","false");
		datas.put("age","11");
		Stu stu=new Stu();
		Pafa5ConfigUtils.bindBean(datas, stu);
		System.err.println("name="+stu.getAge());
	}
}
