package com.pingan.pafa.common.beans.map;

import java.util.Map;

public class BeanMapUtilsTest2 {

	public static void main(String args[]) throws Exception{
		BeanMapUtils BeanMapUtils=new BeanMapUtils();
		Stu stu=new Stu();
		Map datas=(Map)BeanMapUtils._toMap(stu);
		
		System.err.println(datas);
		
		System.err.println(((Stu)BeanMapUtils._toBean(Stu.class, datas)).getAge());
		
		
	}
}
