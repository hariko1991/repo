package com.paic.pafa.validator.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD,ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
/**
 * 枚举值配置，目标类型:String,Number
 * 主要针对一些枚举型成员变量，如性别成员变量只能是M/F等
 * */
public @interface VEnum  {
	/**枚举项列表*/
	String[] value() ;
	/**默认的错误信息*/
	String message() default "";
}
