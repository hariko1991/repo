package com.paic.pafa.validator;

import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.Array;
import java.util.Collection;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.validation.Errors;

import com.paic.pafa.validator.annotation.ConfigLoader;

 class ValidatorExecutor {
	
	 private Log log=LogFactory.getLog(this.getClass());
	
	private Object bean;
	
	private Map<String,NestedPathValidators> pathValidators;
	
	private Errors errors;
	
	private ValidateSupport validateSupport;
	
	
	
	
	public ValidatorExecutor(Object bean,Errors errors
			,ValidateSupport validateSupport){
		this.bean=bean;
		this.errors=errors;
		this.validateSupport=validateSupport;
	}
	
	
	
	public boolean validate(){
		if(bean==null){
			throw new ValidateException("bean requried.");
		}
		if(pathValidators==null){
			pathValidators=validateSupport.getConfigLoader().getNestedPathValidators(bean.getClass());
		}
		try {
			_validate(bean,null,-1);
		}catch (RuntimeException e) {
			throw (RuntimeException)e;
		}catch (Throwable e) {
			throw new ValidateException("Validate["+bean+"]error."+e.getMessage(),e);
		}
		return errors.getErrorCount()==0;
	}
	
	public void _validate(Object dto,String parentPath,int idx) throws Throwable{
		
		PropertyDescriptor[] pds=Introspector.getBeanInfo(dto.getClass()).getPropertyDescriptors();
		String realParentPath=parentPath;
		if(idx>-1 && parentPath!=null){
			realParentPath=(parentPath+"["+idx+"]");
		}
		ValidateContext context=new DefaultValidateContext(this.bean,realParentPath,dto,errors);
		//
		ConfigLoader configLoader=validateSupport.getConfigLoader();
		configLoader.checkConfigLoaded(dto.getClass());
		//----------------------------
		for(int i=0;i<pds.length;i++){
			PropertyDescriptor pd=pds[i];
			if(pd.getReadMethod()==null)continue;
			Object value=pd.getReadMethod().invoke(dto);
			//---------------------------------------------------------------------
			//根据参数名取得验证器集合
			String realPath=null;
			String idxPath=(parentPath==null?pd.getName():(parentPath+"."+pd.getName()));;
			if(idx>-1 && realParentPath!=null){
				realPath=realParentPath+"."+pd.getName();
			}else{
				realPath=idxPath;
			}
			boolean isArray=pd.getPropertyType().isArray();
			int isBaseArray=0;//0未知,1是,2否
			if(isArray){
				if(isBaseType(pd.getPropertyType().getComponentType())){
					isBaseArray=1;
				}else{
					isBaseArray=2;
				}
			}
			ValidatorsSet validators=null;
			//--------------------------------------------------------------------
			ValidatorsSet temp=configLoader.getValidators(dto.getClass(),pd.getName());
			if(temp!=null){//如果未绑定任何验证器
				if(validators==null){
					validators=new ValidatorsSet();
				}
				validators.addAll(temp);
			}
			
			if(pathValidators!=null && idx>-1 && parentPath!=null){
				temp=pathValidators.get(idxPath);
				if(temp!=null){
					if(validators==null){
						validators=new ValidatorsSet();
					}
					validators.addAll(temp);
				}
			}else if(pathValidators!=null){
				temp=pathValidators.get(realPath);
				if(temp!=null){
					if(validators==null){
						validators=new FieldValidators();
					}
					validators.addAll(temp);
				}
			}
			if(isArray && isBaseArray==1){
				if(validators !=null){
					if(value==null){
						validators.validate(context,pd,null,realPath,log);
					}else{
						int arrLen=Array.getLength(value);
						if(arrLen==0){
							validators.validate(context,pd,null,realPath,log);
						}else{
							for(int m=0;m<arrLen;m++){
								Object arrItem=Array.get(value,m);
								if(arrItem!=null ){
									validators.validate(context,pd,arrItem,realPath+"["+m+"]",log);
								}
							}
						}
					}
				}
			}else{
				if(validators!=null){
					//进行验证
					validators.validate(context,pd,value,realPath,log);
				}
			}
			//---------------------------------------------------------------------
			if(value!=null){
				if(validateSupport.supports(pd.getPropertyType())){
					_validate(value,idxPath,-1);
				}
				else if(isArray && isBaseArray==2){
					int arrLen=Array.getLength(value);
					for(int m=0;m<arrLen;m++){
						Object arrItem=Array.get(value,m);
						if(arrItem!=null ){
							if(validateSupport.supports(arrItem.getClass())){
								_validate(arrItem,idxPath,m);
							}
						}
					}
				}else if(value instanceof Collection){
					Collection<?> list=(Collection<?>)value;
					int tempInt=-1;
					for(Object obj:list){
						tempInt++;
						if(obj!=null && validateSupport.supports(obj.getClass())){
							_validate(obj,idxPath,tempInt);
						}
						
					}
				}else if(value instanceof Map){
					Map<?,?> map=(Map<?,?>)value;
					Set<?> list=map.entrySet();
					for(Object entryObj:list){
						Map.Entry<?,?> entry=(Map.Entry<?,?>)entryObj;
						Object vv=entry.getValue();
						if(vv!=null && validateSupport.supports(vv.getClass())){
							_validate(vv,idxPath+"."+entry.getKey(),-1);
						}
					}
				}
			}
		}
	} 
	
	

	
	
	
	private  boolean isBaseType(Class<?> c){
		if(c.equals(String.class)){
			return true;
			//
		}else if((c.getSuperclass()!=null && c.getSuperclass().equals(Number.class)) || c.isPrimitive()){
			return true;
		}
		return false;
	}
	
	
}
