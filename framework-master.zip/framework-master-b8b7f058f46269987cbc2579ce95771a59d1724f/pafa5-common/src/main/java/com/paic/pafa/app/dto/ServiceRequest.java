/*
 * Created on 2004-7-2
 * 
 * To change the template for this generated file go to
 *
 */
package com.paic.pafa.app.dto;

import java.util.HashMap;
import java.util.Map;

import org.springframework.ui.ModelMap;


/**
 * @author lg
 *   
 */
public class ServiceRequest extends PafaDTO {

    private static final String REQUESTED_SERVICE_ID = "REQUESTED_SERVICE_ID";
    
    private static final String REQUESTED_SERVICE_GROUP = "REQUESTED_SERVICE_GROUP";
    
    /***
     * @deprecated
     */
	public static final String CURRENT_REQUEST_OBJECT =
		"CURRENT_REQUEST_OBJECT";
	
	public static final String SESSION_DTO = "SESSION_DTO";
	 /***
     * @deprecated
     */
	public static final String CONTROL = "CONTROL";
	 /***
     * @deprecated
     */
	public static final String PRINCIPAL="PRINCIPAL";
	
	private Map parameters;

	private static final long serialVersionUID = 4490490957886951839L;
	
	/**
	 * @deprecated
	 */
	public ServiceRequest() {
		this.parameters = new HashMap();
		//setControl(new Control());
		//setSessionDTO(new SessionDTO());		
	}

	/**
	 * @param parameters
	 * @deprecated 
	 */
	public ServiceRequest(Map parameters) {
		if (parameters != null){
			this.parameters=parameters;
		}else{
			this.parameters = new HashMap();
		}
	}
	
	public ServiceRequest(String actionName,Map parameters) {
		if (parameters != null){
			this.parameters=parameters;
		}else{
			this.parameters = new HashMap();
		}
		this.setRequestedServiceID(actionName);
	}
	
	public ServiceRequest(String actionName,ModelMap model) {
		this.parameters = new HashMap();
		this.setRequestedServiceID(actionName);
		if(model!=null){
			parameters.putAll(model);
		}
	}

	/**
	 * @param parameterKey
	 */
	public Object getParameter(String parameterKey) {
		return parameters.get(parameterKey);
	}

	/**
	 * @param parameterKey
	 * @param parameter
	 */
	public void setParameter(String parameterKey, Object parameter) {
		parameters.put(parameterKey, parameter);
	}
	
	public void setActionName(String actionName){
		this.setRequestedServiceID(actionName);
	}
	
	

	/**
	 * @param serviceID
	 */
	public void setRequestedServiceID(String serviceID) {
		parameters.put(REQUESTED_SERVICE_ID, serviceID);
	}

	/**
	 * 
	 * @return the service request ID
	 */
	public String getRequestedServiceID() {
		return (String) parameters.get(REQUESTED_SERVICE_ID);
	}
	
	public String getActionName(){
		return getRequestedServiceID();
	}
	
	public String getGroup(){
		return (String) parameters.get(REQUESTED_SERVICE_GROUP);
	}
	
	public void setGroup(String group) {
		parameters.put(REQUESTED_SERVICE_GROUP, group);
	}

	/**
	 * 
	 * @return
	 * @deprecated
	 */
	public Object getCurrentRequestObject() {
		return (Object) parameters.get(CURRENT_REQUEST_OBJECT);
	}

	/**
	 * 
	 * @param obj
	 * @deprecated
	 */
	public void setCurrentRequestObject(Object obj) {
		parameters.put(CURRENT_REQUEST_OBJECT, obj);
	}

	/**
	 * @deprecated
	 * @return
	 */
	public Control getControl() {
		return (Control) parameters.get(CONTROL);
	}
	
	/**
	 * @deprecated
	 * @return
	 */
	public void setControl(Control control) {
		parameters.put(CONTROL, control);
	}

	/**
	 * @return Returns the parameters.
	 */
	public Map getParameters() {
		return parameters;
	}

	/**
	 * @param parameters
	 *            The parameters to set.
	 */
	public void setParameters(Map parameters) {
		if(this.parameters==null){
			this.parameters = parameters;
		}else{
			this.parameters.putAll(parameters);
		}
	}

	public SessionDTO getSessionDTO() {
		Object data= parameters.get(SESSION_DTO);
		if(data!=null){
			if(data instanceof SessionDTO){
				return (SessionDTO)data;
			}else if(data instanceof Map){
				SessionDTO dto=new SessionDTO();
				Map<Object,Object> map=(Map<Object,Object>)data;
				Object value=map.get("txnId");
				if(value!=null)dto.setTxnId(value.toString());
				 value=map.get("userID");
				 if(value!=null)dto.setUserId(value.toString());
				 parameters.put(SESSION_DTO, dto);
				 return dto;
			}
		}
		return null;
	}
	
	public void setSessionDTO(SessionDTO sessionDTO) {
		parameters.put(SESSION_DTO, sessionDTO);
	}

}