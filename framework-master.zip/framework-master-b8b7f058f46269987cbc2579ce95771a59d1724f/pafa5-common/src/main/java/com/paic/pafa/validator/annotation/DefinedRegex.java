package com.paic.pafa.validator.annotation;

public enum DefinedRegex {
	None(null),
	Email("^[\\w\\-\\.]+@[a-zA-Z0-9]+(\\-[a-zA-Z0-9]+)?(\\.[a-zA-Z0-9]+(\\-[a-zA-Z0-9]+)?)*\\.[a-zA-Z]{2,4}$")
	,Mobile("^((13|14|15|18)(\\d)(\\*\\*\\*\\*|\\d{4})(\\d{4,5}))?$")
	,ChineseWords("^[\\u4e00-\\u9fa5\\s]*$")
	,LetterDigitals("^[a-zA-Z\\d\\s]*$")
	,Letters("^[a-zA-Z\\s]*$")
	,Digitals("^[\\d\\s]*$");
	 
	private String regex;
	
	private DefinedRegex(String regex){
		this.regex=regex;
	}

	public String getRegex() {
		return regex;
	}

	
	
}
