package com.paic.pafa.web.util;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.StringWriter;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.StringUtils;

import com.paic.pafa.web.WebException;
import com.pingan.pafa.common.beans.json.JsonMapUtils;

public class JsonHttpServletRequestWrapper extends HttpServletRequestWrapper {
	
	
	private static Log logger=LogFactory.getLog(JsonHttpServletRequestWrapper.class);
	
	public JsonHttpServletRequestWrapper(HttpServletRequest request){
		super(request);
	}
   
	private Map<String,String[]> paramsList;
	
	
	
	@SuppressWarnings("unchecked")
	public JsonHttpServletRequestWrapper(HttpServletRequest request,Map jsonMap){
		super(request);
		if(jsonMap!=null && jsonMap.size()>0){
			JsonToFormParamsUtils utils=new JsonToFormParamsUtils();
			paramsList=utils.toHttpParams(jsonMap);
			paramsList.putAll(this.getRequest().getParameterMap());
		}else{
			paramsList=request.getParameterMap();
		}
	}
	
	

	@SuppressWarnings("unchecked")
	@Override
	public Map getParameterMap() {
		return getParamsList();
	}


	

	


	@Override
	public String getParameter(String key) {
		String[] v= this.getParamsList().get(key);
		if(v!=null && v.length>0){
			return v[0];
		}
		return null;
	}








	@SuppressWarnings("unchecked")
	@Override
	public Enumeration getParameterNames() {
		return new KeyEnumeration(this.getParamsList().keySet());
	}








	@Override
	public String[] getParameterValues(String key) {
		return this.getParamsList().get(key);
	}







	@SuppressWarnings("unchecked")
	private  Map<String,String[]> getParamsList() {
		if(paramsList==null){
			paramsList=this.getRequest().getParameterMap();
			//-----------------------------------------------
			Map<String,String[]> tempList=_read();
			if(tempList!=null && tempList.size()>0){
				tempList.putAll(paramsList);
				paramsList=tempList;
			}
		}
		return paramsList;
	}
	
	



	@SuppressWarnings("unchecked")
	private Map<String,String[]> _read(){
		String requestParams=null;
		try {
			BufferedReader in=this.getReader();
			StringWriter out=new StringWriter(128);
			//------------------------------------
			char[] buffer = new char[512];
			int bytesRead = -1;
			while ((bytesRead = in.read(buffer)) != -1) {
				out.write(buffer, 0, bytesRead);
			}
			requestParams=out.toString();
		} catch (IOException e) {
			throw new WebException(e.getMessage(),e);
		}
		if(StringUtils.hasText(requestParams)){
			if(logger.isDebugEnabled()){
				logger.debug("JsonParams="+requestParams);
			}
			Map jsonMap=null;
			try{
				 jsonMap=JsonMapUtils.toHashMap(requestParams);
			}catch(Exception ex){
				throw new WebException("PostJson["+requestParams+"] format error:"+ex.getMessage(),ex);
			}
			JsonToFormParamsUtils utils=new JsonToFormParamsUtils();
			return utils.toHttpParams(jsonMap);
		}else{
			if(logger.isDebugEnabled()){
				logger.debug("JsonParams={}");
			}
			return null;
		}
	}
	

	
	



	


	/*public static void main(String args[]){
		MockHttpServletRequest request = new MockHttpServletRequest(){
			@Override
			public BufferedReader getReader()  {
				return new BufferedReader(new CharArrayReader(("{name:'张三',sex:1,instedns:['1','22','33']," +
						"insure:{name:'李四',age:'22',addr:{postedCode:'299911',addr:'中山三道丁122号'}}}").toCharArray()));
			}
		};  
		JsonHttpServletRequestWrapper a=new JsonHttpServletRequestWrapper(request);
		System.out.println(a.getParameter("name"));
		System.out.println(a.getParameterNames());
	}*/
	

	class KeyEnumeration implements Enumeration<String>{
		
		private Iterator<String> iterator;
		
		private Set<String> keySet;
		
		public KeyEnumeration(Set<String> keySet){
			this.keySet=keySet;
		}

		public boolean hasMoreElements() {
			
			return getIterator().hasNext();
		}
		
		private Iterator<String> getIterator(){
			if(iterator==null){
				this.iterator=keySet.iterator();
			}
			return iterator;
		}

		public String nextElement() {
			return getIterator().next();
		}
		
		public String toString(){
			return this.keySet.toString();
		}
		
	}
	
	
}
