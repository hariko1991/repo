package com.paic.pafa.web;

import com.paic.pafa.Pafa4Exception;



public class WebException  extends Pafa4Exception{
	
	private static final long serialVersionUID = 1L;

	
	
	
	public WebException(String msg){
		super(msg);
	}
	
	
	
	public WebException(Throwable th){
		super(th.getMessage(),th);
	}
	
	public WebException(String msg,Throwable th){
		super(msg,th);
	}
	
	
}
