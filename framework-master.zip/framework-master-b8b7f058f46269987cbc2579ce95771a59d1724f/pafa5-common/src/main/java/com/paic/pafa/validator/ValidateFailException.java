package com.paic.pafa.validator;

import java.util.List;

import org.springframework.validation.Errors;
import org.springframework.validation.FieldError;

public class ValidateFailException extends ValidateException {

	private static final long serialVersionUID = 1L;
	
	private Errors errors;

	private Class<?> formClazz;
	
	@Override
	public String getMessage() {
		
		if(formClazz==null){
			return super.getMessage();
		}else{
			List<FieldError> list=errors.getFieldErrors();
			StringBuilder msg=new StringBuilder();
			msg.append('[');
			for(int i=0;i<list.size();i++){
				FieldError f=list.get(i);
				if(i!=0){
					msg.append(',');
				}
				msg.append(toString(f));
			}
			msg.append(']');
			
			return "Class["+formClazz.getName()+"] validate failed,cause by:"+msg;
		}
	}
	
	private String toString(FieldError fe){
		return "{path="+fe.getField()+",value="+fe.getRejectedValue()+",ruleType="+fe.getCode()+",message="+fe.getDefaultMessage()+"}";
	}
	
	public ValidateFailException(Class<?> formClazz,Errors errors){
		super((String)null);
		this.formClazz=formClazz;
		this.errors=errors;
	}

	
	public Errors getErrors() {
		return errors;
	}

	public void setErrors(Errors errors) {
		this.errors = errors;
	}

	public Class<?> getFormClazz() {
		return formClazz;
	}
	public void setFormClazz(Class<?> formClazz) {
		this.formClazz = formClazz;
	}
	public static long getSerialVersionUID() {
		return serialVersionUID;
	}
	
}
