package com.paic.pafa.biz.dao;

import com.paic.pafa.Pafa4Exception;



public class DAOException  extends Pafa4Exception{
	
	private static final long serialVersionUID = 1L;

	
	
	public DAOException(String msg){
		super(msg);
	}
	
	
	
	public DAOException(Throwable th){
		super(th.getMessage(),th);
	}
	
	public DAOException(String msg,Throwable th){
		super(msg,th);
	}
	
	
	
	
}
