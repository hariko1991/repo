package com.paic.pafa.validator.impl;

import java.beans.PropertyDescriptor;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.util.Assert;
import org.springframework.util.StringUtils;

import com.paic.pafa.validator.IValidator;
import com.paic.pafa.validator.ValidateContext;
import com.paic.pafa.validator.ValidateException;
import com.paic.pafa.validator.annotation.VDate;


public class DateValidator implements   IValidator,InitializingBean {
	
	private static Log log=LogFactory.getLog(DateValidator.class);
	

	private String min;
	
	private String max;
	
	private String pattern;
	
	private String message;
	
	
	private DateParser _minParser;
	
	private DateParser _maxParser;
	
	private Date _minDate;
	
	private Date _maxDate;
	
	
	public DateValidator(){
		
	}
	
	public DateValidator(String min,String max,String pattern){
		if(StringUtils.hasText(min)){
			this.min=min;
		}
		if(StringUtils.hasText(max)){
			this.max=max;
		}
		if(StringUtils.hasText(pattern)){
			this.pattern=pattern;
		}
		afterPropertiesSet();
	}
	
	public DateValidator(VDate vn){
		if(vn.max().length()>0){
			max=vn.max();
		}
		if(vn.min().length()>0){
			min=vn.min();
		}
		if(vn.pattern().length()>0){
			pattern=vn.pattern();
		}
		if(vn.message().length()>0){
			this.message=vn.message();
		}
		afterPropertiesSet();
	}

	
	public String getMin() {
		return min;
	}



	public String getMax() {
		return max;
	}



	public String getPattern() {
		return pattern;
	}

	


	@Override
	public RuleType getRuleType() {
		return RuleType.Date;
	}


	@Override
	public boolean validate(ValidateContext context, PropertyDescriptor feild,
			Object value, String nestedPath) {
		long v=-1;
		if(value instanceof Date){
			v=((Date)value).getTime();
		}else {
			String temp=pattern;
			if(temp==null){
				temp="yyyy-MM-dd";
			}
			try {
				SimpleDateFormat sdf=new SimpleDateFormat(temp);
				v= sdf.parse(value.toString()).getTime();
			} catch (ParseException e) {
				if(log.isErrorEnabled()){
					log.error("["+context.getTarget().getClass().getName()+"."+feild.getName()+"] [value ="+value+",pattern="+pattern+"]"+e.getMessage());
				}
				return false;
			}
		}
		if(v!=-1){
			if(min!=null){
				Date minDate=null;
				if(_minParser!=null){
					minDate=_minParser.getCompareDate();
				}else{
					minDate= _minDate;
				}
				if(v<minDate.getTime()){
					return false;
				}
			}
			if(max!=null){
				Date maxDate=null;
				if(_maxParser!=null){
					maxDate=_maxParser.getCompareDate();
				}else{
					maxDate= _maxDate;
				}
				if(v>maxDate.getTime()){
					return false;
				}
			}
			return true;
		}else{
			return false;
		}
	}
	
	
	public void setMin(String min) {
		this.min = min;
	}

	public void setMax(String max) {
		this.max = max;
	}

	public void setPattern(String pattern) {
		this.pattern = pattern;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	
	public void afterPropertiesSet() {
		try {
			if(min!=null){
				if(min.charAt(0)=='{'){
					_minParser=new DateParser(min);
				}else{
					Assert.notNull(pattern, "pattern  is null");
					SimpleDateFormat sdf=new SimpleDateFormat(pattern);
					_minDate= sdf.parse(min);
				}
			}
			if(max!=null){
				if(max.charAt(0)=='{'){
					_maxParser=new DateParser(max);
				}else{
					Assert.notNull(pattern, "pattern  is null");
					SimpleDateFormat sdf=new SimpleDateFormat(pattern);
					_maxDate= sdf.parse(max);
				}
			}
		} catch (ParseException e) {
			throw new ValidateException("Validator defined error[max="+max+",pattern="+pattern+"]"+e.getMessage());
		}
	}
	
	

	

	@Override
	public String toString() {
		return "Datetime@@min="+min+",max="+max+",pattern="+pattern;
	}
}
