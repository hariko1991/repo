package com.paic.pafa.ac;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.BeansException;
import org.springframework.context.ApplicationContext;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.app.biz.ac.ApplicationControllerException;
import com.paic.pafa.app.biz.action.Action;
import com.paic.pafa.app.dto.ServiceRequest;
import com.paic.pafa.app.dto.ServiceResponse;

/***
 * @deprecated
 * @author LIXINGNAN945
 *
 */
public class ActionDispatcher implements AppDispatcher {
	
	protected Log log=LogFactory.getLog(this.getClass());
	
	private ApplicationContext applicationContext;
  
	@Override
	public void setApplicationContext(ApplicationContext applicationContext)
			throws BeansException {
		this.applicationContext=applicationContext;
	}
	
	@Override
	public   ServiceResponse handleRequest(ServiceRequest request) throws ApplicationControllerException {
		String actionName=request.getRequestedServiceID();
		if(actionName==null || (actionName=actionName.trim()).length()==0){
			throw new ApplicationControllerException("Not setter action name,request.requestedServiceID() is null.");
		}
		if(log.isInfoEnabled()){
			log.info("Handling Action<"+actionName+">...");
		}
		long t1=System.currentTimeMillis();
		try {
			Action  action=getAction(actionName);
			//---------------------------------------------
			Log actionLog=getActionLog(request,action);
			if(actionLog.isDebugEnabled() && log.isDebugEnabled()){
				log.debug("Handling Action<"+actionName+"> params="+JSONObject.toJSONString(request.getParameters()));
			}
			ServiceResponse response=dispatch((Action)action,request,actionName);
			Object m=(response==null?null:response.getModel());
			//------------------------------
			if(actionLog.isDebugEnabled() && log.isDebugEnabled()){
				log.debug("Handled Action<"+actionName+">result="+(m==null?"{}":JSONObject.toJSONString(m))+".");
			}
			if(log.isInfoEnabled()){
				log.info("#"+(System.currentTimeMillis()-t1)+"ms# Handled Action<"+actionName+"> completed.");
			}
			return response;
		} catch (Throwable e) {
			//------------
			if(log.isErrorEnabled()){
				String message="#"+(System.currentTimeMillis()-t1)+"ms# Handled Action<"+actionName+"> failed,params="
					+JSONObject.toJSONString(request.getParameters());
				log.error(message);
				Throwable logEx=null;
				if(e instanceof ApplicationControllerException && e.getCause()!=null){
					logEx=e.getCause();
				}else{
					logEx=e;
				}
				log.error(logEx.getMessage(),logEx);
			}
			if(e instanceof RuntimeException){
				throw (RuntimeException)e;
			}else if(e instanceof ApplicationControllerException){
				throw (ApplicationControllerException)e;
			}else{
				throw new ApplicationControllerException(e);
			}
		}
	}
	
	protected Log getActionLog(ServiceRequest request,Action action){
		Class<?> beanClass= AopUtils.getTargetClass(action);
		return LogFactory.getLog(beanClass);
	}
	
	protected Action getAction(String actionBeanName) throws ApplicationControllerException{
		Object bean=null;
		try{
			bean=getApplicationContext().getBean(actionBeanName); 
		}catch(BeansException ex){
			throw new ApplicationControllerException("Action<"+actionBeanName+"> error:"+ex.getMessage(),ex);
		}
		if(!(bean instanceof Action)){
			throw new ApplicationControllerException("Not found action<"+actionBeanName+">");
		}
		return (Action)bean;
	}
	

	protected ApplicationContext getApplicationContext() throws ApplicationControllerException{
		if(applicationContext==null){
			throw new ApplicationControllerException("Not setter ApplicationContext or ApplicationContext initialized fail.");
		}
		return applicationContext;
	}
	
	
	protected ServiceResponse dispatch(Action action,ServiceRequest request,String actionBeanName) throws Exception {
		return action.perform(request);
	}
}
