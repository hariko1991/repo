package com.paic.pafa.web.util;

import java.io.UnsupportedEncodingException;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.http.MediaType;

import com.paic.pafa.Pafa4Exception;

/***
 * @deprecated
 * @author LIXINGNAN945
 *
 */
public class WebCommonUtils   implements InitializingBean,ApplicationContextAware{
	
	private static final String HEADER_PRAGMA = "Pragma";

	private static final String HEADER_EXPIRES = "Expires";

	private static final String HEADER_CACHE_CONTROL = "Cache-Control";
	
	private String defaultCharset;
	
	private boolean preventCaching=true;
	
	private boolean enableResolveCharset=true;
	
	private boolean enableSetterCommonAttrs=false;
	
	private boolean cookieCrossDomainSupport=false;
	
	
	private boolean disableRequestLog=false;
	
	private ApplicationContext applicationContext;
	
	private ContentTypeUtil contentTypeUtil=new ContentTypeUtil();
	
	protected Log logger=LogFactory.getLog(this.getClass());
	
	
	
	public MediaType getMediaType(ServletRequest request){
		return contentTypeUtil.getMediaType(request);
	}
	
	public String resolveCharset(HttpServletRequest request,HttpServletResponse response){
		String requestCharset=null;
		if(enableResolveCharset){
			requestCharset=contentTypeUtil.getCharset(request, defaultCharset);
		}else{
			requestCharset=defaultCharset;
		}
		//----------------------------------------------------------
		if(requestCharset!=null){
			try {
				request.setCharacterEncoding(requestCharset);
				response.setCharacterEncoding(requestCharset);
			} catch (UnsupportedEncodingException e) {
				throw new Pafa4Exception(e.getMessage(),e);
			}
		}
		return requestCharset;
	}
	
	public void resolveCrossDomainHeader(HttpServletResponse response){
		if(cookieCrossDomainSupport){
			response.setHeader("P3P","CP=CAO PSA OUR");
			response.addHeader("Access-Control-Allow-Origin", "*");
		}
	}
	

	@Override
	public void afterPropertiesSet() throws Exception {
		logger.info("config["+"defaultCharset="+defaultCharset
				+",preventCaching="+preventCaching+",cookieCrossDomainSupport="+cookieCrossDomainSupport+",disableRequestLog="+disableRequestLog+"]");
	}
	

	
	public ApplicationContext getApplicationContext() {
		return applicationContext;
	}

	public void setApplicationContext(ApplicationContext applicationContext) {
		this.applicationContext = applicationContext;
	}

	public void preventCaching(HttpServletResponse response) {
		if(preventCaching){
			response.setHeader(HEADER_PRAGMA, "no-cache");
			response.setDateHeader(HEADER_EXPIRES, 1L);
			response.setHeader(HEADER_CACHE_CONTROL, "no-cache");
			response.addHeader(HEADER_CACHE_CONTROL, "no-store");
		}
	}
	
	

	public boolean isDisableRequestLog() {
		return disableRequestLog;
	}

	public void setDisableRequestLog(boolean disableRequestLog) {
		this.disableRequestLog = disableRequestLog;
	}

	public String getDefaultCharset() {
		return defaultCharset;
	}

	public void setDefaultCharset(String defaultCharset) {
		this.defaultCharset = defaultCharset;
	}

	public boolean isPreventCaching() {
		return preventCaching;
	}

	public void setPreventCaching(boolean preventCaching) {
		this.preventCaching = preventCaching;
	}

	public boolean isCookieCrossDomainSupport() {
		return cookieCrossDomainSupport;
	}

	public void setCookieCrossDomainSupport(boolean cookieCrossDomainSupport) {
		this.cookieCrossDomainSupport = cookieCrossDomainSupport;
	}

	public ContentTypeUtil getContentTypeUtil() {
		return contentTypeUtil;
	}

	public void setContentTypeUtil(ContentTypeUtil contentTypeUtil) {
		this.contentTypeUtil = contentTypeUtil;
	}

	public boolean isEnableResolveCharset() {
		return enableResolveCharset;
	}

	public void setEnableResolveCharset(boolean enableResolveCharset) {
		this.enableResolveCharset = enableResolveCharset;
	}

	public boolean isEnableSetterCommonAttrs() {
		return enableSetterCommonAttrs;
	}

	public void setEnableSetterCommonAttrs(boolean enableSetterCommonAttrs) {
		this.enableSetterCommonAttrs = enableSetterCommonAttrs;
	}

	
	

}
