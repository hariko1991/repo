package com.paic.pafa.utils;

import java.util.UUID;

import com.paic.pafa.core.service.IDGenService;

public class IdMakerUUID  implements IDGenService {

	@Override
	public String getID() {
		return UUID.randomUUID().toString();
	}
	
}
