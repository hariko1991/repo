package com.paic.pafa.validator;

import java.util.Map;

import com.paic.pafa.validator.annotation.ConfigLoader;

public interface ValidateSupport extends org.springframework.validation.Validator {
	

	public abstract void validate(Object target) throws ValidateFailException;
	
	
	public abstract Map<String,NestedPathValidators> getPathValidators(Class<?> beanClazz);
	
	public abstract ConfigLoader getConfigLoader();
	
	
}
