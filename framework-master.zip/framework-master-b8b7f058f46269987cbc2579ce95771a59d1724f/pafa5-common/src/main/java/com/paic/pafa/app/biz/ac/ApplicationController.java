/*
 * Created on 2004-7-2
 *
 * To change the template for this generated file go to
 *
 */
package com.paic.pafa.app.biz.ac;

import java.rmi.RemoteException;

import com.paic.pafa.app.dto.ServiceRequest;
import com.paic.pafa.app.dto.ServiceResponse;

/**
 * gateway interface.
 * @author lg
 * 
 *
 */
public interface ApplicationController {

	/*
	 * Command pattend
	 */
	public ServiceResponse handleRequest(ServiceRequest request)
		throws ApplicationControllerException, RemoteException;
}
