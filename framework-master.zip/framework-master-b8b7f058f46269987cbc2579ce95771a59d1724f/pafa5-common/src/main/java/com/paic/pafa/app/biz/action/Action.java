/*
 * Created on 2005-2-4
 *
 *
 *
 */
package com.paic.pafa.app.biz.action;

import com.paic.pafa.app.dto.ServiceRequest;
import com.paic.pafa.app.dto.ServiceResponse;

/**
 * Action is where application logic resides. It is closely related with
 * user request.
 * 
 * @author architect
 * 
 */
public interface Action {
	public ServiceResponse perform(ServiceRequest request)
	throws Exception;

}
