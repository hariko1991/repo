package com.paic.pafa;



/***
 *
 * @author LIXINGNAN945
 *
 */
public abstract class Pafa  {
	
	public static final String PARAM_NAME_DATA_TYPE="pafa_data_type";
	
	/***
	 * @deprecated
	 */
	public static final String PARAM_NAME_DISABLE_LOG="pafa_disable_log";
	
	public static final String PARAM_NAME_METHOD_META="pafa_method_meta";
	
	public static final String PARAM_NAME_METHOD_RESULT="pafa_method_result";
	
	/***
	 * @deprecated
	 */
	public static final String PARAM_NAME_ASYNC_FLAG="pafa_async_flag";
	
	/***
	 * @deprecated
	 */
	public static final String PARAM_NAME_LOCAL_PRIORITY="pafa_local_priority";
	
	
	public static final String DATA_TYPE_MAP="map";
	/**@deprecated*/
	public static final String ENV_TYPE_PRD="prd";
	/**@deprecated*/
	public static final String ENV_TYPE_DVP="dvp";
	/**@deprecated*/
	public static final String ENV_TYPE_STG="stg";
	/**@deprecated*/
	public static final String ENV_TYPE_TEST="test";
	
	/**@deprecated*/
	public static final String ENV_TYPE_KEY="pafa.e.type";
	
	public static final String LOG_HOME_KEY="pafa.log.home";

	//----------------------------------------------------------
	public Pafa(){
	}
	
	private static String envType=ENV_TYPE_PRD;
	
	
	//---------------------------------------------
	
	
	/**@deprecated*/
	public  static boolean isTEST(){
		return ENV_TYPE_TEST.equals(envType);
	}
	/**@deprecated*/
	public static boolean isPRD(){
		return envType==null ||  ENV_TYPE_PRD.equals(envType)  ;
	}
	/**@deprecated*/
	public static boolean isSTG(){
		return  ENV_TYPE_STG.equals(envType);
	}
	
	/**@deprecated*/
	public static boolean isDVP(){
		return ENV_TYPE_DVP.equals(envType);
	}


	/**@deprecated*/
	public static String getEnvType() {
		return envType;
	}


	/**@deprecated*/
	public static void setEnvType(String envType) {
		Pafa.envType = envType;
	}




	

}
 
