/*
 * Created on 2005-3-11
 *
 * TODO To change the template for this generated file go to
 * Window - Preferences - Java - Code Style - Code Templates
 */
package com.paic.pafa.app.integration.sa;

/**
 * Service interface that integrates external systems. Action can invoke
 * this component directly.
 * @author wangguosheng001
 * @deprecated
 */
public interface PafaSAO {

}
