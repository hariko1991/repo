/*
 * Created on 2005-3-8
 *
 *
 *
 */
package com.paic.pafa.app.integration.dao;




/**
 * DAO interface
 * @author architect
 * @deprecated
 */
public interface PafaDAO  {

}
