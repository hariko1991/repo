package com.paic.pafa.validator.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


@Target({ElementType.TYPE,ElementType.METHOD,ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)

/***
 * 成员变量嵌套路径校验配置。
 * 在ESA绑定参数、Form绑定时，因为Form/DTO上的校验配置是所有ESA/Controller共享的，
 * 如果某个ESA/Controller/REST要增加或修改配置，且只对自身有效，则需要使用@Validators完成。
 * 此注解用于ESA/Controller/Rest类上。
 */
public @interface Validators {
	/***
	 * 校验目标成员变量的相对于ESA/Form的嵌套路径
	 * 示例：insured.name
	 * @return
	 */
	String path();
	
	VDate[] VDate() default{};
	
	VLength[] VLength() default{};
	
	VNumber[] VNumber() default{};
	
	VEnum[] VEnum() default{};
	
	VNotEmpty[] VNotEmpty() default{};
	
	VRegex[] VRegex() default{};
	
	VEmpty[] VEmpty() default{};
	
	
	@Target({ElementType.TYPE,ElementType.METHOD,ElementType.FIELD})
	@Retention(RetentionPolicy.RUNTIME)
	/**配置集合*/
	public @interface List {
		
		Validators[] value() default {};
		
	}
	
	
	//VCustom [] VCustom() default {};
	
	
}
