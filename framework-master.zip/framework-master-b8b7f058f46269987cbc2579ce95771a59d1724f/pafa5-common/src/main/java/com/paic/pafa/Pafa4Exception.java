package com.paic.pafa;

public class Pafa4Exception extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public Pafa4Exception(String msg) {
		super(msg);
	}

	public Pafa4Exception(Throwable th) {
		super(th);
	}

	public Pafa4Exception(String msg, Throwable th) {
		super(msg, th);
	}
}
