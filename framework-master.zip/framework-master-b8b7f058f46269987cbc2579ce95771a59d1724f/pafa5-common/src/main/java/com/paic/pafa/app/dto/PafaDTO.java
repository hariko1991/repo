/*
 * Created on 2005-2-6
 *
 *
 *
 */
package com.paic.pafa.app.dto;

import java.io.Serializable;

/**
 * @author architect
 *
 *
 *
 */
public class PafaDTO implements Serializable {
	static final long serialVersionUID = -4623703295938223949L;
}
