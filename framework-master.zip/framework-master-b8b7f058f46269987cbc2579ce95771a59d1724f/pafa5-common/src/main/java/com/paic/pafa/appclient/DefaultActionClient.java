package com.paic.pafa.appclient;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.FatalBeanException;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.app.biz.ac.ApplicationController;
import com.paic.pafa.app.biz.ac.ApplicationControllerException;
import com.paic.pafa.app.biz.action.Action;
import com.paic.pafa.app.dto.ServiceRequest;
import com.paic.pafa.app.dto.ServiceResponse;
import com.paic.pafa.utils.MDCUtil;

public class DefaultActionClient extends BaseServiceClient implements Action  {
	
	
	private String name;
	
	private String group;
	
	private ApplicationController pafaAcBean;
	
	private String pafaAc;
	
	public DefaultActionClient(){}

	public DefaultActionClient(String name,String pafaAc){
		this.name=name;
		this.pafaAc=pafaAc;
	}
	
	@Override
	protected String getServiceName() {
		return name;
	}


	@Override
	public ServiceResponse perform(ServiceRequest request)
			throws Exception {
		request.setRequestedServiceID(this.name);
		if(group!=null) {
			request.setGroup(group);
		}
		return  performRequest(request);
	}
	
	public ServiceResults invoke(Object paramsModel) {
		Map params=processParams(paramsModel);
		ServiceRequest request=new ServiceRequest(this.name,params);
		if(group!=null) {
			request.setGroup(group);
		}
		//--------------------------------------
		ServiceResponse resp= performRequest(request);
		Map model=null;
		if(resp!=null){
			model= resp.getModel();
		}
		//-------------------------------
		return processResult(model);
	}

	private ApplicationController getPafaAcBean(){
		if(this.pafaAcBean==null){
			if(!this.applicationContext.containsBean(pafaAc)){
				throw new FatalBeanException("Not define bean  for pafaAc <"+pafaAc+"> ");
			}
			Object bean=this.applicationContext.getBean(pafaAc);
			if(!(bean instanceof ApplicationController)){
				throw new FatalBeanException("Bean of pafaAc<"+pafaAc+"> not instanceof <"+ApplicationController.class.getName()+">");
			}
			this.pafaAcBean=(ApplicationController)bean;
		}
		return this.pafaAcBean;
	}
	//private static final com.paic.pafa.app.dto.Control controlDTO= new com.paic.pafa.app.dto.Control();
	
	@SuppressWarnings({  "deprecation" })
	private  ServiceResponse performRequest(ServiceRequest request) {
		long t1=System.nanoTime();
		if(logger.isDebugEnabled()){
			StringBuilder sb=new StringBuilder();
			sb.append("Invoking<"+name+"> by <"+pafaAc+">");
			sb.append(",params="+JSONObject.toJSONString(request.getParameters()));
			sb.append(".");
			logger.info(sb);
		}
		//--------------------- 
		request.setSessionDTO(MDCUtil.peekSessionDTO(request.getSessionDTO()));
		//request.setControl(controlDTO);
   		//-----------------------------------------------------
		ServiceResponse resp=null;
		try {
			resp=  this.getPafaAcBean().handleRequest(request);
			if(resp!=null){
				processResponse(resp);
			}
			//--------------------------------
			if(logger.isInfoEnabled()){
				StringBuilder sb=new StringBuilder();
				sb.append("#"+(System.nanoTime()-t1)/1000/1000.0+"ms#Invoked<"+name+"> by <"+pafaAc+">");
				if(logger.isDebugEnabled()){
					sb.append(",result=");
					Object m=(resp==null?null:resp.getModel());
					sb.append(m==null?"null":JSONObject.toJSONString(m));
				}
				sb.append(".");
				logger.info(sb);
			}
		} catch (Throwable ex) {
			if(ex instanceof ApplicationControllerException && ex.getCause()!=null){
				ex=ex.getCause();
			}
			StringBuilder sb=new StringBuilder();
			Class<?> handleClazz=this.getHandleClazz();
			sb.append("#"+(System.nanoTime()-t1)/1000/1000.0+"ms#Invoked<"+name+"> by <"+pafaAc+"><"+(handleClazz==null?"unknown":handleClazz.getName())+">");
			sb.append(",params="+JSONObject.toJSONString(request.getParameters()));
			sb.append(".");
			if(logger.isErrorEnabled()){
				logger.error(sb);
				logger.error(ex.getMessage(),ex);
			}
			throw new AppClientException(sb.toString(),ex);
		}
		return resp;	
	}
	
	@SuppressWarnings({ "unused", "unchecked" })
	private  void processResponse(ServiceResponse resp){
		Map model=resp.getModel();
		if(model==null){
			model=new HashMap(2);
			model.put("responseCode", resp.getResponseCode());
			if(resp.getResponseMsg()!=null){
				model.put("responseMsg", resp.getResponseMsg());
			}
			resp.setModel(model);
		}else{
			String code=resp.getResponseCode();
			if(!model.containsKey("responseCode")){
				model.put("responseCode", resp.getResponseCode());
			}
			if(resp.getResponseMsg()!=null && !model.containsKey("responseMsg")){
				model.put("responseMsg", resp.getResponseMsg());
			}
		}
	}
	
	
	


	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}


	public String getPafaAc() {
		return pafaAc;
	}

	public void setPafaAc(String pafaAc) {
		this.pafaAc = pafaAc;
	}

	@Override
	public void afterPropertiesSet() throws Exception  {
		super.afterPropertiesSet();
		if(this.pafaAc==null){
			throw new FatalBeanException("pafaAc is null");
		}
		if(this.name==null){
			throw new FatalBeanException("name is null");
		}
		//---------------------
		getPafaAcBean();
	}

	public void setPafaAcBean(ApplicationController pafaAcBean) {
		this.pafaAcBean = pafaAcBean;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	
	
	
}
