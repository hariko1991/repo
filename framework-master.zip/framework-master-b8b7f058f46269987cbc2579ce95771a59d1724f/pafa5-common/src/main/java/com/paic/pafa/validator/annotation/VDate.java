package com.paic.pafa.validator.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


@Target({ElementType.METHOD,ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
/**日期校验，目标类型：java.util.Date或java.lang.String*/
public @interface VDate {
	/**
	 * 下限限制。
	 * 如果以当前系统时间比较基线，配置方式示例:保险起期必须Today+2天,则配置"{+2d}"
	 * 		<p>{}表示当前系统时间比较基线</p>
	 * 		<p>+2:表示在当前时间基础上增加，反之”-“为当前系统时间基础上减除</p>
	 * 		<p>d:为单位,d为天,y:年,M:月,H:时,m:分,s秒</p>
	 * 反之，字符串格式必须与{@link #pattern()}匹配，示例："1990-01-01"
	 * */
	String min() default "";
	/**上限限制*/
	String max() default "";
	
	/**如果成员变量为字符串，可用此限定字符串符合此日期格式*/
	String pattern() default "";
	/**默认错误信息*/
	String message() default "";
}
