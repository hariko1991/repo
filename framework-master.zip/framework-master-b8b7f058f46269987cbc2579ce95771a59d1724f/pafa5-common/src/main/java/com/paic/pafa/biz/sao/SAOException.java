package com.paic.pafa.biz.sao;

import com.paic.pafa.Pafa4Exception;


public class SAOException extends Pafa4Exception {

	
	private static final long serialVersionUID = 1L;

	public SAOException(String msg){
		super(msg);
	}
	
	public SAOException(String msg,Throwable th){
		super(msg,th);
	}
	
	public SAOException(Throwable th){
		super(th.getMessage(),th); 
	}
}
