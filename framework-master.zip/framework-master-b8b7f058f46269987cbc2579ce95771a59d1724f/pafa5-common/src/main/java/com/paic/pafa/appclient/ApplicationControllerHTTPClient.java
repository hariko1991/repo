package com.paic.pafa.appclient;

import org.springframework.remoting.httpinvoker.HttpInvokerProxyFactoryBean;

import com.paic.pafa.app.biz.ac.ApplicationController;

/**
 * 
 * @author lixingnan945
 */
public class ApplicationControllerHTTPClient extends HttpInvokerProxyFactoryBean  {

	 
	 
	public ApplicationControllerHTTPClient(){
		setServiceInterface(ApplicationController.class);
	}


}
