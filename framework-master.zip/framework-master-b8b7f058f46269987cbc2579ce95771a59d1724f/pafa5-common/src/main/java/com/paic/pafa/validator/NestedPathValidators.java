package com.paic.pafa.validator;

import com.paic.pafa.validator.annotation.VNotEmpty;
import com.paic.pafa.validator.annotation.Valid;

@Valid
public class NestedPathValidators extends ValidatorsSet {
	@VNotEmpty
	private String path;
	
	public String getPath() {
		return path;
	}

	public void setPath(String path) {
		this.path = path;
	}
	


	@Override
	public void add(IValidator v) {
		super.add(v);
	}


	
	
	
}
