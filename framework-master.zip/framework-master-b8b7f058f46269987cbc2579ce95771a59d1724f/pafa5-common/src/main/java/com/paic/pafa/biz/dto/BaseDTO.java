package com.paic.pafa.biz.dto;

/***
 * DTO
 * @author lixingnan945
 */
public class BaseDTO implements java.io.Serializable,java.lang.Cloneable,DTO {

	private static final long serialVersionUID = 1L;
	
	
	public Object clone()  {
		try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			return null;
		}
	}
	
	
}
