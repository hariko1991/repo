/*
 * Created on 2005-2-2
 *
 *
 *
 */
package com.paic.pafa.app.biz;

import java.util.Map;


/**
 * 
 * 
 * This bean can be used to configure application specific data.
 * Application Controller (the Pafa Gateway) uses it to decide what requests need to invoke the 
 * txnActionBean to apply transaction control before invoking the
 * POJO transaction. 
 * 
 * @author architect
 * @deprecated
 */
public class Mapping{
    
    private Map mapping;

    public Mapping(){
    	
    }
    
	/**
	 * @return Returns the mapping.
	 */
	public Map getMapping() {
		return mapping;
	}
	/**
	 * @param mapping The mapping to set.
	 */
	public void setMapping(Map mapping) {
		this.mapping = mapping;
	}
	
	public Object get(Object key){
		return mapping==null?null:mapping.get(key);
	}
}
