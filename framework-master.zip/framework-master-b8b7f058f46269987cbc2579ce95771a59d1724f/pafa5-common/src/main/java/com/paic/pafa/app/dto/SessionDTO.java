/*
 * Created on 2005-3-10
 *
 *
 *
 */
package com.paic.pafa.app.dto;


/**
 * @author wangguosheng001
 * <p>
 * Passes information across tiers or system boundary
 */
public class SessionDTO extends PafaDTO {
    private String txnId = null;
    private String userId = null;
    static final long serialVersionUID = 7821231580564395369L;

    public SessionDTO() {
        super();
    }

    /**
     * @return userId
     */
    public String getUserId() {
        return userId;
    }

    /**
     * @param userID
     */
    public void setUserId(String userID) {
        userId = userID;
    }

    /**
     * @return Returns the txnId.
     */
    public String getTxnId() {
        return txnId;
    }

    /**
     * @param txnId The txnId to set.
     */
    public void setTxnId(String txnId) {
        this.txnId = txnId;
    }

	@Override
	public String toString() {
		return "{userId="+this.userId+",txnId="+this.txnId+"}";
	}
    
    
}
