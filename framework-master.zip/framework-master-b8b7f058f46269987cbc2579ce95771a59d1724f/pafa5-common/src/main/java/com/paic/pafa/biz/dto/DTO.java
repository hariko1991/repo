package com.paic.pafa.biz.dto;


public interface DTO {

}
