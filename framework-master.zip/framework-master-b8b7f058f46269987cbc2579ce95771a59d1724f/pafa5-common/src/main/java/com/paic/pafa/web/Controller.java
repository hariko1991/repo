package com.paic.pafa.web;

public interface Controller {

}
