package com.paic.pafa.biz.services;

import com.paic.pafa.Pafa4Exception;



public class ServicesException  extends Pafa4Exception{
	
	private static final long serialVersionUID = 1L;

	
	
	public ServicesException(String msg){
		super(msg);
	}
	
	
	
	public ServicesException(Throwable th){
		super(th.getMessage(),th);
	}
	
	public ServicesException(String msg,Throwable th){
		super(msg,th);
	}
	
	
	
	
}
