package com.paic.pafa.validator.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


@Target({ElementType.METHOD,ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
/**长度限定配置，目标类型为：String及Number子类*/
public @interface VLength {
	/**最小长度限定，-1不限定*/
	int min() default -1;
	/**最大长度限定，-1不限定*/
	int max() default -1;
	/**是否按字节计算，否则按字符计算*/
	boolean byteUnit() default false;
	/**默认错误信息*/
	String message() default "";
}
