package com.paic.pafa.appclient.interceptor;

/***
 * @deprecated
 * @author LIXINGNAN945
 *
 */
public interface InterceptCallback {
	public  abstract Object todo() throws Throwable;
}
