package com.paic.pafa.validator;

import java.beans.PropertyDescriptor;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;

import com.paic.pafa.validator.impl.DateValidator;
import com.paic.pafa.validator.impl.EmptyValidator;
import com.paic.pafa.validator.impl.EnumsValidator;
import com.paic.pafa.validator.impl.LengthValidator;
import com.paic.pafa.validator.impl.NumberValidator;
import com.paic.pafa.validator.impl.RegexValidator;

public class ValidatorsSet {

	
	
	private DateValidator datetime;
	
	private EnumsValidator enums;
	
	private LengthValidator length;
	
	private EmptyValidator empty;
	
	private NumberValidator number;
	
	private RegexValidator regex;
	
	
	/**不通过验证类型:-1未知,0自定义规则,1长度验证,2数值验证,3枚举验证,4正则表达式验证,5非空验证,6日期验证*/
	public void add(IValidator v){
		if(v==null){
			return ;
		}
		switch(v.getRuleType().getTypeCode()){
			case 1 :this.length=(LengthValidator)v; break;
			case 2:this.number=(NumberValidator)v; break;
			case 3:this.enums=(EnumsValidator)v; break;
			case 4:this.regex=(RegexValidator)v; break;
			case 5:this.empty=(EmptyValidator)v; break;
			case 6:this.datetime=(DateValidator)v; break;
		}
	}
	
	public int getSize(){
		IValidator[] vs=this.toArray();
		int size=0;
		for(int i=0;i<vs.length;i++){
			IValidator v=(IValidator)vs[i];
			if(v!=null){
				size++;
			}
		}
		return size;
	}

	private IValidator[] toArray(){
		return new IValidator[]{empty,length,number,regex,datetime,enums};
	}
	
	public List<IValidator> toList(){
		IValidator[] vs=this.toArray();
		List<IValidator> datas=new ArrayList<IValidator>(6);
		for(int i=0;i<vs.length;i++){
			IValidator v=(IValidator)vs[i];
			if(v!=null){
				datas.add(v);
			}
		}
		return datas;
	}


	public void addAll(ValidatorsSet set){
		if(set==null)return;
		IValidator[] vs=set.toArray();
		for(int i=0;i<vs.length;i++){
			IValidator v=(IValidator)vs[i];
			this.add(v);
		}
	}
	
	public void validate(ValidateContext context,PropertyDescriptor feild,Object value,String path,Log log) {
		if(value==null){
			if(empty!=null){
				try {
					if(!empty.validate(context,feild,value,path)){
						log.warn("Validator["+empty+"] valid ["+path+"="+value+"] failed.");
						context.getErrors().rejectValue(path,empty.getRuleType().toString(), empty.getMessage());
					}
				} catch (Throwable e) {
					throw new ValidateException("Validator["+empty+"] validate ["+path+"="+value+"]"+e.getMessage(),e);
				}
			}
		}else{
			//取所有验证器进行验证
			IValidator [] vs=this.toArray();
			for(int i=0;i<vs.length;i++){
				IValidator v=vs[i];
				if(v!=null){
					try {
						if(!v.validate(context,feild,value,path)){
							log.warn("Validator["+v+"] valid ["+path+"="+value+"] failed.");
							context.getErrors().rejectValue(path, v.getRuleType().toString(), v.getMessage());
						}
					} catch (Throwable e) {
						throw new ValidateException("Validator["+v+"] validate feild["+path+"="+value+"]error:"+e.getMessage(),e);
					}
				}
			}
			return ;
		}
	}
	
	
	
	
	

	/**重写toString()方法,仅用于日志输出**/
	public String toString(){
		try {
			return this.toList().toString();
		} catch (Exception e) {
			return super.toString();
		} 
	}
	
	
	

	public DateValidator getDatetime() {
		return datetime;
	}

	public void setDatetime(DateValidator datetime) {
		this.datetime = datetime;
	}

	public EnumsValidator getEnums() {
		return enums;
	}

	public void setEnums(EnumsValidator enums) {
		this.enums = enums;
	}

	public LengthValidator getLength() {
		return length;
	}

	public void setLength(LengthValidator length) {
		this.length = length;
	}


	public EmptyValidator getEmpty() {
		return empty;
	}

	public void setEmpty(EmptyValidator empty) {
		this.empty = empty;
	}

	public NumberValidator getNumber() {
		return number;
	}

	public void setNumber(NumberValidator number) {
		this.number = number;
	}

	public RegexValidator getRegex() {
		return regex;
	}

	public void setRegex(RegexValidator regex) {
		this.regex = regex;
	}
	
	
	
	
}
