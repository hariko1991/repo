package com.paic.pafa.utils;

import org.springframework.beans.factory.FactoryBean;

import com.paic.pafa.core.service.IDGenService;


public class IdMaker implements FactoryBean<Object>,IDGenService {
    

	private static IDGenService instance= new IdMaker64();
	
	
	
    @Override
	public Object getObject() throws Exception {
		return instance;
	}


	@Override
	public Class<?> getObjectType() {
		return IDGenService.class;
	}


	@Override
	public boolean isSingleton() {
		return true;
	}


	@Override
	public String getID() {
		return generate();
	}
	
	public static IDGenService getInstance(){
		return instance;
	}

	/***
     * 
     * @return
     */
	public static String generate(){
		return instance.getID();
	}
}
