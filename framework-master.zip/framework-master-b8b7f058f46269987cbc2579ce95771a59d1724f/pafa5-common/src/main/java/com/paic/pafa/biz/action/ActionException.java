package com.paic.pafa.biz.action;

import com.paic.pafa.Pafa4Exception;



public class ActionException  extends Pafa4Exception{
	
	private static final long serialVersionUID = 1L;

	
	public ActionException(String msg){
		super(msg);
	}
	
	
	public ActionException(Throwable th){
		super(th.getMessage(),th);
	}
	
	public ActionException(String msg,Throwable th){
		super(msg,th);
	}
	
	
}
