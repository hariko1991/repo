package com.paic.pafa.biz.dao;

public interface DAO {

}
