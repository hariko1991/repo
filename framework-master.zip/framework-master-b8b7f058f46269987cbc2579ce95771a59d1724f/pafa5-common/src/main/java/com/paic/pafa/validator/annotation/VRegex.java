package com.paic.pafa.validator.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;


@Target({ElementType.METHOD,ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
/**正则表达式配置，目标类型：String*/
public @interface VRegex {
	/**正则表达式*/
	String value() default "";
	/**一些内置的表达式*/ 
	DefinedRegex defined() default com.paic.pafa.validator.annotation.DefinedRegex.None;
	/**默认错误信息*/
	String message() default "";
}
