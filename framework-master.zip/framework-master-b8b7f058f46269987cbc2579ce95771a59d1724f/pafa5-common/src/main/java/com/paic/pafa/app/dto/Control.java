/*
 * Created on Aug 17, 2004
 *
 * To change the template for this generated file go to
 *
 */
package com.paic.pafa.app.dto;


/**
 * @author mayli
 * @deprecated {@link SessionDTO}
 *
 *
 */
public class Control extends PafaDTO {
    private String requestId = null;
    //private String txnId = null;
    private String userId = null;

    //private String appController;	//name of application controller ej bean
   // private boolean validated = false;

    /**
     *
     */
    public Control() {
    }

    /**
     * @return
     */
    public String getRequestId() {
        return requestId;
    }

   
    /**
     * @return
     */
    public String getUserId() {
        return userId;
    }

    
    /**
     * @param string
     */
    public void setRequestId(String string) {
        requestId = string;
    }

   

    /**
     * @param string
     */
    public void setUserId(String string) {
        userId = string;
    }

   
}
