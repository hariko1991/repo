package com.paic.pafa.biz.action;

import com.paic.pafa.app.biz.action.Action;

/**
 * @deprecated
 * @author LIXINGNAN945
 * 
 */
public interface ESA extends Action {
	
	 void execute() throws Throwable;
	 
	 String getActionName();  
	   
}
