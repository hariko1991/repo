package com.paic.pafa.ac;

import org.springframework.context.ApplicationContextAware;

import com.paic.pafa.app.biz.ac.ApplicationController;

public interface AppDispatcher extends ApplicationController,ApplicationContextAware{
	
	 
}
