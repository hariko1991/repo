package com.paic.pafa.validator.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD,ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
/***
 * 成员变量的值不能为null
 * 如果是String类型不能为空字符串("")，Collection.size()、Array.length不能为=0
 */
public @interface VEmpty {
	/**默认的错误信息*/
	String message() default "";
}
