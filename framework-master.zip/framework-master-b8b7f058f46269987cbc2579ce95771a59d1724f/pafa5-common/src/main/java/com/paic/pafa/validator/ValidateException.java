package com.paic.pafa.validator;

import com.paic.pafa.Pafa4Exception;


public class ValidateException extends Pafa4Exception {

private static final long serialVersionUID = 1L;
	
	
	public ValidateException(String msg){
		super(msg);
	}
	public ValidateException(String msg,Throwable th){
		super(msg,th);
	}
	
}
