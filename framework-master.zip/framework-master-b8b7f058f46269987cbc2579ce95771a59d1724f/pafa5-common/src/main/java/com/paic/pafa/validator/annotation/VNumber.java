package com.paic.pafa.validator.annotation;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

@Target({ElementType.METHOD,ElementType.FIELD})
@Retention(RetentionPolicy.RUNTIME)
/***
 * 数值校验配置,主要用于限定数值的大小及精度
 * 校验目标类型：Number子类(double的兼容类型)及String类
 */
public @interface VNumber {
	/**最小值限定，必须大于或等于此值*/
	double min() default Double.MIN_VALUE;
	/**最大值限定，必须小于或等于此值*/
	double max() default Double.MAX_VALUE;
	/**精度限定，即小数位数限定;-1不限定,0只能整数*/
	int precision() default -1;
	/**默认提示消息*/
	String message() default "";
}
