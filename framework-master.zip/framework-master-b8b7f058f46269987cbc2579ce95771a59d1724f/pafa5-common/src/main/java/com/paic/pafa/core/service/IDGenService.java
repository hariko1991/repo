/*
 * Created on 2004-9-21
 * 
 */
package com.paic.pafa.core.service;

/**
 * @author gus
 * @version 3.0 
 * 
 */
public interface IDGenService {
	String getID();
}
