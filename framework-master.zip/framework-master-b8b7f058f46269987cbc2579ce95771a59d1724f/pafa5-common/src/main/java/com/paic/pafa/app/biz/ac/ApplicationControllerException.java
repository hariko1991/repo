/*
 * Created on Aug 18, 2004
 *
 * To change the template for this generated file go to
 *
 */
package com.paic.pafa.app.biz.ac;


/**
 *
 * 
 * @author mayli
 *
 * 
 * modify by chenliang015 at 2009-06-29 .Delete some unuseful construct method.
 */
public class ApplicationControllerException extends Exception {

	
  private static final long serialVersionUID = -6814081746628061319L;

  /**
	 * 
	 */
	public ApplicationControllerException() {
		super();
		
	}


	/**
	 * @param cause
	 */
	public ApplicationControllerException(Throwable cause) {
		super(cause);
		
	}



	/**
	 * @param message
	 */
	public ApplicationControllerException(String message) {
		super(message);
		
	}


	/**
	 * @param message
	 * @param cause
	 */
	public ApplicationControllerException(String message, Throwable cause) {
		super(message, cause);
		
	}



}
