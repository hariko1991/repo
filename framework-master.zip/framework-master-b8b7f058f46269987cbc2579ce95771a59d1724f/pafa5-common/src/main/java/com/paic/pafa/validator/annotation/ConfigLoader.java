package com.paic.pafa.validator.annotation;

import java.beans.IntrospectionException;
import java.beans.Introspector;
import java.beans.PropertyDescriptor;
import java.lang.reflect.ParameterizedType;
import java.lang.reflect.Type;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.Assert;

import com.paic.pafa.utils.ReflectUtils;
import com.paic.pafa.validator.BeanValidators;
import com.paic.pafa.validator.FieldValidators;
import com.paic.pafa.validator.IValidator;
import com.paic.pafa.validator.NestedPathValidators;
import com.paic.pafa.validator.ValidateException;
import com.paic.pafa.validator.impl.DateValidator;
import com.paic.pafa.validator.impl.EmptyValidator;
import com.paic.pafa.validator.impl.EnumsValidator;
import com.paic.pafa.validator.impl.LengthValidator;
import com.paic.pafa.validator.impl.NumberValidator;
import com.paic.pafa.validator.impl.RegexValidator;

public class ConfigLoader {
	
	private Map<Class<?>,Boolean> annotationFlag=new HashMap<Class<?>,Boolean>();
	
	private Log log=LogFactory.getLog(ConfigLoader.class);
	
	
	/**参数验证集合,以参数名为键,参数绑定的所有验证器为值**/
	private Map<String,FieldValidators> feildValidatorsMap=new HashMap<String,FieldValidators>();
	
	/**参数验证集合,以参数名为键,参数绑定的所有验证器为值**/
	private Map<Class<?>,Map<String,NestedPathValidators>> beanPathValidators=new HashMap<Class<?>,Map<String,NestedPathValidators>>();
	
	
	public void addValidator(IValidator v,Class<?> beanClass,String field){
		Assert.notNull(field, "field can't be null");
		String key=beanClass.hashCode()+"@"+field;
		FieldValidators vds=feildValidatorsMap.get(key);
		if(vds==null){
			vds=new FieldValidators();
			vds.setFieldName(field);
			feildValidatorsMap.put(key,vds);
		}
		vds.add(v);
		if(log.isDebugEnabled()){
			log.debug("Feild["+beanClass.getName()+"@"+field+"]Add validator["+v+"]");
		}
	}
	
	public void addValidators(FieldValidators vs,Class<?> beanClass){
		List<IValidator> datas=vs.toList();
		if(datas!=null && datas.size()>0){
			for(int i=0;i<datas.size();i++){
				addValidator(datas.get(i),beanClass,vs.getFieldName());
			}
		}
	}
	
	public void addValidators(BeanValidators beanValidators) throws ClassNotFoundException{
		List<FieldValidators> datas=beanValidators.getFields();
		if(datas!=null && datas.size()>0){
			for(int i=0;i<datas.size();i++){
				addValidators(datas.get(i),beanValidators.getTargetClass());
			}
		}
	}
	public void addPathValidators(Class<?> scopeClass,Map<String, NestedPathValidators> pathValidators){
		beanPathValidators.put(scopeClass,pathValidators);
		if(log.isDebugEnabled()){
			log.debug("Class["+scopeClass.getName()+"]Add PathValidators["+pathValidators+"]");
		}
	}
	
	

	public Map<String, NestedPathValidators> getNestedPathValidators(
			Class<?> beanClazz) {
		this.checkConfigLoaded(beanClazz);
		return beanPathValidators.get(beanClazz);
	}
	
	public FieldValidators getValidators(Class<?> dtoClass,String feild){
		return feildValidatorsMap.get(dtoClass.hashCode()+"@"+feild);
	}
	
	
	

	

	
	
	public void checkConfigLoaded(Class<?> dtoClass){
		Boolean isloaded=annotationFlag.get(dtoClass);
		if(isloaded==null){
			synchronized(annotationFlag){
				checkAnotation(dtoClass);
				checkClazzAnotation(dtoClass);
				annotationFlag.put(dtoClass, Boolean.TRUE);
			}
		}
	}
	
	private void checkClazzAnotation(Class<?> targetClass){
		Validators.List nc=targetClass.getAnnotation(Validators.List.class);
		if(nc==null){
			return ;
		}
		Map<String, NestedPathValidators> pathValidators=new HashMap<String,NestedPathValidators>(8);
		//
		Validators[] configs=nc.value();
		if(configs!=null && configs.length>0){
			for(int i=0;i<configs.length;i++){
				Validators config=configs[i];
				NestedPathValidators validators=new NestedPathValidators();
				if(config.VNotEmpty().length>0){
					Assert.isTrue(config.VNotEmpty().length==1,"Defined more VNotEmpty validators.");
					validators.add(new EmptyValidator(config.VNotEmpty()[0]));
				}else if(config.VEmpty().length>0){
					Assert.isTrue(config.VEmpty().length==1,"Defined more VEmpty validators.");
					validators.add(new EmptyValidator(config.VEmpty()[0]));
				}
				if(config.VDate().length>0){
					Assert.isTrue(config.VDate().length==1,"Defined more VDate validators.");
					validators.add(new DateValidator(config.VDate()[0]));
				}
				if(config.VEnum().length>0){
					Assert.isTrue(config.VEnum().length==1,"Defined more VEnum validators.");
					validators.add(new EnumsValidator(config.VEnum()[0]));
				}
				if(config.VLength().length>0){
					Assert.isTrue(config.VLength().length==1,"Defined more VLength validators.");
					validators.add(new LengthValidator(config.VLength()[0]));
				}
				if(config.VNumber().length>0){
					Assert.isTrue(config.VNumber().length==1,"Defined more VNumber validators.");
					validators.add(new NumberValidator(config.VNumber()[0]));
				}
				if(config.VRegex().length>0){
					Assert.isTrue(config.VRegex().length==1,"Defined more VRegex validators.");
					validators.add(new RegexValidator(config.VRegex()[0]));
				}
				/*if(config.VCustom().length>0){
					Assert.isTrue(config.VCustom().length==1,"Defined more VCustom validators.");
					validators.add(CustomValidatorFactory.getByAnnotation(config.VCustom()[0]));
				}*/
				
				pathValidators.put(config.path(), validators);
			
			}
		}
		
		if(pathValidators.size()!=0){
			this.addPathValidators(targetClass, pathValidators);
		}
	}
	
	private void checkAnotation(Class<?> dtoClass){
		PropertyDescriptor[] pds=null;
		try {
			pds = Introspector.getBeanInfo(dtoClass).getPropertyDescriptors();
		} catch (IntrospectionException e1) {
			throw new ValidateException(e1.getMessage(),e1);
		}
		for(int i=0;i<pds.length;i++){
			PropertyDescriptor pd=pds[i];
			VNumber vn=ReflectUtils.getAnnotation(pd,VNumber.class);
			if(vn!=null){
				this.addValidator(new NumberValidator(vn),dtoClass,pd.getName());
			}
			VLength vl=ReflectUtils.getAnnotation(pd,VLength.class);
			if(vl!=null){
				this.addValidator(new LengthValidator(vl),dtoClass,pd.getName());
			}
			VRegex vr=ReflectUtils.getAnnotation(pd,VRegex.class);
			if(vr!=null){
				this.addValidator(new RegexValidator(vr),dtoClass,pd.getName());
			}
			VEnum ve=ReflectUtils.getAnnotation(pd,VEnum.class);
			if(ve!=null){
				this.addValidator(new EnumsValidator(ve),dtoClass,pd.getName());
			}
			VNotEmpty vnotEmpty=ReflectUtils.getAnnotation(pd,VNotEmpty.class);
			if(vnotEmpty!=null){
				this.addValidator(new EmptyValidator(vnotEmpty),dtoClass,pd.getName());
			}
			VEmpty vEmpty=ReflectUtils.getAnnotation(pd,VEmpty.class);
			if(vEmpty!=null){
				this.addValidator(new EmptyValidator(vEmpty),dtoClass,pd.getName());
			}
			VDate vdt=ReflectUtils.getAnnotation(pd,VDate.class);
			if(vdt!=null){
				this.addValidator(new DateValidator(vdt),dtoClass,pd.getName());
			}
			/*VCustom custom=ReflectUtils.getAnnotation(pd,VCustom.class);
			if(custom!=null){
				this.addValidator(CustomValidatorFactory.getByAnnotation(custom),dtoClass,pd.getName());
			}*/
		}
	}
	
	public static Class<?> getGenericClass(PropertyDescriptor p,int idx){
		Class<?> clazz=null;
		if(p.getWriteMethod()!=null){
			clazz=p.getWriteMethod().getDeclaringClass();
		}else if(p.getReadMethod()!=null){
			clazz=p.getReadMethod().getDeclaringClass();
		}
		if(clazz==null)return null;
		try {
			Type type=clazz.getDeclaredField(p.getName()).getGenericType();
			if(type!=null){
				return getGenericClass(type,idx);
			}
		} catch (Exception e) {
		} 
		return null;
	 }
	
	 @SuppressWarnings("unchecked")
	 private static Class<?> getGenericClass(Type t, int i) {
		 if(t instanceof ParameterizedType){
			 ParameterizedType pt=(ParameterizedType)t;
			 Type[] types=pt.getActualTypeArguments();
			 if(types!=null && types.length>i){
				 Type genericClass = pt.getActualTypeArguments()[i];
				 if(genericClass!=null && genericClass instanceof Class){
					 Class<?> temp= (Class<?>)genericClass;
					 if(!(temp.isInterface() || temp.equals(Object.class))){
						 return temp;
					 }
				 }
			 }
		 }
		return null;
	} 
	 
	 public static Class<?> getGenericClass(PropertyDescriptor prop){
		 return getGenericClass(prop,0);
	 }
	
	public static  Class<?>  getMapBindType(PropertyDescriptor p){
		return getGenericClass(p,1);
	}
	
	public static Class<?> getCollectionBindType(PropertyDescriptor p){
		return getGenericClass(p);
	}
	
	
	
}
