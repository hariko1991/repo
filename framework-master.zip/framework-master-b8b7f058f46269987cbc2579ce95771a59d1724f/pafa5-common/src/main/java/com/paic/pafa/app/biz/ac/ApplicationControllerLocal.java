package com.paic.pafa.app.biz.ac;

import com.paic.pafa.app.dto.ServiceRequest;
import com.paic.pafa.app.dto.ServiceResponse;

public interface ApplicationControllerLocal extends ApplicationController {

	public ServiceResponse handleRequest(ServiceRequest request);
}
