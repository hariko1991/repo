
/**
 * Pafa4:Pafa校验框架，主要是使用注解配置校验。
 * 集成Spring3的校验接口,主要用于支持Form提交数据校验、Action访问参数校验及DB存储时PO校验
 */
package com.paic.pafa.validator;

