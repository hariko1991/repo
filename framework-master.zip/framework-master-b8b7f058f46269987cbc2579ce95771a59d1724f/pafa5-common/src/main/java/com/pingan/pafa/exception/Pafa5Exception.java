package com.pingan.pafa.exception;

import com.paic.pafa.Pafa4Exception;

public class Pafa5Exception extends Pafa4Exception {
	private static final long serialVersionUID = 1L;

	public Pafa5Exception(String msg) {
		
		super(msg);
	}

	public Pafa5Exception(Throwable th) {
		super(th);
	}

	public Pafa5Exception(String msg, Throwable th) {
		super(msg, th);
	}
}
