package com.pingan.pafa.common.security.cyber;

import java.security.MessageDigest;
import java.util.Map;

/**
 * cyberark v9 的sign标识加密处理类
 * 
 * @date 2016-11-10
 * @author SHICHENGCHENG316
 * 
 */
public class CyberSignUtil {
	
	public static String makeSign(String s) {
		try {
			MessageDigest digest = MessageDigest.getInstance("SHA-1");
			digest.update(s.getBytes());
			byte[] messageDigest = digest.digest();
			return CyberHexUtil.byte2hex(messageDigest);
		} catch (Exception e) {
			return null;
		}
	}

	public static String makeSign(Map<String, Object> data, String appKey) {
		final StringBuilder sb = new StringBuilder();
		String appCode = (String) data.get(CyberFields.APPID);
		sb.append(appCode).append('&').append(appKey);
		return sb.length() > 0 ? makeSign(sb.toString()) : null;
	}
	
}
