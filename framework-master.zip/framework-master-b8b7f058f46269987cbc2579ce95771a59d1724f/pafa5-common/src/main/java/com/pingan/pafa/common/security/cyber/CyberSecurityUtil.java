package com.pingan.pafa.common.security.cyber;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;

import com.pingan.pafa.common.security.PasswordProviderException;

/**
 * cyberark v9 的加密工具类类
 * 
 * @date 2016-11-10
 * @author SHICHENGCHENG316
 * 
 */
public class CyberSecurityUtil {
	
	public static String encrypt(String s, String k) {
		if (s == null || k == null) {
			throw new PasswordProviderException("invalid parameters");
		}
		try {
			SecretKeySpec key = new SecretKeySpec(k.getBytes(), "AES");
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");// 创建密码器
			cipher.init(Cipher.ENCRYPT_MODE, key);// 初始化
			byte[] result = cipher.doFinal(s.getBytes());// 加密
			return CyberHexUtil.byte2hex(result);
		} catch (Exception ex) {
			throw new PasswordProviderException("Encrypt failede", ex);
		}
	}

	public static String decrypt(String s, String k) {
		if (s == null || k == null) {
			throw new PasswordProviderException("Invalid parameters");
		}
		try {
			SecretKeySpec key = new SecretKeySpec(k.getBytes(), "AES");
			Cipher cipher = Cipher.getInstance("AES/ECB/PKCS5Padding");// 创建密码器
			cipher.init(Cipher.DECRYPT_MODE, key);// 初始化
			byte[] result = cipher.doFinal(CyberHexUtil.hex2byte(s)); // 加密
			return new String(result);
		} catch (Exception ex) {
			throw new PasswordProviderException("Encrypt failede", ex);
		}
	}
	
}
