package com.pingan.pafa.papp.exception;


/***
 * @deprecated ResponseCodeException
 * @author LIXINGNAN945
 *
 */
public class PAppExceptionUtils {

	
	public static ResponseCodeException toResponseCodeException(Throwable ex){
		return ResponseCodeException.toResponseCodeException(ex);
	}

	
}
