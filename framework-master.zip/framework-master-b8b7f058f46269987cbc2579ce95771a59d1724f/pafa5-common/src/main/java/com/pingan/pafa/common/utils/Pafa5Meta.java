package com.pingan.pafa.common.utils;

import com.alibaba.dubbo.common.Version;


public class Pafa5Meta {
	
	public static String VERSION=Version.getVersion(Pafa5Meta.class, "5.3");
	
	public static String getVersion() {
		return VERSION;
	}

	
}
