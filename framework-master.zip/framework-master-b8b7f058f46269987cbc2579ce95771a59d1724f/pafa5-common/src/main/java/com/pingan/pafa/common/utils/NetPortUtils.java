package com.pingan.pafa.common.utils;

import java.io.IOException;
import java.net.InetAddress;
import java.net.Socket;
import java.net.UnknownHostException;

public class NetPortUtils {

	public static boolean isLoclePortUsing(int port){
		boolean flag = true;
		try {
			flag = isPortUsing("127.0.0.1", port);
		} catch (Exception e) {
		}
		return flag;
	}
	
	public static boolean isPortUsing(String host,int port) throws UnknownHostException{
		boolean flag = false;
		InetAddress theAddress = InetAddress.getByName(host);
		Socket socket=null;
		try {
			socket = new Socket(theAddress,port);
			socket.close();
			flag = true;
		} catch (IOException e) {
		}
		return flag;
	}
	
}
