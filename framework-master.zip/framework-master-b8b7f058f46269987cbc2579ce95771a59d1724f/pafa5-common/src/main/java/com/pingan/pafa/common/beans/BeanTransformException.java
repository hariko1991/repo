package com.pingan.pafa.common.beans;

import com.pingan.pafa.exception.Pafa5Exception;


public class BeanTransformException extends Pafa5Exception {

	private static final long serialVersionUID = 1L;

	public BeanTransformException(String msg) {
		super(msg);
	}
	
	public BeanTransformException(String msg,Throwable th) {
		super(msg,th);
	}
	
	
}
