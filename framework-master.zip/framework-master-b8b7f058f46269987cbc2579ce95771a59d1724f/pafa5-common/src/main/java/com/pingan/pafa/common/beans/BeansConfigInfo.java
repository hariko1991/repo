package com.pingan.pafa.common.beans;

import static java.util.Locale.ENGLISH;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.InvalidPropertyException;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.NumberFormat;

import com.pingan.pafa.common.beans.format.FieldFormatterFactory;

public class BeansConfigInfo {
	
	
	private  Map<Class<?>,List<ParameterInfo>> cache;
	
	public BeansConfigInfo(){
		cache=new ConcurrentHashMap<Class<?>,List<ParameterInfo>>();
	}
	
	
	public  List<ParameterInfo> getRestFields(Class<?> clazz) {
		return _getRestFields(clazz);
		
	}
	
	private  List<ParameterInfo> _getRestFields(Class<?> clazz) {
		List<ParameterInfo> fields=cache.get(clazz);
		if(fields==null){
			synchronized(cache){
				fields=getParameterInfos(clazz);
				if(fields.size()>0){
					forFieldAnnotations(clazz,fields);
					//forMethodAnnotations(clazz,fields);
					cache.put(clazz, fields);
				}
			}
		}
		if(fields.size()==0){
			return null;
		}else{
			return fields;
		}
	}
	
	protected  List<ParameterInfo> getParameterInfos(Class<?> clazz){
		List<ParameterInfo> fields=new ArrayList<ParameterInfo>(8);
		Field clazzFields[]=clazz.getDeclaredFields();
		Class<?> superClass=clazz.getSuperclass();
		if(superClass!=null && !superClass.equals(Object.class)){
			fields.addAll(getParameterInfos(superClass));
		}
		for(Field clazzField:clazzFields){
			if(Modifier.isStatic(clazzField.getModifiers())){
				continue;
			}
			if(Modifier.isTransient(clazzField.getModifiers())){
				continue;
			}
			Method writem=getWriteMethod(clazzField,clazz);
			Method readm=getReadMethod(clazzField,clazz);
			if(readm!=null || writem!=null){
				fields.add(new BeanPropertyInfo(clazzField,writem
						,readm,clazz));
			}
		}
		return fields;
	}
	
	public  Method getReadMethod(Field clazzField,Class<?> clazz) {
		 String readMethodName=null;
		 Class<?> fieldType=clazzField.getType();
		 String name=clazzField.getName();
		 if (fieldType == boolean.class || fieldType == null) {
			 if(!name.startsWith("is")){
				 readMethodName = "is" + capitalize(name);
			 }else{
				 readMethodName=name;
			 }
		} else {
		    readMethodName = "get" + capitalize(name);
		}
		 try {
			Method[] methods=clazz.getDeclaredMethods();
			Method foundMethod=null;
			for(Method method:methods){
				if(method.getName().equals(readMethodName) && method.getParameterTypes().length==0){
					int mods=method.getModifiers();
				    if (Modifier.isPublic(mods)) {
				    	foundMethod= method;
				    }
				}
			}
			return foundMethod;
		} catch (Exception e) {
		} 
		return null;
	 }
	
	 public  Method getWriteMethod(Field clazzField,Class<?> clazz) {
		 String writeMethodName=null;
		 String name=clazzField.getName();
		 if(name.startsWith("is")){
			 writeMethodName = "set" + name.substring(2);
		 }else{
			 writeMethodName = "set" + capitalize(name);
		 }
		Method[] methods=clazz.getDeclaredMethods();
		Method foundMethod=null;
		for(Method method:methods){
			if(method.getName().equals(writeMethodName) && method.getParameterTypes().length==1){
				int mods=method.getModifiers();
			    if (Modifier.isPublic(mods)) {
			    	foundMethod= method;
			    }
			    break;
			}
		}
		return foundMethod;
	 }

	public  String capitalize(String name) { 
		if (name == null || name.length() == 0) { 
		    return name; 
	        }
		return name.substring(0, 1).toUpperCase(ENGLISH) + name.substring(1);
    }
			
	
	
	
	private  void forFieldAnnotations(Class<?> targetClass, List<ParameterInfo> bindFields){
		Field[] fields=targetClass.getDeclaredFields();
		if(fields==null)return ;
		for(Field f:fields){
			NumberFormat nf=f.getAnnotation(NumberFormat.class);
			DateTimeFormat df=f.getAnnotation(DateTimeFormat.class);
			if( nf!=null || df!=null){
				ParameterInfo bindField=null;
				if(bindFields.size()>0){
					for(ParameterInfo temp:bindFields){
						if(temp.getName().equalsIgnoreCase(f.getName())){
							bindField=temp;
						}
					}
				}
				if(bindField==null){
					Object temp=(nf!=null?nf:df);
					throw new InvalidPropertyException(targetClass,f.getName()," no read/write method for annotation["+temp+"].");
				}else{
					if(nf!=null){
						bindField.setFormatter(FieldFormatterFactory.getNumberFormatter(bindField,nf));
					}
					if(df!=null){
						bindField.setFormatter(FieldFormatterFactory.getDateFormatter(bindField,df));
					}
				}
			}
		}
	}

	
	public synchronized void clear(){
		this.cache.clear();
	}
	
	
}
