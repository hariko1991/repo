package com.pingan.pafa.common.security.cyber;

import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.net.ssl.HostnameVerifier;
import javax.net.ssl.HttpsURLConnection;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLSession;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.alibaba.fastjson.JSONObject;
import com.pingan.pafa.common.security.PasswordContext;
import com.pingan.pafa.common.security.PasswordProvider;
import com.pingan.pafa.common.security.PasswordProviderException;

/**
 * It only support cyberArk v9.
 * 
 * @author SHICHENGCHENG316
 * 
 */
public class CyberPasswordProvider implements PasswordProvider {

	protected Log logger = LogFactory.getLog(this.getClass());

	public CyberPasswordProvider() {
	}

	public void refreshConfig(Properties properties) {
		String enable = properties.getProperty("cyberArk.enable");
		if (enable == null) {
			return;
		}

		System.setProperty("cyberArk.enable", enable);

		System.setProperty("cyberArk.safe", properties.getProperty("cyberArk.safe", "")); // required.
		System.setProperty("cyberArk.folder", properties.getProperty("cyberArk.folder", "")); // required.

		// cyberArk.appId: supported since cyberark V9. Added by
		// SHICHENGCHENG316, 2016-11-10
		System.setProperty("cyberArk.appId", properties.getProperty("cyberArk.appId", ""));
		System.setProperty("cyberArk.appKey", properties.getProperty("cyberArk.appKey", ""));
		System.setProperty("cyberArk.url", properties.getProperty("cyberArk.url", ""));
	}

	/**
	 * 增加了支持 cyberark V9的功能
	 * 
	 * @author SHICHENGCHENG316
	 * @date 2016-11-11
	 */
	@Override
	public String getPassword(PasswordContext passwordContext) {
		String key = passwordContext.getKey();

		try {
			String password = null;
			if (StringUtils.isEmpty(System.getProperty("cyberArk.url", ""))) {
				throw new NullPointerException("cyberArk.url  is null.");
			}

			Map<String, Object> config = new HashMap<String, Object>();
			String url = System.getProperty("cyberArk.url");

			String appKey = System.getProperty("cyberArk.appKey", "");
			config.put(CyberFields.APPID, System.getProperty("cyberArk.appId", ""));

			config.put(CyberFields.SAFE, System.getProperty("cyberArk.safe", ""));
			config.put(CyberFields.FOLDER, System.getProperty("cyberArk.folder", ""));
			config.put(CyberFields.OBJECT, key);
			config.put(CyberFields.SIGN, CyberSignUtil.makeSign(config, appKey));

			if ("true".equalsIgnoreCase(System.getProperty("cyberArk.enable"))) {
				if (key == null || (key = key.trim()).length() == 0) {
					throw new NullPointerException("Password key  is null.");
				}
				this.initSSL();
				password = this.getPasswordFromRemote(url, config, appKey);
			}
			
			if (password == null) {
				if (passwordContext.getDefaultPassword() != null) {
					return passwordContext.getDefaultPassword();
				} else if (passwordContext.isRequired()) {
					throw new PasswordProviderException("CyberArk error: read password failed for cyberUser:" + key);
				}
			}
			return password;
		} catch (PasswordProviderException pe) {
			throw pe;
		} catch (Throwable th) {
			throw new PasswordProviderException(
					"CyberArkUtil error for cyberUser:" + key + ", cause:" + th.getMessage(), th);
		}
	}

	/**
	 * cyberArk v9 的远程调用方法, 应用系统不需要像v6那样, 在本地安装cyberArk 客户端, 已经封装了https调用.
	 * <p>
	 * 注意: 使用之前必须initSSL()，否则https请求无效。
	 * </p>
	 * 
	 * @param url
	 *            cyberArk v9 远程服务地址
	 * @param param
	 *            cyberArk v9 远程服务参数
	 * @param appKey
	 *            cyberArk v9 中的object参数, 此参数是同一个App中对应的账号的唯一Id,
	 *            在cyberArk中称之为'object', 与appKey不是同一个.
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public String getPasswordFromRemote(String url, Map<String, Object> param, String appKey) {
		try {
			String obj = JSONObject.toJSONString(param);

			URL postUrl = new URL(url);
			HttpURLConnection http = (HttpURLConnection) postUrl.openConnection();
			http.setDoOutput(true);
			http.setDoInput(true);
			http.setUseCaches(false);

			http.setRequestProperty("Content-Type", "application/json");
			http.setRequestMethod("POST");
			http.setRequestProperty("Content-Length", String.valueOf(obj.getBytes().length));

			http.connect();
			DataOutputStream out = new DataOutputStream(http.getOutputStream());
			out.writeBytes(obj);
			out.flush();
			out.close();

			BufferedReader reader = new BufferedReader(new InputStreamReader(http.getInputStream(), "utf-8"));
			StringBuilder readBuffer = new StringBuilder();
			for (String line = reader.readLine(); line != null; line = reader.readLine()) {
				readBuffer.append(line);
			}

			Map<String, Object> result = (Map<String, Object>) JSONObject.parse(readBuffer.toString());

			if (result != null && "200".equals(result.get("code"))) {
				return CyberSecurityUtil.decrypt((String) result.get(CyberFields.PASSWORD), appKey);
			} else {

				throw new PasswordProviderException(
						"CyberArk error: from CyberArk V9 service,  " + (String) result.get("msg"));
			}

		} catch (Exception e) {
			throw new PasswordProviderException("CyberArk error: get password from remote service.", e);
		}
	}

	/**
	 * 初始化SSL
	 */
	private void initSSL() {
		HttpsURLConnection.setDefaultHostnameVerifier(new HostnameVerifier() {
			public boolean verify(String hostname, SSLSession session) {
				return true;
			}
		});

		try {
			SSLContext sc = SSLContext.getInstance("TLS");
			sc.init(null, new TrustManager[] { new X509TrustManager() {
				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				public void checkClientTrusted(X509Certificate[] certs, String authType) {
				}

				public void checkServerTrusted(X509Certificate[] certs, String authType) {
				}
			} }, null);
			HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());
		} catch (Exception ex) {
			throw new PasswordProviderException("CyberArkUtil error when init SSL." + ex.getMessage(), ex);
		}
	}
	
}
