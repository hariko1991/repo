package com.pingan.pafa.common.beans.format;

public interface FieldFormatter {
	
	public Object parse(String value);
	
	public String print(Object value);
	
}
