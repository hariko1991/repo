package com.pingan.pafa.common.security.cyber;

/**
 * cyberark v9 webservice的参数字段名称
 * 
 * @date 2016-11-10
 * @author SHICHENGCHENG316
 * 
 */
public class CyberFields {
	
	public static final String REQUESTID = "requestId";
	public static final String REQUESTTIME = "requestTime";
	public static final String RESPONSEID = "responseId";
	public static final String RESPONSETIME = "responseTime";
	public static final String SIGN = "sign";

	public static final String ID = "id";
	public static final String PASSWORD = "password";

	public static final String APPID = "appId";
	public static final String SAFE = "safe";
	public static final String FOLDER = "folder";
	public static final String OBJECT = "object";
	public static final String REASON = "reason";
	
}
