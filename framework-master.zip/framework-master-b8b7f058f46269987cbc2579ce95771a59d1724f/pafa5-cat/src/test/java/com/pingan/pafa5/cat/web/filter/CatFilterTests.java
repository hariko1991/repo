package com.pingan.pafa5.cat.web.filter;

import org.junit.Assert;
import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(plugins = "cat")
public class CatFilterTests extends BaseSARTest {

	@Test
	public void testHello() throws Exception {
		String result = this.handleWebRequest(this.createMockRequest("/hello/say", "name=nangua"),
				this.createMockResponse());
		Assert.assertEquals(result, "");
	}
}
