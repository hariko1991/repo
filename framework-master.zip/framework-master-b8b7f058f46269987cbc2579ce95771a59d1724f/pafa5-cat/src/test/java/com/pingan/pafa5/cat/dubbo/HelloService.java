package com.pingan.pafa5.cat.dubbo;

import java.util.Map;




/**
 * 通用服务接口
 * 
 * @export
 */
public interface HelloService {

    
	Map<Object,Object> $invoke(Map<Object,Object> params) throws HelloServiceException;

}