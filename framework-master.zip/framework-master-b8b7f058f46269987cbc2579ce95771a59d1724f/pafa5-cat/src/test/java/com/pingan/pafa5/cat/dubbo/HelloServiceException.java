
package com.pingan.pafa5.cat.dubbo;



public class HelloServiceException extends RuntimeException {

	private static final long serialVersionUID = -1182299763306599962L;

	
	
	public HelloServiceException() {
	}

    public HelloServiceException(String exceptionMessage) {
        super(exceptionMessage);
    }
}