package com.pingan.pafa5.cat.dubbo.filter;

import org.apache.commons.lang.StringUtils;

import com.alibaba.dubbo.common.Constants;
import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.common.extension.Activate;
import com.alibaba.dubbo.rpc.Filter;
import com.alibaba.dubbo.rpc.Invocation;
import com.alibaba.dubbo.rpc.Invoker;
import com.alibaba.dubbo.rpc.Result;
import com.alibaba.dubbo.rpc.RpcContext;
import com.alibaba.dubbo.rpc.RpcException;
import com.dianping.cat.Cat;
import com.dianping.cat.message.Message;
import com.dianping.cat.message.Transaction;
import com.pingan.pafa5.cat.Pafa5Cat;
import com.pingan.pafa5.cat.dubbo.constants.CatConstants;

@Activate(group = { Constants.PROVIDER }, order = -9000)
public class CatDubboProviderFilter extends CatDubboAbstractFilter implements Filter {

   @Override
   public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
      if (!Pafa5Cat.isEnable()) {
         return invoker.invoke(invocation);
      }
      URL url = invoker.getUrl();
      String loggerName = url.getParameter(Constants.INTERFACE_KEY) + "." + invocation.getMethodName();
      Transaction transaction = Cat.newTransaction(CatConstants.CROSS_SERVER, loggerName);
      try {
         RpcContext rpcContext = RpcContext.getContext();
         Cat.Context context = createContext(rpcContext);
         createProviderCross(url, transaction);
         Cat.logRemoteCallServer(context);
         refreshAttachment(context, rpcContext);
         Result result = invoker.invoke(invocation);
         if (result.hasException()) {
            Throwable throwable = result.getException();
            Cat.logError(throwable);
            transaction.setStatus(result.getException());
         } else {
            transaction.setStatus(Message.SUCCESS);
         }
         return result;
      } catch (RuntimeException e) {
         Cat.logError(e);
         transaction.setStatus(e);
         throw e;
      } finally {
         transaction.complete();
      }
   }

   private void createProviderCross(URL url, Transaction transaction) {
      RpcContext context = RpcContext.getContext();
      String consumerName = context.getAttachment(CatConstants.CONSUMER_NAME);
      if (StringUtils.isEmpty(consumerName)) {
         consumerName = context.getRemoteHost() + ":" + context.getRemotePort();
      }
      Cat.logEvent(CatConstants.PROVIDER_CALL_APP, url.getHost());
      Cat.logEvent(CatConstants.PROVIDER_CALL_SERVER, consumerName);
   }

}
