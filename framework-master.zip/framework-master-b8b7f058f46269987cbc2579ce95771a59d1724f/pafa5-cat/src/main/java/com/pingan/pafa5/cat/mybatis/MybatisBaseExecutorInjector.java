package com.pingan.pafa5.cat.mybatis;

import com.dianping.cat.Cat;
import com.dianping.cat.message.Message;
import com.dianping.cat.message.Transaction;
import org.apache.ibatis.cache.CacheKey;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.mapping.SqlCommandType;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;

import java.sql.Connection;

/**
 * Created by JIANGJIE164 on 2017/12/13.
 */
public class MybatisBaseExecutorInjector {

    public static Transaction query(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler,
                                    CacheKey key, BoundSql boundSql){

        //得到类名，方法
        String[] strArr = ms.getId().split("\\.");
        String methodName = strArr[strArr.length - 2] + "." + strArr[strArr.length - 1];

        Transaction t = Cat.newTransaction("SQL", methodName);

        //得到sql语句
        //Configuration configuration = mappedStatement.getConfiguration();
        //String sql = showSql(configuration, boundSql);
        String sql = boundSql.getSql();

        //获取SQL类型
        SqlCommandType sqlCommandType = ms.getSqlCommandType();
        Cat.logEvent("SQL.Method", sqlCommandType.name().toUpperCase(), Message.SUCCESS, sql);



        return t;

    }

    public static Transaction queryFromDatabase(MappedStatement ms, Object parameter, RowBounds rowBounds, ResultHandler resultHandler, CacheKey key, BoundSql boundSql){

        Transaction t = Cat.newTransaction("SQL","queryFromDatabase");
        return t;
    }

    public static Transaction getConnection(org.apache.ibatis.logging.Log statementLog){
        Transaction t = Cat.newTransaction("SQL","getConnection");
        return t;
    }

    public static void _getConnection(Connection conn){

        if(conn!=null){
            try {
                Cat.logEvent("SQL.Database",conn.getMetaData().getURL());
            }catch (Throwable e){
                Cat.logError(e);
            }
        }
    }

    public static Transaction update(MappedStatement ms, Object parameter) {
        String[] strArr = ms.getId().split("\\.");
        String methodName = strArr[strArr.length - 2] + "." + strArr[strArr.length - 1];

        Transaction t = Cat.newTransaction("SQL", methodName);

        BoundSql boundSql = ms.getBoundSql(parameter);
        //获取SQL类型
        SqlCommandType sqlCommandType = ms.getSqlCommandType();
        Cat.logEvent("SQL.Method", sqlCommandType.name().toUpperCase(), Message.SUCCESS,boundSql.getSql());

        return t;
    }
}
