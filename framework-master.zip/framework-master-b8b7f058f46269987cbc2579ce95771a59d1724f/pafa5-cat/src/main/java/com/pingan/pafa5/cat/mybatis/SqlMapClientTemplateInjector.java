package com.pingan.pafa5.cat.mybatis;

import com.alibaba.druid.pool.DruidDataSource;
import com.dianping.cat.Cat;
import com.dianping.cat.message.Transaction;
import com.ibatis.common.jdbc.SimpleDataSource;
import com.ibatis.sqlmap.client.event.RowHandler;
import com.ibatis.sqlmap.engine.impl.SqlMapClientImpl;
import org.springframework.orm.ibatis.SqlMapClientTemplate;

import javax.sql.DataSource;

/**
 * Created by JIANGJIE164 on 2017/12/20.
 */
public class SqlMapClientTemplateInjector {

    private final static String SELECT="SELECT";
    private final static String DELETE="DELETE";
    private final static String INSERT="INSERT";
    private final static String UPDATE="UPDATE";
    private final static String SP="SP";


    private static Transaction getTransaction(SqlMapClientTemplate src,String statementName,String method){
        Transaction t = Cat.newTransaction("SQL",statementName);
        Cat.logEvent("SQL.Method",method);
        try {
            SqlMapClientImpl impl = (SqlMapClientImpl) src.getSqlMapClient();

            Cat.logEvent("SQL.SQL",String.valueOf(impl.getDelegate().getMappedStatement(statementName).getSql().getSql(null,null)));
            DataSource ds = src.getDataSource();
            if(ds instanceof DruidDataSource){
                Cat.logEvent("SQL.Database", ((DruidDataSource)ds).getUrl());
            }else if(ds instanceof SimpleDataSource){
                Cat.logEvent("SQL.Database", ((SimpleDataSource)ds).getJdbcUrl());
            }

        }catch (Throwable e){
            //ignore
        }

        return t;
    }

    public static Transaction queryForObject(SqlMapClientTemplate src,final String statementName, final Object parameterObject){
        return getTransaction(src,statementName,SELECT);
    }

    public static Transaction queryForObject(SqlMapClientTemplate src,final String statementName, final Object parameterObject, final Object resultObject){

        return getTransaction(src,statementName,SELECT);
    }



    public static Transaction queryForList(SqlMapClientTemplate src,final String statementName, final Object parameterObject){
        return getTransaction(src,statementName,SELECT);
   }


    public static Transaction queryForList(SqlMapClientTemplate src,final String statementName, final Object parameterObject, final int skipResults, final int maxResults){
        return getTransaction(src,statementName,SELECT);
    }


    public static Transaction queryWithRowHandler(SqlMapClientTemplate src,final String statementName, final Object parameterObject, final RowHandler rowHandler){
        return getTransaction(src,statementName,SELECT);
    }

    public static Transaction queryForMap(SqlMapClientTemplate src, final String statementName, final Object parameterObject, final String keyProperty){
        return getTransaction(src,statementName,SELECT);
    }

    public static Transaction queryForMap(SqlMapClientTemplate src, final String statementName, final Object parameterObject, final String keyProperty, final String valueProperty){
        return getTransaction(src,statementName,SELECT);
    }


    public static Transaction insert(SqlMapClientTemplate src,final String statementName, final Object parameterObject){
        return getTransaction(src,statementName,INSERT);
    }


    public static Transaction update(SqlMapClientTemplate src,final String statementName, final Object parameterObject){

        return getTransaction(src,statementName,UPDATE);
    }


    public static Transaction delete(SqlMapClientTemplate src,final String statementName, final Object parameterObject){

        return getTransaction(src,statementName,DELETE);
    }

}
