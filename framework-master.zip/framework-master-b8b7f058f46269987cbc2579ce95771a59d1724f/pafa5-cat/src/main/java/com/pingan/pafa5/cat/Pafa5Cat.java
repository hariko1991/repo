package com.pingan.pafa5.cat;



/**
 * Created by bieber on 2015/11/16.
 */
public class Pafa5Cat {
    private static boolean isEnable=true;

    /**
     * 禁用dubbo cat
     */
    public static void disable(){
        isEnable=false;
    }

    /**
     * 启用dubbo cat
     */
    public static void enable(){
        isEnable=true;
    }

    /**
     * 是否有效
     * @return
     */
    public static boolean isEnable(){
        return isEnable && com.dianping.cat.Cat.getManager().isCatEnabled();
    }

	public  void setEnable(boolean isEnable) {
		Pafa5Cat.isEnable = isEnable;
	}

}
