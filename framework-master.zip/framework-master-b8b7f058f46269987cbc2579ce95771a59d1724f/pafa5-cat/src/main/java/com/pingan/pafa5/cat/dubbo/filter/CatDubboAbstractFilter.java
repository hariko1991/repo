package com.pingan.pafa5.cat.dubbo.filter;

import java.util.HashMap;
import java.util.Map;

import com.alibaba.dubbo.rpc.RpcContext;
import com.dianping.cat.Cat;

public class CatDubboAbstractFilter {

   //private final static String DUBBO_BIZ_ERROR = "DUBBO_BIZ_ERROR";

   //private final static String DUBBO_TIMEOUT_ERROR = "DUBBO_TIMEOUT_ERROR";

   //private final static String DUBBO_REMOTING_ERROR = "DUBBO_REMOTING_ERROR";

   private class DubboCatContext implements Cat.Context {

      private Map<String, String> properties = new HashMap<String, String>();

      @Override
      public void addProperty(String key, String value) {
         properties.put(key, value);
      }

      @Override
      public String getProperty(String key) {
         return properties.get(key);
      }
   }

   protected Cat.Context createContext(RpcContext rpcContext) {
      Cat.Context context = new DubboCatContext();
      context.addProperty(Cat.Context.CHILD, rpcContext.getAttachment(Cat.Context.CHILD));
      context.addProperty(Cat.Context.PARENT, rpcContext.getAttachment(Cat.Context.PARENT));
      context.addProperty(Cat.Context.ROOT, rpcContext.getAttachment(Cat.Context.ROOT));
      return context;
   }

   protected void refreshAttachment(Cat.Context context, RpcContext rpcContext) {
      rpcContext.setAttachment(Cat.Context.ROOT, context.getProperty(Cat.Context.ROOT));
      rpcContext.setAttachment(Cat.Context.CHILD, context.getProperty(Cat.Context.CHILD));
      rpcContext.setAttachment(Cat.Context.PARENT, context.getProperty(Cat.Context.PARENT));
   }
}
