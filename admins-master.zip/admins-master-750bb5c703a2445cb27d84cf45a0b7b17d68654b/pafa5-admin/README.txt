此版本为升级版本
升级spring3.x-->spring4.3.x,支持mongodb3.4的服务端
编译，打包，jar管理使用maven
test