package com.pingan.pafa5.admin.papp.dao;

import java.util.List;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSearchDTO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigPO;

/**
 * 当前配置操作
 * 
 * @author EX-YANGSHENGXIANG001
 */
public interface GardenPizzaConfigDAO {

	



	List<String> listKeys(String group, String pizzaKeyRegex);

	

	List<String> listKeys(String proId, String group, String pizzaKeyRegex);

	

}
