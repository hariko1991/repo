package com.pingan.pafa5.admin.logging.services.impl;



import java.io.IOException;
import java.io.Writer;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.pingan.pafa.redis.queue.RedisQueue;


public class LogOutputUtils {
	
	public static final String PAFA5_LOG_MONITOR = "pafa5_log_monitor";


	public static void outputHTML(RedisQueue<HashMap> redisQueue,Writer out,int limitSize)
		throws IOException{
		DateFormat dateFormat=new SimpleDateFormat("HH:mm:ss.SSS");
		int counter=0;
		HashMap datas=null;
		out.write("<pre>");
		do{
			datas=redisQueue.pop();
			if(datas!=null){
				String temp=LogOutputUtils.toStringLine(datas,dateFormat);
				char[] chars=temp.toCharArray();
				for(int i=0;i<chars.length;i++){
					char ch=chars[i];
					if(ch=='<'){
						out.write("&lt;");
					}else if(ch=='>'){
						out.write("&gt;");
					}else{
						out.write(ch);
					}
				}
			}
			counter++;
			if(limitSize>0 && counter>limitSize){
				break;
			}
		}while(datas!=null);
		out.write("</pre>");
		out.flush();
	}
	
	public static String toStringLine(HashMap datas,DateFormat dateFormat){
		StringBuilder str=new StringBuilder(64);
		//
		str.append('[').append(datas.get("instanceIp")).append(']').append(' ');
		Long millis=(Long)datas.get("millis");
		str.append('[').append(dateFormat.format(new Date(millis))).append(']').append(' ');
		str.append('[').append(datas.get("level")).append(']').append(' ');
		List<Object> stacks=(List<Object>)datas.get("contextStack");
		if(stacks!=null && stacks.size()>0){
			for(int i=0;i<stacks.size();i++){
				if(i!=0)str.append(',');
				str.append(stacks.get(i)).append(' ');
			}
		}
		String logName=(String)datas.get("loggerName");
		int idx=logName.lastIndexOf('.');
		if(idx!=-1){
			logName=logName.substring(idx+1);
		}
		str.append(logName).append(":").append(datas.get("message"));
		str.append("\n");
		Map thrown=(Map)datas.get("thrown");
		if(thrown!=null){
			forThrown(thrown,str,false);
		}
		return str.toString();
	}
	
	/**
	 * @param thrown
	 * @param str
	 */
	private static  void forThrown(Map thrown,StringBuilder str,boolean isCause){
		  
		  if(isCause){
			  str.append("Caused by: ").append(thrown.get("type"));
			  Object msg=thrown.get("message");
			  if(msg!=null){
				  str.append(':').append(msg);
			  }
			  str.append('\n');
		  }
		  List<Map> stacks=(List<Map>)thrown.get("stackTrace");
		  //... 49 more
		  for(int i=0;i<stacks.size();i++){
			  if(isCause && i>1){
				  str.append("\t... ").append(stacks.size()-2).append(" more\n");
				  break;
			  }
			 
			  Map stack=stacks.get(i);
			  String className=(String)stack.get("className");
			  str.append('\t').append("at ").append(className)
			  .append('.').append(stack.get("methodName")).append("(");
			  Long lineNumber = (Long)stack.get("lineNumber");
			  if(lineNumber!=null && lineNumber>0){
				  int idx=className.lastIndexOf('.');
				  if(idx!=-1){
					  className=className.substring(className.lastIndexOf('.')+1);
				  }
				  str.append(className).append(".java")
				  .append(':').append(lineNumber);
			  }else{
				  str.append("Native Method");
			  }
			  str.append(')').append('\n');
		  }
		  Map causeThrown=(Map)thrown.get("cause");
		  if(causeThrown!=null){
			  forThrown(causeThrown,str,true);
		  }
	}
	

	

}
