package com.pingan.pafa5.admin.papp.dto;


/**
 * ivy.xml文件依赖配置DTO
 * @author WANGJUN791
 *
 */
public class IvyDenpendencyConfigDTO {
	
	private String projectId;
	
	private String pappName;
	
	private String org;
	
	private String oldOrg;
	
	private String module;
	
	private String oldModule;
	
	private String version;
	
	private String xmlContent;
	
	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getPappName() {
		return pappName;
	}

	public void setPappName(String pappName) {
		this.pappName = pappName;
	}

	public String getOrg() {
		return org;
	}

	public void setOrg(String org) {
		this.org = org;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getXmlContent() {
		return xmlContent;
	}

	public void setXmlContent(String xmlContent) {
		this.xmlContent = xmlContent;
	}

	public String getOldOrg() {
		return oldOrg;
	}

	public void setOldOrg(String oldOrg) {
		this.oldOrg = oldOrg;
	}

	public String getOldModule() {
		return oldModule;
	}

	public void setOldModule(String oldModule) {
		this.oldModule = oldModule;
	}
}