package com.pingan.pafa5.admin.fling.services;

import java.util.List;
import java.util.concurrent.ExecutionException;

import org.springframework.ui.ModelMap;

public interface ServiceDetectionService {
	
	int processDubboAdmin(String sarName,String instanceIp);
	
	void processDubboAdmin(List<ModelMap> map) throws InterruptedException, ExecutionException;
}
