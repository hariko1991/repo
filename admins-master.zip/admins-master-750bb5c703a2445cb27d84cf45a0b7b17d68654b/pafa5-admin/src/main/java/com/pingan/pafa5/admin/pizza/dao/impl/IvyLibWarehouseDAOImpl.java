package com.pingan.pafa5.admin.pizza.dao.impl;

import java.util.Date;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.pizza.dao.IvyLibWarehouseDAO;
import com.pingan.pafa5.admin.pizza.po.IvyLibWarehousePO;

@Nosql
@Repository
public class IvyLibWarehouseDAOImpl extends  BaseMongoDAO<IvyLibWarehousePO> implements IvyLibWarehouseDAO {

	@Override
	public boolean isExists(String projectId , String md5 ) {
		Criteria criteria = where("projectId").is(projectId).and("md5").is(md5).and("enableFlag").is("Y");
		return this._exists(criteria);
	}

	@Override
	public void updateIvyLib(IvyLibWarehousePO ivyLibPO) {
		this._updateById(ivyLibPO);
	}
	
	@Override
	public void saveIvyLib(IvyLibWarehousePO ivyLibPO) {
		this._add(ivyLibPO);
	}

	@Override
	public IvyLibWarehousePO findByMd5(String projectId, String md5) {
		Criteria criteria = where("projectId").is(projectId).and("md5").is(md5).and("enableFlag").is("Y");
		return this._get(criteria);
	}

	@Override
	public IvyLibWarehousePO findById(String id) {
		Criteria criteria = where("Id").is(id);
		return this._get(criteria);
	}

	@Override
	public void cleanTempFile(Date date) {
		Criteria criteria = where("updatedDate").lt(date).and("enableFlag").ne("Y");
		this._remove(criteria);
	}

	
	

	
}
