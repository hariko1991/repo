package com.pingan.pafa5.admin.fling.web;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

import javax.crypto.CipherInputStream;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.collections.map.HashedMap;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa5.admin.commons.BasePO;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.fling.po.FlingPappInstancePO;
import com.pingan.pafa5.admin.fling.po.FlingPappMonitorMsgPO;
import com.pingan.pafa5.admin.fling.po.FlingSARInstancePO;
import com.pingan.pafa5.admin.fling.services.InstanceServices;
import com.pingan.pafa5.admin.papp.dto.SarDTO;

@Controller
public class GardenInstancesController extends BaseController{
	
	@Autowired
    private InstanceServices instanceServices;
	
	@ActionClient(name = "pafa5-admin-fling.getPappIpInfo")
    private IServiceClient getPappIpInfo;
	
	private static final String IPAddress = "^(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|[1-9])\\."
            +"(00?\\d|1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."
            +"(00?\\d|1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."
            +"(00?\\d|1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)$";
	
	
	@ESA(value = "pafa5-admin-fling.gardenListPapps")
	public ResponseModel getPappList(@RequestParam(value = "projectId", required = false) String projectId,
    		@RequestParam(value = "pappName", required = false) String pappName, 
    		@RequestParam(value = "pageSize", defaultValue = "30") int pageSize, 
    		@RequestParam(value = "pageNum", defaultValue = "1") int pageNum){
		
		List<FlingPappInstancePO> pos = instanceServices.listForPapp1(projectId, pappName);
        if (pos == null || pos.size() == 0) {
        	 ResponseModel model =new ResponseModel("0", "应用:" + pappName + "未能找到对应节点信息。");
        	 model.addAttribute("datas", new ArrayList<ModelMap>());
            return model;
        }
        List<ModelMap> datas = new ArrayList<ModelMap>(pos.size());
        DateFormat formatter = null;
        formatter = DateFormat.getDateTimeInstance();
        for (FlingPappInstancePO po : pos) {
            ModelMap map = new ModelMap();
            map.put("instanceIp", po.getInstanceIp());
            map.put("lastActiveTime", formatter.format(new Date(po.getLastActiveTimestamp())));
            map.put("lastActiveObjectId", po.getLastActiveObjectId());
            map.put("lastActiveCause", po.getUpdatedBy());
            map.put("status", po.getStatus());
            map.put("hostName", "-");
            map.put("instanceName", "-");
            map.put("pappName", po.getAppName());
            map.put("dirName",po.getAppName());
            String appName = po.getAppName();
            String ip = po.getInstanceIp();
            if (appName != null && !"".equals(appName.trim()) && ip != null&& !"".equals(ip.trim())) {
                FlingPappMonitorMsgPO detail = instanceServices.getInstanceDetails(projectId, appName, ip);
                if (detail != null) {
                    if (detail.getInstanceName() != null) {
                        map.put("instanceName", detail.getInstanceName());
                    }
                    if (detail.getHostName() != null) {
                        map.put("hostName", detail.getHostName());
                    }
                }
            }
            datas.add(map);
        }
        List<ModelMap> datasOut = new ArrayList<ModelMap>(pageSize);
		for(int i=(pageNum-1)*pageSize;i<Math.min(datas.size(), pageNum*pageSize);i++){
			datasOut.add(datas.get(i));
		}
        ResponseModel model = new ResponseModel();
        model.addAttribute("datas", datasOut);
        model.addAttribute("totalSize", pos.size());
        return model;
	}
	
	@ESA("pafa5-admin-fling.gardenListSars")
    public ResponseModel getSarList(@RequestParam(value = "instanceIp", required = false) String instanceIp,
    		@RequestParam(value = "projectId", required = false) String projectId,
    		@RequestParam(value = "sarName", required = false) String sarName, 
    		@RequestParam(value = "pappName", required = false) String pappName, 
    		@RequestParam(value = "pageSize", defaultValue = "30") int pageSize, 
    		@RequestParam(value = "pageNum", defaultValue = "1") int pageNum) {

        List<FlingSARInstancePO> pos = instanceServices.listForSAR(instanceIp, projectId, sarName, pappName);

        if (pos == null || pos.size() == 0) {
        	ResponseModel model = new  ResponseModel("0", "组件:" + sarName + "未能找到对应节点信息。");
            model.addAttribute("datas", new ArrayList<ModelMap>());
            return model;
        }
        List<ModelMap> datas = new ArrayList<ModelMap>(pos.size());
        DateFormat formatter = null;
        formatter = DateFormat.getDateTimeInstance();
        for (FlingSARInstancePO po : pos) {
            ModelMap map = new ModelMap();
            map.put("instanceIp", po.getInstanceIp());
            map.put("lastActiveTime", formatter.format(new Date(po.getLastActiveTimestamp())));
            map.put("lastActiveObjectId", po.getLastActiveObjectId());
            map.put("lastActiveCause", po.getCreatedBy());
            map.put("pappName", po.getAppName());
            map.put("sarName", po.getSarName());
            map.put("status", po.getStatus());
            map.put("dirName",po.getAppName()+" > "+po.getSarName());
            datas.add(map);
        }
        List<ModelMap> datasOut = new ArrayList<ModelMap>(pageSize);
		for(int i=(pageNum-1)*pageSize;i<Math.min(datas.size(), pageNum*pageSize);i++){
			datasOut.add(datas.get(i));
		}
        ResponseModel model = new ResponseModel();
        model.addAttribute("datas", datasOut);
        model.addAttribute("totalSize", pos.size());
        return model;
    }
	
	@ESA("pafa5-admin-fling.gardenGetDetails")
    public ResponseModel getDetails(
    		@RequestParam(value = "projectId") String projectId,
            @RequestParam(value = "pappName", required = true) String pappName,
            @RequestParam(value = "sarName", required = false) String sarName, 
            @RequestParam(value = "instanceIp") String instanceIp
            ) {
		ModelMap map =
                instanceServices.getInstanceDetails(projectId, pappName,sarName, instanceIp);
        if (map.isEmpty()) {
        	 ResponseModel model = new ResponseModel("0",  "未能找到对应节点详情信息。");
        	 model.addAttribute("datas", new ModelMap());
        	 return model;
        }

        ResponseModel model = new ResponseModel();
        model.addAttribute("datas", map);
        return model;
    }
	
	@ESA("pafa5-admin-fling.gardenGetInstanceByIp")
	public ResponseModel getInstanceByIp(
			@RequestParam(value = "instanceIp", required = true) String instanceIp,
			@RequestParam(value = "pageSize", defaultValue = "30") int pageSizeSar, 
    		@RequestParam(value = "pageNum", defaultValue = "1") int pageNumSar){
		//sar进行分页查询，papp暂不支持
		PageDataDTO<FlingSARInstancePO> pageDataDTO = instanceServices.getSarInstanceByIp(instanceIp, pageSizeSar, pageNumSar);
		
		List<FlingPappInstancePO> poPapp = instanceServices.getPappInstanceByIp(instanceIp);
		List<FlingSARInstancePO> posSar = pageDataDTO.getDatas();
		
		if (poPapp == null || poPapp.size() == 0) {
			ResponseModel model =  new ResponseModel("0",  "未能找到IP："+instanceIp+"对应的机器信息。");
			 model.addAttribute("datas", new ArrayList<ModelMap>());
			 return model;
        }
        List<ModelMap> datas = new ArrayList<ModelMap>(poPapp.size());
        DateFormat formatter = null;
        formatter = DateFormat.getDateTimeInstance();
        for (FlingPappInstancePO po : poPapp) {
            ModelMap map = new ModelMap();
            map.put("instanceIp", po.getInstanceIp());
            map.put("lastActiveTime", formatter.format(new Date(po.getLastActiveTimestamp())));
            map.put("lastActiveObjectId", po.getLastActiveObjectId());
            map.put("lastActiveCause", po.getUpdatedBy());
            map.put("projectId", po.getProjectId());
            map.put("status", po.getStatus());
            map.put("hostName", "-");
            map.put("instanceName", "-");
            map.put("pappName", po.getAppName());
            List<ModelMap> sarList = new ArrayList<ModelMap>(posSar.size());
            for (FlingSARInstancePO poSar : posSar) {
            	if(poSar.getAppName().equals(po.getAppName())&&poSar.getProjectId().equals(po.getProjectId())){
	            	ModelMap mapSarTemp = new ModelMap();
	            	mapSarTemp.put("instanceIp", poSar.getInstanceIp());
	            	mapSarTemp.put("lastActiveTime", formatter.format(new Date(poSar.getLastActiveTimestamp())));
	            	mapSarTemp.put("lastActiveObjectId", poSar.getLastActiveObjectId());
	            	mapSarTemp.put("lastActiveCause", poSar.getCreatedBy());
	            	mapSarTemp.put("pappName", poSar.getAppName());
	            	mapSarTemp.put("sarName", poSar.getSarName());
	            	mapSarTemp.put("status", poSar.getStatus());
	            	sarList.add(mapSarTemp);
            	}
            }
            map.put("sarInstances", sarList);
            datas.add(map);
        }
        ResponseModel model = new ResponseModel();
        model.addAttribute("datas", datas);
        model.addAttribute("totalSize", poPapp.size());
        return model;
	}
	
    @ESA("pafa5-admin-fling.listSars_Papp")
    public ResponseModel listForSAR_Papp(
            @RequestParam(value = "projectId", required = false) String projectId,  @RequestParam(
                    value = "pappName", required = false) String pappName ) {
    	
    	
        PageDataDTO<FlingSARInstancePO> pageDataDTO = instanceServices.listForSAR(projectId, null, pappName, Integer.MAX_VALUE, 1);

        List<FlingSARInstancePO> pos = pageDataDTO.getDatas();
        if (pos == null || pos.size() == 0) {
        	 ResponseModel model =new ResponseModel("0", "未能找到对应SAR信息。");
        	 List<ModelMap> datas = new ArrayList<ModelMap>();
        	 model.addAttribute("sarNames",datas);
        	 model.addAttribute("size",0);
            return model;
        }
        Set<String> sarNameSet  = new HashSet<String>();
        for(FlingSARInstancePO po : pos){
        	sarNameSet.add(po.getSarName());
        }
        List<SarDTO> datas = new ArrayList<SarDTO>(sarNameSet.size());
        for (String s : sarNameSet) {
        	SarDTO dto = new SarDTO();
        	dto.setId(s);
			dto.setSarName(s);
            datas.add(dto);
        }
        ResponseModel model = new ResponseModel();
        model.addAttribute("sarNames", datas);
        model.addAttribute("size", sarNameSet.size());
        return model;
    }
    @ESA("pafa5-admin-fling.getAllStatusPappList")
    public ResponseModel getAllStatusPappList(
    		@RequestParam(value = "status", required = true) int status,
    		@RequestParam(value = "pageSize", defaultValue = "100") int pageSize, 
    		@RequestParam(value = "pageNum", defaultValue = "1") int pageNum){
    	PageDataDTO<FlingPappInstancePO> pageDataDTO = instanceServices.listForPapp(status, pageSize, pageNum);
        List<FlingPappInstancePO> pos = pageDataDTO.getDatas();
        if (pos == null || pos.size() == 0) {
        	 ResponseModel model =new ResponseModel("0",  "未能找到对应节点信息。");
        	 model.addAttribute("datas", new ArrayList<ModelMap>());
            return model;
        }
        List<ModelMap> datas = new ArrayList<ModelMap>(pos.size());
        DateFormat formatter = null;
        formatter = DateFormat.getDateTimeInstance();
        for (FlingPappInstancePO po : pos) {
            ModelMap map = new ModelMap();
            map.put("instanceIp", po.getInstanceIp());
            map.put("lastActiveTime", formatter.format(new Date(po.getLastActiveTimestamp())));
            map.put("lastActiveObjectId", po.getLastActiveObjectId());
            map.put("lastActiveCause", po.getUpdatedBy());
            map.put("status", po.getStatus());
            map.put("hostName", "-");
            map.put("instanceName", "-");
            map.put("pappName", po.getAppName());
            String appName = po.getAppName();
            String ip = po.getInstanceIp();
            if (appName != null && !"".equals(appName.trim()) && ip != null&& !"".equals(ip.trim())) {
                FlingPappMonitorMsgPO detail = instanceServices.getInstanceDetails(status, appName, ip);
                if (detail != null) {
                    if (detail.getInstanceName() != null) {
                        map.put("instanceName", detail.getInstanceName());
                    }
                    if (detail.getHostName() != null) {
                        map.put("hostName", detail.getHostName());
                    }
                }
            }
            datas.add(map);
        }
        ResponseModel model = new ResponseModel();
        model.addAttribute("datas", datas);
        model.addAttribute("totalSize", pageDataDTO.getTotalSize());
        return model;
    	
    }
    
    
    @ESA("pafa5-admin-fling.getAllStatusSarList")
    public ResponseModel getAllStatusSarList(
    		@RequestParam(value = "status", required = true) int status,
    		@RequestParam(value = "pageSize", defaultValue = "100") int pageSize, 
    		@RequestParam(value = "pageNum", defaultValue = "1") int pageNum){
    	PageDataDTO<FlingSARInstancePO> pageDataDTO = instanceServices.listForSAR(status, pageSize, pageNum);

        List<FlingSARInstancePO> pos = pageDataDTO.getDatas();
        if (pos == null || pos.size() == 0) {
        	ResponseModel model = new  ResponseModel("0", "未能找到对应节点信息。");
            model.addAttribute("datas", new ArrayList<ModelMap>());
            return model;
        }
        List<ModelMap> datas = new ArrayList<ModelMap>(pos.size());
        DateFormat formatter = null;
        formatter = DateFormat.getDateTimeInstance();
        for (FlingSARInstancePO po : pos) {
            ModelMap map = new ModelMap();
            map.put("instanceIp", po.getInstanceIp());
            map.put("lastActiveTime", formatter.format(new Date(po.getLastActiveTimestamp())));
            map.put("lastActiveObjectId", po.getLastActiveObjectId());
            map.put("lastActiveCause", po.getCreatedBy());
            map.put("pappName", po.getAppName());
            map.put("sarName", po.getSarName());
            map.put("status", po.getStatus());
            datas.add(map);
        }
        ResponseModel model = new ResponseModel();
        model.addAttribute("datas", datas);
        model.addAttribute("totalSize", pageDataDTO.getTotalSize());
        return model;
    	
    }
    
    
    @ESA("pafa5-admin-fling.getSizebyStatus")
    public ResponseModel getSizebyStatus(@RequestParam(value = "status", required = true) int status ,@RequestParam(value = "type", required = true) String type){
    	int status0=0;
    	int status3=0;
    	List<FlingPappInstancePO> pos1 = null;
    	List<FlingSARInstancePO> pos2 = null;
    	if(status>=0&&status<10&&type.equals("papp")){
    		pos1 = instanceServices.listForPapp(status);
    	}else if(status>=0&&status<10&&type.equals("sar")){
    		pos2 = instanceServices.listForSAR(status);
    	}else {
    		ResponseModel model =new ResponseModel("0", "查询参数错误。");
       	 model.addAttribute("datas", new ArrayList<ModelMap>());
           return model;
    	}
    	if (type.equals("papp")&&(pos1==null||pos1.size()==0) || type.equals("sar")&&(pos2==null||pos2.size()==0)) {
        	ResponseModel model = new  ResponseModel("0", "未能找到相关信息。");
            model.addAttribute("datas", new ArrayList<ModelMap>());
            return model;
        }
        if(type.equals("papp")){
        	for (FlingPappInstancePO po : pos1) {
        		if(po.getStatus()==0)
        			++status0;
        		else
        			++status3;
            }
        }else{
        	for (FlingSARInstancePO po : pos2) {
        		if(po.getStatus()==0)
        			++status0;
        		else
        			++status3;
            }
        }
        
        ResponseModel model = new ResponseModel();
        model.addAttribute("numOfstatus0", status0);
        model.addAttribute("numOfstatus3", status3);
        return model;
    }
    
    @ESA("pafa5-admin-fling.getPappInstanceIp")
    public ResponseModel getPappInstanceIp(
    		@RequestParam(value = "pappName", required = true) String pappName ){
    	List<FlingPappInstancePO> pos = instanceServices.listForPapp("", pappName);
    	
    	if (pos == null || pos.size() == 0) {
        	ResponseModel model = new  ResponseModel("0", "未能找到对应节点信息。");
            model.addAttribute("datas", new ArrayList<ModelMap>());
            return model;
        }
    	List<String> datas = new ArrayList<String>(pos.size());
        DateFormat formatter = null;
        formatter = DateFormat.getDateTimeInstance();
        for (FlingPappInstancePO po : pos) {
            datas.add(po.getInstanceIp());
        }
        ResponseModel model = new ResponseModel();
        model.addAttribute("datas", datas);
        model.addAttribute("totalSize", pos.size());
        return model;
    	
    }
    
    @ESA("pafa5-admin-fling.getPappIpInfo")
    public ResponseModel getPappIpInfo(
    		@RequestParam(value = "paramMap", required = true) Map<String,List<String>> paramMap ){
    	Map<String, Map<String,List<String>>> mapResult = new HashMap<String, Map<String,List<String>>>();
    	for(Map.Entry<String, List<String>> entry:paramMap.entrySet() ) {
    		Map<String,List<String>> map = new HashMap<String,List<String>>();
    		for(String s:entry.getValue()) {
    			List<String> pos = instanceServices.listForPappIp(entry.getKey(), s);
    			map.put(s, pos);
    		}
    		mapResult.put(entry.getKey(), map);
    	}
    	
    	
    	if (mapResult == null || mapResult.size() == 0) {
        	ResponseModel model = new  ResponseModel("0", "未能找到对应节点信息。");
            model.addAttribute("datas", new HashMap<String, Map<String,List<String>>>());
            return model;
        }
        
        ResponseModel model = new ResponseModel();
        model.put("datas", mapResult);
        return model;
    	
    }
    @RequestMapping("/test.do")
    @ResponseBody
    public ServiceResults test(@RequestParam(value = "list", required = false)ArrayList<String> list
    		,@RequestParam(value = "listPapp", required = false)ArrayList<ArrayList<String>> listPapp) {
    	ServiceParams p = new ServiceParams();
    	Map<String,List<String>> map = new HashMap<>();
    	int i =0;
    	for(String s :list) {
    		if(map.containsKey(s)) {
    			List<String> dd = map.get(s);
    			dd.add(listPapp.get(i).get(0));
    			map.put(s, dd);
    			
    			i++;
    			continue;
    		}
    		map.put(s, listPapp.get(i));
    		i++;
    	}
    	p.set("paramMap", map);
    	ServiceResults re = getPappIpInfo.invoke(p);
    	
    	return re;
    	
    }
    
    @ESA("pafa5-admin-fling.getSearchList")
    public ResponseModel getSearchList(
    		@RequestParam(value = "searchField", required = false) String searchField,
    		@RequestParam(value = "projectId", required = false) String projectId,
    		@RequestParam(value = "pageSize", defaultValue = "20") int pageSize, 
    		@RequestParam(value = "pageNum", defaultValue = "1") int pageNum){
    	List<FlingPappInstancePO> posPapp = instanceServices.listPappSearchResult(projectId, searchField);
    	List<FlingSARInstancePO> posSar = instanceServices.listSarSearchResult(projectId, searchField);
    	int posPappSize=0;
		int posSarSize=0;
		int posPappAbnIndex=0;	
		int posSarAbnIndex=0;
		int totalSize = 0;
		if (posPapp == null || posPapp.size() == 0) {
			posPappSize=0;
		}else{
			posPappSize=posPapp.size();
		}
		if (posSar == null || posSar.size() == 0) {
			posSarSize=0;
		}else{
			posSarSize=posSar.size();
		}
		if (posPappSize+posSarSize == 0) {
        	 ResponseModel model =new ResponseModel("0", "未能搜索到任何相关信息。");
        	 model.addAttribute("datas", new ArrayList<ModelMap>());
            return model;
      }
		totalSize = posPappSize+posSarSize;
		List<ModelMap> datas = new ArrayList<ModelMap>(totalSize);
		DateFormat formatter = DateFormat.getDateTimeInstance();
		for(int i=0;i<posPappSize;i++){
			ModelMap map = new ModelMap();
			if(posPapp.get(i).getStatus()!=0){
				map.put("instanceIp", posPapp.get(i).getInstanceIp());
                map.put("lastActiveTime", formatter.format(new Date(posPapp.get(i).getLastActiveTimestamp())));
                map.put("lastActiveObjectId", posPapp.get(i).getLastActiveObjectId());
                map.put("lastActiveCause", posPapp.get(i).getUpdatedBy());
                map.put("status", posPapp.get(i).getStatus());
                map.put("pappName", posPapp.get(i).getAppName());
                map.put("projectId", posPapp.get(i).getProjectId()==null?"def":posPapp.get(i).getProjectId());
                map.put("type", "papp");
                datas.add(map);
			}
			if(posPapp.get(i).getStatus()==0){
				posPappAbnIndex=i;
				break;
			}
		}
		for(int i=0;i<posSarSize;i++){
			ModelMap map = new ModelMap();
			if(posSar.get(i).getStatus()!=0){
				map.put("instanceIp", posSar.get(i).getInstanceIp());
                map.put("lastActiveTime", formatter.format(new Date(posSar.get(i).getLastActiveTimestamp())));
                map.put("lastActiveObjectId", posSar.get(i).getLastActiveObjectId());
                map.put("lastActiveCause", posSar.get(i).getCreatedBy());
                map.put("pappName", posSar.get(i).getAppName());
                map.put("sarName", posSar.get(i).getSarName());
                map.put("status", posSar.get(i).getStatus());
                map.put("projectId", posSar.get(i).getProjectId()==null?"def":posSar.get(i).getProjectId());
                map.put("type", "sar");
                datas.add(map);
			}
			if(posSar.get(i).getStatus()==0){
				posSarAbnIndex=i;
				break;
			}
				
		}
		for(int i=posPappAbnIndex;i<posPappSize;i++){
			ModelMap map = new ModelMap();
			if(posPapp.get(i).getStatus()==0){
				map.put("instanceIp", posPapp.get(i).getInstanceIp());
                map.put("lastActiveTime", formatter.format(new Date(posPapp.get(i).getLastActiveTimestamp())));
                map.put("lastActiveObjectId", posPapp.get(i).getLastActiveObjectId());
                map.put("lastActiveCause", posPapp.get(i).getUpdatedBy());
                map.put("status", posPapp.get(i).getStatus());
                map.put("pappName", posPapp.get(i).getAppName());
                map.put("projectId", posPapp.get(i).getProjectId()==null?"def":posPapp.get(i).getProjectId());
                map.put("type", "papp");
                datas.add(map);
			}
		}
		for(int i=posSarAbnIndex;i<posSarSize;i++){
			ModelMap map = new ModelMap();
			if(posSar.get(i).getStatus()==0){
				map.put("instanceIp", posSar.get(i).getInstanceIp());
                map.put("lastActiveTime", formatter.format(new Date(posSar.get(i).getLastActiveTimestamp())));
                map.put("lastActiveObjectId", posSar.get(i).getLastActiveObjectId());
                map.put("lastActiveCause", posSar.get(i).getCreatedBy());
                map.put("pappName", posSar.get(i).getAppName());
                map.put("sarName", posSar.get(i).getSarName());
                map.put("projectId", posSar.get(i).getProjectId()==null?"def":posSar.get(i).getProjectId());
                map.put("status", posSar.get(i).getStatus());
                map.put("type", "sar");
                datas.add(map);
			}
		}
		List<ModelMap> datasOut = new ArrayList<ModelMap>(pageSize);
		for(int i=(pageNum-1)*pageSize;i<Math.min(datas.size(), pageNum*pageSize);i++){
			datasOut.add(datas.get(i));
		}
		ResponseModel model = new ResponseModel();
        model.addAttribute("datas", datasOut);
        model.addAttribute("totalSize", totalSize);
        return model;
	
    }
    @ESA("pafa5-admin-fling.getIndexPageList")
    public ResponseModel getIndexPageList(
    		@RequestParam(value = "type", required = true) String type,
    		@RequestParam(value = "projectId", required = false) String projectId,
    		@RequestParam(value = "pageSize", defaultValue = "10") int pageSize, 
    		@RequestParam(value = "pageNum", defaultValue = "1") int pageNum
    		){
    	
		List<FlingPappInstancePO> pos = instanceServices.listPappIndexPage(projectId);
		DateFormat formatter = null;
        formatter = DateFormat.getDateTimeInstance();
		if (pos == null || pos.size() == 0) {
           	ResponseModel model =new ResponseModel("0",  "未能找到对应节点信息。");
           	model.addAttribute("datas", new ArrayList<ModelMap>());
        	return model;
		}
		 List<ModelMap> datas = new ArrayList<ModelMap>(pos.size());
		for(FlingPappInstancePO po:pos){
			ModelMap map = new ModelMap();
			map.put("instanceIp", po.getInstanceIp());
            map.put("lastActiveTime", formatter.format(new Date(po.getLastActiveTimestamp())));
            map.put("lastActiveObjectId", po.getLastActiveObjectId());
            map.put("lastActiveCause", po.getUpdatedBy());
            map.put("status", po.getStatus());
            map.put("pappName", po.getAppName());
            map.put("type", "papp");
            datas.add(map);
		}
		List<ModelMap> datasOut = new ArrayList<ModelMap>(pageSize);
		for(int i=(pageNum-1)*pageSize;i<Math.min(datas.size(), pageNum*pageSize);i++){
			datasOut.add(datas.get(i));
		}
		ResponseModel model = new ResponseModel();
        model.addAttribute("datas", datasOut);
        model.addAttribute("totalSize", pos.size());
        return model;
	}
}
