package com.pingan.pafa5.admin.pizza.services.impl;

import org.springframework.stereotype.Service;

@Service
public class AdminLoginServiceImpl {

}
