package com.pingan.pafa5.admin.papp.dao.impl;

import java.util.List;

import com.pingan.pafa5.admin.commons.Nosql;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import com.google.common.collect.Lists;
import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa.mongodb.MongoPagination;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.papp.dao.PappManagerDAO;
import com.pingan.pafa5.admin.papp.dto.PappManagerDTO;
import com.pingan.pafa5.admin.papp.po.PappManagerPO;
import com.pingan.pafa5.admin.systems.dto.SystemGroupDTO;

/**
 * 应用管理dao
 * 2016-6-14 14:12:23
 * @author HOUSHANGZHI377
 *
 */
@Nosql
@Repository
public class PappManagerDAOImpl  extends BaseMongoDAO<PappManagerPO> implements PappManagerDAO 
{
	
	@Override
	public PappManagerPO isExists(PappManagerDTO form)
	{
		Criteria where = this.where("pappName").is(form.getPappName());
		return this._get(where);
	}
	
	@Override
	public PageDataDTO<PappManagerPO> list(PappManagerDTO dto) 
	{
		MongoPagination<PappManagerPO> page=new MongoPagination<PappManagerPO>(dto.getPage(),dto.getLimit());
		page.setDesc(true);
		page.setOrderBy(new String[]{"createdDate"});
		page.setTotalSize(-1);
		PageDataDTO<PappManagerPO> result = new PageDataDTO<PappManagerPO>();			
		Criteria where = new Criteria();
		
		if (!StringUtils.isEmpty(dto.getPappName()))
		{
			where.and("pappName").is(dto.getPappName());
		}
		if(!StringUtils.isEmpty(dto.getSystemsId())) 
		{
			where.and("systemsId").is(dto.getSystemsId());
		}
		
		this._paginated(where, page);				
		result.setDatas(page.getPojos());
		result.setTotalSize(page.getTotalSize());
		return result;
	}
	
	@Override
	public PageDataDTO<PappManagerPO> listUserPapp(PappManagerDTO dto ,List<SystemGroupDTO> list) 
	{
		MongoPagination<PappManagerPO> page=new MongoPagination<PappManagerPO>(dto.getPage(),dto.getLimit());
		page.setDesc(true);
		page.setOrderBy(new String[]{"createdDate"});
		page.setTotalSize(-1);
		PageDataDTO<PappManagerPO> result = new PageDataDTO<PappManagerPO>();
		if(null == list||list.size()==0)
		{
			result.setDatas(null);
			result.setTotalSize(0);
			return result;
		}
		
		Criteria where = new Criteria();
		if (!StringUtils.isEmpty(dto.getPappName())) 
		{
			where.and("pappName").is(dto.getPappName());
		}
		if(!StringUtils.isEmpty(dto.getSystemsId())) 
		{
			where.and("systemsId").is(dto.getSystemsId());
		}
		if(null != list&&list.size()>0)
		{
			List<Criteria> userSysList = Lists.newArrayList();
			for(SystemGroupDTO po:list)
			{
				Criteria sys = Criteria.where("systemsId").is(po.getGroupId());
				userSysList.add(sys);
			}
			where.orOperator((Criteria[])userSysList.toArray(new Criteria[userSysList.size()]));
		}
		
		this._paginated(where, page);
		
		result.setDatas(page.getPojos());
		result.setTotalSize(page.getTotalSize());
		return result;
	}

	@Override
	public PappManagerPO getById(String id) 
	{
		return this._getById(id);
	}
	
	@Override
	public PappManagerPO getByProperty(String property,String value){
		return this._getByProperty(property, value);
	}

	@Override
	public boolean updateById(PappManagerPO po) 
	{
		return this._updateById(po);
	}
	
	public void add(PappManagerPO po){
		  this._add(po);
	}

	@Override
	public boolean delById(String id) {
		// TODO Auto-generated method stub
		return this._removeById(id);
	}
	
}
