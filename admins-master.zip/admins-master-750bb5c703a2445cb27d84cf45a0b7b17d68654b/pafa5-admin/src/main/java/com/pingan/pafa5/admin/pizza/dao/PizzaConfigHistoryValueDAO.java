package com.pingan.pafa5.admin.pizza.dao;

import com.pingan.pafa5.admin.pizza.po.PizzaConfigHistoryValuePO;

public interface PizzaConfigHistoryValueDAO {

	
	void add(PizzaConfigHistoryValuePO historyValueDTO);
	
	PizzaConfigHistoryValuePO getById(String historyId);

	void update(PizzaConfigHistoryValuePO historyValueDTO);
	
	boolean del(String id);
}
