
package com.pingan.pafa5.admin.monitor.services.impl;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;

import javax.annotation.PreDestroy;
import javax.imageio.ImageIO;

import org.apache.commons.lang.time.DateFormatUtils;
import org.apache.commons.lang.time.DateUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.axis.DateAxis;
import org.jfree.chart.plot.XYPlot;
import org.jfree.data.time.Minute;
import org.jfree.data.time.TimeSeries;
import org.jfree.data.time.TimeSeriesCollection;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.dubbo.common.Constants;
import com.alibaba.dubbo.common.URL;
import com.alibaba.dubbo.common.logger.Logger;
import com.alibaba.dubbo.common.logger.LoggerFactory;
import com.alibaba.dubbo.common.utils.ConfigUtils;
import com.alibaba.dubbo.common.utils.NamedThreadFactory;
import com.alibaba.dubbo.common.utils.NetUtils;
import com.alibaba.dubbo.monitor.MonitorService;
import com.pingan.pafa.redis.lock.RedisLock;
import com.pingan.pafa.redis.lock.RedisLockFactory;
import com.pingan.pafa5.admin.monitor.dao.DubboInterfaceDAO;
import com.pingan.pafa5.admin.monitor.dao.DubboStatisticsDAO;
import com.pingan.pafa5.admin.monitor.dao.MongoFileDAO;
import com.pingan.pafa5.admin.monitor.dtos.StatisticsDTO;
import com.pingan.pafa5.admin.monitor.po.DubboInterfacePO;
import com.pingan.pafa5.admin.monitor.po.DubboMethodPO;
import com.pingan.pafa5.admin.monitor.po.DubboStatisticsPO;
import com.pingan.pafa5.admin.monitor.services.DubboMonitorService;

@Service("monitorService")
public class DubboMonitorServiceImpl implements MonitorService, DubboMonitorService {

    private static final Logger logger = LoggerFactory.getLogger(DubboMonitorServiceImpl.class);

    private static final String POISON_PROTOCOL = "poison";
    private static final String LOCK_OBJ_ID = "pizza-dubbo-monitor";

    // 定时任务执行器
    private final ScheduledExecutorService scheduledExecutorService =
            Executors.newScheduledThreadPool(1, new NamedThreadFactory("DubboMonitorTimer", true));

    // 图表绘制定时器
    private final ScheduledFuture<?> chartFuture;

    private final Thread writeThread;

    private final BlockingQueue<URL> queue;

    private volatile boolean running = true;

    private String[] parsePatterns = {"yyyy-MM-dd"};

    @Autowired
    private DubboStatisticsDAO dubboStatisticsDAO;

    @Autowired
    private DubboInterfaceDAO dubboInterfaceDAO;

    @Autowired
    private RedisLockFactory lockFactory;

    @Autowired
    private MongoFileDAO fileDAO;

    public DubboMonitorServiceImpl() {
        queue = new LinkedBlockingQueue<URL>(Integer.parseInt(ConfigUtils.getProperty("dubbo.monitor.queue", "100000")));

        writeThread = new Thread(new Runnable() {
            public void run() {
                while (running) {
                    try {
                        writeMongo(); // 记录统计日志
                    } catch (Throwable t) { // 防御性容错
                        logger.error("Unexpected error occur at write stat log, cause: "
                                + t.getMessage(), t);
                        try {
                            Thread.sleep(5000); // 失败延迟
                        } catch (Throwable t2) {
                        }
                    }
                }
            }
        });
        writeThread.setDaemon(true);
        writeThread.setName("DubboMonitorAsyncWriteLogThread");
        writeThread.start();

        chartFuture = scheduledExecutorService.scheduleWithFixedDelay(new Runnable() {
            public void run() {
                try {
                    // drawMongoDB(); // 绘制图表
                } catch (Throwable t) { // 防御性容错
                    logger.error( "Unexpected error occur at draw stat chart, cause: " + t.getMessage(), t);
                }
            }
        }, 1, 300, TimeUnit.SECONDS);
    }

    @PreDestroy
    public void close() {
        try {
            running = false;
            queue.offer(new URL(POISON_PROTOCOL, NetUtils.LOCALHOST, 0));
        } catch (Throwable t) {
            logger.warn(t.getMessage(), t);
        }
        try {
            chartFuture.cancel(true);
        } catch (Throwable t) {
            logger.warn(t.getMessage(), t);
        }
    }

    private void writeMongo() throws Exception {
        URL statistics = queue.take();
        if (POISON_PROTOCOL.equals(statistics.getProtocol())) {
            return;
        }
        saveData(statistics);
    }

    private void drawMongoDB() {
        /*
         * if (!dubboMonitorOpen) { return; } String service = ""; String methodName = ""; long
         * elapsedMax = 0; String day = new SimpleDateFormat("yyyyMMdd").format(new Date()); String
         * creatTime = new SimpleDateFormat("yyyy-MM-dd").format(new Date()); List<StatisticsDTO>
         * list = statisMongoDAO.listByPropertys("status", "0", "creatTime", creatTime);//
         * 查询当天所有未更新为图表的数据 if (list == null || list.size() == 0) { return; } // 要对多个方法进行遍历
         * List<String> methodlist = new ArrayList<String>(); for (StatisticsDTO sto : list) {
         * String un = sto.getService() + "/" + sto.getMethodName(); methodlist.add(un); }
         * methodlist = removeDuplicateWithOrder(methodlist); for (int i = 0; i < methodlist.size();
         * i++) { Map<String, long[]> elapsedData = new HashMap<String, long[]>(); Map<String,
         * long[]> successData = new HashMap<String, long[]>(); double[] elapsedSummary = new
         * double[4]; double[] successSummary = new double[4]; service =
         * methodlist.get(i).split("/")[0]; methodName = methodlist.get(i).split("/")[1];
         * List<StatisticsDTO> listone = statisMongoDAO.listByValues("service", service,
         * "methodName", methodName, "creatTime", creatTime); appendDataMongo(listone, elapsedData,
         * elapsedSummary, "elapsed"); appendDataMongo(listone, successData, successSummary,
         * "success"); for (StatisticsDTO statis : listone) { elapsedMax = Math.max(elapsedMax,
         * statis.getMaxelapsed()); statis.setStatus("1"); statisMongoDAO.updateByProperty("unique",
         * statis.getUnique(), statis); } List<MethodDTO> mtos = methodMongoDAO.listTypes(service,
         * methodName, creatTime); for (MethodDTO mto : mtos) { elapsedSummary[0] =
         * Math.max(elapsedSummary[0], mto.getMaxelapsed()); elapsedSummary[1] = -1;
         * elapsedSummary[2] += mto.getAvgelapsed(); elapsedSummary[3] = -1; successSummary[3] +=
         * mto.getSuccess(); } createChartMongo("ms/t", service, methodName, day, new String[]
         * {CONSUMER, PROVIDER}, elapsedData, elapsedSummary, "elapsed"); successSummary[0] =
         * successSummary[0] / 60; successSummary[1] = successSummary[1] / 60; successSummary[2] =
         * successSummary[2] / 60; createChartMongo("t/s", service, methodName, day, new String[]
         * {CONSUMER, PROVIDER}, successData, successSummary, "success");
         * 
         * }
         */
    }

    public static List<String> removeDuplicateWithOrder(List<String> list) {
        Set<Object> set = new HashSet<Object>();
        List<String> newList = new ArrayList<String>();
        for (Iterator<String> iter = list.iterator(); iter.hasNext();) {
            String element = iter.next();
            if (set.add(element))
                newList.add(element);
        }
        return newList;
    }

    private void appendDataMongo(List<StatisticsDTO> list, Map<String, long[]> data,double[] summary, String type) {
        int sum = 0;
        int cnt = 0;
        long value = 0;
        for (StatisticsDTO sta : list) {
            String key = sta.getUpdate().substring(11, 16).replace(":", "");
            if (type.equalsIgnoreCase("elapsed")) {
                value = sta.getElapsed();
            }
            if (type.equalsIgnoreCase("success")) {
                value = sta.getSuccess();
            }
            long[] values = data.get(key);
            if (values == null) {
                values = new long[2];
                data.put(key, values);
            }
            if (sta.getType().equalsIgnoreCase("consumer")) {
                values[0] += value;
            } else {
                values[1] += value;
                summary[0] = Math.max(summary[0], values[1]);
                summary[1] = summary[1] == 0 ? values[1] : Math.min(summary[1], values[1]);
                sum += value;
                cnt++;
            }
        }
    }

    private void createChartMongo(String key, String service, String method, String date,String[] types, Map<String, long[]> data, double[] summary, String chartype) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmm");
        DecimalFormat numberFormat = new DecimalFormat("###,##0.##");
        TimeSeriesCollection xydataset = new TimeSeriesCollection();
        for (int i = 0; i < types.length; i++) {
            String type = types[i];
            TimeSeries timeseries = new TimeSeries(type);
            for (Map.Entry<String, long[]> entry : data.entrySet()) {
                try {
                    timeseries.add(new Minute(dateFormat.parse(date + entry.getKey())),
                            entry.getValue()[i]);
                } catch (ParseException e) {
                    logger.error(e.getMessage(), e);
                }
            }
            xydataset.addSeries(timeseries);
        }
        JFreeChart jfreechart = ChartFactory
                .createTimeSeriesChart(
                        "max: " + numberFormat.format(summary[0])
                                + (summary[1] >= 0 ? " min: " + numberFormat.format(summary[1])
                                        : "")
                                + " avg: " + numberFormat.format(summary[2])
                                + (summary[3] >= 0 ? " sum: " + numberFormat.format(summary[3])
                                        : ""),
                        toDisplayService(service) + "  " + method + "  " + toDisplayDate(date), key,
                        xydataset, true, true, false);
        jfreechart.setBackgroundPaint(Color.WHITE);
        XYPlot xyplot = (XYPlot) jfreechart.getPlot();
        xyplot.setBackgroundPaint(Color.WHITE);
        xyplot.setDomainGridlinePaint(Color.GRAY);
        xyplot.setRangeGridlinePaint(Color.GRAY);
        xyplot.setDomainGridlinesVisible(true);
        xyplot.setRangeGridlinesVisible(true);
        DateAxis dateaxis = (DateAxis) xyplot.getDomainAxis();
        dateaxis.setDateFormatOverride(new SimpleDateFormat("HH:mm"));
        BufferedImage image = jfreechart.createBufferedImage(600, 300);
        try {
            if (logger.isInfoEnabled()) {
                logger.info("write chart: ");
            }
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            try {
                ImageIO.write(image, "png", out);
                // mongodb
                ByteArrayInputStream in = new ByteArrayInputStream(out.toByteArray());
                // filename = service + method + day 表示同一个方法一天创建一条数据
                String filename = "";
                if (chartype.equalsIgnoreCase("success")) {
                    filename = service + "." + method + "." + date + "." + chartype;
                } else {
                    filename = service + "." + method + "." + date;
                }
                if (in != null) {
                    fileDAO.deleteOneFileAccordingToFilename(filename);
                    fileDAO.insertOrUpdateFile(in, filename);
                    logger.info("------------>" + filename);
                }
                out.flush();
            } finally {
                out.close();
            }
        } catch (IOException e) {
            logger.warn(e.getMessage(), e);
        }
    }

    private static String toDisplayService(String service) {
        int i = service.lastIndexOf('.');
        if (i >= 0) {
            return service.substring(i + 1);
        }
        return service;
    }

    private static String toDisplayDate(String date) {
        try {
            return new SimpleDateFormat("yyyy-MM-dd")
                    .format(new SimpleDateFormat("yyyyMMdd").parse(date));
        } catch (ParseException e) {
            return date;
        }
    }

    private void saveData(URL statistics) throws Exception {
    	if("false".equalsIgnoreCase(System.getProperty("dubbo.service.open", "false"))){
    		logger1.info("dubbo 服务统计开关关闭，无需统计");
    		return;
    	}
        String timestamp = statistics.getParameter(Constants.TIMESTAMP_KEY);
        Date now;
        if (timestamp == null || timestamp.length() == 0) {
            now = new Date();
        } else if (timestamp.length() == "yyyyMMddHHmmss".length()) {
            now = new SimpleDateFormat("yyyyMMddHHmmss").parse(timestamp);
        } else {
            now = new Date(Long.parseLong(timestamp));
        }
        int success = statistics.getParameter(SUCCESS, 0);
        int failure = statistics.getParameter(FAILURE, 0);
        int input = statistics.getParameter(INPUT, 0);
        int output = statistics.getParameter(OUTPUT, 0);
        int elapsed = statistics.getParameter(ELAPSED, 0);
        int concurrent = statistics.getParameter(CONCURRENT, 0);
        int maxInput = statistics.getParameter(MAX_INPUT, 0);
        int maxOutput = statistics.getParameter(MAX_OUTPUT, 0);
        int mxaElapsed = statistics.getParameter(MAX_ELAPSED, 0);
        int maxConcurrent = statistics.getParameter(MAX_CONCURRENT, 0);
        String applicationName = statistics.getParameter(APPLICATION);
        String interfaceName = statistics.getServiceInterface();
        String methodName = statistics.getParameter(METHOD);
        try {
            String type;
            String consumer;
            String provider;
            if (statistics.hasParameter(PROVIDER)) {
                type = CONSUMER;
                consumer = statistics.getHost();
                provider = statistics.getParameter(PROVIDER);
                int i = provider.indexOf(':');
                if (i > 0) {
                    provider = provider.substring(0, i);
                }
            } else {
                type = PROVIDER;
                consumer = statistics.getParameter(CONSUMER);
                int i = consumer.indexOf(':');
                if (i > 0) {
                    consumer = consumer.substring(0, i);
                }
                provider = statistics.getHost();
            }

            // 不记录fling的心跳接口调用
            if ("com.pingan.pafa.fling.monitor.FlingMonitorDubboServices".equals(interfaceName)
                    && "sendMonitorMsg".equals(methodName)) {
                return;
            }

            DubboStatisticsPO po = new DubboStatisticsPO();
            po.setApplicationName(applicationName);
            po.setInterfaceName(interfaceName);
            po.setMethodName(methodName);
            po.setConsumerHost(consumer);
            po.setProviderHost(provider);
            po.setType(type);
            po.setSuccess(success);
            po.setFailure(failure);
            po.setInput(input);
            po.setOutput(output);
            po.setElapsed(elapsed);
            po.setConcurrent(concurrent);
            po.setMaxInput(maxInput);
            po.setMaxOutput(maxOutput);
            po.setMaxElapsed(mxaElapsed);
            po.setMaxConcurrent(maxConcurrent);
            po.setCreateTime(now);
            dubboStatisticsDAO.save(po);
        } catch (Throwable t) {
            logger.error(t.getMessage(), t);
        }
    }

    public void count(URL statistics) {
        collect(statistics);
    }

    public void collect(URL statistics) {
        queue.offer(statistics);
        if (logger.isInfoEnabled()) {
            logger.info("collect statistics: " + statistics);
        }
    }

    public List<URL> lookup(URL query) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long countMethod(String likeName, String relDate, String type) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public List<DubboMethodPO> listMethod(String likeName, String relDate, String type, int page,
            int limit) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public long countInterface(String startTime,String endTime, String interfaceName) {
        Date beginDate = getBeginDate(startTime);
        Date endDate = getBeginDate(endTime);
        endDate = DateUtils.addDays(endDate, 1);
        return dubboInterfaceDAO.count(interfaceName, beginDate, endDate);
    }

    @Override
    public List<DubboInterfacePO> listInterface(String startTime,String endTime, String interfaceName, int page,
            int limit) {
    	Date beginDate = getBeginDate(startTime);
        Date endDate = getBeginDate(endTime);
        endDate = DateUtils.addDays(endDate, 1);
        int skip = (page - 1) * limit;
        return dubboInterfaceDAO.list(interfaceName, beginDate, endDate, skip, limit);
    }

    @Override
    public long countStatistics(String logDay, String interfaceName) {
        Date beginDate = getBeginDate(logDay);
        Date endDate = DateUtils.addDays(beginDate, 1);
        return dubboStatisticsDAO.count(interfaceName, beginDate, endDate);
    }

    @Override
    public List<DubboStatisticsPO> listStatistics(String logDay, String interfaceName, int page,
            int limit) {
        Date beginDate = getBeginDate(logDay);
        Date endDate = DateUtils.addDays(beginDate, 1);
        int skip = (page - 1) * limit;
        return dubboStatisticsDAO.list(interfaceName, beginDate, endDate, skip, limit);
    }

    @Override
    public void cleanData() {
        // TODO Auto-generated method stub
    }
    private Log logger1 = LogFactory.getLog(this.getClass());
    @Override
    public void calculateData() {
    	if("false".equalsIgnoreCase(System.getProperty("dubbo.service.open", "false"))){
    		logger1.info("dubbo 服务统计开关关闭，无需统计");
    		return;
    	}
        RedisLock lock = lockFactory.getLock(LOCK_OBJ_ID+System.getProperty("env.lock", ""));
        if (lock.tryLock()) {
            try {
                Date now = new Date();
                List<DubboStatisticsPO> list = dubboStatisticsDAO.list(now);
                dubboStatisticsDAO.removeByCreateTime(now);
                Map<String, DubboInterfacePO> mapping = new HashMap<String, DubboInterfacePO>();
                if (list != null && list.size() != 0) {
                	logger1.info("需要计算的服务数量："+list.size());
                    Iterator<DubboStatisticsPO> it = list.iterator();
                    while (it.hasNext()) {
                         DubboStatisticsPO po = it.next();
                    	 String key = po.getApplicationName() + "/" + po.getInterfaceName() + "/" + po.getType() + "/"+ DateFormatUtils.format(po.getCreateTime(), "yyyyMMdd");
                    	 if (mapping.containsKey(key)) {
                             DubboInterfacePO interfacePO = mapping.get(key);
                             interfacePO.setSuccess(interfacePO.getSuccess() + po.getSuccess());
                             interfacePO.setFailure(interfacePO.getFailure() + po.getFailure());
                             interfacePO.setTotal(interfacePO.getSuccess() + interfacePO.getFailure());
                             interfacePO.setElapsed(interfacePO.getElapsed() + po.getElapsed());
                             if (interfacePO.getTotal() != 0) {
                                 interfacePO.setAvgElapsed(interfacePO.getElapsed() / interfacePO.getTotal());
                             }
                             if (po.getMaxElapsed() > interfacePO.getMaxElapsed()) {
                                 interfacePO.setMaxElapsed(po.getMaxElapsed());
                             }
                             if (po.getConcurrent() < interfacePO.getMinConcurrent()) {
                                 interfacePO.setMinConcurrent(po.getConcurrent());
                             }
                             if (po.getMaxConcurrent() > interfacePO.getMaxConcurrent()) {
                                 interfacePO.setMaxConcurrent(po.getMaxConcurrent());
                             }
                             interfacePO.setUpdateTime(now);
                             mapping.put(key, interfacePO);
                         } else {
                             DubboInterfacePO interfacePO = new DubboInterfacePO();
                             interfacePO.setId(key);
                             interfacePO.setApplicationName(po.getApplicationName());
                             interfacePO.setInterfaceName(po.getInterfaceName());
                             interfacePO.setMethodName(po.getMethodName());
                             interfacePO.setType(po.getType());
                             interfacePO.setSuccess(po.getSuccess());
                             interfacePO.setFailure(po.getFailure());
                             interfacePO.setTotal(interfacePO.getSuccess() + interfacePO.getFailure());
                             interfacePO.setElapsed(po.getElapsed());
                             if (interfacePO.getTotal() != 0) {
                                 interfacePO.setAvgElapsed(interfacePO.getElapsed() / interfacePO.getTotal());
                             }
                             interfacePO.setMaxElapsed(po.getMaxElapsed());
                             interfacePO.setMinConcurrent(po.getConcurrent());
                             interfacePO.setMaxConcurrent(po.getMaxConcurrent());
                             interfacePO.setUpdateTime(now);
                             mapping.put(key, interfacePO);
                        }
						
                        it.remove();
                    }
                    for (DubboInterfacePO po : mapping.values()) {
                        DubboInterfacePO temp = dubboInterfaceDAO.getById(po.getId());
                        if (temp == null) {
                            dubboInterfaceDAO.save(po);
                        } else {
                            dubboInterfaceDAO.update(po);
                        }
                    }
                } else {
                    logger.info("没有监控到任何服务.");
                }
            } finally {
                lock.unlock();
            }
        } else {
            logger.debug("Another dubbo monitor action is running");
        }
    }

    private Date getBeginDate(String logDay) {
        try {
            Date beginDate = DateUtils.parseDate(logDay, parsePatterns);
            return beginDate;
        } catch (ParseException e) {
            return new Date();
        }
    }

}
