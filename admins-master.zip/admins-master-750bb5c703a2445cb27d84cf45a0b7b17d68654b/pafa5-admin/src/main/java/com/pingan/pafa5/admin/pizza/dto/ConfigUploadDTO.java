package com.pingan.pafa5.admin.pizza.dto;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

/**
 * 配置信息 
 * @author EX-YANGSHENGXIANG001
 */
public class ConfigUploadDTO extends ConfigSaveDTO{

	
	
	//上传文件
	private CommonsMultipartFile upload;
	
	//配置组类型
	private String group;

	public CommonsMultipartFile getUpload() {
		return upload;
	}

	public void setUpload(CommonsMultipartFile upload) {
		this.upload = upload;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	} 
	
	

	
	
}
