/**
 * pizza配置管理
 */
package com.pingan.pafa5.admin.pizza;