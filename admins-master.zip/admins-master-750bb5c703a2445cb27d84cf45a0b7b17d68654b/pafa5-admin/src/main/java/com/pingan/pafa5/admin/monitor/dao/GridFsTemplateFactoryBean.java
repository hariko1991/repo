package com.pingan.pafa5.admin.monitor.dao;

import java.util.List;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.data.mongodb.MongoDbFactory;
import org.springframework.data.mongodb.core.SimpleMongoDbFactory;
import org.springframework.data.mongodb.core.convert.DbRefResolver;
import org.springframework.data.mongodb.core.convert.DefaultDbRefResolver;
import org.springframework.data.mongodb.core.convert.MappingMongoConverter;
import org.springframework.data.mongodb.core.convert.MongoConverter;
import org.springframework.data.mongodb.core.mapping.MongoMappingContext;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;

import com.mongodb.MongoClient;
import com.mongodb.MongoClientOptions;
import com.mongodb.MongoCredential;
import com.mongodb.ServerAddress;
import com.pingan.pafa.mongodb.MongodbConfigure;
import com.pingan.pafa.mongodb.MongodbConfigureHandler;

public class GridFsTemplateFactoryBean extends MongodbConfigureHandler implements InitializingBean, DisposableBean, FactoryBean<GridFsTemplate> {
	//private Logger logger = LoggerFactory.getLogger(GridFsTemplateFactoryBean.class);
	
	private String bucket;
	private MongoDbFactory dbFactory;
	private MongoConverter converter;
	
	private MongodbConfigure config;
	private MongoClientOptions ops;
	private List<MongoCredential> mongoCredentials;
	//private MongoCredential credential;
	List<ServerAddress> servers;
	
	private GridFsTemplate fs;
	
	@Override
	public void afterPropertiesSet() throws Exception {
		config = this.initializeConfigure();
		mongoCredentials = this.resolveCredentials(config);
		//credential = getCredentials(config);
		ops = this.resolveClientOptions(config);
		servers = this.resovleServers(config);
	}

	@Override
	public void destroy() throws Exception {
		if (fs != null) {
			fs = null;
		}
		config = null;
		//credential = null;
		ops = null;
		servers = null;
	}
	
	/*public MongoCredential getCredentials(MongodbConfigure config) {
		String user = config.getUser();
		if (StringUtils.isBlank(user)) {
			logger.info("no mongo user defined");
			return null;
		}
		String pwd = config.getPassword();
		if (StringUtils.isBlank(pwd)) {
			logger.info("password is blank, try read it from passwordKey");
			pwd = this.readPassword(user, config.getPasswordKey(), user);
		}
		
		return MongoCredential.createCredential(user, config.getDbname(), pwd.toCharArray());
		//return new UserCredentials(user, pwd);
	}*/

	@Override
	public GridFsTemplate getObject() throws Exception {
		if (dbFactory == null) {
			dbFactory = new SimpleMongoDbFactory(getClient(), config.getDbname());
		}
		if (converter == null) {
			converter = getDefaultMongoConverter(dbFactory);
		}
		fs = new GridFsTemplate(dbFactory, converter, bucket);
		return fs;
	}
	
	/**
	 * this method is a clone of MongoTemplate.getDefaultMongoConverter
	 * @param factory
	 * @return
	 */
	private final MongoConverter getDefaultMongoConverter(MongoDbFactory factory) {
		DbRefResolver dbRefResolver = new DefaultDbRefResolver(factory);
		MappingMongoConverter converter = new MappingMongoConverter(dbRefResolver, new MongoMappingContext());
		converter.afterPropertiesSet();
		return converter;
	}
	
	public MongoClient getClient() {
		if (servers.size() == 1 && "direct".equals(config.getAuthorityType())) {
			return new MongoClient(servers.get(0), mongoCredentials, ops);
		} else {
			return new MongoClient(servers, mongoCredentials, ops);
		}
	}

	@Override
	public Class<?> getObjectType() {
		return GridFsTemplate.class;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}
	
	public MongoDbFactory getDbFactory() {
		return dbFactory;
	}

	public void setDbFactory(MongoDbFactory dbFactory) {
		this.dbFactory = dbFactory;
	}

	public MongoConverter getConverter() {
		return converter;
	}

	public void setConverter(MongoConverter converter) {
		this.converter = converter;
	}

	public void setBucket(String bucket) {
		this.bucket = bucket;
	}
	
	public String getBucket() {
		return bucket;
	}
}
