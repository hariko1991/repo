package com.pingan.pafa5.admin.pizza.services;

import java.util.List;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dto.GlobalVariableDTO;
import com.pingan.pafa5.admin.pizza.form.GlobalVariableForm;
import com.pingan.pafa5.admin.pizza.po.GlobalVariablePO;

/**
 * 全局变量操作服务类
 * @author ZHANGJIAWEI370
 *
 */
public interface GlobalVariableService {

	/**
	 * 查询全局变量
	 * @param proId
	 * @param property
	 * @param page
	 * @param limit
	 * @return
	 * @throws Exception
	 */
	public PageDataDTO<GlobalVariableDTO> list(String proId, String property, int page,
											   int limit) throws Exception;

	/**
	 * 获取全局变量
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public GlobalVariableDTO getById(String id) throws Exception;

	/**
	 * 添加全局变量
	 * @param form
	 */
	public void add(GlobalVariableForm form);

	/**
	 * 修改全局变量
	 * @param form
	 * @return
	 */
	public boolean edit(GlobalVariableForm form);

	/**
	 * 删除全局变量
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public boolean delete(String id) throws Exception;
	
	/**
     * 生成全局变量文件并保存到PizzaManager
     * 
     * @param domainId
     */
    public void putPizzaManager(String domainId);
	
	/**
	 * 所有全局变量生成属性
	 * @param domainId
	 * @return
	 */
	public String toProperties(String domainId);
	
	public List<GlobalVariablePO> list(String proId);

}