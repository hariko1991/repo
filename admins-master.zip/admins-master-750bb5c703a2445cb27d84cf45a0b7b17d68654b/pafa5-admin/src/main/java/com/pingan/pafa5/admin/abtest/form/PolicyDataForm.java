package com.pingan.pafa5.admin.abtest.form;

public class PolicyDataForm {

	private String policy;
	
	private String ipString;
	
	private String oldIp;
	
	public String getOldIp() {
		return oldIp;
	}

	public void setOldIp(String oldIp) {
		this.oldIp = oldIp;
	}

	public String getPolicy() {
		return policy;
	}

	public void setPolicy(String policy) {
		this.policy = policy;
	}

	public String getIpString() {
		return ipString;
	}

	public void setIpString(String ipString) {
		this.ipString = ipString;
	}
}