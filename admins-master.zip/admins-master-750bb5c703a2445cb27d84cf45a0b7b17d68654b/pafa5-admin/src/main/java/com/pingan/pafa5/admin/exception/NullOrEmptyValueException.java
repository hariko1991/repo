package com.pingan.pafa5.admin.exception;

/**
 * 不能为空的值, 抛出异常
 * 
 * @author SHICHENGCHENG316
 * 
 */
public class NullOrEmptyValueException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public NullOrEmptyValueException() {
		super();
	}

	public NullOrEmptyValueException(String message) {
		super(message);
	}

}