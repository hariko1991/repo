package com.pingan.pafa5.admin.fling.services.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa5.admin.fling.dao.DruidDatasourceDAO;
import com.pingan.pafa5.admin.fling.dao.FlingPappInstanceDAO;
import com.pingan.pafa5.admin.fling.po.DruidDatasourcePO;
import com.pingan.pafa5.admin.fling.po.FlingPappInstancePO;
import com.pingan.pafa5.admin.fling.services.DruidDatasourceService;

@Service("druidDatasourceService")
public class DruidDatasourceServiceImpl extends BaseServices implements DruidDatasourceService {
	
	@Autowired
	private DruidDatasourceDAO druidDatasourceDAO;
	
	@Autowired
	private FlingPappInstanceDAO flingPappInstanceDAO;

	@Override
	public void druidHeartBeat() {
		List<DruidDatasourcePO> list = druidDatasourceDAO.getAll();
		Map<String,Object> map = new HashMap<String,Object>();
		
		for(DruidDatasourcePO po :list){
			map.put("domainId", po.getDomainId());
			map.put("pappName", po.getPappName());
			map.put("instanceIp", po.getInstanceIp());
			FlingPappInstancePO fpi = flingPappInstanceDAO.getFlingPappInstancePO(po.getPappName(),po.getInstanceIp(),po.getDomainId());
			if(fpi.getStatus() != po.getStatus()){
				po.setStatus(fpi.getStatus());
				druidDatasourceDAO.update(po);
			}
			map.remove("domainId");
			map.remove("pappName");
			map.remove("instanceIp");
		}
		
		
	}


	

	
	

}
