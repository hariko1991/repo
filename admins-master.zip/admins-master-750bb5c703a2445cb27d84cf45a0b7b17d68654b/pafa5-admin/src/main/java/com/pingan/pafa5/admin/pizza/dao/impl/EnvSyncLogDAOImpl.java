package com.pingan.pafa5.admin.pizza.dao.impl;

import java.util.List;
import java.util.Map;
import java.util.regex.Pattern;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.pizza.dao.EnvSyncLogDAO;
import com.pingan.pafa5.admin.pizza.po.EnvSyncLogPO;
import com.pingan.um.client.util.UUID;

@Nosql
@Repository
public class EnvSyncLogDAOImpl extends BaseMongoDAO<EnvSyncLogPO> implements EnvSyncLogDAO {

    @Override
    public List<EnvSyncLogPO> list(Map<String,Object> queryParams, int page, int limit) {
        Criteria criteria = null;
        int index = 0;
        if(queryParams != null){
        	for(String key : queryParams.keySet()){
        		if(index <= 0){
        			criteria = where(key).is(queryParams.get(key));
        		}else{
        			criteria.and(key).regex( Pattern.compile("^.*" + queryParams.get(key) + ".*$", Pattern.CASE_INSENSITIVE));
        		}
        	}
        }
       
        int skip = (page - 1) * limit;
        return this._listAndDesc(criteria, skip, limit, "createdDate");
    }

    @Override
    public long getCount(Map<String,Object> queryParams) {
        Criteria criteria = null;
        int index = 0;
        if(queryParams != null){
        	for(String key : queryParams.keySet()){
        		if(index <= 0){
        			criteria = where(key).is(queryParams.get(key));
        		}else{
        			criteria.and(key).regex( Pattern.compile("^.*" + queryParams.get(key)
        					+ ".*$", Pattern.CASE_INSENSITIVE));
        		}
        	}
        }
        return this._count(criteria);
    }

    @Override
    public String add(EnvSyncLogPO po) {
        String id = UUID.getRandomID();
        po.setId(id);
        this._add(po);
        return id;
    }

    @Override
    public boolean update(EnvSyncLogPO po) {
        return this._updateById(po);
    }

    @Override
    public EnvSyncLogPO findById(String id) {
        return this._getById(id);
    }

}
