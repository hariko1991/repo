package com.pingan.pafa5.admin.papp.web;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentFactory;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Multimap;
import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.pizza.PizzaConstants;
import com.pingan.pafa5.admin.Constants;
import com.pingan.pafa5.admin.commons.SARManagerConstants;
import com.pingan.pafa5.admin.papp.dto.DependencyDTO;
import com.pingan.pafa5.admin.papp.dto.IvyDenpendencyConfigDTO;

@Controller
public class PappRelyConfigController {

	private static Log logger = LogFactory.getLog(PappRelyConfigController.class);
	
	@ActionClient(name="pafa5_admin_pizza.getConfigItem")
	private IServiceClient client;
	
	@ActionClient(name="pafa5-admin-pizza.modifyConfigContent")
	private IServiceClient pizzaClient;
	
	@ActionClient(name="pafa5-admin-pizza.saveConfig")
	private IServiceClient pizzaSaveConfigService;
	
	@RequestMapping("/papp/relyConfig-list.do")
	@ResponseBody
	public ResponseModel list(@RequestParam(value="pappName", required=true) String pappName,
								@RequestParam(value="projectId", required=true) String projectId) {
		if(logger.isInfoEnabled()){
			logger.info("list,pappName=" + pappName);
		}
		
		ResponseModel model = new ResponseModel();
		String pizzaKey = pappName + "." + Constants.IVY_XML;
		try {
			ServiceParams params = ServiceParams.newInstance();
			params.set("projectId", projectId);
			params.set("group", PizzaConstants.GROUP_PAPP);
			params.set("key", pizzaKey);
			ServiceResults result = client.invoke(params);
			String ivyXmlContent = result.getString("value");
			String responseCode = result.getString("responseCode");
			boolean success = responseCode.equals(SARManagerConstants.RESPONSECODE_ZERO);
			if (success && ivyXmlContent!=null ) {
				List<DependencyDTO> dependencys = parserXML(ivyXmlContent);
				model.put("xmlContent", ivyXmlContent);
				model.put("datas", dependencys);
				model.put("totalProperty", dependencys.size());
			} else {
				model.put("xmlContent", "");
			}
		} catch (DocumentException e) {
			logger.error("ivy.xml文件解析错误！", e);
			model.setResponseCode("1");
			model.setResponseMsg("ivy.xml文件解析错误！");
		} catch (Exception e) {
			logger.error("获取依赖配置列表错误！", e);
			model.setResponseCode("1");
			model.setResponseMsg("获取依赖配置列表错误！");
		}
		
		return model;
	}
	
	@ResponseBody
	@RequestMapping("/papp/relyConfig-add.do")
	public ResponseModel addRelyConfig(IvyDenpendencyConfigDTO form) {
		if(logger.isInfoEnabled()){
			logger.info("add,items=" + JSON.toJSONString(form));
		}
		
		ResponseModel model = new ResponseModel();
		String ivyXmlContent = form.getXmlContent();
		logger.info("ivyXmlContent = " + ivyXmlContent);
		
		DependencyDTO dependency = new DependencyDTO();
		dependency.setOrg(form.getOrg());
		dependency.setModule(form.getModule());
		dependency.setVersion(form.getVersion());
		
		try {
			ivyXmlContent = modifyRelyConfig(ivyXmlContent, dependency, "add");
			logger.info("ivyXmlContent = " + ivyXmlContent);
			
			String pizzaKey = form.getPappName() + "." + Constants.IVY_XML;
			
//			ServiceParams params = ServiceParams.newInstance();
//			params.set("group", PizzaConstants.GROUP_PAPP);
//			params.set("key", pizzaKey);
//			params.set("content", ivyXmlContent);
//			ServiceResults result = pizzaClient.invoke(params);
			
			// 保存配置信息
			ServiceParams params = ServiceParams.newInstance().set("group", PizzaConstants.GROUP_PAPP);
			params.set("key", pizzaKey);
//			params.set("optype", "add");
			params.set("projectId", form.getProjectId());
			params.set("value", ivyXmlContent);
			ServiceResults result = pizzaSaveConfigService.invoke(params);
			
			String responseCode = result.getString("responseCode");
			String cause = result.getString("cause");
			String msg = result.getString("msg");
			boolean success = responseCode.equals(SARManagerConstants.RESPONSECODE_ZERO);
			if (success) {
				model.put("success", success);
				model.put("xmlContent", ivyXmlContent);
				model.setResponseMsg(msg);
			} else {
				model.setResponseCode("1");
				model.setResponseMsg(cause);
			}
		} catch (DocumentException e) {
			logger.error("ivy.xml文件解析错误！", e);
			model.setResponseCode("1");
			model.setResponseMsg("ivy.xml文件解析错误！");
		} catch (IOException e) {
			logger.error("ivy.xml文件创建错误！", e);
			model.setResponseCode("1");
			model.setResponseMsg("ivy.xml文件创建错误！");
		} catch (Exception e) {
			logger.error("系统异常！", e);
			model.setResponseCode("1");
			model.setResponseMsg("系统异常！");
		}
		
		return model;
	}
	
	@ResponseBody
	@RequestMapping("/papp/relyConfig-update.do")
	public ResponseModel eidtRelyConfig(IvyDenpendencyConfigDTO form) {
		if(logger.isInfoEnabled()){
			logger.info("edit,items=" + JSON.toJSONString(form));
		}
		
		ResponseModel model = new ResponseModel();
		String ivyXmlContent = form.getXmlContent();
		logger.info("ivyXmlContent = " + ivyXmlContent);
		
		if (!StringUtils.isBlank(ivyXmlContent)) {
			DependencyDTO dependency = new DependencyDTO();
			dependency.setOrg(form.getOrg());
			dependency.setModule(form.getModule());
			dependency.setOldOrg(form.getOldOrg());
			dependency.setOldModule(form.getOldModule());
			dependency.setVersion(form.getVersion());
			
			try {
				ivyXmlContent = modifyRelyConfig(ivyXmlContent, dependency, "edit");
				logger.info("ivyXmlContent = " + ivyXmlContent);
				
				String pizzaKey = form.getPappName() + "." + Constants.IVY_XML;
				
//				ServiceParams params = ServiceParams.newInstance();
//				params.set("group", PizzaConstants.GROUP_PAPP);
//				params.set("key", pizzaKey);
//				params.set("content", ivyXmlContent);
//				ServiceResults result = pizzaClient.invoke(params);
				
				// 保存配置信息
				ServiceParams params = ServiceParams.newInstance().set("group", PizzaConstants.GROUP_PAPP);
				params.set("key", pizzaKey);
				params.set("projectId", form.getProjectId());
				params.set("value", ivyXmlContent);
				ServiceResults result = pizzaSaveConfigService.invoke(params);
				
				String responseCode = result.getString("responseCode");
				String cause = result.getString("cause");
				String msg = result.getString("msg");
				boolean success = responseCode.equals(SARManagerConstants.RESPONSECODE_ZERO);
				if (success) {
					model.put("success", success);
					model.put("xmlContent", ivyXmlContent);
					model.setResponseMsg(msg);
				} else {
					model.setResponseCode("1");
					model.setResponseMsg(cause);
				}
			} catch (DocumentException e) {
				logger.error("ivy.xml文件解析错误！", e);
				model.setResponseCode("1");
				model.setResponseMsg("ivy.xml文件解析错误！");
			} catch (IOException e) {
				logger.error("ivy.xml文件创建错误！", e);
				model.setResponseCode("1");
				model.setResponseMsg("ivy.xml文件创建错误！");
			} catch (Exception e) {
				logger.error("系统异常！", e);
				model.setResponseCode("1");
				model.setResponseMsg("系统异常！");
			}
		}
		
		return model;
	}
	
	@ResponseBody
	@RequestMapping("/papp/relyConfig-del.do")
	public ResponseModel delRelyConfig(@RequestParam(value="pappName", required=true) String pappName,
			@RequestParam(value="projectId", required=true) String projectId,
			@RequestParam(value="ivyXmlContent", required=true) String ivyXmlContent,
			@RequestParam(value="org", required=true) String org, 
			@RequestParam(value="module", required=true) String module, 
			@RequestParam(value="version", required=true) String version) {
		
		if (logger.isInfoEnabled()) {
			logger.info("del,ivyXmlContent=" + ivyXmlContent + "");
		}
		
		ResponseModel model = new ResponseModel();
		if (!StringUtils.isBlank(ivyXmlContent)) {
			DependencyDTO dependency = new DependencyDTO();
			dependency.setOrg(org);
			dependency.setModule(module);
			dependency.setVersion(version);
			
			try {
				ivyXmlContent = modifyRelyConfig(ivyXmlContent, dependency, "del");
				logger.info("ivyXmlContent = " + ivyXmlContent);
				
				String pizzaKey = pappName + "." + Constants.IVY_XML;
				
//				ServiceParams params = ServiceParams.newInstance();
//				params.set("group", PizzaConstants.GROUP_PAPP);
//				params.set("key", pizzaKey);
//				params.set("content", ivyXmlContent);
//				ServiceResults result = pizzaClient.invoke(params);
				
				// 保存配置信息
				ServiceParams params = ServiceParams.newInstance().set("group", PizzaConstants.GROUP_PAPP);
				params.set("key", pizzaKey);
				params.set("projectId", projectId);
				params.set("value", ivyXmlContent);
				ServiceResults result = pizzaSaveConfigService.invoke(params);
				
				String responseCode = result.getString("responseCode");
				String cause = result.getString("cause");
				String msg = result.getString("msg");
				boolean success = responseCode.equals(SARManagerConstants.RESPONSECODE_ZERO);
				if (success) {
					model.put("success", success);
					model.put("xmlContent", ivyXmlContent);
					model.setResponseMsg(msg);
				} else {
					model.setResponseCode("1");
					model.setResponseMsg(cause);
				}
			} catch (DocumentException e) {
				logger.error("ivy.xml文件解析错误！", e);
				model.setResponseCode("1");
				model.setResponseMsg("ivy.xml文件解析错误！");
			} catch (IOException e) {
				logger.error("ivy.xml文件构建错误！", e);
				model.setResponseCode("1");
				model.setResponseMsg("ivy.xml文件构建错误！");
			} catch (Exception e) {
				logger.error("系统异常！", e);
				model.setResponseCode("1");
				model.setResponseMsg("系统异常！");
			}
		}
		
		return model;
	}
	
	private List<DependencyDTO> parserXML(String XMLContent) throws DocumentException {
		Document document = DocumentHelper.parseText(XMLContent);
        Element root = document.getRootElement();
        List<Element> rootChilds = root.elements();
        Element dependenciesElement = null;
        for (Element element : rootChilds) {
			String name = element.getName();
			if (name.equalsIgnoreCase("dependencies")) {
				dependenciesElement = element;
				break;
			}
		}
        
        List<DependencyDTO> dependencys = new ArrayList<DependencyDTO>();
        if (dependenciesElement != null) {
	        List<Element> dependenciesChilds = dependenciesElement.elements();
	        
	        for (Element dependencyElement : dependenciesChilds) {
	        	DependencyDTO dependency = new DependencyDTO();
	        	
	        	dependency.setOrg(dependencyElement.attribute("org").getText());
	        	dependency.setModule(dependencyElement.attribute("name").getText());
	        	dependency.setVersion(dependencyElement.attribute("rev").getText());
	        	
	        	dependencys.add(dependency);
			}
        }
        
        return dependencys;
	}
	
	private String modifyRelyConfig(String XMLContent, DependencyDTO dependency, String opt) throws DocumentException, IOException {
		Document document = null;
		Element root = null;
		Element dependenciesElement = null;
		if (StringUtils.isBlank(XMLContent)) {
			document = DocumentFactory.getInstance().createDocument();
			root = document.addElement("ivy-module");
			root.addAttribute("version", "2.0");
			
			dependenciesElement = root.addElement("dependencies");
		} else {
			document = DocumentHelper.parseText(XMLContent);
	        root = document.getRootElement();
	        List<Element> rootChilds = root.elements();
	        for (Element element : rootChilds) {
				String name = element.getName();
				if (name.equalsIgnoreCase("dependencies")) {
					dependenciesElement = element;
					break;
				}
			}
		}
        
        Element newDependencyElement = null;
        List<Element> dependenciesChilds = null;
        if (dependenciesElement != null) {
        	
        	if (opt.equals("add")) {
        		newDependencyElement = DocumentHelper.createElement("dependency");
        		newDependencyElement.addAttribute("org", dependency.getOrg());
        		newDependencyElement.addAttribute("name", dependency.getModule());
        		newDependencyElement.addAttribute("rev", dependency.getVersion());
	        	dependenciesElement.add(newDependencyElement);
        	} else {
        		dependenciesChilds = dependenciesElement.elements();
    	        
        		String org = null;
        		String name = null;
    	        for (Element dependencyElement : dependenciesChilds) {
    	        	org = dependencyElement.attributeValue("org");
    	        	name = dependencyElement.attributeValue("name");
    	        	
    	        	if (opt.equals("del")) {
    	        		if (org.equals(dependency.getOrg()) && name.equals(dependency.getModule())) {
    	        			dependenciesElement.remove(dependencyElement);
    	        		}
    	        	} else if (opt.equals("edit")) {
    	        		if (org.equals(dependency.getOldOrg()) && name.equals(dependency.getOldModule())) {
    	        			dependencyElement.attribute("org").setValue(dependency.getOrg());
    	        			dependencyElement.attribute("name").setValue(dependency.getModule());
    	        			dependencyElement.attribute("rev").setValue(dependency.getVersion());
    	        		}
    	        	} else {
    	        		// do nothing
    	        	}
    			}
        	}
        }
        
        StringWriter writer = new StringWriter();
        OutputFormat out = OutputFormat.createPrettyPrint();
        XMLWriter xmlWriter = new XMLWriter(writer, out);
        xmlWriter.write(document);
        
        return document.asXML();
	}
	
	public IServiceClient getClient() {
		return client;
	}

	public void setClient(IServiceClient client) {
		this.client = client;
		Multimap<String, String> m =ArrayListMultimap.create();
	}
}