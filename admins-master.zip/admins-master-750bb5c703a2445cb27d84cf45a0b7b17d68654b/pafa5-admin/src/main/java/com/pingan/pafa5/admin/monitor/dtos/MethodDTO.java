package com.pingan.pafa5.admin.monitor.dtos;

public class MethodDTO {
	
	private String id;
	
	private String creatTime;
	
	private String update;
	
	private String methodName;
	
	private String nodeHost;
	//类型consumer provider
	private String type;
	//成功次数
	private int success;
	//失败次数
	private int failure;
	//总耗时
	private int elapsed;
	//最大耗时
	private int maxelapsed;
	//最小耗时
	private int minelapsed;
	//平均耗时
	private int avgelapsed;
	//调用总次数
	private int concurrent;
	//最大连接数
	private int maxconcurrent;
	private String service;
	//应用名称
	private String application;
    
	private String unique;
    
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
	public String getUnique() {
		return unique;
	}

	public void setUnique(String unique) {
		this.unique = unique;
	}

	public int getMinelapsed() {
		return minelapsed;
	}

	public void setMinelapsed(int minelapsed) {
		this.minelapsed = minelapsed;
	}

	public int getAvgelapsed() {
		return avgelapsed;
	}

	public void setAvgelapsed(int avgelapsed) {
		this.avgelapsed = avgelapsed;
	}

	public int getConcurrent() {
		return concurrent;
	}

	public void setConcurrent(int concurrent) {
		this.concurrent = concurrent;
	}

	public String getApplication() {
		return application;
	}

	public void setApplication(String application) {
		this.application = application;
	}

	public String getService() {
		return service;
	}

	public void setService(String service) {
		this.service = service;
	}

	public String getUpdate() {
		return update;
	}

	public void setUpdate(String update) {
		this.update = update;
	}

	public int getElapsed() {
		return elapsed;
	}

	public void setElapsed(int elapsed) {
		this.elapsed = elapsed;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public int getSuccess() {
		return success;
	}

	public void setSuccess(int success) {
		this.success = success;
	}

	public int getFailure() {
		return failure;
	}

	public void setFailure(int failure) {
		this.failure = failure;
	}

	public int getMaxelapsed() {
		return maxelapsed;
	}

	public void setMaxelapsed(int maxelapsed) {
		this.maxelapsed = maxelapsed;
	}

	public int getMaxconcurrent() {
		return maxconcurrent;
	}

	public void setMaxconcurrent(int maxconcurrent) {
		this.maxconcurrent = maxconcurrent;
	}

	public MethodDTO() {
		super();
	}

	public String getCreatTime() {
		return creatTime;
	}

	public void setCreatTime(String creatTime) {
		this.creatTime = creatTime;
	}

	public String getMethodName() {
		return methodName;
	}

	public void setMethodName(String methodName) {
		this.methodName = methodName;
	}

	public String getNodeHost() {
		return nodeHost;
	}

	public void setNodeHost(String nodeHost) {
		this.nodeHost = nodeHost;
	}


}
