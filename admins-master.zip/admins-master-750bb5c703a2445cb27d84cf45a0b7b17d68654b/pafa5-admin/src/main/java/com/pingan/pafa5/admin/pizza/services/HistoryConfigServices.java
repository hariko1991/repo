package com.pingan.pafa5.admin.pizza.services;

import java.util.List;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSearchDTO;
import com.pingan.pafa5.admin.pizza.dto.PizzaConfigHistoryDTO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigHistoryPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigHistoryValuePO;

/**
 * 资源中心-历史记录
 * @author ZHANGJIAWEI370
 *
 */
public interface HistoryConfigServices {

    /**
     * 查询历史记录列表
     * @param searchDTO
     * @return
     */
    PageDataDTO<PizzaConfigHistoryPO> search(ConfigSearchDTO searchDTO);
    
    /**
     * 保存历史记录
     * @param dto
     * @return
     */
    void save(PizzaConfigHistoryDTO dto);

    /**
     * 获取历史记录
     * @param group
     * @param key
     * @param createDate
     * @return
     */
    PizzaConfigHistoryPO get(String group, String key, long createDate);

    /**
     * 获取历史记录
     * @param historyId
     * @return
     */
    PizzaConfigHistoryPO getById(String historyId);

    /**
     * 获取历史记录内容
     * @param historyId
     * @return
     */
    PizzaConfigHistoryValuePO getValueById(String historyId);

    /**
     * 恢复历史记录
     * @param historyId
     * @return
     */
    boolean recovery(String historyId) throws Exception;
    /**
     * 获取历史历史记录
     * @param dto
     * @return
     */

	List<PizzaConfigHistoryPO> search(String proId, String group,
			String key, String string);
	/**
     * 删除历史记录、与内容
     * @param dto
     * @return
     */
	public boolean cleanUpRecord(String cleanBeforeThisTime, String projectId/*, int recordNum*/);
	
	/**
     * 获得久远的历史记录条目
     * @param dto
     * @return
     */
	public long getRecordNum(String cleanBeforeThisTime, String projectId);

}
