package com.pingan.pafa5.admin.fling.services;

import com.pingan.pafa.fling.msg.FlingCommandMsg;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa5.admin.fling.dto.FlingCommandResultsDTO;
import com.pingan.pafa5.admin.fling.form.SendCommandForm;

public interface FlingCommandServices {

    /**
     * 查询指令结果
     * @param commandId
     * @return
     */
	FlingCommandResultsDTO getResults(String commandId);
	
	/**
	 * 发送指令
	 * @param msg
	 * @param form
	 * @return
	 */
	String sendCommand(FlingCommandMsg msg, SendCommandForm form);
	
	/**
	 * 删除15天前数据
	 * @return
	 */
	boolean delete15DaysBefore();
	
	ResponseModel checkSarExist(FlingCommandMsg msg, SendCommandForm form) throws Exception;
	
}
