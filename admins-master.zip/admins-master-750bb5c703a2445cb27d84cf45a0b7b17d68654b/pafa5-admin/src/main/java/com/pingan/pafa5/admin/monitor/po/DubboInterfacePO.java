package com.pingan.pafa5.admin.monitor.po;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="dubbo_interface")
public class DubboInterfacePO {
    
    @Id
    private String id;

    // 应用/组件名称
    private String applicationName;

    // 接口名
    private String interfaceName;

    // 方法名
    private String methodName;
    
    // 类型consumer/provider
    private String type;

    // 成功次数
    private int success;

    // 失败次数
    private int failure;
    
    // 总次数
    private int total;

    // 总耗时
    private int elapsed;
    
    // 平均耗时
    private int avgElapsed;

    // 最大耗时
    private int maxElapsed;
    
    // 最小并发数
    private int minConcurrent;

    // 最大并发数
    private int maxConcurrent;
    
    // 数据时间
    @Indexed
    private Date updateTime;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getApplicationName() {
        return applicationName;
    }

    public void setApplicationName(String applicationName) {
        this.applicationName = applicationName;
    }

    public String getInterfaceName() {
        return interfaceName;
    }

    public void setInterfaceName(String interfaceName) {
        this.interfaceName = interfaceName;
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getSuccess() {
        return success;
    }

    public void setSuccess(int success) {
        this.success = success;
    }

    public int getFailure() {
        return failure;
    }

    public void setFailure(int failure) {
        this.failure = failure;
    }

    public int getTotal() {
        return total;
    }

    public void setTotal(int total) {
        this.total = total;
    }

    public int getElapsed() {
        return elapsed;
    }

    public void setElapsed(int elapsed) {
        this.elapsed = elapsed;
    }

    public int getAvgElapsed() {
        return avgElapsed;
    }

    public void setAvgElapsed(int avgElapsed) {
        this.avgElapsed = avgElapsed;
    }

    public int getMaxElapsed() {
        return maxElapsed;
    }

    public void setMaxElapsed(int maxElapsed) {
        this.maxElapsed = maxElapsed;
    }

    public int getMinConcurrent() {
        return minConcurrent;
    }

    public void setMinConcurrent(int minConcurrent) {
        this.minConcurrent = minConcurrent;
    }

    public int getMaxConcurrent() {
        return maxConcurrent;
    }

    public void setMaxConcurrent(int maxConcurrent) {
        this.maxConcurrent = maxConcurrent;
    }

    public Date getUpdateTime() {
        return updateTime;
    }

    public void setUpdateTime(Date updateTime) {
        this.updateTime = updateTime;
    }
    
}
