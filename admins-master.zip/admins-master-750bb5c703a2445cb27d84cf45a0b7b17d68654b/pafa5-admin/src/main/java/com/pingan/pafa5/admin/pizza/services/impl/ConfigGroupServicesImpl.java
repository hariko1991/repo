package com.pingan.pafa5.admin.pizza.services.impl;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.springframework.stereotype.Service;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa5.admin.pizza.po.ConfigGroupPO;
import com.pingan.pafa5.admin.pizza.services.ConfigGroupServices;

@Service
public class ConfigGroupServicesImpl extends BaseServices implements ConfigGroupServices {

    // 分组数据
    public static Map<String, ConfigGroupPO> groups = new LinkedHashMap<String, ConfigGroupPO>();
    
    public ConfigGroupServicesImpl() {
        ConfigGroupPO cfvo = null;
        cfvo = new ConfigGroupPO("papp", "应用配置");
        groups.put(cfvo.getGroupCode(), cfvo);
        cfvo = new ConfigGroupPO("sar", "业务组件配置");
        groups.put(cfvo.getGroupCode(), cfvo);
        cfvo = new ConfigGroupPO("esa", "微服务配置");
        groups.put(cfvo.getGroupCode(), cfvo);
        cfvo = new ConfigGroupPO("lib", "依赖包仓库", true);
        groups.put(cfvo.getGroupCode(), cfvo);
        cfvo = new ConfigGroupPO("zip", "Zip文件仓库", true);
        groups.put(cfvo.getGroupCode(), cfvo);
        cfvo = new ConfigGroupPO("patddl", "TDDL配置");
        groups.put(cfvo.getGroupCode(), cfvo);
        cfvo = new ConfigGroupPO("datasource", "数据源配置");
        groups.put(cfvo.getGroupCode(), cfvo);
        cfvo = new ConfigGroupPO("mongodb", "MongoDB配置");
        groups.put(cfvo.getGroupCode(), cfvo);
        cfvo = new ConfigGroupPO("redis", "Redis配置");
        groups.put(cfvo.getGroupCode(), cfvo);      
        cfvo = new ConfigGroupPO("def", "默认配置");
        groups.put(cfvo.getGroupCode(), cfvo);
        cfvo = new ConfigGroupPO("globalvars", "全局变量", false, true);
        groups.put(cfvo.getGroupCode(), cfvo);
        cfvo = new ConfigGroupPO("resources", "组件资源文件", true, true);
        groups.put(cfvo.getGroupCode(), cfvo);
    }

    @Override
    public Set<String> getGroupNames() {
        return groups.keySet();
    }

    public String getGroupName(String group) {
        return getGroup(group).getGroupName();
    }

    public ConfigGroupPO getGroup(String group) {
        if (group == null || (group = group.trim()).length() == 0) {
            throw new NullPointerException("Group is null.");
        }
        ConfigGroupPO groupDTO = groups.get(group);
        if (groupDTO == null) {
            throw new IllegalArgumentException("配置组:" + group + "不存在。");
        }
        return groupDTO;
    }

    @Override
    public List<ConfigGroupPO> listAll() {
        return list(true, true);
    }

    public List<ConfigGroupPO> list(boolean includeBinaryGroup) {
        return list(includeBinaryGroup, false);
    }

    @Override
    public List<ConfigGroupPO> list(boolean includeBinaryGroup, boolean includeHideGroup) {
        List<ConfigGroupPO> datas = new ArrayList<ConfigGroupPO>();
        for (ConfigGroupPO po : groups.values()) {
            boolean isInclude = true;
            if (po.isBinary() && !includeBinaryGroup) {
                isInclude = false;
            }
            if (po.isHide() && !includeHideGroup) {
                isInclude = false;
            }
            if (isInclude) {
                datas.add((ConfigGroupPO) po.clone());
            }                
        }
        return datas;
    }

}
