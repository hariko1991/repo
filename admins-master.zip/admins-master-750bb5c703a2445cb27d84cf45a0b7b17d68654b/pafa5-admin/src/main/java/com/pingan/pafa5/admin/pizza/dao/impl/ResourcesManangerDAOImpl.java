package com.pingan.pafa5.admin.pizza.dao.impl;

import java.util.List;

import com.pingan.pafa5.admin.commons.Nosql;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Component;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.pizza.dao.ResourcesManangerDAO;
import com.pingan.pafa5.admin.pizza.po.ResourceFilePO;
import org.springframework.stereotype.Repository;

@Nosql
@Repository
public class ResourcesManangerDAOImpl extends BaseMongoDAO<ResourceFilePO> implements ResourcesManangerDAO {

	@Override
	public ResourceFilePO getById(String id) {
		return this._getById(id);
	}

	@Override
	public void add(ResourceFilePO po) {
		this._add(po);
	}

	@Override
	public boolean update(ResourceFilePO po) {
		return this._updateById(po.getId(), po);
	}

	@Override
	public boolean delete(ResourceFilePO po) {
		return this._removeById(po.getId());
	}

	@Override
	public List<ResourceFilePO> list(String sarName, int limit, int page) {
		Criteria criteria = null;
		if (sarName != null && !"".equals(sarName)) {
			criteria = where("sarName").is(sarName);
		}
		int skip = (page - 1) * limit;
		return this._list(criteria, skip, limit);
	}

	@Override
	public long getCount(String sarName) {
		Criteria criteria = null;
		if (sarName != null && !"".equals(sarName)) {
			criteria = where("sarName").is(sarName);
		}
		return this._count(criteria);
	}

}
