package com.pingan.pafa5.admin.fling.services.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.fling.dao.DruidDatasourceDAO;
import com.pingan.pafa5.admin.fling.dao.DruidSqlDAO;
import com.pingan.pafa5.admin.fling.po.DruidDatasourcePO;
import com.pingan.pafa5.admin.fling.po.DruidSqlPO;
import com.pingan.pafa5.admin.fling.services.DruidMonitorService;

@Service("druidMonitorService")
public class DruidMonitorServiceImpl extends BaseServices implements
		DruidMonitorService {
	
	@Autowired
	private DruidDatasourceDAO druidDatasourceDAO;
	
	@Autowired
	private DruidSqlDAO druidSqlDAO;
	
	@Override
	public DruidDatasourcePO getDataSourceById(String id, int identify) {
		return druidDatasourceDAO.getDruidDatasourceById(id, identify);
	}


	@Override
	public PageDataDTO<DruidSqlPO> listForSql(String druidDatasourceId, int identify, int limit, int page) {
		
		PageDataDTO<DruidSqlPO> datas = new PageDataDTO<DruidSqlPO>();
		
		if(page <= 0){
        	page = 0;
        }else{
        	page = page -1;
        }
        
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("druidDatasourceId", druidDatasourceId);
		map.put("identify", identify);
		map.put("page", page * limit);
		map.put("limit", limit);
		
		List<DruidSqlPO> pos = this.druidSqlDAO.list(map);
		long totalCount = this.druidSqlDAO.getDruidSqlCount(map);
		datas.setDatas(pos);
		datas.setTotalSize(totalCount);
		
		return datas;
	}

	


	@Override
	public PageDataDTO<DruidDatasourcePO> listForDatasource(String domainId, String pappName, int limit, int page) {
		PageDataDTO<DruidDatasourcePO> pageDataDTO = new PageDataDTO<DruidDatasourcePO>();
		if(page <= 0){
        	page = 0;
        }else{
        	page = page -1;
        }
        
        Map<String,Object> map = new HashMap<String,Object>();
        map.put("domainId", domainId);
		map.put("pappName", pappName);
		map.put("page", page * limit);
		map.put("limit", limit);
		
		List<DruidDatasourcePO> pos= druidDatasourceDAO.list( map);
		pageDataDTO.setDatas(pos);
		
		long totalSize = druidDatasourceDAO.getCount(map);
		pageDataDTO.setTotalSize(totalSize);
		
		return pageDataDTO;
	}




}
