package com.pingan.pafa5.admin.pizza.po;

import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 资源中心-全局资源内容
 * @author ZHANGJIAWEI370
 *
 */
@Document
public class PizzaConfigValuePO {

    @org.springframework.data.annotation.Id
    private String id;
    
    private String pizzaValue;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPizzaValue() {
        return pizzaValue;
    }

    public void setPizzaValue(String pizzaValue) {
        this.pizzaValue = pizzaValue;
    }
    
}
