package com.pingan.pafa5.admin.pizza.dao;

import java.util.List;

import com.pingan.pafa5.admin.pizza.po.PizzaRecoveryRegisterLogPo;

public interface PizzaRecoveryRegisterLogDAO {
	void saveErrorLog(PizzaRecoveryRegisterLogPo recoveryRegisterLogPo);
	
	void deleteErrorLog(String projectId);
	
	List<PizzaRecoveryRegisterLogPo> getErrorLogs(String logId,String projectId);
}
