package com.pingan.pafa5.admin.papp.services.impl;

import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa.pizza.PizzaConstants;
import com.pingan.pafa5.admin.Constants;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.commons.PizzaManagerHolder;
import com.pingan.pafa5.admin.papp.dao.GardenPizzaConfigDAO;
import com.pingan.pafa5.admin.papp.services.GardenPizzaConfigServices;
import com.pingan.pafa5.admin.pizza.PizzaConstants.ConfigHistoryOperationType;
import com.pingan.pafa5.admin.pizza.PizzaConstants.VersionOperationType;
import com.pingan.pafa5.admin.pizza.dao.FileTempDAO;
import com.pingan.pafa5.admin.pizza.dao.IvyLibConfigDAO;
import com.pingan.pafa5.admin.pizza.dao.PizzaConfigDAO;
import com.pingan.pafa5.admin.pizza.dao.PizzaConfigValueDAO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSaveDTO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSearchDTO;
import com.pingan.pafa5.admin.pizza.dto.PizzaConfigHistoryDTO;
import com.pingan.pafa5.admin.pizza.form.PizzaConfigForm;
import com.pingan.pafa5.admin.pizza.po.ConfigGroupPO;
import com.pingan.pafa5.admin.pizza.po.FileTempPO;
import com.pingan.pafa5.admin.pizza.po.IvyLibConfigPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigHistoryPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigValuePO;
import com.pingan.pafa5.admin.pizza.services.ConfigGroupServices;
import com.pingan.pafa5.admin.pizza.services.HistoryConfigServices;
import com.pingan.pafa5.admin.pizza.services.PizzaConfigServices;
import com.pingan.pafa5.admin.pizza.utils.ConfigContentUtils;
import com.pingan.pafa5.admin.sso.CacheData;
import com.pingan.pafa5.admin.sso.UserPrincipal;
import com.pingan.um.client.util.StringUtil;

@Service
public class GardenPizzaConfigServicesImpl extends BaseServices implements
		GardenPizzaConfigServices {

	@Autowired
	private GardenPizzaConfigDAO pizzaConfigDAO;

	

	

	@Override
	public List<String> listKeys(String proId, String group,
			String pizzaKeyRegex) {
		if (group == null || (group = group.trim()).length() == 0) {
			throw new NullPointerException("group is null.");
		}
		if (proId.equalsIgnoreCase("def")) {
			return pizzaConfigDAO.listKeys(group, pizzaKeyRegex);
		}
		return pizzaConfigDAO.listKeys(proId, group, pizzaKeyRegex);
	}

	@Override
	public List<String> listKeys(String domainId, String group) {
		return listKeys(domainId, group, null);
	}

	

}
