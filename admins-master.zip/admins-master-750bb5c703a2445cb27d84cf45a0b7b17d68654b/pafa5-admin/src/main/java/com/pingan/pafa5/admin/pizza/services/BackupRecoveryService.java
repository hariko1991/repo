package com.pingan.pafa5.admin.pizza.services;

import java.util.List;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dto.OperationLogSearchDTO;
import com.pingan.pafa5.admin.pizza.po.PizzaOperationLogPO;
import com.pingan.pafa5.admin.pizza.po.PizzaRecoveryRegisterLogPo;

/**
 * 备份与恢复
 * @author ZHANGJIAWEI370
 *
 */
public interface BackupRecoveryService {
    
    public static final String LOCK_OBJ_ID = "pizza-backup-recovery";//分布式锁ID

    /**
     * 查询操作记录
     * 
     * @param queryDTO
     * @return
     */
    public PageDataDTO<PizzaOperationLogPO> search(OperationLogSearchDTO queryDTO);

    /**
     * 备份资源数据库
     * 
     * @param targetDomainId
     * @param targetDomainName
     * @param operationReason
     * @return
     */
    public String backup(String targetDomainId, String targetDomainName, String operationReason);

    /**
     * 回滚资源数据库
     * 
     * @param referOperationId
     * @param operationReason
     * @return
     */
    public String rollback(String referOperationId, String operationReason);

    /**
     * 恢复配置中心
     * 
     * @param operationReason
     */
    public void recoveryRegister(String targetDomainId, String targetDomainName, String operationReason);

    public List<PizzaRecoveryRegisterLogPo> getErrorLog(String logId,String projectId);
    
    /**
     * 根据文件数量确保业务结果的状态显示正确
     * 
     * @param operationReason
     */
	public boolean checkStatus(String projectId,String versionId);

}
