package com.pingan.pafa5.admin;

import java.util.Arrays;
import java.util.List;

/**
 * @see pafa admin 常量类
 * @author JIECHANGKE805
 * @date 2016-05-03
 * 
 */
public class Constants {

    /**
     * 资源组-依赖包仓库
     */
    public static final String LIB_GROUP = "lib";
    /**
     * 非文本文件
     */
    public static final List<String> NOT_TEXT_FILE = Arrays.asList("jar", "zip", "rar", "war",
            "JAR", "ZIP", "RAR", "WAR");

    /**
     * 文件类型 xml
     */
    public static final String FILE_TYPE_XML = "xml";
    /**
     * 文件类型 jar
     */
    public static final String FILE_TYPE_JAR = "jar";
    /**
     * ivyconf.xml文件名
     */
    public static final String IVY_CONF_XML = "ivyconf.xml";
    /**
     * ivy.xml
     */
    public static final String IVY_XML = "ivy.xml";
    /**
     * ivy.xml路径定义的pattern
     */
    public static final String IVY_PATTERN = "/[organization]/[module]/[revision]/ivy.xml";
    /**
     * artifact路径定义pattern
     */
    public static final String ARTIFACT_PATTERN =
            "/[organization]/[module]/[revision]/[artifact].[ext]";
    /**
     * 待审批
     */
    public static final String WAITING_FOR_APPROVE = "waiting for approve";
    /**
     * 审批完成
     */
    public static final String APPROVED = "approved";
    
    /**
     * 默认领域def
     */
    public static final String DOMAIN_ID_DEF="def";
    public static final String DOMAIN_NAME_DEF="默认的";

    /**
     * 菜单类型
     */
    public class MenuType {
        public static final int PAGE = 1; // 页面
        public static final int BUTTON = 2; // 按钮
    }

    /**
     * 用户状态
     */
    public class UserStatus {
        public static final int NOT_APPROVED = -1; // 未审批
        public static final int ENABLE = 0; // 正常
        public static final int DISABLE = 1; // 禁用
    }

    /**
     * 是否管理员
     */
    public class AdminStatus {
        public static final int YES = 1; // 是
        public static final int NO = 0; // 否
    }

    public static final int HEARTBEAT_TIMEOUT = 3;

}
