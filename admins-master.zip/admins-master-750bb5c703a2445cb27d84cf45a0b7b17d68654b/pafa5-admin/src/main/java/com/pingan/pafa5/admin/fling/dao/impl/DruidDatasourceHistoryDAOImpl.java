package com.pingan.pafa5.admin.fling.dao.impl;

import java.util.Date;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.fling.dao.DruidDatasourceHistoryDAO;
import com.pingan.pafa5.admin.fling.po.DruidDatasourceHistoryPO;
@Nosql
@Repository
public class DruidDatasourceHistoryDAOImpl extends BaseMongoDAO<DruidDatasourceHistoryPO> implements DruidDatasourceHistoryDAO{

	@Override
	public void add(DruidDatasourceHistoryPO po) {
		// TODO Auto-generated method stub
		this._add(po);
	}

	@Override
	public long getCountByDate(Date createdDate) {
		// TODO Auto-generated method stub
		Criteria criteria =this.where("createdDate").lt(createdDate);
		return this._count(criteria);
	}

	@Override
	public int removeByDate(Date createdDate) {
		// TODO Auto-generated method stub
		Criteria criteria =this.where("createdDate").lt(createdDate);
		return this._remove(criteria);
	}

}
