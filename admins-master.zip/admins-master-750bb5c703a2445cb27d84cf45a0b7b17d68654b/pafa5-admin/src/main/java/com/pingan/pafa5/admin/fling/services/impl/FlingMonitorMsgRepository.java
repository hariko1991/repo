package com.pingan.pafa5.admin.fling.services.impl;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.fling.monitor.MonitorMsgRepository;
import com.pingan.pafa.fling.monitor.dtos.MonitorMsgDTO;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.fling.dao.FlingPappInstanceDAO;
import com.pingan.pafa5.admin.fling.dao.FlingPappMonitorMsgDAO;
import com.pingan.pafa5.admin.fling.dao.FlingPappStatusMonitorMsgDAO;
import com.pingan.pafa5.admin.fling.dao.FlingSARInstanceDAO;
import com.pingan.pafa5.admin.fling.dao.FlingSARMonitorMsgDAO;
import com.pingan.pafa5.admin.fling.dao.FlingWarnDAO;
import com.pingan.pafa5.admin.fling.po.FlingPappInstancePO;
import com.pingan.pafa5.admin.fling.po.FlingPappMonitorMsgPO;
import com.pingan.pafa5.admin.fling.po.FlingPappStatusMonitorMsgPO;
import com.pingan.pafa5.admin.fling.po.FlingSARInstancePO;
import com.pingan.pafa5.admin.fling.po.FlingSARMonitorMsgPO;
import com.pingan.pafa5.admin.fling.po.FlingWarnPO;

@Service("defMonitorMsgRepository")
public class FlingMonitorMsgRepository extends BaseServices implements MonitorMsgRepository {

    @Autowired
    private FlingSARMonitorMsgDAO flingSARMonitorMsgDAO;

    @Autowired
    private FlingPappMonitorMsgDAO flingPappMonitorMsgDAO;

    @Autowired
    private FlingPappStatusMonitorMsgDAO flingPappStatusMonitorMsgDAO;

    @Autowired
    private FlingPappInstanceDAO flingPappInstanceDAO;

    @Autowired
    private FlingSARInstanceDAO flingSARInstanceDAO;

    @Autowired
    private FlingWarnDAO flingWarnDAO;

    @Override
    public void onMessage(MonitorMsgDTO msg) throws Exception {
        if (logger.isDebugEnabled()) {
            logger.debug("Msg=" + JSONObject.toJSONString(msg));
        }
        if (logger.isInfoEnabled()) {
            logger.info("OnMessage=" + msg.getMsgId() + " for instanceIp:" + msg.getInstanceIp()
                    + ",event:" + msg.getEventName());
        }
        String ename = msg.getEventName();
        if (MonitorMsgDTO.EVENT_SAR_SHUTDOWN.equals(ename)
                || MonitorMsgDTO.EVENT_SAR_STARTUP.equals(ename)) {
            FlingSARMonitorMsgPO po = new FlingSARMonitorMsgPO();
            POUtils.copyProperties(po, msg);
            po.setCreatedTimestamp(System.currentTimeMillis());
            flingSARMonitorMsgDAO.add(po);
            int status = MonitorMsgDTO.EVENT_SAR_SHUTDOWN.equals(msg.getEventName()) ? 1 : 0;
            upsetSARInstance(msg, status);
        } else if (MonitorMsgDTO.EVENT_SAR_STARTUP_FAILURE.equals(ename)) {
            // 告警
            upsetSARInstance(msg, 2);
            reportWarn(msg);
        } else if (MonitorMsgDTO.EVENT_ERROR.equals(ename)) {
            // 告警
            reportWarn(msg);
        } else {
            if (msg.isIncludeInstanceInfo() && msg.getInstanceInfo() != null) {
                FlingPappMonitorMsgPO po = new FlingPappMonitorMsgPO();
                POUtils.copyProperties(po, msg);
                POUtils.copyProperties(po, msg.getInstanceInfo());
                po.setCreatedTimestamp(System.currentTimeMillis());
                flingPappMonitorMsgDAO.add(po);
            }
            if (MonitorMsgDTO.EVENT_HEARTBEAT.equals(ename) && msg.isIncludeStatusInfo()
                    && msg.getInstanceStatus() != null) {
                FlingPappStatusMonitorMsgPO po = new FlingPappStatusMonitorMsgPO();
                POUtils.copyProperties(po, msg);
                POUtils.copyProperties(po, msg.getInstanceStatus());
                po.setCreatedTimestamp(System.currentTimeMillis());
                flingPappStatusMonitorMsgDAO.add(po);
            }
            upsetPappInstance(msg);
        }
    }

    protected void reportWarn(MonitorMsgDTO msg) {
        FlingWarnPO po = new FlingWarnPO();
        if (StringUtils.isNotEmpty(msg.getDomainId())) {
        	po.setProjectId(msg.getDomainId());
        } else if (StringUtils.isNotEmpty(msg.getProjectId())) {
        	po.setProjectId(msg.getProjectId());
        }
        po.setAppName(msg.getAppName());
        po.setBizRequestId(msg.getBizRequestId());
        po.setCreatedTimestamp(System.currentTimeMillis());
        po.setInstanceIp(msg.getInstanceIp());
        po.setWarnSource("FlingMonitor-" + msg.getEventName());
        po.setDescription(msg.getDiscription());
        po.setSarName(msg.getSarName());
        if (logger.isInfoEnabled()) {
            logger.info("AddFlingWarn:" + JSONObject.toJSONString(po));
        }
        flingWarnDAO.add(po);
    }

    protected void upsetSARInstance(MonitorMsgDTO msg, int status) {
        FlingSARInstancePO instance = new FlingSARInstancePO();
        if (StringUtils.isNotEmpty(msg.getDomainId())) {
            instance.setProjectId(msg.getDomainId());
        } else if (StringUtils.isNotEmpty(msg.getProjectId())) {
            instance.setProjectId(msg.getProjectId());
        }
        instance.setSarName(msg.getSarName());
        instance.setAppName(msg.getAppName());
        instance.setInstanceIp(msg.getInstanceIp());
        instance.setStatus(status);
        POUtils.setForUpdate("FlingMonitor-" + msg.getEventName(), instance);
        instance.setLastActiveTimestamp(instance.getUpdatedDate().getTime());
        instance.setLastActiveObjectId(msg.getMsgId());
        flingSARInstanceDAO.upset(instance);
    }

    protected void upsetPappInstance(MonitorMsgDTO msg) {
        FlingPappInstancePO instance = new FlingPappInstancePO();
        if (StringUtils.isNotEmpty(msg.getDomainId())) {
            instance.setProjectId(msg.getDomainId());
        } else if (StringUtils.isNotEmpty(msg.getProjectId())) {
            instance.setProjectId(msg.getProjectId());
        }
        instance.setAppName(msg.getAppName());
        instance.setInstanceIp(msg.getInstanceIp());
        int status = MonitorMsgDTO.EVENT_SHUTDOWN.equals(msg.getEventName()) ? 1 : 0;
        instance.setStatus(status);
        POUtils.setForUpdate("FlingMonitor-" + msg.getEventName(), instance);
        instance.setLastActiveTimestamp(instance.getUpdatedDate().getTime());
        instance.setLastActiveObjectId(msg.getMsgId());
        flingPappInstanceDAO.upset(instance);
    }

    public void setFlingSARMonitorMsgDAO(FlingSARMonitorMsgDAO flingSARMonitorMsgDAO) {
        this.flingSARMonitorMsgDAO = flingSARMonitorMsgDAO;
    }

    public void setFlingPappMonitorMsgDAO(FlingPappMonitorMsgDAO flingPappMonitorMsgDAO) {
        this.flingPappMonitorMsgDAO = flingPappMonitorMsgDAO;
    }

    public void setFlingPappStatusMonitorMsgDAO(
            FlingPappStatusMonitorMsgDAO flingPappStatusMonitorMsgDAO) {
        this.flingPappStatusMonitorMsgDAO = flingPappStatusMonitorMsgDAO;
    }

    public void setFlingPappInstanceDAO(FlingPappInstanceDAO flingPappInstanceDAO) {
        this.flingPappInstanceDAO = flingPappInstanceDAO;
    }

    public void setFlingSARInstanceDAO(FlingSARInstanceDAO flingSARInstanceDAO) {
        this.flingSARInstanceDAO = flingSARInstanceDAO;
    }

    public void setFlingWarnDAO(FlingWarnDAO flingWarnDAO) {
        this.flingWarnDAO = flingWarnDAO;
    }

}
