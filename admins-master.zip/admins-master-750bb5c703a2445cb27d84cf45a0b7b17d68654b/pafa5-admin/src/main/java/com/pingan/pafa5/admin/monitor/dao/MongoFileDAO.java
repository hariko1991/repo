package com.pingan.pafa5.admin.monitor.dao;

import com.mongodb.DBObject;
import com.mongodb.gridfs.GridFSDBFile;
import org.springframework.data.mongodb.core.query.Criteria;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

/**
 * Created by ZHANGWENZHUO810 on 2016-11-14.
 */
public interface MongoFileDAO {
    void insertOrUpdateFile(InputStream content, String filename) throws IOException;
    void insertOrUpdateFileWithMetadata(InputStream content, String filename, DBObject metadata) throws IOException;
    void dumpOneFileToStreamAccordingToFilename(String filename, OutputStream out) throws IOException;
    void dumpOneFileToStreamByCriteria(Criteria criteria, OutputStream out) throws IOException;
    List<GridFSDBFile> dumpFileListByCriteria(Criteria criteria) throws IOException;
    int size(Criteria criteria) throws IOException;
    void deleteOneFileAccordingToFilename(String filename);
    void deleteFilesByCriteria(Criteria criteria);
}
