package com.pingan.pafa5.admin.pizza.po;

import org.springframework.data.mongodb.core.mapping.Document;

import com.pingan.pafa5.admin.commons.BasePO;

/**
 * 资源文件
 * 
 * @author ZHANGGANG871
 * 
 */
@Document
public class ResourceFilePO extends BasePO {

	/**
	 * ResourceKey类的 namespace+"#"+resourceName
	 */
	@org.springframework.data.annotation.Id
	private String id;

	/**
	 * 组件名称
	 */
	private String sarName;

	/**
	 * 文件名称
	 */
	private String fileName;

	/**
	 * 文件DM5
	 */
	private String fileMD5;

	/**
	 * 文件大小
	 */
	private Long size;

	/**
	 * 文件内容
	 */
	private String content;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getSarName() {
		return sarName;
	}

	public void setSarName(String sarName) {
		this.sarName = sarName;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public String getFileMD5() {
		return fileMD5;
	}

	public void setFileMD5(String fileMD5) {
		this.fileMD5 = fileMD5;
	}

	public Long getSize() {
		return size;
	}

	public void setSize(Long size) {
		this.size = size;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

}
