package com.pingan.pafa5.admin.pizza.dto;

public class BackupListenerDTO  implements java.io.Serializable{

private static final long serialVersionUID = 1L;
	
	private String logId;
	
	private String projectId;

	private String versionId;
	
	private String opertype;

	public String getLogId() {
		return logId;
	}

	public void setLogId(String logId) {
		this.logId = logId;
	}

	public String getVersionId() {
		return versionId;
	}

	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}

	public String getOpertype() {
		return opertype;
	}

	public void setOpertype(String opertype) {
		this.opertype = opertype;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	
	
}
