package com.pingan.pafa5.admin.papp.dto;

public class SarDTO {
	
	private String id;
	private String sarName;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getSarName() {
		return sarName;
	}
	public void setSarName(String sarName) {
		this.sarName = sarName;
	}
	
}
