package com.pingan.pafa5.admin.pizza.dto;

import java.util.Date;

public class PizzaConfigHistoryDTO {
    
    /**
     * pizza分组
     */
    private String pizzaGroup;

    /**
     * pizza分组名称
     */
    private String pizzaGroupName;

    /**
     * pizza key
     */
    private String pizzaKey;
    
    private String pizzaValue;

    /**
     *
     */
    private String valueMd5;

    /**
     *
     */
    private Integer valueSize;

    /**
     * 项目id
     */
    private String projectId;

    /**
     * 项目名称
     */
    private String projectName;
    
    /**
     * 操作人
     */
    private String operationUser;

    /**
     * 操作类型
     * <p>
     * 1:修改,2:新增；3:删除；4：同步
     * </p>
     */
    private String operationType;

    /**
     * 操作来源IP
     */
    private String operationIp;

    /**
     * 是否被恢复. y,n
     */
    private String recovery;

    /**
     * 恢复时间
     */
    private Date recoveryDate;

    /**
     * 操作人
     */
    private String recoveryUser;

    public String getPizzaGroup() {
        return pizzaGroup;
    }

    public void setPizzaGroup(String pizzaGroup) {
        this.pizzaGroup = pizzaGroup;
    }

    public String getPizzaGroupName() {
        return pizzaGroupName;
    }

    public void setPizzaGroupName(String pizzaGroupName) {
        this.pizzaGroupName = pizzaGroupName;
    }

    public String getPizzaKey() {
        return pizzaKey;
    }

    public void setPizzaKey(String pizzaKey) {
        this.pizzaKey = pizzaKey;
    }

    public String getPizzaValue() {
        return pizzaValue;
    }

    public void setPizzaValue(String pizzaValue) {
        this.pizzaValue = pizzaValue;
    }

    public String getValueMd5() {
        return valueMd5;
    }

    public void setValueMd5(String valueMd5) {
        this.valueMd5 = valueMd5;
    }

    public Integer getValueSize() {
        return valueSize;
    }

    public void setValueSize(Integer valueSize) {
        this.valueSize = valueSize;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getOperationUser() {
        return operationUser;
    }

    public void setOperationUser(String operationUser) {
        this.operationUser = operationUser;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public String getOperationIp() {
        return operationIp;
    }

    public void setOperationIp(String operationIp) {
        this.operationIp = operationIp;
    }

    public String getRecovery() {
        return recovery;
    }

    public void setRecovery(String recovery) {
        this.recovery = recovery;
    }

    public Date getRecoveryDate() {
        return recoveryDate;
    }

    public void setRecoveryDate(Date recoveryDate) {
        this.recoveryDate = recoveryDate;
    }

    public String getRecoveryUser() {
        return recoveryUser;
    }

    public void setRecoveryUser(String recoveryUser) {
        this.recoveryUser = recoveryUser;
    }

}
