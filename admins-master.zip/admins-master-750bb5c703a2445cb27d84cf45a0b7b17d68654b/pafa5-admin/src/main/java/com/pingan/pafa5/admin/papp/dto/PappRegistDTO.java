package com.pingan.pafa5.admin.papp.dto;


 /**
  * @see 应用注册对象
  * @author JIECHANGKE805
  * @date 2016-06-16
  */
public class PappRegistDTO {
	
	private String pappId;
	
	private String pappName;
	
	private String pappCnName;
	
	private String projectId;
	
	private boolean edit;

	public String getPappId() {
		return pappId;
	}

	public void setPappId(String pappId) {
		this.pappId = pappId;
	}

	public String getPappName() {
		return pappName;
	}

	public void setPappName(String pappName) {
		this.pappName = pappName;
	}
 
	public String getPappCnName() {
		return pappCnName;
	}

	public void setPappCnName(String pappCnName) {
		this.pappCnName = pappCnName;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public boolean isEdit() {
		return edit;
	}

	public void setEdit(boolean edit) {
		this.edit = edit;
	}



}
