package com.pingan.pafa5.admin.pizza.dao;

import java.util.List;

import com.pingan.pafa5.admin.pizza.po.PizzaConfigBackupPO;

public interface PizzaConfigBackupDAO {

	void add(PizzaConfigBackupPO po);
	
	void add(List<PizzaConfigBackupPO> pos);

	long checkCount(String projectId, String versionId);
	
	PizzaConfigBackupPO getById(String proId, String versionId, String pizzaGroup, String pizzaKey);
	
	List<String> listKeys(String proId, String versionId, String pizzaGroup);

	List<String> listKeys(String versionId, String pizzaGroup);

	PizzaConfigBackupPO getById(String versionId, String pizzaGroup,
								String pizzaKey);

	
	//List<PizzaConfigBackupPO> list(String versionId,String pizzaGroup,int limitSize,int beginIndex);
	
	//List<PizzaConfigBackupPO> list(String versionId,String pizzaGroup);
	
	
}
