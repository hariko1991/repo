package com.pingan.pafa5.admin.notify.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class MailParams {

    private String mailTemplate;

    private String subject;

    private List<String> toList = new ArrayList<String>();

    private List<String> ccList = new ArrayList<String>();

    private HashMap<String, Object> context = new HashMap<String, Object>();

    public String getMailTemplate() {
        return mailTemplate;
    }

    public void setMailTemplate(String mailTemplate) {
        this.mailTemplate = mailTemplate;
    }

    public String getSubject() {
        return subject;
    }

    public void setSubject(String subject) {
        this.subject = subject;
    }

    public List<String> getToList() {
        return toList;
    }

    public void setToList(List<String> toList) {
        this.toList = toList;
    }

    public List<String> getCcList() {
        return ccList;
    }

    public void setCcList(List<String> ccList) {
        this.ccList = ccList;
    }

    public HashMap<String, Object> getContext() {
        return context;
    }

    public void setContext(HashMap<String, Object> context) {
        this.context = context;
    }

}
