package com.pingan.pafa5.admin.pizza.web;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.InvocationTargetException;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa5.admin.Constants;
import com.pingan.pafa5.admin.pizza.dto.IvyLibConfigDTO;
import com.pingan.pafa5.admin.pizza.dto.IvyLibWarehouseDTO;
import com.pingan.pafa5.admin.pizza.services.IvyLibWarehouseService;
import com.pingan.pafa5.admin.pizza.services.LibManagerService;
import com.pingan.pafa5.admin.pizza.utils.ConfigContentUtils;

@Controller
public class IvyLibWarehouseController {
	
	private static final Log log = LogFactory.getLog(IvyLibWarehouseController.class);
	
	@Autowired
	private ConfigContentUtils configContentUtils;
	
	@Autowired
	private IvyLibWarehouseService ivyLibService;
	
	@Autowired
	private LibManagerService libManagerService;
	
	@ActionClient(name="pafa5-admin-systems.isOwner")
	private IServiceClient ownerService;
	
	private static final Pattern PATTERN = Pattern.compile("[\u4e00-\u9fa5]");

	/**
	 * @see 上传jar包到ivy仓库
	 * @param projectId : 领域ID
	 * @param org : 组织
	 * @param module : 模块
	 * @param version : 版本 
	 * @return 上传结果
	 * @throws Exception 
	 * @remark 如果传进enable_flag不为Y，则属于无效数据，将被清除
	 */
	@RequestMapping("/ivy/upload.do")
	@ResponseBody
	public ResponseModel uploadLib(IvyLibConfigDTO ivyDTO){
		
		ResponseModel responseModel = new ResponseModel();
		if(checkValid(ivyDTO.getModule())){
			ResponseModel model = new ResponseModel("2410","模块："+ivyDTO.getModule()+" 不合法，不能含有中文。");
			model.put("success", false);
			return model;
		}
		
		if(checkValid(ivyDTO.getOrg())){
			ResponseModel model = new ResponseModel("2411","组织："+ivyDTO.getOrg()+" 不合法，不能含有中文。");
			model.put("success", false);
			return model;
		}
		
		ServiceParams params = new ServiceParams();
		  params.set("groupId", ivyDTO.getProjectId());
	      ServiceResults results = ownerService.invoke(params);
		  boolean isBoo = results.getBool("isowner");
		   if (!isBoo) {
			  responseModel.setResponseCode("2408");
			  responseModel.setResponseMsg("You are not the owner of this domain, can not upload libs.");
			  return responseModel;
			}
		
		if(ivyDTO.getUpload() != null){
			String content = Base64.encodeBase64String(ivyDTO.getUpload().getBytes());
			String md5 = configContentUtils.md5(content);
			String path = ivyLibService.checkExistsAndReturnPath(ivyDTO.getProjectId(), md5);
			if(StringUtils.isNotEmpty(path)){
				responseModel.setResponseCode("2402");
				responseModel.setResponseMsg("Lib is already exist in this project,its path is " + path);
			    return responseModel;
			} 
			
			IvyLibWarehouseDTO ivyLibDTO = new IvyLibWarehouseDTO();
			
			String id = ivyDTO.getProjectId()+"/"+ivyDTO.getOrg()+"/"+ivyDTO.getModule()+"/"+ivyDTO.getVersion();
			try {
				BeanUtils.copyProperties(ivyLibDTO, ivyDTO);
			} catch (IllegalAccessException e) {
				log.info("error occured while copying bean ivyDTO to ivyLibPO, id is : " + id + "cause by : "+e.getMessage());
			} catch (InvocationTargetException e) {
				log.info("error occured while copying bean ivyDTO to ivyLibPO, id is : " + id + "cause by : "+e.getMessage());
			}
			
			 String formattedKey = ivyDTO.getOrg()+"#"+ivyDTO.getModule()+"#"+ivyDTO.getVersion()+"."+Constants.FILE_TYPE_JAR;
			 String ivyXmlBytes = libManagerService.generateIvyXML(formattedKey);
			 
			 ivyLibDTO.setId(id);
			 ivyLibDTO.setIvyXml(ivyXmlBytes);
			 ivyLibDTO.setLibValue(content); 
			 ivyLibDTO.setMd5(md5);
			 ivyLibDTO.setEnableFlag(ivyDTO.getEnableFlag() == null ? "Y" : ivyDTO.getEnableFlag());
			 
			 ivyLibService.saveIvyLib(ivyLibDTO);
			 
			 responseModel.setResponseCode("0");
			 responseModel.setResponseMsg("Save lib in ivy warehouse success.");
			 return responseModel;
			 
		}else{
			responseModel.setResponseCode("2403");
			responseModel.setResponseMsg("You have uploaded an empty file.");
			return responseModel;
		}
		
	}
	
	/**
	 * @see 接收/project/libs/org/module/version/name.jar(ivy.xml)请求，
	 *     返回数据写入response
	 * @param request
	 * @param response
	 * @return 
	 * @throws Exception 
	 */
	@RequestMapping("/{projectId}/libs/{org}/{module}/{version}/*")
	@ResponseBody
	public ModelMap downloadLibFromWarehouse(
			@PathVariable("projectId") String projectId,
			@PathVariable("org") String org,
			@PathVariable("module") String module,
			@PathVariable("version") String version,
			HttpServletRequest request,HttpServletResponse response){
	
		ModelMap rspModel = new ModelMap();
		String[] eles = request.getRequestURI().split("/");
		if(eles == null || eles.length != 8 ){
			rspModel.put("responseCode", "2404");
			rspModel.put("responseMsg", "Illegal request : " + request.getRequestURI());
			return  rspModel;
		}
		
		String id = projectId+"/"+org+"/"+module+"/"+version;
		String reqFile = eles[eles.length-1];
		String ext = reqFile.substring(reqFile.lastIndexOf(".")+1);
		byte[] content = null;
		 
		IvyLibWarehouseDTO ivyLibDTO = ivyLibService.findById(id);
		if(null == ivyLibDTO){
			rspModel.put("responseCode", "2405");
			rspModel.put("responseMsg", "Lib ( "+id+" ) is not exist.");
			return  rspModel;
		}
		if(Constants.FILE_TYPE_JAR.equals(ext)){
			content = Base64.decodeBase64(ivyLibDTO.getLibValue());
			response.setContentType("application/java-archive");
			response.addHeader("Content-Disposition", "attachment;filename=" + ivyLibDTO.getModule()+"-"+ivyLibDTO.getVersion()+"."+ext);
		}else{
			String formattedKey =  org+"#"+module+"#"+version+"."+Constants.FILE_TYPE_JAR;
			try {
				content = libManagerService.generateIvyXML(formattedKey).getBytes("UTF-8");
			} catch (UnsupportedEncodingException e) {
				log.info("UnsupportedEncoding error,detail is : " + e.getMessage());
			}
			response.setContentType("text/xml;charset=UTF-8");
		}
		try {
			response.getOutputStream().write(content);
		} catch (IOException e) {
            log.error("Error occured when writing content to response, detail is: " + e.getMessage());
            rspModel.put("responseCode", "2407");
			rspModel.put("responseMsg", "content write to response error.");
            return rspModel;
		}
		return  null;
	}
	
	public boolean checkValid(String input) {
		return PATTERN.matcher(input).find();
	}
	
}
