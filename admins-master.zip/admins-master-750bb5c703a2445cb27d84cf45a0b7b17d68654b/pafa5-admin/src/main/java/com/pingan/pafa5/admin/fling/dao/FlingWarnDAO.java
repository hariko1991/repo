package com.pingan.pafa5.admin.fling.dao;

import java.util.Date;
import java.util.List;

import com.pingan.pafa5.admin.fling.po.FlingWarnPO;

public interface FlingWarnDAO {

    void add(FlingWarnPO po);

    List<FlingWarnPO> listLast(String projectId, String pappName, String sarName, int size, int page);

    FlingWarnPO getById(String id);

    long getCount(String projectId, String pappName, String sarName);

    int removeBeforeDate(Date date);

}
