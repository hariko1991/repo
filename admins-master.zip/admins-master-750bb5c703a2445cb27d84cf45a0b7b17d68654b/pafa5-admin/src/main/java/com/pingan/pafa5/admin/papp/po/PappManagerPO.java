package com.pingan.pafa5.admin.papp.po;

import java.util.Date;

import com.paic.pafa.validator.annotation.VLength;
import com.pingan.pafa5.admin.commons.BasePO;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 应用管理PO
 * 2016年6月14日14:08:48
 * @author HOUSHANGZHI377
 *
 */
@Document
public class PappManagerPO  extends BasePO {

	/**ID*/
	@Id
	private String id;
	
	/**应用ID*/
	@VLength(max=250)
	private String pappName;
	
	/**应用中文名*/
	@VLength(max=250)
	private String pappChName;
	
	/**所属项目id*/
	@Indexed
	private String systemsId;
	
	/**所属项目名称*/
	private String systemsName;
	
	/**应用负责人*/
	private String pappOwner;
	
	/**应用负责人ID*/
	private String pappOwnerId;

	private String remark;
	//add by yuying412
	private Date updatedDateFromConfigManager;
	//add by yuying412
	private Date updatedDateFromPappManager;
	
	public Date getUpdatedDateFromConfigManager() {
		return updatedDateFromConfigManager;
	}

	public void setUpdatedDateFromConfigManager(Date updatedDateFromConfigManager) {
		this.updatedDateFromConfigManager = updatedDateFromConfigManager;
	}

	public Date getUpdatedDateFromPappManager() {
		return updatedDateFromPappManager;
	}

	public void setUpdatedDateFromPappManager(Date updatedDateFromPappManager) {
		this.updatedDateFromPappManager = updatedDateFromPappManager;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}


	public String getPappName() {
		return pappName;
	}


	public void setPappName(String pappName) {
		this.pappName = pappName;
	}


	public String getPappChName() {
		return pappChName;
	}


	public void setPappChName(String pappChName) {
		this.pappChName = pappChName;
	}


	public String getSystemsId() {
		return systemsId;
	}


	public void setSystemsId(String systemsId) {
		this.systemsId = systemsId;
	}


	public String getSystemsName() {
		return systemsName;
	}


	public void setSystemsName(String systemsName) {
		this.systemsName = systemsName;
	}


	public String getPappOwner() {
		return pappOwner;
	}


	public void setPappOwner(String pappOwner) {
		this.pappOwner = pappOwner;
	}


	public String getPappOwnerId() {
		return pappOwnerId;
	}


	public void setPappOwnerId(String pappOwnerId) {
		this.pappOwnerId = pappOwnerId;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

}
