package com.pingan.pafa5.admin.pizza.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.pizza.dao.EnvSyncFailureDAO;
import com.pingan.pafa5.admin.pizza.po.EnvSyncFailurePO;

@Nosql
@Repository
public class EnvSyncFailureDAOImpl extends BaseMongoDAO<EnvSyncFailurePO> implements EnvSyncFailureDAO {

    public void add(EnvSyncFailurePO po) {
        this._add(po);
    }

    public List<EnvSyncFailurePO> list(String syncId) {
        return this._list(where("syncId").is(syncId));
    }

}
