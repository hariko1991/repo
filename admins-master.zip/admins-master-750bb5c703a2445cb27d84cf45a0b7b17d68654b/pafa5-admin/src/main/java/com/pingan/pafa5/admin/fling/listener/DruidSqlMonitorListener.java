package com.pingan.pafa5.admin.fling.listener;

import java.util.Date;
import java.util.UUID;

import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.ServiceConfig;
import com.pingan.pafa.datasource.monitor.DruidSqlMessageDTO;
import com.pingan.pafa.datasource.monitor.DruidSqlMonitorDubboService;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.fling.dao.DruidDatasourceDAO;
import com.pingan.pafa5.admin.fling.dao.DruidSqlDAO;
import com.pingan.pafa5.admin.fling.po.DruidDatasourcePO;
import com.pingan.pafa5.admin.fling.po.DruidSqlPO;

public class DruidSqlMonitorListener implements InitializingBean, DisposableBean {
	
	private Log logger = LogFactory.getLog(this.getClass());
	
	private ServiceConfig<DruidSqlMonitorDubboService> serviceConfig;
	
	@Autowired
	private DruidSqlDAO druidSqlDAO;
	
	@Autowired
	private DruidDatasourceDAO druidDatasourceDAO;

	@Override
	public void afterPropertiesSet() throws Exception {
		serviceConfig = new ServiceConfig<DruidSqlMonitorDubboService>();
		serviceConfig.setInterface(DruidSqlMonitorDubboService.class);
		serviceConfig.setRef(new DruidSqlMonitorDubboService() {

			@Override
			public void sendSqlMsg(DruidSqlMessageDTO msg) {
				if (logger.isDebugEnabled()) {
		            logger.debug("druidSqlMsg:" + msg.toString());
		        }
				if(msg != null){
					DruidDatasourcePO druidDataSource = druidDatasourceDAO.getDruidDatasourceByIdentity(msg.getIdentity());
					
					if(druidDataSource != null){
						DruidSqlPO po = druidSqlDAO.getDruidSqlBySqlId(msg.getSqlId(), msg.getIdentity());
						addAndUpdateDruidSql(po,msg,druidDataSource);
					}
					
				}
			}

		});

		serviceConfig.export();
	}
	
	@Override
	public void destroy() throws Exception {
		if (serviceConfig != null) {
			try {
				serviceConfig.unexport();
			} catch (Exception ex) {
				//TODO
			}
			serviceConfig = null;
		}
	}
	
	public void addAndUpdateDruidSql(DruidSqlPO po, DruidSqlMessageDTO msg, DruidDatasourcePO druidDataSource){
		ConvertUtils.register(new DateConverter(null), java.util.Date.class);
		if(po != null){
			POUtils.copyProperties(po,msg);
			if(msg.getHistogram() != null && msg.getHistogram().length != 0){
				po.setHistogram(POUtils.arrayToString(msg.getHistogram()));
			}
			if(msg.getFetchRowCountHistogram() != null && msg.getFetchRowCountHistogram().length != 0){
				po.setFetchRowCountHistogram(POUtils.arrayToString(msg.getFetchRowCountHistogram()));
			}
			if(msg.getEffectedRowCountHistogram() != null && msg.getEffectedRowCountHistogram().length != 0){
				po.setEffectedRowCountHistogram(POUtils.arrayToString(msg.getEffectedRowCountHistogram()));
			}
			if(msg.getExecuteAndResultHoldTimeHistogram() != null && msg.getExecuteAndResultHoldTimeHistogram().length != 0){
				po.setExecuteAndResultHoldTimeHistogram(POUtils.arrayToString(msg.getExecuteAndResultHoldTimeHistogram()));
			}
			po.setUpdatedDate(new Date());
			druidSqlDAO.update(po);
			
		}else{
			DruidSqlPO druidSql = new DruidSqlPO();
		    //ConvertUtils.register(new DateConverter(null), java.util.Date.class);  
			POUtils.copyProperties(druidSql,msg);
			String uuid = UUID.randomUUID().toString();
			druidSql.setId(uuid);
			if(msg.getHistogram() != null && msg.getHistogram().length != 0){
				druidSql.setHistogram(POUtils.arrayToString(msg.getHistogram()));
			}
			if(msg.getFetchRowCountHistogram() != null && msg.getFetchRowCountHistogram().length != 0){
				druidSql.setFetchRowCountHistogram(POUtils.arrayToString(msg.getFetchRowCountHistogram()));
			}
			if(msg.getEffectedRowCountHistogram() != null && msg.getEffectedRowCountHistogram().length != 0){
				druidSql.setEffectedRowCountHistogram(POUtils.arrayToString(msg.getEffectedRowCountHistogram()));
			}
			if(msg.getExecuteAndResultHoldTimeHistogram() != null && msg.getExecuteAndResultHoldTimeHistogram().length != 0){
				druidSql.setExecuteAndResultHoldTimeHistogram(POUtils.arrayToString(msg.getExecuteAndResultHoldTimeHistogram()));
			}
			druidSql.setCreatedDate(new Date());
			druidSql.setDruidDatasourceId(druidDataSource.getId());
			
			druidSqlDAO.add(druidSql);
			
		}
	}

}
