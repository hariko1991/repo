package com.pingan.pafa5.admin.logging.job;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paic.pafa.job.TimerJob;
import com.pingan.pafa5.admin.logging.services.LogMonitorServices;

@Component
public class LogMonitorJob {

	// 日志
	private Log logger = LogFactory.getLog(this.getClass());

	@Autowired
	private LogMonitorServices logMonitorServices;
	
	@TimerJob(repeatInterval="60000")
	public void execute()  {
		if (logger.isInfoEnabled()) {
			logger.info("execute LogMonitorJob");
		}
		logMonitorServices.setTimeOutStatus();
	}

	public void setLogMonitorServices(LogMonitorServices logMonitorServices) {
		this.logMonitorServices = logMonitorServices;
	}
		
}
