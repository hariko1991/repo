package com.pingan.pafa5.admin.pizza.web;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.validator.annotation.Valid;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.commons.SARManagerConstants;
import com.pingan.pafa5.admin.pizza.dto.GlobalVariableDTO;
import com.pingan.pafa5.admin.pizza.form.GlobalVariableForm;
import com.pingan.pafa5.admin.pizza.po.GlobalVariablePO;
import com.pingan.pafa5.admin.pizza.services.GlobalVariableService;
import com.pingan.um.client.util.StringUtil;

@Controller
@RequestMapping("/pizzamgr/global")
public class GlobalVariableController extends BaseController {

	@Autowired
	private GlobalVariableService globalService;
	
	@ActionClient(name = "pafa5-admin-systems.isOwner")
    private IServiceClient ownerService;

	@ResponseBody
	@RequestMapping("/list.do")
	public ResponseModel list(
			@RequestParam(value = "projectId", required = false) String proId,
			@RequestParam(value = "property", required = false) String property,
			@RequestParam(value = "page", required = false, defaultValue = "1") int page,
			@RequestParam(value = "limit", required = false, defaultValue = "30") int limit)
			throws Exception {
		if (logger.isInfoEnabled()) {
			logger.info("Query: proId=" + proId + ", page=" + page + ", limit=" + limit);
		}
		PageDataDTO<GlobalVariableDTO> pageData = globalService.list(proId, property, page, limit);
		List<GlobalVariableDTO> list = new ArrayList<GlobalVariableDTO>();
		if (pageData.getTotalSize() == 0) {
			pageData.setDatas(list);
		}
		// for(GlobalVariableDTO dto : pageData.getDatas()) {
		// if(dto.isHidden()) {
		// dto.setValue("******");
		// }
		// }
		ResponseModel model = new ResponseModel();
		model.put("datas", pageData.getDatas());
		model.put("size", pageData.getTotalSize());
		return model;
	}
	
	@ESA(name="pafa5-admin-pizza.getglobalall",local=true)
	public ResponseModel getGlobalAll(@RequestParam(value = "projectId", required = false) String projectId) throws Exception {
		if (logger.isInfoEnabled()) {
			logger.info("Query: projectId=" + projectId);
		}
		List<GlobalVariablePO> globalVariablePOs = globalService.list(projectId);
		
		ResponseModel model = new ResponseModel();
		model.put("datas", globalVariablePOs);
		model.put("size", globalVariablePOs.size());
		return model;
	}

	@ResponseBody
	@RequestMapping("/findById.do")
	@ESA(value = "pafa5_admin_pizza.findGlobalById",local = true)
	public ResponseModel findById(
			@RequestParam(value = "id", required = true) String id)
			throws Exception {
		GlobalVariableDTO dto = globalService.getById(id);
		ResponseModel model = new ResponseModel();
		model.put("success", true);
		model.put("global", dto);
		return model;
	}

	@ResponseBody
	@RequestMapping("/add.do")
	@ESA(value = "pafa5_admin_pizza.addGlobal",local = true)
	public ResponseModel add(@Valid GlobalVariableForm form) throws IOException {
	    isOwner(form.getProId());
	    
		if (logger.isInfoEnabled()) {
			logger.info("form=" + JSONObject.toJSONString(form));
		}
		String msg = "";
		if(StringUtil.isNotNull(form.getProperty())&&form.getProperty().length()>250){
			msg = "对不起，变量名过长！";
            ResponseModel map = new ResponseModel();
            map.put("success", false);
            map.setResponseMsg(msg);
            return map;
		}
		globalService.add(form);
		ResponseModel model = new ResponseModel();
		model.put("success", true);
		return model;
	}

	@ResponseBody
	@RequestMapping("/edit.do")
	@ESA(value = "pafa5_admin_pizza.editGlobal",local = true)
	public ResponseModel edit(@Valid GlobalVariableForm form)
			throws IOException {
	    isOwner(form.getProId());
	    
		if (logger.isInfoEnabled()) {
			logger.info("form=" + JSONObject.toJSONString(form));
		}
		String msg = "";
		if(StringUtil.isNotNull(form.getProperty())&&form.getProperty().length()>250){
			msg = "变量名过长！";
            ResponseModel map = new ResponseModel();
            map.put("success", false);
            map.setResponseMsg(msg);
            return map;
		}
//		if ("******".equals(form.getValue()) || form.getValue() == null
//				|| form.getValue().trim().length() == 0
//				|| form.getValue().trim().equals("")) {
		if("******".equals(form.getValue())){
			ResponseModel model = new ResponseModel();
			model.put("success", false);
			model.setResponseMsg("请填写正确的变量值");
			return model;
		} else {
			ResponseModel model = new ResponseModel();
			boolean success = globalService.edit(form);
			model.put("success", success);
			return model;
		}
	}

	@ResponseBody
	@RequestMapping("/delete.do")
	public ResponseModel delete(
			@RequestParam(value = "id", required = true) String id)
			throws Exception {
		boolean success = globalService.delete(id);
		ResponseModel model = new ResponseModel();
		model.put("success", success);
		return model;
	}
	
	public void isOwner(String domainId) {
        if (domainId == null || SARManagerConstants.DEF.equalsIgnoreCase(domainId)) {
            return;
        }
        ServiceParams params = new ServiceParams();
        params.set("groupId", domainId);
        ServiceResults results = ownerService.invoke(params);
        boolean isBoo = results.getBool("isowner");
        if (!isBoo) {
            throw new ResponseCodeException("354", "对不起，你不是领域负责人，没有此操作权限");
        }
    }
	
	public void setGlobalService(GlobalVariableService globalService) {
		this.globalService = globalService;
	}

    public void setOwnerService(IServiceClient ownerService) {
        this.ownerService = ownerService;
    }

}
