package com.pingan.pafa5.admin.pizza.dto;

import java.util.Date;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.paic.pafa.validator.annotation.VLength;
import com.paic.pafa.validator.annotation.VNotEmpty;


/**
 * @see ivy依赖仓库配置文件
 * @author JIECHANGKE805
 * @since 2016-05-23
 */
public class IvyLibConfigDTO {
	
    private String id;
	
	private String group;

	private String key;
	
	private String uuid;
	
	private String ivyByteValue;
	
	private String ivySha1;
	
	private String jarSha1;
	@VNotEmpty
	private String projectId;
//	@VNotEmpty
//	@VLength(max=100,min=1)
	private String org;
//	@VNotEmpty
//	@VLength(max=100,min=1)
	private String module;
//	@VNotEmpty
//	@VLength(max=50,min=1)
	private String version;
	
	private boolean edit;
	
	private boolean override;
//	@VNotEmpty
//	@VLength(max=50,min=1)
	private String fileName;
	
	//上传文件
//	@VNotEmpty
    private CommonsMultipartFile upload;
    
    private String valueSize;
	
	private String createdBy;
	
    private Date createdDate;
    
	private String updatedBy;
	
	private Date updatedDate;
	
	private String requestId;
	
	private String enableFlag;
	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getIvyByteValue() {
		return ivyByteValue;
	}

	public void setIvyByteValue(String ivyByteValue) {
		this.ivyByteValue = ivyByteValue;
	}
  
	public String getIvySha1() {
		return ivySha1;
	}

	public void setIvySha1(String ivySha1) {
		this.ivySha1 = ivySha1;
	}

	public String getJarSha1() {
		return jarSha1;
	}

	public void setJarSha1(String jarSha1) {
		this.jarSha1 = jarSha1;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getOrg() {
		return org;
	}

	public void setOrg(String org) {
		this.org = org;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public boolean isEdit() {
		return edit;
	}

	public void setEdit(boolean edit) {
		this.edit = edit;
	}

	public boolean isOverride() {
		return override;
	}

	public void setOverride(boolean override) {
		this.override = override;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public CommonsMultipartFile getUpload() {
		return upload;
	}

	public void setUpload(CommonsMultipartFile upload) {
		this.upload = upload;
	}

	public String getValueSize() {
		return valueSize;
	}

	public void setValueSize(String valueSize) {
		this.valueSize = valueSize;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public String getUpdatedBy() {
		return updatedBy;
	}

	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	public Date getUpdatedDate() {
		return updatedDate;
	}

	public void setUpdatedDate(Date updatedDate) {
		this.updatedDate = updatedDate;
	}

	public String getRequestId() {
		return requestId;
	}

	public void setRequestId(String requestId) {
		this.requestId = requestId;
	}

	public String getEnableFlag() {
		return enableFlag;
	}

	public void setEnableFlag(String enableFlag) {
		this.enableFlag = enableFlag;
	}
	

}
