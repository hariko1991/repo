package com.pingan.pafa5.admin.papp.form;

import com.paic.pafa.validator.annotation.VNotEmpty;
import com.paic.pafa.validator.annotation.VRegex;

public class SaveDubboConfigForm {
	
	@VNotEmpty
	private String projectId;
	
	@VNotEmpty
	private String pappName;
	
	@VNotEmpty
	@VRegex("^[0-9]*[1-9][0-9]*$")
	private Integer port;
	
	@VNotEmpty
	private Boolean monitor;
	
	private String host;
	
	@VNotEmpty
	private String serializer;
	
	@VNotEmpty
	@VRegex("^[0-9]*[1-9][0-9]*$")
	private Integer pool;
	
	@VNotEmpty
	@VRegex("^[0-9]*[1-9][0-9]*$")
	private Integer timeout;
	
	@VNotEmpty
	private String loadbalance;
	
	private String opType;
	
	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getPappName() {
		return pappName;
	}

	public void setPappName(String pappName) {
		this.pappName = pappName;
	}

	public Integer getPort() {
		return port;
	}

	public void setPort(Integer port) {
		this.port = port;
	}

	public Boolean getMonitor() {
		return monitor;
	}

	public void setMonitor(Boolean monitor) {
		this.monitor = monitor;
	}

	public String getHost() {
		return host;
	}

	public void setHost(String host) {
		this.host = host;
	}

	public String getSerializer() {
		return serializer;
	}

	public void setSerializer(String serializer) {
		this.serializer = serializer;
	}

	public Integer getPool() {
		return pool;
	}

	public void setPool(Integer pool) {
		this.pool = pool;
	}

	public Integer getTimeout() {
		return timeout;
	}

	public void setTimeout(Integer timeout) {
		this.timeout = timeout;
	}

	public String getLoadbalance() {
		return loadbalance;
	}

	public void setLoadbalance(String loadbalance) {
		this.loadbalance = loadbalance;
	}

	public String getOpType() {
		return opType;
	}

	public void setOpType(String opType) {
		this.opType = opType;
	}
	
}
