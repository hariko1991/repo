package com.pingan.pafa5.admin.monitor.dao;

import java.util.Date;
import java.util.List;

import com.pingan.pafa5.admin.monitor.po.DubboStatisticsPO;

public interface DubboStatisticsDAO {

    void save(DubboStatisticsPO po);
    
    long count(String interfaceName, Date beginDate, Date endDate);
    
    List<DubboStatisticsPO> list(String interfaceName, Date beginDate, Date endDate, int skip, int limit);
    
    List<DubboStatisticsPO> list(Date createTime);
    
    void removeByCreateTime(Date createTime);
    
    void removeById(String id);
    
}
