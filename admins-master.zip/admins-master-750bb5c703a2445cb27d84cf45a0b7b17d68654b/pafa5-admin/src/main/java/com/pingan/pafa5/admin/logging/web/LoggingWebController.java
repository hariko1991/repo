package com.pingan.pafa5.admin.logging.web;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.validator.annotation.Valid;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.redis.queue.RedisQueue;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.logging.dto.LogMonitorDTO;
import com.pingan.pafa5.admin.logging.form.LogMonitorForm;
import com.pingan.pafa5.admin.logging.po.LogMonitorPO;
import com.pingan.pafa5.admin.logging.services.LogMonitorServices;
import com.pingan.pafa5.admin.logging.services.impl.LogOutputUtils;

@Controller
@RequestMapping("/logging")
public class LoggingWebController extends BaseController {

	@Autowired
	private LogMonitorServices logMonitorServices;
	
	@ActionClient(name="logservices.query")
	private IServiceClient esService;
	
	@ActionClient(name="logservices.openlog")
	private IServiceClient esOpenlogService;
	
	@ActionClient(name="logservices.excuteIndex")
	private IServiceClient esIndexService;
	
	@ActionClient(name="logservices.getkafkaurl")
	private IServiceClient esKafkaUrlService;
	
	@RequestMapping("/list.do")
	@ResponseBody
	public ResponseModel listForPapp(
			@RequestParam(value="projectId",required=false) String projectId,
			@RequestParam(value="pappName",required=false) String pappName,
			@RequestParam(value="limit",defaultValue="30") int limit,
			@RequestParam(value="page",defaultValue="1") int page){
		PageDataDTO<LogMonitorDTO> dtos = logMonitorServices.list(projectId, pappName, limit, page);
		ResponseModel model = new ResponseModel();
		model.put("datas", dtos.getDatas());
		model.put("total", dtos.getTotalSize());
		return model;
	}
	
	/** 生成配置
	 * 
	 * @param form
	 * @return
	 */
	@RequestMapping("/config.do")
	@ResponseBody
	public ResponseModel submit(@Valid LogMonitorForm form){
		ResponseModel model = new ResponseModel();
		
		try {
			String currTime = getCurrTime();
			LogMonitorPO po = logMonitorServices.configXML(form, currTime);
			model.put("queueName", po.getQueueName());
			model.put("id", po.getId());
			model.put("timer", po.getExpiredTime());
			model.put("startTime", currTime);
			model.put("success", true);
		} catch (Exception e) {
			model.put("msg", e.getMessage());
			model.put("success", false);
			return model;
		}
		
		return model;
	}
	
	/** 查看日志
	 * 
	 * @param form
	 * @return
	 */
	@RequestMapping("/view.do")
	@ResponseBody
	public ResponseModel view(
			@RequestParam(value="id", required=true) String id){
		ResponseModel model = new ResponseModel();
		try {
			String currTime = getCurrTime();
			LogMonitorPO po = logMonitorServices.configXML(id, currTime);
			model.put("queueName", po.getQueueName());
			model.put("timer", po.getExpiredTime());
			model.put("startTime", currTime);
			model.put("success", true);
		} catch (Exception e) {
			e.printStackTrace();
			model.put("msg", e.getMessage());
			model.put("success", false);
			return model;
		}
		return model;
	}
	
	/** 还原
	 * 
	 * @param queueName
	 * @return
	 */
	@RequestMapping("/restore.do")
	@ResponseBody
	public ResponseModel restore(
			@RequestParam(value="id", required=true) String id, 
			@RequestParam(value="startTime", required=true) String startTime){
		ResponseModel model = new ResponseModel();
		try {
			logMonitorServices.restoreXML(id.toLowerCase(), startTime);
			model.put("success", true);
		} catch (Exception e) {
			model.put("msg", e.getMessage());
			model.put("success", false);
			return model;
		}
		
		return model;
	}
	
	/** 删除
	 * 
	 * @param queueName
	 * @return
	 */
	@RequestMapping("/delete.do")
	@ResponseBody
	public ResponseModel delete(@RequestParam(value="id", required=true) String id){
		if (logger.isInfoEnabled()) {
			logger.info("delete, ID="+id);
		}
		ResponseModel model = new ResponseModel();
		try {
			boolean success = logMonitorServices.delete(id);
			model.put("success", success);
		} catch (Exception e) {
			model.put("msg", e.getMessage());
			model.put("success", false);
			return model;
		}
		
		return model;
	}
	
	@SuppressWarnings("rawtypes")
	@RequestMapping("/read.do")
	public void read(
			 @RequestParam("queueName") String queueName,
			 @RequestParam(value="limitSize",defaultValue="-1") int  limitSize,
			 HttpServletResponse response) throws Throwable {
		if (logger.isInfoEnabled()) {
			logger.info("QueueName="+queueName);
		}
		RedisQueue<HashMap> redisQueue=logMonitorServices.getConfigRedis(queueName).loadQueue(queueName, HashMap.class);
		response.setContentType("text/plain");
		response.setCharacterEncoding("UTF-8");
		PrintWriter out=response.getWriter();
		LogOutputUtils.outputHTML(redisQueue, out, limitSize);
	}
	
	/**
	 * 查看es中日志
	 * @return
	 */
	@RequestMapping("/viewlog.do")
	@ResponseBody
	public ResponseModel queryeslog(
			@RequestParam(value="projectId", required=false) String projectId,
			@RequestParam(value="appName", required=false) String appName,
			@RequestParam(value="starttime", required=true) String starttime,
			@RequestParam(value="endtime", required=true) String endtime,
			@RequestParam(value="content", required=false) String content,
			@RequestParam(value="level", required=false) String level,
			@RequestParam(value="ip", required=false) String ip, 
			@RequestParam(value="loggerName", required=false) String loggerName, 
			@RequestParam(value="contextstack", required=false) String contextstack, 
			@RequestParam(value="pageNo", required=false ) int pageNo, 
			@RequestParam(value="pageSize", required=false) int pageSize, 
			@RequestParam(value="ascOrdesc", required=false) String ascOrdesc, 
			@RequestParam(value="requestId", required=false) String requestId,
			HttpServletResponse response) throws Throwable{
			ServiceParams params = ServiceParams.newInstance();
			params.set("starttime", starttime);
			params.set("endtime", endtime);
			params.set("loggerName", loggerName);
			params.set("appName", appName);
			params.set("ip", ip);
			params.set("level", level);
			params.set("message", content);
			params.set("contextstack", contextstack);
			params.set("projectId", projectId);
			params.set("pageNo", pageNo);
			params.set("pageSize", pageSize);
			params.set("ascOrdesc", ascOrdesc);
			params.set("requestId", requestId);
			ServiceResults result =esService.invoke(params);
			
			ResponseModel model = new ResponseModel();
			if ("000000".equals(result.getString("responseCode"))) {
				String eslog = result.getString("esresult");
				long total = result.getLong("totalSize");
							
				model.put("eslog", eslog==null?"<font color='red'>无结果</font>":eslog);
				model.put("total", total);
			}else{
				model.put("eslog", "<font color='red'>" + result.getString("responseMsg") + "</font>");
				
			}
			return model;
	}
	
	/** 获取当前时间戳
	 * 
	 * @param format
	 * @return
	 */
	private String getCurrTime() {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
		return sdf.format(new Date());
	}
	
	/** 插入日志队列
	 * 
	 * @param form
	 * @return
	 */
	@RequestMapping("/openKafkaLog.do")
	@ResponseBody
	public ResponseModel openKafkaLog(@RequestParam(value="pappName", required=true) String pappName,
			@RequestParam(value="projectId", required=true) String projectId){

		ResponseModel model = new ResponseModel();		
		String kafkaurl =null;
		//更改log4j
		try{
			 ServiceParams params = ServiceParams.newInstance();
			 ServiceResults result =esKafkaUrlService.invoke(params);
			 kafkaurl = result.getString("kafkaurl");
		}catch (Exception e){
			logger.error("获取kafkaurl失败");
			model.put("success", false);
			model.put("msg", "获取kafkaurl失败");
			return model;
		}
		try{
			logMonitorServices.configKafkaXML(pappName, projectId, kafkaurl);
		}catch (Exception e){
			logger.error("更改log4j配置文件失败");
			model.put("success", false);
			model.put("msg", "更改log4j配置文件失败");
			return model;
		}
		
		//插入mongodb		
		ServiceParams formparams = ServiceParams.newInstance();		
		formparams.put("projectId", projectId);
		formparams.put("appId", pappName);
		try{
			ServiceResults opresult =esOpenlogService.invoke(formparams);
			String openresult = opresult.getString("result");
			if (openresult.equals("fail")){
				logger.error("保存队列信息失败");
				model.put("success", false);
				model.put("msg", "保存队列信息失败");
				return model;
			}
		}catch (Exception e){
			logger.error("保存队列信息失败");
			model.put("success", false);
			model.put("msg", "保存队列信息失败");
			return model;
		}
		
		
//		//创建Index
//		ServiceResults indexresult =esIndexService.invoke(formparams);
//		try{
//			String responseCode = indexresult.getString("responseCode");	
//			if (!responseCode.equals("000000")){
//				logger.error("创建Index失败");
//				model.put("success", false);
//				model.put("msg", "创建Index失败");
//				return model;
//			}else{
//				model.put("success", true);
//				model.put("msg", "开启成功");
//			}
//		}
//		catch (Exception e){
//			logger.error("创建Index失败");
//			model.put("success", false);
//			model.put("msg", "创建Index失败");
//			return model;
//		}
		
		model.put("success", true);
		model.put("msg", "开启成功");
		return model;
	}
	
	/** 还原
	 * 
	 * @param queueName
	 * @param projectId
	 * @return
	 */
	@RequestMapping("/deleteKafkaLog.do")
	@ResponseBody
	public ResponseModel deleteKafkaLog(
			@RequestParam(value="pappName", required=true) String pappName,
					@RequestParam(value="projectId", required=true) String projectId){
		ResponseModel model = new ResponseModel();
		try {
			logMonitorServices.restoreKafkaXML(pappName,projectId);
			model.put("msg", "关闭成功");
			model.put("success", true);
		} catch (Exception e) {
			model.put("msg", e.getMessage());
			model.put("success", false);
			return model;
		}
		
		return model;
	}
	
	/**
	 * 判断log4j kafka节点是否存在
	 * @param pappName
	 * @param projectId
	 * @return
	 */
	@RequestMapping("/checkKafkaNodeExist.do")
	@ResponseBody
	public ResponseModel checkKafkaNodeExist(@RequestParam(value="pappName", required=true) String pappName,
			@RequestParam(value="projectId", required=true) String projectId){
		ResponseModel model = new ResponseModel();
		try{
			boolean flag = logMonitorServices.checkKafkaExist(pappName, projectId);
			model.put("success", flag);
			model.put("msg", "noerror");
		}catch (Exception e) {
			model.put("msg", e.getMessage());
			model.put("success", false);
			return model;
		}
		return model;
	}
	
	
	@ActionClient(name="logservices.download")
	private IServiceClient esDownService;
	
	@RequestMapping(value = "/export.do")
	public ResponseModel download(@RequestParam(value = "projectId", required = false) String projectId, @RequestParam(value = "appName", required = false) String appName,
			@RequestParam(value = "starttime", required = true) String starttime, @RequestParam(value = "endtime", required = true) String endtime,
			@RequestParam(value = "content", required = false) String content, @RequestParam(value = "level", required = false) String level, @RequestParam(value = "ip", required = false) String ip,
			@RequestParam(value = "loggerName", required = false) String loggerName, @RequestParam(value = "contextstack", required = false) String contextstack,
			@RequestParam(value = "ascOrdesc", required = false) String ascOrdesc, @RequestParam(value="requestId", required=false) String requestId, HttpServletResponse response) throws Throwable {

		ServiceParams params = ServiceParams.newInstance();
		params.set("starttime", starttime);
		params.set("endtime", endtime);
		params.set("loggerName", loggerName);
		params.set("appName", appName);
		params.set("ip", ip);
		params.set("level", level);
		params.set("message", content);
		params.set("contextstack", contextstack);
		params.set("projectId", projectId);
		params.set("ascOrdesc", ascOrdesc);
		params.set("requestId", requestId);

		// Map<Object, Object> test = new HashMap<Object, Object>();
		// ServiceResults result = new ServiceResults(test);
		// result.put("responseCode", "000000");
		// result.put("data", "测试数据");

		ResponseModel model = new ResponseModel();
		try {
			ServiceResults result = esDownService.invoke(params);

			if ("000000".equals(result.getString("responseCode"))) {
				String eslog = result.getString("data");

				response.setContentType("text/plain;charset=utf-8");
				response.addHeader("Content-Disposition", "attachment;filename=" + "esLog.txt");
				response.getOutputStream().write(eslog.getBytes());
				response.getOutputStream().flush();
				response.getOutputStream().close();
				return null;
			} else {
				model.put("responseCode", result.getString("responseCode"));
				model.put("responseMsg", result.getString("responseMsg"));
				return model;
			}

		} catch (Exception e) {
			model.put("error", e.toString());
			return model;
		}

	}
	
	
	
	public void setLogMonitorServices(LogMonitorServices logMonitorServices) {
		this.logMonitorServices = logMonitorServices;
	}
}
