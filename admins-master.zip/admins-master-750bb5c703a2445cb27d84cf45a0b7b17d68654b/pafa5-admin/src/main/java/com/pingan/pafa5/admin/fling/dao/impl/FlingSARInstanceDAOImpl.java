package com.pingan.pafa5.admin.fling.dao.impl;

import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.fling.dao.FlingSARInstanceDAO;
import com.pingan.pafa5.admin.fling.po.FlingSARInstancePO;

@Nosql
@Repository
public class FlingSARInstanceDAOImpl extends BaseMongoDAO<FlingSARInstancePO> implements
        FlingSARInstanceDAO {

    @Override
    public void upset(FlingSARInstancePO po) {
    	 this._upsert(
                 this.where("sarName").is(po.getSarName()).and("instanceIp").is(po.getInstanceIp())
                         .and("projectId").is(po.getProjectId()), po);
    	
    }

    @Override
    public FlingSARInstancePO getFlingSarInstancePO(String sarName, String instanceIp) {
        return this._get(this.where("sarName").is(sarName).and("instanceIp").is(instanceIp));
    }

    @Override
    public List<FlingSARInstancePO> list(String instanceIp,int limit, int page) {
    	Criteria where = where("status").ne(9);// 非删除状态
        if (StringUtils.isNotEmpty(instanceIp)) {
            where.and("instanceIp").is(instanceIp);
        } 
        int skip = (page - 1) * limit;
        return this._list(where, skip, limit);
    }
    
    @Override
    public List<FlingSARInstancePO> list(int status) {
    	Criteria where = where("status").is(status);// 非删除状态
        return this._list(where);
    }
    
    @Override
    public List<FlingSARInstancePO> list(String sarName, String pappName) {
        Criteria where = where("sarName").is(sarName);
        if (pappName != null && !pappName.equals("") && !"null".equals(pappName)) {
            where.and("appName").is(pappName);
        }
        where.and("status").ne(9);// 非删除状态
        return this._list(where);
    }

    @Override
    public List<FlingSARInstancePO> list(String projectId, String pappName, String sarName) {

        Criteria where = where("status").ne(9);// 非删除状态
        if (StringUtils.isNotEmpty(projectId)) {
            where.and("projectId").is(projectId);
        } else {
            where.and("projectId").is(null);
        }
        if (pappName != null && !pappName.equals("") && !"null".equals(pappName)) {
            where.and("appName").is(pappName);
        }

        if (sarName != null && !sarName.equals("") && !"null".equals(sarName)) {
            where.and("sarName").is(sarName);
        }

        return this._list(where);
    }

    @Override
    public List<FlingSARInstancePO> list(String projectId, String sarName, String pappName,
            int limit, int page) {
        Criteria where = where("status").ne(9);// 非删除状态
        if (StringUtils.isNotEmpty(projectId)) {
            where.and("projectId").is(projectId);
        } else {
            where.and("projectId").is(null);
        }

        if (pappName != null && !pappName.equals("") && !"null".equals(pappName)) {
            where.and("appName").is(pappName);
        }

        if (sarName != null && !sarName.equals("") && !"null".equals(sarName)) {
            where.and("sarName").is(sarName);
        }
        int skip = (page - 1) * limit;
        return this._list(where, skip, limit);
    }
    
    @Override
    public List<FlingSARInstancePO> list(String instanceIp , String projectId, String sarName, String pappName,
            int limit, int page) {
        Criteria where = where("status").ne(9);// 非删除状态
        if (StringUtils.isNotEmpty(projectId)) {
            where.and("projectId").is(projectId);
        } else {
            where.and("projectId").is(null);
        }

        if (instanceIp != null && !projectId.equals("") && !"null".equals(instanceIp)) {
            where.and("instanceIp").is(instanceIp);
        }
        
        if (pappName != null && !pappName.equals("") && !"null".equals(pappName)) {
            where.and("appName").is(pappName);
        }

        if (sarName != null && !sarName.equals("") && !"null".equals(sarName)) {
            where.and("sarName").is(sarName);
        }
        int skip = (page - 1) * limit;
        return this._list(where, skip, limit);
    }
    
    @Override
    public List<FlingSARInstancePO> list(String instanceIp , String projectId, String sarName, String pappName) {
        Criteria where = where("status").ne(9);// 非删除状态
        if (StringUtils.isNotEmpty(projectId)) {
            where.and("projectId").is(projectId);
        } else {
            where.and("projectId").is(null);
        }

        if (instanceIp != null && !projectId.equals("") && !"null".equals(instanceIp)) {
            where.and("instanceIp").is(instanceIp);
        }
        
        if (pappName != null && !pappName.equals("") && !"null".equals(pappName)) {
            where.and("appName").is(pappName);
        }

        if (sarName != null && !sarName.equals("") && !"null".equals(sarName)) {
            where.and("sarName").is(sarName);
        }
        return this._list(where);
    }
    
    @Override
    public List<FlingSARInstancePO> list(int status,
            int limit, int page) {
        Criteria where = where("status").is(status);// 非删除状态
        

        
        int skip = (page - 1) * limit;
        return this._list(where, skip, limit);
    }
    
    

    @Override
    public long getSarCount(String projectId, String sarName, String pappName) {
        Criteria where = where("status").ne(9);// 非删除状态

        if (StringUtils.isNotEmpty(projectId)) {
            where.and("projectId").is(projectId);
        } else {
            where.and("projectId").is(null);
        }

        if (pappName != null && !pappName.equals("") && !"null".equals(pappName)) {
            where.and("appName").is(pappName);
        }

        if (sarName != null && !sarName.equals("") && !"null".equals(sarName)) {
            where.and("sarName").is(sarName);
        }
        return this._count(where);
    }
    
    @Override
    public long getSarCount(String instanceIp) {
        Criteria where = where("status").ne(9);// 非删除状态

        if (StringUtils.isNotEmpty(instanceIp)) {
            where.and("instanceIp").is(instanceIp);
        } 
        return this._count(where);
    }
    
   
    
    @Override
    public long getSarCount(int  status) {
        Criteria where = where("status").is(status);
        return this._count(where);
    }

    @Override
    public List<FlingSARInstancePO> listAll() {
        return this._list(null);
    }

    @Override
    public boolean delete(String projectId, String sarName, String instanceIp ,String pappName) {
        Criteria criteria = where("sarName").is(sarName).and("instanceIp").is(instanceIp).and("appName").is(pappName);
        if (StringUtils.isNotEmpty(projectId)) {
            criteria.and("projectId").is(projectId);
        } else {
            criteria.and("projectId").is(null);
        }
        FlingSARInstancePO po = this._get(criteria);
        po.setStatus(9);
        return this._update(criteria, po);
    }
    
    @Override
    public boolean checkSarExistenceByName(String sarName) {
        Criteria criteria = where("sarName").is(sarName);
        boolean result = this._exists(criteria);
        return result;
    }

	@Override
	public List<FlingSARInstancePO> listSarSearchResult(String projectId,
			String searchField) {
		Pattern p = Pattern.compile("^.*"+searchField+".*$",Pattern.CASE_INSENSITIVE);
        Criteria where = this.where("status").ne(9).orOperator(where("sarName").regex(p),where("instanceIp").regex(p));
        if (projectId != null && !"".equals(projectId.trim())) {
            where.and("projectId").is(projectId);
        }
		return this._list(where);
	}

	@Override
	public void updateStatus(FlingSARInstancePO po) {
		this._update(Criteria.where("projectId").is(po.getProjectId()).and("sarName").is(po.getSarName()).and("instanceIp").is(po.getInstanceIp()), 
				Update.update("status", po.getStatus()).set("updatedBy", po.getUpdatedBy()).set("updatedDate", new Date()));
	}


}
