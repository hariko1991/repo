package com.pingan.pafa5.admin.pool.dao;

import java.util.List;

import com.pingan.pafa5.admin.pool.po.PoolDatabasePO;

public interface PoolDatabaseDAO {

	public abstract List<PoolDatabasePO> list(String pizzaKey, String projectId, int limit, int page);

	public abstract long getCount(String pizzaId, String projectId);

	public abstract void add(PoolDatabasePO po);

	public abstract PoolDatabasePO getById(String pizzaId);

	public abstract boolean updateById(PoolDatabasePO po);

	public abstract boolean delete(String pizzaId);

}