package com.pingan.pafa5.admin.garden.web;

import org.springframework.stereotype.Controller;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.annotation.ActionClient;

import com.paic.pafa.web.BaseController;

import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.papp.esa.ResponseModel;

/**
 * 运维APP
 * @author yuying412
 *
 */
@Controller
public class GardenController extends BaseController{
	

	@ActionClient(name = "pafa5-admin-papp.getPappListNames")
    private IServiceClient pappService;
	
	@ActionClient(name = "pafa5-admin-sar.getSarListNames")
    private IServiceClient sarService;
	
	@ActionClient(name = "pafa5-admin-fling.gardenListPapps")
    private IServiceClient pappInstancesService;
	
	@ActionClient(name = "pafa5-admin-fling.gardenListSars")
    private IServiceClient sarInstancesService;
	
	@ActionClient(name = "pafa5-admin-systems.gardenListDomainIds")
    private IServiceClient domainListService;
	
	@ESA("pafa5-admin-garden.queryDomainIdList")

	public ResponseModel userPageMenus() {
		
		ResponseModel model = new ResponseModel();
		model.put("responseCode","0");
		return model;
	}
	
}
