package com.pingan.pafa5.admin.fling.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.fling.dao.FlingSARMonitorMsgDAO;
import com.pingan.pafa5.admin.fling.po.FlingSARMonitorMsgPO;

@Nosql
@Repository
public class FlingSARMonitorMsgDAOImpl extends BaseMongoDAO<FlingSARMonitorMsgPO> implements
        FlingSARMonitorMsgDAO {

    @Override
    public void add(FlingSARMonitorMsgPO po) {
        this._add(po);
    }

	@Override
	public FlingSARMonitorMsgPO getLast(String pappName,String sarName, String instanceIp) {
		List<FlingSARMonitorMsgPO> datas =
                this._listAndDesc(
                        this.where("appName").is(pappName).and("sarName").is(sarName).and("instanceIp").is(instanceIp), 0, 1,
                        "createdTimestamp");
        if (datas == null || datas.size() == 0) {
            return null;
        }
        return datas.get(0);
	}

}
