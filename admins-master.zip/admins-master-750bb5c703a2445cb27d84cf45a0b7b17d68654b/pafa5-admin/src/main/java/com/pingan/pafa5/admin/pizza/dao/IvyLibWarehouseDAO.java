package com.pingan.pafa5.admin.pizza.dao;

import java.util.Date;

import com.pingan.pafa5.admin.pizza.po.IvyLibWarehousePO;

/**
 * @see ivy lib仓库数据库操作接口
 * @author JIECHANGKE805
 * @date 2016-12-14
 */
public interface IvyLibWarehouseDAO {
	
	/**
	 * @see 校验lib是否已存在
	 * @param md5
	 * @return true/false
	 */
	public boolean isExists(String projectId,String md5);
	
	/**
	 * @see 根据项目ID和md5查询lib
	 * @param projectId
	 * @param md5
	 * @return lib PO
	 */
	public IvyLibWarehousePO findByMd5(String projectId,String md5);
	
	/**
	 * @see 保存lib
	 * @param ivyLibPO
	 */
	public void saveIvyLib(IvyLibWarehousePO ivyLibPO);
	
	/**
	 * @see 更新lib
	 * @param ivyLibPO
	 */
	public void updateIvyLib(IvyLibWarehousePO ivyLibPO);
	
	/**
	 * @see 根据ID查询lib和描述信息
	 * @param id
	 * @return lib记录
	 */
	public IvyLibWarehousePO findById(String id);
	
	/**
	 * 清理ivy仓库上传时产生的临时文件
	 */
	public void cleanTempFile(Date date);
	

}
