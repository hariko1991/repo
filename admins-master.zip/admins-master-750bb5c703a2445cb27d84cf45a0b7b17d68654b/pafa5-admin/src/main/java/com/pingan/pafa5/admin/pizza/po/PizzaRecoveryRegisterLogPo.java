package com.pingan.pafa5.admin.pizza.po;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;

public class PizzaRecoveryRegisterLogPo {

	@Id
	private String id;
	
	@Indexed
	private String logId;

	/**
	 * 领域id
	 */
	@Indexed
	private String projectId;

	private String groupId;
	/**
	 * 配置文件关键字
	 */
	private String keyConfig;

	private String errorLog;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getLogId() {
		return logId;
	}

	public void setLogId(String logId) {
		this.logId = logId;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getGroupId() {
		return groupId;
	}

	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}

	public String getKeyConfig() {
		return keyConfig;
	}

	public void setKeyConfig(String keyConfig) {
		this.keyConfig = keyConfig;
	}

	public String getErrorLog() {
		return errorLog;
	}

	public void setErrorLog(String errorLog) {
		this.errorLog = errorLog;
	}

}
