package com.pingan.pafa5.admin.pizza.services.impl;

import java.text.ParseException;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dao.PizzaConfigHistoryDAO;
import com.pingan.pafa5.admin.pizza.dao.PizzaConfigHistoryValueDAO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSaveDTO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSearchDTO;
import com.pingan.pafa5.admin.pizza.dto.PizzaConfigHistoryDTO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigHistoryPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigHistoryValuePO;
import com.pingan.pafa5.admin.pizza.services.ConfigGroupServices;
import com.pingan.pafa5.admin.pizza.services.HistoryConfigServices;
import com.pingan.pafa5.admin.pizza.services.PizzaConfigServices;
import com.pingan.pafa5.admin.pizza.utils.ConfigContentUtils;

@Service
public class HistoryConfigServicesImpl extends BaseServices implements HistoryConfigServices {

    @Autowired
    private ConfigGroupServices configGroupServices;

    @Autowired
    private PizzaConfigHistoryDAO pizzaConfigHistoryDAO;

    @Autowired
    private PizzaConfigHistoryValueDAO pizzaConfigHistoryValueDAO;

    @Autowired
    private PizzaConfigServices pizzaConfigServices;

    @Autowired
    private ConfigContentUtils configContentUtils;

    @Override
    public PageDataDTO<PizzaConfigHistoryPO> search(ConfigSearchDTO searchDTO) {
        if (searchDTO.getPage() <= 0) {
            searchDTO.setPage(1);
        }
        int limit = searchDTO.getLimit();
        if (limit <= 0) {
            searchDTO.setLimit(30);
        }         
        if (limit > 100) {
            searchDTO.setLimit(100);
        }       
        return pizzaConfigHistoryDAO.pageQuery(searchDTO);
    }
    
    @Override
    public void save(PizzaConfigHistoryDTO dto) {
        PizzaConfigHistoryPO po = new PizzaConfigHistoryPO();
        BeanUtils.copyProperties(dto, po);
        POUtils.setForAdd(dto.getOperationUser(), po);
        pizzaConfigHistoryDAO.add(po);
        
        PizzaConfigHistoryValuePO valuePo = new PizzaConfigHistoryValuePO();
        valuePo.setHistoryId(po.getHistoryId());
        valuePo.setPizzaValue(dto.getPizzaValue());
        pizzaConfigHistoryValueDAO.add(valuePo);
    }

    @Override
    public PizzaConfigHistoryPO get(String group, String key, long createDate) {
        if (key == null || (key = key.trim()).length() == 0) {
            throw new NullPointerException("key is null.");
        }
        if (group == null || (group = group.trim()).length() == 0) {
            throw new NullPointerException("group is null.");
        }
        return pizzaConfigHistoryDAO.get(group, key, createDate);
    }

    @Override
    public PizzaConfigHistoryPO getById(String historyId) {
        if (historyId == null || (historyId = historyId.trim()).length() == 0) {
            throw new NullPointerException("historyId is null.");
        }
        return pizzaConfigHistoryDAO.getById(historyId);
    }

    @Override
    public PizzaConfigHistoryValuePO getValueById(String historyId) {
        if (historyId == null || (historyId = historyId.trim()).length() == 0) {
            throw new NullPointerException("historyId is null.");
        }
        return pizzaConfigHistoryValueDAO.getById(historyId);
    }

    /**
     * 恢复
     * 
     * @param historyId
     */
    public boolean recovery(String historyId) throws Exception{
        PizzaConfigHistoryPO po = getById(historyId);
        if (po == null) {
            throw new NullPointerException("history is null.");
        }        
        PizzaConfigHistoryValuePO historyValuePo = getValueById(historyId);
        
        String key = po.getPizzaKey();
        String group = po.getPizzaGroup();
        String pizzaValue = historyValuePo.getPizzaValue();// 内容
        String proId = po.getProjectId();
        String proName = po.getProjectName();

        ConfigSaveDTO dto = new ConfigSaveDTO();
        dto.setProjectId(proId);
        dto.setProjectName(proName);
        dto.setKey(key);
        dto.setGroup(group);
        dto.setValue(pizzaValue);
        dto.setOptype("1");

        int result = pizzaConfigServices.save(dto);

        return result == 2 ? false : true;
    }
    /**
     * 恢复
     * 
     * @param String proId, String group,String pizzaKey, String opterationType
     */
	@Override
	public List<PizzaConfigHistoryPO> search(String proId, String group,
			String pizzakey, String opterationType) {
		
		return pizzaConfigHistoryDAO.search(proId, group,pizzakey, opterationType);
	}
	
	@Override
	public boolean cleanUpRecord(String cleanBeforeThisTime, String projectId) {
		boolean flag = true;
		Date date = getDate(cleanBeforeThisTime);
		List<PizzaConfigHistoryPO> list = pizzaConfigHistoryDAO.cleanUpRecord(date, projectId);
		for(PizzaConfigHistoryPO po :list){
			pizzaConfigHistoryValueDAO.del(po.getHistoryId());
			pizzaConfigHistoryDAO.deleteHistoryPo(po.getHistoryId());
		}
		return flag;
	}
	
	@Override
	public long getRecordNum(String cleanBeforeThisTime, String projectId){
		
		Date date = getDate(cleanBeforeThisTime);
		return pizzaConfigHistoryDAO.getRecordNum(date, projectId);
	}
	
	private String[] parsePatterns = {"yyyy-MM-dd"};
	private Date getDate(String logDay) {
	        try {
	            Date beginDate = DateUtils.parseDate(logDay, parsePatterns);
	            return beginDate;
	        } catch (ParseException e) {
	            return new Date();
	        }
	}

    
}
