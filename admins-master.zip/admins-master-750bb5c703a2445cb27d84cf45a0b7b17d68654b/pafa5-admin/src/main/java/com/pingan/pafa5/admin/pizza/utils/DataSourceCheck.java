package com.pingan.pafa5.admin.pizza.utils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.Properties;

import org.springframework.util.StringUtils;

public class DataSourceCheck {
	public static int checkMaxActive(String content,int maxSize) {
		try {
			InputStream inputStream = new ByteArrayInputStream(content.getBytes("UTf-8"));
			if(inputStream!=null) {
				
				Properties properties = new Properties();
				properties.load(inputStream);
				
				if(properties.size()>0) {
					Object maxActiveO = properties.get("maxActive");
					if(!StringUtils.isEmpty(maxActiveO)) {
						int maxActive = Integer.parseInt(maxActiveO+"");
						if(maxActive>maxSize) {
							return maxActive;
						}
					}
				}
			}
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}
		return 0;
	}
}
