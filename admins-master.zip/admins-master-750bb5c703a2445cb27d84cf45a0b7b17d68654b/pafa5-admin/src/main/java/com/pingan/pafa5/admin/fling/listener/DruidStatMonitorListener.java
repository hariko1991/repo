package com.pingan.pafa5.admin.fling.listener;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

import org.apache.commons.beanutils.ConvertUtils;
import org.apache.commons.beanutils.converters.DateConverter;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.ServiceConfig;
import com.pingan.pafa.datasource.monitor.DruidStatMessageDTO;
import com.pingan.pafa.datasource.monitor.DruidStatMonitorDubboService;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.fling.dao.DruidDatasourceDAO;
import com.pingan.pafa5.admin.fling.dao.DruidDatasourceHistoryDAO;
import com.pingan.pafa5.admin.fling.po.DruidDatasourceHistoryPO;
import com.pingan.pafa5.admin.fling.po.DruidDatasourcePO;

public class DruidStatMonitorListener implements InitializingBean, DisposableBean {
	
	private Log logger = LogFactory.getLog(this.getClass());
	
	private ServiceConfig<DruidStatMonitorDubboService> serviceConfig;
	
	@Autowired
	private DruidDatasourceDAO druidDatasourceDAO;
	
	@Autowired
	private DruidDatasourceHistoryDAO druidDatasourceHistoryDAO;
	
	@Override
	public void afterPropertiesSet() throws Exception {
		serviceConfig = new ServiceConfig<DruidStatMonitorDubboService>();
		serviceConfig.setInterface(DruidStatMonitorDubboService.class);
		serviceConfig.setRef(new DruidStatMonitorDubboService() {

		@Override
		public void sendStatMsg(DruidStatMessageDTO msg) {
			if (logger.isDebugEnabled()) {
	            logger.debug("datasourceMsg=" + msg.toString());
	        }
			if(msg !=null){
				 Map<String,Object> map = new HashMap<String,Object>();
			        map.put("domainId", msg.getDomainId());
					map.put("pappName", msg.getPappName());
					map.put("instanceIp", msg.getInstanceIp());
					map.put("url", msg.getUrl());
				DruidDatasourcePO druidDatasource = druidDatasourceDAO.getDruidDatasourceByUrl(map);
				
				addAndUpadteDruidDataSource(druidDatasource, msg);
			}
		}});

		serviceConfig.export();
	}

	@Override
	public void destroy() throws Exception {
		if (serviceConfig != null) {
			try {
				serviceConfig.unexport();
			} catch (Exception ex) {
				//TODO
			}
			serviceConfig = null;
		}
	}

	public void addAndUpadteDruidDataSource(DruidDatasourcePO druidDataSource, DruidStatMessageDTO msg){
		ConvertUtils.register(new DateConverter(null), java.util.Date.class);  
		if(druidDataSource != null){
			POUtils.copyProperties(druidDataSource,msg);
			if(msg.getConnectionHoldTimeHistogram() != null && msg.getConnectionHoldTimeHistogram().length != 0){
				druidDataSource.setConnectionHoldTimeHistogram(POUtils.arrayToString(msg.getConnectionHoldTimeHistogram()));
			}
			if(msg.getTransactionHistogram() != null && msg.getTransactionHistogram().length != 0){
				druidDataSource.setConnectionHoldTimeHistogram(POUtils.arrayToString(msg.getConnectionHoldTimeHistogram()));
			}
			druidDataSource.setUpdatedDate(new Date());
			druidDatasourceDAO.update(druidDataSource);
			
			DruidDatasourceHistoryPO druidDatasourceHistory = new DruidDatasourceHistoryPO();
			POUtils.copyProperties(druidDatasourceHistory,druidDataSource);
			String uuid = UUID.randomUUID().toString();
			druidDatasourceHistory.setDruidDatasourceHistoryId(uuid);
			druidDatasourceHistory.setDruidDatasourceId(druidDataSource.getId());
			druidDatasourceHistory.setCreatedDate(new Date());
			druidDatasourceHistoryDAO.add(druidDatasourceHistory);
		}else{
			DruidDatasourcePO po = new DruidDatasourcePO();
			POUtils.copyProperties(po,msg);
			String id = UUID.randomUUID().toString();
			po.setId(id);
			
			if(msg.getConnectionHoldTimeHistogram() != null && msg.getConnectionHoldTimeHistogram().length != 0){
				po.setConnectionHoldTimeHistogram(POUtils.arrayToString(msg.getConnectionHoldTimeHistogram()));
			}
			if(msg.getTransactionHistogram() != null && msg.getTransactionHistogram().length != 0){
				po.setConnectionHoldTimeHistogram(POUtils.arrayToString(msg.getConnectionHoldTimeHistogram()));
			}
			po.setCreatedDate(new Date());
			druidDatasourceDAO.add(po);
			
			DruidDatasourceHistoryPO druidDatasourceHistory = new DruidDatasourceHistoryPO();
			POUtils.copyProperties(druidDatasourceHistory,po);
			String uuid = UUID.randomUUID().toString();
			druidDatasourceHistory.setDruidDatasourceHistoryId(uuid);
			druidDatasourceHistory.setDruidDatasourceId(id);
			druidDatasourceHistoryDAO.add(druidDatasourceHistory);
		}
	}
}
