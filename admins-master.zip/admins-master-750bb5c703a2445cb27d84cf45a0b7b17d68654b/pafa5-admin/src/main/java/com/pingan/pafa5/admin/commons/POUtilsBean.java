package com.pingan.pafa5.admin.commons;

import java.beans.PropertyDescriptor;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtilsBean;
import org.apache.commons.beanutils.ContextClassLoaderLocal;
import org.apache.commons.beanutils.Converter;
import org.apache.commons.beanutils.DynaBean;
import org.apache.commons.beanutils.DynaProperty;

/**
 * 解决
 * 
 * @author SHICHENGCHENG316
 * 
 */
public class POUtilsBean extends BeanUtilsBean {

	public static class UtilDateConverter implements Converter {

		public Object convert(Class clazz, Object arg1) {
			String p = (String) arg1;
			if (p == null || p.trim().length() == 0) {
				return null;
			}
			try {
				SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
				return df.parse(p.trim());
			} catch (Exception e) {
				try {
					SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
					return df.parse(p.trim());
				} catch (ParseException ex) {
					return null;
				}
			}
		}
	}

	private static final ContextClassLoaderLocal PO_BY_CLASSLOADER = new ContextClassLoaderLocal() {
		protected Object initialValue() {
			return new POUtilsBean();
		}
	};

	public static POUtilsBean getPOUtilsBeanInstance() {
		return (POUtilsBean) PO_BY_CLASSLOADER.get();
	}

	public static void setInstance(POUtilsBean newInstance) {
		PO_BY_CLASSLOADER.set(newInstance);
	}

	public void copyProperties(Object dest, Object orig) throws IllegalAccessException, InvocationTargetException {
		doCopyProperties(dest, orig, false);
	}

	public void copyPropertiesIgnoreNull(Object dest, Object orig) throws IllegalAccessException, InvocationTargetException {
		doCopyProperties(dest, orig, true);
	}

	private void doCopyProperties(Object dest, Object orig, boolean ignoreNull) throws IllegalAccessException, InvocationTargetException {
		if (dest == null) {
			throw new IllegalArgumentException("No destination bean specified");
		}
		if (orig == null) {
			throw new IllegalArgumentException("No origin bean specified");
		}

		if ((orig instanceof DynaBean)) {
			DynaProperty[] origDescriptors = ((DynaBean) orig).getDynaClass().getDynaProperties();
			for (int i = 0; i < origDescriptors.length; i++) {

				String name = origDescriptors[i].getName();
				if ((getPropertyUtils().isReadable(orig, name)) && (getPropertyUtils().isWriteable(dest, name))) {
					Object value = ((DynaBean) orig).get(name);

					if (ignoreNull == false) {
						copyProperty(dest, name, value);
					} else {
						// 跳过null值
						if (null == value)
							continue;
					}
				}

			}
		} else if ((orig instanceof Map)) {
			Iterator entries = ((Map) orig).entrySet().iterator();
			while (entries.hasNext()) {
				Map.Entry entry = (Map.Entry) entries.next();
				String name = (String) entry.getKey();
				if (getPropertyUtils().isWriteable(dest, name)) {

					if (ignoreNull == false) {
						copyProperty(dest, name, entry.getValue());
					} else {
						// 跳过null值
						if (null == entry.getValue())
							continue;
					}
				}
			}
		} else {
			PropertyDescriptor[] origDescriptors = getPropertyUtils().getPropertyDescriptors(orig);
			for (int i = 0; i < origDescriptors.length; i++) {
				String name = origDescriptors[i].getName();
				if (!"class".equals(name)) {
					if ((getPropertyUtils().isReadable(orig, name)) && (getPropertyUtils().isWriteable(dest, name))) {
						try {
							Object value = getPropertyUtils().getSimpleProperty(orig, name);

							if (ignoreNull == false) {
								copyProperty(dest, name, value);
							} else {
								// 跳过null值
								if (null == value)
									continue;
							}
						} catch (NoSuchMethodException e) {
						}
					}
				}
			}
		}
	}

}
