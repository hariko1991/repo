package com.pingan.pafa5.admin.pizza.po;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * redis历史操作记录
 * 
 * @author EX-YANGSHENGXIANG001
 */
@Document
public class PizzaConfigBackupPO {

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	@org.springframework.data.annotation.Id
	private String id;

	/**
	 * 版本id
	 */
	@Indexed
	private String versionId;

	/**
	 * 
	 */
	private int index;

	/**
	 * pizza分组
	 */
	private String pizzaGroup;

	/**
	 * pizza key
	 */
	private String pizzaKey;

	/**
	 * pizza value
	 */
	private String pizzaValue;

	/**
	 * md5值
	 */
	private String valueMd5;

	/**
	 * 项目ID
	 */
	@Indexed
	private String projectId;
	
	/**
	 * 项目名称
	 */
	@Indexed
	private String projectName;

	public String getPizzaGroup() {
		return pizzaGroup;
	}

	public void setPizzaGroup(String pizzaGroup) {
		this.pizzaGroup = pizzaGroup;
	}

	public String getPizzaKey() {
		return pizzaKey;
	}

	public void setPizzaKey(String pizzaKey) {
		this.pizzaKey = pizzaKey;
	}

	public String getPizzaValue() {
		return pizzaValue;
	}

	public void setPizzaValue(String pizzaValue) {
		this.pizzaValue = pizzaValue;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getVersionId() {
		return versionId;
	}

	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}

	public String getValueMd5() {
		return valueMd5;
	}

	public void setValueMd5(String valueMd5) {
		this.valueMd5 = valueMd5;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

}
