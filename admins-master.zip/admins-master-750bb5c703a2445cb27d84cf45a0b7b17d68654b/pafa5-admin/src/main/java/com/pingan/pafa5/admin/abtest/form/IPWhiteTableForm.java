package com.pingan.pafa5.admin.abtest.form;

public class IPWhiteTableForm {

	private String ip;

	public String getIp() {
		return ip;
	}

	public void setIp(String ip) {
		this.ip = ip;
	}
}