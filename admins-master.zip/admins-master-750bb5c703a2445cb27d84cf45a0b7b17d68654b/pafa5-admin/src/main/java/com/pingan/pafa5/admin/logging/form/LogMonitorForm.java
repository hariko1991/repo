package com.pingan.pafa5.admin.logging.form;

import com.paic.pafa.validator.annotation.DefinedRegex;
import com.paic.pafa.validator.annotation.VNotEmpty;
import com.paic.pafa.validator.annotation.VRegex;


public class LogMonitorForm {
	
	/**队列ID*/
	private String queueName;
	
	private String projectId;
	
	/**监控目标App*/
	@VNotEmpty
	@VRegex("^[\\w\\-\\.]+$")
	private String targetPapp;
	
	/**过期时间*/
	@VNotEmpty
	@VRegex(defined=DefinedRegex.Digitals)
	private Integer expiredTime;

	public String getQueueName() {
		return queueName;
	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getTargetPapp() {
		return targetPapp;
	}

	public void setTargetPapp(String targetPapp) {
		this.targetPapp = targetPapp;
	}

	public Integer getExpiredTime() {
		return expiredTime;
	}

	public void setExpiredTime(Integer expiredTime) {
		this.expiredTime = expiredTime;
	}
	
}
