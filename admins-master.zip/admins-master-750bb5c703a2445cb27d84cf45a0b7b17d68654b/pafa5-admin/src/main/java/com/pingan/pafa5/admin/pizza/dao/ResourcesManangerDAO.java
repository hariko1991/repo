package com.pingan.pafa5.admin.pizza.dao;

import java.util.List;

import com.pingan.pafa5.admin.pizza.po.ResourceFilePO;

public interface ResourcesManangerDAO {

	public abstract ResourceFilePO getById(String id);

	void add(ResourceFilePO po);

	boolean update(ResourceFilePO curPO);

	List<ResourceFilePO> list(String sarName, int limit, int page);

	long getCount(String sarName);

	boolean delete(ResourceFilePO po);

}