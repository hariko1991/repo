package com.pingan.pafa5.admin.pizza.dto;

import org.springframework.data.mongodb.core.index.Indexed;



/**
 * 配置信息 
 * @author EX-YANGSHENGXIANG001
 */
public class ConfigItemInfoDTO{

	//配置组(Group)名称
	private String groupName;
	//配置组(Group)编码
	private String group;
	//配置键(Key)
	private String key;
	//配置值(Value)
	private String value;
	//配置内容MD5签名
	private String valueMd5;
	
	//配置文件大小(chars)
	private Integer valueSize;
	
	@Indexed
	private String projectId;
	
	private String projectName;
	
	//访问文件的url
	private String uri;
	
	private String createdBy;
	
	private String createdDate;
	
	private String updatedBy;
	
	private String updatedDate;
	

	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	
	public String getUri() {
		return uri;
	}
	public void setUri(String uri) {
		this.uri = uri;
	}
	public String getGroupName() {
		return groupName;
	}
	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getUpdatedBy() {
		return updatedBy;
	}
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}
	public String getUpdatedDate() {
		return updatedDate;
	}
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	public String getValueMd5() {
		return valueMd5;
	}
	public void setValueMd5(String valueMd5) {
		this.valueMd5 = valueMd5;
	}
	public Integer getValueSize() {
		return valueSize;
	}
	public void setValueSize(Integer valueSize) {
		this.valueSize = valueSize;
	}
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedDate() {
		return createdDate;
	}
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}
	
	
}
