package com.pingan.pafa5.admin.pizza.listener;

//import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.Ordered;

import com.alibaba.dubbo.config.ProtocolConfig;
//import com.alibaba.dubbo.config.RegistryConfig;
import com.alibaba.dubbo.config.ServiceConfig;
import com.pingan.pafa.papp.protocol.dubbo.IDubboProtocol;
import com.pingan.pafa.pola.dubbo.ArtifactReadService;

public class DubboArtifactReadServiceListener implements InitializingBean, DisposableBean, Ordered {
	
	@Resource(name="_papp_dubbo")
	private IDubboProtocol _papp_dubbo;
	
	private ArtifactReadService artifactReadService;
	
	private boolean exportService=true;
	
	private ServiceConfig<ArtifactReadService> _serviceConfig;
	
	@Value(value="${dubbo.lib.service.timeout}")
	private Integer rmiTimeout;
	
	public DubboArtifactReadServiceListener(){
		
	}
	
	public DubboArtifactReadServiceListener(ArtifactReadService artifactReadService){
		this.artifactReadService = artifactReadService;
	}
	
	@Override
	public void destroy() throws Exception {
		if(_serviceConfig!=null){
			try{
				_serviceConfig.unexport();
			}catch(Exception ex){
				
			}
			_serviceConfig=null;
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		if(this.exportService){
			_serviceConfig= new ServiceConfig<ArtifactReadService>();
			_serviceConfig.setInterface(ArtifactReadService.class);
			ProtocolConfig protocolConfig = new ProtocolConfig();
			_serviceConfig.setProtocol(protocolConfig);
			_serviceConfig.setRef(artifactReadService);
			_serviceConfig.setInterface(ArtifactReadService.class);
			//--------------------------
			_serviceConfig.export();
		}
	}

	

	public ArtifactReadService getArtifactReadService() {
		return artifactReadService;
	}

	public void setArtifactReadService(ArtifactReadService artifactReadService) {
		this.artifactReadService = artifactReadService;
	}

	public ServiceConfig<ArtifactReadService> get_serviceConfig() {
		return _serviceConfig;
	}

	public void set_serviceConfig(ServiceConfig<ArtifactReadService> _serviceConfig) {
		this._serviceConfig = _serviceConfig;
	}

	public boolean isExportService() {
		return exportService;
	}

	public void setExportService(boolean exportService) {
		this.exportService = exportService;
	}

	@Override
	public int getOrder() {
		return Ordered.HIGHEST_PRECEDENCE;
	}

}
