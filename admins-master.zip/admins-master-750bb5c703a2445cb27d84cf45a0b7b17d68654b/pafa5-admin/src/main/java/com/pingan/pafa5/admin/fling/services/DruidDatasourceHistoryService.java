package com.pingan.pafa5.admin.fling.services;

public interface DruidDatasourceHistoryService {
	
	public boolean deleteYesterday();

}
