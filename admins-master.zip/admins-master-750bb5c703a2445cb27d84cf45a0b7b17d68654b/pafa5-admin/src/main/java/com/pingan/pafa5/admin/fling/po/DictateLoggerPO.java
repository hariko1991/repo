package com.pingan.pafa5.admin.fling.po;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.pingan.pafa5.admin.commons.BasePO;

/**
 * 管控指令日志记录
 * 
 * @author ZHANGGANG871
 * 
 */
@Document
public class DictateLoggerPO extends BasePO {

    /**
     * 指令ID
     */
    @Id
    private String id;
    /**
     * 所属项目
     */
    private String projectId;
    
    /**
     * 目标地址
     */
    private String instanceIp;
    /**
     * 目标名 papp名或者sar名
     */
    private String posName;
    /**
     * 目标类型 papp：应用 sar：组件
     */
    private String posType;
    /**
     * 指令
     */
    private String dictateName;
    /**
     * 执行指令获取回执结果ID
     */
    private String dictateId;
    /**
     * 执行结果
     */
    private String result;
    /**
     * 失败原因
     */
    private String cause;


    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getInstanceIp() {
        return instanceIp;
    }

    public void setInstanceIp(String instanceIp) {
        this.instanceIp = instanceIp;
    }

    public String getPosName() {
        return posName;
    }

    public void setPosName(String posName) {
        this.posName = posName;
    }

    public String getPosType() {
        return posType;
    }

    public void setPosType(String posType) {
        this.posType = posType;
    }

    public String getDictateName() {
        return dictateName;
    }

    public void setDictateName(String dictateName) {
        this.dictateName = dictateName;
    }

    public String getDictateId() {
        return dictateId;
    }

    public void setDictateId(String dictateId) {
        this.dictateId = dictateId;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    @Override
    public String toString() {
        return "DictateLoggerPO [id=" + id + ", projectId=" + projectId + ", instanceIp="
                + instanceIp + ", posName=" + posName + ", posType=" + posType + ", dictateName="
                + dictateName + ", dictateId=" + dictateId + ", result=" + result + ", cause="
                + cause + ", getCreatedBy()=" + getCreatedBy() + ", getCreatedDate()="
                + getCreatedDate() + ", getUpdatedBy()=" + getUpdatedBy() + ", getUpdatedDate()="
                + getUpdatedDate() + ", getRequestId()=" + getRequestId() + ", getClass()="
                + getClass() + ", hashCode()=" + hashCode() + ", toString()=" + super.toString()
                + "]";
    }

}
