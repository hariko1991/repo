package com.pingan.pafa5.admin.pizza.dao.impl;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.pizza.dao.FileTempDAO;
import com.pingan.pafa5.admin.pizza.po.FileTempPO;

@Nosql
@Repository
public class FileTempDAOImpl extends BaseMongoDAO<FileTempPO> implements
		FileTempDAO {

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.pingan.pafa5.admin.pizza.dao.impl.FileTempDAO#saveFileTemp(com.pingan
	 * .pafa5.admin.pizza.po.FileTempPO)
	 */
	@Override
	public void saveFileTemp(FileTempPO po) {
		this._save(po);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.pingan.pafa5.admin.pizza.dao.impl.FileTempDAO#getFileTempById(java
	 * .lang.String)
	 */
	@Override
	public FileTempPO getFileTempById(String uuid) {
		return this._getById(uuid);
	}

	@Override
	public void delFileTempById(String uuid) {
		this._removeById(uuid);
	}

}
