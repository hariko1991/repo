package com.pingan.pafa5.admin.pizza.dao.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.dao.DataAccessException;
import org.springframework.data.mongodb.core.DocumentCallbackHandler;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.mongodb.DBObject;
import com.mongodb.MongoException;
import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.pizza.dao.PizzaConfigBackupDAO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigBackupPO;

@Nosql
@Repository
public class PizzaConfigBackupDAOImpl extends BaseMongoDAO<PizzaConfigBackupPO> implements PizzaConfigBackupDAO{

	@Override
	public void add(PizzaConfigBackupPO po) {
		this._add(po);
	}

	@Override
	public void add(List<PizzaConfigBackupPO> pos) {
		this._add(pos);
	}
	
	
	public List<String> listKeys(String proId, String versionId, String pizzaGroup) {
		Query query=new Query();
		Criteria where=where("versionId").is(versionId).and("pizzaGroup").is(pizzaGroup).and("projectId").is(proId);
		
		query.addCriteria(where);
		query.fields().include("pizzaKey");
		final List<String> keys=new ArrayList<String>(32);
		this._listQuery(query,new DocumentCallbackHandler(){

			@Override
			public void processDocument(DBObject paramDBObject)
					throws MongoException, DataAccessException {
				keys.add((String)paramDBObject.get("pizzaKey"));
			}
			 
		});
		if(keys.size()==0){
			return null;
		}
		return keys;
	}
	
	@Override
	public List<String> listKeys(String versionId, String pizzaGroup) {
		Query query=new Query();
		Criteria where=where("versionId").is(versionId).and("pizzaGroup").is(pizzaGroup).and("projectId").is(null);
		
		query.addCriteria(where);
		query.fields().include("pizzaKey");
		final List<String> keys=new ArrayList<String>(32);
		this._listQuery(query,new DocumentCallbackHandler(){

			@Override
			public void processDocument(DBObject paramDBObject)
					throws MongoException, DataAccessException {
				keys.add((String)paramDBObject.get("pizzaKey"));
			}
			 
		});
		if(keys.size()==0){
			return null;
		}
		return keys;
	}

	@Override
	public PizzaConfigBackupPO getById(String proId, String versionId, String pizzaGroup,
			String pizzaKey) {
		Criteria where=this.where("versionId").is(versionId).and("pizzaGroup").is(pizzaGroup)
				.and("pizzaKey").is(pizzaKey).and("projectId").is(proId);
		return this._get(where);
	}
	
	@Override
	public PizzaConfigBackupPO getById(String versionId, String pizzaGroup,
			String pizzaKey) {
		Criteria where=this.where("versionId").is(versionId).and("pizzaGroup").is(pizzaGroup)
				.and("pizzaKey").is(pizzaKey).and("projectId").is(null);
		return this._get(where);
	}

	@Override
	public long checkCount(String projectId, String versionId) {
		Criteria criteria=this.where("versionId").is(versionId).and("projectId").is(projectId);
		return this._count(criteria);
	}


	/*@Override
	public List<PizzaConfigBackupPO> list(String versionId, String pizzaGroup) {
		return this.list(versionId, pizzaGroup,-1,-1);
	}

	@Override
	public List<PizzaConfigBackupPO> list(String versionId, String pizzaGroup,
			int limitSize, int beginIndex) {
		Criteria where=this.where("versionId").is(versionId).and("pizzaGroup").is(pizzaGroup);
		if(beginIndex>0){
			where.and("index").gt(beginIndex);
		}
		Query query=new Query(where);
		if(limitSize>0){
			query.limit(limitSize);
		}
		return this._listQuery(query);
	}*/

}
