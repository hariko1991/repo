package com.pingan.pafa5.admin.fling.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.fling.dao.FlingCommandResultDAO;
import com.pingan.pafa5.admin.fling.po.FlingCommandResultPO;

@Nosql
@Repository
public class FlingCommandResultDAOImpl extends  BaseMongoDAO<FlingCommandResultPO> implements FlingCommandResultDAO{

	@Override
	public void add(FlingCommandResultPO po) {
		this._add(po);
	}

	@Override
	public List<FlingCommandResultPO> listByCommandId(String commandId) {
		return this._list(where("rid").is(commandId));
	}

}
