package com.pingan.pafa5.admin.fling.services.impl;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ScheduledExecutorService;

import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.ui.ModelMap;

import com.paic.pafa.biz.services.BaseServices;
import com.paic.pafa.utils.MDCUtil;
import com.pingan.pafa5.admin.fling.dao.FlingSARInstanceDAO;
import com.pingan.pafa5.admin.fling.po.FlingSARInstancePO;
import com.pingan.pafa5.admin.fling.services.ServiceDetectionService;

@Service
public class ServiceDetectionServiceImpl extends BaseServices implements ServiceDetectionService,DisposableBean,InitializingBean {
	private CloseableHttpClient httpclient = null;

	@Override
	public int processDubboAdmin(String sarName,String instanceIp) {
		String url = System.getProperty("service.echo.url", "http://localhost:8080/governance/applications/${sarName}/addresses");
		try {
			if (StringUtils.isNotEmpty(url) && StringUtils.isNotEmpty(sarName)) {
				url = url.replace("${sarName}", sarName);
				String htmlContent = get(url);
				if(StringUtils.isNotEmpty(htmlContent)) {
					if(validate(htmlContent,instanceIp)) {
						return 4;//正常
					}else {
						return 5;
					}
				}
			} else {
				return 1;
			}
		} catch (Exception e) {
			e.printStackTrace();
			return 2;
		}
		return 3;
	}

	private boolean validate(String htmlContent,String instanceIp) {
		long s = System.nanoTime();
		boolean bool = false;
		Document document = Jsoup.parse(htmlContent);
		Element element = document.getElementById("table_o");
		if(element!=null) {
			Elements elements = element.getElementsByTag("tr");
			if(elements!=null&&elements.size()>0) {
				for (int i=0;i< elements.size();i++) {
					if(i!=0) {
						Element element2 = elements.get(i);
						if(element2!=null) {
							Elements elements2 = element2.getElementsByTag("td");
							Element element3 = elements2.get(0);
							Element element4 = elements2.get(1);
							if("提供者".equals(element4.text())) {
								if(element3.text().contains(instanceIp)) {
									bool = true;
									break;
								}
							}
						}
					}
				}
			}
		}else {
			
		}
		logger.info("解析html耗时"+(System.nanoTime()-s)/1000/1000.0+"ms");
		return bool;
	}
	
	/**
	 * 发送 post请求访问本地应用并根据传递参数不同返回不同结果
	 */
	public String get(String url) {
		long s = System.nanoTime();
		// 创建默认的httpClient实例.
		String httpContent="";
		// 创建httppost
		HttpGet httppost = new HttpGet(url);
		// 创建参数队列
		// List<E> formparams = new ArrayList();
		// formparams.add(new BasicNameValuePair("type", "house"));
		// UrlEncodedFormEntity uefEntity;
		try {
			// uefEntity = new UrlEncodedFormEntity(formparams, "UTF-8");
			// httppost.setEntity(uefEntity);
			logger.info("executing request " + httppost.getURI());
			CloseableHttpResponse response = httpclient.execute(httppost);
			try {
				if(200==response.getStatusLine().getStatusCode()) {
					HttpEntity entity = response.getEntity();
					if (entity != null) {
						//System.out.println("--------------------------------------");
						//System.out.println("Response content: " + EntityUtils.toString(entity, "UTF-8"));
						//System.out.println("--------------------------------------");
						httpContent = EntityUtils.toString(entity, "UTF-8");
					}
				}
			} finally {
				response.close();
			}
		} catch (ClientProtocolException e) {
			e.printStackTrace();
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			logger.info("调用耗时"+(System.nanoTime()-s)/1000/1000.0+"ms");
		}
		return httpContent;
	}

	private ScheduledExecutorService scheduledThreadPool = null;
	
	@Override
	public void afterPropertiesSet() throws Exception {
	    RequestConfig requestConfig = RequestConfig.custom()  
                .setConnectionRequestTimeout(500)   //从连接池中获取连接的超时时间  
                        //与服务器连接超时时间：httpclient会创建一个异步线程用以创建socket连接，此处设置该socket的连接超时时间  
                .setConnectTimeout(500)
                .setSocketTimeout(3000)               //socket读数据超时时间：从服务器获取响应数据的超时时间  
                .build();  
	    if(httpclient==null) {
	    	httpclient = HttpClientBuilder.create()
                .setMaxConnTotal(50)//连接池中最大连接数  
                        /** 
                         * 分配给同一个route(路由)最大的并发连接数。 
                         * route：运行环境机器 到 目标机器的一条线路。 
                         * 举例来说，我们使用HttpClient的实现来分别请求 www.baidu.com 的资源和 www.bing.com 的资源那么他就会产生两个route。 
                         */  
                .setMaxConnPerRoute(50)  
                .setDefaultRequestConfig(requestConfig)  
                .build();  
	    }
		if(httpclient==null) {
			httpclient = HttpClients.createDefault();
		}
		if(scheduledThreadPool==null) {
			scheduledThreadPool = Executors.newScheduledThreadPool(20);
		}
		
	}

	@Override
	public void destroy() throws Exception {
		if(httpclient!=null) {
			httpclient.close();
		}
		if(scheduledThreadPool!=null) {
			scheduledThreadPool.shutdown();
		}
	}
	
	@Autowired
	private FlingSARInstanceDAO flingSARInstanceDAO;
	
	@Override
	public void processDubboAdmin(List<ModelMap> map) throws InterruptedException, ExecutionException {
		if(map!=null&&map.size()>0) {
			List<Future<Boolean>> results = new ArrayList<Future<Boolean>>(map.size());
			CountDownLatch latch = new CountDownLatch(map.size());
			for (ModelMap modelMap : map) {
				Future<Boolean> future = scheduledThreadPool.submit(new MyCallable(latch,modelMap,this));
                results.add(future);
			}
			latch.await();
		}
	}
	
	private class MyCallable implements Callable<Boolean> {
		private ModelMap modelMap;
		private CountDownLatch latch;
		private ServiceDetectionService serviceDetectionService;
		
		public MyCallable(CountDownLatch latch,ModelMap modelMap,ServiceDetectionService serviceDetectionService) {
			this.serviceDetectionService = serviceDetectionService;
			this.latch = latch;
			this.modelMap = modelMap;
		}
		
        public Boolean call() throws Exception {
        	try {
        		MDCUtil.set(Thread.currentThread().getName());
        		Object instanceIp = modelMap.get("instanceIp");
				Object sarName = modelMap.get("sarName");
				Object status = modelMap.get("status");
				int serviceStatus = this.serviceDetectionService.processDubboAdmin(sarName+"", instanceIp+"");
				modelMap.put("serviceStatus",serviceStatus);
				if(serviceStatus==4) {
					if("2".equals(status)) {
						Object projectId = modelMap.get("projectId");
						FlingSARInstancePO po = new FlingSARInstancePO();
						po.setSarName(sarName+"");
						po.setProjectId(projectId+"");
						po.setInstanceIp(instanceIp+"");
						po.setStatus(0);
						po.setUpdatedBy("补偿修正");
						flingSARInstanceDAO.updateStatus(po);
						modelMap.put("status",0);
					}
				}
				return true;
			} finally {
				latch.countDown();
				MDCUtil.clear();
			}
        }

    }
}
