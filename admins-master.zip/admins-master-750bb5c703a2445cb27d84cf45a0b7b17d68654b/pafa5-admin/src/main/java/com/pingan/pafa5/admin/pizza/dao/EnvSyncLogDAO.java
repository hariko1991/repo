package com.pingan.pafa5.admin.pizza.dao;

import java.util.List;
import java.util.Map;

import com.pingan.pafa5.admin.pizza.po.EnvSyncLogPO;

public interface EnvSyncLogDAO {

	public List<EnvSyncLogPO> list(Map<String,Object> queryParams, int page, int limit);

	public long getCount(Map<String,Object> queryParams);

	public String add(EnvSyncLogPO po);

	public boolean update(EnvSyncLogPO po);

	public EnvSyncLogPO findById(String id);

}