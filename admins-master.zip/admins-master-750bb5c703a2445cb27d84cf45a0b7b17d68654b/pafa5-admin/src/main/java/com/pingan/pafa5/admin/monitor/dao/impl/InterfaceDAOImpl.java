package com.pingan.pafa5.admin.monitor.dao.impl;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.monitor.dao.InterfaceDAO;
import com.pingan.pafa5.admin.monitor.dtos.InterfaceDTO;
import org.springframework.stereotype.Repository;

import java.util.List;

@Nosql
@Repository
public class InterfaceDAOImpl extends BaseMongoDAO<InterfaceDTO> implements InterfaceDAO {

	public void add(InterfaceDTO interfaceDTO){
		this._add(interfaceDTO);
	} 
	
	public InterfaceDTO getByProperty(String value1,String value2){
		return this._get(where("interfaceName").is(value1).and("method").is(value2));
	}
	
	public List<InterfaceDTO> findAll(){
		List<InterfaceDTO> list = this._list(where("interfaceName").ne(""));
		return list;
	}
	
	public int removeByProperty(String name ,String value){
		return this._removeByProperty(name, value);
	}
}
