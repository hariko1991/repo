package com.pingan.pafa5.admin.pizza.web;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.validator.annotation.Valid;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dto.OperationLogSearchDTO;
import com.pingan.pafa5.admin.pizza.po.PizzaOperationLogPO;
import com.pingan.pafa5.admin.pizza.po.PizzaRecoveryRegisterLogPo;
import com.pingan.pafa5.admin.pizza.services.BackupRecoveryService;

@Controller
@RequestMapping("/pizzamgr")
public class BackupRecoveryController extends BaseController {

    @Autowired
    private BackupRecoveryService backupRecoveryService;

    @Value("${recovery.web.enable}")
    private boolean recoveryEnable;

    /**
     * 查询备份列表
     * @param form
     * @return
     * @throws Throwable
     */
    @RequestMapping("/operation-log-search.do")
    @ResponseBody
    public ResponseModel search(@Valid OperationLogSearchDTO form) throws Throwable {
        if (logger.isInfoEnabled()) {
            logger.info("Form:" + JSONObject.toJSONString(form));
        }
        PageDataDTO<PizzaOperationLogPO> pageDatas = backupRecoveryService.search(form);

        List<PizzaOperationLogPO> dblist = pageDatas.getDatas();
        List<ModelMap> configItems = new ArrayList<ModelMap>();
        if (dblist != null && dblist.size() >= 0) {
            if (logger.isInfoEnabled()) {
                logger.info("datasize is:" + dblist.size());
            }
            for (PizzaOperationLogPO to : dblist) {
                ModelMap map = new ModelMap();
                map.put("id", to.getId());
                map.put("operationType", to.getOperationType());
                map.put("operationName", to.getOperationName());
                map.put("operationReason", to.getOperationReason());
                map.put("status", to.getStatus());
                map.put("projectId", to.getProjectId());
                map.put("projectName", to.getProjectName());
                map.put("remark", to.getRemark());
                map.put("updateBy", to.getUpdatedBy());
                map.put("updateDate", to.getUpdatedDate().getTime());
                map.put("createdBy", to.getCreatedBy());
                if(to.getCreatedDate()!=null){
					map.put("createdDate", to.getCreatedDate().getTime());
				}else{
					Date date=new Date();
					SimpleDateFormat Standformat=new SimpleDateFormat("yyyy-MM-dd  HH:mm:ss");
					String createdDate=Standformat.format(date);
					map.put("createdDate", createdDate);
				}
                map.put("operationIp", to.getOperationIp());
                configItems.add(map);
            }
        } else {
            if (logger.isInfoEnabled()) {
                logger.info("datasize is:" + 0);
            }
        }
        ResponseModel model = new ResponseModel();
        model.put("totalProperty", pageDatas.getTotalSize());
        model.put("root", configItems);
        return model;
    }

    /**
     * 恢复DB配置到配置中心
     * 
     * @param operationReason
     * @param request
     * @param response
     * @return
     */
    @RequestMapping("/sync-db-to-cache.do")
    @ResponseBody
    public ModelMap recoveryRegister(
            @RequestParam(value = "targetDomainId", defaultValue = "ALL") String targetDomainId,
            @RequestParam(value = "targetDomainName", defaultValue = "全量") String targetDomainName,
            @RequestParam(value = "operationReason", defaultValue = "未知") String operationReason,
            HttpServletRequest request, HttpServletResponse response) {

        ModelMap result = new ModelMap();
        try {
            if (!recoveryEnable) {
                result.put("msg", "恢复开关未开启，请修改系统配置。");
                result.put("success", false);
                return result;
            }
            backupRecoveryService.recoveryRegister(targetDomainId, targetDomainName, operationReason);
            result.put("success", true);
            result.put("msg", "恢复任务提交成功，请等待。");
        } catch (ResponseCodeException e) {
            result.put("msg", e.getResponseMsg());
            result.put("success", false);
            logger.error(e.getMessage(), e);
        }catch (Throwable e) {
            result.put("msg", "恢复任务提交失败，请检查系统日志。");
            result.put("success", false);
            logger.error(e.getMessage(), e);
        }
        return result;
    }

    @RequestMapping("/get-sync-db-to-cache-errorlog.do")
    @ResponseBody
    public ModelMap getRecoveryRegisterErrorLog(
            @RequestParam(value = "logId") String logId,
            String projectId,
            HttpServletRequest request, HttpServletResponse response) {
    	ResponseModel result = new ResponseModel("0","成功");
        try {	
        	 List<PizzaRecoveryRegisterLogPo> logPos = backupRecoveryService.getErrorLog(logId, projectId);
        	 result.put("logPos", logPos);
        } catch (ResponseCodeException e) {
            result.put("msg", e.getResponseMsg());
            result.put("success", false);
            logger.error(e.getMessage(), e);
        }catch (Throwable e) {
            result.put("msg", "恢复任务提交失败，请检查系统日志。");
            result.put("success", false);
            logger.error(e.getMessage(), e);
        }
        return result;
    }
    
    /**
     * 备份数据库
     * 
     * @param operationReason
     * @param request
     * @param response
     * @return
     */
    @RequestMapping("/backup.do")
    @ResponseBody
    public ModelMap backup(
            @RequestParam(value = "targetDomainId", defaultValue = "ALL") String targetDomainId,
            @RequestParam(value = "targetDomainName", defaultValue = "全量") String targetDomainName,
            @RequestParam(value = "operationReason", defaultValue = "未知") String operationReason,
            HttpServletRequest request, HttpServletResponse response) {
        ModelMap result = new ModelMap();
        String versionId = "";
        try {
            versionId = backupRecoveryService.backup(targetDomainId, targetDomainName, operationReason);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            result.put("msg", "备份出错，请联系管理员");
            result.put("success", false);
            return result;
        }
        result.put("msg", (versionId == null || "".equals(versionId)) ? "备份失败" : "备份成功");
        result.put("success", (versionId == null || "".equals(versionId)) ? false : true);
        return result;
    }

    /**
     * 回滚数据库
     * 
     * @param referOperationId
     * @param operationReason
     * @param request
     * @param response
     * @return
     */
    @SuppressWarnings("finally")
	@RequestMapping("/rollback.do")
    @ResponseBody
    public ModelMap rollback(
            @RequestParam(value = "referOperationId", required = true) String referOperationId,
            @RequestParam(value = "operationReason", defaultValue = "未知") String operationReason,
            HttpServletRequest request, HttpServletResponse response) {
        ModelMap result = new ModelMap();
        try {
            String versionId = backupRecoveryService.rollback(referOperationId, operationReason);
            //通过检查文件数量确保回滚状态显示和业务处理结果一致
            if("".equals(versionId)||versionId==null){
            	//logger.info("回滚失败！请稍后重试！其他的备份、回滚或恢复配置中心的任务正在执行中...");
                result.put("msg", "回滚失败！请稍后重试！其他的备份、回滚或恢复配置中心的任务正在执行中...");
                result.put("success", false);
                throw new ResponseCodeException("456","回滚失败！请稍后重试！其他的备份、回滚或恢复配置中心的任务正在执行中...");
            }else{
                result.put("msg", "回滚成功");
                result.put("success", true);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            result.put("success", false);
            result.put("msg", "回滚出错，请联系管理员");
            throw new ResponseCodeException("456","回滚出错！");
        }finally{
        	return result;
        }
    }

    public void setBackupRecoveryService(BackupRecoveryService backupRecoveryService) {
        this.backupRecoveryService = backupRecoveryService;
    }

    public void setRecoveryEnable(boolean recoveryEnable) {
        this.recoveryEnable = recoveryEnable;
    }

}
