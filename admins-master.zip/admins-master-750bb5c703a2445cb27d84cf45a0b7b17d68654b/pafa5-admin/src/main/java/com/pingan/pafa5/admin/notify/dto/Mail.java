package com.pingan.pafa5.admin.notify.dto;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.mail.javamail.MimeMessageHelper;

public class Mail extends MimeMessageHelper {

    private String templateName;

    private List<String> toList = new ArrayList<String>();

    private List<String> ccList = new ArrayList<String>();

    private Map<String, Object> context = new HashMap<String, Object>();

    public Mail(MimeMessage mimeMessage) {
        super(mimeMessage);
    }

    public Object put(String key, Object value) {
        return context.put(key, value);
    }

    public String getSubject() throws MessagingException {
        return super.getMimeMessage().getSubject();
    }

    public String getTemplateName() {
        return templateName;
    }

    public void setTemplateName(String templateName) {
        this.templateName = templateName;
    }

    public List<String> getToList() {
        return toList;
    }

    public void setToList(List<String> toList) {
        this.toList = toList;
    }

    public List<String> getCcList() {
        return ccList;
    }

    public void setCcList(List<String> ccList) {
        this.ccList = ccList;
    }

    public Map<String, Object> getContext() {
        return context;
    }

    public void setContext(Map<String, Object> context) {
        this.context = context;
    }

}
