package com.pingan.pafa5.admin.fling.job;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.paic.pafa.job.TimerJob;
import com.pingan.pafa.redis.lock.RedisLock;
import com.pingan.pafa.redis.lock.RedisLockFactory;
import com.pingan.pafa5.admin.fling.services.DruidDatasourceHistoryService;

/**
 * 运维中心-管控指令数据清理
 * 
 * @author ZHANGJIAWEI370
 * 
 */
@Component
public final class DruidDatasourceHistoryClearJob {
	private static final String LOCK_OBJ_ID = "pizza-dubbo-druid-clear";
	private Log logger = LogFactory.getLog(this.getClass());
	//
	@Autowired
	private RedisLockFactory lockFactory;

	@Autowired
	private DruidDatasourceHistoryService druidDatasourceHistoryService;

	@Value("${clear.druid.datasource.history.enable}")
	private boolean clearDruidDatasourceHistory;

	//
	@TimerJob(cronExpression = "${job.ex.druid.datasource.history.clean.time}")
	public void execute() throws Exception {
		if (clearDruidDatasourceHistory) {

			RedisLock lock = lockFactory.getLock(LOCK_OBJ_ID + System.getProperty("env.lock", ""));
			if (lock.tryLock()) {
				try {
					logger.info("开始清理druid监控数据★★★★★★★★★★★★★★★★★★★★★★★★★★★");
					druidDatasourceHistoryService.deleteYesterday();
					logger.info("结束清理druid监控数据★★★★★★★★★★★★★★★★★★★★★★★★★★★");
				} finally {
					lock.unlock();
				}
			}

		}
	}
	//
	// public void setFlingCommandServices(FlingCommandServices
	// flingCommandServices) {
	// this.flingCommandServices = flingCommandServices;
	// }

}
