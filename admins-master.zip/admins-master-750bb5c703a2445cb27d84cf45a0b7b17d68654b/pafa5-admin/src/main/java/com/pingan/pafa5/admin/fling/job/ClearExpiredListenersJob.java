package com.pingan.pafa5.admin.fling.job;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paic.pafa.job.TimerJob;
import com.pingan.pafa5.admin.commons.FlingCommandHolder;

/**
 * 清除过期指令执行结果数据
 * @author EX-YANGSHENGXIANG001
 */
@Component
public final class ClearExpiredListenersJob {

	@Autowired
	private FlingCommandHolder flingCommandHolder;
	
	@TimerJob(cronExpression="${job.ex.clearExpiredListeners.time}")
	public void execute()  {
		flingCommandHolder.clearExpiredListeners();
	}
	
}
