package com.pingan.pafa5.admin.papp.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.DocumentCallbackHandler;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.mongodb.DBObject;
import com.mongodb.MongoException;
import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa.mongodb.MongoPagination;
import com.pingan.pafa5.admin.Constants;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.commons.SARManagerConstants;
import com.pingan.pafa5.admin.papp.dao.GardenPizzaConfigDAO;
import com.pingan.pafa5.admin.pizza.dao.PizzaConfigDAO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSearchDTO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigPO;

@Nosql
@Repository
public class GardenPizzaConfigDAOImpl extends BaseMongoDAO<PizzaConfigPO> implements
		GardenPizzaConfigDAO {

	

	@Override
	public List<String> listKeys(String group, String pizzaKeyRegex) {
		Query query = new Query();
		Criteria where = where("pizzaGroup").is(group).and("projectId")
				.is(null);
		if (pizzaKeyRegex != null && pizzaKeyRegex.length() > 0) {
			where.and("pizzaKey").regex(Pattern.compile(pizzaKeyRegex));
		}
		query.addCriteria(where);
		query.fields().include("pizzaKey");
		query.with(new Sort(Direction.ASC, "pizzaKey"));
		final List<String> keys = new ArrayList<String>(32);
		this._listQuery(query, new DocumentCallbackHandler() {

			@Override
			public void processDocument(DBObject paramDBObject)
					throws MongoException, DataAccessException {
				keys.add((String) paramDBObject.get("pizzaKey"));
			}

		});
		if (keys.size() == 0) {
			return null;
		}
		return keys;
	}

	@Override
	public List<String> listKeys(String proId, String group,
			String pizzaKeyRegex) {
		Query query = new Query();
		Criteria criteria = where("projectId").is(proId).and("pizzaGroup")
				.is(group);
		if (pizzaKeyRegex != null && pizzaKeyRegex.length() > 0) {
			criteria.and("pizzaKey").regex(Pattern.compile(pizzaKeyRegex));
		}
		query.addCriteria(criteria);
		query.fields().include("pizzaKey");
		query.with(new Sort(Direction.ASC, "pizzaKey"));
		final List<String> keys = new ArrayList<String>(32);
		this._listQuery(query, new DocumentCallbackHandler() {
			@Override
			public void processDocument(DBObject paramDBObject)
					throws MongoException, DataAccessException {
				keys.add((String) paramDBObject.get("pizzaKey"));
			}
		});
		if (keys.size() == 0) {
			return null;
		}
		return keys;
	}

	}
