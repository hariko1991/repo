package com.pingan.pafa5.admin.papp.web;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.text.DateFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.validator.annotation.Valid;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa.pizza.PizzaConstants;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.commons.SARManagerConstants;
import com.pingan.pafa5.admin.commons.SqlUtils;
import com.pingan.pafa5.admin.papp.dao.PappManagerDAO;
import com.pingan.pafa5.admin.papp.dto.PappDTO;
import com.pingan.pafa5.admin.papp.dto.PappManagerDTO;
import com.pingan.pafa5.admin.papp.form.SaveDubboConfigForm;
import com.pingan.pafa5.admin.papp.po.PappManagerPO;
import com.pingan.pafa5.admin.papp.services.PappManagerService;
import com.pingan.pafa5.admin.sar.dao.SARManagerDAO;
import com.pingan.pafa5.admin.sar.po.SARManagerPO;
import com.pingan.pafa5.admin.systems.po.MemberPO;

/**
 * 应用管理 2016-6-14 13:42:07
 * 
 * @author HOUSHANGZHI377
 * 
 */
@Controller
public class PappManagerController extends BaseController {
	private static final Log log = LogFactory.getLog(PappManagerController.class);
	
	@Autowired
	private PappManagerDAO pappManagerDAO;
	
	@Autowired
	private PappManagerService pappManagerService;

	@ActionClient(name = "pafa5-admin-usere.getUserInfoById")
	private IServiceClient userServices;

	@ActionClient(name = "pafa5-admin-systems.findSystemById")
	private IServiceClient systemServices;

	@ActionClient(name = "pafa5-admin-systems.findUserProjects")
	private IServiceClient systemFindUserProjects;

	@ActionClient(name = "pafa5-admin-systems.group-members")
	private IServiceClient getGroupMemberClient;

	@ActionClient(name = "pafa5_admin_pizza.getConfigItem")
	private IServiceClient getConfigItemClient;

	@ActionClient(name = "pafa5-admin-pizza.saveConfig")
	private IServiceClient saveConfigClient;

	@ActionClient(name = "pafa5_admin_pizza.search")
	private IServiceClient pappSearchService;

	/**
	 * 根据条件查询应用列表
	 * 
	 * @param form
	 * @return
	 * @throws ParseException
	 */
	@RequestMapping("/papp/papp-list.do")
	@ResponseBody
	public ResponseModel listUserPapp(PappManagerDTO form) throws ParseException {
		DateFormat formatter = DateFormat.getDateTimeInstance();
		ServiceParams params = ServiceParams.newInstance().set("group", PizzaConstants.GROUP_PAPP);
		String pappName = form.getPappName() == null ? "" : form.getPappName();

		if (SqlUtils.SPRING_PROFILE_NOSQL.equalsIgnoreCase(SqlUtils.getSpringProfilesActive())) {
			String parttern = "^" + pappName + "[\\w\\-\\.]*\\.properties$";
			params.set("likeKey", parttern);
		} else {
			String parttern = pappName + "%.properties";
			params.set("likeKey", parttern);
		}

		params.set("projectId", form.getSystemsId());
		params.set("limit", form.getLimit());
		params.set("page", form.getPage());
		// 获取papp列表
		ServiceResults result = pappSearchService.invoke(params);
		String responseCode = result.getString("responseCode");
		//add by yuying412 for bug #94
		//从另一张表中取到的数据
		PageDataDTO<PappManagerPO> pappManagerPOs = pappManagerDAO.list(form);
		List<PappManagerPO> datas = new ArrayList<PappManagerPO>();
		if ("0".equals(responseCode)) {
			int keySize = result.getInt("totalProperty");
			int len = ".properties".length();
			if (keySize > 0) {
				@SuppressWarnings("unchecked")
				List<Map<String, Object>> keys = (List<Map<String, Object>>) result.get("root");
				for (Map<String, Object> key : keys) {
					PappManagerPO bean = new PappManagerPO();
					String papp = (String) (key.get("key"));
					String singlePappName = papp.substring(0, papp.length() - len);

					// 根据papp name 查询负责人和中文名称
					PappManagerDTO queryParams = new PappManagerDTO();
					queryParams.setPappName(singlePappName);
					queryParams.setSystemsId(form.getSystemsId());
					queryParams.setLimit(1);
					queryParams.setPage(1);

					PageDataDTO<PappManagerPO> queryResult = pappManagerService.list(queryParams);

					bean.setPappName(singlePappName);
					bean.setCreatedBy((String) (key.get("createdBy")));
					if(key.get("createdDate") != null){
						bean.setCreatedDate(formatter.parse((String) key.get("createdDate")));
					}
					//2017.8.10 add by yuying412
					bean.setUpdatedDateFromConfigManager(formatter.parse((String)key.get("updatedDate")));
					//**************
					//change by yuying412 for bug #94
					//对比两张表中的修改时间，取数值较大的表的数据，用来更新修改时间、修改人。
					PappManagerPO rightOne =null;
					for(PappManagerPO pappManagerPOTemp:pappManagerPOs.getDatas()){
						//2017.8.8 edit by yuying412 for 准确匹配Pappname，从key中取的值有后缀.properties
						if(((String)key.get("key")).equals(pappManagerPOTemp.getPappName()+".properties")){
							rightOne=pappManagerPOTemp;
							//2017.8.10 add by yuying412
							bean.setUpdatedDateFromPappManager(rightOne.getUpdatedDate());
							break;
						}
					}
					if(rightOne!=null&&rightOne.getUpdatedDate().getTime()>=formatter.parse((String)key.get("updatedDate")).getTime()){
						bean.setUpdatedBy(rightOne.getUpdatedBy());
						bean.setUpdatedDate(rightOne.getUpdatedDate());
					}else{
						bean.setUpdatedBy((String) (key.get("updatedBy")));
						bean.setUpdatedDate(formatter.parse((String) key.get("updatedDate")));
					}
					//**************
					if (queryResult.getDatas() != null && queryResult.getDatas().size() > 0) {
						PappManagerPO dto = queryResult.getDatas().get(0);
						bean.setCreatedDate(dto.getCreatedDate());
						bean.setId(dto.getId());
						bean.setPappChName(dto.getPappChName());
						bean.setPappOwner(dto.getPappOwner());
						bean.setPappOwnerId(dto.getPappOwnerId());
						bean.setRemark(dto.getRemark());
					}
					if(!bean.getPappName().endsWith(".dubbo")){
						datas.add(bean);
					}
				}
			}
		}

		ResponseModel model = new ResponseModel("0");
		model.put("datas", datas);
		model.put("size", result.getInt("totalProperty"));
		return model;

	}

	@RequestMapping("/papp/papp-getById.do")
	@ResponseBody
	public ResponseModel getById(@RequestParam(value = "id", required = true) String id) {
		ResponseModel model = new ResponseModel();
		PappManagerDTO dto = pappManagerService.getById(id);
		if (dto == null) {
			model.setResponseCode("1");
			model.setResponseMsg("应用不存在");
			model.put("success", false);
			return model;
		}
		model.put("data", dto);
		model.put("success", true);
		return model;
	}
	
	@ResponseBody
	@ESA("pafa5-admin-papp.delPapp")
	public ResponseModel delById(PappManagerDTO form) throws Exception {
		PageDataDTO<PappManagerPO> pappManagerPOs = pappManagerDAO.list(form);
		boolean result = false;
		if(pappManagerPOs.getDatas().size()>0){
			result = pappManagerService.delById(pappManagerPOs.getDatas().get(0).getId());
		}
		ResponseModel model = new ResponseModel("0");
		model.put("result", result);
		return model;
	}

	@RequestMapping("/papp/papp-getByName.do")
	@ResponseBody
	@ESA("pafa5-admin-papp.getByName")
	public ResponseModel getByName(@RequestParam(value = "pappName", required = true) String pappName) {
		ResponseModel model = new ResponseModel();
		PappManagerDTO dto = null;
		try {
			dto = pappManagerService.getByPappName(pappName);
		} catch (Exception e) {
			log.info("error occured when querying pappDTO by pappName,detail is: " + e.getMessage());
			model.setResponseCode("1");
			model.setResponseMsg("查询应用信息出错");
			model.put("success", false);
			return model;
		}
		if (dto == null) {
			model.setResponseCode("2");
			model.setResponseMsg("应用不存在");
			model.put("success", false);
			return model;
		}
		model.put("data", dto);
		model.put("success", true);
		return model;
	}

	@RequestMapping("/papp/papp-edit.do")
	@ResponseBody
	public ResponseModel edit(@Valid PappManagerDTO form) throws Throwable {
		if (logger.isInfoEnabled()) {
			logger.info("form:" + JSONObject.toJSONString(form));
		}
		ResponseModel model = new ResponseModel();

		// 所属项目是否存在
		if (!StringUtils.isEmpty(form.getSystemsId())) {
			ServiceParams params = ServiceParams.newInstance().set("systemsId", form.getSystemsId());
			ServiceResults results = systemServices.invoke(params);
			if (!"0".equals(results.get("responseCode"))) {
				throw new ResponseCodeException("250", "项目不存在。");
			} else {
				form.setSystemsName((String) results.get("chineseName"));
			}
		}

		// 判断负责人是否存在并是否属于项目成员
		if (!StringUtils.isEmpty(form.getPappOwnerId())) {
			String uid = form.getPappOwnerId().toLowerCase();
			ServiceParams params = ServiceParams.newInstance().set("uid", uid);
			ServiceResults results = userServices.invoke(params);
			if (!"0".equals(results.get("responseCode"))) {
				throw new ResponseCodeException("250", "组件负责人不存在。");
			}
			params = ServiceParams.newInstance().set("groupId", form.getSystemsId());
			results = getGroupMemberClient.invoke(params);
			boolean isMember = false;
			if ("0".equals(results.get("responseCode"))) {
				List<MemberPO> members = results.toDTOList("members", MemberPO.class);
				if (members != null) {
					for (MemberPO memberPO : members) {
						if (memberPO.getUserId().equalsIgnoreCase(form.getPappOwnerId())) {
							isMember = true;
							break;
						}
					}
				}
			}
			if (!isMember) {
				throw new ResponseCodeException("250", "负责人不属于该项目成员。");
			}
		} else {
			form.setPappOwner("");
		}

		boolean success = true;
		PappManagerDTO dto = pappManagerService.getById(form.getId());
		if (dto != null&&form.getId()!="") {
			success = pappManagerService.updateById(form);
		} else {
			pappManagerService.add(form);
		}
		model.setResponseCode(SARManagerConstants.RESPONSECODE_ZERO);
		model.setResponseMsg(success ? "修改成功" : "修改失败");
		model.put("success", success);
		return model;
	}

	@RequestMapping("/papp/getDubboConfig.do")
	@ResponseBody
	public ResponseModel getDubboConfig(@RequestParam(value = "projectId", required = true) String projectId,
			@RequestParam(value = "pappName", required = true) String pappName) throws IOException {
		ResponseModel model = new ResponseModel();

		// Dubbo配置文件名
		String key = pappName + ".dubbo.properties";

		ServiceParams params = ServiceParams.newInstance();
		params.set("projectId", projectId).set("group", "papp").set("key", key);
		ServiceResults results = getConfigItemClient.invoke(params);

		String value = results.getString("value");
		if (value != null) {
			model.put("exists", true);
			Properties prop = new Properties();
			Reader reader = new StringReader(value);
			prop.load(reader);
			model.put("port", prop.getProperty("dubbo.protocol.port"));
			if (prop.contains("dubbo.monitor.protocol")) {
				model.put("monitor", true);
			} else {
				model.put("monitor", false);
			}
			model.put("host", prop.getProperty("dubbo.protocol.host"));
			model.put("serializer", prop.getProperty("dubbo.protocol.serialization"));
			model.put("pool", prop.getProperty("dubbo.protocol.threads"));
			model.put("timeout", prop.getProperty("dubbo.service.timeout"));
			model.put("loadbalance", prop.getProperty("dubbo.service.loadbalance"));
		} else {
			model.put("exists", false);
		}

		model.put("success", true);
		return model;
	}

	@RequestMapping("/papp/saveDubboConfig.do")
	@ResponseBody
	public ResponseModel saveDubboConfig(SaveDubboConfigForm form) {
		ResponseModel model = new ResponseModel();

		// Dubbo配置文件名
		String key = form.getPappName() + ".dubbo.properties";
		// Dubbo配置内容
		StringBuilder sb = new StringBuilder();
		sb.append("dubbo.protocol.port=").append(form.getPort()).append("\n");
		if (form.getMonitor()) {
			sb.append("dubbo.monitor.protocol=").append("registry").append("\n");
		}
		if (!StringUtils.isEmpty(form.getHost())) {
			sb.append("dubbo.protocol.host=").append(form.getHost()).append("\n");
		}
		sb.append("dubbo.protocol.serialization=").append(form.getSerializer().trim()).append("\n");
		sb.append("dubbo.protocol.threads=").append(form.getPool()).append("\n");
		sb.append("dubbo.service.timeout=").append(form.getTimeout()).append("\n");
		sb.append("dubbo.service.loadbalance=").append(form.getLoadbalance().trim()).append("\n");
		String value = sb.toString();

		ServiceParams params = ServiceParams.newInstance();
		params.set("projectId", form.getProjectId()).set("group", "papp").set("key", key).set("value", value)
				.set("optype", form.getOpType());
		ServiceResults results = saveConfigClient.invoke(params);

		model.put("success", results.get("success"));
		return model;
	}
}
