package com.pingan.pafa5.admin.pizza.po;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;

import com.pingan.pafa5.admin.commons.BasePO;

/**
 * 全局变量
 * 
 * @author zhanggang871
 * 
 *         <p>
 *         存储格式：global.project.${property}=value
 *         </p>
 */
@Document
public class GlobalVariablePO extends BasePO {

	/**
	 * proId.property
	 * 
	 * id由service层生成uuid
	 * {@link com.pingan.pafa5.admin.pizza.services.impl.GlobalVariableServiceImpl#add}
	 */
	@org.springframework.data.annotation.Id
	private String id;

	private String proId;

	private String proName;

	private String property;

	private String value;

	private boolean isHidden = false;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getProId() {
		return proId;
	}

	public void setProId(String proId) {
		this.proId = proId;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public boolean isHidden() {
		return isHidden;
	}

	public void setHidden(boolean isHidden) {
		this.isHidden = isHidden;
	}

}
