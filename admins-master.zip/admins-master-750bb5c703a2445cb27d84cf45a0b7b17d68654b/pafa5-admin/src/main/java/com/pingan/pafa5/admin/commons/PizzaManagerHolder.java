package com.pingan.pafa5.admin.commons;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import com.pingan.pafa.pizza.Pizza;
import com.pingan.pafa.pizza.PizzaManager;

/**
 * PizzaManager管理类，保存多个项目对应的连接
 * @author ZHANGJIAWEI370
 *
 */
public final class PizzaManagerHolder implements InitializingBean, DisposableBean {
	
	private static final String DEFAULT_ROOT_PATH = "/paconfigs";
	
	private static Map<String, PizzaManager> managerMapping = new ConcurrentHashMap<String, PizzaManager>();
	
	private static String managerUrl;
	
	public synchronized PizzaManager getManager(String domainId) {
		if(StringUtils.isEmpty(domainId)) {
		    domainId = "def";
		}
		if(managerMapping.containsKey(domainId)) {
			return managerMapping.get(domainId);
		} else {
			String sign = managerUrl.indexOf("?") >= 0 ? "&":"?";
			PizzaManager manager = Pizza.getPizzaContext().createManager(managerUrl + sign + "rootPath=/" + domainId);
			managerMapping.put(domainId, manager);
			return manager;
		}
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		//managerMapping = new HashMap<String, PizzaManager>();
		if(managerMapping==null){
			managerMapping = new ConcurrentHashMap<String, PizzaManager>();
		}
		String sign = managerUrl.indexOf("?") >= 0 ? "&":"?";
		PizzaManager defManager = Pizza.getPizzaContext().createManager(managerUrl + sign + "rootPath=" + DEFAULT_ROOT_PATH);
		managerMapping.put("def", defManager);
	}

	@Override
	public void destroy() throws Exception {
		for(PizzaManager manager : managerMapping.values()) {
			manager.shutdown();
		}
		managerMapping = null;
	}

	public static void setManagerUrl(String managerUrl) {
		PizzaManagerHolder.managerUrl = managerUrl;
	}

}
