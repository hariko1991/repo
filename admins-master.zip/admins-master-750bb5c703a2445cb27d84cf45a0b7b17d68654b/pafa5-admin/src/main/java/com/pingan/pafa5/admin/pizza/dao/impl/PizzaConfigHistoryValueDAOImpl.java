package com.pingan.pafa5.admin.pizza.dao.impl;

import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.pizza.dao.PizzaConfigHistoryValueDAO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigHistoryValuePO;

@Nosql
@Repository
public class PizzaConfigHistoryValueDAOImpl extends  BaseMongoDAO<PizzaConfigHistoryValuePO> implements PizzaConfigHistoryValueDAO{

	
	public void add(PizzaConfigHistoryValuePO historyValueDTO) {
		this._add(historyValueDTO);
	}

	@Override
	public PizzaConfigHistoryValuePO getById(String historyId) {
		return this._getById(historyId);
	}
	
    @Override
    public void update(PizzaConfigHistoryValuePO historyValueDTO) {
    	this._updateById(historyValueDTO);
    }

    @Override
    public boolean del(String id) {
    	return this._removeById(id);
    }
}
