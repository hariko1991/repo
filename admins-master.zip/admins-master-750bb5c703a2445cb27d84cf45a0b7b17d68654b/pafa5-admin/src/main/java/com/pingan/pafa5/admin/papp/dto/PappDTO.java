package com.pingan.pafa5.admin.papp.dto;

public class PappDTO {
	
	private String id;
	private String pappName;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPappName() {
		return pappName;
	}
	public void setPappName(String pappName) {
		this.pappName = pappName;
	}
	
	public boolean equals(PappDTO pappDTO){
		return id.equals(pappDTO.getId())
				 &&pappName.equals(pappDTO.getPappName());
	}
	
}
