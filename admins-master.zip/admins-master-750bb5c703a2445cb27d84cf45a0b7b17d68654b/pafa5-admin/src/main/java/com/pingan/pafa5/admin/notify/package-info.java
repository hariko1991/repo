/**
 *@see 邮件发送组件
 *@author JIECHANGKE805
 *@since 2016年8月18日
 *@param 
 */
package com.pingan.pafa5.admin.notify;