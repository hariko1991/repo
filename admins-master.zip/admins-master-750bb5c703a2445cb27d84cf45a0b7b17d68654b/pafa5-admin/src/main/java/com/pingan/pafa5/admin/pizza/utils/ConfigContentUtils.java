package com.pingan.pafa5.admin.pizza.utils;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa.pizza.Pizza;
import com.pingan.pafa.pizza.PizzaConstants;
import com.pingan.pafa.pizza.classloader.ClasspathResourceContent;
import com.pingan.pafa5.admin.pizza.po.ConfigGroupPO;
import com.pingan.pafa5.admin.pizza.services.ConfigGroupServices;

@Component
public class ConfigContentUtils extends BaseServices {

    // 上传文件最大字节[0:表示没有限制]
    @Value("${admin.upload.file.maxByte}")
    private int valueMaxSize;

    @Autowired
    private ConfigGroupServices configGroupServices;

    public int getMaxSize() {
        return valueMaxSize;
    }

    public void checkContent(String group, String key, String value) {
        if (value == null || value.trim().length() == 0 ) {
            throw new ResponseCodeException("12", "配置内容为空!");
        }
        ConfigGroupPO groupDTO = configGroupServices.getGroup(group);
        if (groupDTO == null) {
            throw new ResponseCodeException("11", "配置组不存在!");
        }
        if (!groupDTO.isBinary()) {
            if (valueMaxSize > 0 && value.length() > valueMaxSize) {
                throw new ResponseCodeException("10",
                        "配置内容超过限制大小=" + (valueMaxSize / 1024) + "KB.");
            }
        } else {
            long len = -1;
            try {
                byte[] datas = decodeContent(value);
                len = datas.length;
            } catch (Exception ex) {
                throw new ResponseCodeException("15", "配置组不支持文本格式，必须是base64编码的内容!");
            }
            if (valueMaxSize > 0 && len > valueMaxSize) {
                throw new ResponseCodeException("10", "配置文件大小超过限制大小=" + (len / 1024) + "KB.");
            }
        }
    }

    // 读取文件
    public String encodeContent(String group, String key, byte[] datas) {
        if (logger.isInfoEnabled()) {
            logger.info("encodeConfigContent,group=" + group + ",key=" + key);
        }
        ConfigGroupPO groupDTO = configGroupServices.getGroup(group);
        if (groupDTO == null) {
            throw new ResponseCodeException("11", "配置组不存在!");
        }
        if (datas == null || datas.length == 0) {
            throw new ResponseCodeException("12", "配置内容为空!");
        } else {
            if (valueMaxSize > 0 && datas.length > valueMaxSize) {
                throw new ResponseCodeException("10",  "配置内容超过限制大小=" + (valueMaxSize / 1024) + "KB.");
            }
        }
        if (!groupDTO.isBinary()) {
            String content = new String(datas, Pizza.getCharset());
            if (logger.isDebugEnabled()) {
                logger.debug("encodeConfigContent=" + content);
            }
            /*
             * if(ChineseUtill.isMessyCode(content)){ throw new
             * ResponseCodeException("13","配置内容乱码，请保证是UTF8编码。"); }
             */
            return content;
        } else if (group.equals(PizzaConstants.GROUP_RESOURCES)) {
        	ClasspathResourceContent content = ClasspathResourceContent.create(datas);
            return content.toJSONString();
        } else {
            return Base64.encodeBase64String(datas);
        }
    }

    public byte[] decodeContent(String datas) {
        if (datas == null || datas.length() == 0)
            return null;
        return Base64.decodeBase64(datas);
    }

    public byte[] decodeContent(ConfigGroupPO group, String datas) {
        if (datas == null || datas.length() == 0)
            return null;
        if (group.isBinary()) {
            return Base64.decodeBase64(datas);
        } else {
            return datas.getBytes(Pizza.getCharset());
        }
    }

    public String md5(String content) {
        String value = "";
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            byte b[] = md.digest(content.getBytes("UTF-8"));
            return new String(Base64.encodeBase64(b));
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        return value;
    }

    /**
     * @see 计算上传资源文件的sha1值
     * @author JIECHANGKE805
     * @since 2016年5月12日
     * @param b:文件的字节流
     * @throws NoSuchAlgorithmException
     */
    public String sha1(byte[] b) throws NoSuchAlgorithmException {
        int bufferSize = 1024 * 1024;
        InputStream is = new ByteArrayInputStream(b);
        MessageDigest md = MessageDigest.getInstance("sha1");
        DigestInputStream digIS = new DigestInputStream(is, md);
        // read的过程中进行sha1处理，直到读完文件
        byte[] buffer = new byte[bufferSize];
        try {
            while (digIS.read(buffer) > 0);
        } catch (IOException e) {
            logger.error(
                    "Exception occur when reading file byte stream,detail is : " + e.getMessage());
        }
        // 获取最终的MessageDigest
        md = digIS.getMessageDigest();

        byte[] resultByteArray = md.digest();

        return byteArrayToHex(resultByteArray);
    }

    /**
     * @see 字节数组转换为十六进制字符串
     * @author JIECHANGKE805
     * @since 2016年5月13日
     * @param 需转换的字节数组
     */
    public String byteArrayToHex(byte[] b) {
        String hs = "";
        String stmp = "";
        for (int n = 0; n < b.length; n++) {
            stmp = (Integer.toHexString(b[n] & 0XFF));
            if (stmp.length() == 1) {
                hs = hs + "0" + stmp;
            } else {
                hs = hs + stmp;
            }
            if (n < b.length - 1) {
                hs = hs + "";
            }
        }
        return hs;
    }

    public int getValueMaxSize() {
        return valueMaxSize;
    }

    public void setValueMaxSize(int valueMaxSize) {
        this.valueMaxSize = valueMaxSize;
    }
    /** 非文本文件 */
	private static final List<String> NOT_TEXT_FILE = Arrays.asList("jar", "zip", "rar", "war", "JAR", "ZIP", "RAR", "WAR");
    public boolean isBinary(String key){
    	int idx = key.lastIndexOf(".");
    	String ext = key.substring(idx + 1);
    	if (NOT_TEXT_FILE.contains(ext)) {
    		return true;
    	}
    	return false;
    }

}
