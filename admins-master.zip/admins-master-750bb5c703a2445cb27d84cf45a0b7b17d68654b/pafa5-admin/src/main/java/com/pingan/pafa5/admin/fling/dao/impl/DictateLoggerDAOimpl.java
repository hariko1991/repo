package com.pingan.pafa5.admin.fling.dao.impl;

import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.fling.dao.DictateLoggerDAO;
import com.pingan.pafa5.admin.fling.po.DictateLoggerPO;
import com.pingan.pafa5.admin.fling.po.FlingCommandResultPO;
import com.pingan.um.client.util.UUID;

@Nosql
@Repository
public class DictateLoggerDAOimpl extends BaseMongoDAO<DictateLoggerPO> implements DictateLoggerDAO {

    @Override
    public void add(DictateLoggerPO po) {
        po.setId(UUID.getRandomID());
        this._add(po);
    }

    public DictateLoggerPO getByDictateId(String dictateId) {
        return this._get(where("dictateId").is(dictateId));
    }

    public void setResult(FlingCommandResultPO result) {
        DictateLoggerPO po = this._get(where("dictateId").is(result.getRid()));
        if (po != null) {
            po.setResult(result.getResponseCode());
            po.setCause(result.getResponseMsg());
        }
        this._updateById(po);
    }

    @Override
    public List<DictateLoggerPO> list(int limit, int page, String projectId, String pappName,String sarName) {
        Criteria where = new Criteria();
        if (sarName != null && !"".equals(sarName.trim())) {
            where.and("posName").regex(Pattern.compile("^.*" + sarName + ".*$", Pattern.CASE_INSENSITIVE));
            where.and("posType").is("sar");
        } else {
            if (pappName != null && !"".equals(pappName.trim())) {
                where.and("posName").regex(Pattern.compile("^.*" + pappName + ".*$", Pattern.CASE_INSENSITIVE));
                where.and("posType").is("papp");
            }
        }
        if (StringUtils.isNotEmpty(projectId)) {
            where.and("projectId").is(projectId);
        } else {
            where.and("projectId").is(null);
        }
        int skip = (page - 1) * limit;
        return this._listAndDesc(where, skip, limit, "createdDate");
    }

    public long getTotal(String projectId, String pappName, String sarName) {
        Criteria where = new Criteria();
        if (sarName != null && !"".equals(sarName.trim())) {
            where.and("posName").regex(
                    Pattern.compile("^.*" + sarName + ".*$", Pattern.CASE_INSENSITIVE));
            where.and("posType").is("sar");
        } else {
            if (pappName != null && !"".equals(pappName.trim())) {
                where.and("posName").regex(
                        Pattern.compile("^.*" + pappName + ".*$", Pattern.CASE_INSENSITIVE));
                where.and("posType").is("papp");
            }
        }
        if (StringUtils.isNotEmpty(projectId)) {
            where.and("projectId").is(projectId);
        } else {
            where.and("projectId").is(null);
        }
        return this._count(where);
    }

    @Override
    public DictateLoggerPO getById(String id) {
        return this._getById(id);
    }

}
