package com.pingan.pafa5.admin.pizza.web;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa5.admin.commons.SqlUtils;
import com.pingan.pafa5.admin.pizza.services.ConfigGroupServices;
import com.pingan.pafa5.admin.pizza.services.PizzaConfigServices;
import com.pingan.pafa5.admin.pizza.utils.ConfigContentUtils;

@Controller
public class GardenConfigManagerController extends BaseController{

	@Autowired
	private PizzaConfigServices pizzaConfigServices;

	@Autowired
	private ConfigGroupServices configGroupServices;

	@Autowired
	private ConfigContentUtils configContentUtils;
	
	@ESA(value = "pafa5-admin-pizza.gardenListKeys")
	@ResponseBody
	public ModelMap listKeys(
			@RequestParam("projectId") String projectId,
			@RequestParam("group") String group,
			@RequestParam(value = "keyRegex", required = false) String keyRegex,
			@RequestParam(value = "likeKey", required = false) String likeKey)
			throws Throwable {

		if (likeKey != null && (likeKey = likeKey.trim()).length() > 0) {

			if (SqlUtils.SPRING_PROFILE_NOSQL.equalsIgnoreCase(SqlUtils
					.getSpringProfilesActive())) {
				keyRegex = "^" + likeKey + ".*$";
			} else {
				keyRegex = likeKey + "%";
			}
		}
		List<String> keys = pizzaConfigServices.listKeys(projectId, group,
				keyRegex);
		ModelMap model = new ResponseModel("0");
		model.put("keySize", keys == null ? 0 : keys.size());
		model.put("keys", keys);
		return model;
	}
}
