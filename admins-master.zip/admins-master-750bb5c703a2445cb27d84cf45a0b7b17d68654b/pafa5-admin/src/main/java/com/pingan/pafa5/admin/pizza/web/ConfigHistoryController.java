package com.pingan.pafa5.admin.pizza.web;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.validator.annotation.Valid;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.commons.SARManagerConstants;
import com.pingan.pafa5.admin.pizza.dto.ConfigSearchDTO;
import com.pingan.pafa5.admin.pizza.po.ConfigGroupPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigHistoryPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigHistoryValuePO;
import com.pingan.pafa5.admin.pizza.services.ConfigGroupServices;
import com.pingan.pafa5.admin.pizza.services.HistoryConfigServices;
import com.pingan.pafa5.admin.pizza.utils.ConfigContentUtils;

/**
 * 资源中心-历史记录
 * @author ZHANGJIAWEI370
 * @author LIXINGNAN945
 */
@Controller
@RequestMapping("/pizzamgr/history")
public final class ConfigHistoryController extends BaseController {

    @Autowired
    private HistoryConfigServices historyConfigServices;

    @Autowired
    private ConfigGroupServices configGroupServices;

    @Autowired
    private ConfigContentUtils configContentUtils;

    @ActionClient(name = "pafa5-admin-systems.isOwner")
    private IServiceClient ownerService;
    
    @RequestMapping("/list.do")
    @ResponseBody
    public ResponseModel search(@Valid ConfigSearchDTO form) throws Throwable {
        if (logger.isInfoEnabled()) {
            logger.info("form:" + JSONObject.toJSONString(form));
        }
        PageDataDTO<PizzaConfigHistoryPO> pageDatas = historyConfigServices.search(form);
        List<PizzaConfigHistoryPO> dblist = pageDatas.getDatas();
        List<ModelMap> configItems = new ArrayList<ModelMap>();
        if (dblist != null && dblist.size() >= 0) {
            if (logger.isInfoEnabled()) {
                logger.info("datasize is:" + dblist.size());
            }
            for (PizzaConfigHistoryPO to : dblist) {
                ModelMap map = new ModelMap();
                map.put("pizzaGroupName", configGroupServices.getGroupName(to.getPizzaGroup())
                        + "(" + to.getPizzaGroup() + ")");
                map.put("pizzaGroup", to.getPizzaGroup());
                map.put("createdBy", to.getCreatedBy());
                map.put("createdDate", to.getCreatedDate().getTime());
                map.put("operationIp", to.getOperationIp());
                map.put("operationType", to.getOperationType());
                map.put("pizzaKey", to.getPizzaKey());
                map.put("historyId", to.getHistoryId());
                map.put("recovery", to.getRecovery());
                map.put("recoveryDate", to.getRecoveryDate());
                map.put("recoveryUser", to.getRecoveryUser());
                configItems.add(map);
            }
        } else {
            if (logger.isInfoEnabled()) {
                logger.info("datasize is:" + 0);
            }
        }
        ResponseModel model = new ResponseModel();
        model.put("totalProperty", pageDatas.getTotalSize());
        model.put("root", configItems);
        return model;
    }
    //清理太久远的历史记录 yuying412
    @RequestMapping("/cleanUpRecord.do")
    @ResponseBody
    public ResponseModel cleanUpRecord(
    		@RequestParam(value = "cleanBeforeThisTime", required = true) String cleanBeforeThisTime,
			@RequestParam(value = "projectId", required = false) String projectId/*,
			@RequestParam(value = "recordNum", required = false) int recordNum*/){
    	
    	if(cleanBeforeThisTime!=null&&cleanBeforeThisTime.length()==0/*&&projectId!=null&&projectId.length()==0*/){
    		ResponseModel model = new ResponseModel("1","错误，请求参数不正确！");
            return model;
    	}
    	historyConfigServices.cleanUpRecord(cleanBeforeThisTime,projectId);
    	ResponseModel model = new ResponseModel("0","已清除在选定日期"+cleanBeforeThisTime+"之前的历史数据！");
        return model;
    }
  //获得某日期之前历史记录的数量 yuying412
    @RequestMapping("/getRecordNum.do")
    @ResponseBody
    public ResponseModel getRecordNum(
    		@RequestParam(value = "cleanBeforeThisTime", required = true) String cleanBeforeThisTime,
			@RequestParam(value = "projectId", required = false) String projectId/*,
			@RequestParam(value = "recordNum", required = false) int recordNum*/){
    	
    	if(cleanBeforeThisTime!=null&&cleanBeforeThisTime.length()==0/*&&projectId!=null&&projectId.length()==0*/){
    		ResponseModel model = new ResponseModel("1","错误，请求参数不正确！");
            return model;
    	}
    	
    	ResponseModel model = new ResponseModel("0","成功");
    	model.put("numResult", historyConfigServices.getRecordNum(cleanBeforeThisTime,projectId));
        return model;
    }
    // 查看单个配置文件信息
    @RequestMapping("/find.do")
    @ResponseBody
    public ResponseModel find(@RequestParam("historyId") String historyId) {
        if (logger.isInfoEnabled()) {
            logger.info("historyId=" + historyId);
        }
        PizzaConfigHistoryPO po = historyConfigServices.getById(historyId);
        PizzaConfigHistoryValuePO valuePo = historyConfigServices.getValueById(historyId);
        
        ResponseModel model = new ResponseModel();
        model.put("history", po);
        model.put("pizzaValue", valuePo.getPizzaValue());
        return model;
    }

    // 还原配置文件信息
    @RequestMapping("/recovery.do")
    @ResponseBody
    public ResponseModel recovery(@RequestParam("historyId") String historyId) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("historyId=" + historyId);
        }
        boolean success = historyConfigServices.recovery(historyId);

        ResponseModel model = new ResponseModel();
        model.put("success", success);
        return model;
    }

    @RequestMapping("/show.do")
    @ResponseBody
    public ResponseModel configshow(@RequestParam("historyId") String historyId,
            HttpServletResponse response) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("historyId=" + historyId);
        }
        PizzaConfigHistoryPO history = null;
        PizzaConfigHistoryValuePO historyValuePO = null;
        if (historyId.indexOf("{") != -1) {
            JSONObject pm = JSONObject.parseObject(historyId);
            String group = pm.getString("g");
            String key = pm.getString("k");
            long createDate = pm.getLongValue("c");
            history = historyConfigServices.get(group, key, createDate);
        } else {
            history = historyConfigServices.getById(historyId);
        }
        historyValuePO = historyConfigServices.getValueById(historyId);
        String msg = null;
        if (history == null||historyValuePO==null) {
            msg = "历史版本不存在。";
        } else {
            String key = history.getPizzaKey();
            ConfigGroupPO group = configGroupServices.getGroup(history.getPizzaGroup());
            byte[] content =
                    configContentUtils.decodeContent(group, historyValuePO.getPizzaValue());
            if (content == null) {
                msg = "配置为空";
            } else {
                if (group.isBinary()) {
                    response.setContentType("application/x-zip-compressed");
                    response.addHeader("Content-Disposition", "attachment;filename=" + key);
                } else {
                    if (key.endsWith(".xml")) {
                        response.setContentType("text/xml;charset=utf-8");
                    } else {
                        response.setContentType("text/plain;charset=utf-8");
                    }
                }
                response.getOutputStream().write(content);
                response.getOutputStream().flush();
                return null;
            }
        }
        ResponseModel model = new ResponseModel();
        model.setResponseCode("-1");
        model.setResponseMsg(msg);
        return model;
    }
    
    public void isOwner(String domainId) {
        if (domainId == null || SARManagerConstants.DEF.equalsIgnoreCase(domainId)) {
            return;
        }
        ServiceParams params = new ServiceParams();
        params.set("groupId", domainId);
        ServiceResults results = ownerService.invoke(params);
        boolean isBoo = results.getBool("isowner");
        if (!isBoo) {
            throw new ResponseCodeException("354", "对不起，你不是领域负责人，没有此操作权限");
        }
    }

    public void setHistoryConfigServices(HistoryConfigServices historyConfigServices) {
        this.historyConfigServices = historyConfigServices;
    }

    public void setConfigGroupServices(ConfigGroupServices configGroupServices) {
        this.configGroupServices = configGroupServices;
    }

    public void setConfigContentUtils(ConfigContentUtils configContentUtils) {
        this.configContentUtils = configContentUtils;
    }

    public void setOwnerService(IServiceClient ownerService) {
        this.ownerService = ownerService;
    }
    
}
