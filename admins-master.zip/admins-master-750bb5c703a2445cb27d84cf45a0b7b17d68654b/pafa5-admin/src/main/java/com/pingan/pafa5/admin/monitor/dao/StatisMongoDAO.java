package com.pingan.pafa5.admin.monitor.dao;

import com.pingan.pafa.mongodb.MongoPagination;
import com.pingan.pafa5.admin.monitor.dtos.StatisticsDTO;

import java.util.List;

/**
 * Created by ZHANGWENZHUO810 on 2016-11-14.
 */
public interface StatisMongoDAO {
    void add(StatisticsDTO sti);

    int removeByProperty(String name, String value);

    int removeByDate(String name, String value);

    boolean updateByProperty(String name, String value, StatisticsDTO sta);

    public StatisticsDTO getByProperty(String name, String value);

    public StatisticsDTO getByPropertys(String name, String value, String name2, String value2);

    public List<StatisticsDTO> listByProperty(String name, String value);

    public List<StatisticsDTO> listByType(String value, String value2, String value3, String value4);

    public List<StatisticsDTO> listByValues(String name, String value, String name2, String value2, String name3, String value3);

    public List<StatisticsDTO> listByPropertys(String name, String value, String name2, String value2);

    public MongoPagination<StatisticsDTO> paginated(MongoPagination<StatisticsDTO> page, String name, String value);

    public long size();
}
