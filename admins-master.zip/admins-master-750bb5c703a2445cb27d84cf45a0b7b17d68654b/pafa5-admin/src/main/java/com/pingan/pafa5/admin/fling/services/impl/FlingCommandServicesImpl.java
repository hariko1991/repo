package com.pingan.pafa5.admin.fling.services.impl;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.fling.FlingCommand;
import com.pingan.pafa.fling.msg.FlingCommandMsg;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.pizza.Pizza;
import com.pingan.pafa5.admin.commons.FlingCommandHolder;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.commons.PizzaManagerHolder;
import com.pingan.pafa5.admin.fling.dao.DictateLoggerDAO;
import com.pingan.pafa5.admin.fling.dao.FlingCommandDAO;
import com.pingan.pafa5.admin.fling.dao.FlingCommandResultDAO;
import com.pingan.pafa5.admin.fling.dao.FlingPappInstanceDAO;
import com.pingan.pafa5.admin.fling.dto.FlingCommandResultsDTO;
import com.pingan.pafa5.admin.fling.form.SendCommandForm;
import com.pingan.pafa5.admin.fling.po.DictateLoggerPO;
import com.pingan.pafa5.admin.fling.po.FlingCommandPO;
import com.pingan.pafa5.admin.fling.po.FlingCommandResultPO;
import com.pingan.pafa5.admin.fling.services.FlingCommandServices;
import com.pingan.pafa5.admin.sso.UserPrincipal;

@Service
public class FlingCommandServicesImpl extends BaseServices implements FlingCommandServices {

    @Autowired
    private FlingCommandHolder flingCommandHolder;

    @Autowired
    private FlingCommandDAO flingCommandDAO;

    @Autowired
    private PizzaManagerHolder pizzaManagerHolder;

    @Autowired
    private FlingCommandResultDAO flingCommandResultDAO;

    @Autowired
    private FlingPappInstanceDAO flingPappInstanceDAO;

    @Autowired
    private DictateLoggerDAO dictateLoggerDAO;
    
    @ActionClient(name="pafa5_admin_pizza.getConfigItem")
    private IServiceClient configService;

    @ActionClient(name="pafa5_admin_pizza.findGlobalById")
    private IServiceClient globalService;
    
    @Value("${instance.heartbeat.expired}")
    private int heartbeatExpired = 3 * 60 * 1000;
    
    @ActionClient(name = "garden.getPappMessage")
    private IServiceClient pushServicePapp;
    
    @ActionClient(name = "garden.getSarMessage")
    private IServiceClient pushServiceSar;
    
    @ActionClient(name = "pafa5-admin-systems.gardenGetGroupPM")
    private IServiceClient gardenGetGroupPM;
    
    @ActionClient(name = "garden.getProjectUms")
    private IServiceClient getProjectUms;
    

    @SuppressWarnings("unchecked")
	public FlingCommandResultsDTO getResults(String commandId) {
        if (commandId == null || (commandId = commandId.trim()).length() == 0) {
            throw new NullPointerException("CommandID不能为空.");
        }
        FlingCommandPO cmdPO = flingCommandDAO.getById(commandId);
        if (cmdPO == null) {
            throw new IllegalArgumentException("Command:" + commandId + " error,not exists.");
        }
        List<FlingCommandResultPO> results = flingCommandResultDAO.listByCommandId(commandId);
        List<String> limitIps = cmdPO.getLimitIps();
        int instanceSize = (limitIps == null ? 0 : limitIps.size());
        int resultsSize = (results == null ? 0 : results.size());
        FlingCommandResultsDTO dto = null;
        if (resultsSize == 0) {
            dto = new FlingCommandResultsDTO(false, instanceSize, null);
        } else {
            if (instanceSize == 0) {
                dto = new FlingCommandResultsDTO(true, instanceSize, results);
            } else {
                boolean completed = instanceSize == resultsSize;
                dto = new FlingCommandResultsDTO(completed, instanceSize, results);
            }
        }
       
        // 更新结果
        if (dto != null) {
        	ServiceResults projectIdResults = null;
            ServiceParams params = new ServiceParams();
            ServiceParams paramss = new ServiceParams();
            paramss.set("projectId", cmdPO.getProjectId());
            projectIdResults = gardenGetGroupPM.invoke(paramss);
            List<String> list = new ArrayList<>();
        	list=(List<String>) projectIdResults.get("datas");
            for (FlingCommandResultPO po : results) {
            	SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            	if(FlingCommandMsg.TARGET_TYPE_PAPP.equals(po.getTargetType())){
            		if(po.getResponseCode().equals("0")){
            			String descriptionCase =  "应用:" + po.getPappName()+ "执行指令：" + po.getActionType() + "成功";
            			po.setResponseMsg(descriptionCase);
            		}else{
            			String descriptionCase = "应用:" + po.getPappName() + "执行指令：" + po.getActionType() + "失败,失败原因:" + po.getResponseMsg();
            			po.setResponseMsg(descriptionCase);
            		}
            		try {
            			if(System.getProperty("garden.push.switchOn","false").equals("true")){
	            			params.set("umList", list);
	                        params.set("changeType", "于"+df.format(po.getCreatedDate())+po.getActionType());
	                        params.set("changeResult", po.getResponseCode().equals("0")?"成功":"失败");
	                        params.set("projectId", cmdPO.getProjectId());
	                        params.set("instanceIp", po.getInstanceIp());
	                        params.set("msgContent", po.getResponseMsg());
	                        ServiceResults pushResults = pushServicePapp.invoke(params);
	                        logger.info("PushResults:"+pushResults);
                        }
					} catch (Exception e) {
					}
            	}else{
            		if(po.getResponseCode().equals("0")){
            			String descriptionCase = "组件:" + po.getPappName() + "执行指令：" + po.getActionType() + "成功";
            			po.setResponseMsg(descriptionCase);
            		}else{
            			String descriptionCase = "组件:" + po.getPappName() + "执行指令：" + po.getActionType() + "失败,失败原因:" + po.getResponseMsg();
            			po.setResponseMsg(descriptionCase);
            		}
            		try {
            			if(System.getProperty("garden.push.switchOn","false").equals("true")){
            				params.set("umList", list);
	                        params.set("changeType", "于"+df.format(po.getCreatedDate())+po.getActionType());
	                        params.set("changeResult", po.getResponseCode().equals("0")?"成功":"失败");
	                        params.set("projectId", cmdPO.getProjectId());
	                        params.set("instanceIp", po.getInstanceIp());
	                        params.set("msgContent", po.getResponseMsg());
		                    ServiceResults pushResults = pushServiceSar.invoke(params);
		                    logger.info("PushResults:"+pushResults);
                		}
					} catch (Exception e) {
					}
            	}
                dictateLoggerDAO.setResult(po);
            }
        }

        return dto;
    }

    @Override
    public String sendCommand(FlingCommandMsg msg, SendCommandForm form) {
        UserPrincipal user = UserPrincipal.get(true);

        checkTargetType(msg.getTargetType());
        checkActionType(msg.getActionType());
        checkPapp(form.getProjectId(), msg.getPappName());
        
        String sarName = msg.getSarName();
        if (FlingCommandMsg.TARGET_TYPE_SAR.equals(msg.getActionType()) && (sarName == null || (sarName = sarName.trim()).length() == 0)) {
            throw new IllegalArgumentException("组件ID不能为空.");
        }
        if (sarName != null && sarName.length() > 0) {
            checkSar(form.getProjectId(), sarName);
        }
        forLimitIps(msg);

        FlingCommandPO po = new FlingCommandPO();
        POUtils.copyProperties(po, msg);
        POUtils.setForAdd(user.getUid(), po);
       
        po.setSenderIp(user.getIp());
        po.setRid(null);
        String rid = flingCommandDAO.add(po);
        if (logger.isInfoEnabled()) {
            logger.info("Rid=" + rid + ",send command...");
        }
        msg.setRid(rid);
       
        
        FlingCommand flingCommand = flingCommandHolder.getCommand(form.getProjectId());
        flingCommand.send(msg);
        if (logger.isInfoEnabled()) {
            logger.info("Rid=" + rid + ",send completed.");
        }
        // 记录操作日志
        DictateLoggerPO dlpo = new DictateLoggerPO();
        dlpo.setProjectId(form.getProjectId());
        if(form.getExecuteIps()==null||"".equals(form.getExecuteIps())){
        	String limitIpsStr = "";
            for (int i=0;i<msg.getLimitIps().size();i++) {
            	if(i==(msg.getLimitIps().size()-1)){
            		limitIpsStr+=msg.getLimitIps().get(i);
            	}else{
            		limitIpsStr+=msg.getLimitIps().get(i)+",";
            	}
            }
            dlpo.setInstanceIp(limitIpsStr);
        }else{
        	dlpo.setInstanceIp(form.getExecuteIps());
        }
        String type = form.getType();
        if (type.equals("papp")) {
            dlpo.setPosName(form.getPappName());
        } else {
            dlpo.setPosName(form.getSarName());
        }
        dlpo.setPosType(type);
        dlpo.setDictateName(form.getDictateName());
        dlpo.setDictateId(rid);
        POUtils.setForAdd(user.getUid(), dlpo);
        dlpo.setCreatedDate(new Date());
        dictateLoggerDAO.add(dlpo);

        return rid;
    }

    protected void forLimitIps(FlingCommandMsg msg) {
        List<String> limitIps = msg.getLimitIps();
        if (limitIps == null || limitIps.size() == 0) {
            limitIps = flingPappInstanceDAO.listValidInstanceIps(msg.getProjectId(),msg.getPappName(), heartbeatExpired);
            if (limitIps == null || limitIps.size() == 0) {
                if (logger.isInfoEnabled()) {
                    logger.info("NotFound target ips  by papp instances.");
                }
            } else {
                msg.setLimitIps(limitIps);
                if (logger.isInfoEnabled()) {
                    logger.info("Found target ips=" + limitIps + " by papp instances.");
                }
            }
        } else {
            if (logger.isInfoEnabled()) {
                logger.info("Rid=" + msg.getRid() + ",target ips=" + limitIps);
            }
        }
    }

    protected void checkActionType(String actionType) {
        if (actionType == null || actionType.length() == 0) {
            throw new NullPointerException("指令类型不能为空.");
        }
        if (!(FlingCommandMsg.ACTION_TYPE_RESTARTUP.equals(actionType)
                || FlingCommandMsg.ACTION_TYPE_SHUTDOWN.equals(actionType)
                || FlingCommandMsg.ACTION_TYPE_STARTUP.equals(actionType) 
                || FlingCommandMsg.ACTION_TYPE_ECHO .equals(actionType)
                || FlingCommandMsg.ACTION_TYPE_UNEXPORT_ESA.equals(actionType))) {
            throw new IllegalArgumentException("不支持的指令类型:" + actionType + ".");
        }
    }

    protected void checkTargetType(String targetType) {
        if (targetType == null || targetType.length() == 0) {
            throw new NullPointerException("目标类型不能为空.");
        }
        if (!(FlingCommandMsg.TARGET_TYPE_PAPP.equals(targetType) || FlingCommandMsg.TARGET_TYPE_SAR
                .equals(targetType))) {
            throw new IllegalArgumentException("不支持的目标类型:" + targetType + ".");
        }
    }

    protected void checkPapp(String projectId, String pappName) {
        if (pappName == null || pappName.length() == 0) {
            throw new NullPointerException("应用ID不能为空.");
        }
        String content = pizzaManagerHolder.getManager(projectId).get(Pizza.GROUP_PAPP, pappName + ".properties");
        if (content == null || "".equals(content)) {
            throw new IllegalArgumentException("配置中心没有找到应用的配置文件：" + projectId + "/papp/" + pappName + ".properties");
        }
    }

    protected void checkSar(String projectId, String sarName) {
        String content =
                pizzaManagerHolder.getManager(projectId).get(Pizza.GROUP_SAR,
                        sarName + ".properties");
        if (content == null || "".equals(content)) {
            throw new IllegalArgumentException("配置中心没有找到组件的配置文件：" + projectId + "/sar/" + sarName
                    + ".properties");
        }
    }

    @Override
    public boolean delete15DaysBefore() {
        Calendar now = Calendar.getInstance();
        now.add(Calendar.DATE, -15);
        now.set(Calendar.HOUR, 0);
        now.set(Calendar.MINUTE, 0);
        now.set(Calendar.SECOND, 0);
        int affected = flingCommandDAO.removeBeforeDate(now.getTime());
        logger.info("清理管控指令条数：" + affected);
        return affected > 0;
    }

	@Override
	public ResponseModel checkSarExist(FlingCommandMsg msg, SendCommandForm form) throws Exception {
		
		checkTargetType(msg.getTargetType());
        checkActionType(msg.getActionType());
        checkPapp(form.getProjectId(), msg.getPappName());
		
		ResponseModel model = null;
    	
		String type = form.getType();
		
		if (type.equals("papp")) {
            return model;
        } 
		
    	String pappName = form.getPappName();
    	String sarName = form.getSarName();
        String projectId = form.getProjectId();
        String group = "papp";
        String key = pappName+".properties";
        
        Map<String, String> map = new HashMap<String, String>();
        map.put("projectId", projectId);
        map.put("group", group);
        map.put("key", key);
        ServiceResults results = configService.invoke(map);
        if(Boolean.TRUE.toString().equalsIgnoreCase(results.get("success")+"")){
        	Object value = results.get("value");
        	if(!StringUtils.isEmpty(value)){
	        	Properties properties = new Properties();
	        	InputStream in_withcode = new ByteArrayInputStream(value.toString().getBytes("UTF-8"));  
	        	properties.load(in_withcode);
	        	
	        	if(properties!=null&&properties.size()>0){
	        		Object sarValue = properties.get("papp.sar.list");
	        		if(!StringUtils.isEmpty(sarValue)){
	        			String sarValue1 = sarValue.toString();
	        			if(sarValue1.startsWith("@{")){
		        			Map<String,String> params = new HashMap<String,String>();
		        			sarValue1 = sarValue1.replace("@", "").replaceAll("\\{", "").replaceAll("\\}", "");
		        			params.put("id", projectId+"."+sarValue1);
		        			ServiceResults results2 = globalService.invoke(params);
		        			if(Boolean.TRUE.toString().equalsIgnoreCase(results2.get("success")+"")){
		        				@SuppressWarnings("unchecked")
								Map<String,String> map2 = (Map<String, String>) results2.get("global");
		        				if("true".equals(map2.get("isHidden"))){
		        					sarValue1 = map2.get("alValue");
		        				}else{
		        					sarValue1 = map2.get("value");
		        				}
		        				
		        			}else{
		        				model = new ResponseModel("1", "请检查papp.sar.list全局变量是否存在或是否正确");
			                    model.put("executeIp", form.getExecuteIps());
			                    model.put("success", false);
			                    return model;
		        			}
	        			}
	        			
	        			if(StringUtils.isEmpty(sarValue1)){
	        				model = new ResponseModel("1", "获取papp.sar.list的值为空，请检查");
		                    model.put("executeIp", form.getExecuteIps());
		                    model.put("success", false);
		                    return model;
	        			}
	        			
	        			if(!sarValue1.contains(sarName)){
	        				model = new ResponseModel("1", sarName+"组件没有配置在"+key+"文件的papp.sar.list中配置中");
		                    model.put("executeIp", form.getExecuteIps());
		                    model.put("success", false);
	        			}
	        		}else{
	        			model = new ResponseModel("1", key+"配置文件中不存在papp.sar.list配置信息");
	                    model.put("executeIp", form.getExecuteIps());
	                    model.put("success", false);
	        		}
	        	}
        	}else{
        		model = new ResponseModel("1", key+"配置文件内容为空");
                model.put("executeIp", form.getExecuteIps());
                model.put("success", false);
        	}
        }else{
        	Object responseMsg = results.get("responseMsg");
        	
        	if(!StringUtils.isEmpty(responseMsg)){
        		model = new ResponseModel("1", responseMsg.toString());
        	}else{
        		model = new ResponseModel("1", "系统异常");
        	}
            model.put("executeIp", form.getExecuteIps());
            model.put("success", false);
        }
		return model;
	}
}
