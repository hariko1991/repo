package com.pingan.pafa5.admin.pizza.services.impl;

import java.io.IOException; 
import java.io.StringWriter;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;


import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentFactory;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
 



import com.pingan.pafa5.admin.Constants;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dao.IvyLibConfigDAO;
import com.pingan.pafa5.admin.pizza.dto.IvyLibConfigDTO;
import com.pingan.pafa5.admin.pizza.dto.IvyLibSearchDTO;
import com.pingan.pafa5.admin.pizza.exception.ConfigNotExistException;
import com.pingan.pafa5.admin.pizza.po.IvyLibConfigPO;
import com.pingan.pafa5.admin.pizza.services.LibManagerService;
import com.pingan.pafa5.admin.pizza.services.PizzaConfigServices;
import com.pingan.pafa5.admin.pizza.utils.ConfigContentUtils;

/**
 * @see ivy lib存取服务
 * @author JIECHANGKE805
 * @date 2016-05-03
 */
@Service
public class LibManagerServiceImpl implements LibManagerService {
	
	private static final Logger log = Logger.getLogger(LibManagerServiceImpl.class);
	
	@Value("${ivy.lib.prod}")
	private String prodLibUrl;
	
	@Autowired
	private ConfigContentUtils configContentUtils;
	
	@Autowired
	private PizzaConfigServices pizzaConfigServices;
	
	@Autowired
	private IvyLibConfigDAO libConfigDAO;
	
	public static IvyLibConfigDTO currLibConfigDTO;
	
	/**
	 * @see 传入资源组 key：org#module#version#jarName生成ivy.xml文件
	 * @author JIECHANGKE805
	 * @date 2016-05-16
	 * @param  key：内容对应键值
	 * @throws IOException 
	 * @throws RuntimeException 
	 */
	@Override
	public String generateIvyXML(String key){
		
		String[] params = key.substring(0,key.lastIndexOf(".")).split("#");
		
		Document doc = DocumentFactory.getInstance().createDocument();

        Element root = doc.addElement("ivy-module");
          root.addAttribute("version", "2.0");
       
        Element info = root.addElement("info");
          info.addAttribute("organisation", params[0]);
          info.addAttribute("module", params[1]);
          info.addAttribute("revision", params[2]);
          info.addAttribute("status", "release");
        	
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
          info.addAttribute("publication", format.format(new Date()));
        	
        Element pub = root.addElement("publications");
        Element artifact = pub.addElement("artifact");
          artifact.addAttribute("name", params[1]+"-"+params[2]);
          artifact.addAttribute("type", Constants.FILE_TYPE_JAR);
            
          root.addElement("dependencies");
            
        StringWriter writer = new StringWriter();
        OutputFormat out = OutputFormat.createPrettyPrint();
            
        XMLWriter xmlWriter = new XMLWriter(writer,out);
	       if(log.isInfoEnabled()){
	    	   log.info("XML : "+ doc.asXML());
	       }
	        try {
				xmlWriter.write(doc);
			} catch (IOException e) {
				log.error("Error occured when writing ivy.xml,detail is: "+e.getMessage());
			}
             
		return writer.toString();  
		 
	}
	
	
	/**
	 * @see 处理/lib/ivyconf.xml请求，生成文件返回
	 * @author JIECHANGKE805
	 * @date 2016-05-18
	 * @param   
	 * @throws 
	 * @description 已废弃，未整改 
	 */
	public byte[] generateIvyConf(String reqUrl){
		
		Document doc =  DocumentFactory.getInstance().createDocument();

		Element root = doc.addElement("ivysettings");

		Element settings = root.addElement("settings");
			settings.addAttribute("defaultResolver", "default-resolver");
		
		Element statuses = root.addElement("statuses");
			statuses.addAttribute("default", "bronze");
		
		Element statusOne = statuses.addElement("status");
			statusOne.addAttribute("name", "alpha");
			statusOne.addAttribute("integration", "false");

		Element statusTwo = statuses.addElement("status");
			statusTwo.addAttribute("name", "beta");
			statusTwo.addAttribute("integration", "false");

		Element statusThree = statuses.addElement("status");
			statusThree.addAttribute("name", "nightly");
			statusThree.addAttribute("integration", "false");

		Element statusFour = statuses.addElement("status");
			statusFour.addAttribute("name", "release");
			statusFour.addAttribute("integration", "false");
			
		Element resolvers =  root.addElement("resolvers");	
		
		Element chain = resolvers.addElement("chain");
			chain.addAttribute("name", "default-resolver");
			chain.addAttribute("returnFirst", "true");
	    
		Element localUrl = chain.addElement("url");
	      localUrl.addAttribute("name", "local");
	         
	    String libRootUrl = reqUrl.substring(0,reqUrl.indexOf("/libs/")+5);
	    Element localIvy = localUrl.addElement("ivy");
	        localIvy.addAttribute("pattern",libRootUrl.concat(Constants.IVY_PATTERN));
	    Element localArtifact = localUrl.addElement("artifact");
	    	localArtifact.addAttribute("pattern", libRootUrl.concat(Constants.ARTIFACT_PATTERN));
	  
	    Element prodUrl = chain.addElement("url");
           prodUrl.addAttribute("name", "prod");
        Element prodIvy = prodUrl.addElement("ivy");
	       prodIvy.addAttribute("pattern",prodLibUrl.concat(Constants.IVY_PATTERN));
	    Element prodArtifact = prodUrl.addElement("artifact");
	       prodArtifact.addAttribute("pattern", prodLibUrl.concat(Constants.ARTIFACT_PATTERN));
	       
        StringWriter writer = new StringWriter();
        OutputFormat out = OutputFormat.createPrettyPrint();
	            
        XMLWriter xmlWriter = new XMLWriter(writer,out);
	            
	        try {
				xmlWriter.write(doc);
			} catch (IOException e) {
				log.error("Error occured when writing ivy.xml,detail is: "+e.getMessage());
			}
	             
		return writer.toString().getBytes(); 
		 
	}

	/**
	 * @throws IOException 
	 * @see 处理ivy.xml请求，生成文件返回,同时生成sha1
	 * @author JIECHANGKE805
	 * @date 2016-05-19
	 * @param group ： lib
	 * @param key :org#module#version.jar
	 * @param byteValues : jar 文件的字节流经过Base64转码的字符串
	 * @throws  
	 */
	@Override
	public byte[] ivyReqPrepare(String group, String rawkey, String byteValues) throws NoSuchAlgorithmException {
			
		    byte[] xmlStream = null;
		    String xmlContent = null;
		    String key = null;
		    String ivySha1 = null;
		 
			byte[] decodedBytes = configContentUtils.decodeContent(byteValues);
			        String sha1 = configContentUtils.sha1(decodedBytes);
			  if(log.isInfoEnabled()){
				  log.info("sha1 of file "+group+"/"+rawkey+" is : "+sha1);
			  }
			  if(rawkey.indexOf("unknown")!=-1){
				  key = rawkey.replace("unknown#", "").replace("#unknown", "");
			  }else{
				  key = rawkey;
			  } 
				 xmlStream = generateIvyXML(rawkey).getBytes();
				
				if(xmlStream != null){
					
				   xmlContent = configContentUtils.encodeContent(group,key,xmlStream);
					 // 生成ivy.xml的sha1
				     ivySha1 = configContentUtils.sha1(xmlStream);
					  if(log.isInfoEnabled()){
						  log.info("sha1 of file "+group+"/"+key+"is : "+sha1);
					  }
				 
				}
				//TODO 更新ivy lib
				IvyLibConfigPO ivyConfigPO = libConfigDAO.find(group, key);
				
				IvyLibConfigPO libConfigPO =  new IvyLibConfigPO();
				
				libConfigPO.setId(group.concat("/").concat(key));
                libConfigPO.setGroup(group);
                libConfigPO.setKey(key);
                libConfigPO.setIvyByteValue(xmlContent);
                libConfigPO.setJarSha1(sha1);
                libConfigPO.setIvySha1(ivySha1);
                
                libConfigPO.setOrg(ivyConfigPO.getOrg());
                libConfigPO.setModule(ivyConfigPO.getModule());
                libConfigPO.setVersion(ivyConfigPO.getVersion());
                libConfigPO.setValueSize(ivyConfigPO.getValueSize());
                libConfigPO.setFileName(ivyConfigPO.getFileName());
                libConfigPO.setCreatedBy(ivyConfigPO.getCreatedBy());
                libConfigPO.setCreatedDate(ivyConfigPO.getCreatedDate());
                libConfigPO.setUpdatedBy(ivyConfigPO.getUpdatedBy());
                libConfigPO.setUpdatedDate(ivyConfigPO.getUpdatedDate());
                
                libConfigDAO.update(libConfigPO);
			
			return xmlStream;
		
	}
	
	/**
	 *@see 查询ivy配置文件
	 *@author JIECHANGKE805
	 *@since 2016年5月23日
	 *@param group:资源组  key：键值
	 */
	public IvyLibConfigDTO findIvyConfig(String group,String key){
		IvyLibConfigDTO libConfigDTO = new IvyLibConfigDTO() ;
		IvyLibConfigPO libConfigPO = libConfigDAO.find(group, key);
		if(libConfigPO == null){
			throw new ConfigNotExistException("Config "+group+"/"+key+" not exist.");
		}
		  POUtils.copyProperties(libConfigDTO, libConfigPO);
		  currLibConfigDTO = libConfigDTO;
		  
		  return libConfigDTO;
	}
	
	/**
	 *@see 查询ivy配置文件
	 *@author JIECHANGKE805
	 *@since 2016年5月23日
	 *@param group:资源组  key：键值
	 */
	public IvyLibConfigDTO findIvyConfig(String proId, String group,String key){
		IvyLibConfigDTO libConfigDTO = new IvyLibConfigDTO() ;
		IvyLibConfigPO libConfigPO = libConfigDAO.find(proId, group, key);
		if(libConfigPO == null){
			throw new ConfigNotExistException("Config "+proId+"/"+group+"/"+key+" not exist.");
		}
		POUtils.copyProperties(libConfigDTO, libConfigPO);
		currLibConfigDTO = libConfigDTO;
		  
		  return libConfigDTO;
	}

	@Override
	public PageDataDTO<IvyLibConfigPO> searchIvyLib(IvyLibSearchDTO queryDTO) {

         if(queryDTO.getPage()<=1){
        	 queryDTO.setPage(1);
         }
         if(queryDTO.getLimit()>=100){
        	 queryDTO.setLimit(100);
         }
		
		return libConfigDAO.pageQuery(queryDTO);
	}
	
	

}
