package com.pingan.pafa5.admin.pizza.services;

import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.Map;

import com.pingan.pafa5.admin.pizza.dto.InstanceDTO;
import com.pingan.pafa5.admin.pizza.form.PizzaInstanceForm;

public interface PizzaInstanceService {
	
	int addConfig(PizzaInstanceForm instanceForm) throws UnsupportedEncodingException;
	
	int saveConfig(PizzaInstanceForm instanceForm) throws UnsupportedEncodingException;
	
	InstanceDTO getById(PizzaInstanceForm instanceForm);
	
	List<InstanceDTO> getInstances(String projectId,String group,Map<String,String> instancesMap,String instanceIp);
}
