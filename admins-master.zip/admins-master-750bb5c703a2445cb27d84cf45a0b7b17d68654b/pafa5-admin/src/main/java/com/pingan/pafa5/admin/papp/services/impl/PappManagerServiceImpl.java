package com.pingan.pafa5.admin.papp.services.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.papp.dao.PappManagerDAO;
import com.pingan.pafa5.admin.papp.dto.PappManagerDTO;
import com.pingan.pafa5.admin.papp.po.PappManagerPO;
import com.pingan.pafa5.admin.papp.services.PappManagerService;
import com.pingan.pafa5.admin.sso.UserPrincipal;
import com.pingan.pafa5.admin.systems.dto.SystemGroupDTO;
import com.pingan.um.client.util.UUID;

/**
 * 应用管理service
 * 2016-6-14 14:05:06
 * @author HOUSHANGZHI377
 *
 */
@Component
public class PappManagerServiceImpl  extends BaseServices implements PappManagerService 
{
	
	@Autowired
	private PappManagerDAO pappManagerDAO;
	 
	/**
	 * 判断应用是否已注册
	 */
	@Override
	public boolean isExists(PappManagerDTO dto) 
	{
		PappManagerPO po = pappManagerDAO.isExists(dto);
		if(po != null)
		{
			logger.warn("应用ID:" + po.getPappName() + " ,be exists.");
			return true;
		}
		return false;
	}

	/**
	 * 查询应用列表
	 */
	@Override
	public PageDataDTO<PappManagerPO> list(PappManagerDTO dto) 
	{
//		if(!StringUtils.isEmpty(dto.getSystemsId()) && "def".equals(dto.getSystemsId())) {
//			dto.setSystemsId(null);
//		}
		return pappManagerDAO.list(dto);
	}

	/**
	 * 查询应用列表
	 */
	@Override
	public PageDataDTO<PappManagerPO> listUserPapp(PappManagerDTO dto,List<SystemGroupDTO> list) 
	{
		return pappManagerDAO.listUserPapp(dto,list);
	}

	@Override
	public PappManagerDTO getById(String id) {
		PappManagerPO po = pappManagerDAO.getById(id);
		if (po == null) {
			return null;
		}
		PappManagerDTO dto = new PappManagerDTO();
		POUtils.copyProperties(dto, po);
		return dto;
	}
	
	@Override
	public PappManagerDTO getByPappName(String pappName) throws Exception {
		PappManagerPO po = pappManagerDAO.getByProperty("pappName", pappName);
		PappManagerDTO dto = new PappManagerDTO();
		BeanUtils.copyProperties(dto, po);
		return dto;
	}

	@Override
	public boolean updateById(PappManagerDTO form) throws Exception 
	{
		PappManagerPO po = new PappManagerPO();
		PappManagerPO oldpo = pappManagerDAO.getById(form.getId());
		BeanUtils.copyProperties(po, form);
		UserPrincipal up = UserPrincipal.get(true);
		POUtils.setForUpdate(up.getUid(), po);
		po.setCreatedDate(oldpo.getCreatedDate());
		po.setUpdatedDate(new Date());
		return pappManagerDAO.updateById(po);
	}

	@Override
	public void add(PappManagerDTO form) throws Exception {
		PappManagerPO po = new PappManagerPO();
		BeanUtils.copyProperties(po, form);
		UserPrincipal up = UserPrincipal.get(true);
		POUtils.setForAdd(up.getUid(), po);
		po.setId(UUID.getRandomID());
		pappManagerDAO.add(po);
	}

	@Override
	public boolean delById(String id) {
		// TODO Auto-generated method stub
		return pappManagerDAO.delById(id);
	}
}
