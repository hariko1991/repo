package com.pingan.pafa5.admin.pizza.form;

import com.paic.pafa.validator.annotation.VNotEmpty;

/** 同步环境配置
 * 
 * @author zhangjiawei370
 * @author zhanggang871
 *
 */
public class EnvSyncConfigForm {
	
	@VNotEmpty
	private String uri;
	
	@VNotEmpty
	private String loginUser;
	
	@VNotEmpty
	private String loginPwd;
	
	private String targetDomainId;
	
	private String targetDomainName;
	
	private Integer autoSync;//同步类型  关闭，一天一次
	
	private String remark;//备注

    public String getUri() {
        return uri;
    }

    public void setUri(String uri) {
        this.uri = uri;
    }

    public String getLoginUser() {
        return loginUser;
    }

    public void setLoginUser(String loginUser) {
        this.loginUser = loginUser;
    }

    public String getLoginPwd() {
        return loginPwd;
    }

    public void setLoginPwd(String loginPwd) {
        this.loginPwd = loginPwd;
    }

    public String getTargetDomainId() {
        return targetDomainId;
    }

    public void setTargetDomainId(String targetDomainId) {
        this.targetDomainId = targetDomainId;
    }

    public String getTargetDomainName() {
        return targetDomainName;
    }

    public void setTargetDomainName(String targetDomainName) {
        this.targetDomainName = targetDomainName;
    }

    public Integer getAutoSync() {
        return autoSync;
    }

    public void setAutoSync(Integer autoSync) {
        this.autoSync = autoSync;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
	
}
