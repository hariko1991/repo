package com.pingan.pafa5.admin.pizza.listener.impl;

import javax.annotation.Resource;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.common.utils.PURL;
import com.pingan.pafa.pola.ArtifactData;
import com.pingan.pafa.pola.ArtifactInfo;
import com.pingan.pafa.pola.PolaService;
import com.pingan.pafa.pola.dubbo.ArtifactReadService;
import com.pingan.pafa5.admin.pizza.services.PizzaConfigServices;
          
@Service("defDubboArtifactReadService")
public class DubboArtifactReadServiceImpl extends BaseServices implements ArtifactReadService,DisposableBean,InitializingBean{

	@Autowired
	private PizzaConfigServices pizzaConfigServices;
	
	@Resource(name="polaService")
	private PolaService polaService;
	
	@Override
	public ArtifactData readArtifact(String domainId, ArtifactInfo artifactInfo) {
		//System.out.println(artifactInfo.getFileName());
		//System.out.println(artifactInfo.getModule());
		//System.out.println(artifactInfo.getOrganization());
		//System.out.println(artifactInfo.getVersion());
		//System.out.println(artifactInfo.toPizzaKey());
		//System.out.println(artifactInfo.toPathURI());
		ArtifactData artifactData = new ArtifactData();
		byte[] content = null;
		if(artifactInfo.hasGoordinate()){
			String group = subFix(artifactInfo.toPizzaKey());
			content = pizzaConfigServices.getConfigByteContent(domainId, group , artifactInfo.toPizzaKey());
		}else{
			String group = subFix(artifactInfo.getFileName());
			content = pizzaConfigServices.getConfigByteContent(domainId, group , artifactInfo.getFileName());
		}
		
		if(content==null){
			try {
				ArtifactData artifactData1 = polaService.readArtifact(artifactInfo);
				content = artifactData1.getDatas();
				//保存到本地仓库
				
			} catch (Exception e) {
				logger.error("从maven下载依赖包异常",e);
			}
		}
		
		artifactData.setDatas(content);
		return artifactData;
	}
	
	/**
	 * 根据文件名的后缀得到文件所在的分组
	 * @param artifactURI
	 * @return
	 */
	private String subFix(String artifactURI){
		String group = "";
		if(artifactURI.endsWith(".jar")){
			group = "lib";
		}else if(artifactURI.endsWith(".zip")){
			group = "zip";
		}
		return group;
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		String mavenUrl = System.getProperty("maven.url","http://maven-repo.pab.com.cn/repository/maven-public");
		if(mavenUrl != null){
			PURL configURL = PURL.valueOf(mavenUrl);
			configURL.addParameter("connTimeout", 1000);
			configURL.addParameter("readTimeout", 10000);
			configURL.addParameter("connStaleCheck", true);
			try {
				polaService.init(configURL);
			} catch (Exception e) {
				logger.error("",e);
			}
		}
	}

	@Override
	public void destroy() throws Exception {
		polaService.destory();
	}
}
