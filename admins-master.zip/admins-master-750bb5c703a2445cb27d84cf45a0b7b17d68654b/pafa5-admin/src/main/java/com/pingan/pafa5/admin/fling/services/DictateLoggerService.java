package com.pingan.pafa5.admin.fling.services;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.fling.dto.DictateLoggerDTO;

public interface DictateLoggerService {

    /**
     * 批量查询记录
     * 
     * @param domainId
     * @param pappName
     * @param sarName
     * @param size
     * @param page
     * @return
     */
    PageDataDTO<DictateLoggerDTO> list(String domainId, String pappName, String sarName, int size,
            int page);

    /**
     * 查询记录
     * 
     * @param id
     * @return
     */
    DictateLoggerDTO getById(String id);

    /**
     * 查询原因
     * 
     * @param id
     * @return
     */
    String getCause(String id);

}
