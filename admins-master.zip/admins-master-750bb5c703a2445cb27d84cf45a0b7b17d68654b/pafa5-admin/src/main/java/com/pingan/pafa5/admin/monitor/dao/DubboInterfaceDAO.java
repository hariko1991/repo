package com.pingan.pafa5.admin.monitor.dao;

import java.util.Date;
import java.util.List;

import com.pingan.pafa5.admin.monitor.po.DubboInterfacePO;

public interface DubboInterfaceDAO {

    DubboInterfacePO getById(String id);
    
    long count(String interfaceName, Date beginDate, Date endDate);
    
    List<DubboInterfacePO> list(String interfaceName, Date beginDate, Date endDate, int skip, int limit);
    
    void save(DubboInterfacePO po);
    
    void update(DubboInterfacePO po);
    
    void removeByUpdateTime(String updateTime);
    
}
