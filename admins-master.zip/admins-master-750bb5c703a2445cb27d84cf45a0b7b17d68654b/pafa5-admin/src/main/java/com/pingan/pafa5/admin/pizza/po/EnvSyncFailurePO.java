package com.pingan.pafa5.admin.pizza.po;

import java.util.Date;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 失败记录
 * 
 * @author zhangjiawei370
 * @author zhanggang871
 * 
 */
@Document(collection = "pizza_sync_failure")
public class EnvSyncFailurePO {

	/**
	 * ID 由 service层的UUID生成 {@link com.pingan.pafa5.admin.pizza.services.impl.EnvSyncServiceImpl#asyncByGroup}
	 * 
	 */
	@org.springframework.data.annotation.Id
	private String id;
	
	@Indexed
	private String syncId;

	/**
	 * 配置组
	 */
	private String groupId;

	private String pizzKey;

	/**
	 * 失败原因
	 */
	private String cause;

	/**
	 * 时间
	 */
	private Date currDate;

    @Override
    public String toString() {
        return "SyncFailurePO [id=" + id + ", syncId=" + syncId + ", groupId=" + groupId
                + ", pizzKey=" + pizzKey + ", cause=" + cause + ", currDate=" + currDate + "]";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getSyncId() {
        return syncId;
    }

    public void setSyncId(String syncId) {
        this.syncId = syncId;
    }

    public String getGroupId() {
        return groupId;
    }

    public void setGroupId(String groupId) {
        this.groupId = groupId;
    }

    public String getPizzKey() {
        return pizzKey;
    }

    public void setPizzKey(String pizzKey) {
        this.pizzKey = pizzKey;
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    public Date getCurrDate() {
        return currDate;
    }

    public void setCurrDate(Date currDate) {
        this.currDate = currDate;
    }

}
