package com.pingan.pafa5.admin.fling.dao;

import com.pingan.pafa5.admin.fling.po.FlingPappStatusMonitorMsgPO;

public interface FlingPappStatusMonitorMsgDAO {

    void add(FlingPappStatusMonitorMsgPO po);

}
