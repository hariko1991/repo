package com.pingan.pafa5.admin.pizza.web;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.validator.annotation.Valid;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa.pizza.classloader.PizzaURL;
import com.pingan.pafa5.admin.Constants;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.commons.SARManagerConstants;
import com.pingan.pafa5.admin.commons.SqlUtils;
import com.pingan.pafa5.admin.pizza.PizzaConstants.ConfigHistoryOperationType;
import com.pingan.pafa5.admin.pizza.PizzaConstants.VersionOperationType;
import com.pingan.pafa5.admin.pizza.dto.ConfigItemInfoDTO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSaveDTO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSearchDTO;
import com.pingan.pafa5.admin.pizza.dto.ConfigUploadDTO;
import com.pingan.pafa5.admin.pizza.exception.ConfigNotExistException;
import com.pingan.pafa5.admin.pizza.form.PizzaConfigForm;
import com.pingan.pafa5.admin.pizza.po.ConfigGroupPO;
import com.pingan.pafa5.admin.pizza.po.FileTempPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigPO;
import com.pingan.pafa5.admin.pizza.services.ConfigGroupServices;
import com.pingan.pafa5.admin.pizza.services.PizzaConfigServices;
import com.pingan.pafa5.admin.pizza.utils.ConfigContentUtils;
import com.pingan.pafa5.admin.pizza.utils.DataSourceCheck;
import com.pingan.pafa5.admin.sso.UserPrincipal;
import com.pingan.um.client.util.StringUtil;

@Controller
@RequestMapping("/pizzamgr")
public final class ConfigManagerController {

	private Log logger = LogFactory.getLog(this.getClass());

	/** 非文本文件 */
	private static final List<String> NOT_TEXT_FILE = Arrays.asList("jar", "zip", "rar", "war", "JAR", "ZIP", "RAR", "WAR");

	@Autowired
	private PizzaConfigServices pizzaConfigServices;

	@Autowired
	private ConfigGroupServices configGroupServices;

	@Autowired
	private ConfigContentUtils configContentUtils;

	@ActionClient(name = "pafa5-admin-systems.isOwner")
	private IServiceClient ownerService;
	
	@ActionClient(name = "pafa5-admin-sar.del-sar")
	private IServiceClient sARManagerService;
	
	@ActionClient(name = "pafa5-admin-papp.delPapp")
	private IServiceClient pappManagerService;
	
	@Value(value="${datasource.max.active}")
	private int maxActive=100;

	// 校验key是否已存在
	@RequestMapping("/validatekey.do")
	@ResponseBody
	public ModelMap checkExists(@RequestParam("group") String group,
			@RequestParam("key") String key) throws Throwable {
		boolean flag = pizzaConfigServices.checkExists(null, group, key);
		ModelMap model = new ResponseModel();
		model.put("code", flag + "");
		model.put("success", true);
		return model;
	}

	@RequestMapping("/listKeys.do")
	@ESA(value = "pafa5-admin-pizza.listKeys", local = true)
	@ResponseBody
	public ModelMap listKeys(
			@RequestParam("projectId") String projectId,
			@RequestParam("group") String group,
			@RequestParam(value = "keyRegex", required = false) String keyRegex,
			@RequestParam(value = "likeKey", required = false) String likeKey)
			throws Throwable {

		if (likeKey != null && (likeKey = likeKey.trim()).length() > 0) {

			if (SqlUtils.SPRING_PROFILE_NOSQL.equalsIgnoreCase(SqlUtils
					.getSpringProfilesActive())) {
				keyRegex = "^" + likeKey + ".*$";
			} else {
				keyRegex = likeKey + "%";
			}
		}
		List<String> keys = pizzaConfigServices.listKeys(projectId, group,
				keyRegex);
		ModelMap model = new ResponseModel("0");
		model.put("keySize", keys == null ? 0 : keys.size());
		model.put("keys", keys);
		return model;
	}

	@RequestMapping("/changeConfigProject.do")
	@ESA(value = "pafa5-admin-pizza.changeConfigProject", local = true)
	@ResponseBody
	public ModelMap changeConfigProject(
			@RequestParam(value = "group", required = true) String group,
			@RequestParam(value = "pizzaKey", required = true) String key,
			@RequestParam(value = "projectId", required = true) String projectId,
			@RequestParam(value = "projectName", required = true) String projectName)
			throws Throwable {
		isOwner(projectId);

		boolean success = pizzaConfigServices.changeConfigProject(group, key,
				projectId, projectName);
		ModelMap model = new ResponseModel("0");
		model.put("success", success);
		return model;
	}

	// 上传配置信息
	@RequestMapping("/uploadConfigItem.do")
	@ResponseBody
	public ModelMap upload(@Valid ConfigUploadDTO form) throws Throwable {
		isOwner(form.getProjectId());

		if (logger.isInfoEnabled()) {
			logger.info("UploadContentType:"+ form.getUpload().getContentType());
			logger.info("Bytes.length=" + form.getUpload().getBytes().length+ ";size=" + form.getUpload().getSize());
		}
		String responseMsg = "上传成功!";
		String originalFilename = form.getUpload().getOriginalFilename();
		if (StringUtil.isNotEmpty(originalFilename)) {
			if (originalFilename.length() > 250) {
				responseMsg = "上传文件名过长！";
				ResponseModel map = new ResponseModel();
				map.put("success", false);
				map.setResponseMsg(responseMsg);
				return map;
			}
		}
		int maxSize = configContentUtils.getMaxSize();
		if (maxSize > 0 && form.getUpload().getSize() > maxSize) {
			ResponseModel map = new ResponseModel("40040");
			map.put("failure", "true");
			map.put("responseMsg", "上传文件大小="
					+ (form.getUpload().getSize() / 1024) + "KB，超过限制大小="
					+ (maxSize / 1024) + "KB.");
			return map;
		}
		byte[] datas = form.getUpload().getBytes();
		PizzaURL url = PizzaURL.valueOf(form.getGroup(), form.getKey());
		String group = url.getPizzaGroup();
		String key = url.getPizzaKey();
		// add_upload
		if (logger.isInfoEnabled()) {
			logger.info("PizzaURL=" + url);
		}

		if (group == null || (group = group.trim()).length() == 0) {
			responseMsg = "配置组为空,上传失败!";
		} else if (key == null || (key = key.trim()).length() == 0) {
			responseMsg = "配置键为空,上传失败!";
		} else {
			try {
				String content = configContentUtils.encodeContent(group, key, datas);
				form.setValue(content);

				int result = pizzaConfigServices.save(form);

				if (result == 0) {
					ResponseModel map = new ResponseModel();
					map.put("success", "true");
					map.put("responseMsg", responseMsg);
					map.put("msg", responseMsg);
					return map;
				} else if (result == 1) {
					responseMsg = "配置文件未变化。";
					ResponseModel map = new ResponseModel();
					map.put("success", "true");
					map.put("responseMsg", responseMsg);
					map.put("msg", responseMsg);
					return map;
				} else {
					responseMsg = "上传失败，系统错误或配置中心错误。";
				}
			} catch (ResponseCodeException ex) {
				responseMsg = ex.getMessage();
			}
		}
		ModelMap map = new ResponseModel("4000", responseMsg);
		map.put("failure", "true");
		map.put("responseMsg", responseMsg);
		map.put("msg", responseMsg);
		return map;
	}

	/**
	 * 上传配置文件
	 * 
	 * @param form
	 * @return
	 * @throws Throwable
	 */
	@RequestMapping("/uploadConfigFile.do")
	@ResponseBody
	public ModelMap uploadConfigFile(@Valid ConfigUploadDTO form) throws Throwable {
		isOwner(form.getProjectId());

		// 获取文件后缀
		String fileName = form.getUpload().getOriginalFilename();
		String msg = "";
		// 文件名长度限制
		if (StringUtil.isNotNull(fileName) && fileName.length() > 250) {
			msg = "上传文件名过长,不超过250个字符！";
			ResponseModel map = new ResponseModel();
			map.put("success", false);
			map.setResponseMsg(msg);
			return map;
		}
		int idx = fileName.lastIndexOf(".");
		String ext = "";
		if (idx != -1) {
			ext = fileName.substring(idx + 1, fileName.length());
		}
		if (!ext.equalsIgnoreCase("xml") && !ext.equalsIgnoreCase("zip")
				&& !ext.equalsIgnoreCase("json")
				&& !ext.equalsIgnoreCase("properties")
				&& !ext.equalsIgnoreCase("jar") && !ext.equals("")) {
			ModelMap map = new ResponseModel("40041");
			map.put("success", false);
			map.put("responseMsg", "只能上传【xml、jar、zip、json、properties,和无后缀名文件】五种类型的配置文件");
			return map;
		}

		int maxSize = configContentUtils.getMaxSize();
		// 文件大小不超过3M 3145728kb
		if (maxSize > 0 && form.getUpload().getSize() > maxSize) {
			ModelMap map = new ResponseModel("40040");
			map.put("success", false);
			msg = "上传文件大小=" + (form.getUpload().getSize() / 1024) + "KB，超过限制大小=" + (maxSize / 1024) + "KB.";
			map.put("responseMsg", msg);
			map.put("msg", msg);
			return map;
		}
		byte[] datas = form.getUpload().getBytes();
		// 检测group/key作为主键是否有重复数据
		PizzaURL url = PizzaURL.valueOf(form.getGroup(), form.getKey());
		String group = url.getPizzaGroup();
		String key = url.getPizzaKey();
		String content = "";
		ModelMap map = new ResponseModel("0");
		String responseMsg = "上传成功!";
		boolean success = false;
		if (group == null || (group = group.trim()).length() == 0) {
			responseMsg = "配置组为空,上传失败!";
		} else if (key == null || (key = key.trim()).length() == 0) {
			responseMsg = "配置键为空,上传失败!";
		} else {
			try {
				// to do check key isExit
				content = configContentUtils.encodeContent(group, key, datas);

				// 只有 "jar", "zip", "rar", "war", "JAR", "ZIP", "RAR", "WAR"
				// 转换成二进制，其他的都转为String
				if (NOT_TEXT_FILE.contains(ext)) {
					content = Base64.encodeBase64String(datas);
					// 将二进制文件保存到临时文件
					String uuid = pizzaConfigServices.saveFileTemp(content);
					map.put("content", uuid);
					map.put("type", ext);
					
				} else {
					if (ext.equalsIgnoreCase("xml")
							|| ext.equalsIgnoreCase("html")
							|| ext.equalsIgnoreCase("htm")) {
						content = replaceHtml(content);
					}
					map.put("content", content);
					map.put("type", "text");
				}
				map.put("ext", ext);
				success = true;

			} catch (ResponseCodeException ex) {
				responseMsg = ex.getMessage();
			}
		}

		map.put("success", success);
		map.put("responseMsg", responseMsg);
		map.put("msg", responseMsg);
		return map;
	}

	/**
	 * 初始配置组下拉框
	 */
	@RequestMapping("/initGroups.do")
	@ResponseBody
	public List<ModelMap> listGroups(HttpServletResponse response)
			throws Exception {
		List<ConfigGroupPO> datas = configGroupServices.list(true);
		List<ModelMap> resturns = new ArrayList<ModelMap>();
		// resturns.add(new ModelMap().addAttribute("groupCode",
		// "").addAttribute("groupName", "--请选择--"));
		for (ConfigGroupPO config : datas) {
			resturns.add(new ModelMap().addAttribute("groupCode",
					config.getGroupCode()).addAttribute("groupName",
					config.getGroupName() + "(" + config.getGroupCode() + ")"));
		}
		return resturns;
	}

	@ESA(value = "pafa5_admin_pizza.getGroup", local = true)
	@ResponseBody
	public ModelMap getGroup(@RequestParam("groupCode") String groupCode)
			throws Exception {
		ConfigGroupPO group = configGroupServices.getGroup(groupCode);
		if (group == null) {
			return new ResponseModel("1", "配置组不存在。");
		} else {
			ModelMap model = new ResponseModel();
			model.put("groupCode", group.getGroupCode());
			model.put("groupName", group.getGroupName());
			model.put("isBinary", group.isBinary());
			return model;
		}
	}

	@RequestMapping("/get-pizzakey-group.do")
	@ResponseBody
	public ModelMap listPizzaKeyByGroup(
			@RequestParam(value = "projectId", required = true) String projectId,
			@RequestParam(value = "group", required = true) String group) {
		ModelMap model = new ResponseModel();
		List<PizzaConfigPO> list = pizzaConfigServices.getPizzaKey(projectId, group);
		if (list != null && list.size() > 0) {
			List<ModelMap> result = new ArrayList<ModelMap>();
			for (PizzaConfigPO po : list) {
				ModelMap map = new ModelMap();
				map.put("id", po.getId());
				map.put("pizzaKey", po.getPizzaKey());
				result.add(map);
			}
			model.put("data", result);
		}
		return model;
	}

	/**
	 * 查询配置项
	 */
	@RequestMapping("/queryConfigItems.do")
	@ResponseBody
	@ESA(value = "pafa5_admin_pizza.search", local = true)
	public ModelMap search(@Valid ConfigSearchDTO form) throws Throwable {
		if (logger.isInfoEnabled()) {
			logger.info("查询配置项:" + JSONObject.toJSONString(form));
		}
		PageDataDTO<PizzaConfigPO> pageDatas = pizzaConfigServices.search(form);

		List<PizzaConfigPO> dblist = pageDatas.getDatas();
		List<ConfigItemInfoDTO> configItems = new ArrayList<ConfigItemInfoDTO>();
		if (dblist != null && dblist.size() >= 0) {
			if (logger.isInfoEnabled()) {
				logger.info("datasize is:" + dblist.size());
			}
			DateFormat formatter = null;
			if (form.isFormatDate()) {
				formatter = DateFormat.getDateTimeInstance();
			}
			for (PizzaConfigPO to : dblist) {
				ConfigItemInfoDTO vo = new ConfigItemInfoDTO();
				String groupName = configGroupServices.getGroupName(to.getPizzaGroup());
				String uri = "/config-show.do?group=" + to.getPizzaGroup()+ "&key=" + to.getPizzaKey();

				vo.setGroup(to.getPizzaGroup());
				vo.setKey(to.getPizzaKey());
				vo.setGroupName(groupName + "(" + to.getPizzaGroup() + ")");
				vo.setUri(uri);
				vo.setValueMd5(to.getValueMd5());

				Integer valueSize = to.getValueSize();
				vo.setValueSize(valueSize == null ? -1 : valueSize);
				vo.setCreatedBy(to.getCreatedBy());
				vo.setUpdatedBy(to.getUpdatedBy());
				if (form.isFormatDate()) {
					if (to.getCreatedDate() != null) {
						vo.setCreatedDate(formatter.format(to.getCreatedDate()));
					}
					if (to.getUpdatedDate() != null) {
						vo.setUpdatedDate(formatter.format(to.getUpdatedDate()));
					} else {
						Date date = new Date();
						SimpleDateFormat Standformat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
						String updatedDate = Standformat.format(date);
						vo.setUpdatedDate(updatedDate);
					}
				} else {
					if (to.getCreatedDate() != null) {
						vo.setCreatedDate(String.valueOf(to.getCreatedDate().getTime()));
					}
					vo.setUpdatedDate(String.valueOf(to.getUpdatedDate().getTime()));
				}
				String proId = to.getProjectId();
				if (proId == null|| SARManagerConstants.DEF.equalsIgnoreCase(proId)) {
					vo.setProjectId("def");
				} else {
					vo.setProjectId(to.getProjectId());
				}
				configItems.add(vo);
			}
		} else {
			if (logger.isInfoEnabled()) {
				logger.info("datasize is:" + 0);
			}
		}
		ModelMap model = new ResponseModel();
		model.put("totalProperty", pageDatas.getTotalSize());
		model.put("root", configItems);
		return model;
	}

	/**
	 * 查询配置项接口
	 */
	@RequestMapping("/getConfigItems.do")
	@ResponseBody
	@ESA(value = "pafa5_admin_pizza.getConfigItems", local = true)
	public ModelMap query(
			@RequestParam(value = "projectId", required = true) String projectId,
			@RequestParam(value = "group", required = true) String group,
			@RequestParam(value = "file", required = false) String regexKey,
			@RequestParam(value = "pattern", required = false) String pattern)
			throws Throwable {
		List<PizzaConfigPO> list = pizzaConfigServices.query(projectId, group, regexKey, pattern);
		List<ConfigItemInfoDTO> datas = new ArrayList<ConfigItemInfoDTO>();
		if (list != null && list.size() > 0) {
			for (PizzaConfigPO to : list) {
				ConfigItemInfoDTO vo = new ConfigItemInfoDTO();
				String groupName = configGroupServices.getGroupName(to.getPizzaGroup());
				String uri = "/config-show.do?group=" + to.getPizzaGroup()+ "&key=" + to.getPizzaKey();
				vo.setGroup(to.getPizzaGroup());
				vo.setKey(to.getPizzaKey());
				vo.setGroupName(groupName + "(" + to.getPizzaGroup() + ")");
				vo.setUri(uri);
				vo.setValueMd5(to.getValueMd5());

				Integer valueSize = to.getValueSize();
				vo.setValueSize(valueSize == null ? -1 : valueSize);
				vo.setUpdatedBy(to.getUpdatedBy());
				datas.add(vo);
			}
		}
		ModelMap model = new ResponseModel();
		model.put("datas", datas);
		return model;
	}

	// 获取单个配置信息
	@RequestMapping("/getConfigItem.do")
	@ESA(value = "pafa5_admin_pizza.getConfigItem", local = true)
	@ResponseBody
	public ModelMap getContent(@RequestParam("projectId") String proId,
			@RequestParam("group") String group, @RequestParam("key") String key)
			throws Throwable {
		String value = pizzaConfigServices.getConfigContent(proId, group, key);
		ResponseModel model = new ResponseModel();
		if (value != null && value.trim().length() > 0) {
			value = value.replaceAll("	", "   ").replaceAll("\t", "   ");
			if (logger.isInfoEnabled()) {
				logger.info("ReplaceAll Result = " + JSONObject.toJSONString(value));
			}
			model.put("success", true);
			model.put("value", value);
		} else {
			model.setResponseCode("400101");
			model.put("success", false);
			model.setResponseMsg("请求内容为空。");
		}
		return model;
	}
	
	@ESA(value = "pafa5_admin_pizza.getConfigItemValue", local = true)
	@ResponseBody
	public ModelMap getConfigItemValue(@RequestParam("projectId") String proId,
			@RequestParam("group") String group, @RequestParam("key") String key)
			throws Throwable {
		ResponseModel model = new ResponseModel();
		boolean flag = pizzaConfigServices.checkExists(proId,group, key);
		if(flag){
			String value = pizzaConfigServices.getConfigContent(proId, group, key);
			if (value != null && value.trim().length() > 0) {
				value = value.replaceAll("	", "   ").replaceAll("\t", "   ");
				if (logger.isInfoEnabled()) {
					logger.info("ReplaceAll Result = " + JSONObject.toJSONString(value));
				}
				model.put("success", true);
				model.put("value", value);
			} else {
				model.setResponseCode("400101");
				model.put("success", false);
				model.setResponseMsg("请求内容为空。");
			}
		}else{
			model.put("success", false);
			model.setResponseMsg(key+"配置文件不存在");
		}
		return model;
	}

	/**
	 * 获取配置信息
	 * 
	 * @param group
	 * @param key
	 * @return
	 * @throws Throwable
	 */
	@RequestMapping("/getConfigItem2.do")
	@ResponseBody
	public ModelMap getContent2(@RequestParam("group") String group,
			@RequestParam("key") String key) throws Throwable {
		ModelMap model = new ResponseModel();

		int idx = key.lastIndexOf(".");
		String ext = key.substring(idx + 1);

		String value = "";
		try {
			value = pizzaConfigServices.getConfigContent(null, group, key);
		} catch (ConfigNotExistException ex) {
			if (NOT_TEXT_FILE.contains(ext)) {
				value = "";
			} else {
				throw ex;
			}
		}

		model.put("value", value);
		return model;
	}

	@RequestMapping("/saveConfigItem.do")
	@ESA(value = "pafa5_admin_pizza.saveConfigFile", local = true)
	@ResponseBody
	public ResponseModel save(@Valid ConfigSaveDTO form) throws Throwable {
		isOwner(form.getProjectId());

		PizzaURL url = PizzaURL.valueOf(form.getGroup(), form.getKey());
		String group = url.getPizzaGroup();
		String key = url.getPizzaKey();

		String optype = form.getOptype();
		if ("add".equals(optype) || "2".equals(optype)) {
			boolean flag = pizzaConfigServices.checkExists(form.getProjectId(),group, key);
			if (flag) {
				ResponseModel map = new ResponseModel();
				map.put("success", false);
				map.put("responseMsg", "配置键已经存在，只允许修改");
				map.put("msg", "配置键已经存在，只允许修改");
				return map;
			}
			form.setOptype("2");
		}
		int idx = key.lastIndexOf(".");
		String ext = key.substring(idx + 1);
//		String origValue = form.getValue();
//		byte[] datas =(byte[]) (origValue==null ? 0:origValue.getBytes());
//		byte[] datas = form.getBytesValue();
//		String uuid = "";
//		if (NOT_TEXT_FILE.contains(ext)) {
//			String content = configContentUtils
//					.encodeContent(group, key, datas);
//			content = Base64.encodeBase64String(datas);
//			// 将二进制文件保存到临时文件
//			uuid = pizzaConfigServices.saveFileTemp(content);
//		}

		byte[] bytesValue = form.getBytesValue();
		/*if(bytesValue==null&& VersionOperationType.VERSION_ROLLBACK.equals(optype)){
			String origValue=form.getValue();
			bytesValue=(byte[]) (origValue==null ? 0:Base64.decodeBase64(origValue));
			form.setOptype(ConfigHistoryOperationType.UPDATE);
		}*/
		
		if(VersionOperationType.VERSION_ROLLBACK.equals(optype)){
			//String origValue=form.getValue();
			//bytesValue=(byte[]) (origValue==null ? 0:Base64.decodeBase64(origValue));
			form.setOptype(ConfigHistoryOperationType.UPDATE);
		}
		
		if(VersionOperationType.VERSION_RELEASE.equals(optype)){
			form.setOptype(ConfigHistoryOperationType.UPDATE);
		}
		
		logger.info("save ext="+ext);
		if (NOT_TEXT_FILE.contains(ext)) {
			String content = "";
			String origValue=form.getValue();
			
			if(bytesValue!=null){
				content = Base64.encodeBase64String(bytesValue);
			}else if(origValue!=null){
				content = origValue;
			}
			form.setValue(content);
			/*String uuid = pizzaConfigServices.saveFileTemp(content);
			if (StringUtil.isNotEmpty(uuid)) {
				FileTempPO tempPO = pizzaConfigServices.getFileTempById(uuid);
				if (tempPO != null) {
					form.setValue(tempPO.getBytes());
				} else {
					ResponseModel map = new ResponseModel();
					map.put("success", false);
					map.put("responseMsg", "文件不能为空");
					map.put("msg", "文件不能为空");
					return map;
				}
			} else {
				ResponseModel map = new ResponseModel();
				map.put("success", true);
				map.put("responseMsg", "配置文件未变化");
				map.put("msg", "配置文件未变化");
				return map;
			}*/
		} else {
			try {
				if (bytesValue != null) {
					logger.info("save bytesValue="+bytesValue+",length="+bytesValue.length);
					String value = this.configContentUtils.encodeContent(group,key, bytesValue);
					logger.info("save value="+value);
					form.setValue(value);
					this.configContentUtils.checkContent(group, key, value);
				}
			} catch (ResponseCodeException ex) {
				ResponseModel model = new ResponseModel(ex.getResponseCode());
				model.put("failure", "true");
				model.put("responseMsg", ex.getResponseMsg());
				model.put("msg", ex.getResponseMsg());
				return model;
			}
		}

		int result = pizzaConfigServices.save(form);
		String responseMsg = null;
		if (result == 0) {
			ResponseModel map = new ResponseModel();
			map.put("success", "true");
			map.put("msg", "保存成功。");
			return map;
		} else if (result == 1) {
			responseMsg = "配置文件未变化。";
			ResponseModel map = new ResponseModel();
			map.put("success", "true");
//			map.put("responseMsg", responseMsg);
			map.put("msg", responseMsg);
			return map;
		} else {
			responseMsg = "保存失败，系统错误或者配置中心访问错误。";
		}
		ResponseModel model = new ResponseModel();
		model.put("failure", "true");
		model.put("msg", responseMsg);
		return model;
	}

	/**
	 * 保存配置信息
	 * 
	 * @param form
	 * @return
	 * @throws Throwable
	 */
	@RequestMapping("/saveConfig.do")
	@ESA(value = "pafa5-admin-pizza.saveConfig", local = true)
	@ResponseBody
	public ResponseModel saveConfig(@Valid ConfigSaveDTO form) throws Throwable {
		isOwner(form.getProjectId());
		ResponseModel map = new ResponseModel();
		if (form.getValue() == null || form.getValue().trim().length() == 0) {
			throw new NullPointerException("value is null.");
		}
		if (form.getKey() == null || form.getKey().trim().length() == 0) {
			throw new NullPointerException("itemkey is null.");
		}
		form.setValue(form.getValue().trim());
		
		form.setKey(form.getKey().trim());
		PizzaURL url = PizzaURL.valueOf(form.getGroup(), form.getKey());
		String group = url.getPizzaGroup();
		String key = url.getPizzaKey();
		String proId = form.getProjectId();
		String optype = form.getOptype();
		if ("add".equals(optype) || "2".equals(optype)) { // add 新增文件资源 1 编辑配置文件
															// , 上传新的配置文件，依赖包
															// 也是1 2
			boolean flag = pizzaConfigServices.checkExists(proId, group, key);
			if (flag) {
				map.put("success", false);
				map.put("responseMsg", "配置键已经存在，只允许修改");
				return map;
			}
			form.setOptype("2");
		}
		String uuid = form.getUuid();
		int idx = key.lastIndexOf(".");
		String ext = key.substring(idx + 1);
		if (Constants.LIB_GROUP.equals(group) && (!"jar".equalsIgnoreCase(ext) || idx == -1)) {
			map.put("success", false);
			map.put("responseMsg", "lib下只能新增jar文件");
			return map;
		}

		if (NOT_TEXT_FILE.contains(ext)) {
			// 如果是压缩类型的， 先获取文件ID，在从数据库中把临时表的数据拿出来，存放到value里面
			if (StringUtil.isNotEmpty(uuid)) {
				FileTempPO tempPO = pizzaConfigServices.getFileTempById(uuid);
				if (tempPO != null) {
					form.setValue(tempPO.getBytes());
				} else {
					map.put("success", false);
					map.put("responseMsg", "文件不能为空");
					map.put("msg", "文件不能为空");
					return map;
				}
			} else {
				map.put("success", true);
				map.put("responseMsg", "配置文件未变化");
				map.put("msg", "配置文件未变化");
				return map;
			}
		} else {
			try {
				this.configContentUtils.checkContent(group, key,form.getValue());
			} catch (ResponseCodeException ex) {
				ResponseModel model = new ResponseModel(ex.getResponseCode());
				model.put("failure", "true");
				model.put("responseMsg", ex.getMessage());
				model.put("msg", ex.getMessage());
				return model;
			}
		}
		// 缺少IvyLib coding
		int result = pizzaConfigServices.save(form);
		String responseMsg = null;
		if (result == 0) {
			if (StringUtil.isNotEmpty(uuid)) {
				pizzaConfigServices.delFileTempById(uuid);
			}
			
			int resultCheck = DataSourceCheck.checkMaxActive(form.getValue(), maxActive);
			if(resultCheck>0) {
				map.put("resultCheck", resultCheck);
				map.put("success", false);
				map.put("responseMsg", "保存成功，但是数据源连接池最大连接数：maxActive超过"+maxActive+"。");
				map.put("msg", "保存成功。");
				
				sendEmail(form.getProjectName(), proId, group, key, resultCheck);
				return map;
			}
			
			map.put("success", true);
			map.put("responseMsg", "保存成功。");
			map.put("msg", "保存成功。");
			return map;
		} else if (result == 1) {
			int resultCheck = DataSourceCheck.checkMaxActive(form.getValue(), maxActive);
			if(resultCheck>0) {
				map.put("resultCheck", resultCheck);
				map.put("success", false);
				map.put("responseMsg", "配置文件未变化，但是数据源连接池最大连接数：maxActive超过"+maxActive+"。");
				map.put("msg", "保存成功。");
				sendEmail(form.getProjectName(), proId, group, key, resultCheck);
				return map;
			}
			
			responseMsg = "配置文件未变化。";
			map.put("success", true);
			map.put("responseMsg", responseMsg);
			map.put("msg", responseMsg);
			return map;
		} else if (result == 3) {
			responseMsg = "保存失败，依赖包键值格式为jarName.jar或org#module#version.jar。";
		} else {
			responseMsg = "保存失败，系统错误或者配置中心访问错误。";
		}
		ResponseModel model = new ResponseModel();
		model.put("success", false);
		model.put("responseMsg", responseMsg);
		model.put("msg", responseMsg);
		return model;
	}
	
	@ActionClient(name="pafa5-admin-mail.sendMail")
	private IServiceClient sendMailService;
	
	public void sendEmail(String projectName,String projectId,String group,String key,int nowMaxActive) {
		ServiceParams params = ServiceParams.newInstance();
		params.put("mailTemplate", "checkDataSource.ftl");
		params.put("subject", "数据库连接池最大连接数告警通知");

		Map<String,Object> context = new HashMap<String,Object>();
		context.put("projectName",projectName);
		context.put("projectId", projectId);
		context.put("group", group);
		context.put("key", key);
		context.put("maxActive", maxActive);
		context.put("nowMaxActive", nowMaxActive);
		List<String> toList = new ArrayList<String>();
		toList.add("ML_17898@pingan.com.cn");
		UserPrincipal principal = UserPrincipal.get(true);
		toList.add(principal.getUid()+"@pingan.com.cn");
		
		params.put("context", context);
		params.put("toList", toList);
		sendMailService.invoke(params);
	}

	@RequestMapping("/logMonitorSave.do")
	@ESA(value = "pafa5-admin-pizza.logMonitorSave", local = true)
	@ResponseBody
	public ResponseModel logMonitorSave(@Valid ConfigSaveDTO form)
			throws Throwable {
		isOwner(form.getProjectId());

		PizzaURL url = PizzaURL.valueOf(form.getGroup(), form.getKey());
		String domainId = form.getProjectId();
		String group = url.getPizzaGroup();
		String key = url.getPizzaKey();
		boolean flag = pizzaConfigServices.checkExists(domainId, group, key);
		form.setOptype(flag ? "update" : "add");

		int result = pizzaConfigServices.save(form);
		String responseMsg = null;
		if (result == 0) {
			ResponseModel map = new ResponseModel();
			map.put("success", true);
			map.put("responseMsg", "保存成功。");
			return map;
		} else if (result == 1) {
			responseMsg = "配置文件未变化。";
			ResponseModel map = new ResponseModel();
			map.put("success", true);
			map.put("responseMsg", responseMsg);
			map.put("msg", responseMsg);
			return map;
		} else {
			responseMsg = "保存失败，系统错误或者配置中心访问错误。";
		}
		ResponseModel model = new ResponseModel();
		model.put("success", false);
		model.put("responseMsg", responseMsg);
		model.put("msg", responseMsg);
		return model;
	}

	/**
	 * 保存配置信息 存在就修改，不存在就新增
	 * 
	 * @param form
	 * @return
	 * @throws Throwable
	 */
	@RequestMapping("/modifyConfig.do")
	@ESA(value = "pafa5-admin-pizza.modifyConfig", local = true)
	@ResponseBody
	public ResponseModel modifyConfig(@Valid ConfigSaveDTO form)
			throws Throwable {
		isOwner(form.getProjectId());

		PizzaURL url = PizzaURL.valueOf(form.getGroup(), form.getKey());
		String domainId = form.getProjectId();
		String group = url.getPizzaGroup();
		String key = url.getPizzaKey();
		boolean flag = pizzaConfigServices.checkExists(domainId, group, key);
		form.setOptype(flag ? "update" : "add");

		int result = pizzaConfigServices.save(form);
		String responseMsg = null;
		if (result == 0) {
			ResponseModel map = new ResponseModel();
			map.put("success", true);
			map.put("responseMsg", "保存成功。");
			map.put("msg", responseMsg);
			return map;
		} else if (result == 1) {
			responseMsg = "配置文件未变化。";
			ResponseModel map = new ResponseModel();
			map.put("success", true);
			map.put("responseMsg", responseMsg);
			map.put("msg", responseMsg);
			return map;
		} else {
			responseMsg = "保存失败，系统错误或者配置中心访问错误。";
		}
		ResponseModel model = new ResponseModel();
		model.put("success", false);
		model.put("responseMsg", responseMsg);
		model.put("msg", responseMsg);
		return model;
	}

	/**
	 * 专属连接池使用********************************* 保存配置信息 存在就修改，不存在就新增
	 * 
	 * @param form
	 * @return
	 * @throws Throwable
	 */
	@RequestMapping("/modifyConfigForPool.do")
	@ESA(value = "pafa5-admin-pizza.modifyConfigForPool", local = true)
	@ResponseBody
	public ResponseModel modifyConfigForPool(@Valid ConfigSaveDTO form)
			throws Throwable {
		isOwner(form.getProjectId());

		PizzaURL url = PizzaURL.valueOf(form.getGroup(), form.getKey());
		String group = url.getPizzaGroup();
		String key = url.getPizzaKey();
		String proId = form.getProjectId();
		String proName = form.getProjectName();
		boolean flag = pizzaConfigServices.checkExists(proId, group, key);
		form.setOptype(flag ? "update" : "add");
		form.setProjectId(proId);
		form.setProjectName(proName);

		int result = pizzaConfigServices.save(form);
		String responseMsg = null;
		if (result == 0) {
			ResponseModel map = new ResponseModel();
			map.put("success", true);
			map.put("responseMsg", "保存成功。");
			map.put("msg", "保存成功。");
			return map;
		} else if (result == 1) {
			responseMsg = "配置文件未变化。";
			ResponseModel map = new ResponseModel();
			map.put("success", true);
			map.put("responseMsg", responseMsg);
			map.put("msg", responseMsg);
			return map;
		} else {
			responseMsg = "保存失败，系统错误或者配置中心访问错误。";
		}
		ResponseModel model = new ResponseModel();
		model.put("success", false);
		model.put("responseMsg", responseMsg);
		model.put("responseMsg", responseMsg);
		return model;
	}

	// 查看单个配置文件信息
	@RequestMapping("/config-download.do")
	@ResponseBody
	public ModelMap download(@RequestParam("projectId") String proId,
			@RequestParam("group") String group,
			@RequestParam("key") String key, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		return configshow(proId, group, key, request, response);
	}

	// 查看单个配置文件信息
	@RequestMapping("/config-show.do")
	@ResponseBody
	public ModelMap configshow(@RequestParam("projectId") String proId,
			@RequestParam("group") String group,
			@RequestParam("key") String key, HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		// 设置abskey参数，解决#不能直接通过RequestParam传递问题
		String absKey = request.getParameter("absKey");
		key = StringUtil.isNotEmpty(absKey) ? absKey : key.replace("~^~", "#");

		if (logger.isInfoEnabled()) {
			logger.info("group=" + group + "key=" + key);
		}
		String responseMsg = "";
		if (group == null || (group = group.trim()).length() == 0) {
			responseMsg = "配置组为空，查看失败";
		} else if (key == null || (key = key.trim()).length() == 0) {
			responseMsg = "配置键为空，查看失败";
		} else {
			byte[] content = pizzaConfigServices.getConfigByteContent(proId,group, key);
			if (content == null) {
				responseMsg = "配置为空";
			} else {
				int idx = key.lastIndexOf(".");
				String ext = key.substring(idx + 1);

				response.addHeader("pizzaPath", "/" + group + "/" + key);
				if (configGroupServices.getGroup(group).isBinary()) {
					// 如果是依赖包内容，文件名会包含#，此处改为更加友好的文件名
					if (Constants.FILE_TYPE_JAR.equals(ext)&& key.contains("#")) {
						String[] eles = key.split("#");
						key = eles[1].concat("-").concat(eles[2]);
					}
					response.setContentType("application/x-zip-compressed");
					response.addHeader("Content-Disposition","attachment;filename=" + key);
				} else {

					if (NOT_TEXT_FILE.contains(ext)) {
						String text = new String(content);
						content = Base64.decodeBase64(text);

						response.setContentType("application/x-zip-compressed");
						response.addHeader("Content-Disposition","attachment;filename=" + key);
					} else {
						if (ext.equalsIgnoreCase("xml")) {
							response.setContentType("text/xml;charset=utf-8");
						} else if (ext.equalsIgnoreCase("html")|| ext.equalsIgnoreCase("htm")) {
							response.setContentType("text/html;charset=utf-8");
						} else {
							response.setContentType("text/plain;charset=utf-8");
						}
					}
				}
				response.getOutputStream().write(content);
				response.getOutputStream().flush();
				return null;
			}
		}
		ModelMap model = new ModelMap();
		model.put("resultCode", "error");
		model.put("errorMsg", responseMsg);
		model.put("msg", responseMsg);
		model.put("success", true);
		return model;
	}

	// 删除配置信息
	@RequestMapping("/delConfigItem.do")
	@ESA(value = "pafa5_admin_pizza.delConfigFile", local = true)
	@ResponseBody
	public ModelMap del(@RequestParam("projectId") String proId,
			@RequestParam("group") String group, @RequestParam("key") String key)
			throws Throwable {
		isOwner(proId);

		PizzaURL url = PizzaURL.valueOf(group, key);
		if (logger.isInfoEnabled()) {
			logger.info("Del config:" + url);
		}
		boolean success = pizzaConfigServices.del(proId, group, key);
		if(success){
			ServiceParams params = new ServiceParams();
			if(group.equals("sar")){
				key = key.contains(".") ?key.substring(0, key.indexOf(".")):key ;
				params.set("sarId", key);
				params.set("systemsId", proId);
				sARManagerService.invoke(params);
			}else if(group.equals("papp")){
				key = key.contains(".") ?key.substring(0, key.indexOf(".")):key ;
				params.set("pappName", key);
				params.set("systemsId", proId);
				pappManagerService.invoke(params);
			}
		}
		ModelMap model = new ModelMap();
		model.put("responseMsg", success ? "删除成功" : "删除失败");
		model.put("msg", success ? "删除成功" : "删除失败");
		model.put("success", true);
		return model;
	}

	@ResponseBody
	@RequestMapping("/rename.do")
	public ModelMap rename(
			@RequestParam(value = "projectId", required = false) String domainId,
			@RequestParam(value = "group", required = true) String group,
			@RequestParam(value = "key", required = true) String key,
			@RequestParam(value = "newKey", required = true) String newKey) throws Exception{
		isOwner(domainId);
		String responseMsg = "上传成功!";

		ResponseModel model = new ResponseModel();

		if (key.equals(newKey)) {
			model.put("success", true);
			model.put("msg", "配置文件名称未改变");
			return model;
		}
		if (newKey.length() > 250) {
			model.put("success", true);
			model.put("msg", "文件名过长");
			return model;
		}

		PizzaConfigPO exists = pizzaConfigServices.get(domainId, group, newKey);
		if (exists != null) {
			model.put("success", true);
			model.put("responseMsg", "配置文件的名称已经存在");
			model.put("msg", "配置文件的名称已经存在");
			return model;
		}

		PizzaConfigPO po = pizzaConfigServices.get(domainId, group, key);
		if (po == null) {
			model.put("success", true);
			model.put("responseMsg", "配置文件不存在");
			model.put("msg", "配置文件不存在");
			return model;
		}

		String content = pizzaConfigServices.getConfigContent(domainId, group,
				key);

		ConfigSaveDTO form = new ConfigSaveDTO();
		form.setGroup(po.getPizzaGroup());
		form.setKey(po.getPizzaKey());
		form.setValue(content);
		form.setKey(newKey);
		form.setOptype(ConfigHistoryOperationType.ADD);
		form.setProjectId(po.getProjectId());
		form.setProjectName(po.getProjectName());
		int result = pizzaConfigServices.save(form);

		if (result == 0) {
			pizzaConfigServices.del(domainId, group, key);
			model.put("success", true);
			model.put("responseMsg", "修改成功。");
			model.put("msg", "修改成功。");
			return model;
		} else if (result == 1) {
			responseMsg = "配置文件未变化。";
			model.put("success", true);
			model.put("responseMsg", responseMsg);
			model.put("msg", responseMsg);
			return model;
		} else {
			responseMsg = "保存失败，系统错误或者配置中心访问错误。";
		}

		model.put("success", true);
		model.put("responseMsg", responseMsg);
		model.put("msg", responseMsg);
		return model;
	}

	/**
	 * 同步
	 * 
	 * @param form
	 * @return
	 */
	@ResponseBody
	@RequestMapping("/sync.do")
	public ResponseModel modify(@Valid ConfigSaveDTO form) {
		isOwner(form.getProjectId());

		ResponseModel model = new ResponseModel();
		try {
			int result = pizzaConfigServices.save(form);
			if (result == 2) {
				model.put("success", false);
			} else {
				model.put("success", true);
			}
		} catch (Exception ex) {
			logger.error("",ex);
			String sOut = "";
			StackTraceElement[] trace = ex.getStackTrace();
			for (StackTraceElement s : trace) {
				sOut += "\tat " + s + "\r\n";
			}
			model.put("success", false);
			model.setResponseCode("1");
			model.setResponseMsg(sOut);
			return model;
		}
		return model;
	}

	@ESA(value = "pafa5-admin-pizza.modifyConfigContent", local = true)
	@ResponseBody
	public ResponseModel updateConfigContent(
			@RequestParam(value = "projectId", required = true) String projectId,
			@RequestParam(value = "group", required = true) String group,
			@RequestParam(value = "key", required = true) String key,
			@RequestParam(value = "content", required = true) String content) {
		PizzaConfigForm form = new PizzaConfigForm();
		form.setProjectId(projectId);
		form.setPizzaGroup(group);
		form.setPizzaKey(key);
		form.setPizzaValue(content);
		boolean flag = pizzaConfigServices.checkExists(projectId, group, key);

		ResponseModel response = new ResponseModel();
		if (flag) {
			boolean success = pizzaConfigServices.updateConfigContent(form);
			if (success) {
				response.put("success", true);
				response.put("responseMsg", "保存成功！");
				response.put("msg", "保存成功！");
			} else {
				response.put("success", true);
				response.put("responseMsg", "保存失败！");
				response.put("msg", "保存失败！");
			}
		} else {
			pizzaConfigServices.addConfigContent(form);
			response.put("responseMsg", "保存成功！");
			response.put("msg", "保存成功！");
		}

		return response;
	}

	private String replaceHtml(String content) {
		/*
		 * return content.replace("<", "&lt;") .replace(">", "&gt;")
		 * .replace(" ", "&nbsp;") .replace("&","&amp;");
		 */
		return content;
	}

	/**
	 * create by houshangzhi 2016-7-19 09:51:01 根据项目查询资源组配置文件
	 * 
	 * @param group
	 * @param keyRegex
	 * @param likeKey
	 * @return
	 * @throws Throwable
	 */
	@RequestMapping("/listKeysByProId.do")
	@ESA(value = "pafa5-admin-pizza.listKeysByProId", local = true)
	@ResponseBody
	public ResponseModel listKeysByProId(
			@RequestParam("group") String group,
			@RequestParam("projectId") String projectId,
			@RequestParam(value = "keyRegex", required = false) String keyRegex,
			@RequestParam(value = "likeKey", required = false) String likeKey)
			throws Throwable {
		if (likeKey != null && (likeKey = likeKey.trim()).length() > 0) {

			if (SqlUtils.SPRING_PROFILE_NOSQL.equalsIgnoreCase(SqlUtils.getSpringProfilesActive())) {
				keyRegex = "^" + likeKey + ".*$";
			} else {
				keyRegex = likeKey + "%";
			}
		}
		List<String> keys = pizzaConfigServices.listKeysByProId(projectId,
				group, keyRegex);
		ResponseModel model = new ResponseModel("0");
		model.put("keySize", keys == null ? 0 : keys.size());
		model.put("keys", keys);
		return model;
	}

	/**
	 * create by houshangzhi 2016-7-19 09:51:01 获取配置文件的内容
	 * 
	 * @param group
	 * @param key
	 * @return
	 * @throws Throwable
	 */
	@RequestMapping("/getKeyContent.do")
	@ESA(value = "pafa5-admin-pizza.getKeyContent", local = true)
	@ResponseBody
	public ResponseModel getKeyContent(
			@RequestParam("group") String group,
			@RequestParam("key") String key,
			@RequestParam(value = "projectId", required = false) String projectId)
			throws Throwable {

		String content = pizzaConfigServices.getConfigContent(projectId, group, key);
		ResponseModel model = new ResponseModel("0");
		model.put("content", content);
		return model;
	}

	public void isOwner(String domainId) {
		if (domainId == null || SARManagerConstants.DEF.equalsIgnoreCase(domainId)) {
			return;
		}
		ServiceParams params = new ServiceParams();
		params.set("groupId", domainId);
		ServiceResults results = ownerService.invoke(params);
		boolean isBoo = results.getBool("isowner");
		if (!isBoo) {
			throw new ResponseCodeException("354", "对不起，你不是领域负责人，没有此操作权限");
		}
	}

	public void setPizzaConfigServices(PizzaConfigServices pizzaConfigServices) {
		this.pizzaConfigServices = pizzaConfigServices;
	}

	public void setConfigGroupServices(ConfigGroupServices configGroupServices) {
		this.configGroupServices = configGroupServices;
	}

	public void setConfigContentUtils(ConfigContentUtils configContentUtils) {
		this.configContentUtils = configContentUtils;
	}

	public void setOwnerService(IServiceClient ownerService) {
		this.ownerService = ownerService;
	}

}
