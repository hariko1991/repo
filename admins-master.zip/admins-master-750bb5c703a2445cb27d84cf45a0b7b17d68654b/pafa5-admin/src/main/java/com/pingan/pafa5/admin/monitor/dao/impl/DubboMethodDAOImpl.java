package com.pingan.pafa5.admin.monitor.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.monitor.dao.DubboMethodDAO;
import com.pingan.pafa5.admin.monitor.po.DubboMethodPO;

@Nosql
@Repository
public class DubboMethodDAOImpl extends BaseMongoDAO<DubboMethodPO> implements DubboMethodDAO {

    @Override
    public DubboMethodPO getById(String id) {
        return _getById(id);
    }

    @Override
    public void save(DubboMethodPO po) {
        _save(po);
    }

    @Override
    public void update(DubboMethodPO po) {
        _updateById(po);
    }

    @Override
    public int count(String likeName, String createTime, String type) {
        return 0;
    }

    @Override
    public List<DubboMethodPO> list(String likeName, String createTime, String type, int offset,
            int limit) {
        // TODO Auto-generated method stub
        return null;
    }

}
