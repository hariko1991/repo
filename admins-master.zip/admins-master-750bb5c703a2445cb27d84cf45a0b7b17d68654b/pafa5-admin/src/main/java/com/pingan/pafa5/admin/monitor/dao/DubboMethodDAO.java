package com.pingan.pafa5.admin.monitor.dao;

import java.util.List;

import com.pingan.pafa5.admin.monitor.po.DubboMethodPO;

public interface DubboMethodDAO {

    DubboMethodPO getById(String id);
    
    void save(DubboMethodPO po);
    
    void update(DubboMethodPO po);
    
    int count(String likeName, String createTime, String type);
    
    List<DubboMethodPO> list(String likeName, String createTime, String type, int offset, int limit);
    
}
