package com.pingan.pafa5.admin.pizza.dao.impl;

import java.util.List;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.pizza.dao.GlobalVariableBackDAO;
import com.pingan.pafa5.admin.pizza.po.GlobalVariableBackupPO;

@Nosql
@Repository
public class GlobalVariableBackDAOImpl extends BaseMongoDAO<GlobalVariableBackupPO> implements GlobalVariableBackDAO {

	@Override
	public void add(GlobalVariableBackupPO po) {
		this._add(po);
	}

	@Override
	public List<GlobalVariableBackupPO> list(String proId,String versionId) {
		Criteria criteria = null;
		if (proId == null) {
			criteria = where("proId").is(null);
		} else {
			criteria = where("proId").is(proId);
		}
		criteria.and("versionId").is(versionId);
		
		return this._list(criteria);
	}
	
}
