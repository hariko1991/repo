package com.pingan.pafa5.admin.papp.dto;

import com.paic.pafa.validator.annotation.VNotEmpty;

/**
 * 应用管理dto
 * 2016-6-14 14:10:20
 * @author HOUSHANGZHI377
 *
 */
public class PappManagerDTO {
	private String id;
	
	@VNotEmpty
	/**应用ID*/
	private String pappName;
	
	/**应用中文名称*/
	private String pappChName;
	
	/**所属项目id*/
	private String systemsId;
	
	/**所属项目名称*/
	private String systemsName;
	
	/**应用负责人*/
	private String pappOwner;
	
	/**应用负责人ID*/
	private String pappOwnerId;
	
	private String remark;
	
	private int page;
	
	private int limit;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getPappName() {
		return pappName;
	}
	public void setPappName(String pappName) {
		this.pappName = pappName;
	}
	public String getPappChName() {
		return pappChName;
	}
	public void setPappChName(String pappChName) {
		this.pappChName = pappChName;
	}
	public String getSystemsId() {
		return systemsId;
	}
	public void setSystemsId(String systemsId) {
		this.systemsId = systemsId;
	}
	public String getSystemsName() {
		return systemsName;
	}
	public void setSystemsName(String systemsName) {
		this.systemsName = systemsName;
	}
	public String getPappOwner() {
		return pappOwner;
	}
	public void setPappOwner(String pappOwner) {
		this.pappOwner = pappOwner;
	}
	public String getPappOwnerId() {
		return pappOwnerId;
	}
	public void setPappOwnerId(String pappOwnerId) {
		this.pappOwnerId = pappOwnerId;
	}
	public int getPage() {
		return page;
	}
	public void setPage(int page) {
		this.page = page;
	}
	public int getLimit() {
		return limit;
	}
	public void setLimit(int limit) {
		this.limit = limit;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}

}
