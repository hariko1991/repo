package com.pingan.pafa5.admin.fling.po;

import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 应用监控消息
 * 
 * @author JIECHANGKE805
 * 
 */
@Document
@CompoundIndexes({
    @CompoundIndex(name = "def_index", def = "{appName : 1, instanceIp : 1, createdTimestamp:1}")
})
public class FlingPappMonitorMsgPO {

    /**
     * 记录ID
     */
    @org.springframework.data.annotation.Id
    private String msgId;

    /***
     * 应用名
     */
    private String appName;

    /**
     * 实例IP
     */
    private String instanceIp;

    /**
     * 创建时间(即admin服务端时间)
     */
    private long createdTimestamp;

    /**
     * 事件时间
     */
    private String eventName;

    /**
     * 事件时间(客户端时间)
     */
    private long eventTimestamp;

    /**
     * 实例名
     */
    private String instanceName;

    /**
     * 主机名
     */
    private String hostName;

    /**
     * JDK版本
     */
    private String javaVersion;

    /**
     * JDK供应商
     */
    private String javaVendor;

    /**
     * java虚拟机名称
     */
    private String javaVmName;

    /**
     * 操作系统的名称
     */
    private String osName;

    /**
     * 操作系统的构架
     */
    private String osArch;

    /**
     * 操作系统的版本
     */
    private String osVersion;

    /**
     * 业务系统请求ID
     */
    private String bizRequestId;

    /**
     * 操作系统登陆用户名
     */
    private String userName;

    /**
     * 可用处理资源
     */
    private int availableProcessors = -1;

    /**
     * 可用内存
     */
    private int availableMemory = -1;

    public String getMsgId() {
        return msgId;
    }

    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getInstanceIp() {
        return instanceIp;
    }

    public void setInstanceIp(String instanceIp) {
        this.instanceIp = instanceIp;
    }



    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public long getEventTimestamp() {
        return eventTimestamp;
    }

    public void setEventTimestamp(long eventTimestamp) {
        this.eventTimestamp = eventTimestamp;
    }

    public String getInstanceName() {
        return instanceName;
    }

    public void setInstanceName(String instanceName) {
        this.instanceName = instanceName;
    }

    public String getHostName() {
        return hostName;
    }

    public void setHostName(String hostName) {
        this.hostName = hostName;
    }

    public String getJavaVersion() {
        return javaVersion;
    }

    public void setJavaVersion(String javaVersion) {
        this.javaVersion = javaVersion;
    }

    public String getJavaVendor() {
        return javaVendor;
    }

    public void setJavaVendor(String javaVendor) {
        this.javaVendor = javaVendor;
    }

    public String getJavaVmName() {
        return javaVmName;
    }

    public void setJavaVmName(String javaVmName) {
        this.javaVmName = javaVmName;
    }

    public String getOsName() {
        return osName;
    }

    public void setOsName(String osName) {
        this.osName = osName;
    }

    public String getOsArch() {
        return osArch;
    }

    public void setOsArch(String osArch) {
        this.osArch = osArch;
    }

    public String getOsVersion() {
        return osVersion;
    }

    public void setOsVersion(String osVersion) {
        this.osVersion = osVersion;
    }

    public long getCreatedTimestamp() {
        return createdTimestamp;
    }

    public void setCreatedTimestamp(long createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    public String getBizRequestId() {
        return bizRequestId;
    }

    public void setBizRequestId(String bizRequestId) {
        this.bizRequestId = bizRequestId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getAvailableProcessors() {
        return availableProcessors;
    }

    public void setAvailableProcessors(int availableProcessors) {
        this.availableProcessors = availableProcessors;
    }

    public int getAvailableMemory() {
        return availableMemory;
    }

    public void setAvailableMemory(int availableMemory) {
        this.availableMemory = availableMemory;
    }

}
