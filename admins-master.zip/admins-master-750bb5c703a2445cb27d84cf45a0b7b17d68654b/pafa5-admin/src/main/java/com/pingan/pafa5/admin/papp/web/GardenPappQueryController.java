package com.pingan.pafa5.admin.papp.web;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestParam;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.pizza.PizzaConstants;
import com.pingan.pafa5.admin.commons.SqlUtils;
import com.pingan.pafa5.admin.papp.dto.PappDTO;

@Controller
public class GardenPappQueryController extends BaseController{
	
	@ActionClient(name = "pafa5-admin-pizza.listKeys")
	private IServiceClient pizzaListKeysService;

	@ActionClient(name = "pafa5-admin-pizza.listKeysByProId")
	private IServiceClient listPappsService;

	private static final String APP_NAME_PATTERN_STRING = "^[\\w\\-]+$";

	private static final Pattern APP_NAME_PATTERN = Pattern.compile(APP_NAME_PATTERN_STRING);

	@ESA(value= "pafa5-admin-papp.getPappListNames")
	public ResponseModel listKeys(@RequestParam(value = "pappName", required = false) String pappName,
			@RequestParam(value = "projectId", required = false) String projectId) throws Throwable {
		ServiceParams params = ServiceParams.newInstance();
		params.set("projectId", projectId);
		params.set("group", PizzaConstants.GROUP_PAPP);

		if (pappName != null && !APP_NAME_PATTERN.matcher(pappName).matches()) {
			ResponseModel model = new ResponseModel("1", "pappName:" + pappName + " not matched by pattern:" + APP_NAME_PATTERN_STRING);
			model.put("pappNames", new ArrayList<PappDTO>());
			return model;
		}
		if (pappName == null) {
			pappName = "";
		}

		if (SqlUtils.SPRING_PROFILE_NOSQL.equalsIgnoreCase(SqlUtils.getSpringProfilesActive())) {
			String parttern = "^" + pappName + "[\\w\\-]*\\.properties$";
			params.set("keyRegex", parttern);
		} else {
			String parttern = pappName + "%.properties";
			params.set("keyRegex", parttern);
		}

		ServiceResults result = pizzaListKeysService.invoke(params);
		// -----------------------------------
		String responseCode = result.getString("responseCode");
		List<PappDTO> datas = new ArrayList<PappDTO>();
		if ("0".equals(responseCode) || "success".equals(responseCode)) {
			int keySize = result.getInt("keySize");
			ResponseModel model = new ResponseModel("0");
			model.put("size", keySize);
			int len = ".properties".length();
			if (keySize > 0) {
				List<String> keys = (List<String>) result.get("keys");
				for (String key : keys) {
					String name = key.substring(0, key.length() - len);
					PappDTO dto = new PappDTO();
					dto.setId(name);
					dto.setPappName(name);
					datas.add(dto);
				}
			}
			model.put("pappNames", datas);
			return model;
		} else {
			return new ResponseModel(responseCode, result.getString("responseMsg"));
		}
	}
}
