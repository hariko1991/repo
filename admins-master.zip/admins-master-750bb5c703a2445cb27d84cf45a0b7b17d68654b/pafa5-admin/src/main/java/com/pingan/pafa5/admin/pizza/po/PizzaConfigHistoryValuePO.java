package com.pingan.pafa5.admin.pizza.po;

import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 历史value操作记录
 * 
 * @author EX-XIEDONGPING001
 */
@Document
public class PizzaConfigHistoryValuePO {

    @org.springframework.data.annotation.Id
    private String historyId;

    private String pizzaValue;

    public String getHistoryId() {
        return historyId;
    }

    public void setHistoryId(String historyId) {
        this.historyId = historyId;
    }

    public String getPizzaValue() {
        return pizzaValue;
    }

    public void setPizzaValue(String pizzaValue) {
        this.pizzaValue = pizzaValue;
    }

}
