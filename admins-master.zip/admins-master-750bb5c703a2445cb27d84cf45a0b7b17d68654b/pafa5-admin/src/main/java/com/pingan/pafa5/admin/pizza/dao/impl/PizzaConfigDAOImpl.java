package com.pingan.pafa5.admin.pizza.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.dao.DataAccessException;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.DocumentCallbackHandler;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.mongodb.DBObject;
import com.mongodb.MongoException;
import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa.mongodb.MongoPagination;
import com.pingan.pafa5.admin.Constants;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.commons.SARManagerConstants;
import com.pingan.pafa5.admin.pizza.dao.PizzaConfigDAO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSearchDTO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigPO;

@Nosql
@Repository
public class PizzaConfigDAOImpl extends BaseMongoDAO<PizzaConfigPO> implements
		PizzaConfigDAO {

	@Override
	public PizzaConfigPO add(PizzaConfigPO po) {

		String proId = po.getProjectId();
		if (proId == null || SARManagerConstants.DEF.equalsIgnoreCase(proId)) {
			po.setProjectId(Constants.DOMAIN_ID_DEF);
			po.setProjectName(Constants.DOMAIN_NAME_DEF);
			po.setId(Constants.DOMAIN_ID_DEF+"/"+po.getPizzaGroup()+"/"+po.getPizzaKey());
		} else {
			po.setId(po.getProjectId() + "/" + po.getPizzaGroup() + "/"
					+ po.getPizzaKey());
		}
		this._add(po);
		return po;
	}

	@Override
	public List<String> listKeys(String group) {

		return listKeys(group, null);
	}

	@Override
	public List<String> listKeys(String group, String pizzaKeyRegex) {
		Query query = new Query();
		Criteria where = where("pizzaGroup").is(group).and("projectId")
				.is(null);
		if (pizzaKeyRegex != null && pizzaKeyRegex.length() > 0) {
			where.and("pizzaKey").regex(Pattern.compile(pizzaKeyRegex));
		}
		query.addCriteria(where);
		query.fields().include("pizzaKey");
		query.with(new Sort(Direction.ASC, "pizzaKey"));
		final List<String> keys = new ArrayList<String>(32);
		this._listQuery(query, new DocumentCallbackHandler() {

			@Override
			public void processDocument(DBObject paramDBObject)
					throws MongoException, DataAccessException {
				keys.add((String) paramDBObject.get("pizzaKey"));
			}

		});
		if (keys.size() == 0) {
			return null;
		}
		return keys;
	}

	@Override
	public List<String> listKeys(String proId, String group,
			String pizzaKeyRegex) {
		Query query = new Query();
		Criteria criteria = where("projectId").is(proId).and("pizzaGroup")
				.is(group);
		if (pizzaKeyRegex != null && pizzaKeyRegex.length() > 0) {
			criteria.and("pizzaKey").regex(Pattern.compile(pizzaKeyRegex));
		}
		query.addCriteria(criteria);
		query.fields().include("pizzaKey");
		query.with(new Sort(Direction.ASC, "pizzaKey"));
		final List<String> keys = new ArrayList<String>(32);
		this._listQuery(query, new DocumentCallbackHandler() {
			@Override
			public void processDocument(DBObject paramDBObject)
					throws MongoException, DataAccessException {
				keys.add((String) paramDBObject.get("pizzaKey"));
			}
		});
		if (keys.size() == 0) {
			return null;
		}
		return keys;
	}

	@Override
	public boolean del(String group, String key) {
		String id = group + "/" + key;
		return this._removeById(id);
	}

	@Override
	public boolean del(String proId, String group, String key) {
		if (proId == null) {
			return del(group, key);
		}
		String id = proId + "/" + group + "/" + key;
		return this._removeById(id);
	}

	@Override
	public boolean update(PizzaConfigPO po) {
		String proId = po.getProjectId();
		if (proId == null || proId.length() < 1) {
			po.setId(po.getPizzaGroup()+"/"+po.getPizzaKey());
		} else {
			po.setId(proId + "/" + po.getPizzaGroup() + "/" + po.getPizzaKey());
		}
		return this._updateById(po);
	}

	/**
	 * 添加项目属性
	 * 
	 */
	@Override
	public boolean addProject(PizzaConfigPO po) {
		this._removeById(po.getId());
		this.add(po);
		return true;
	}

	@Override
	public boolean exist(String pizzaGroup, String pizzaKey) {
		return get(pizzaGroup, pizzaKey) != null;
	}

	@Override
	public boolean exist(String proId, String group, String pizzaKey) {
		if (proId == null) {
			return exist(group, pizzaKey);
		}
		String id = proId + "/" + group + "/" + pizzaKey;
		return this._getById(id) != null;
	}

	@Override
	public PizzaConfigPO get(String group, String key) {
		String id = group + "/" + key;
		Criteria criteria = where("id").is(id).and("projectId").is(null);
		return this._get(criteria);
	}

	@Override
	public PizzaConfigPO get(String proId, String group, String key) {
		if (proId == null) {
			return get(group, key);
		}
		String id = proId + "/" + group + "/" + key;
		return this._getById(id);
	}

    @Override
    public PageDataDTO<PizzaConfigPO> pageQuery(ConfigSearchDTO queryDTO) {
        MongoPagination<PizzaConfigPO> page =
                new MongoPagination<PizzaConfigPO>(queryDTO.getPage(), queryDTO.getLimit());
        String proId = queryDTO.getProjectId();
        Criteria where = null;
        if (proId == null) {
            where = where("pizzaGroup").is(queryDTO.getGroup()).and("projectId").is(null);
        } else {
            where = where("projectId").is(proId).and("pizzaGroup").is(queryDTO.getGroup());
        }
        String likeKey = queryDTO.getLikeKey();
        if (likeKey != null && (likeKey = likeKey.trim()).length() > 0) {
            where.and("pizzaKey").regex(
                    Pattern.compile("^.*" + likeKey + ".*$", Pattern.CASE_INSENSITIVE));
        }
        page.setTotalSize(-1);
        Query query = new Query(where);
        query.with(new Sort(Direction.DESC, "updatedDate"));
        this._paginatedQuery(query, page);
        PageDataDTO<PizzaConfigPO> result = new PageDataDTO<PizzaConfigPO>();
        result.setDatas(page.getPojos());
        result.setTotalSize(page.getTotalSize());
        return result;
    }
	


	@Override
	public List<PizzaConfigPO> query(String group, String regexKey,
			String pattern) {
		Criteria where = where("pizzaGroup").is(group);
		if (regexKey != null && regexKey.length() > 0) {
			where.and("pizzaKey").is(regexKey);
		} else {
			where.and("pizzaKey").regex(
					Pattern.compile(pattern, Pattern.CASE_INSENSITIVE));
		}
		return this._list(where);
	}

	@Override
	public List<PizzaConfigPO> query(String projectId, String group,
			String regexKey, String pattern) {
		Criteria where = where("pizzaGroup").is(group);
		if (projectId == null) {
			return query(group, regexKey, pattern);
		} else {
			where.and("projectId").is(projectId);
		}
		if (regexKey != null && regexKey.length() > 0) {
			where.and("pizzaKey").is(regexKey);
		} else {
			where.and("pizzaKey").regex(
					Pattern.compile(pattern, Pattern.CASE_INSENSITIVE));
		}
		return this._list(where);
	}

	@Override
	public List<PizzaConfigPO> queryByGroup(String group) {
		return this._list(where("pizzaGroup").is(group));
	}

	@Override
	public List<PizzaConfigPO> queryAll() {
		return this._list(null);
	}

	@Override
	public List<PizzaConfigPO> queryAllByProject(String proId) {
		Criteria criteria = null;
		if (proId == null) {
			criteria = where("projectId").is(null);
		} else {
			criteria = where("projectId").is(proId);
		}
		return this._list(criteria);
	}

	/**
	 * 根据配置组获取配置文件
	 * 
	 * @param pizzaGroup
	 * @return
	 */
	@Override
	public List<PizzaConfigPO> getPizzaKey(String pizzaGroup) {
		return this._list(where("pizzaGroup").is(pizzaGroup).and("projectId")
				.is(null));
	}

	@Override
	public List<PizzaConfigPO> getPizzaKey(String proId, String pizzaGroup) {
		if (proId == null) {
			return getPizzaKey(pizzaGroup);
		}
		return this._list(where("pizzaGroup").is(pizzaGroup).and("projectId")
				.is(proId));
	}

	@Override
	public PizzaConfigPO getByProperty(String propertyName, Object propertyValue) {
		return this._getByProperty(propertyName, propertyValue);
	}

	@Override
	public List<String> listKeysByProId(String projectId, String group,
			String pizzaKeyRegex) {
		Query query = new Query();
		Criteria where = where("pizzaGroup").is(group).and("projectId")
				.is(projectId);
		if (pizzaKeyRegex != null && pizzaKeyRegex.length() > 0) {
			where.and("pizzaKey").regex(Pattern.compile(pizzaKeyRegex));
		}
		query.addCriteria(where);
		query.fields().include("pizzaKey");
		query.with(new Sort(Direction.ASC, "pizzaKey"));
		final List<String> keys = new ArrayList<String>(32);
		this._listQuery(query, new DocumentCallbackHandler() {

			@Override
			public void processDocument(DBObject paramDBObject)
					throws MongoException, DataAccessException {
				keys.add((String) paramDBObject.get("pizzaKey"));
			}

		});
		if (keys.size() == 0) {
			return null;
		}
		return keys;
	}

	@Override
	public PizzaConfigPO isMD5Exist(String projectId, String md5) {
		Criteria where = where("projectId").is(projectId).and("valueMd5")
				.is(md5);
		return this._get(where);
	}

	@Override
	public List<PizzaConfigPO> listMD5Exist(String projectId, String md5,
			String group) {
		Criteria where = where("projectId").is(projectId).and("valueMd5")
				.is(md5).and("pizzaGroup").is(group);
		return this._list(where);
	}

	@Override
	public long checkCount(String projectId) {
		Criteria criteria = where("projectId").is(projectId);
		return this._count(criteria);
	}

}
