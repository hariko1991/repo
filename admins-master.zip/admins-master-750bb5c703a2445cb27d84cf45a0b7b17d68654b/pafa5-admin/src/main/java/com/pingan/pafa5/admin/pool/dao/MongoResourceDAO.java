package com.pingan.pafa5.admin.pool.dao;

import java.util.List;

import com.pingan.pafa5.admin.pool.po.MongoResourcePO;
import com.pingan.pafa5.admin.pool.po.NodePO;

public interface MongoResourceDAO {

	public abstract List<MongoResourcePO> list(String projectId,
			String projectName, int limit, int page);

	public abstract long getCount(String projectId, String projectName);

	public abstract void add(MongoResourcePO po);

	public abstract MongoResourcePO getById(String id);

	public abstract boolean updateById(MongoResourcePO po);

	public abstract boolean delete(String id);

	public abstract boolean updateServers(String id, String servers);

	List<MongoResourcePO> list(String projectId);

	boolean addNode(NodePO node, String id);

	boolean findNode(String ip, String id);

	boolean deleteNode(String ip, String id);

	List<NodePO> findNodes(String id);

}