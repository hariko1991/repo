package com.pingan.pafa5.admin.pizza.services;

import java.util.List;
import java.util.Set;

import com.pingan.pafa5.admin.pizza.po.ConfigGroupPO;

public interface ConfigGroupServices {

    public String getGroupName(String group);

    public ConfigGroupPO getGroup(String group);

    public List<ConfigGroupPO> list(boolean includeBinaryGroup, boolean includeHideGroup);

    public List<ConfigGroupPO> list(boolean includeBinaryGroup);

    public List<ConfigGroupPO> listAll();

    public Set<String> getGroupNames();
}
