package com.pingan.pafa5.admin.commons;

import java.util.List;

/**
 * 分页数据对象
 * 
 * @author EX-YANGSHENGXIANG001
 * @param <T>
 */
public class PageDataDTO<T> {

    private long totalSize;

    private List<T> datas;

    public long getTotalSize() {
        return totalSize;
    }

    public void setTotalSize(long totalSize) {
        this.totalSize = totalSize;
    }

    public List<T> getDatas() {
        return datas;
    }

    public void setDatas(List<T> datas) {
        this.datas = datas;
    }

}
