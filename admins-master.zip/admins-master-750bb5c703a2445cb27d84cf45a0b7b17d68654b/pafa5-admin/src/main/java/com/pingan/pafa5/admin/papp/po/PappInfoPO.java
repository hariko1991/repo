package com.pingan.pafa5.admin.papp.po;

import com.paic.pafa.validator.annotation.VLength;
import com.pingan.pafa5.admin.commons.BasePO;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;

public class PappInfoPO extends BasePO {
    /**
     * 组件id
     */
    @Id
    private String id;
    /**
     * 组件中文名称
     */
    @VLength(max=250)
    private String chineseName;
    /**
     * 备注
     */
    @VLength(max=250)
    private String remark;
    /**
     * 所属项目id
     */
    @Indexed
    private String systemId;
    /**
     * 所属项目名称
     */
    private String systemChineseName;
    /**
     * 逻辑实体名
     */
    private String logicalEntity;

    //-------------------------------------

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getChineseName() {
        return chineseName;
    }

    public void setChineseName(String chineseName) {
        this.chineseName = chineseName;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getSystemId() {
        return systemId;
    }

    public void setSystemId(String systemId) {
        this.systemId = systemId;
    }

    public String getSystemChineseName() {
        return systemChineseName;
    }

    public void setSystemChineseName(String systemChineseName) {
        this.systemChineseName = systemChineseName;
    }

    public String getLogicalEntity() {
        return logicalEntity;
    }

    public void setLogicalEntity(String logicalEntity) {
        this.logicalEntity = logicalEntity;
    }


}
