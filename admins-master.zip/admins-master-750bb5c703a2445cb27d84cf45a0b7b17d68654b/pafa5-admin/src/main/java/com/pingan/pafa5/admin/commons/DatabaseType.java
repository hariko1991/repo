package com.pingan.pafa5.admin.commons;

import java.util.ArrayList;
import java.util.List;

public class DatabaseType {

	public static final String MONGODB = "mongodb";

	public static final String MYSQL = "mysql";

	public static final String POSTGRESQL = "postgresql";

	public static final String ORACLE = "oracle";

	private static List<String> dbTypeList = null;
	static {

		dbTypeList = new ArrayList<String>();

		dbTypeList.add(MYSQL);
		dbTypeList.add(POSTGRESQL);
		dbTypeList.add(ORACLE);
		dbTypeList.add(MONGODB);
	}

	public static boolean has(String type) {
		return dbTypeList.contains(type.toLowerCase());
	}
}
