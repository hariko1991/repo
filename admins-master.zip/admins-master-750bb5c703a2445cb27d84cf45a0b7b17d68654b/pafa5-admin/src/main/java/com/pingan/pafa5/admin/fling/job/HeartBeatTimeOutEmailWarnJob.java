package com.pingan.pafa5.admin.fling.job;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.job.TimerJob;
import com.pingan.pafa5.admin.Constants;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.fling.po.FlingPappInstancePO;
import com.pingan.pafa5.admin.fling.services.InstanceServices;
import com.pingan.pafa5.admin.papp.dto.PappManagerDTO;

/**
 * @see 应用心跳过期邮件提醒定时任务
 * 
 * @author JIECHANGKE805
 * 
 */
@Component
public final class HeartBeatTimeOutEmailWarnJob {

    private Log log = LogFactory.getLog(HeartBeatTimeOutEmailWarnJob.class);

    @Value("${instance.heartbeat.expired}")
    private int heartbeatExpired = 3 * 60 * 1000;

    @Value("${heartbeat.mailwarn.interval}")
    private int emailSendInterval = 5 * 60 * 1000;

    @Autowired
    private InstanceServices instanceServices;

    @ActionClient(name = "pafa5-admin-papp.getByName")
    private IServiceClient pappManagerService;

    @ActionClient(name = "pafa5-admin-mail.sendMail")
    private IServiceClient sendMailService;

    @ActionClient(name = "pafa5-admin-fling.listSars")
    private IServiceClient sarInstanceService;

    @ActionClient(name = "pafa5-admin-sar.getByName")
    private IServiceClient sarManagerService;

    @TimerJob(cronExpression = "${job.ex.fling.mailwarn.time}")
    public void execute() throws Exception {
        log.info("心跳过期检测邮件提醒开始...");

        PageDataDTO<FlingPappInstancePO> instancePageDTO = instanceServices.listForPapp(null, null, Integer.MAX_VALUE, 1);

        ServiceParams pappParams = null;
        ServiceParams mailParams = null;
        List<String> toList = null;

        if (instancePageDTO != null && !CollectionUtils.isEmpty(instancePageDTO.getDatas())) {
            log.info("pappListSize: " + instancePageDTO.getDatas().size());

            for (FlingPappInstancePO pappInstancePO : instancePageDTO.getDatas()) {

                long expiredTime =  System.currentTimeMillis() - pappInstancePO.getLastActiveTimestamp();
                if (Constants.HEARTBEAT_TIMEOUT == pappInstancePO.getStatus() && expiredTime <= emailSendInterval + heartbeatExpired) {

                    pappParams = ServiceParams.newInstance();
                    pappParams.put("pappName", pappInstancePO.getAppName());
                    ServiceResults result = pappManagerService.invoke(pappParams);

                    PappManagerDTO dto = result.toDTO("data", PappManagerDTO.class);

                    if (dto == null) {
                        log.info("Can not find papp info,send warn mail failed.");
                        continue;
                    }

                    mailParams = ServiceParams.newInstance();
                    mailParams.put("mailTemplate", "pappHeartBeatTimeout.ftl");
                    mailParams.put("subject", "应用心跳过期警告");

                    Map<String, Object> context = new HashMap<String, Object>();
                    context.put("pappName", pappInstancePO.getAppName());
                    context.put("ip", pappInstancePO.getInstanceIp());
                    mailParams.put("context", context);

                    toList = new ArrayList<String>();
                    toList.add(dto.getPappOwnerId().concat("@pingan.com.cn"));

                    mailParams.put("toList", toList);

                    sendMailService.invoke(mailParams);
                }
            }
            log.info("pappListSize: " + instancePageDTO.getDatas().size());
        }

        log.info("心跳过期检测邮件提醒结束...");
    }

    public void setHeartbeatExpired(int heartbeatExpired) {
        this.heartbeatExpired = heartbeatExpired;
    }

    public void setEmailSendInterval(int emailSendInterval) {
        this.emailSendInterval = emailSendInterval;
    }

    public void setInstanceServices(InstanceServices instanceServices) {
        this.instanceServices = instanceServices;
    }

    public void setPappManagerService(IServiceClient pappManagerService) {
        this.pappManagerService = pappManagerService;
    }

    public void setSendMailService(IServiceClient sendMailService) {
        this.sendMailService = sendMailService;
    }

    public void setSarInstanceService(IServiceClient sarInstanceService) {
        this.sarInstanceService = sarInstanceService;
    }

    public void setSarManagerService(IServiceClient sarManagerService) {
        this.sarManagerService = sarManagerService;
    }

}
