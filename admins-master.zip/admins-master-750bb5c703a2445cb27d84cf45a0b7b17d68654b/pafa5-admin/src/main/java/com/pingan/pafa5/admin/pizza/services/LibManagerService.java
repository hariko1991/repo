package com.pingan.pafa5.admin.pizza.services;

import java.security.NoSuchAlgorithmException;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dto.IvyLibConfigDTO;
import com.pingan.pafa5.admin.pizza.dto.IvyLibSearchDTO;
import com.pingan.pafa5.admin.pizza.po.IvyLibConfigPO;


/**
 * @see Ivy lib管理接口
 * @author JIECHANGKE805
 * @date 2016-05-03
 * @exception 
 */
public interface LibManagerService {
	 
	 /**
	  *@see 生成ivy.xml
	  *@author JIECHANGKE805
	  *@since 2016年5月16日
	  *@param key：键值(org#module#version#name.ext)
	 * @throws 
	  */
	public String generateIvyXML(String key);
	
	/**
	 *@see 生成ivyconf.xml
	 *@author JIECHANGKE805
	 *@since 2016年5月18日
	 *@param reqUrl：当前请求url
	 *@return 生成文件的byte流
	 */
	public byte[] generateIvyConf(String reqUrl);

     /**
      *@see 初次请求ivy的准备服务，生成ivy.xml，生成sha1等
      *@author JIECHANGKE805
      *@since 2016年5月19日
      *@param 资源组，资源键值，字节流
      *@throws NoSuchAlgorithmException
      */
	 public byte[] ivyReqPrepare(String group, String key, String byteValues) throws NoSuchAlgorithmException;
	
	/**
	 *@see 查找ivy仓库配置文件
	 *@author JIECHANGKE805
	 *@since 2016年5月23日
	 *@param 资源组和键值
	 */
	public IvyLibConfigDTO findIvyConfig(String group, String key);
	
	/**
	 *@see 查询Ivy依赖包列表
	 *@author JIECHANGKE805
	 *@since 2016年5月25日
	 *@param 表单提交查询条件
	 */
	public PageDataDTO<IvyLibConfigPO> searchIvyLib(IvyLibSearchDTO form);

}
