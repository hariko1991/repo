package com.pingan.pafa5.admin.pizza.po;

import java.util.Date;

import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.pingan.pafa5.admin.commons.BasePO;

/**
 * 资源中心历史记录
 * 
 * @author EX-XIEDONGPING001
 */
@Document
@CompoundIndexes({
		@CompoundIndex(name = "def_index", def = "{projectId : 1, pizzaGroup : 1}"),
		@CompoundIndex(name = "createdDate_index", def = "{createdDate : 1}") })
public class PizzaConfigHistoryPO extends BasePO {
    
	@org.springframework.data.annotation.Id
	private String historyId;

	/**
	 * pizza分组
	 */
	private String pizzaGroup;

	/**
	 * pizza分组名称
	 */
	private String pizzaGroupName;

	/**
	 * pizza key
	 */
	@Indexed
	private String pizzaKey;

	/**
	 *
	 */
	private String valueMd5;

	/**
	 *
	 */
	private Integer valueSize;

	/**
	 * 项目id
	 */
	private String projectId;

	/**
	 * 项目名称
	 */
	private String projectName;

	/**
	 * 操作类型
	 * <p>
	 * 1:修改,2:新增；3:删除；4：同步
	 * </p>
	 */
	private String operationType;

	/**
	 * 操作来源IP
	 */
	private String operationIp;

	/**
	 * 是否被恢复. y,n
	 */
	private String recovery;

	/**
	 * 恢复时间
	 */
	private Date recoveryDate;

	/**
	 * 操作人
	 */
	private String recoveryUser;

	public String getHistoryId() {
		return historyId;
	}

	public void setHistoryId(String historyId) {
		this.historyId = historyId;
	}

	public String getPizzaGroup() {
		return pizzaGroup;
	}

	public void setPizzaGroup(String pizzaGroup) {
		this.pizzaGroup = pizzaGroup;
	}

	public String getPizzaKey() {
		return pizzaKey;
	}

	public void setPizzaKey(String pizzaKey) {
		this.pizzaKey = pizzaKey;
	}

	public String getOperationType() {
		return operationType;
	}

	public void setOperationType(String operationType) {
		this.operationType = operationType;
	}

	public String getOperationIp() {
		return operationIp;
	}

	public void setOperationIp(String operationIp) {
		this.operationIp = operationIp;
	}

	public String getPizzaGroupName() {
		return pizzaGroupName;
	}

	public void setPizzaGroupName(String pizzaGroupName) {
		this.pizzaGroupName = pizzaGroupName;
	}

	public String getValueMd5() {
		return valueMd5;
	}

	public void setValueMd5(String valueMd5) {
		this.valueMd5 = valueMd5;
	}

	public Integer getValueSize() {
		return valueSize;
	}

	public void setValueSize(Integer valueSize) {
		this.valueSize = valueSize;
	}

	public String getRecovery() {
		return recovery;
	}

	public void setRecovery(String recovery) {
		this.recovery = recovery;
	}

	public Date getRecoveryDate() {
		return recoveryDate;
	}

	public void setRecoveryDate(Date recoveryDate) {
		this.recoveryDate = recoveryDate;
	}

	public String getRecoveryUser() {
		return recoveryUser;
	}

	public void setRecoveryUser(String recoveryUser) {
		this.recoveryUser = recoveryUser;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

}
