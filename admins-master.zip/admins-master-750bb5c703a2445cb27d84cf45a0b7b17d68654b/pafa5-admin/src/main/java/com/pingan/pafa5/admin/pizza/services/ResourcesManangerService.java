package com.pingan.pafa5.admin.pizza.services;

import com.pingan.pafa.pizza.classloader.ClasspathResourceKey;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dto.ResourceFileDTO;
import com.pingan.pafa5.admin.pizza.dto.ResourceUploadDTO;

/**
 * 组件资源
 * @author ZHANGJIAWEI370
 *
 */
public interface ResourcesManangerService {
    
    /**
     * 获取组件资源列表
     * @param domainId
     * @param sarName
     * @param limit
     * @param page
     * @return
     */
    PageDataDTO<ResourceFileDTO> list(String domainId, String sarName, int limit, int page);

    /**
     * 保存组件资源
     * @param key
     * @param dto
     * @param content
     * @return
     */
    int putPizza(ClasspathResourceKey key, ResourceUploadDTO dto, String content) throws Exception;

    /**
     * 删除组件资源
     * @param domainId
     * @param id
     * @return
     */
    boolean delete(String domainId, String id);

    /**
     * 获取组件资源内容
     * @param domainId
     * @param id
     * @return
     */
    byte[] getFileContent(String domainId, String id);

}
