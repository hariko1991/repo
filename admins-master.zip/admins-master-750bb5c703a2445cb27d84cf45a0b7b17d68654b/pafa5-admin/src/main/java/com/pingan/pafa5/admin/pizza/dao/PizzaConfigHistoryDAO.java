package com.pingan.pafa5.admin.pizza.dao;

import java.util.Date;
import java.util.List;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSearchDTO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigHistoryPO;

public interface PizzaConfigHistoryDAO {

	void add(PizzaConfigHistoryPO historyDTO);
	
	PizzaConfigHistoryPO getById(String historyId);
	
	PizzaConfigHistoryPO get(String group, String key, long createDate);
	
	PageDataDTO<PizzaConfigHistoryPO> pageQuery(ConfigSearchDTO queryVO);

	public boolean record(String historyId, String recovery, String recoveryUser);

	List<PizzaConfigHistoryPO> search(String proId, String group,
			String pizzakey, String opterationType);
	
	public long getRecordNum(Date cleanBeforeThisTime, String projectId);
	
	public List<PizzaConfigHistoryPO> cleanUpRecord(Date cleanBeforeThisTime, String projectId/*, int recordNum*/);
	
	public void deleteHistoryPo(String id);
}
