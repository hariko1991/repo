package com.pingan.pafa5.admin.papp.dto;


/**
 * ivy.xml配置文件的dependency元素
 * @author WANGJUN791
 *
 */
public class DependencyDTO {
	
	private String org;
	
	private String oldOrg;
	
	private String module;
	
	private String oldModule;
	
	private String version;

	public String getOrg() {
		return org;
	}

	public void setOrg(String org) {
		this.org = org;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getOldOrg() {
		return oldOrg;
	}

	public void setOldOrg(String oldOrg) {
		this.oldOrg = oldOrg;
	}

	public String getOldModule() {
		return oldModule;
	}

	public void setOldModule(String oldModule) {
		this.oldModule = oldModule;
	}
}