package com.pingan.pafa5.admin.notify.service;

import javax.mail.MessagingException;

import com.pingan.pafa5.admin.notify.dto.Mail;

public interface MailService {

    Mail createMail(String templateName, String subject) throws MessagingException;

    void sendMail(Mail mail);

}
