package com.pingan.pafa5.admin.pizza.dto;

public class ConfigSearchDTO {

	private String projectId;
	
	private String group;
	
	private String likeKey;
	
	private int page;
	
	private int limit;
	
	private boolean formatDate=true;

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getLikeKey() {
		return likeKey;
	}

	public void setLikeKey(String likeKey) {
		this.likeKey = likeKey;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		this.limit = limit;
	}

	public boolean isFormatDate() {
		return formatDate;
	}

	public void setFormatDate(boolean formatDate) {
		this.formatDate = formatDate;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	
}
