package com.pingan.pafa5.admin.fling.dao;

import com.pingan.pafa5.admin.fling.po.FlingPappMonitorMsgPO;

public interface FlingPappMonitorMsgDAO {

    void add(FlingPappMonitorMsgPO po);

    FlingPappMonitorMsgPO getLast(String pappName, String instanceIp);

}
