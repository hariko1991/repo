package com.pingan.pafa5.admin.fling.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.fling.dao.DictateLoggerDAO;
import com.pingan.pafa5.admin.fling.dto.DictateLoggerDTO;
import com.pingan.pafa5.admin.fling.po.DictateLoggerPO;
import com.pingan.pafa5.admin.fling.services.DictateLoggerService;

@Service
public class DictateLoggerServiceImpl implements DictateLoggerService {

    @Autowired
    private DictateLoggerDAO dictateLoggerDAO;

    @Override
    public PageDataDTO<DictateLoggerDTO> list(String domainId, String pappName, String sarName,
            int size, int page) {
        PageDataDTO<DictateLoggerDTO> pageData = new PageDataDTO<DictateLoggerDTO>();
        
        long total = dictateLoggerDAO.getTotal(domainId, pappName, sarName);
        pageData.setTotalSize(total);
        
        if(total > 0) {
            List<DictateLoggerPO> pos = dictateLoggerDAO.list(size, page, domainId, pappName, sarName);
            if (pos != null && pos.size() > 0) {
                List<DictateLoggerDTO> dtos = new ArrayList<DictateLoggerDTO>(pos.size());
                for (DictateLoggerPO po : pos) {
                    DictateLoggerDTO dto = new DictateLoggerDTO();
                    dto.setId(po.getId());
                    dto.setInstanceIp(po.getInstanceIp());
                    dto.setPosName(po.getPosName());
                    dto.setPosType(po.getPosType());
                    dto.setDictateName(po.getDictateName());
                    dto.setDictateId(po.getDictateId());
                    dto.setResult(po.getResult());
                    dto.setCause(po.getCause());
                    dto.setCreatedBy(po.getCreatedBy());
                    dto.setCreatedDate(po.getCreatedDate());
                    dtos.add(dto);
                }
                pageData.setDatas(dtos);
            }
        }
        
        return pageData;
    }

    @Override
    public DictateLoggerDTO getById(String id) {
        DictateLoggerPO po = dictateLoggerDAO.getById(id);
        if (po == null) {
            throw new NullPointerException("没有发现数据");
        }

        DictateLoggerDTO dto = new DictateLoggerDTO();
        dto.setId(po.getId());
        dto.setInstanceIp(po.getInstanceIp());
        dto.setPosName(po.getPosName());
        dto.setPosType(po.getPosType());
        dto.setDictateName(po.getDictateName());
        dto.setDictateId(po.getDictateId());
        dto.setResult(po.getResult());
        dto.setCause(po.getCause());
        dto.setCreatedBy(po.getCreatedBy());
        dto.setCreatedDate(po.getCreatedDate());

        return dto;
    }

    @Override
    public String getCause(String id) {
        DictateLoggerPO po = dictateLoggerDAO.getById(id);
        if (po == null) {
            throw new ResponseCodeException("没有找到相关信息");
        }
        return po.getCause();
    }

}
