package com.pingan.pafa5.admin.papp.services;

import java.util.List;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.papp.dto.PappManagerDTO;
import com.pingan.pafa5.admin.papp.po.PappManagerPO;
import com.pingan.pafa5.admin.systems.dto.SystemGroupDTO;

/**
 * 应用管理
 * 2016-6-14 14:07:32
 * @author HOUSHANGZHI377
 *
 */
public interface PappManagerService 
{

	public boolean isExists(PappManagerDTO form);
	
	public PageDataDTO<PappManagerPO> list(PappManagerDTO form);
	
	public PageDataDTO<PappManagerPO> listUserPapp(PappManagerDTO form,List<SystemGroupDTO> list);
	
	public PappManagerDTO getById(String id);
	
	public PappManagerDTO getByPappName(String pappName) throws Exception;
	
	public boolean updateById(PappManagerDTO form)  throws Exception;
	
	public void add(PappManagerDTO form)  throws Exception;
	
	boolean delById(String id);
}
