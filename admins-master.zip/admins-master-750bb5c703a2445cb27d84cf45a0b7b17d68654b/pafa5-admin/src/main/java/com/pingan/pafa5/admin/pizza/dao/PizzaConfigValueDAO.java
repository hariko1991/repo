package com.pingan.pafa5.admin.pizza.dao;

import com.pingan.pafa5.admin.pizza.po.PizzaConfigValuePO;

/**
 * 当前配置操作 
 * @author EX-xiedongping001
 */
public interface PizzaConfigValueDAO {

    PizzaConfigValuePO get(String id);
    
    void save(PizzaConfigValuePO po);
    
    void update(PizzaConfigValuePO po);
    
    boolean del(String proId, String group,String key);
    
    boolean del(String group,String key);
    
    
}
