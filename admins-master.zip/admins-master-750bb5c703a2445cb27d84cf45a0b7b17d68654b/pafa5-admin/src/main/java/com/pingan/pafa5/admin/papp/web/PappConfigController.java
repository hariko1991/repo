package com.pingan.pafa5.admin.papp.web;

import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.base.Strings;
import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.common.utils.Pafa5ConfigUtils;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.pizza.PizzaConstants;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.papp.dao.PappConfigDAO;
import com.pingan.pafa5.admin.papp.dto.PappConfigDTO;
import com.pingan.pafa5.admin.papp.po.PappConfigPO;
import com.pingan.pafa5.admin.sso.UserPrincipal;

/**
 * 组件配置.
 * @author linkaibin447
 *
 */
@Controller
public class PappConfigController  extends BaseController{

	private static final String CONFIG_TRUE = "true";
	private static final String CONFIG_FALSE = "false";
	
	private static final Set<String> innerConfigItem = new HashSet<String>();
	static{
		innerConfigItem.add("papp.sar.list");
		innerConfigItem.add("papp.protocols");
		innerConfigItem.add("papp.esa.http.export.enable");
		innerConfigItem.add("papp.lib.list");
		innerConfigItem.add("papp.def.charset");
		innerConfigItem.add("papp.local.home.dir");
		innerConfigItem.add("papp.web.enable");
		innerConfigItem.add("papp.common.filter.enable");
		innerConfigItem.add("papp.jetty.enable");
		innerConfigItem.add("papp.dubbo.enable");
		innerConfigItem.add("papp.web.dispatcher");
		innerConfigItem.add("papp.resources.suffix");
		innerConfigItem.add("fling.monitor.enable");
		innerConfigItem.add("papp.status");
		innerConfigItem.add("stop");
		innerConfigItem.add("running");
	}
	
	/*"papp.sar.list", "papp.protocols", "papp.esa.http.export.enable",
	"papp.lib.list", "papp.def.charset", "papp.local.home.dir",
	"papp.web.enable", "papp.common.filter.enable",
	"papp.jetty.enable", "papp.dubbo.enable", "papp.web.dispatcher",
	"papp.resources.suffix", "fling.monitor.enable", "papp.status",
	"stop", "running"*/
	
	
	@ActionClient(name="pafa5-admin-pizza.saveConfig")
	private IServiceClient pizzaSaveConfigService;
	
	@ActionClient(name="pafa5_admin_pizza.getConfigItem")
	private IServiceClient pizzaGetConfigItemService;
	
	@Autowired
	private PappConfigDAO pappConfigDAO;
	
 
	@RequestMapping("/papp/cfg-list.do")
	@ResponseBody
	public ResponseModel list(
			@RequestParam(value="projectId", required=true) String projectId,
			@RequestParam(value="pappId", required=true) String pappId) {
		if(logger.isInfoEnabled()){
			logger.info("/cfg-list,projectId=" + projectId+",sarId"+pappId);
		}
	 
		ServiceParams params=ServiceParams.newInstance().set("group", PizzaConstants.GROUP_PAPP);
		params.set("key",pappId + ".properties");
		params.set("projectId", projectId);
		ServiceResults result = pizzaGetConfigItemService.invoke(params);
		String content = result.getString("value");
		
		Properties p = new Properties();
		try {
			InputStream in = new ByteArrayInputStream(content.getBytes());
			p.load(new InputStreamReader(in, "UTF-8"));
		} catch (Exception e) {
			ResponseModel model = new ResponseModel();
			model.put("success", false);
			return model;
		}
		
		if(!StringUtils.isEmpty(p.getProperty("papp.local.home.dir"))){
			p.put(switchPappKey("papp.local.home.dir"),p.getProperty("papp.local.home.dir"));
		}
		p.put(switchPappKey("papp.dubbo.enable"), CONFIG_TRUE.equals(p.getProperty("papp.dubbo.enable"))?"true":"false");
		p.put(switchPappKey("papp.jetty.enable"), CONFIG_TRUE.equals(p.getProperty("papp.jetty.enable"))?"true":"false");
		p.put(switchPappKey("fling.monitor.enable"), CONFIG_TRUE.equals(p.getProperty("fling.monitor.enable"))?"true":"false");
		if(!StringUtils.isEmpty(p.getProperty("papp.def.charset"))){
			p.put(switchPappKey("papp.def.charset"), p.getProperty("papp.def.charset"));
		}
		p.put(switchPappKey("papp.esa.http.export.enable"), CONFIG_TRUE.equals(p.getProperty("papp.esa.http.export.enable"))?"true":"false");
		if(!StringUtils.isEmpty(p.getProperty("papp.resources.suffix"))){
			p.put(switchPappKey("papp.resources.suffix"), p.getProperty("papp.resources.suffix"));
		}
		
		//如果papp.protocols配置了相关协议，则也支持
		String protocolsString=p.getProperty("papp.protocols");
		Set<String> protocols=Pafa5ConfigUtils.split(protocolsString);
		if(protocols!=null){
			if(protocols.contains("dubbo")){
				p.put(switchPappKey("papp.dubbo.enable"), "true");
			}
			if(protocols.contains("jetty")){
				p.put(switchPappKey("papp.jetty.enable"), "true");
			}
		}
		 
		ResponseModel model = new ResponseModel();
		model.put("data", p);
		model.put("success", true);
		return model;
	}
	
	@ResponseBody
	@RequestMapping("/papp/innercfg-save.do")
	public  ResponseModel add(PappConfigDTO form) throws Exception{
		//获取配置信息
	 
		ServiceParams param=ServiceParams.newInstance().set("group", PizzaConstants.GROUP_PAPP);
		param.set("key",form.getPappId() + ".properties");
		param.set("projectId", form.getProjectId());
		ServiceResults results = pizzaGetConfigItemService.invoke(param);
		String content = results.getString("value");
		
		
		Properties p = new Properties();
		if(!StringUtils.isEmpty(content)) {
			content = content.trim();
			try {
				InputStream in = new ByteArrayInputStream(content.getBytes());
				p.load(new InputStreamReader(in, "UTF-8"));
			} catch (Exception e) {
				ResponseModel model = new ResponseModel();
				model.put("success", false);
				return model;
			}
		}
		
		p.put(switchPappKey("localHomeDir"), form.getLocalHomeDir());
		p.put(switchPappKey("jettyEnable"), form.getJettyEnable());
		p.put(switchPappKey("dubboEnable"), form.getDubboEnable());
		p.put(switchPappKey("defCharset"), form.getDefCharset());
		p.put(switchPappKey("flingMonitorEnable"), form.getFlingMonitorEnable());
		p.put(switchPappKey("esaHttpExportEnable"), form.getEsaHttpExportEnable());
		p.put(switchPappKey("resourcesSuffix"), form.getResourcesSuffix());
		
		//如果papp.protocols配置了相关协议，则也支持,且优先级高
		String pappProtocols = "";
		if(CONFIG_TRUE.equals(form.getDubboEnable()))
		{
			pappProtocols = pappProtocols+"dubbo,";
		}
		if(CONFIG_TRUE.equals(form.getJettyEnable()))
		{
			pappProtocols = pappProtocols+"jetty,";
		}
		p.put("papp.protocols", pappProtocols);
		
		StringBuffer strBuffer = new StringBuffer();
		for (Map.Entry<Object, Object> entry : p.entrySet()) {
			if(!StringUtils.isEmpty((String) entry.getValue())) {
				strBuffer.append(entry.getKey()).append( "=" ).append(entry.getValue()).append("\n");
			}
		}
		
		//保存配置信息
		ServiceParams params=ServiceParams.newInstance().set("group", PizzaConstants.GROUP_PAPP);
		params.set("key", form.getPappId() + ".properties");
		params.set("projectId", form.getProjectId());
		params.set("optype", "1");
		params.set("value", strBuffer.toString());
		ServiceResults result = pizzaSaveConfigService.invoke(params);
		
		String response=result.getString("success");
		boolean success = "true".equals(response);
		ResponseModel model = new ResponseModel("0");
		model.put("success", success ? true : false);
		model.put("responseCode",response);
		model.put("responseMsg", StringUtils.isEmpty(result.getString("responseMsg"))?result.getString("msg"):result.getString("responseMsg"));
		return model;
	}
	 

private String switchPappKey(String nextToken) {
	if(nextToken.equals("papp.local.home.dir")) {
		return "localHomeDir";
	} else if (nextToken.equals("papp.jetty.enable")) {
		return "jettyEnable";
	} else if (nextToken.equals("papp.dubbo.enable")) {
		return "dubboEnable";
	} else if (nextToken.equals("papp.def.charset")) {
		return "defCharset";
	} else if (nextToken.equals("fling.monitor.enable")) {
		return "flingMonitorEnable";
	} else if (nextToken.equals("papp.esa.http.export.enable")) {
		return "esaHttpExportEnable";
	} else if (nextToken.equals("papp.resources.suffix")) {
		return "resourcesSuffix";
	} 
	
	if(nextToken.equals("localHomeDir")) {
		return "papp.local.home.dir";
	} else if (nextToken.equals("jettyEnable")) {
		return "papp.jetty.enable";
	} else if (nextToken.equals("dubboEnable")) {
		return "papp.dubbo.enable";
	} else if (nextToken.equals("defCharset")) {
		return "papp.def.charset";
	} else if (nextToken.equals("flingMonitorEnable")) {
		return "fling.monitor.enable";
	} else if (nextToken.equals("esaHttpExportEnable")) {
		return "papp.esa.http.export.enable";
	} else if (nextToken.equals("resourcesSuffix")) {
		return "papp.resources.suffix";
	} 
	return nextToken;
}

@RequestMapping("/papp/customcfg-list.do")
@ResponseBody
public ResponseModel customCfglist(
		@RequestParam(value="projectId", required=true) String projectId,
		@RequestParam(value="pappId", required=true) String pappId) {
	if(logger.isInfoEnabled()){
		logger.info("/customcfg-list,projectId=" + projectId+",sarId"+pappId);
	}
	
	ServiceParams params=ServiceParams.newInstance().set("group", PizzaConstants.GROUP_PAPP);
	params.set("key",pappId + ".properties");
	params.set("projectId", projectId);
	ServiceResults result = pizzaGetConfigItemService.invoke(params);
	String content = result.getString("value");
	
	Properties p = new Properties();
	try {
		InputStream in = new ByteArrayInputStream(content.getBytes());
		p.load(new InputStreamReader(in, "UTF-8"));
	} catch (Exception e) {
		ResponseModel model = new ResponseModel();
		model.put("success", false);
		return model;
	}
	
	String cfgItemDes = "";
	
	//如果配置文件在全局资源修改了，则需要同步
	List<PappConfigPO> nowConfigList =  pappConfigDAO.getCustomList(pappId, projectId);
	//同步删除
	if(null!=nowConfigList&&0<nowConfigList.size())
	{
		for(PappConfigPO ppo:nowConfigList)
		{
			 if(!innerConfigItem.contains(ppo.getCfgItem()))
				 {
				 	if(!p.contains(ppo.getCfgItem()))
				 	{
				 		//保存描述信息;
				 		cfgItemDes = ppo.getCfgItemDes();
				 		pappConfigDAO.delete(ppo.getId());
				 	}
			 
				 }
		}
	}
	
	 PappConfigDTO dto;
	 //同步更新和增加
	 for (Map.Entry<Object, Object> entry : p.entrySet()) {
			 
		 if(!innerConfigItem.contains((String) entry.getKey())){
		 
			PappConfigPO po = new PappConfigPO();
			po.setCfgItem((String) entry.getKey());
			po.setCfgValues((String) entry.getValue());
			POUtils.setForAdd(UserPrincipal.peekUserId(), po);
			po.setPappId(pappId);
			po.setProjectId(projectId);
			po.setCfgItemDes(cfgItemDes);
			dto = new PappConfigDTO();
			PappConfigPO existspo =pappConfigDAO.isExists(POUtils.copyProperties(dto, po));
			if(null==existspo)
			{
				pappConfigDAO.add(po);
			}else
			{
				existspo.setCfgValues((String) entry.getValue());
				pappConfigDAO.updateById(existspo);
			}
				
		 }
			 
		}
	 
	 
	 List<PappConfigPO> cusConfigList = pappConfigDAO.getCustomList(pappId, projectId);
	 
	ResponseModel model = new ResponseModel();
	model.put("data", cusConfigList);
	model.put("success", true);
	return model;
}

@RequestMapping("/papp/customcfg-update.do")
@ResponseBody
public ResponseModel customCfgUpdate(PappConfigDTO form) {
	if(logger.isInfoEnabled()){
		logger.info("/customcfg-update.do");
	}
	
	//保存zk上数据
	ServiceParams param=ServiceParams.newInstance().set("group", PizzaConstants.GROUP_PAPP);
	param.set("key",form.getPappId() + ".properties");
	param.set("projectId", form.getProjectId());
	ServiceResults results = pizzaGetConfigItemService.invoke(param);
	String content = results.getString("value");
	
	
	Properties p = new Properties();
	if(!StringUtils.isEmpty(content)){
		content = content.trim();
		try {
			InputStream in = new ByteArrayInputStream(content.getBytes());
			p.load(new InputStreamReader(in, "UTF-8"));
		} catch (Exception e) {
			ResponseModel model = new ResponseModel();
			model.put("success", false);
			return model;
		}
	}
	
	p.put(form.getCfgItem(), form.getCfgValues());
	 
	StringBuffer strBuffer = new StringBuffer();
	for (Map.Entry<Object, Object> entry : p.entrySet()) {
		if(!StringUtils.isEmpty((String) entry.getValue())) {
			strBuffer.append(entry.getKey()).append( "=" ).append(entry.getValue()).append("\n");
		}
	}
	
	
	ServiceParams params=ServiceParams.newInstance().set("group", PizzaConstants.GROUP_PAPP);
	params.set("key", form.getPappId() + ".properties");
	params.set("projectId", form.getProjectId());
	params.set("optype", "1");
	params.set("value", strBuffer.toString());
	ServiceResults result = pizzaSaveConfigService.invoke(params);
	
	String response=result.getString("success");
	boolean success = "true".equals(response);
	if(!success)
	{
		ResponseModel model = new ResponseModel();
		model.put("success", false);
		model.put("responseMsg", StringUtils.isEmpty(result.getString("responseMsg"))?result.getString("msg"):result.getString("responseMsg"));
		return model;
	}
	 
	//保存到pappConfigPo
	PappConfigPO po = new PappConfigPO();
	POUtils.copyProperties(po, form);
	
	pappConfigDAO.updateById(po);
	
	 List<PappConfigPO> cusConfigList = pappConfigDAO.getCustomList(form.getPappId(), form.getProjectId());
	 
	ResponseModel model = new ResponseModel();
	model.put("data", cusConfigList);
	model.put("success", true);
	return model;
}


@RequestMapping("/papp/customcfg-add.do")
@ResponseBody
public ResponseModel customCfgAdd(PappConfigDTO form) {
	if(logger.isInfoEnabled()){
		logger.info("/customcfg-update.do");
	}
	
	if(null!=pappConfigDAO.isExists(form))
	{
		ResponseModel model = new ResponseModel();
		model.put("responseMsg", "已存在该配置项");
		model.put("success", false);
		return model;
	}
	
	
	//保存zk上数据
	ServiceParams param=ServiceParams.newInstance().set("group", PizzaConstants.GROUP_PAPP);
	param.set("key",form.getPappId() + ".properties");
	param.set("projectId", form.getProjectId());
	ServiceResults results = pizzaGetConfigItemService.invoke(param);
	String content = results.getString("value");
	
	Properties p = new Properties();
	if(!StringUtils.isEmpty(content)){
		content = content.trim();
		try {
			InputStream in = new ByteArrayInputStream(content.getBytes());
			p.load(new InputStreamReader(in, "UTF-8"));
		} catch (Exception e) {
			ResponseModel model = new ResponseModel();
			model.put("success", false);
			return model;
		}
	}
	
	p.put(form.getCfgItem(), form.getCfgValues());
	 
	StringBuffer strBuffer = new StringBuffer();
	for (Map.Entry<Object, Object> entry : p.entrySet()) {
		if(!StringUtils.isEmpty((String) entry.getValue())) {
			strBuffer.append(entry.getKey()).append( "=" ).append(entry.getValue()).append("\n");
		}
	}
	
	
	ServiceParams params=ServiceParams.newInstance().set("group", PizzaConstants.GROUP_PAPP);
	params.set("key", form.getPappId() + ".properties");
	params.set("projectId", form.getProjectId());
	params.set("optype", "1");
	params.set("value", strBuffer.toString());
	ServiceResults result = pizzaSaveConfigService.invoke(params);
	
	String response=result.getString("success");
	boolean success = "true".equals(response);
	if(!success)
	{
		ResponseModel model = new ResponseModel();
		model.put("success", false);
		model.put("responseMsg", StringUtils.isEmpty(result.getString("responseMsg"))?result.getString("msg"):result.getString("responseMsg"));
		return model;
	}
	 
	//保存到pappConfigPo
	PappConfigPO po = new PappConfigPO();
	POUtils.copyProperties(po, form);
	
	pappConfigDAO.add(po);
	
	 List<PappConfigPO> cusConfigList = pappConfigDAO.getCustomList(form.getPappId(), form.getProjectId());
	 
	ResponseModel model = new ResponseModel();
	model.put("data", cusConfigList);
	model.put("success", true);
	return model;
}


@RequestMapping("/papp/customcfg-del.do")
@ResponseBody
public ResponseModel customCfgDel(PappConfigDTO form) {
	if(logger.isInfoEnabled()){
		logger.info("/customcfg-update.do");
	}
	
	if(null ==pappConfigDAO.isExists(form))
	{
		ResponseModel model = new ResponseModel();
		model.put("responseMsg", "不存在该配置项");
		model.put("success", false);
		return model;
	}
	
	
	//保存zk上数据
	ServiceParams param=ServiceParams.newInstance().set("group", PizzaConstants.GROUP_PAPP);
	param.set("key",form.getPappId() + ".properties");
	param.set("projectId", form.getProjectId());
	ServiceResults results = pizzaGetConfigItemService.invoke(param);
	String content = results.getString("value");
	
	Properties p = new Properties();
	if(!StringUtils.isEmpty(content)){
		content = content.trim();
		try {
			InputStream in = new ByteArrayInputStream(content.getBytes());
			p.load(new InputStreamReader(in, "UTF-8"));
		} catch (Exception e) {
			ResponseModel model = new ResponseModel();
			model.put("success", false);
			return model;
		}
	}
	
	p.remove(form.getCfgItem());
	 
	StringBuffer strBuffer = new StringBuffer();
	for (Map.Entry<Object, Object> entry : p.entrySet()) {
		if(!StringUtils.isEmpty((String) entry.getValue())) {
			strBuffer.append(entry.getKey()).append( "=" ).append(entry.getValue()).append("\n");
		}
	}
	
	
	ServiceParams params=ServiceParams.newInstance().set("group", PizzaConstants.GROUP_PAPP);
	params.set("key", form.getPappId() + ".properties");
	params.set("projectId", form.getProjectId());
	params.set("optype", "update");
	params.set("value", strBuffer.toString());
	ServiceResults result = pizzaSaveConfigService.invoke(params);
	
	String response=result.getString("success");
	boolean success = "true".equals(response);
	if(!success)
	{
		ResponseModel model = new ResponseModel();
		model.put("success", false);
		model.put("responseMsg", StringUtils.isEmpty(result.getString("responseMsg"))?result.getString("msg"):result.getString("responseMsg"));
		return model;
	}
	 
	//保存到pappConfigPo 
	pappConfigDAO.delete(form.getId());
	
	 List<PappConfigPO> cusConfigList = pappConfigDAO.getCustomList(form.getPappId(), form.getProjectId());
	 
	ResponseModel model = new ResponseModel();
	model.put("data", cusConfigList);
	model.put("success", true);
	return model;
}
	
	
}
