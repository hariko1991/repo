package com.pingan.pafa5.admin.notify.web;

import javax.mail.MessagingException;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa5.admin.notify.dto.Mail;
import com.pingan.pafa5.admin.notify.dto.MailParams;
import com.pingan.pafa5.admin.notify.service.MailService;

@Controller
public class SendMailController extends BaseController {

    private static final Log log = LogFactory.getLog(SendMailController.class);

    @Autowired
    public MailService mailService;

    @Value("${pafa5.base.url}")
    private String pafa5adminUrl;

    @ESA(value = "pafa5-admin-mail.sendMail", local = true)
    public void sendMail(MailParams params) {
        log.info("Send mail start...");

        Mail mail;
        try {
            mail = mailService.createMail(params.getMailTemplate(), params.getSubject());
            params.getContext().put("url", pafa5adminUrl);
            mail.setContext(params.getContext());
            if (null != params.getToList()) {
                mail.setTo(params.getToList().toArray(new String[] {}));
                log.info("receivers list: " + StringUtils.join(params.getToList(), ","));
            }
            if (null != params.getCcList()) {
                mail.setCc(params.getCcList().toArray(new String[] {}));
                log.info("cc list: " + StringUtils.join(params.getCcList(), ","));
            }
            mailService.sendMail(mail);
        } catch (MessagingException e) {
            log.error("Send mail failed, detail is : " + e);
        }

    }

}
