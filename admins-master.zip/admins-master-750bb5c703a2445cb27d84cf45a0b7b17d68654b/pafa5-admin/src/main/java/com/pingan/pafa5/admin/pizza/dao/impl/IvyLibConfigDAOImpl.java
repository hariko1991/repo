package com.pingan.pafa5.admin.pizza.dao.impl;

import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa.mongodb.MongoPagination;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.commons.SARManagerConstants;
import com.pingan.pafa5.admin.pizza.dao.IvyLibConfigDAO;
import com.pingan.pafa5.admin.pizza.dto.IvyLibSearchDTO;
import com.pingan.pafa5.admin.pizza.po.IvyLibConfigPO;

@Nosql
@Repository
public class IvyLibConfigDAOImpl extends BaseMongoDAO<IvyLibConfigPO> implements
		IvyLibConfigDAO {

	@Override
	public void add(IvyLibConfigPO ivyConfigPO) {

		this._add(ivyConfigPO);

	}

	@Override
	public IvyLibConfigPO find(String group, String key) {
		String id = group + "/" + key;
		return this._getById(id);
	}

	@Override
	public IvyLibConfigPO find(String proId, String group, String key) {
		String id = proId + "/" + group + "/" + key;;
		if (proId == null) {
			id = group + "/" + key;
		} else {
			id = proId + "/" + group + "/" + key;
		}
		return this._getById(id);
	}

	@Override
	public boolean update(IvyLibConfigPO po) {
		return this._updateById(po);
	}

	@Override
	public PageDataDTO<IvyLibConfigPO> pageQuery(IvyLibSearchDTO queryDTO) {
		MongoPagination<IvyLibConfigPO> page = new MongoPagination<IvyLibConfigPO>(
				queryDTO.getPage(), queryDTO.getLimit());
		Criteria where = null;
		String proId = queryDTO.getProjectId();

		if (proId == null ) {
			where = where("projectId").is(null);
		} else {
			where = where("projectId").is(proId);
		}
		if (StringUtils.isNotEmpty(queryDTO.getOrg())) {
			Pattern pattern = Pattern
					.compile("^.*" + queryDTO.getOrg() + ".*$",
							Pattern.CASE_INSENSITIVE);
			where.and("org").regex(pattern);
		}
		if (StringUtils.isNotEmpty(queryDTO.getModule())) {
			Pattern pattern = Pattern.compile("^.*" + queryDTO.getModule()
					+ ".*$", Pattern.CASE_INSENSITIVE);
			where.and("module").regex(pattern);
		}
		if (StringUtils.isNotEmpty(queryDTO.getVersion())) {
			Pattern pattern = Pattern.compile("^.*" + queryDTO.getVersion()
					+ ".*$", Pattern.CASE_INSENSITIVE);
			where.and("version").regex(pattern);
		}

		Query query = new Query(where);
		query.with(new Sort(Direction.DESC, "updatedDate"));
		this._paginatedQuery(query, page);

		PageDataDTO<IvyLibConfigPO> result = new PageDataDTO<IvyLibConfigPO>();
		result.setDatas(page.getPojos());
		result.setTotalSize(page.getTotalSize());

		return result;
	}

	@Override
	public boolean del(String group, String key) {

		String id = group + "/" + key;
		return this._removeById(id);

	}

	@Override
	public boolean del(String proId, String group, String key) {

		String id = proId + "/" + group + "/" + key;
		return this._removeById(id);

	}

}
