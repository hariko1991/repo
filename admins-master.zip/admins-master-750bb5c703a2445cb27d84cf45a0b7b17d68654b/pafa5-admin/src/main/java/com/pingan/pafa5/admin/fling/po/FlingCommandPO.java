package com.pingan.pafa5.admin.fling.po;

import java.util.List;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.pingan.pafa5.admin.commons.BasePO;

/**
 * 监控指令
 * 
 * @author JIECHANGKE805
 * 
 */
@Document
public class FlingCommandPO extends BasePO {

    /**
     * 流水ID
     */
    @Id
    private String rid;

    /**
     * 项目ID
     */
    private String projectId;
    /**
     * 应用名
     */
    private String pappName;
    /**
     * 组件名
     */
    private String sarName;
    /**
     * 操作目标IP列表
     */
    private List<String> limitIps;
    /**
     * 逗号分隔Ip串
     */
    private String limitIpsStr;

    /**
     * 发送者IP
     */
    private String senderIp;
    /**
     * 目标类型： papp/sar
     */
    private String targetType;
    /**
     * 动作类型： shutdown/startup/restartup
     */
    private String actionType;

    public String getRid() {
        return rid;
    }

    public void setRid(String rid) {
        this.rid = rid;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getPappName() {
        return pappName;
    }

    public void setPappName(String pappName) {
        this.pappName = pappName;
    }

    public String getSarName() {
        return sarName;
    }

    public void setSarName(String sarName) {
        this.sarName = sarName;
    }

    public List<String> getLimitIps() {
        return limitIps;
    }

    public void setLimitIps(List<String> limitIps) {
        this.limitIps = limitIps;
    }


    public String getLimitIpsStr() {
        return limitIpsStr;
    }

    public void setLimitIpsStr(String limitIpsStr) {
        this.limitIpsStr = limitIpsStr;
    }

    public String getSenderIp() {
        return senderIp;
    }

    public void setSenderIp(String senderIp) {
        this.senderIp = senderIp;
    }

    public String getTargetType() {
        return targetType;
    }

    public void setTargetType(String targetType) {
        this.targetType = targetType;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    @Override
    public String toString() {
        return "FlingCommandPO [rid=" + rid + ", projectId=" + projectId + ", pappName=" + pappName
                + ", sarName=" + sarName + ", limitIps=" + limitIps + ", senderIp=" + senderIp
                + ", targetType=" + targetType + ", actionType=" + actionType + ", getCreatedBy()="
                + getCreatedBy() + ", getCreatedDate()=" + getCreatedDate() + ", getUpdatedBy()="
                + getUpdatedBy() + ", getUpdatedDate()=" + getUpdatedDate() + ", getRequestId()="
                + getRequestId() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode()
                + ", toString()=" + super.toString() + "]";
    }

}
