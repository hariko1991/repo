package com.pingan.pafa5.admin.pizza;

public final class PizzaConstants {

	/**
	 * 资源历史操作类型
	 */
	public class ConfigHistoryOperationType {
		public static final String UPDATE = "1"; // 修改
		public static final String ADD = "2"; // 新增
		public static final String DEL = "3"; // 删除
		public static final String RECOVERY = "4"; // 从注册中心同步恢复
		public static final String ROLLBACK = "5"; // 备份回滚
		public static final String IVY_ADD = "6"; // 由ant打包时ivy仓库中新增
		public static final String SYNC_ADD = "7"; // 环境同步,
													// history_id从service层生成uuid.
	}

	public class VersionOperationType {
		public static final String VERSION_ROLLBACK = "8";
		public static final String VERSION_RELEASE = "9";
	}

	/**
	 * 跨环境同步类型
	 */
	public class EnvSyncType {
		public static final int MANUAL = 0; // 手动
		public static final int AUTO = 1; // 自动
	}

}
