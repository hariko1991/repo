package com.pingan.pafa5.admin.pizza.job;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.paic.pafa.job.TimerJob;
import com.pingan.pafa5.admin.pizza.services.BackupRecoveryService;

/**
 * 定时同步数据到注册中心任务
 * @author ZHANGJIAWEI370
 *
 */
@Component
public final class RecoveryRegisterJob {

    private Log logger = LogFactory.getLog(this.getClass());

    @Value("${recovery.register.job.enable}")
    private boolean recoveryEnable;

    @Autowired
    private BackupRecoveryService recoveryServices;
    
    @TimerJob(cronExpression = "${job.ex.recoveryRegister.time}")
    public void execute() throws Exception {
        if (recoveryEnable) {
            if (logger.isInfoEnabled()) {
                logger.info("recoveryRegisterJob...");
            }
            recoveryServices.recoveryRegister("ALL", "全量", "定时同步DB数据到注册中心。");
            if (logger.isInfoEnabled()) {
                logger.info("recoveryRegisterJob completed.");
            }

        } else {
            if (logger.isWarnEnabled()) {
                logger.warn("recovery.register.job.enable=false.");
            }
        }
    }

    public void setRecoveryEnable(boolean recoveryEnable) {
        this.recoveryEnable = recoveryEnable;
    }

    public void setRecoveryServices(BackupRecoveryService recoveryServices) {
        this.recoveryServices = recoveryServices;
    }

}
