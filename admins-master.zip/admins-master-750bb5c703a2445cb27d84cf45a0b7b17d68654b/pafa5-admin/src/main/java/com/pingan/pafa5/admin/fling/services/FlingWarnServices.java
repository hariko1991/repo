package com.pingan.pafa5.admin.fling.services;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.fling.po.FlingWarnPO;

public interface FlingWarnServices {

    /**
     * 查询告警信息列表
     * @param domainId
     * @param pappName
     * @param sarName
     * @param size
     * @param page
     * @return
     */
    PageDataDTO<FlingWarnPO> list(String domainId, String pappName, String sarName, int size,
            int page);
    
    /**
     * 查询详细信息
     * @param id
     * @return
     */
    String details(String id);

    /**
     * 删除15天前数据
     * @return
     */
    boolean delete15DaysBefore();

}
