package com.pingan.pafa5.admin.pizza.dto;

import com.pingan.pafa5.admin.commons.BasePO;

/** 
 * 同步记录
 * @author zhangjiawei370
 *
 */
public class EnvSyncLogDTO extends BasePO  {
	
    private String domainId;

    private String domainName;
    
    private String id;

    /**
     * 登录账户
     */
    private String loginUser;

    /*
     * 操作类型；手动0、系统1
     */
    private int syncType;

    /**
     * 耗时
     */
    private String time;

    /**
     * 总数
     */
    private long totalCount;

    /**
     * 成功总记录数
     */
    private long successCount;

    /**
     * 失败原因
     */
    private String cause;

    /**
     * 0同步中, 1同步异常, 2同步完成
     */
    private int status = 0;
    
    private String uri;

    public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDomainId() {
        return domainId;
    }

    public void setDomainId(String domainId) {
        this.domainId = domainId;
    }

    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public String getLoginUser() {
        return loginUser;
    }

    public void setLoginUser(String loginUser) {
        this.loginUser = loginUser;
    }

    public int getSyncType() {
        return syncType;
    }

    public void setSyncType(int syncType) {
        this.syncType = syncType;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public long getTotalCount() {
        return totalCount;
    }

    public void setTotalCount(long totalCount) {
        this.totalCount = totalCount;
    }

    public long getSuccessCount() {
        return successCount;
    }

    public void setSuccessCount(long successCount) {
        this.successCount = successCount;
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

	public String getUri() {
		return uri;
	}

	public void setUri(String uri) {
		this.uri = uri;
	}

}
