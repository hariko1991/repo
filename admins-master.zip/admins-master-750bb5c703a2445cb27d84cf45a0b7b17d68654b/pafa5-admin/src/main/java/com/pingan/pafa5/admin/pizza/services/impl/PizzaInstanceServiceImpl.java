package com.pingan.pafa5.admin.pizza.services.impl;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;

import org.apache.commons.codec.digest.DigestUtils;
import org.apache.http.client.utils.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.commons.PizzaManagerHolder;
import com.pingan.pafa5.admin.pizza.dao.PizzaInstanceDAO;
import com.pingan.pafa5.admin.pizza.dto.InstanceDTO;
import com.pingan.pafa5.admin.pizza.form.PizzaInstanceForm;
import com.pingan.pafa5.admin.pizza.po.PizzaInstancePO;
import com.pingan.pafa5.admin.pizza.services.PizzaInstanceService;
import com.pingan.pafa5.admin.sso.UserPrincipal;

@Service
public class PizzaInstanceServiceImpl extends BaseServices implements PizzaInstanceService {
	
	@Resource
	private PizzaInstanceDAO pizzaInstanceDAO;
	@Autowired
	private PizzaManagerHolder pizzaManagerHolder;
	
	private final String instance_path = "/pizza/instances";
	
	private final String FILENAME_PATTERN_STRING = "^[0-9a-zA-Z_-]{1,}$";
	
	private final String IPV4 = "^(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|[1-9])\\."
						+"(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."
						+"(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)\\."
						+"(1\\d{2}|2[0-4]\\d|25[0-5]|[1-9]\\d|\\d)$";
	
	@Override
	public int saveConfig(PizzaInstanceForm instanceForm) throws UnsupportedEncodingException {
		UserPrincipal principal = UserPrincipal.get(true);
		String sha1String = DigestUtils.sha1Hex(instanceForm.getContent());
		String instanceIp = instanceForm.getInstanceIp();
		instanceIp = instanceIp.replaceAll(".properties", "");
		String id = instanceForm.getProjectId()+"-"+instanceIp;
		PizzaInstancePO instancePO = new PizzaInstancePO();
		instancePO.setId(id);
		instancePO.setContent(instanceForm.getContent());
		instancePO.setInstanceIp(instanceIp);
		instancePO.setSha1String(sha1String);
		instancePO.setGroup(instanceForm.getGroup());
		instancePO.setLength(instanceForm.getContent().getBytes("UTF-8").length);
		instancePO.setUpdatedBy(principal.getUid());
		instancePO.setUpdatedDate(DateUtils.formatDate(new Date(System.currentTimeMillis()+(8*60*60*1000)), "yyyy-MM-dd HH:mm:ss"));
		
		Map<String,String> m = getGroup(instanceForm.getContent());
		String group = m.get("group");
		if(!StringUtils.isEmpty(group)) {
			group = group.trim();
			if(!group.matches(FILENAME_PATTERN_STRING)) {
				return 4;
			}
		}
		instancePO.setGroup(group==null?"":group);
		
		String appName = m.get("appName");
		instancePO.setAppName(appName==null?"":appName);
		
		PizzaInstancePO instancePO2 = pizzaInstanceDAO.get(instanceForm.getProjectId(), instanceIp);
		//为空保存
		if(instancePO2==null) {
			instancePO.setCreatedDate(DateUtils.formatDate(new Date(System.currentTimeMillis()+(8*60*60*1000)), "yyyy-MM-dd HH:mm:ss"));
			
			instancePO.setCreatedBy(principal.getUid());
			//先保存到zk
			pizzaManagerHolder.getManager(instanceForm.getProjectId()).add(instance_path+"/"+instanceIp, instanceForm.getContent());
			//在保存到mongodb
			pizzaInstanceDAO.save(instancePO);
			return 1;
		}else {
			if(instancePO2.getSha1String().equals(sha1String)) {
				return 3;
			}
			//不为空，更新
			instancePO.setId(instancePO2.getId());
			instancePO.setCreatedBy(instancePO2.getCreatedBy());
			instancePO.setCreatedDate(instancePO2.getCreatedDate());
			pizzaManagerHolder.getManager(instanceForm.getProjectId()).set(instance_path+"/"+instanceIp, instanceForm.getContent());
			//先保存到mongodb
			pizzaInstanceDAO.update(instancePO);
			
			return 2;
		}
	}
	/**
	 * 获取服务分组名
	 * @param content
	 * @return String[],group,appname
	 */
	private Map<String,String> getGroup(String content) {
		Map<String,String> m = new HashMap<String, String>();
		if(!StringUtils.isEmpty(content)) {
			InputStream inputStream = null;
			try {
				inputStream = new ByteArrayInputStream(content.getBytes("UTF-8"));
				
				Properties properties = new Properties();
				properties.load(inputStream);
				
				logger.info(properties.size());
				
				Object groupO = properties.get("dubbo.service.group");
				if(!StringUtils.isEmpty(groupO)) {
					m.put("group", groupO+"");
				}
				
				Object appName = properties.get("pizza.app.name");
				if(!StringUtils.isEmpty(appName)) {
					m.put("appName", appName+"");
				}
				//return m;
			} catch (Exception e) {
				
			}finally {
				if(inputStream!=null) {
					try {
						inputStream.close();
					} catch (IOException e) {
						e.printStackTrace();
					}
				}
			}
		}
		return m;
	}

	@Override
	public InstanceDTO getById(PizzaInstanceForm instanceForm) {
		String instanceIp = instanceForm.getInstanceIp();
		instanceIp = instanceIp.replaceAll(".properties", "");
		PizzaInstancePO instancePO = pizzaInstanceDAO.get(instanceForm.getProjectId(), instanceIp);
		if(instancePO!=null) {
			InstanceDTO instanceDTO = new InstanceDTO();
			instanceDTO.setGroup(instancePO.getGroup());
			instanceDTO.setContent(instancePO.getContent());
			instanceDTO.setSha1String(instancePO.getSha1String());
			instanceDTO.setLength(instancePO.getLength());
			instanceDTO.setUpdatedBy(instancePO.getUpdatedBy());
			instanceDTO.setUpdatedDate(instancePO.getUpdatedDate());
			instanceDTO.setPappName(instancePO.getAppName());
			return instanceDTO;
		}else {
			return null;
		}
	}
	
	
	@Override
	public int addConfig(PizzaInstanceForm instanceForm) throws UnsupportedEncodingException {
		String instanceIp = instanceForm.getInstanceIp();
		instanceIp = instanceIp.replaceAll(".properties", "");
		
		if(!instanceIp.matches(IPV4)) {
			return 2;
		}
		
		PizzaInstancePO instancePO2 = pizzaInstanceDAO.get(instanceForm.getProjectId(), instanceIp);
		if(instancePO2!=null) {
			return 1;
		}
		
		UserPrincipal principal = UserPrincipal.get(true);
		String sha1String = DigestUtils.sha1Hex(instanceForm.getContent());
		
		String id = instanceForm.getProjectId()+"-"+instanceIp;
		PizzaInstancePO instancePO = new PizzaInstancePO();
		instancePO.setId(id);
		instancePO.setContent(instanceForm.getContent());
		instancePO.setInstanceIp(instanceIp);
		instancePO.setSha1String(sha1String);
		instancePO.setGroup(instanceForm.getGroup());
		instancePO.setLength(instanceForm.getContent().getBytes("UTF-8").length);
		instancePO.setUpdatedBy(principal.getUid());
		instancePO.setUpdatedDate(DateUtils.formatDate(new Date(System.currentTimeMillis()+(8*60*60*1000)), "yyyy-MM-dd HH:mm:ss"));
		
		Map<String,String> m = getGroup(instanceForm.getContent());
		String group = m.get("group");
		if(!StringUtils.isEmpty(group)) {
			group = group.trim();
			if(!group.matches(FILENAME_PATTERN_STRING)) {
				return 4;
			}
		}
		instancePO.setGroup(group==null?"":group);
		
		String appName = m.get("appName");
		instancePO.setAppName(appName==null?"":appName);
		
		//为空保存
		instancePO.setCreatedDate(DateUtils.formatDate(new Date(System.currentTimeMillis()+(8*60*60*1000)), "yyyy-MM-dd HH:mm:ss"));
		instancePO.setCreatedBy(principal.getUid());
		//先保存到zk
		pizzaManagerHolder.getManager(instanceForm.getProjectId()).add(instance_path+"/"+instanceIp, instanceForm.getContent());
		//在保存到mongodb
		pizzaInstanceDAO.save(instancePO);
		return 3;
	}
	@Override
	public List<InstanceDTO> getInstances(String projectId,String group,Map<String,String> instancesMap,String instanceIp) {
		List<InstanceDTO> dtos = new ArrayList<InstanceDTO>();
		List<PizzaInstancePO> instancePOs = pizzaInstanceDAO.getInstances(projectId,instanceIp);
		if(instancePOs!=null&&instancePOs.size()>0) {
			InstanceDTO instanceDTO = null;
			for (PizzaInstancePO pizzaInstancePO : instancePOs) {
				instanceDTO = new InstanceDTO();
				POUtils.copyProperties(instanceDTO, pizzaInstancePO);
				if(!instancesMap.containsKey(instanceDTO.getInstanceIp())) {
					instanceDTO.setInstanceIp(instanceDTO.getInstanceIp()+".properties");
					instanceDTO.setProjectId(projectId);
					instanceDTO.setPappName(pizzaInstancePO.getAppName());
					instanceDTO.setStatus("-1");
					if(!StringUtils.isEmpty(group)) {
						if(instanceDTO.getGroup().contains(group)) {
							dtos.add(instanceDTO);
						}
					}else {
						dtos.add(instanceDTO);
					}
				}
			}
		}
		return dtos;
	}
	
}
