package com.pingan.pafa5.admin.fling.po;

import org.springframework.data.mongodb.core.mapping.Document;

import com.pingan.pafa5.admin.commons.BasePO;

@Document
public class FlingPappInstancePO extends BasePO {

    private String rid;
    /**
     * 项目ID
     */
    private String projectId;
    /**
     * 应用名
     */
    private String appName;

    /**
     * 实例IP
     */
    private String instanceIp;

    /**
     * 最近活跃时间
     */
    private long lastActiveTimestamp;

    /**
     * 状态: 0 运行正常 9 已过期删除 1 已停止 2 启动失败 3 心跳过期
     */
    private int status;

    /**
     * 最近活跃消息ID
     */
    private String lastActiveObjectId;

    public String getRid() {
        return rid;
    }

    public void setRid(String rid) {
        this.rid = rid;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getInstanceIp() {
        return instanceIp;
    }

    public void setInstanceIp(String instanceIp) {
        this.instanceIp = instanceIp;
    }

    public long getLastActiveTimestamp() {
        return lastActiveTimestamp;
    }

    public void setLastActiveTimestamp(long lastActiveTimestamp) {
        this.lastActiveTimestamp = lastActiveTimestamp;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getLastActiveObjectId() {
        return lastActiveObjectId;
    }

    public void setLastActiveObjectId(String lastActiveObjectId) {
        this.lastActiveObjectId = lastActiveObjectId;
    }

}
