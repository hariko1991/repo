package com.pingan.pafa5.admin.logging.po;

import org.springframework.data.mongodb.core.mapping.Document;

import com.pingan.pafa5.admin.commons.BasePO;



@Document
public class LogMonitorPO extends BasePO{
	
	@org.springframework.data.annotation.Id
	private String id;

	/**
	 * 队列ID
	 */
	private String queueName;
	
	/**
	 * 所属项目
	 */
	private String projectId;
	
	/**
	 *监控目标App
	 */	
	private String targetPapp;
	
	/**
	 *过期时间
	 */	
	private Integer expiredTime;
	
	/**
	 *开始时间
	 */	
	private String startTime;
	
	/**
	 * redis URL
	 */
	private String redisURL;
	
	/** 
	 * 系统配置的log4j 文件内容
	 */
	private String log4j;
	
	/**
	 * 状态：0正在查看，1过期
	 */
	private Integer status;
	
	/**
	 * ip
	 */
	private String ipaddr;
	
	public String getQueueName() {
		return queueName;
	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getTargetPapp() {
		return targetPapp;
	}

	public void setTargetPapp(String targetPapp) {
		this.targetPapp = targetPapp;
	}

	public Integer getExpiredTime() {
		return expiredTime;
	}

	public void setExpiredTime(Integer expiredTime) {
		this.expiredTime = expiredTime;
	}

	public String getRedisURL() {
		return redisURL;
	}

	public void setRedisURL(String redisURL) {
		this.redisURL = redisURL;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getLog4j() {
		return log4j;
	}

	public void setLog4j(String log4j) {
		this.log4j = log4j;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getStartTime() {
		return startTime;
	}

	public void setStartTime(String startTime) {
		this.startTime = startTime;
	}

	public String getIpaddr() {
		return ipaddr;
	}

	public void setIpaddr(String ipaddr) {
		this.ipaddr = ipaddr;
	}
	
}
