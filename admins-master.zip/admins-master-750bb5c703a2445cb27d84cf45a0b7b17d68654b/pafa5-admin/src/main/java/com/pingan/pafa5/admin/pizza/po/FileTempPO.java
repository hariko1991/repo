package com.pingan.pafa5.admin.pizza.po;


import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 临时文件 用户 上传文件过大的时候，将文件存放在临时存储区
 * 
 * @author ZHANGGANG871
 * 
 */
@Document
public class FileTempPO {

	/**
	 * id由service层生成uuid. {@link com.pingan.pafa5.admin.pizza.services.impl.PizzaConfigServicesImpl#saveFileTemp}
	 */
	@org.springframework.data.annotation.Id
	private String uuid;

	/**
	 * 二进制
	 */
	private String bytes;

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getBytes() {
		return bytes;
	}

	public void setBytes(String bytes) {
		this.bytes = bytes;
	}
}
