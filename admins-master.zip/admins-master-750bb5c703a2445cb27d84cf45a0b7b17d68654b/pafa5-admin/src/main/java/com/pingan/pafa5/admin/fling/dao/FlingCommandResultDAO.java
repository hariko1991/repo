package com.pingan.pafa5.admin.fling.dao;

import java.util.List;

import com.pingan.pafa5.admin.fling.po.FlingCommandResultPO;

public interface FlingCommandResultDAO {

    void add(FlingCommandResultPO po);

    List<FlingCommandResultPO> listByCommandId(String commandId);

}
