package com.pingan.pafa5.admin.pizza.exception;



/**
 * @see 配置不存在异常
 * @author JIECHANGKE805
 * @since 2016-05-19
 */
public class ConfigNotExistException extends NullPointerException {
 
	private static final long serialVersionUID = 1L;
	
	       public ConfigNotExistException() {
			   super();
		    }

		    public ConfigNotExistException(String message) {
			  super(message);
		    }
	

}
