package com.pingan.pafa5.admin.pizza.dao;

import java.util.List;

import com.pingan.pafa5.admin.pizza.po.PizzaInstancePO;

public interface PizzaInstanceDAO {
	void save(PizzaInstancePO instancePO);
	void update(PizzaInstancePO instancePO);
	PizzaInstancePO get(String proId, String instanceIp);
	
	List<PizzaInstancePO> getInstances(String projectId,String instanceIp);
}
