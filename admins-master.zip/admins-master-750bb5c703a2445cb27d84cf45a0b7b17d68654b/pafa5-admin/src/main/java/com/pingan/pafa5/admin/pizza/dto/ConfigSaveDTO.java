package com.pingan.pafa5.admin.pizza.dto;

import com.paic.pafa.validator.annotation.VNotEmpty;

/**
 * 配置信息 
 * @author EX-YANGSHENGXIANG001
 */
public class ConfigSaveDTO{

	//配置组(Group)编码
	@VNotEmpty
	private String group;
	//配置键(Key)
	@VNotEmpty
	private String key;
	
	private String description;
	//操作
	private String optype;
	
	private String value;
	
	private byte[] bytesValue;
	
	private String projectId;
	
	private String projectName;
	
	//文件存储位置的ID
	private String uuid;
	
	private String uid;//日志监控使用
	private String ipaddr;//日志监控使用
	

	public byte[] getBytesValue() {
		return bytesValue;
	}
	public void setBytesValue(byte[] bytesValue) {
		this.bytesValue = bytesValue;
	}
	public String getKey() {
		return key;
	}
	public void setKey(String key) {
		this.key = key;
	}
	public String getOptype() {
		return optype;
	}
	public void setOptype(String optype) {
		this.optype = optype;
	}
	public String getProjectId() {
		return projectId;
	}
	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
	public String getProjectName() {
		return projectName;
	}
	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getGroup() {
		return group;
	}
	public void setGroup(String group) {
		this.group = group;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getIpaddr() {
		return ipaddr;
	}
	public void setIpaddr(String ipaddr) {
		this.ipaddr = ipaddr;
	}
	
}
