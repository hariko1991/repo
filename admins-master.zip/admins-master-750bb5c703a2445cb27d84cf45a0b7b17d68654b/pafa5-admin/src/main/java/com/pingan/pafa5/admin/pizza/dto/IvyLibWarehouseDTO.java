package com.pingan.pafa5.admin.pizza.dto;

/**
 * @see ivy仓库数据传递对象
 * @author JIECHANGKE805
 * @date 2016-12-14
 *
 */
public class IvyLibWarehouseDTO  {
	
	/**
	 * 主键：projectID/org/module/version
	 */
	private String id;
	
	/**
	 * 项目ID
	 */
	private String projectId;
	/**
	 * 组织
	 */
	private String org;
	/**
	 * 模块
	 */
	private String module;
	/**
	 * 版本
	 */
	private String version;
	
	/**
	 * ivy文件，以字符串形式存储 
	 */
	private String ivyXml;
	
	/**
	 * lib包由Base64转码后的字符串
	 */
	private String libValue;
	/**
	 * 是否有效标识
	 */
	private String enableFlag;
	
	/**
	 * lib的md5
	 */
	private String md5;
	

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getOrg() {
		return org;
	}

	public void setOrg(String org) {
		this.org = org;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getIvyXml() {
		return ivyXml;
	}

	public void setIvyXml(String ivyXml) {
		this.ivyXml = ivyXml;
	}

	public String getLibValue() {
		return libValue;
	}

	public void setLibValue(String libValue) {
		this.libValue = libValue;
	}
	
	public String getEnableFlag() {
		return enableFlag;
	}

	public void setEnableFlag(String enableFlag) {
		this.enableFlag = enableFlag;
	}

	public String getMd5() {
		return md5;
	}

	public void setMd5(String md5) {
		this.md5 = md5;
	}
	

}
