package com.pingan.pafa5.admin.fling.po;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;

import com.paic.pafa.biz.dao.BasePO;

public class DruidSqlPO extends BasePO {

	@Id
	private String id;
	@Indexed
	private String druidDatasourceId;

	private String msgId;
	@Indexed
	private int identity;
	@Indexed
	private long sqlId;

	/**
	 * SQL
	 */
	private String druidSql;

	/**
	 * 执行数
	 */
	private long executeCount;

	/**
	 * 错误数
	 */
	private long errorCount;

	/**
	 * 执行时间
	 */
	private long totalTime;

	/**
	 * SQL
	 */
	private Date lastTime;

	/**
	 * 最慢
	 */
	private long maxTimespan;

	/**
	 * SQL
	 */
	private String lastError;

	/**
	 * 更新行数
	 */
	private long effectedRowCount;
	/**
	 * 读取行数
	 */
	private long fetchRowCount;

	private Date maxTimespanOccurTime;

	private long batchSizeMax;

	private long batchSizeTotal;
	/**
	 * 最大并发数
	 */
	private long concurrentMax;

	/**
	 * 执行中数
	 */
	private long runningCount;

	private String druidName;

	private String druidFile;

	private String lastErrorMessage;

	private String lastErrorClass;

	private String lastErrorStackTrace;

	private Date lastErrorTime;

	private String dbType;

	private String url;

	/**
	 * 事务执行数
	 */
	private long inTransactionCount;

	/**
	 * 执行时间分布
	 */
	private String histogram;

	private String lastSlowParameters;

	private long resultSetHoldTime;

	/**
	 * 执行和返回结果时间分布
	 */
	private long executeAndResultSetHoldTime;

	/**
	 * 读取行分布
	 */
	private String fetchRowCountHistogram;
	/**
	 * 更新行分布
	 */
	private String effectedRowCountHistogram;

	private String executeAndResultHoldTimeHistogram;

	private long effectedRowCountMax;

	private long fetchRowCountMax;

	private long clobOpenCount;

	private long blobOpenCount;

	private long readStringLength;

	private long readBytesLength;

	private long inputStreamOpenCount;

	private long readerOpenCount;

	private long sqlHash;

	public DruidSqlPO() {

	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getDruidDatasourceId() {
		return druidDatasourceId;
	}

	public void setDruidDatasourceId(String druidDatasourceId) {
		this.druidDatasourceId = druidDatasourceId;
	}

	public String getMsgId() {
		return msgId;
	}

	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}

	public int getIdentity() {
		return identity;
	}

	public void setIdentity(int identity) {
		this.identity = identity;
	}

	public long getSqlId() {
		return sqlId;
	}

	public void setSqlId(long sqlId) {
		this.sqlId = sqlId;
	}

	public String getDruidSql() {
		return druidSql;
	}

	public void setDruidSql(String druidSql) {
		this.druidSql = druidSql;
	}

	public long getExecuteCount() {
		return executeCount;
	}

	public void setExecuteCount(long executeCount) {
		this.executeCount = executeCount;
	}

	public long getErrorCount() {
		return errorCount;
	}

	public void setErrorCount(long errorCount) {
		this.errorCount = errorCount;
	}

	public long getTotalTime() {
		return totalTime;
	}

	public void setTotalTime(long totalTime) {
		this.totalTime = totalTime;
	}

	public Date getLastTime() {
		return lastTime;
	}

	public void setLastTime(Date lastTime) {
		this.lastTime = lastTime;
	}

	public long getMaxTimespan() {
		return maxTimespan;
	}

	public void setMaxTimespan(long maxTimespan) {
		this.maxTimespan = maxTimespan;
	}

	public String getLastError() {
		return lastError;
	}

	public void setLastError(String lastError) {
		this.lastError = lastError;
	}

	public long getEffectedRowCount() {
		return effectedRowCount;
	}

	public void setEffectedRowCount(long effectedRowCount) {
		this.effectedRowCount = effectedRowCount;
	}

	public long getFetchRowCount() {
		return fetchRowCount;
	}

	public void setFetchRowCount(long fetchRowCount) {
		this.fetchRowCount = fetchRowCount;
	}

	public Date getMaxTimespanOccurTime() {
		return maxTimespanOccurTime;
	}

	public void setMaxTimespanOccurTime(Date maxTimespanOccurTime) {
		this.maxTimespanOccurTime = maxTimespanOccurTime;
	}

	public long getBatchSizeMax() {
		return batchSizeMax;
	}

	public void setBatchSizeMax(long batchSizeMax) {
		this.batchSizeMax = batchSizeMax;
	}

	public long getBatchSizeTotal() {
		return batchSizeTotal;
	}

	public void setBatchSizeTotal(long batchSizeTotal) {
		this.batchSizeTotal = batchSizeTotal;
	}

	public long getConcurrentMax() {
		return concurrentMax;
	}

	public void setConcurrentMax(long concurrentMax) {
		this.concurrentMax = concurrentMax;
	}

	public long getRunningCount() {
		return runningCount;
	}

	public void setRunningCount(long runningCount) {
		this.runningCount = runningCount;
	}

	public String getDruidName() {
		return druidName;
	}

	public void setDruidName(String druidName) {
		this.druidName = druidName;
	}

	public String getDruidFile() {
		return druidFile;
	}

	public void setDruidFile(String druidFile) {
		this.druidFile = druidFile;
	}

	public String getLastErrorMessage() {
		return lastErrorMessage;
	}

	public void setLastErrorMessage(String lastErrorMessage) {
		this.lastErrorMessage = lastErrorMessage;
	}

	public String getLastErrorClass() {
		return lastErrorClass;
	}

	public void setLastErrorClass(String lastErrorClass) {
		this.lastErrorClass = lastErrorClass;
	}

	public String getLastErrorStackTrace() {
		return lastErrorStackTrace;
	}

	public void setLastErrorStackTrace(String lastErrorStackTrace) {
		this.lastErrorStackTrace = lastErrorStackTrace;
	}

	public Date getLastErrorTime() {
		return lastErrorTime;
	}

	public void setLastErrorTime(Date lastErrorTime) {
		this.lastErrorTime = lastErrorTime;
	}

	public String getDbType() {
		return dbType;
	}

	public void setDbType(String dbType) {
		this.dbType = dbType;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public long getInTransactionCount() {
		return inTransactionCount;
	}

	public void setInTransactionCount(long inTransactionCount) {
		this.inTransactionCount = inTransactionCount;
	}

	public String getHistogram() {
		return histogram;
	}

	public void setHistogram(String histogram) {
		this.histogram = histogram;
	}

	public String getLastSlowParameters() {
		return lastSlowParameters;
	}

	public void setLastSlowParameters(String lastSlowParameters) {
		this.lastSlowParameters = lastSlowParameters;
	}

	public long getResultSetHoldTime() {
		return resultSetHoldTime;
	}

	public void setResultSetHoldTime(long resultSetHoldTime) {
		this.resultSetHoldTime = resultSetHoldTime;
	}

	public long getExecuteAndResultSetHoldTime() {
		return executeAndResultSetHoldTime;
	}

	public void setExecuteAndResultSetHoldTime(long executeAndResultSetHoldTime) {
		this.executeAndResultSetHoldTime = executeAndResultSetHoldTime;
	}

	public String getFetchRowCountHistogram() {
		return fetchRowCountHistogram;
	}

	public void setFetchRowCountHistogram(String fetchRowCountHistogram) {
		this.fetchRowCountHistogram = fetchRowCountHistogram;
	}

	public String getEffectedRowCountHistogram() {
		return effectedRowCountHistogram;
	}

	public void setEffectedRowCountHistogram(String effectedRowCountHistogram) {
		this.effectedRowCountHistogram = effectedRowCountHistogram;
	}

	public String getExecuteAndResultHoldTimeHistogram() {
		return executeAndResultHoldTimeHistogram;
	}

	public void setExecuteAndResultHoldTimeHistogram(String executeAndResultHoldTimeHistogram) {
		this.executeAndResultHoldTimeHistogram = executeAndResultHoldTimeHistogram;
	}

	public long getEffectedRowCountMax() {
		return effectedRowCountMax;
	}

	public void setEffectedRowCountMax(long effectedRowCountMax) {
		this.effectedRowCountMax = effectedRowCountMax;
	}

	public long getFetchRowCountMax() {
		return fetchRowCountMax;
	}

	public void setFetchRowCountMax(long fetchRowCountMax) {
		this.fetchRowCountMax = fetchRowCountMax;
	}

	public long getClobOpenCount() {
		return clobOpenCount;
	}

	public void setClobOpenCount(long clobOpenCount) {
		this.clobOpenCount = clobOpenCount;
	}

	public long getBlobOpenCount() {
		return blobOpenCount;
	}

	public void setBlobOpenCount(long blobOpenCount) {
		this.blobOpenCount = blobOpenCount;
	}

	public long getReadStringLength() {
		return readStringLength;
	}

	public void setReadStringLength(long readStringLength) {
		this.readStringLength = readStringLength;
	}

	public long getReadBytesLength() {
		return readBytesLength;
	}

	public void setReadBytesLength(long readBytesLength) {
		this.readBytesLength = readBytesLength;
	}

	public long getInputStreamOpenCount() {
		return inputStreamOpenCount;
	}

	public void setInputStreamOpenCount(long inputStreamOpenCount) {
		this.inputStreamOpenCount = inputStreamOpenCount;
	}

	public long getReaderOpenCount() {
		return readerOpenCount;
	}

	public void setReaderOpenCount(long readerOpenCount) {
		this.readerOpenCount = readerOpenCount;
	}

	public long getSqlHash() {
		return sqlHash;
	}

	public void setSqlHash(long sqlHash) {
		this.sqlHash = sqlHash;
	}

}
