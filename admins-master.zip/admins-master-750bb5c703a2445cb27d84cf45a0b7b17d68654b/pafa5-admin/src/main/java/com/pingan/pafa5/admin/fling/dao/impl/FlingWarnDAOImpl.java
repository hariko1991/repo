package com.pingan.pafa5.admin.fling.dao.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.fling.dao.FlingWarnDAO;
import com.pingan.pafa5.admin.fling.po.FlingWarnPO;

@Nosql
@Repository
public class FlingWarnDAOImpl extends BaseMongoDAO<FlingWarnPO> implements FlingWarnDAO {

    @Override
    public void add(FlingWarnPO po) {
        this._add(po);
    }

    @Override
    public FlingWarnPO getById(String id) {
        return this._getById(id);
    }

    @Override
    public List<FlingWarnPO> listLast(String projectId, String pappName, String sarName, int size,
            int page) {
        Criteria criteria = new Criteria();
        if (sarName != null && !"".equals(sarName.trim())) {
            criteria.and("sarName").is(sarName);
        }
        if (pappName != null && !"".equals(pappName.trim())) {
            criteria.and("appName").is(pappName);
        }
        if (StringUtils.isNotEmpty(projectId)) {
            criteria.and("projectId").is(projectId);
        } else {
            criteria.and("projectId").is(null);
        }

        int skip = (page - 1) * size;
        return this._listAndDesc(criteria, skip, size, "createdTimestamp");
    }

    @Override
    public long getCount(String projectId, String pappName, String sarName) {
        Criteria criteria = new Criteria();
        if (sarName != null && !"".equals(sarName.trim())) {
            criteria.and("sarName").is(sarName);
        }
        if (pappName != null && !"".equals(pappName.trim())) {
            criteria.and("appName").is(pappName);
        }
        if (StringUtils.isNotEmpty(projectId)) {
            criteria.and("projectId").is(projectId);
        } else {
            criteria.and("projectId").is(null);
        }

        return this._count(criteria);
    }

    @Override
    public int removeBeforeDate(Date date) {
        Criteria criteria = Criteria.where("createdTimestamp").lt(date.getTime());
        int affected = this._remove(criteria);
        return affected;
    }
    
}
