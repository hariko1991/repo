package com.pingan.pafa5.admin.fling.dao;

import java.util.List;
import java.util.Map;

import com.pingan.pafa5.admin.fling.po.DruidDatasourcePO;

public interface DruidDatasourceDAO {
	
	public void add(DruidDatasourcePO datasourece);
	public void update(DruidDatasourcePO datasourece);
	public DruidDatasourcePO getDruidDatasourceById(String id, int identity);
	public DruidDatasourcePO getDruidDatasourceByIdentity(int identity);
	public DruidDatasourcePO getDruidDatasourceByUrl(Map<String,Object> map);
	public List<DruidDatasourcePO> list(Map<String,Object> map);
	public List<DruidDatasourcePO> getAll();
	public long getCount(Map<String,Object> map);

}
