package com.pingan.pafa5.admin.fling.dao;

import java.util.Date;

import com.pingan.pafa5.admin.fling.po.DruidDatasourceHistoryPO;

public interface DruidDatasourceHistoryDAO {
	
	public void add(DruidDatasourceHistoryPO po);
	
	public long getCountByDate(Date createdDate);
	
	public int removeByDate(Date createdDate);

}
