package com.pingan.pafa5.admin.logging.dao;

import java.util.List;

import com.pingan.pafa5.admin.logging.po.LogMonitorPO;

public interface LogMonitorDAO {
	
	void add(LogMonitorPO po);

	List<LogMonitorPO> list(String projectId, String pappName, int limit, int page);

	long getTotal(String projectId, String pappName);

	LogMonitorPO getById(String queueName);

	boolean update(LogMonitorPO po);

	boolean delete(String id);

	boolean isUsed(String queueName);

	List<LogMonitorPO> getUseList();

	boolean isLock(String projectId, String targetPapp);

	boolean isLooking(String projectId, String pappName, int expiredTime, int status);
}
