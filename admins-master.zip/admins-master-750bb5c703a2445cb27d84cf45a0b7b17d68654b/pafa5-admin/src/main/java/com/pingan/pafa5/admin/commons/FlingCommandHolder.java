package com.pingan.pafa5.admin.commons;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import com.pingan.pafa.fling.FlingCommand;
import com.pingan.pafa.fling.FlingCommandBean;
import com.pingan.pafa.fling.FlingCommandReceiptor;

public final class FlingCommandHolder implements InitializingBean, DisposableBean {
	
	private Log logger=LogFactory.getLog(this.getClass());

	private static Map<String, FlingCommandBean> commandMapping;

	private PizzaManagerHolder pizzaManagerHolder;
	
	private FlingCommandReceiptor commandReceiptor;
	
	public synchronized FlingCommand getCommand(String projectId) {
		if(StringUtils.isEmpty(projectId)) {
			projectId = "def";
		}
		
		if(commandMapping.containsKey(projectId)) {
			return commandMapping.get(projectId);
		} else {
			FlingCommandBean command = newCommand(projectId);
			commandMapping.put(projectId, command);
			return command;
		}
	}
	
	private FlingCommandBean newCommand(String projectId) {
		FlingCommandBean command = new FlingCommandBean();
		
		command.setPizzaManager(pizzaManagerHolder.getManager(projectId));
		command.setCommandReceiptor(commandReceiptor);
		try {
			command.afterPropertiesSet();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return command;
	}
	
	@Override
	public void afterPropertiesSet() throws Exception {
		commandMapping = new HashMap<String, FlingCommandBean>();
		
		FlingCommandBean command = newCommand("def");
		commandMapping.put("def", command);
	}
	
	private void closeCommand(FlingCommandBean command) {
		try {
			command.destroy();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@Override
	public void destroy() throws Exception {
		for(FlingCommandBean command : commandMapping.values()) {
			closeCommand(command);
		}
	}
	
	public void clearExpiredListeners() {
		for(FlingCommand flingCommand : commandMapping.values()) {
			flingCommand.clearExpiredListeners();
		}
	}

	public void setPizzaManagerHolder(PizzaManagerHolder pizzaManagerHolder) {
		this.pizzaManagerHolder = pizzaManagerHolder;
	}

	public void setCommandReceiptor(FlingCommandReceiptor commandReceiptor) {
		this.commandReceiptor = commandReceiptor;
	}

}
