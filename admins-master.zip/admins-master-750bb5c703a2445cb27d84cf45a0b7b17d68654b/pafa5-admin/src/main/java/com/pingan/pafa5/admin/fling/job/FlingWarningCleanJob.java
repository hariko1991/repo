package com.pingan.pafa5.admin.fling.job;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paic.pafa.job.TimerJob;
import com.pingan.pafa5.admin.fling.services.FlingWarnServices;

/**
 * 运维中心-告警信息数据清理
 * @author ZHANGJIAWEI370
 * 
 */
@Component
public final class FlingWarningCleanJob {

	private Log logger = LogFactory.getLog(this.getClass());
	
	@Autowired
	private FlingWarnServices flingWarnServices;

	@TimerJob(cronExpression="${job.ex.fling.warning.clean.time}")
	public void execute() throws Exception{
		logger.info("开始清理告警信息数据★★★★★★★★★★★★★★★★★★★★★★★★★★★");
		
		flingWarnServices.delete15DaysBefore();
		
		logger.info("结束清理告警信息数据★★★★★★★★★★★★★★★★★★★★★★★★★★★");
	}

	public void setFlingWarnServices(FlingWarnServices flingWarnServices) {
		this.flingWarnServices = flingWarnServices;
	}
	
}
