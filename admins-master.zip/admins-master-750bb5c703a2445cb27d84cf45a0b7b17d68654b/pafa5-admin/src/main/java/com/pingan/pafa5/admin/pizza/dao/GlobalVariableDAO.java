package com.pingan.pafa5.admin.pizza.dao;

import java.util.List;

import com.pingan.pafa5.admin.pizza.po.GlobalVariablePO;

public interface GlobalVariableDAO {

	public List<GlobalVariablePO> list(String proId, String property, int page,
									   int limit);

	public long getCount(String proId, String property);

	public GlobalVariablePO getById(String id);

	public void add(GlobalVariablePO po);

	public boolean edit(GlobalVariablePO po);

	public boolean delete(String id);

	public List<GlobalVariablePO> list(String proId);
}