package com.pingan.pafa5.admin.fling.web;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.fling.msg.FlingCommandMsg;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa5.admin.commons.SARManagerConstants;
import com.pingan.pafa5.admin.fling.dto.FlingCommandResultsDTO;
import com.pingan.pafa5.admin.fling.form.SendCommandForm;
import com.pingan.pafa5.admin.fling.po.FlingCommandResultPO;
import com.pingan.pafa5.admin.fling.services.FlingCommandServices;

/**
 * 用户操作指令
 * 
 * @author ZHANGJIAWEI370
 * @author EX-YANGSHENGXIANG001
 */
@Controller
@RequestMapping("/pizzamgr")
public class FlingCommandController extends BaseController {

    @Autowired
    private FlingCommandServices flingCommandServices;
    
    @ActionClient(name = "pafa5-admin-systems.isOwner")
    private IServiceClient ownerService;
    
    /**
     * 获取指令执行结果
     * @param dictateId
     * @param mode wait/lastTries
     * @return
     * @throws Throwable
     */
    @RequestMapping("/getDictateResult.do")
    @ESA(value = "pafa5-admin-fling.getDictateResult", local = true)
    @ResponseBody
    public ResponseModel getDictateResult(@RequestParam("dictateId") String commandId,
            @RequestParam(value = "mode", defaultValue = "wait") String mode) throws Throwable {
        FlingCommandResultsDTO dto = flingCommandServices.getResults(commandId); 
        List<FlingCommandResultPO> datas = dto.getResults();

        boolean completedFlag = dto.isCompleted();
        boolean outputResultFlag = completedFlag || (!mode.equals("wait") && datas != null && datas.size() > 0);
        List<ModelMap> results = null;
        if (outputResultFlag) {
            results = new ArrayList<ModelMap>(datas.size());
            DateFormat formatter = DateFormat.getDateTimeInstance();
            for (FlingCommandResultPO po : datas) {
                ModelMap model = new ModelMap();
                // model.put("dictateId", po.getRid());
                model.put("status", po.getResponseCode());
                model.put("resultMsg", po.getResponseMsg());
                model.put("instanceIp", po.getInstanceIp());
                model.put("instanceName", po.getInstanceName());
                // model.put("sarName", po.getSarName());
                model.put("receiptDate", formatter.format(new Date(po.getReceiptDate())));
                model.put("createdDate", formatter.format(po.getCreatedDate()));
                // model.put("pappName", po.getPappName());
                results.add(model);
            }
        }
        ResponseModel map = new ResponseModel();
        map.put("instanceSize", dto.getInstanceSize());
        map.put("completed", dto.isCompleted());
        map.put("results", results);
        return map;
    }

    /**
     * 接收指令
     * @param form
     * @return
     * @throws Throwable
     */
    @RequestMapping("/sendDictate.do")
    @ESA(value = "pafa5-admin-fling.sendDictate", local = true)
    @ResponseBody
    public ResponseModel sendDictate(SendCommandForm form) throws Throwable {
        isOwner(form.getProjectId());
        
        if (logger.isInfoEnabled()) {
            logger.info("sendDictate:" + JSONObject.toJSONString(form));
        }
        
        String dictateName = form.getDictateName();
        // 发送指令
        FlingCommandMsg cmdMsg = new FlingCommandMsg();
        cmdMsg.setProjectId(form.getProjectId());
        cmdMsg.setActionType(dictateName.equals("delete") ? "shutdown" : dictateName);
        cmdMsg.setPappName(form.getPappName());
        cmdMsg.setSarName(form.getSarName());
        cmdMsg.setTargetType(form.getType());
        String executeIps = form.getExecuteIps();
        if (executeIps != null && !"".equals(executeIps.trim())) {
            List<String> limitIps = new ArrayList<String>();
            for (String ip : executeIps.split(",")) {
                limitIps.add(ip);
            }
            cmdMsg.setLimitIps(limitIps);
        }
        String dictateId = null;
        try {
        	
	        /*ResponseModel model1 = flingCommandServices.checkSarExist(cmdMsg,form);
	        if(model1!=null){
	        	return model1;
	        }*/
       
            dictateId = flingCommandServices.sendCommand(cmdMsg, form);
        } catch (Exception ex) {
            logger.error("SendCommand error,cause:" + ex.getMessage(), ex);
            ResponseModel model = new ResponseModel("1", ex.getMessage());
            model.put("executeIp", form.getExecuteIps());
            model.put("success", false);
            return model;
        }
        ResponseModel model = new ResponseModel("0", "指令发送成功");
        model.put("dictateId", dictateId);
        model.put("executeIp", form.getExecuteIps());
        model.put("success", true);
        return model;
    }

    /**
     * 指令操作日志
     * 
     * @return
     */
    public ResponseModel getOperationLogger() {
        ResponseModel model = new ResponseModel("0", "指令发送成功");
        model.put("success", true);
        return model;
    }
    
    public void isOwner(String domainId) {
        if (domainId == null || SARManagerConstants.DEF.equalsIgnoreCase(domainId)) {
            return;
        }
        ServiceParams params = new ServiceParams();
        params.set("groupId", domainId);
        ServiceResults results = ownerService.invoke(params);
        boolean isBoo = results.getBool("isowner");
        if (!isBoo) {
            throw new ResponseCodeException("354", "对不起，你不是领域负责人，没有此操作权限");
        }
    }

    public void setFlingCommandServices(FlingCommandServices flingCommandServices) {
        this.flingCommandServices = flingCommandServices;
    }

    public void setOwnerService(IServiceClient ownerService) {
        this.ownerService = ownerService;
    }

}
