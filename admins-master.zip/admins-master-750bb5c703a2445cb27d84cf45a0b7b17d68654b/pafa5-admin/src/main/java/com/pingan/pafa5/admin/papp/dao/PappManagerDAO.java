package com.pingan.pafa5.admin.papp.dao;

import java.util.List;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.papp.dto.PappManagerDTO;
import com.pingan.pafa5.admin.papp.po.PappManagerPO;
import com.pingan.pafa5.admin.systems.dto.SystemGroupDTO;

/**
 * 应用管理dao接口
 * 2016-6-14 14:11:25
 * @author HOUSHANGZHI377
 *
 */
public interface PappManagerDAO 
{

	public PappManagerPO isExists(PappManagerDTO form);

	public PageDataDTO<PappManagerPO> listUserPapp(PappManagerDTO dto ,List<SystemGroupDTO> list);
	
	public PageDataDTO<PappManagerPO> list(PappManagerDTO dto);
	
	public PappManagerPO getById(String id);
	
	public PappManagerPO getByProperty(String property,String value);
	
	public boolean updateById(PappManagerPO po);
	
	public void add(PappManagerPO po);
	
	boolean delById(String id);
}
