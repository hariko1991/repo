package com.pingan.pafa5.admin.fling.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.fling.po.FlingWarnPO;
import com.pingan.pafa5.admin.fling.services.FlingWarnServices;
import com.pingan.pafa5.admin.papp.dto.SarDTO;

@Controller
@RequestMapping("/fling")
public class FlingWarnController extends BaseController {

	@Autowired
	private FlingWarnServices flingWarnServices;
	 @ActionClient(name = "garden.pushMessage")
	    private IServiceClient pushService;
	
	@RequestMapping("/list-warns.do")
	@ResponseBody
	public ResponseModel listForPapp(@RequestParam(value="limit",defaultValue="30") int limit
			,@RequestParam(value="page",defaultValue="1") int page
			,@RequestParam(value="formatDate",defaultValue="true")boolean formatDate
			,@RequestParam(value="projectId") String projectId
			,@RequestParam(value="pappName",required=false) String pappName
			,@RequestParam(value="sarName",required=false) String sarName){
		PageDataDTO<FlingWarnPO> pageDataDTO = flingWarnServices.list(projectId,pappName, sarName, limit, page);
		//List<FlingWarnPO> pos=flingWarnServices.listLast(pappName, sarName, limit, page);
		List<FlingWarnPO> pos = pageDataDTO.getDatas();
		if(pos==null|| pos.size()==0){
			return new ResponseModel("1","没有任何告警信息。");
		}
		List<ModelMap> datas=new ArrayList<ModelMap>(pos.size());
		DateFormat formatter =null;
		if(formatDate){
			formatter=DateFormat.getDateTimeInstance();
		}
		for(FlingWarnPO po:pos){
			ModelMap map=new ModelMap();
			map.put("id", po.getId());
			map.put("pappName", po.getAppName());
			map.put("sarName", po.getSarName());
			map.put("instanceIp", po.getInstanceIp());
			map.put("bizRequestId", po.getBizRequestId());
			map.put("warnSource", po.getWarnSource());
			String desc = po.getDescription();
			if (desc != null && !"".equals(desc.trim())) {
				if(desc.indexOf('\n')>-1){
					desc = desc.substring(0, desc.indexOf('\n')-1)+"……";
				}
			}
			map.put("description", desc);
			if(formatDate){
				map.put("createdTime", formatter.format(new Date(po.getCreatedTimestamp())));
			}else{
				map.put("createdTime", po.getCreatedTimestamp());
			}
			datas.add(map);
		}
		ResponseModel model=new ResponseModel();
		model.addAttribute("datas",datas);
		model.addAttribute("totalProperty",pageDataDTO.getTotalSize());
		return model;
	}
	
	@RequestMapping("/list-warns-papp.do")
	@ResponseBody
	public ResponseModel listForPapp_Papp(@RequestParam(value="limit",defaultValue="30") int limit
			,@RequestParam(value="page",defaultValue="1") int page
			,@RequestParam(value="formatDate",defaultValue="true")boolean formatDate
			,@RequestParam(value="projectId") String projectId
			,@RequestParam(value="pappName",required=false) String pappName
			,@RequestParam(value="sarName",required=false) String sarName){
		PageDataDTO<FlingWarnPO> pageDataDTO = flingWarnServices.list(projectId,pappName, sarName, limit, page);
		//List<FlingWarnPO> pos=flingWarnServices.listLast(pappName, sarName, limit, page);
		List<FlingWarnPO> pos = pageDataDTO.getDatas();
        if (pos == null || pos.size() == 0) {
        	ResponseModel model =new ResponseModel("1", "未能找到对应SAR信息。");
	       	 List<ModelMap> datas = new ArrayList<ModelMap>();
	       	 model.addAttribute("sarNames",datas);
	       	 model.addAttribute("size",0);
           return model;
        }
        Set<String> sarNameSet  = new HashSet<String>();
        for(FlingWarnPO po : pos){
        	sarNameSet.add(po.getSarName());
        }
        List<SarDTO> datas = new ArrayList<SarDTO>(sarNameSet.size());
        for (String s : sarNameSet) {
        	SarDTO dto = new SarDTO();
        	dto.setId(s);
			dto.setSarName(s);
            datas.add(dto);
        }
        ResponseModel model = new ResponseModel();
        model.addAttribute("sarNames", datas);
        model.addAttribute("size", pageDataDTO.getTotalSize());
        return model;
	}
	
	/*** 查看警告信息
	 * 
	 * @param id
	 * @param response
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/details-warns.do")
	public ModelMap details(
			@RequestParam(value="id",required=true) String id,
			HttpServletResponse response) throws IOException {
		String desc = flingWarnServices.details(id);
		if (desc != null && !"".equals(desc.trim())) {
			response.setContentType("text/plain;charset=utf-8");
			PrintWriter pw = response.getWriter();
			pw.print(desc);
			pw.flush();
			pw.close();
		}
		return null;
	}
	/*** garden测试
	 * 
	 * @param 
	 * @param 
	 * @return
	 * @throws IOException
	 */
	@RequestMapping("/gardenTest.do")
	@ResponseBody
	public ServiceResults gardenPushTest()  {
		ServiceParams params = new ServiceParams();
		params.set("isStg", true);
		params.set("isIOS", false);
		params.set("deviceId", "suntao701");
		params.set("scopeValue", "sdfsdfsdf");
		params.set("messageContent", "管控平台调用esa接口推送");
		params.set("messageTitle", "怕了吧");
        return  pushService.invoke(params);
		
	}
	
}
