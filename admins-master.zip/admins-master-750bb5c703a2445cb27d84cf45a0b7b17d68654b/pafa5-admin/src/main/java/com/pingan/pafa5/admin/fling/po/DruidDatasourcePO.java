package com.pingan.pafa5.admin.fling.po;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;

import com.paic.pafa.biz.dao.BasePO;

public class DruidDatasourcePO extends BasePO{
	
	@Id
	private String id;
	

	private String msgId;
    
	 
    private int identity;
    
    /**
     * 领域名Id
     */
    @Indexed
    private String domainId;
    /**
     * 领域名
     */
    private String domainName;
    
    /**
     * 应用名
     */
    @Indexed
	private String pappName;
    
    /**
     * 节点IP
     */
    private String instanceIp;
    
    /**
     * 节点IP
     */
    private String instanceName;
    
	 /**
     * druid用户名
     */
	private String druidName;
	 /**
     * 数据库类型
     */
    private String dbType;
    /**
     * 数据库驱动
     */
    private String driverClassName;
   
    /**
     * 数据库用户名
     */
    private String userName;
    /**
     * 数据库地址
     */
    private String url;
    /**
     * 过滤器类
     */
    private String filterClassName;
	 /**
     * 数据库类型
     */
    private int waitThreadCount;
	 /**
     * 等待次数
     */
    private long notEmptyWaitCount;
	 /**
     * 等待线程数量
     */
    private long notEmptyWaitNanos;
	 /**
     * 池中连接数
     */
    private int poolingCount;
	 /**
     * 池中连接数峰值
     */
    private int poolingPeak;
	 /**
     * 池中连接数峰值时间
     */
    private Date poolingPeakTime;
	 /**
     * 活跃连接数
     */
    private int activeCount;
	 /**
     * 活跃连接数峰值
     */
    private int activePeak;
	 /**
     * 活跃连接数峰值时间
     */
    private Date activePeakTime;
	 /**
     * 初始化大小
     */
    private int initialSize;
	 /**
     * 最小空闲连接数
     */
    private int minIdle;
	 /**
     * 最大连接数
     */
    private int maxActive;
	 /**
     * 查询超时时间
     */
    private int queryTimeout;
	 /**
     * 事务查询超时时间
     */
    private int transactionQueryTimeout;
	 /**
     * 登陆超时时间
     */
    private int loginTimeout;
	 /**
     * 连接有效性检查类名
     */
    private String validConnectionCheckerClassName;
	
    private String exceptionSorterClassName;
	 /**
     * 获取连接时检查
     */
    private boolean testOnBorrow;
	 /**
     * 连接放回连接池时检测
     */
    private boolean testOnReturn;
	 /**
     * 空闲时检测
     */
    private boolean testWhileIdle;
	 /**
     * 默认自动提交设置
     */
    private boolean defaultAutoCommit;
	 /**
     * 默认只读设置
     */
    private boolean defaultReadOnly;
	 /**
     * 默认事务隔离级别设置
     */
    private String defaultTransactionIsolation;
	 /**
     * 逻辑连接次数
     */
    private long logicConnectCount;
	 /**
     * 逻辑关闭次数
     */
    private long logicCloseCount;
	 /**
     * 逻辑连接错误次数
     */
    private long logicConnectErrorCount;
	 /**
     * 物理连接次数
     */
    private long physicalConnectCount;
	 /**
     * 物理关闭次数
     */
    private long physicalCloseCount;
	 /**
     * 物理连接失败次数
     */
    private long physicalConnectErrorCount;
	
    private long executeCount;
	 /**
     * 执行数
     */
    private long errorCount;
	 /**
     * 错误数
     */
    private long commitCount;
	 /**
     * 提交次数
     */
    private long rollbackCount;
	 /**
     * 回滚次数
     */
    private long pSCacheAccessCount;
	
    private long pSCacheHitCount;

    private long pSCacheMissCount;
	 /**
     * 事务启动数
     */
    private long startTransactionCount;
	 /**
     * 事务时间分
     */
    private String transactionHistogram;
	
    private String connectionHoldTimeHistogram;

    private boolean removeAbandoned;
	
    private long clobOpenCount;

    private long blobOpenCount;
	 /**
     * 检查活跃连接次数
     */
    private long keepAliveCheckCount;
	 /**
     * 保持活跃设置
     */
    private boolean keepAlive;
	 /**
     * 快速失败设置
     */
    private boolean failFast;
	
    private int maxWait;
    /**
     * 数据库类型
     */
    private int maxWaitThreadCount;
   
    private int poolPreparedStatements;
  
    private int maxPoolPreparedStatementsPerConnectionSize;
    /**
     * 连接可空闲的最小时间
     */
    private int minEvictableIdleTimeMillis;
    /**
     * 连接可空闲的最大时间
     */
    private int maxEvictableIdleTimeMillis;
    
    private int logDifferentThread;
   
    private int recycleErrorCount;
  
    private int preparedStatementOpenCount;
   
    private int preparedStatementClosedCount;
   
    private boolean useUnfairLock;
   
    private boolean initGlobalvariants;
   
    private boolean initVariants;
    
    private int status;
    
    
    public DruidDatasourcePO(){
    	
    }


    
	public String getId() {
		return id;
	}



	public void setId(String id) {
		this.id = id;
	}



	public String getMsgId() {
		return msgId;
	}


	public void setMsgId(String msgId) {
		this.msgId = msgId;
	}

	public int getIdentity() {
		return identity;
	}


	public void setIdentity(int identity) {
		this.identity = identity;
	}


	public String getDomainId() {
		return domainId;
	}


	public void setDomainId(String domainId) {
		this.domainId = domainId;
	}


	public String getDomainName() {
		return domainName;
	}



	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}



	public String getPappName() {
		return pappName;
	}


	public void setPappName(String pappName) {
		this.pappName = pappName;
	}


	public String getInstanceName() {
		return instanceName;
	}


	public void setInstanceName(String instanceName) {
		this.instanceName = instanceName;
	}


	public String getInstanceIp() {
		return instanceIp;
	}


	public void setInstanceIp(String instanceIp) {
		this.instanceIp = instanceIp;
	}


	public String getDruidName() {
		return druidName;
	}


	public void setDruidName(String druidName) {
		this.druidName = druidName;
	}


	public String getDbType() {
		return dbType;
	}


	public void setDbType(String dbType) {
		this.dbType = dbType;
	}


	public String getDriverClassName() {
		return driverClassName;
	}


	public void setDriverClassName(String driverClassName) {
		this.driverClassName = driverClassName;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getUrl() {
		return url;
	}


	public void setUrl(String url) {
		this.url = url;
	}


	public String getFilterClassName() {
		return filterClassName;
	}


	public void setFilterClassName(String filterClassName) {
		this.filterClassName = filterClassName;
	}


	public int getWaitThreadCount() {
		return waitThreadCount;
	}


	public void setWaitThreadCount(int waitThreadCount) {
		this.waitThreadCount = waitThreadCount;
	}


	public long getNotEmptyWaitCount() {
		return notEmptyWaitCount;
	}


	public void setNotEmptyWaitCount(long notEmptyWaitCount) {
		this.notEmptyWaitCount = notEmptyWaitCount;
	}


	public long getNotEmptyWaitNanos() {
		return notEmptyWaitNanos;
	}


	public void setNotEmptyWaitNanos(long notEmptyWaitNanos) {
		this.notEmptyWaitNanos = notEmptyWaitNanos;
	}


	public int getPoolingCount() {
		return poolingCount;
	}


	public void setPoolingCount(int poolingCount) {
		this.poolingCount = poolingCount;
	}


	public int getPoolingPeak() {
		return poolingPeak;
	}


	public void setPoolingPeak(int poolingPeak) {
		this.poolingPeak = poolingPeak;
	}


	public Date getPoolingPeakTime() {
		return poolingPeakTime;
	}


	public void setPoolingPeakTime(Date poolingPeakTime) {
		this.poolingPeakTime = poolingPeakTime;
	}


	public int getActiveCount() {
		return activeCount;
	}


	public void setActiveCount(int activeCount) {
		this.activeCount = activeCount;
	}


	public int getActivePeak() {
		return activePeak;
	}


	public void setActivePeak(int activePeak) {
		this.activePeak = activePeak;
	}


	public Date getActivePeakTime() {
		return activePeakTime;
	}


	public void setActivePeakTime(Date activePeakTime) {
		this.activePeakTime = activePeakTime;
	}


	public int getInitialSize() {
		return initialSize;
	}


	public void setInitialSize(int initialSize) {
		this.initialSize = initialSize;
	}


	public int getMinIdle() {
		return minIdle;
	}


	public void setMinIdle(int minIdle) {
		this.minIdle = minIdle;
	}


	public int getMaxActive() {
		return maxActive;
	}


	public void setMaxActive(int maxActive) {
		this.maxActive = maxActive;
	}


	public int getQueryTimeout() {
		return queryTimeout;
	}


	public void setQueryTimeout(int queryTimeout) {
		this.queryTimeout = queryTimeout;
	}


	public int getTransactionQueryTimeout() {
		return transactionQueryTimeout;
	}


	public void setTransactionQueryTimeout(int transactionQueryTimeout) {
		this.transactionQueryTimeout = transactionQueryTimeout;
	}


	public int getLoginTimeout() {
		return loginTimeout;
	}


	public void setLoginTimeout(int loginTimeout) {
		this.loginTimeout = loginTimeout;
	}


	public String getValidConnectionCheckerClassName() {
		return validConnectionCheckerClassName;
	}


	public void setValidConnectionCheckerClassName(
			String validConnectionCheckerClassName) {
		this.validConnectionCheckerClassName = validConnectionCheckerClassName;
	}


	public String getExceptionSorterClassName() {
		return exceptionSorterClassName;
	}


	public void setExceptionSorterClassName(String exceptionSorterClassName) {
		this.exceptionSorterClassName = exceptionSorterClassName;
	}


	public boolean isTestOnBorrow() {
		return testOnBorrow;
	}


	public void setTestOnBorrow(boolean testOnBorrow) {
		this.testOnBorrow = testOnBorrow;
	}


	public boolean isTestOnReturn() {
		return testOnReturn;
	}


	public void setTestOnReturn(boolean testOnReturn) {
		this.testOnReturn = testOnReturn;
	}


	public boolean isTestWhileIdle() {
		return testWhileIdle;
	}


	public void setTestWhileIdle(boolean testWhileIdle) {
		this.testWhileIdle = testWhileIdle;
	}


	public boolean isDefaultAutoCommit() {
		return defaultAutoCommit;
	}


	public void setDefaultAutoCommit(boolean defaultAutoCommit) {
		this.defaultAutoCommit = defaultAutoCommit;
	}


	public boolean isDefaultReadOnly() {
		return defaultReadOnly;
	}


	public void setDefaultReadOnly(boolean defaultReadOnly) {
		this.defaultReadOnly = defaultReadOnly;
	}


	public String getDefaultTransactionIsolation() {
		return defaultTransactionIsolation;
	}


	public void setDefaultTransactionIsolation(String defaultTransactionIsolation) {
		this.defaultTransactionIsolation = defaultTransactionIsolation;
	}


	public long getLogicConnectCount() {
		return logicConnectCount;
	}


	public void setLogicConnectCount(long logicConnectCount) {
		this.logicConnectCount = logicConnectCount;
	}


	public long getLogicCloseCount() {
		return logicCloseCount;
	}


	public void setLogicCloseCount(long logicCloseCount) {
		this.logicCloseCount = logicCloseCount;
	}


	public long getLogicConnectErrorCount() {
		return logicConnectErrorCount;
	}


	public void setLogicConnectErrorCount(long logicConnectErrorCount) {
		this.logicConnectErrorCount = logicConnectErrorCount;
	}


	public long getPhysicalConnectCount() {
		return physicalConnectCount;
	}


	public void setPhysicalConnectCount(long physicalConnectCount) {
		this.physicalConnectCount = physicalConnectCount;
	}


	public long getPhysicalCloseCount() {
		return physicalCloseCount;
	}


	public void setPhysicalCloseCount(long physicalCloseCount) {
		this.physicalCloseCount = physicalCloseCount;
	}


	public long getPhysicalConnectErrorCount() {
		return physicalConnectErrorCount;
	}


	public void setPhysicalConnectErrorCount(long physicalConnectErrorCount) {
		this.physicalConnectErrorCount = physicalConnectErrorCount;
	}


	public long getExecuteCount() {
		return executeCount;
	}


	public void setExecuteCount(long executeCount) {
		this.executeCount = executeCount;
	}


	public long getErrorCount() {
		return errorCount;
	}


	public void setErrorCount(long errorCount) {
		this.errorCount = errorCount;
	}


	public long getCommitCount() {
		return commitCount;
	}


	public void setCommitCount(long commitCount) {
		this.commitCount = commitCount;
	}


	public long getRollbackCount() {
		return rollbackCount;
	}


	public void setRollbackCount(long rollbackCount) {
		this.rollbackCount = rollbackCount;
	}


	public long getpSCacheAccessCount() {
		return pSCacheAccessCount;
	}


	public void setpSCacheAccessCount(long pSCacheAccessCount) {
		this.pSCacheAccessCount = pSCacheAccessCount;
	}


	public long getpSCacheHitCount() {
		return pSCacheHitCount;
	}


	public void setpSCacheHitCount(long pSCacheHitCount) {
		this.pSCacheHitCount = pSCacheHitCount;
	}


	public long getpSCacheMissCount() {
		return pSCacheMissCount;
	}


	public void setpSCacheMissCount(long pSCacheMissCount) {
		this.pSCacheMissCount = pSCacheMissCount;
	}


	public long getStartTransactionCount() {
		return startTransactionCount;
	}


	public void setStartTransactionCount(long startTransactionCount) {
		this.startTransactionCount = startTransactionCount;
	}


	public String getTransactionHistogram() {
		return transactionHistogram;
	}


	public void setTransactionHistogram(String transactionHistogram) {
		this.transactionHistogram = transactionHistogram;
	}


	public String getConnectionHoldTimeHistogram() {
		return connectionHoldTimeHistogram;
	}


	public void setConnectionHoldTimeHistogram(String connectionHoldTimeHistogram) {
		this.connectionHoldTimeHistogram = connectionHoldTimeHistogram;
	}


	public boolean isRemoveAbandoned() {
		return removeAbandoned;
	}


	public void setRemoveAbandoned(boolean removeAbandoned) {
		this.removeAbandoned = removeAbandoned;
	}


	public long getClobOpenCount() {
		return clobOpenCount;
	}


	public void setClobOpenCount(long clobOpenCount) {
		this.clobOpenCount = clobOpenCount;
	}


	public long getBlobOpenCount() {
		return blobOpenCount;
	}


	public void setBlobOpenCount(long blobOpenCount) {
		this.blobOpenCount = blobOpenCount;
	}


	public long getKeepAliveCheckCount() {
		return keepAliveCheckCount;
	}


	public void setKeepAliveCheckCount(long keepAliveCheckCount) {
		this.keepAliveCheckCount = keepAliveCheckCount;
	}


	public boolean isKeepAlive() {
		return keepAlive;
	}


	public void setKeepAlive(boolean keepAlive) {
		this.keepAlive = keepAlive;
	}


	public boolean isFailFast() {
		return failFast;
	}


	public void setFailFast(boolean failFast) {
		this.failFast = failFast;
	}


	public int getMaxWait() {
		return maxWait;
	}


	public void setMaxWait(int maxWait) {
		this.maxWait = maxWait;
	}


	public int getMaxWaitThreadCount() {
		return maxWaitThreadCount;
	}


	public void setMaxWaitThreadCount(int maxWaitThreadCount) {
		this.maxWaitThreadCount = maxWaitThreadCount;
	}


	public int getPoolPreparedStatements() {
		return poolPreparedStatements;
	}


	public void setPoolPreparedStatements(int poolPreparedStatements) {
		this.poolPreparedStatements = poolPreparedStatements;
	}


	public int getMaxPoolPreparedStatementsPerConnectionSize() {
		return maxPoolPreparedStatementsPerConnectionSize;
	}


	public void setMaxPoolPreparedStatementsPerConnectionSize(
			int maxPoolPreparedStatementsPerConnectionSize) {
		this.maxPoolPreparedStatementsPerConnectionSize = maxPoolPreparedStatementsPerConnectionSize;
	}


	public int getMinEvictableIdleTimeMillis() {
		return minEvictableIdleTimeMillis;
	}


	public void setMinEvictableIdleTimeMillis(int minEvictableIdleTimeMillis) {
		this.minEvictableIdleTimeMillis = minEvictableIdleTimeMillis;
	}


	public int getMaxEvictableIdleTimeMillis() {
		return maxEvictableIdleTimeMillis;
	}


	public void setMaxEvictableIdleTimeMillis(int maxEvictableIdleTimeMillis) {
		this.maxEvictableIdleTimeMillis = maxEvictableIdleTimeMillis;
	}


	public int getLogDifferentThread() {
		return logDifferentThread;
	}


	public void setLogDifferentThread(int logDifferentThread) {
		this.logDifferentThread = logDifferentThread;
	}


	public int getRecycleErrorCount() {
		return recycleErrorCount;
	}


	public void setRecycleErrorCount(int recycleErrorCount) {
		this.recycleErrorCount = recycleErrorCount;
	}


	public int getPreparedStatementOpenCount() {
		return preparedStatementOpenCount;
	}


	public void setPreparedStatementOpenCount(int preparedStatementOpenCount) {
		this.preparedStatementOpenCount = preparedStatementOpenCount;
	}


	public int getPreparedStatementClosedCount() {
		return preparedStatementClosedCount;
	}


	public void setPreparedStatementClosedCount(int preparedStatementClosedCount) {
		this.preparedStatementClosedCount = preparedStatementClosedCount;
	}


	public boolean isUseUnfairLock() {
		return useUnfairLock;
	}


	public void setUseUnfairLock(boolean useUnfairLock) {
		this.useUnfairLock = useUnfairLock;
	}


	public boolean isInitGlobalvariants() {
		return initGlobalvariants;
	}


	public void setInitGlobalvariants(boolean initGlobalvariants) {
		this.initGlobalvariants = initGlobalvariants;
	}


	public boolean isInitVariants() {
		return initVariants;
	}


	public void setInitVariants(boolean initVariants) {
		this.initVariants = initVariants;
	}



	public int getStatus() {
		return status;
	}



	public void setStatus(int status) {
		this.status = status;
	}



	
    
}
