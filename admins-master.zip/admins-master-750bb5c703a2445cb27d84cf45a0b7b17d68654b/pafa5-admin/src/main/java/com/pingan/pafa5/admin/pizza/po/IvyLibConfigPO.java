package com.pingan.pafa5.admin.pizza.po;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.pingan.pafa5.admin.commons.BasePO;

/**
 * @see Ivy仓库配置文件持久层对象
 * @author JIECHANGKE805
 * @since 2016-05-23
 */
@Document
public class IvyLibConfigPO extends BasePO {

	@org.springframework.data.annotation.Id
	private String id;

	@Indexed
	private String projectId;

	private String projectName;

	private String group;

	/**
	 * org#module#version.jar
	 */
	private String key;

	private String uuid;

	/**
	 * ivy.xml的二进制串
	 */
	private String ivyByteValue;

	private String ivySha1;

	private String jarSha1;

	private String org;

	private String module;

	private String version;

	private boolean override;

	private String fileName;

	/**
	 * 上传文件
	 */
	private CommonsMultipartFile upload;

	private long valueSize;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getIvyByteValue() {
		return ivyByteValue;
	}

	public void setIvyByteValue(String ivyByteValue) {
		this.ivyByteValue = ivyByteValue;
	}

	public String getIvySha1() {
		return ivySha1;
	}

	public void setIvySha1(String ivySha1) {
		this.ivySha1 = ivySha1;
	}

	public String getJarSha1() {
		return jarSha1;
	}

	public void setJarSha1(String jarSha1) {
		this.jarSha1 = jarSha1;
	}

	public String getOrg() {
		return org;
	}

	public void setOrg(String org) {
		this.org = org;
	}

	public String getModule() {
		return module;
	}

	public void setModule(String module) {
		this.module = module;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public boolean isOverride() {
		return override;
	}

	public void setOverride(boolean override) {
		this.override = override;
	}

	public String getFileName() {
		return fileName;
	}

	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

	public CommonsMultipartFile getUpload() {
		return upload;
	}

	public void setUpload(CommonsMultipartFile upload) {
		this.upload = upload;
	}

	public long getValueSize() {
		return valueSize;
	}

	public void setValueSize(long valueSize) {
		this.valueSize = valueSize;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
}
