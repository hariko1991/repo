package com.pingan.pafa5.admin.pizza.dao;

import java.util.List;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSearchDTO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigPO;

/**
 * 当前配置操作
 * 
 * @author EX-YANGSHENGXIANG001
 */
public interface PizzaConfigDAO {

	PizzaConfigPO add(PizzaConfigPO po);

	boolean del(String group, String key);

	boolean update(PizzaConfigPO po);

	long checkCount(String projectId);

	PizzaConfigPO isMD5Exist(String projectId, String md5);

	List<PizzaConfigPO> listMD5Exist(String projectId, String md5, String group);

	List<String> listKeys(String group);

	List<String> listKeys(String group, String pizzaKeyRegex);

	List<String> listKeysByProId(String projectId, String group,
			String pizzaKeyRegex);

	boolean exist(String pizzaGroup, String pizzaKey);

	PizzaConfigPO get(String group, String key);

	PageDataDTO<PizzaConfigPO> pageQuery(ConfigSearchDTO queryDTO);

	List<PizzaConfigPO> getPizzaKey(String pizzaGroup);

	List<PizzaConfigPO> query(String group, String regexKey, String pattern);

	List<PizzaConfigPO> queryByGroup(String group);

	public List<PizzaConfigPO> queryAll();

	PizzaConfigPO getByProperty(String propertyName, Object propertyValue);

	boolean addProject(PizzaConfigPO po);

	List<String> listKeys(String proId, String group, String pizzaKeyRegex);

	boolean exist(String projectId, String group, String pizzaKey);

	PizzaConfigPO get(String proId, String group, String key);

	boolean del(String proId, String group, String key);

	List<PizzaConfigPO> queryAllByProject(String proId);

	List<PizzaConfigPO> getPizzaKey(String proId, String pizzaGroup);

	List<PizzaConfigPO> query(String projectId, String group, String regexKey,
			String pattern);

}
