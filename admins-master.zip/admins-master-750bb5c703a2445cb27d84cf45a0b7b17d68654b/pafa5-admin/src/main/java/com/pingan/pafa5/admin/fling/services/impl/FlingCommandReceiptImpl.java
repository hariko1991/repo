package com.pingan.pafa5.admin.fling.services.impl;

import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.fling.FlingCommandReceiptor;
import com.pingan.pafa.fling.msg.FlingCommandMsg;
import com.pingan.pafa.fling.msg.FlingReceiptMsg;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.fling.dao.FlingCommandResultDAO;
import com.pingan.pafa5.admin.fling.dao.FlingPappInstanceDAO;
import com.pingan.pafa5.admin.fling.dao.FlingSARInstanceDAO;
import com.pingan.pafa5.admin.fling.dao.FlingWarnDAO;
import com.pingan.pafa5.admin.fling.po.FlingCommandResultPO;
import com.pingan.pafa5.admin.fling.po.FlingPappInstancePO;
import com.pingan.pafa5.admin.fling.po.FlingSARInstancePO;
import com.pingan.pafa5.admin.fling.po.FlingWarnPO;

/**
 * 指令执行结果处理
 * 
 * @author EX-YANGSHENGXIANG001
 */
@Service("flingCommandReceipt")
public class FlingCommandReceiptImpl extends BaseServices implements FlingCommandReceiptor {

    private Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    private FlingCommandResultDAO flingCommandResultDAO;

    @Autowired
    private FlingPappInstanceDAO flingPappInstanceDAO;

    @Autowired
    private FlingSARInstanceDAO flingSARInstanceDAO;

    @Autowired
    private FlingWarnDAO flingWarnDAO;

    // 指令执行结果处理
    public void receipt(FlingReceiptMsg receiptMsg) {
        if (logger.isInfoEnabled()) {
            logger.info("回执，receiptDate=" + new Date(receiptMsg.getReceiptDate()) + ",id="
                    + receiptMsg.getRid() + ",instanceIp=" + receiptMsg.getInstanceIp());
            logger.info("Admin receipted Json : " + JSON.toJSON(receiptMsg));
        }
        FlingCommandResultPO po = new FlingCommandResultPO();
        POUtils.copyProperties(po, receiptMsg);
        po.setUpdatedBy("FlingCommandReceipt");
        po.setCreatedDate(new Date());
        flingCommandResultDAO.add(po);
        String targetType = receiptMsg.getTargetType();
        if (FlingCommandMsg.TARGET_TYPE_SAR.equals(targetType)) {
            handleForSAR(receiptMsg);
        } else {
            handleForPapp(receiptMsg);
        }
    }

    protected void handleForPapp(FlingReceiptMsg msg) {
        String actionType = msg.getActionType();
        int status = -1;
        if (FlingCommandMsg.ACTION_TYPE_SHUTDOWN.equals(actionType) && FlingReceiptMsg.RCODE_SUCCESS.equals(msg.getResponseCode())) {
            status = 1;
        } else {
            if (FlingReceiptMsg.RCODE_SUCCESS.equals(msg.getResponseCode())) {
                status = 0;
            } else if (FlingReceiptMsg.RCODE_FATAL_ERROR.equals(msg.getResponseCode()) || FlingReceiptMsg.RCODE_APP_CMD_FAILURE.equals(msg.getResponseCode())) {
                status = 2;
                
            }
            
        }
        if (status != -1) {
            upsetPappInstance(msg, status);
            if (status == 2) {
                String warnDescription = "应用：" + msg.getPappName() + "执行指令：" + msg.getActionType()
                        + "发生错误，原因：" + msg.getResponseMsg();
                sendWarn(msg, warnDescription);
            }
        }
    }

    protected void handleForSAR(FlingReceiptMsg msg) {
        String actionType = msg.getActionType();
        int status = -1;
        if (FlingCommandMsg.ACTION_TYPE_SHUTDOWN.equals(actionType) && FlingReceiptMsg.RCODE_SUCCESS.equals(msg.getResponseCode())) {
            status = 1;
        } else {
            if (FlingReceiptMsg.RCODE_SUCCESS.equals(msg.getResponseCode())) {
                status = 0;
            } else if (FlingReceiptMsg.RCODE_FATAL_ERROR.equals(msg.getResponseCode())|| FlingReceiptMsg.RCODE_SAR_CMD_FAILURE.equals(msg.getResponseCode())) {
                status = 2;
            }
        }
        if (status != -1) {
            upsetSARInstance(msg, status);
            if (status == 0) {
                upsetPappInstance(msg, status);
            }
            if (status == 2) {
                String warnDescription = "组件：" + msg.getSarName() + "执行指令：" + msg.getActionType()
                        + "发生错误，原因：" + msg.getResponseMsg();
                sendWarn(msg, warnDescription);
            }
        }
    }

    protected void sendWarn(FlingReceiptMsg msg, String warnDescription) {
        FlingWarnPO po = new FlingWarnPO();
        if (StringUtils.isNotEmpty(msg.getDomainId())) {
        	po.setProjectId(msg.getDomainId());
        } else if (StringUtils.isNotEmpty(msg.getProjectId())) {
        	po.setProjectId(msg.getProjectId());
        }
        po.setAppName(msg.getPappName());
        po.setBizRequestId(null);
        po.setCreatedTimestamp(System.currentTimeMillis());
        po.setInstanceIp(msg.getInstanceIp());
        po.setWarnSource("FlingCommand-" + msg.getActionType());
        po.setDescription(warnDescription);
        po.setSarName(msg.getSarName());
        flingWarnDAO.add(po);
    }

    protected void upsetSARInstance(FlingReceiptMsg msg, int status) {
        FlingSARInstancePO po = new FlingSARInstancePO();
        if (StringUtils.isNotEmpty(msg.getDomainId())) {
        	po.setProjectId(msg.getDomainId());
        } else if (StringUtils.isNotEmpty(msg.getProjectId())) {
        	po.setProjectId(msg.getProjectId());
        }
        po.setSarName(msg.getSarName());
        po.setAppName(msg.getPappName());
        po.setInstanceIp(msg.getInstanceIp());

        po.setStatus(status);
        POUtils.setForUpdate("FlingCommand-" + msg.getActionType(), po);
        po.setLastActiveTimestamp(po.getUpdatedDate().getTime());
        // po.setLastActiveObjectId(msg.getRid());
        flingSARInstanceDAO.upset(po);
    }

    protected void upsetPappInstance(FlingReceiptMsg msg, int status) {
        FlingPappInstancePO po = new FlingPappInstancePO();
        if (StringUtils.isNotEmpty(msg.getDomainId())) {
        	po.setProjectId(msg.getDomainId());
        } else if (StringUtils.isNotEmpty(msg.getProjectId())) {
        	po.setProjectId(msg.getProjectId());
        }
        po.setProjectId(msg.getProjectId());
        po.setAppName(msg.getPappName());
        po.setInstanceIp(msg.getInstanceIp());

        po.setStatus(status);
        POUtils.setForUpdate("FlingCommand-" + msg.getActionType(), po);
        po.setLastActiveTimestamp(po.getUpdatedDate().getTime());
        // po.setLastActiveObjectId(msg.getRid());

        logger.info("Before upsetPappInstance : " + JSON.toJSONString(msg));

        flingPappInstanceDAO.upset(po);
    }

    public void setFlingCommandResultDAO(FlingCommandResultDAO flingCommandResultDAO) {
        this.flingCommandResultDAO = flingCommandResultDAO;
    }

    public void setFlingPappInstanceDAO(FlingPappInstanceDAO flingPappInstanceDAO) {
        this.flingPappInstanceDAO = flingPappInstanceDAO;
    }

    public void setFlingSARInstanceDAO(FlingSARInstanceDAO flingSARInstanceDAO) {
        this.flingSARInstanceDAO = flingSARInstanceDAO;
    }

    public void setFlingWarnDAO(FlingWarnDAO flingWarnDAO) {
        this.flingWarnDAO = flingWarnDAO;
    }

}
