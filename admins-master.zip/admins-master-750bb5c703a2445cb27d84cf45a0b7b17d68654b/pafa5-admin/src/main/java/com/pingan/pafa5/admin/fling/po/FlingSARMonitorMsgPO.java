package com.pingan.pafa5.admin.fling.po;

import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import com.pingan.pafa5.admin.commons.BasePO;

/**
 * 组件监控信息
 * 
 * @author JIECHANGKE805
 * 
 */
@Document
@CompoundIndexes({
    @CompoundIndex(name = "def_index", def = "{sarName : 1, instanceIp : 1, createdTimestamp:1}")
})
public class FlingSARMonitorMsgPO extends BasePO {

    /**
     * 记录ID
     */
    @org.springframework.data.annotation.Id
    private String msgId;

    /***
     * 组件名
     */
    private String sarName;

    /**
     * 实例IP
     */
    private String instanceIp;

    /**
     * 创建时间(即admin服务端时间)
     */
    private long createdTimestamp;

    /**
     * 事件发生时间
     */
    private String eventName;

    /***
     * 应用名
     */
    private String appName;

    /**
     * 事件时间(客户端时间)
     */
    private long eventTimestamp;


    /**
     * 实例名
     */
    private String instanceName;

    /**
     * 业务系统请求ID
     */
    private String bizRequestId;

    public String getMsgId() {
        return msgId;
    }

    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getInstanceIp() {
        return instanceIp;
    }

    public void setInstanceIp(String instanceIp) {
        this.instanceIp = instanceIp;
    }



    public String getEventName() {
        return eventName;
    }

    public void setEventName(String eventName) {
        this.eventName = eventName;
    }

    public long getEventTimestamp() {
        return eventTimestamp;
    }

    public void setEventTimestamp(long eventTimestamp) {
        this.eventTimestamp = eventTimestamp;
    }


    public long getCreatedTimestamp() {
        return createdTimestamp;
    }

    public void setCreatedTimestamp(long createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    public String getSarName() {
        return sarName;
    }

    public void setSarName(String sarName) {
        this.sarName = sarName;
    }

    public String getInstanceName() {
        return instanceName;
    }

    public void setInstanceName(String instanceName) {
        this.instanceName = instanceName;
    }

    public String getBizRequestId() {
        return bizRequestId;
    }

    public void setBizRequestId(String bizRequestId) {
        this.bizRequestId = bizRequestId;
    }

}
