package com.pingan.pafa5.admin.pizza.web;

import java.io.IOException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.validator.annotation.Valid;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa.pizza.classloader.ClasspathResourceKey;
import com.pingan.pafa.pizza.classloader.PizzaURL;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.commons.SARManagerConstants;
import com.pingan.pafa5.admin.pizza.dto.ResourceFileDTO;
import com.pingan.pafa5.admin.pizza.dto.ResourceUploadDTO;
import com.pingan.pafa5.admin.pizza.services.ResourcesManangerService;
import com.pingan.pafa5.admin.pizza.utils.ConfigContentUtils;

@Controller
@RequestMapping("/pizzamgr")
public class ResourcesManangerController extends BaseController {

	@Autowired
	private ConfigContentUtils configContentUtils;

	@Autowired
	private ResourcesManangerService resourcesManangerService;

	@ActionClient(name = "pafa5-admin-systems.isOwner")
	private IServiceClient ownerService;

	@RequestMapping("/resource-list.do")
	@ResponseBody
	public ModelMap list(
			@RequestParam(value = "projectId", required = true) String proId,
			@RequestParam(value = "sarName") String sarName,
			@RequestParam(value = "limit", required = true, defaultValue = "30") int limit,
			@RequestParam(value = "page", required = true, defaultValue = "1") int page) {
		ModelMap model = new ResponseModel();
		if (limit > 100 || limit <= 0) {
			limit = 30;
		}
		PageDataDTO<ResourceFileDTO> dtos = resourcesManangerService.list(proId, sarName, limit, page);
		model.put("datas", dtos.getDatas());
		model.put("size", dtos.getTotalSize());

		return model;
	}

	@RequestMapping("/resource-delete.do")
	@ResponseBody
	public ModelMap delete(
			@RequestParam(value = "domainId", required = true) String domainId,
			@RequestParam(value = "sarName", required = true) String sarName,
			@RequestParam(value = "fileName", required = true) String fileName) {
		isOwner(domainId);

		ModelMap model = new ResponseModel();
		boolean success = resourcesManangerService.delete(domainId, sarName
				+ "#" + fileName);
		model.put("success", success);
		model.put("msg", "删除成功");
		return model;
	}

	@RequestMapping("/resource-upload.do")
	// 组件资源文件Resource上传
	@ResponseBody
	public ModelMap upload(@Valid ResourceUploadDTO form) throws Throwable {
		isOwner(form.getProjectId());

		// 文件最大值 3145728
		int maxSize = configContentUtils.getMaxSize();
		form.setSize(form.getFileUpload().getSize());
		if (maxSize > 0 && form.getFileUpload().getSize() > maxSize) {
			return new ResponseModel("40040", "上传文件大小="
					+ (form.getFileUpload().getSize() / 1024) + "KB，超过限制大小="
					+ (maxSize / 1024) + "KB.");
		}

		String resourceName = form.getResourceName();
		if (resourceName == null || resourceName.length() == 0) {
			resourceName = form.getFileUpload().getOriginalFilename();
		}
		if (resourceName == null
				|| (resourceName = resourceName.trim()).length() == 0) {
			throw new NullPointerException("resourceName is null");
		}
		if (regexChinese(resourceName)) {
			ResponseModel model = new ResponseModel("9", "上传失败，配置文件名称不能存在汉字");
			model.put("success", false);
			return model;
		}
		String msg = "";
		if (resourceName.length() > 250) {
			msg = "上传文件名过长！";
			ResponseModel map = new ResponseModel();
			map.put("success", false);
			map.setResponseMsg(msg);
			return map;
		}
		byte[] datas = form.getFileUpload().getBytes();
		form.setResourceName(resourceName);
		ClasspathResourceKey _key = ClasspathResourceKey.valueOf(form.getSarName(), resourceName);
		PizzaURL pizzaURL = _key.toPizzaURL();

		String content = null;
		if (logger.isInfoEnabled()) {
			logger.info("pizzaURL=" + pizzaURL);
		}
		try {
			String group = pizzaURL.getPizzaGroup();
			String key = pizzaURL.getPizzaKey();
			content = configContentUtils.encodeContent(group, key, datas);

			int result = resourcesManangerService.putPizza(_key, form, content);

			if (result == 0) {
				ModelMap model = new ResponseModel("0", "上传成功");
				model.put("success", true);
				return model;
			} else if (result == 1) {
				ModelMap model = new ResponseModel("1", "配置文件未变化");
				model.put("success", true);
				return model;
			} else {
				ModelMap model = new ResponseModel("9", "上传失败");
				model.put("success", false);
				return model;
			}
		} catch (ResponseCodeException ex) {
			ModelMap model = new ResponseModel("4000", ex.getMessage());
			model.put("success", false);
			return model;
		}
	}

	@RequestMapping("/resource-view.do")
	public ModelMap view(HttpServletResponse response,
			@RequestParam(value = "id", required = true) String id,
			@RequestParam(value = "projectId", required = true) String proId) {
		String msg = null;
		ServletOutputStream sos = null;
		try {
			String pizzKey = id.replace("|", "#");
			response.setCharacterEncoding("utf-8");
			String fileName = pizzKey.split("#")[1];
			byte[] content = resourcesManangerService.getFileContent(proId,
					pizzKey);
			if (content == null || content.length == 0) {
				msg = "配置为空";
			} else {
				response.setContentType("application/x-zip-compressed");
				response.addHeader("Content-Disposition",
						"attachment;filename=" + fileName);
				sos = response.getOutputStream();
				sos.write(content);
				sos.flush();
				sos.close();
				return null;
			}
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			if (sos != null) {
				try {
					sos.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
			}
		}
		ModelMap model = new ResponseModel();
		model.put("resultCode", "error");
		model.put("errorMsg", msg);
		model.put("success", true);
		return model;
	}

	private boolean regexChinese(String str) {
		String regex = "[\\u4e00-\\u9fa5]";
		Pattern pattern = Pattern.compile(regex, Pattern.UNICODE_CASE);
		Matcher matcher = pattern.matcher(str);
		return matcher.find();
	}

	public void isOwner(String domainId) {
		if (domainId == null || SARManagerConstants.DEF.equalsIgnoreCase(domainId)) {
			return;
		}
		ServiceParams params = new ServiceParams();
		params.set("groupId", domainId);
		ServiceResults results = ownerService.invoke(params);
		boolean isBoo = results.getBool("isowner");
		if (!isBoo) {
			throw new ResponseCodeException("354", "对不起，你不是领域负责人，没有此操作权限");
		}
	}

	public void setConfigContentUtils(ConfigContentUtils configContentUtils) {
		this.configContentUtils = configContentUtils;
	}

	public void setResourcesManangerService(
			ResourcesManangerService resourcesManangerService) {
		this.resourcesManangerService = resourcesManangerService;
	}

	public void setOwnerService(IServiceClient ownerService) {
		this.ownerService = ownerService;
	}

}
