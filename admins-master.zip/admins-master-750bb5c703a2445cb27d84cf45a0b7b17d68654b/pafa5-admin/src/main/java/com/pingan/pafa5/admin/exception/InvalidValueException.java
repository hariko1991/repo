package com.pingan.pafa5.admin.exception;

/**
 * 内容不正确异常
 * 
 * @author SHICHENGCHENG316
 * 
 */
public class InvalidValueException extends RuntimeException {

	private static final long serialVersionUID = 1L;

	public InvalidValueException() {
		super();
	}

	public InvalidValueException(String message) {
		super(message);
	}

}
