package com.pingan.pafa5.admin.pizza.dao;

import com.pingan.pafa5.admin.pizza.po.EnvSyncFailurePO;

import java.util.List;

/**
 * Created by ZHANGWENZHUO810 on 2016-11-16.
 */
public interface EnvSyncFailureDAO {
    
	public void add(EnvSyncFailurePO po);

	public List<EnvSyncFailurePO> list(String syncId);
	
}
