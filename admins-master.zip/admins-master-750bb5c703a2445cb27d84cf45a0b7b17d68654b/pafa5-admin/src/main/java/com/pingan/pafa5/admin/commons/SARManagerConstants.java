package com.pingan.pafa5.admin.commons;

public interface SARManagerConstants {
	String RESPONSECODE_ZERO = "0";
	String RESPONSECODE_ONE = "1";
	boolean RESULT_FALSE = false;
	int NUM_ZERO = 0;
	int NUM_ONE =1;
	int NUM_TWO = 2;
	
	//基包
	String KEY_BASE_PACKAGE="sar.base.package";
	//是否支持web请求
	String KEY_ENABLE_WEB="sar.web.enable";
	//处理web请求的优先级
	String KEY_ORDER="sar.order";
	//是否启用ibatis
	String KEY_ENABLE_IBATIS="sar.ibatis.enable";
	//是否启用quartz
	String KEY_ENABLE_QUARTZ="sar.quartz.enable";
	//是否启用IVY仓库
	String KEY_ENABLE_IVY="sar.ivy.enable";
	//引用数据源KEY
	String KEY_DATASOURCE_KEY="sar.datasource.key";
	//组件包
	String KEY_LIB_KEY="sar.lib";
	//是否启用DB事务支持
	String KEY_TRANSACTION_ENABLE="sar.transaction.enable";
	
	String SLASH = "/";
	String PROJECT_NAME = "pafa5_sample_helloworld";
	String PROJECT_SUFFIX = "/.project";
	String BUILD_PROPERTIES_NAME = "/build.properties";
	String BUILD_XML_NAME = "/build.xml";
	String PROPERTIES_SUFFIX = ".properties";
	String IVY_NAME = "/ivy.xml";
	String SOURCE_CATALOG = "/src/main/java/com/pingan/pafa5/sample/helloworld";
	String TEMP_CATALOG= "/src/main/java/temp";
	String SOURCE_PATH = "/src/main/java";
	String TEST_SOURCE_CATALOG = "/src/test/java/com/pingan/pafa5/sample/helloworld";
	String TEST_TEMP_CATALOG= "/src/test/java/temp";
	String TEST_SOURCE_PATH = "/src/test/java";
	String TEST_RESOURCE_PATH = "/src/test/resources";
	String PIZZA_PROPERTIES = "/src/test/resources/pizza.properties";
	String ZIP_SUFFIX = ".zip";
	String SAR_PATH = "/sar/";
	
	String ATTR_NAME_PROJECT = "project";
	String ATTR_NAME = "name";
	String ATTR_NAME_INFO = "info";
	String ATTR_NAME_ORGANISATION = "organisation";
	String ATTR_NAME_MODULE = "module";
	String ATTR_NAME_REVISION = "revision";
	String ATTR_VALUE_REVISION = "1.0.0";
	String ATTR_NAME_ARTIFACT = "artifact";
	String ATTR_NAME_SOURPATH = "sourPath";
	String ATTR_NAME_DESPATH = "desPath";
	String ATTR_NAME_FILEPATH = "filePath";
	String ATTR_NAME_BASEPACKAGE = "basePackage";
	
	String DEPLOY_PIZZADIR ="pafa5.deploy.pizzadir";
	String PIZZA_MANAGER = "pizza.manager";
	String SOURCE_PACKAGE = "com.pingan.pafa5.sample.helloworld";
	
	String WRAP = "\n";
	String SIGN = "=";

	String DEF = "def";
}
