package com.pingan.pafa5.admin.pizza.web;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.validator.annotation.Valid;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa.pizza.classloader.PizzaURL;
import com.pingan.pafa5.admin.Constants;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.PizzaConstants.ConfigHistoryOperationType;
import com.pingan.pafa5.admin.pizza.dao.IvyLibConfigDAO;
import com.pingan.pafa5.admin.pizza.dao.PizzaConfigDAO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSaveDTO;
import com.pingan.pafa5.admin.pizza.dto.IvyLibConfigDTO;
import com.pingan.pafa5.admin.pizza.dto.IvyLibSearchDTO;
import com.pingan.pafa5.admin.pizza.po.FileTempPO;
import com.pingan.pafa5.admin.pizza.po.IvyLibConfigPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigPO;
import com.pingan.pafa5.admin.pizza.services.LibManagerService;
import com.pingan.pafa5.admin.pizza.services.PizzaConfigServices;
import com.pingan.pafa5.admin.pizza.utils.ConfigContentUtils;
import com.pingan.pafa5.admin.sso.UserPrincipal;
import com.pingan.um.client.util.StringUtil;

/**
 * @see pizza lib仓库实现请求入口
 * @author JIECHANGKE805
 * @since 2016-05-03
 */
@Controller
@RequestMapping("/libs")
public class PizzaLibController extends BaseController {

    @Autowired
    private LibManagerService libManager;

    @Autowired
    private PizzaConfigServices pizzaConfigServices;

    @Autowired
    private ConfigContentUtils configContentUtils;

    @Autowired
    private IvyLibConfigDAO ivyConfigDAO;

    @Autowired
    private PizzaConfigDAO pizzaConfigDAO;
    
    private static final Pattern PATTERN = Pattern.compile("[\u4e00-\u9fa5]");

    /**
     * @see 上传依赖包到仓库 
     * @author JIECHANGKE805
     * @since 2016年6月12日
     * @param
     */
    @RequestMapping("/uploadJarFile.do")
    @ResponseBody
    public ResponseModel uploadIvyLib(@Valid IvyLibConfigDTO form) {
    	
        int maxSize = configContentUtils.getMaxSize();
        String msg = "";
        if (maxSize > 0 && form.getUpload().getSize() > maxSize) {
            msg = "上传文件大小=" + (form.getUpload().getSize() / 1024) + "KB，超过限制大小=" + (maxSize / 1024)
                    + "KB.";
            ResponseModel map = new ResponseModel();
            map.put("success", false);
            map.setResponseMsg(msg);
            return map;
        }
        
        if(checkValid(form.getModule())){
			ResponseModel model = new ResponseModel("2410","模块："+form.getModule()+" 不合法，不能含有中文。");
			model.put("success", false);
			return model;
		}
		
		if(checkValid(form.getOrg())){
			ResponseModel model = new ResponseModel("2411","组织："+form.getOrg()+" 不合法，不能含有中文。");
			model.put("success", false);
			return model;
		}
        
        String fileName =form.getFileName();
        if(StringUtil.isEmpty(fileName)||"".equals(fileName.trim())){
        	fileName=form.getUpload().getOriginalFilename();
        }
        String org = form.getOrg();
        String version = form.getVersion();
        String module = form.getModule();
        if (StringUtil.isEmpty(org)||StringUtil.isEmpty(module)
        		||StringUtil.isEmpty(version)||StringUtil.isEmpty(fileName)) {
			throw new NullPointerException("org,module,version,fileName 配置不能为空！");
        }
        if(org.length()>250||module.length()>250||version.length()>250||fileName.length()>250){
        	msg="org,module,version太长!";
        	ResponseModel map = new ResponseModel();
            map.put("success", false);
            map.setResponseMsg(msg);
            return map;        	
        }
        	
        int lastIndexOf = fileName.lastIndexOf(".");
        if(lastIndexOf==-1){
        	++lastIndexOf;
        }
        String ext = fileName.substring(lastIndexOf);
        if (!Constants.FILE_TYPE_JAR.equals(ext.substring(1))) {
            msg = "上传文件格式错误，请检查。";
            ResponseModel map = new ResponseModel();
            map.put("success", false);
            map.setResponseMsg(msg);
            return map;
        }

        String key = "";
        key = form.getOrg().concat("#").concat(form.getModule()).concat("#").concat(form.getVersion()).concat(ext);
        key = key.replace("#unknown", "").replace("unknown#", "");
        PizzaURL.valueOf(Constants.LIB_GROUP, key);

        String projectId = form.getProjectId();
        IvyLibConfigPO po = ivyConfigDAO.find(projectId, Constants.LIB_GROUP, key);
//        加上原始文件名到pizzaConfig表中 检查是否存在
        
        // 如果是新增，不允许key重复，如果是编辑，key重复则覆盖jar
        if (po != null && !form.isEdit()) {
            msg = "jar包 " + (po.getOrg() + "/" + po.getModule() + "/" + po.getVersion() + "已存在 。");
        }

        byte[] bytes = form.getUpload().getBytes();
        String value = configContentUtils.encodeContent(Constants.LIB_GROUP, null, bytes);

        String valueMd5 = configContentUtils.md5(value);
//		dao层应该在service
        PizzaConfigPO pizzaPO = pizzaConfigDAO.isMD5Exist(projectId, valueMd5);
        if (pizzaPO != null && Constants.LIB_GROUP.equals(pizzaPO.getPizzaGroup())) {
            String pathKey = pizzaPO.getPizzaKey();
            msg = "依赖包已存在,配置(org/module/version)为 ： "
                    + pathKey.replace("#", "/").substring(0, pathKey.lastIndexOf("."));
        }

        String content = Base64.encodeBase64String(form.getUpload().getBytes());
        String uuid = pizzaConfigServices.saveFileTemp(content);

        ResponseModel map = new ResponseModel();
        if (msg.equals("")) {
            map.put("key", key);
            map.put("uuid", uuid);
            map.put("fileName", fileName);
            map.put("valueSize", form.getUpload().getSize());
            map.put("success", true);
            map.setResponseMsg("上传成功！");
        } else {
            map.put("success", false);
            map.setResponseMsg(msg);
        }
        return map;
    }

    /**
     * @see 保存依赖包仓库上传的jar文件
     * @author JIECHANGKE805
     * @since 2016年5月25日
     * @param
     */
    @RequestMapping("/saveUploadLib.do")
    @ResponseBody
    public ResponseModel saveUploadIvyLib(@Valid IvyLibConfigDTO form) throws Exception{

        PizzaURL url = PizzaURL.valueOf(Constants.LIB_GROUP, form.getKey());
        String group = url.getPizzaGroup();
        String key = url.getPizzaKey();
        String projectId = form.getProjectId();
        // 键值是否已存在
        boolean keyExist = pizzaConfigServices.checkExists(projectId, group, key);
        if (keyExist && !form.isEdit()) {
            ResponseModel map = new ResponseModel();
            map.put("success", false);
            map.setResponseMsg("配置键已经存在，请更换");
            return map;
        }
        String uuid = form.getUuid();
        FileTempPO filePO = pizzaConfigServices.getFileTempById(uuid);

        try {
            configContentUtils.checkContent(group, key, filePO.getBytes());
        } catch (ResponseCodeException ex) {
            ResponseModel model = new ResponseModel(ex.getResponseCode());
            model.put("success", false);
            model.setResponseMsg(ex.getMessage());
            return model;
        }

        ConfigSaveDTO configDTO = new ConfigSaveDTO();
        configDTO.setProjectId(projectId);
        configDTO.setGroup(Constants.LIB_GROUP);
        configDTO.setKey(key);
        configDTO.setValue(filePO.getBytes());

        int resultCode = pizzaConfigServices.save(configDTO);
        if (resultCode == 0 || resultCode == 1) {
            if (uuid != null && !"".equals(uuid)) {
                pizzaConfigServices.delFileTempById(uuid);
            }
        } else {
            ResponseModel model = new ResponseModel();
            model.put("success", false);
            model.setResponseMsg("保存失败，系统错误或者配置中心访问错误。");
            return model;
        }
        ResponseModel model = new ResponseModel();
        model.put("success", true);
        model.setResponseMsg("保存成功！");

        return model;
    }

    /**
     * @see 查询ivy依赖包列表
     * @author JIECHANGKE805
     * @since 2016年5月25日
     * @param 表单查询字段
     */
    @RequestMapping("/queryIvyLib.do")
    @ResponseBody
    public ResponseModel searchIvyList(@Valid IvyLibSearchDTO form) {
        PageDataDTO<IvyLibConfigPO> pageDatas = libManager.searchIvyLib(form);

        List<IvyLibConfigPO> ivyLibPOList = pageDatas.getDatas();
        List<IvyLibConfigDTO> ivyLibDTOList = new ArrayList<IvyLibConfigDTO>();

        if (CollectionUtils.isNotEmpty(ivyLibPOList)) {
            for (IvyLibConfigPO ivyPO : ivyLibPOList) {
                IvyLibConfigDTO ivyDTO = new IvyLibConfigDTO();
                ivyDTO.setId(ivyPO.getId());
                ivyDTO.setOrg(ivyPO.getOrg());
                ivyDTO.setModule(ivyPO.getModule());
                ivyDTO.setVersion(ivyPO.getVersion());
                ivyDTO.setFileName(ivyPO.getFileName());
                ivyDTO.setValueSize(String.valueOf(ivyPO.getValueSize()));
                ivyDTO.setCreatedBy(ivyPO.getCreatedBy());
                ivyDTO.setCreatedDate(ivyPO.getCreatedDate());
                ivyDTO.setUpdatedBy(ivyPO.getUpdatedBy());
                ivyDTO.setUpdatedDate(ivyPO.getUpdatedDate());

                ivyLibDTOList.add(ivyDTO);
            }
        }

        ResponseModel model = new ResponseModel();
        model.put("success", true);
        model.put("totalProperty", pageDatas.getTotalSize());
        model.put("root", ivyLibDTOList);
        return model;
    }

    /**
     * @see 审批上传的依赖包
     * @author JIECHANGKE805
     * @since 2016年5月27日
     * @param lib的组织 、模块、版本
     */
    @RequestMapping("/approve.do")
    @ResponseBody
    public ResponseModel approveIvyLib(@Valid IvyLibConfigDTO form) {

        String ext = form.getFileName().substring(form.getFileName().lastIndexOf("."));
        String key = form.getOrg().concat("#").concat(form.getModule()).concat("#")
                .concat(form.getVersion()).concat(ext);

        IvyLibConfigPO ivyPO = ivyConfigDAO.find(Constants.LIB_GROUP, key);

        // ivyPO.setStatus(Constants.APPROVED);
        UserPrincipal user = UserPrincipal.get(true);
        POUtils.setForUpdate(user.getUid(), ivyPO);

        if (logger.isInfoEnabled()) {
            logger.info("Approved ivy lib : " + key);
        }
        ivyConfigDAO.update(ivyPO);

        ResponseModel model = new ResponseModel();
        model.put("success", true);
        model.setResponseMsg("审批通过。");

        return model;
    }

    /**
     * @see 删除依赖库中的jar
     * @author JIECHANGKE805
     * @since 2016年5月27日
     * @param key ： jar包的键值
     */
    @RequestMapping("/delIvyLib.do")
    @ResponseBody
    public ResponseModel delIvyLib(@RequestParam("projectId") String projectId,
            @RequestParam("key") String key) {

        String msg = "删除失败。";
        if (pizzaConfigServices.del(projectId, Constants.LIB_GROUP, key)) {
            msg = "删除成功。";
        }

        ResponseModel model = new ResponseModel();
        model.put("success", true);
        model.setResponseMsg(msg);

        return model;
    }

    /**
     * @see 比对上传包与已有包是否重复
     * @author JIECHANGKE805
     * @since 2016年5月27日
     * @param 上传文件的字节数组
     */
    @RequestMapping("/compareIvyLib.do")
    @ResponseBody
    public ResponseModel compareLib(@Valid IvyLibConfigDTO form) {

        byte[] bytes = form.getUpload().getBytes();
        String value = configContentUtils.encodeContent(Constants.LIB_GROUP, null, bytes);

        String valueMd5 = configContentUtils.md5(value);
        if ("def".equals(form.getProjectId())) {
            form.setProjectId(null);
        }
        PizzaConfigPO pizzaPO = pizzaConfigDAO.isMD5Exist(form.getProjectId(), valueMd5);

        ResponseModel model = new ResponseModel();

        if (pizzaPO == null) {
            model.setResponseMsg("依赖库无相同文件。");
        } else {
            String pizzaKey = pizzaPO.getPizzaKey();
            model.setResponseMsg("依赖包已存在,配置(org/module/version)为 ： "
                    + pizzaKey.replace("#", "/").substring(0, pizzaKey.lastIndexOf(".")));
        }

        return model;
    }

    /**
     * @see 通过ANT打包上传jar到pizza lib仓库接口
     * @author JIECHANGKE805
     * @since 2016年5月30日
     * @param org 组织
     * @param module 模块
     * @param version 版本
     * @param bytesValue 上传文件的字节流
     */
    @RequestMapping("/antUpload.do")
    @ResponseBody
    public ResponseModel antUploadLib(@Valid IvyLibConfigDTO form) throws Exception{
        int maxSize = configContentUtils.getMaxSize();
        if (maxSize > 0 && form.getUpload().getSize() > maxSize) {
            ResponseModel map = new ResponseModel("40040");
            map.put("success", false);
            map.setResponseMsg("上传文件大小=" + (form.getUpload().getSize() / 1024) + "KB，超过限制大小="
                    + (maxSize / 1024) + "KB.");
            return map;
        }
        String org = form.getOrg();
        String module = form.getModule();
        String version = form.getVersion();
        String projectId = form.getProjectId();

        String key = org.concat("#").concat(module).concat("#").concat(version).concat(".jar");
        if (logger.isInfoEnabled()) {
            logger.info("Ant upload jar,key is : " + key + " fileSize: "
                    + form.getUpload().getSize() / 1024 + " KB.");
        }

        // 保存jar文件配置信息
        IvyLibConfigPO ivyConfigPO = new IvyLibConfigPO();
        ivyConfigPO.setProjectId(projectId);
        ivyConfigPO.setGroup(Constants.LIB_GROUP);
        ivyConfigPO.setKey(key);
        ivyConfigPO.setId(projectId + "/" + Constants.LIB_GROUP + "/" + key);
        ivyConfigPO.setOrg(org);
        ivyConfigPO.setModule(module);
        ivyConfigPO.setVersion(version);
        ivyConfigPO.setValueSize(form.getUpload().getSize());
        ivyConfigPO.setFileName(module.concat("." + Constants.FILE_TYPE_JAR));

        UserPrincipal user = UserPrincipal.get(true);

        IvyLibConfigPO ivyLibPO = ivyConfigDAO.find(projectId, Constants.LIB_GROUP, key);

        if (ivyLibPO != null && form.isOverride()) {
            ivyConfigPO.setCreatedBy(ivyLibPO.getCreatedBy());
            ivyConfigPO.setCreatedDate(ivyLibPO.getCreatedDate());
            POUtils.setForUpdate(user.getUid(), ivyConfigPO);
            ivyConfigDAO.update(ivyConfigPO);
        } else {
            try {
                POUtils.setForAdd(user.getUid(), ivyConfigPO);
                ivyConfigDAO.add(ivyConfigPO);
            } catch (DuplicateKeyException ex) {
                ResponseModel model = new ResponseModel();
                model.put("success", false);
                model.setResponseMsg("此依赖包已存在，且不允许覆盖，请调整版本号。");
                return model;
            }

        }
        String content = configContentUtils.encodeContent(Constants.LIB_GROUP, key,
                form.getUpload().getBytes());

        ConfigSaveDTO saveForm = new ConfigSaveDTO();
        saveForm.setProjectId(projectId);
        saveForm.setGroup(Constants.LIB_GROUP);
        saveForm.setKey(key);
        saveForm.setValue(content);
        saveForm.setOptype(ConfigHistoryOperationType.IVY_ADD);

        pizzaConfigServices.save(saveForm);

        ResponseModel model = new ResponseModel();
        model.put("success", true);
        model.setResponseMsg("依赖包上传成功。");

        return model;
    }
    public boolean checkValid(String input) {
		return PATTERN.matcher(input).find();
	}
    

}
