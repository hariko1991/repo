package com.pingan.pafa5.admin.monitor.job;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.paic.pafa.job.TimerJob;
import com.pingan.pafa5.admin.monitor.services.DubboMonitorService;

/*
 * 数据清洗，保留7天的数据
 */
@Component
public class MonitorJob {

    private Log logger = LogFactory.getLog(this.getClass());

    @Value("${monitor.clean.job.enable}")
    private boolean cleanEnable;

    @Value("${monitor.calculate.job.enable}")
    private boolean calculateEnable;

    @Autowired
    private DubboMonitorService dubboMonitorService;

    @TimerJob(cronExpression = "${job.ex.monitor.clean.time}")
    public void execute() throws Exception {
        if (cleanEnable) {
            logger.info("开始清洗服务监控数据★★★★★★★★★★★★★★★★★★★★★★★★★★★");
            dubboMonitorService.cleanData();
            logger.info("结束清洗服务监控数据★★★★★★★★★★★★★★★★★★★★★★★★★★★");
        }
    }

    @TimerJob(cronExpression = "${job.ex.monitor.calculate.time}")
    public void calculate() throws Exception {
    	logger.info("calculateEnable="+calculateEnable);
        if (calculateEnable) {
            logger.info("开始计算服务监控数据★★★★★★★★★★★★★★★★★★★★★★★★★★★");
            dubboMonitorService.calculateData();
            logger.info("结束计算服务监控数据★★★★★★★★★★★★★★★★★★★★★★★★★★★");
        }
    }

}
