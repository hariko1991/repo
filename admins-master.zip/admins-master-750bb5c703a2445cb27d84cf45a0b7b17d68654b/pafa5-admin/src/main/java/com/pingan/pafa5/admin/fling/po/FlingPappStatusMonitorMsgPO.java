package com.pingan.pafa5.admin.fling.po;

import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

import com.pingan.pafa5.admin.commons.BasePO;

/**
 * 应用状态监控信息
 * 
 * @author JIECHANGKE805
 * 
 */
@Document
@CompoundIndexes({
    @CompoundIndex(name = "def_index", def = "{appName : 1, instanceIp : 1, createdTimestamp:1}")
})
public class FlingPappStatusMonitorMsgPO extends BasePO {


    /**
     * 记录ID
     */
    @org.springframework.data.annotation.Id
    private String msgId;

    /***
     * 应用名
     */
    private String appName;

    /**
     * 实例IP
     */
    private String instanceIp;

    /**
     * 创建时间(即admin服务端时间)
     */
    private long createdTimestamp;


    /**
     * 进程(JVM)可使用(已分配)内存,单位:MB.
     */
    private int totalMemory;

    /**
     * 进程(JVM)剩余内存,单位:MB.
     */
    private int freeMemory;

    /**
     * 进程(JVM)最大可使用内存,单位:MB.
     */
    private int maxMemory;

    /**
     * 进程(JVM)已用内存,单位:MB
     */
    private int usedMemory;

    /**
     * 进程内CPU平均负载，非准确的参考值，单位：百分比，如：64即64%
     */
    private double jvmCPURatioAverage;

    /**
     * 主机CPU负载，单位：百分比，如：64即64%
     */
    private double hostCPURatio;

    /**
     * 进程(JVM)内开启线程数
     */
    private int threadTotal;

    /**
     * 可用CPU核数
     */
    private int availableProcessors;

    public String getMsgId() {
        return msgId;
    }

    public void setMsgId(String msgId) {
        this.msgId = msgId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getInstanceIp() {
        return instanceIp;
    }

    public void setInstanceIp(String instanceIp) {
        this.instanceIp = instanceIp;
    }

    public long getCreatedTimestamp() {
        return createdTimestamp;
    }

    public void setCreatedTimestamp(long createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    public int getTotalMemory() {
        return totalMemory;
    }

    public void setTotalMemory(int totalMemory) {
        this.totalMemory = totalMemory;
    }

    public int getFreeMemory() {
        return freeMemory;
    }

    public void setFreeMemory(int freeMemory) {
        this.freeMemory = freeMemory;
    }

    public int getMaxMemory() {
        return maxMemory;
    }

    public void setMaxMemory(int maxMemory) {
        this.maxMemory = maxMemory;
    }

    public int getUsedMemory() {
        return usedMemory;
    }

    public void setUsedMemory(int usedMemory) {
        this.usedMemory = usedMemory;
    }

    public double getJvmCPURatioAverage() {
        return jvmCPURatioAverage;
    }

    public void setJvmCPURatioAverage(double jvmCPURatioAverage) {
        this.jvmCPURatioAverage = jvmCPURatioAverage;
    }

    public double getHostCPURatio() {
        return hostCPURatio;
    }

    public void setHostCPURatio(double hostCPURatio) {
        this.hostCPURatio = hostCPURatio;
    }

    public int getThreadTotal() {
        return threadTotal;
    }

    public void setThreadTotal(int threadTotal) {
        this.threadTotal = threadTotal;
    }

    public int getAvailableProcessors() {
        return availableProcessors;
    }

    public void setAvailableProcessors(int availableProcessors) {
        this.availableProcessors = availableProcessors;
    }

}
