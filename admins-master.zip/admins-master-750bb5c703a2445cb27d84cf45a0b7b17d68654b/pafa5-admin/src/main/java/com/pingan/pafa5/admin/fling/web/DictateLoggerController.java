package com.pingan.pafa5.admin.fling.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.fling.dto.DictateLoggerDTO;
import com.pingan.pafa5.admin.fling.services.DictateLoggerService;

@Controller
@RequestMapping("/fling")
public class DictateLoggerController extends BaseController {

    @Autowired
    private DictateLoggerService dictateLoggerService;

    @RequestMapping("/dictate-loggers.do")
    @ResponseBody
    public ResponseModel listForPapp(@RequestParam(value = "limit", defaultValue = "30") int limit,
            @RequestParam(value = "page", defaultValue = "1") int page, 
            @RequestParam(value = "formatDate", defaultValue = "true") boolean formatDate, 
            @RequestParam(value = "projectId") String projectId, 
            @RequestParam(value = "pappName", required = false) String pappName, 
            @RequestParam(value = "sarName", required = false) String sarName) {
        PageDataDTO<DictateLoggerDTO> dtos = dictateLoggerService.list(projectId, pappName, sarName, limit, page);
        ResponseModel model = new ResponseModel();
        model.put("datas", dtos.getDatas());
        model.put("total", dtos.getTotalSize());
        return model;
    }

    /**
     * 显示原因
     * 
     * @param id
     * @param response
     * @return
     * @throws IOException
     */
    @RequestMapping("/get-cause.do")
    @ResponseBody
    public ResponseModel getCause(@RequestParam(value = "id", required = true) String id,
            HttpServletResponse response) throws IOException {
        String cause = dictateLoggerService.getCause(id);
        if (cause != null && !"".equals(cause.trim())) {
            response.setContentType("text/plain;charset=utf-8");
            PrintWriter pw = response.getWriter();
            pw.print(cause);
            pw.flush();
            pw.close();
        }
        return null;
    }

}
