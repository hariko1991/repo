package com.pingan.pafa5.admin.pizza.form;

import com.paic.pafa.validator.annotation.VLength;
import com.paic.pafa.validator.annotation.VNotEmpty;
import com.paic.pafa.validator.annotation.VRegex;

/** 全局变量
 * 
 * @author zhanggang871
 * 
 * <p>
 * 存储格式：global.project.${property}=value
 * </p>
 */
public class GlobalVariableForm {

	private String id;//proId.property
	@VNotEmpty
	private String proId;
	private String proName;
	@VNotEmpty
	@VRegex(value="^[a-zA-Z0-9_\\.\\-]*$", message="变量名只能输入数字和英文字母. _ -")
	@VLength(max=255,min=1)
	private String property;
	@VNotEmpty
	@VLength(max=-1,min=1)
	private String value;
	private String isHidden;
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getProperty() {
		return property;
	}
	public void setProperty(String property) {
		this.property = property;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getProId() {
		return proId;
	}
	public void setProId(String proId) {
		this.proId = proId;
	}
	public String getProName() {
		return proName;
	}
	public void setProName(String proName) {
		this.proName = proName;
	}
	public String getIsHidden() {
		return isHidden;
	}
	public void setIsHidden(String isHidden) {
		this.isHidden = isHidden;
	}
	
}
