package com.pingan.pafa5.admin.fling.dto;

import java.util.List;

import com.pingan.pafa5.admin.fling.po.FlingCommandResultPO;

public class FlingCommandResultsDTO {

    private boolean completed;

    private int instanceSize;

    private List<FlingCommandResultPO> results;

    public FlingCommandResultsDTO(boolean completed, int instanceSize,
            List<FlingCommandResultPO> results) {
        this.completed = completed;
        this.instanceSize = instanceSize;
        this.results = results;
    }

    public boolean isCompleted() {
        return completed;
    }

    public void setCompleted(boolean completed) {
        this.completed = completed;
    }

    public int getInstanceSize() {
        return instanceSize;
    }

    public void setInstanceSize(int instanceSize) {
        this.instanceSize = instanceSize;
    }

    public List<FlingCommandResultPO> getResults() {
        return results;
    }

    public void setResults(List<FlingCommandResultPO> results) {
        this.results = results;
    }

}
