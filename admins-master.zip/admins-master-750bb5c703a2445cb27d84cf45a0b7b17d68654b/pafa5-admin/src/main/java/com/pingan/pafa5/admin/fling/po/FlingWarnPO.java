package com.pingan.pafa5.admin.fling.po;

import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 告警信息表
 * 
 */
@Document
public class FlingWarnPO {

    /**
     * 告警ID
     */
    @org.springframework.data.annotation.Id
    private String id;

    /**
     * 项目ID
     */
    private String projectId;

    /***
     * 应用名
     */
    private String appName;
    /**
     * 组件名
     */
    private String sarName;

    /**
     * 实例IP
     */
    private String instanceIp;

    /**
     * 创建时间(即admin服务端时间)
     */
    private long createdTimestamp;

    /**
     * 警告源
     */
    private String warnSource;
    /**
     * 描述信息
     */
    private String description;
    /**
     * 描述信息简述
     */
    private String shortDescription;

    /**
     * 业务系统请求ID
     */
    private String bizRequestId;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getAppName() {
        return appName;
    }

    public void setAppName(String appName) {
        this.appName = appName;
    }

    public String getInstanceIp() {
        return instanceIp;
    }

    public void setInstanceIp(String instanceIp) {
        this.instanceIp = instanceIp;
    }

    public long getCreatedTimestamp() {
        return createdTimestamp;
    }

    public void setCreatedTimestamp(long createdTimestamp) {
        this.createdTimestamp = createdTimestamp;
    }

    public String getWarnSource() {
        return warnSource;
    }

    public void setWarnSource(String warnSource) {
        this.warnSource = warnSource;
    }

    public String getBizRequestId() {
        return bizRequestId;
    }

    public void setBizRequestId(String bizRequestId) {
        this.bizRequestId = bizRequestId;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getShortDescription() {
        return shortDescription;
    }

    public void setShortDescription(String shortDescription) {
        this.shortDescription = shortDescription;
    }

    public String getSarName() {
        return sarName;
    }

    public void setSarName(String sarName) {
        this.sarName = sarName;
    }

}
