package com.pingan.pafa5.admin.logging.services;



import org.dom4j.DocumentException;

import com.pingan.pafa.redis.Redis;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.logging.dto.LogMonitorDTO;
import com.pingan.pafa5.admin.logging.form.LogMonitorForm;
import com.pingan.pafa5.admin.logging.po.LogMonitorPO;

public interface LogMonitorServices {

	public LogMonitorPO apply(String pappName,String redisPizzaKey);

	public Redis getConfigRedis(String queueName);
	
	public PageDataDTO<LogMonitorDTO> list(String projectId, String pappName, int limit, int page);

	public LogMonitorPO configXML(LogMonitorForm po, String currTime) throws DocumentException;

	public void restoreXML(String queueName, String currTime);

	public LogMonitorPO configXML(String id, String currTime);

	public boolean delete(String id);

	public void setTimeOutStatus();

	public LogMonitorPO configXML2(String pappName, String projectId);

	public void restoreXML2(String pappName, String projectId);
	
	public void configKafkaXML(String pappName, String projectId,String kafkaurl); 
	
	public void restoreKafkaXML(String pappName , String projectId);
	
	public boolean checkKafkaExist(String pappName , String projectId);
}
