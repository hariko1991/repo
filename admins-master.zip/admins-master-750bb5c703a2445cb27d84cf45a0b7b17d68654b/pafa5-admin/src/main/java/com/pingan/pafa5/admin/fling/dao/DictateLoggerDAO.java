package com.pingan.pafa5.admin.fling.dao;

import java.util.List;

import com.pingan.pafa5.admin.fling.po.DictateLoggerPO;
import com.pingan.pafa5.admin.fling.po.FlingCommandResultPO;

public interface DictateLoggerDAO {

    void add(DictateLoggerPO po);

    DictateLoggerPO getByDictateId(String dictateId);

    DictateLoggerPO getById(String id);

    void setResult(FlingCommandResultPO result);

    List<DictateLoggerPO> list(int limit, int page, String projectId, String pappName,
            String sarName);

    long getTotal(String projectId, String pappName, String sarName);

}
