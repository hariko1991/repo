package com.pingan.pafa5.admin.fling.po;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.pingan.pafa5.admin.commons.BasePO;

/**
 * 指令执行结果
 * 
 * @author JIECHANGKE805
 * 
 */
@Document
public class FlingCommandResultPO extends BasePO {
    

	@org.springframework.data.annotation.Id
    private String id;

    /**
     * 指令流水ID
     */
    @Indexed
    private String rid;

    /**
     * 回执者IP地址
     */
    private String instanceIp;

    /**
     * 回执者机器名
     */
    private String instanceName;

    /**
     * 回执行日期
     */
    private long receiptDate;

    /**
     * 执行结果编码
     */
    private String responseCode;

    /**
     * 执行结果信息
     */
    private String responseMsg;

    /**
     * 目标类型： papp/sar
     */
    private String targetType;

    /**
     * 操作类型： stop/start/restart
     */
    private String actionType;

    /**
     * 应用名
     */
    private String pappName;

    /**
     * 组件名
     */
    private String sarName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getRid() {
        return rid;
    }

    public void setRid(String rid) {
        this.rid = rid;
    }

    public String getInstanceIp() {
        return instanceIp;
    }

    public void setInstanceIp(String instanceIp) {
        this.instanceIp = instanceIp;
    }

    public String getInstanceName() {
        return instanceName;
    }

    public void setInstanceName(String instanceName) {
        this.instanceName = instanceName;
    }

    public long getReceiptDate() {
        return receiptDate;
    }

    public void setReceiptDate(long receiptDate) {
        this.receiptDate = receiptDate;
    }

    public String getResponseCode() {
        return responseCode;
    }

    public void setResponseCode(String responseCode) {
        this.responseCode = responseCode;
    }

    public String getResponseMsg() {
        return responseMsg;
    }

    public void setResponseMsg(String responseMsg) {
        this.responseMsg = responseMsg;
    }

    public String getTargetType() {
        return targetType;
    }

    public void setTargetType(String targetType) {
        this.targetType = targetType;
    }

    public String getActionType() {
        return actionType;
    }

    public void setActionType(String actionType) {
        this.actionType = actionType;
    }

    public String getPappName() {
        return pappName;
    }

    public void setPappName(String pappName) {
        this.pappName = pappName;
    }

    public String getSarName() {
        return sarName;
    }

    public void setSarName(String sarName) {
        this.sarName = sarName;
    }

}
