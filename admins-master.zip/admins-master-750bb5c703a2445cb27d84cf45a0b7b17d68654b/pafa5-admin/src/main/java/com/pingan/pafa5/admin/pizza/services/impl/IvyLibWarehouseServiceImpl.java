package com.pingan.pafa5.admin.pizza.services.impl;

import java.lang.reflect.InvocationTargetException;
import java.util.Calendar;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DuplicateKeyException;
import org.springframework.stereotype.Service;

import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.pizza.dao.IvyLibWarehouseDAO;
import com.pingan.pafa5.admin.pizza.dto.IvyLibWarehouseDTO;
import com.pingan.pafa5.admin.pizza.po.IvyLibWarehousePO;
import com.pingan.pafa5.admin.pizza.services.IvyLibWarehouseService;
import com.pingan.pafa5.admin.sso.UserPrincipal;

@Service
public class IvyLibWarehouseServiceImpl implements IvyLibWarehouseService {
	
	private static final Log log = LogFactory.getLog(IvyLibWarehouseServiceImpl.class);

	@Autowired
	private IvyLibWarehouseDAO ivyLibDAO;
	
	@Override
	public String checkExistsAndReturnPath(String projectId,String md5) {
		boolean isExists = ivyLibDAO.isExists(md5, projectId);
		if(isExists){
			IvyLibWarehousePO ivyLibPO = ivyLibDAO.findByMd5(projectId,md5);
			return ivyLibPO.getOrg()+"/"+ivyLibPO.getModule()+"/"+ivyLibPO.getVersion();
		} 
		return null;
	}

	@Override
	public void saveIvyLib(IvyLibWarehouseDTO ivyLibDTO) {
		IvyLibWarehousePO  ivyLibPO = new IvyLibWarehousePO();
		
		try {
			BeanUtils.copyProperties(ivyLibPO, ivyLibDTO);
		} catch (IllegalAccessException e) {
			log.info("error occured while copying bean form ivyLibDTO to ivyLibPO, id is : " + ivyLibDTO.getId() +"cause by: "+e.getMessage());
		} catch (InvocationTargetException e) {
			log.info("error occured while copying bean form ivyLibDTO to ivyLibPO, id is : " + ivyLibDTO.getId() +"cause by: "+e.getMessage());
		}
		IvyLibWarehouseDTO ivyDTO = this.findById(ivyLibPO.getId());
		
		UserPrincipal user = UserPrincipal.get();
		String uid = user != null ? user.getUid() : "Ant Script";
		 if(null == ivyDTO){
		 	POUtils.setForAdd(uid , ivyLibPO);
		 	ivyLibDAO.saveIvyLib(ivyLibPO);
		 }else{
			POUtils.setForUpdate(uid , ivyLibPO);
			ivyLibDAO.updateIvyLib(ivyLibPO);
		 }
		
	}

	@Override
	public IvyLibWarehouseDTO findById(String id) {
		
		IvyLibWarehouseDTO ivyLibDTO = new IvyLibWarehouseDTO();
		 
		IvyLibWarehousePO ivyLibPO = ivyLibDAO.findById(id);
		
		if(null == ivyLibPO) return null;
		
		try{
		   BeanUtils.copyProperties(ivyLibDTO , ivyLibPO);
		}catch(IllegalAccessException e){
			log.info("error occured while copying bean form ivyLibDTO to ivyLibPO, id is : " + ivyLibPO.getId() +"cause by: "+e.getMessage());
		} catch (InvocationTargetException e) {
			log.info("error occured while copying bean form ivyLibDTO to ivyLibPO, id is : " + ivyLibPO.getId() +"cause by: "+e.getMessage());
		}
		
		return ivyLibDTO;
	}

	@Override
	public void cleanIvyWarehouseTempFile() {
		Calendar time = Calendar.getInstance();
		  time.add(Calendar.MINUTE, -30);
		ivyLibDAO.cleanTempFile(time.getTime());
		
	}

}
