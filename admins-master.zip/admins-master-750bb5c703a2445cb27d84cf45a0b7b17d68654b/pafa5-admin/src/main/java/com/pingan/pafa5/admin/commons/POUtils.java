package com.pingan.pafa5.admin.commons;

import java.util.Date;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.ui.ModelMap;

import com.paic.pafa.biz.dao.PO;
import com.paic.pafa.utils.MDCUtil;
import com.pingan.pafa5.admin.commons.POUtilsBean.UtilDateConverter;

public class POUtils {

	static {
		// 注册sql.date的转换器，即允许BeanUtils.copyProperties时的源目标的sql类型的值允许为空
		// ConvertUtils.register(new SqlDateConverter(), java.util.Date.class);
		// ConvertUtils.register(new SqlTimestampConverter(), java.sql.Timestamp.class);
		// 注册util.date的转换器，即允许BeanUtils.copyProperties时的源目标的util类型的值允许为空

		POUtilsBean.getPOUtilsBeanInstance().getConvertUtils().register(new UtilDateConverter(), java.util.Date.class);
	}

	public static void setForAdd(String user, PO po) {
		if (user == null)
			user = "UNKNOWN";
		po.setCreatedBy(user);
		po.setRequestId(MDCUtil.getDatas().getRequestId());
		po.setCreatedDate(new Date());
		po.setUpdatedBy(user);
		po.setUpdatedDate(po.getCreatedDate());
	}

	public static void setForUpdate(String user, PO po) {
		if (user == null)
			user = "UNKNOWN";
		po.setRequestId(MDCUtil.getDatas().getRequestId());
		po.setUpdatedBy(user);
		po.setUpdatedDate(new Date());
	}

	/**
	 * 属性复制，不排除null字段，date类型的转换未增加，有隐患
	 * 
	 * @param target
	 * @param orig
	 * @return
	 */
	public static <T extends Object> T copyProperties(T target, Object orig) {
		try {
			// POUtilsBean.getPOUtilsBeanInstance().copyProperties(target, orig);
			BeanUtils.copyProperties(target, orig);

		} catch (Exception e) {
			throw new IllegalArgumentException("Bean copy exception,cause:" + e.getMessage(), e);
		}
		return target;
	}

	/**
	 * 对象复制, 忽略null属性, 对日期为null的属性已经作了处理
	 * 
	 * @param target
	 *            目标对象
	 * @param orig
	 *            源对象
	 * @return
	 */
	public static <T extends Object> T copyPropertiesIgnoreNull(T target, Object orig) {
		try {
			POUtilsBean.getPOUtilsBeanInstance().copyPropertiesIgnoreNull(target, orig);
		} catch (Exception e) {
			throw new IllegalArgumentException("Bean copy exception,cause:" + e.getMessage(), e);
		}
		return target;
	}

	public static ModelMap toMap(Object orig) {
		try {
			ModelMap model = new ModelMap();
			model.addAllAttributes(BeanUtils.describe(orig));
			model.remove("class");
			return model;
		} catch (Exception e) {
			throw new IllegalArgumentException("Bean toMap exception,cause:" + e.getMessage(), e);
		}
	}
	
	public static String arrayToString(long[] ls){
		String strArray = "[";
		for(Object o: ls){
			strArray += o.toString() + ",";
		}
		strArray = strArray.substring(0, strArray.length()-1) + "]";
		return strArray;
	}

}
