package com.pingan.pafa5.admin.papp.web;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.validator.annotation.Valid;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.pizza.PizzaConstants;
import com.pingan.pafa5.admin.Constants;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.commons.SARManagerConstants;
import com.pingan.pafa5.admin.commons.SqlUtils;
import com.pingan.pafa5.admin.papp.dto.AddSarForm;
import com.pingan.pafa5.admin.papp.dto.PappDTO;
import com.pingan.pafa5.admin.papp.dto.PappManagerDTO;
import com.pingan.pafa5.admin.papp.dto.PappRegistDTO;
import com.pingan.pafa5.admin.papp.po.PappManagerPO;
import com.pingan.pafa5.admin.papp.services.PappManagerService;
import com.pingan.pafa5.admin.papp.services.impl.ConfigFileGenerate;
import com.pingan.pafa5.admin.sar.dto.SARManagerDTO;
import com.pingan.pafa5.admin.sso.UserPrincipal;
import com.pingan.pafa5.admin.systems.dto.SystemGroupDTO;
import com.pingan.pafa5.admin.users.po.UserInfoPO;

@Controller
public class PappRegistController {

	@Autowired
	private ConfigFileGenerate configFileGenerate;

	@Autowired
	private PappManagerService pappManagerService;

	@ActionClient(name = "pafa5-admin-pizza.listKeys")
	private IServiceClient pizzaListKeysService;

	@ActionClient(name = "pafa5-admin-systems.findGroupByProperty")
	private IServiceClient systemGroupService;

	@ActionClient(name = "pafa5-admin-sar.sar-list")
	private IServiceClient sarService;

	@ActionClient(name = "pafa5-admin-systems.findGroupById")
	private IServiceClient groupService;

	@ActionClient(name = "pafa5-admin-sar.sar-register")
	private IServiceClient sarRegister;

	@ActionClient(name = "pafa5-admin-sar.sar-delete")
	private IServiceClient sarDelete;

	@ActionClient(name = "pafa5-admin-pizza.saveConfig")
	private IServiceClient saveConfig;

	@ActionClient(name = "pafa5-admin-user.getUser")
	private IServiceClient userService;

	/**
	 * @see 查询未注册应用列表
	 * @author JIECHANGKE805
	 * @since 2016年6月15日
	 * @param
	 */
	@RequestMapping("/papp/unRegistPapp.do")
	@ResponseBody
	public ResponseModel listUnRegistPapp(@RequestParam("projectId") String projectId) {

		List<PappDTO> pappList = findAllPapps(projectId);
		if (CollectionUtils.isEmpty(pappList)) {
			ResponseModel model = new ResponseModel("1", "应用列表为空。");
			model.put("datas", new ArrayList<String>());
			return model;
		}

		PappManagerDTO pappManagerDTO = new PappManagerDTO();
		List<PappManagerPO> rawPappList = pappManagerService.list(pappManagerDTO).getDatas();

		List<PappDTO> registedPapp = new ArrayList<PappDTO>();
		if (!CollectionUtils.isEmpty(rawPappList)) {
			for (PappManagerPO pappPO : rawPappList) {
				PappDTO pappDTO = new PappDTO();
				pappDTO.setId(pappPO.getPappName());
				pappDTO.setPappName(pappPO.getPappName());

				registedPapp.add(pappDTO);
			}
		}

		List<PappDTO> removeList = new ArrayList<PappDTO>();
		for (PappDTO pappDTO : pappList) {
			for (PappDTO unRegistDTO : registedPapp) {
				if (pappDTO.equals(unRegistDTO)) {
					removeList.add(pappDTO);
				}
			}
		}
		pappList.removeAll(removeList);

		ResponseModel responseModel = new ResponseModel();
		// 移除已经注册过的应用
		responseModel.put("datas", pappList);
		return responseModel;

	}

	@RequestMapping("/papp/regist.do")
	@ResponseBody
	public ResponseModel registPapp(@Valid PappRegistDTO pappRegistDTO) throws Exception {

		ServiceParams params = ServiceParams.newInstance();
		params.set("projectId", pappRegistDTO.getProjectId());
		params.set("optype", "add");
		params.set("group", "papp");
		params.set("key", pappRegistDTO.getPappName() + ".properties");

		params.set("value", configFileGenerate.generatePappProperties());
		// 生成papp.properties

		ServiceResults saveResult = saveConfig.invoke(params);

		boolean success = false;

		try {
			success = (Boolean) saveResult.get("success");
		} catch (NullPointerException ex) {
			ResponseModel responseModel = new ResponseModel();
			responseModel.put("success", false);
			responseModel.put("msg", "对不起，你不是项目负责人，不能新增应用。");
			return responseModel;
		}

		if (!success) {
			ResponseModel responseModel = new ResponseModel();
			responseModel.put("success", success);
			responseModel.put("msg", saveResult.getString("responseMsg"));
			return responseModel;
		}

		ServiceParams paras = ServiceParams.newInstance();
		paras.set("projectId", pappRegistDTO.getProjectId());
		paras.set("group", "papp");
		paras.set("optype", "add");
		paras.set("key", pappRegistDTO.getPappName() + ".log4j.xml");
		paras.set("value", configFileGenerate.generatePappLog4jXml());

		// 生成papp.log4j.xml
		ServiceResults saveRst = saveConfig.invoke(paras);
		boolean succ = (Boolean) saveRst.get("success");
		if (!succ) {
			ResponseModel responseModel = new ResponseModel();
			responseModel.put("success", success);
			responseModel.put("msg", saveResult.getString("msg"));
			return responseModel;
		}
		ServiceParams groupParas = ServiceParams.newInstance().set("groupId", pappRegistDTO.getProjectId());
		ServiceResults result = groupService.invoke(groupParas);
		SystemGroupDTO systemGroupDTO = (SystemGroupDTO) result.toDTO("data", SystemGroupDTO.class);

		PappManagerPO pappManagerPO = new PappManagerPO();
		pappManagerPO.setPappName(pappRegistDTO.getPappName());
		pappManagerPO.setPappChName(pappRegistDTO.getPappCnName());

		if (systemGroupDTO != null) {
			pappManagerPO.setSystemsId(systemGroupDTO.getGroupId());
			pappManagerPO.setSystemsName(systemGroupDTO.getGroupName());
		}else if(pappRegistDTO.getProjectId() != null 
				&& SARManagerConstants.DEF.equalsIgnoreCase(pappRegistDTO.getProjectId())){
			pappManagerPO.setSystemsId(Constants.DOMAIN_ID_DEF);
			pappManagerPO.setSystemsName(Constants.DOMAIN_NAME_DEF);
		}

		UserPrincipal user = UserPrincipal.get(true);

		// 调用USER模块ESA获取用户信息
		ServiceResults results = userService.invoke();
		UserInfoPO userInfo = results.toDTO(UserInfoPO.class);
		String name = userInfo.getName() == null ? "" : userInfo.getName();
		pappManagerPO.setPappOwner(name + " " + user.getUid());
		pappManagerPO.setPappOwnerId(user.getUid());

		POUtils.setForAdd(user.getUid(), pappManagerPO);

		PappManagerDTO dto = new PappManagerDTO();
		BeanUtils.copyProperties(dto, pappManagerPO);
		pappManagerService.add(dto);

		ResponseModel responseModel = new ResponseModel();
		responseModel.put("success", true);
		responseModel.put("msg", "应用注册成功。");

		return responseModel;

	}

	@SuppressWarnings("unchecked")
	public List<PappDTO> findAllPapps(String projectId) {
		ServiceParams params = ServiceParams.newInstance();
		params.set("projectId", projectId);
		params.set("group", PizzaConstants.GROUP_PAPP);

		if (SqlUtils.SPRING_PROFILE_NOSQL.equalsIgnoreCase(SqlUtils.getSpringProfilesActive())) {
			String parttern = "^[\\w\\-]*\\.properties$";
			params.set("keyRegex", parttern);
		} else {
			String parttern = "%.properties";
			params.set("keyRegex", parttern);
		}

		ServiceResults result = pizzaListKeysService.invoke(params);
		String responseCode = result.getString("responseCode");

		List<PappDTO> pappList = null;
		if ("0".equals(responseCode)) {
			pappList = new ArrayList<PappDTO>();

			int keySize = result.getInt("keySize");
			int suffixLength = ".properties".length();
			if (keySize > 0) {

				List<String> keyList = (List<String>) result.get("keys");
				for (String key : keyList) {
					PappDTO pappDTO = new PappDTO();
					String pappName = key.substring(0, key.length() - suffixLength);
					pappDTO.setId(pappName);
					pappDTO.setPappName(pappName);

					pappList.add(pappDTO);
				}
			}
		}

		return pappList;
	}

	@RequestMapping("/papp/sar-list.do")
	@ResponseBody
	public ResponseModel listSarByPapp(@RequestParam(value = "pappName") String pappName,
			@RequestParam(value = "projectId") String projectId) {

		ServiceParams params = ServiceParams.newInstance();
		params.set("projectId", projectId);
		params.set("pappName", pappName);

		ServiceResults result = sarService.invoke(params);

		List<SARManagerDTO> sarList = result.toDTOList("datas", SARManagerDTO.class);

		ResponseModel responseModel = new ResponseModel();
		responseModel.put("datas", sarList);
		responseModel.put("success", true);
		responseModel.put("totalProperty", sarList.size());

		return responseModel;
	}

	@RequestMapping("/papp/addSar.do")
	@ResponseBody
	public ResponseModel addSar(@Valid AddSarForm form) throws Exception {

		ServiceParams serviceParams = ServiceParams.newInstance();
		serviceParams.set("property", "groupName");
		serviceParams.set("value", form.getSystemsName());

		ServiceResults serviceResult = systemGroupService.invoke(serviceParams);
		SystemGroupDTO systemDTO = serviceResult.toDTO("data", SystemGroupDTO.class);

		PappManagerDTO pappPO = pappManagerService.getByPappName(form.getPappName());

		ServiceParams params = ServiceParams.newInstance();
		params.set("sarId", form.getSarId());
		params.set("sarName", form.getSarName());
		params.set("systemsId", systemDTO.getGroupId());
		params.set("systemsName", form.getSystemsName());
		params.set("pappName", form.getPappName());
		params.set("sarOwner", pappPO.getPappOwner());
		params.set("sarOwnerId", pappPO.getPappOwnerId());

		ServiceResults result = sarRegister.invoke(params);

		ResponseModel responseModel = result.toDTO(ResponseModel.class);

		return responseModel;

	}

	@RequestMapping("/papp/deleteSar.do")
	@ResponseBody
	public ResponseModel deleteSar(@RequestParam(value = "pappName") String pappName, @RequestParam(value = "sarId") String sarId) {

		ServiceParams serviceParams = ServiceParams.newInstance();
		serviceParams.set("pappName", pappName);
		serviceParams.set("sarId", sarId);

		sarDelete.invoke(serviceParams);

		ResponseModel responseModel = new ResponseModel();
		responseModel.put("success", true);

		return responseModel;

	}

}
