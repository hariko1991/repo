package com.pingan.pafa5.admin.fling.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.fling.dao.DruidDatasourceDAO;
import com.pingan.pafa5.admin.fling.po.DruidDatasourcePO;
@Nosql
@Repository
public class DruidDatasourceDAOImpl extends BaseMongoDAO<DruidDatasourcePO> implements DruidDatasourceDAO {

	@Override
	public void add(DruidDatasourcePO datasourece) {
		// TODO Auto-generated method stub
		this._add(datasourece);
	}

	@Override
	public void update(DruidDatasourcePO datasourece) {
		// TODO Auto-generated method stub
		this._updateById(datasourece);
	}

	@Override
	public DruidDatasourcePO getDruidDatasourceById(String id, int identity) {
		// TODO Auto-generated method stub
		Criteria criteria = this.where("id").is(id).and("identity").is(identity);
		return this._get(criteria);
	}

	@Override
	public DruidDatasourcePO getDruidDatasourceByIdentity(int identity) {
		// TODO Auto-generated method stub
		Criteria criteria = this.where("identity").is(identity);
		return this._get(criteria);
	}

	@Override
	public DruidDatasourcePO getDruidDatasourceByUrl(Map<String, Object> map) {
		// TODO Auto-generated method stub
		Criteria criteria = where("domainId").is(map.get("domainId"))
								.and("pappName").is(map.get("pappName"))
								.and("instanceIp").is(map.get("instanceIp"))
								.and("url").is(map.get("url"));
		return this._get(criteria);
	}

	@Override
	public List<DruidDatasourcePO> list(Map<String, Object> map) {
		// TODO Auto-generated method stub
		Criteria criteria = where("domainId").is(map.get("domainId")).and("status").is(0);
		if(map.containsKey("pappName")&&(!map.get("pappName").equals(""))) {
			criteria.and("pappName").is(map.get("pappName"));
		}
		return this._list(criteria,(int)map.get("page"),(int)map.get("limit"));
	}

	@Override
	public List<DruidDatasourcePO> getAll() {
		return this._list(null);
	}

	@Override
	public long getCount(Map<String, Object> map) {
		// TODO Auto-generated method stub
		Criteria criteria = where("domainId").is(map.get("domainId")).and("status").is(0);
		if(map.containsKey("pappName")&&(!map.get("pappName").equals(""))) {
			criteria.and("pappName").is(map.get("pappName"));
		}
		return this._count(criteria);
	}

}
