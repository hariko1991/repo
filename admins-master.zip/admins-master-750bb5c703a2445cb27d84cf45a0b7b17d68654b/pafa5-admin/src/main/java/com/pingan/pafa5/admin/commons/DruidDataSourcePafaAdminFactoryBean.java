package com.pingan.pafa5.admin.commons;

import java.util.Properties;

import javax.sql.DataSource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.FatalBeanException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.FactoryBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;

import com.alibaba.druid.pool.DruidDataSource;
import com.alibaba.druid.pool.DruidDataSourceFactory;
import com.pingan.pafa.common.security.PasswordContext;
import com.pingan.pafa.common.security.PasswordProviderFactory;

public class DruidDataSourcePafaAdminFactoryBean implements FactoryBean<DataSource>, InitializingBean, DisposableBean {

	protected Log logger = LogFactory.getLog(this.getClass());

	private DruidDataSource dataSource;

	private Resource configure;

	public DruidDataSourcePafaAdminFactoryBean() {
	}

	@Override
	public DataSource getObject() throws Exception {
		return dataSource;
	}

	@Override
	public Class<?> getObjectType() {
		return DataSource.class;
	}

	@Override
	public boolean isSingleton() {
		return true;
	}

	@Override
	public void destroy() throws Exception {
		try {
			if (dataSource != null) {
				dataSource.close();
			}
		} catch (Exception ex) {
			logger.error("Close datasource error:" + ex.getMessage(), ex);
		}

	}

	protected void forCyberPassword(Properties dbConfig) {
		String user = dbConfig.getProperty("cyberUser");
		if (user == null) {
			user = dbConfig.getProperty("passwordKey");
		}
		if (user == null) {
			user = dbConfig.getProperty("username");
		}
		String pwd = dbConfig.getProperty("password");
		
		logger.info("default password:" + pwd);
		
		pwd = PasswordProviderFactory.getProvider(dbConfig.getProperty("passwordProvider")).getPassword(new PasswordContext(user).setDefaultPassword(pwd).setRequired(true));
		
		logger.info("cyberArk password:" + pwd);
		dbConfig.setProperty("password", pwd);
	}

	@Override
	public void afterPropertiesSet() throws Exception {
		if (configure == null) {
			throw new FatalBeanException("configure be null.");
		}
		Properties props = null;
		try {
			props = new Properties();
			props.load(configure.getInputStream());
			
			props = ReplacePropertiesUtils.replace(props);
			
			forCyberPassword(props);
			dataSource = new DruidDataSource();
			DruidDataSourceFactory.config(dataSource, props);
			if (!("false".equalsIgnoreCase(props.getProperty("initialOnStartup")))) {
				dataSource.init();
			}
		} catch (Exception e) {
			logger.error("Create Druid datasource error by config:", e);
			throw new FatalBeanException("Create Druid datasource error by config:" + props, e);
		}
	}

	public Resource getConfigure() {
		return configure;
	}

	public void setConfigure(Resource configure) {
		this.configure = configure;
	}

}
