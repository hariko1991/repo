package com.pingan.pafa5.admin.pizza.dao.impl;

import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.pizza.dao.PizzaInstanceDAO;
import com.pingan.pafa5.admin.pizza.po.PizzaInstancePO;

@Repository
public class PizzaInstanceDAOImpl extends BaseMongoDAO<PizzaInstancePO> implements PizzaInstanceDAO {

	@Override
	public void save(PizzaInstancePO instancePO) {
		this._add(instancePO);
	}
	
	@Override
	public PizzaInstancePO get(String proId, String instanceIp) {
		String id = proId+"-"+instanceIp;
		return this._getById(id);
	}

	@Override
	public void update(PizzaInstancePO instancePO) {
		this._updateById(instancePO);
	}

	@Override
	public List<PizzaInstancePO> getInstances(String projectId,String instanceIp) {
		Pattern p = Pattern.compile("^.*"+projectId+".*$");
		Criteria criteria = Criteria.where("_id").regex(p);
		if(StringUtils.isNotEmpty(instanceIp)) {
			Pattern pattern = Pattern.compile("^.*"+instanceIp+".*$");
			criteria.and("instanceIp").regex(pattern);
		}
		return this._list(criteria);
	}
}
