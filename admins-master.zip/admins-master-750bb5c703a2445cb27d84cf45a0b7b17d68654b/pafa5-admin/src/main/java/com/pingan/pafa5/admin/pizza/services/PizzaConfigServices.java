package com.pingan.pafa5.admin.pizza.services;

import java.util.List;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSaveDTO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSearchDTO;
import com.pingan.pafa5.admin.pizza.form.PizzaConfigForm;
import com.pingan.pafa5.admin.pizza.po.FileTempPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigPO;
import com.pingan.pafa5.admin.sso.UserPrincipal;

public interface PizzaConfigServices {
    
    /**
     * 查询资源列表
     * @param searchDto
     * @return
     */
    PageDataDTO<PizzaConfigPO> search(ConfigSearchDTO searchDto);
    
    /**
     * 保存资源，有则更新，无则新增
     * @param form
     * @return
     */
    int save(ConfigSaveDTO form) throws Exception;

    /**
     * 新增资源
     * @param form
     */
    void addConfigContent(PizzaConfigForm form);
    
    /**
     * 更新资源
     * @param form
     * @return
     */
    boolean updateConfigContent(PizzaConfigForm form);

    /**
     * 判定资源是否存在
     * @param domainId
     * @param group
     * @param key
     * @return
     */
    boolean checkExists(String domainId, String group, String key);
    
    /**
     * 删除资源
     * @param domainId
     * @param group
     * @param key
     * @return
     */
    boolean del(String domainId, String group, String key);
    
    /**
     * 获取资源信息
     * @param domainId
     * @param group
     * @param key
     * @return
     */
    PizzaConfigPO get(String domainId, String group, String key);

    /**
     * 获取资源内容
     * @param domainId
     * @param group
     * @param key
     * @return
     */
    String getConfigContent(String domainId, String group, String key);
    
    /**
     * 获取二进制资源内容
     * @param proId
     * @param group
     * @param key
     * @return
     */
    byte[] getConfigByteContent(String domainId, String group, String key);

    int save(String proId, String group, String key, String content, String operationType, UserPrincipal user) throws Exception;

    int recoveryDB(String domainId, String group, String key, String content) throws Exception;

    int rollback(String domainId, String group, String key, String content, UserPrincipal up) throws Exception;

    List<String> listKeys(String domainId, String group);

    /**
     * create by houshangzhi 2016-7-19 09:51:01 根据项目查询资源组配置文件
     * 
     * @param group
     * @param keyRegex
     * @param likeKey
     * @return
     */
    List<String> listKeysByProId(String projectId, String group, String pizzaKeyRegex);

    boolean changeConfigProject(String group, String key, String projectId,
            String projectName);

   

    /**
     * 保存临时文件的二进制内容
     * 
     * @param bytes
     * @return
     */
    String saveFileTemp(String bytes);

    /**
     * 根据ID获取临时文件内容
     * 
     * @param uuid
     * @return
     */
    FileTempPO getFileTempById(String uuid);

    /**
     * 删除临时文件内容
     * 
     * @param uuid
     * @return
     */
    void delFileTempById(String uuid);

    List<PizzaConfigPO> getPizzaKey(String pizzaGroup);

    List<PizzaConfigPO> query(String group, String regexKey, String pattern);

    List<PizzaConfigPO> queryByGroup(String group);

    List<PizzaConfigPO> queryAll();

    List<String> listKeys(String proId, String group, String pizzaKeyRegex);

    

    

    

    

    List<PizzaConfigPO> queryAllByProject(String proId);

    List<PizzaConfigPO> getPizzaKey(String proId, String pizzaGroup);

    List<PizzaConfigPO> query(String projectId, String group, String regexKey, String pattern);
    
}
