package com.pingan.pafa5.admin.papp.dao.impl;

import java.util.List;

import com.pingan.pafa5.admin.commons.Nosql;
import org.springframework.data.mongodb.core.query.Criteria;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.papp.dao.PappConfigDAO;
import com.pingan.pafa5.admin.papp.dto.PappConfigDTO;
import com.pingan.pafa5.admin.papp.po.PappConfigPO;
import com.pingan.um.client.util.UUID;
import org.springframework.stereotype.Repository;

/**
 * 组件配置.
 * @author yangxia037
 *
 */
@Nosql
@Repository
public class PappConfigDAOImpl  extends BaseMongoDAO<PappConfigPO> implements PappConfigDAO {

	@Override
	public void add(PappConfigPO po) {
		po.setId(UUID.getRandomID());
		this._add(po);
	}

	@Override
	public PappConfigPO isExists(PappConfigDTO form) {
		Criteria where = this.where("pappId").is(form.getPappId()).and("cfgItem").is(form.getCfgItem()).and("projectId").is(form.getProjectId());
		return this._get(where);
	}

	@Override
	public List<PappConfigPO> getCustomList(String pappId, String projectId) {
		Criteria criteria = this.where("pappId").is(pappId).and("projectId").is(projectId);
		return this._list(criteria);
	}


	@Override
	public long getCustomListCount(String pappId, String projectId) {
		Criteria criteria = this.where("pappId").is(pappId).and("projectId").is(projectId);
		return this._count(criteria);
	}

	@Override
	public boolean delete(String id) {
		return this._removeById(id);
	}

	@Override
	public boolean updateById(PappConfigPO po) {
		return this._updateById(po);
	}

	@Override
	public PappConfigPO getCustomById(String id) {
		Criteria where = this.where("id").is(id);
		return this._get(where);
	}

}
