package com.pingan.pafa5.admin.pizza.form;

import com.paic.pafa.validator.annotation.VNotEmpty;

/**
 * redis中配置值信息
 * 
 * @author EX-YANGSHENGXIANG001
 */

public class PizzaConfigForm {

	@VNotEmpty
	private String projectId;
	@VNotEmpty
	private String pizzaGroup;
	@VNotEmpty
	private String pizzaKey;
	@VNotEmpty
	private String pizzaValue;
	

	public String getPizzaGroup() {
		return pizzaGroup;
	}

	public void setPizzaGroup(String pizzaGroup) {
		this.pizzaGroup = pizzaGroup;
	}

	public String getPizzaKey() {
		return pizzaKey;
	}

	public void setPizzaKey(String pizzaKey) {
		this.pizzaKey = pizzaKey;
	}

	public String getPizzaValue() {
		return pizzaValue;
	}

	public void setPizzaValue(String pizzaValue) {
		this.pizzaValue = pizzaValue;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}
}
