package com.pingan.pafa5.admin.fling.dao;

import java.util.Date;

import com.pingan.pafa5.admin.fling.po.FlingCommandPO;

public interface FlingCommandDAO {

    String add(FlingCommandPO po);

    FlingCommandPO getById(String commandId);

    int removeBeforeDate(Date date);

}
