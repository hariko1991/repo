package com.pingan.pafa5.admin.monitor.dao.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.monitor.dao.DubboInterfaceDAO;
import com.pingan.pafa5.admin.monitor.po.DubboInterfacePO;

@Nosql
@Repository
public class DubboInterfaceDAOImpl extends BaseMongoDAO<DubboInterfacePO> implements DubboInterfaceDAO {

    @Override
    public DubboInterfacePO getById(String id) {
        return this._getById(id);
    }

    @Override
    public void save(DubboInterfacePO po) {
        this._save(po);        
    }
    
    @Override
    public long count(String interfaceName, Date beginDate, Date endDate) {
        Criteria criteria = this.where("updateTime").gte(beginDate).lt(endDate);
        if(StringUtils.isNotEmpty(interfaceName)) {
            criteria.and("interfaceName").is(interfaceName);
        }
        return this._count(criteria);
    }
    
    @Override
    public List<DubboInterfacePO> list(String interfaceName, Date beginDate, Date endDate, int skip, int limit) {
        Criteria criteria = this.where("updateTime").gte(beginDate).lt(endDate);
        if(StringUtils.isNotEmpty(interfaceName)) {
            criteria.and("interfaceName").is(interfaceName);
        }
        return this._list(criteria, skip, limit);
    }
    
    @Override
    public void update(DubboInterfacePO po) {
        this._updateById(po);
    }

    @Override
    public void removeByUpdateTime(String updateTime) {
        Criteria criteria = this.where("updateTime").lt(updateTime);
        this._remove(criteria);
    }   

}
