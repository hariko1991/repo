package com.pingan.pafa5.admin.fling.services.impl;

import java.util.Calendar;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.fling.dao.FlingWarnDAO;
import com.pingan.pafa5.admin.fling.po.FlingWarnPO;
import com.pingan.pafa5.admin.fling.services.FlingWarnServices;

@Service
public class FlingWarnServicesImpl extends BaseServices implements FlingWarnServices {
	
	@Autowired
	private FlingWarnDAO flingWarnDAO;
	
	@Override
	public PageDataDTO<FlingWarnPO> list(String domainId,String pappName, String sarName, int size, int page) {
		PageDataDTO<FlingWarnPO> pageData = new PageDataDTO<FlingWarnPO>();
		
		long count = flingWarnDAO.getCount(domainId,pappName, sarName);
		pageData.setTotalSize(count);
		
		if(count != 0) {
		    List<FlingWarnPO> pos = flingWarnDAO.listLast(domainId,pappName, sarName, size, page);
		    pageData.setDatas(pos);
		}
			
		return pageData;
	}

	@Override
	public String details(String id) {
		FlingWarnPO po = flingWarnDAO.getById(id);
		if (po != null) {
			return po.getDescription();
		}
		return null;
	}

	@Override
	public boolean delete15DaysBefore() {
		Calendar now = Calendar.getInstance();  
		now.add(Calendar.DATE, -15);
		now.set(Calendar.HOUR, 0);
		now.set(Calendar.MINUTE, 0);
		now.set(Calendar.SECOND, 0);

		int affected = flingWarnDAO.removeBeforeDate(now.getTime());	
		logger.info("清理告警信息条数：" + affected);
		
		return affected > 0;
	}

}
