//package com.pingan.pafa5.admin.pizza.job;
//
//import org.apache.commons.logging.Log;
//import org.apache.commons.logging.LogFactory;
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.stereotype.Component;
//
//import com.paic.pafa.job.TimerJob;
//import com.pingan.pafa5.admin.pizza.services.IvyLibWarehouseService;
//
//
///**
// * @see 每小时清理距现在30分钟以上的上传产生的临时文件,暂无界面，不启用
// *      
// * @author JIECHANGKE805
// * 
// */
//@Component
//public class CleanUploadTempFileJob {
//	
//	private static final Log log = LogFactory.getLog(CleanUploadTempFileJob.class);
//	
//	@Autowired
//	private IvyLibWarehouseService ivyLibWarehouseService;
//	
//	@TimerJob(cronExpression="${job.ex.ivy.temp.clean.time}")
//	public void execute(){
//		
//		log.info("Clean ivy warehouse temp file start...");
//		
//		ivyLibWarehouseService.cleanIvyWarehouseTempFile();
//		
//		log.info("Clean ivy warehouse temp file end...");
//		
//	}
//	
//	
//
//}
