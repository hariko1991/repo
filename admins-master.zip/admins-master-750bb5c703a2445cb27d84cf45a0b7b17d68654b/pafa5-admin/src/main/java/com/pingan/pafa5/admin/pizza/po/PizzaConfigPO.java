package com.pingan.pafa5.admin.pizza.po;

import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.pingan.pafa5.admin.commons.BasePO;

/**
 * 资源中心-全局资源
 * @author ZHANGJIAWEI370
 */
@Document
@CompoundIndexes({
	@CompoundIndex(name = "def_index", def = "{projectId : 1, pizzaGroup : 1}"),
	@CompoundIndex(name = "createdDate_index", def = "{createdDate : 1}") })
public class PizzaConfigPO extends BasePO {

	/**
	 * id = project + group + key
	 */
	@org.springframework.data.annotation.Id
	private String id;

	/**
	 * pizza分组
	 */
	private String pizzaGroup;

	/**
	 * pizza key
	 */
	@Indexed
	private String pizzaKey;

	private String valueMd5;

	private Integer valueSize;
	
	private String projectId;

	private String projectName;

	public String getPizzaGroup() {
		return pizzaGroup;
	}

	public void setPizzaGroup(String pizzaGroup) {
		this.pizzaGroup = pizzaGroup;
	}

	public String getPizzaKey() {
		return pizzaKey;
	}

	public void setPizzaKey(String pizzaKey) {
		this.pizzaKey = pizzaKey;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getValueMd5() {
		return valueMd5;
	}

	public void setValueMd5(String valueMd5) {
		this.valueMd5 = valueMd5;
	}

	public Integer getValueSize() {
		return valueSize;
	}

	public void setValueSize(Integer valueSize) {
		this.valueSize = valueSize;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

}
