package com.pingan.pafa5.admin.fling.services;

import java.util.List;

import org.springframework.ui.ModelMap;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.fling.dto.InstanceDTO;
import com.pingan.pafa5.admin.fling.po.FlingPappInstancePO;
import com.pingan.pafa5.admin.fling.po.FlingPappMonitorMsgPO;
import com.pingan.pafa5.admin.fling.po.FlingSARInstancePO;

public interface InstanceServices {

    boolean checkSarExistence(String sarName);

    boolean deletePapp(String projectId, String pappName, String instanceIp);

    boolean deleteSar(String projectId, String sarName, String instanceIp,String pappName);

    FlingPappInstancePO detailForPapp(String pappName, String instanceIp);

    FlingSARInstancePO detailForSar(String sarName, String instanceIp);
    
   

    FlingPappMonitorMsgPO getInstanceDetails(int status,String pappName, String instanceIp);

    FlingPappMonitorMsgPO getInstanceDetails(String projectId, String pappName, String instanceIp);

    ModelMap getInstanceDetails(String projectId, String pappName, String sarName, String instanceIp);
    
   

    List<FlingPappInstancePO> getPappInstanceByIp(String instanceIp);
    
    PageDataDTO<FlingSARInstancePO> getSarInstanceByIp(String instanceIp, int pageSizeSar, int pageNumSar);
    
    PageDataDTO<FlingSARInstancePO> getSarInstanceByIp(String instanceIp, String projectId, int pageSizeSar, int pageNumSar);
    
   

	List<FlingPappInstancePO> listForPapp(int status);

	PageDataDTO<FlingPappInstancePO> listForPapp(int status, int limit, int page);

	List<FlingPappInstancePO> listForPapp(String projectId, String pappName);

	PageDataDTO<FlingPappInstancePO> listForPapp(String projectId, String pappName, int limit, int page);

	List<FlingSARInstancePO> listForSAR(int status);

	PageDataDTO<FlingSARInstancePO> listForSAR(int status, int limit, int page);

	List<FlingSARInstancePO> listForSAR(String projectId, String sarName, String pappName);

	PageDataDTO<FlingSARInstancePO> listForSAR(String projectId, String sarName, String pappName, int limit, int page);

	List<FlingSARInstancePO> listForSAR(String instanceIp, String projectId,String sarName, String pappName);

	PageDataDTO<FlingSARInstancePO> listForSAR(String instanceIp, String projectId,String sarName,String pappName, int limit, int page);

	List<FlingPappMonitorMsgPO> listInstanceDetails(String peojectId, String pappName, String instanceIp);

	

	List<FlingPappInstancePO> listPappIndexPage(String projectId);
	List<FlingPappInstancePO> listPappSearchResult(String projectId,String searchField);
	
	List<FlingSARInstancePO> listSarSearchResult(String projectId,String searchField);
	
	List<FlingPappInstancePO> listForPapp1(String projectId,String pappName);
	
	List<InstanceDTO> listForProjectId(String projectId,String instanceIp);
	
	List<String> listForPappIp(String projectId,String pappName);
	
}
