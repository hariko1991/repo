package com.pingan.pafa5.admin.papp.dao;

import java.util.List;

import com.pingan.pafa5.admin.papp.dto.PappConfigDTO;
import com.pingan.pafa5.admin.papp.po.PappConfigPO;

/**
 * 组件配置.
 * @author yangxia037
 *
 */
public interface PappConfigDAO {

	void add(PappConfigPO po);

	PappConfigPO isExists(PappConfigDTO form);

	List<PappConfigPO> getCustomList(String pappId, String projectId);

	long getCustomListCount(String pappId, String projectId);

	boolean delete(String id);

	boolean updateById(PappConfigPO po);

	PappConfigPO getCustomById(String id);

}
