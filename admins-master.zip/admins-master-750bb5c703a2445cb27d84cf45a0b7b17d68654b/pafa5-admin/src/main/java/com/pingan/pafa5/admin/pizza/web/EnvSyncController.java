package com.pingan.pafa5.admin.pizza.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.validator.annotation.Valid;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dto.EnvSyncLogDTO;
import com.pingan.pafa5.admin.pizza.form.EnvSyncConfigForm;
import com.pingan.pafa5.admin.pizza.po.EnvSyncFailurePO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigPO;
import com.pingan.pafa5.admin.pizza.services.EnvSyncService;
import com.pingan.pafa5.admin.pizza.services.PizzaConfigServices;

/** 
 * 环境同步
 * @author ZHANGJIAWEI370
 * @author zhanggang871
 *
 */
@Controller
@RequestMapping("/pizzamgr/envsync")
public final class EnvSyncController extends BaseController {
	
	private Log logger = LogFactory.getLog(this.getClass());
	
	@Autowired 
	private EnvSyncService envSyncService;
	
	@Autowired 
	private PizzaConfigServices pizzaConfigServices;

	@ResponseBody
	@RequestMapping("/test-config.do")
	public ResponseModel testConfig(@Valid EnvSyncConfigForm form) {
		ResponseModel model = new ResponseModel();
		boolean success = envSyncService.testLink(form.getUri(), form.getLoginUser(), form.getLoginPwd());
		if (success) {
			model.setResponseMsg("连接测试成功");
		} else {
			model.setResponseMsg("用户名或密码错误，请检查");
		}
		model.put("success", success);
		return model;
	}

	@ResponseBody
	@RequestMapping("/list.do")
	public ResponseModel list(
			@RequestParam(value="syncType", required=false) Integer syncType,
			@RequestParam(value="status", required=false) Integer status,
			@RequestParam(value="page", required=false, defaultValue="1") int page,
			@RequestParam(value="limit", required=false, defaultValue="30") int limit) {
		Map<String,Object> queryParams = new HashMap<String, Object>();
		if(syncType != null){
			queryParams.put("syncType", syncType);
		}
		if(status != null){
			queryParams.put("status", status);
		}
		PageDataDTO<EnvSyncLogDTO> pageData = envSyncService.list(queryParams, page, limit);
		ResponseModel model = new ResponseModel();
		model.put("datas", pageData.getDatas());
		model.put("size", pageData.getTotalSize());
		return model;
	}
	
    @ResponseBody
    @RequestMapping("/startup.do")
    public ResponseModel startup(@Valid EnvSyncConfigForm form, HttpServletRequest httpRequest) {
        ResponseModel model = new ResponseModel();
        String strBackUrl1 = httpRequest.getScheme()
        					+ "://" 
        					+ httpRequest.getServerName() 
        					+ ":"
					        + httpRequest.getServerPort()
					        + httpRequest.getContextPath()
					        + httpRequest.getServletPath();
        String strBackUrl2 = strBackUrl1+"/";
        String strBackUrl3 = httpRequest.getScheme()
							+ "://" 
							+ httpRequest.getServerName()
							+ httpRequest.getContextPath()
					        + httpRequest.getServletPath();
        String strBackUrl4 = strBackUrl3+"/";
        logger.info("同步目标地址："+form.getUri());
        logger.info("同步原地址1："+strBackUrl1);
        logger.info("同步原地址2："+strBackUrl2);
        logger.info("同步原地址3："+strBackUrl3);
        logger.info("同步原地址4："+strBackUrl4);
        //开发与测试环境的url有差异，测试环境中：strBackUrl1=http://bank-pafa5-admin-dev.sdb.com.cn:80/admin/pizzamgr/envsync/startup.do
        //原地址更长，，故使用contains()方法
        if(strBackUrl1.contains(form.getUri())||strBackUrl2.contains(form.getUri())||strBackUrl3.contains(form.getUri())||strBackUrl4.contains(form.getUri())){
        	model.setResponseMsg("目标环境与当前环境相同，无法同步，请输入正确的目标环境。");
            model.put("success", false);
            return model;
        }
        envSyncService.manulSync(form.getTargetDomainId(), form.getTargetDomainName(), form.getUri(), form.getLoginUser(), form.getLoginPwd());
        model.setResponseMsg("正在同步中，请稍后检查结果……");
        model.put("success", true);
        return model;
    }
	
	@ResponseBody
	@RequestMapping("/find-cause.do")
	public ResponseModel findCause(
			@RequestParam(value="id", required=false) String id) {
		ResponseModel model = new ResponseModel();
		EnvSyncLogDTO async = envSyncService.findLog(id);
		model.put("async", async);
		model.put("success", true);
		return model;
	}
	
	@ResponseBody
	@RequestMapping("/view-cause.do")
	public ResponseModel viewCause(
			@RequestParam(value="id", required=false) String id,
			HttpServletResponse response) {
		ResponseModel model = new ResponseModel();
		EnvSyncLogDTO async = envSyncService.findLog(id);
		
		response.setContentType("text/html;charset=utf-8");
		PrintWriter pw = null;
		try {
			pw = response.getWriter();
			if (async != null) {
				pw.print(async.getCause() == null ? "没有找到失败原因" : async.getCause());
			} else {
				pw.print("没有找到失败原因");
			}
			pw.flush();
		} catch (IOException e) {
			logger.info(e);
		} finally {
			if (pw != null) {
				pw.close();
			}
		}
		model.put("async", async);
		model.put("success", true);
		return null;
	}
	
	@ResponseBody
	@RequestMapping("/find-failures.do")
	public ResponseModel findFailures(@RequestParam(value="id", required=false) String syncId) {
		ResponseModel model = new ResponseModel();
		List<EnvSyncFailurePO> pos = envSyncService.getFailuers(syncId);
		model.put("failures", pos);
        model.put("success", true);
		return model;
	}
	
	@ResponseBody
	@RequestMapping("/list-all-resources.do")
	public ResponseModel listAllResources(
			@RequestParam(value="projectId", required=true) String proId) {
		List<PizzaConfigPO> pos = pizzaConfigServices.queryAllByProject(proId);
		
		List<Map<String, Object>> list = new ArrayList<Map<String, Object>>(pos.size());
		for(PizzaConfigPO po : pos) {
			Map<String, Object> item = new HashMap<String, Object>();
			item.put("id", po.getId());
			item.put("group", po.getPizzaGroup());
			item.put("key", po.getPizzaKey());
			item.put("md5", po.getValueMd5());
			item.put("size", po.getValueSize());
			item.put("projectId", po.getProjectId());
			item.put("projectName", po.getProjectName());
			list.add(item);
		}
		ResponseModel model = new ResponseModel();
		model.put("success", true);
		model.put("datas", list);
		return model;
	}

    public void setEnvSyncService(EnvSyncService envSyncService) {
        this.envSyncService = envSyncService;
    }

    public void setPizzaConfigServices(PizzaConfigServices pizzaConfigServices) {
        this.pizzaConfigServices = pizzaConfigServices;
    }
	
}

