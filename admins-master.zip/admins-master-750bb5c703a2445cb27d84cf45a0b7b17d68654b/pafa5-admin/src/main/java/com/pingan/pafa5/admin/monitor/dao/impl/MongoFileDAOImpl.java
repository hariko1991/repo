package com.pingan.pafa5.admin.monitor.dao.impl;

import com.mongodb.DBObject;
import com.mongodb.gridfs.GridFSDBFile;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.monitor.dao.MongoFileDAO;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.gridfs.GridFsTemplate;
import org.springframework.stereotype.Repository;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.List;

@Nosql
@Repository
public class MongoFileDAOImpl implements MongoFileDAO {
	
	@Autowired
	private GridFsTemplate fsTemplate;
	
	public void insertOrUpdateFile(InputStream content, String filename) throws IOException {
		if (StringUtils.isBlank(filename)) {
			throw new IllegalArgumentException("filename is null or blank");
		}
		if (content == null || content.available() <= 0) {
			throw new IllegalArgumentException("inputstream is null or unavailable");
		}
		fsTemplate.store(content, filename);
	}
	
	public void insertOrUpdateFileWithMetadata(InputStream content, String filename, DBObject metadata) 
			throws IOException {
		if (StringUtils.isBlank(filename)) {
			throw new IllegalArgumentException("filename is null or blank");
		}
		if (content == null || content.available() <= 0) {
			throw new IllegalArgumentException("inputstream is null or unavailable");
		}
		fsTemplate.store(content, filename, metadata);
	}
	
	public void dumpOneFileToStreamAccordingToFilename(String filename, OutputStream out) throws IOException {
		if (StringUtils.isBlank(filename)) {
			throw new IllegalArgumentException("filename is null or blank");
		}
		if (out == null) {
			throw new IllegalArgumentException("outputstream is null");
		}
		GridFSDBFile dbFile = fsTemplate.findOne(new Query(Criteria.where("filename").is(filename)));
		if(dbFile != null){
			dbFile.writeTo(out);
		}
	}
	
	public void dumpOneFileToStreamByCriteria(Criteria criteria, OutputStream out) throws IOException {
		if (out == null) {
			throw new IllegalArgumentException("outputstream is null");
		}
		GridFSDBFile dbFile = fsTemplate.findOne(new Query(criteria));
		dbFile.writeTo(out);
	}
	
	public List<GridFSDBFile>  dumpFileListByCriteria(Criteria criteria) throws IOException {
		return fsTemplate.find(new Query(criteria));
	}
	
	public int size(Criteria criteria) throws IOException {
		return fsTemplate.find(new Query(criteria)).size();
		
	}
	
	public void deleteOneFileAccordingToFilename(String filename) {
		if (StringUtils.isBlank(filename)) {
			throw new IllegalArgumentException("filename is null or blank");
		}
		fsTemplate.delete(new Query(Criteria.where("filename").is(filename)));
	}
	
	public void deleteFilesByCriteria(Criteria criteria) {
		if (criteria == null) {
			throw new IllegalArgumentException("delete criteria can't be null, as you can't delete all files once");
		}
		fsTemplate.delete(new Query(criteria));
	}
}
