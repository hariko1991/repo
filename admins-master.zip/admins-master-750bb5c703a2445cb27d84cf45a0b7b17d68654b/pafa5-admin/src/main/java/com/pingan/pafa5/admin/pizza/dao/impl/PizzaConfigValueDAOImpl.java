package com.pingan.pafa5.admin.pizza.dao.impl;

import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.commons.SARManagerConstants;
import com.pingan.pafa5.admin.pizza.dao.PizzaConfigValueDAO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigValuePO;

@Nosql
@Repository
public class PizzaConfigValueDAOImpl extends  BaseMongoDAO<PizzaConfigValuePO> implements PizzaConfigValueDAO {

    @Override
    public PizzaConfigValuePO get(String id) {
        return this._getById(id);
    }

    @Override
    public void save(PizzaConfigValuePO po) {
       this._save(po);
    }

    @Override
    public void update(PizzaConfigValuePO po) {
        this._updateById(po);
    }
    
    @Override
	public boolean del(String proId, String group,String key) {
		if (proId == null) {
			return del(group, key);
		}
		String id=proId + "/" +group+"/"+key;
		return this._removeById(id);
	}

	@Override
	public boolean del(String group,String key) {
		String id=group+"/"+key;
		return this._removeById(id);
	}
	
}
