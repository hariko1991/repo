package com.pingan.pafa5.admin.fling.services.impl;

import java.text.DateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.ui.ModelMap;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.fling.dao.FlingPappInstanceDAO;
import com.pingan.pafa5.admin.fling.dao.FlingPappMonitorMsgDAO;
import com.pingan.pafa5.admin.fling.dao.FlingSARInstanceDAO;
import com.pingan.pafa5.admin.fling.dao.FlingSARMonitorMsgDAO;
import com.pingan.pafa5.admin.fling.dto.InstanceDTO;
import com.pingan.pafa5.admin.fling.po.FlingPappInstancePO;
import com.pingan.pafa5.admin.fling.po.FlingPappMonitorMsgPO;
import com.pingan.pafa5.admin.fling.po.FlingSARInstancePO;
import com.pingan.pafa5.admin.fling.po.FlingSARMonitorMsgPO;
import com.pingan.pafa5.admin.fling.services.InstanceServices;

@Service
public class InstanceServicesImpl extends BaseServices implements InstanceServices{
	
	@Autowired
	private FlingPappInstanceDAO flingPappInstanceDAO;
	
	@Autowired
	private FlingSARInstanceDAO flingSARInstanceDAO;
	
	@Autowired
	private FlingPappMonitorMsgDAO flingPappMonitorMsgDAO;
	
	@Autowired
	private FlingSARMonitorMsgDAO flingSARMonitorMsgDAO;
	
	@Value("${instance.heartbeat.expired}")
	private int heartbeatExpired=3*60*1000;

	@Override
	public List<FlingPappInstancePO> listForPapp(String projectId,String pappName) {
		if(pappName==null || (pappName=pappName.trim()).length()==0){
			throw new NullPointerException("pappName is null");
		}
		List<FlingPappInstancePO> pos= flingPappInstanceDAO.list(projectId,pappName);

		for(FlingPappInstancePO po:pos){
			if(po.getStatus()==0){
				long lastActiveTime=po.getLastActiveTimestamp();
				if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
					po.setStatus(3);
				}
			}
		}
		return pos;
	}
	
	@Override
	public List<String> listForPappIp(String projectId,String pappName) {
		if(pappName==null || (pappName=pappName.trim()).length()==0){
			throw new NullPointerException("pappName is null");
		}
		List<FlingPappInstancePO> pos= flingPappInstanceDAO.list(projectId,pappName);
		List<String> list = new ArrayList<String>();
		for(FlingPappInstancePO po : pos) {
			list.add(po.getInstanceIp());
		}
		return list;
	}
	
	@Override
	public List<FlingPappInstancePO> listForPapp(int status) {
		List<FlingPappInstancePO> pos= flingPappInstanceDAO.list(status);

		for(FlingPappInstancePO po:pos){
			if(po.getStatus()==0){
				long lastActiveTime=po.getLastActiveTimestamp();
				if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
					po.setStatus(3);
				}
			}
		}
		return pos;
	}
	
	@Override
	public PageDataDTO<FlingPappInstancePO> listForPapp(String projectId,String pappName, int limit, int page) {
		if("def".equals(projectId)) {
			projectId = null;
		}
		
		PageDataDTO<FlingPappInstancePO> pageDataDTO = new PageDataDTO<FlingPappInstancePO>();
		List<FlingPappInstancePO> pos= flingPappInstanceDAO.list(projectId,pappName, limit, page);
		for(FlingPappInstancePO po:pos){
			if(po.getStatus()==0){
				long lastActiveTime=po.getLastActiveTimestamp();
				if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
					po.setStatus(3);
				}
			}
		}
		pageDataDTO.setDatas(pos);
		
		long totalSize = flingPappInstanceDAO.getPappCount(projectId,pappName);
		pageDataDTO.setTotalSize(totalSize);
		
		return pageDataDTO;
	}
	
	@Override
	public List<FlingPappInstancePO> listForPapp1(String projectId,String pappName) {
		List<FlingPappInstancePO> pos= flingPappInstanceDAO.list(projectId,pappName);
		List<FlingPappInstancePO> instanceOut = new ArrayList<FlingPappInstancePO>();
		for(FlingPappInstancePO po:pos){
			if(po.getStatus()==0){
				long lastActiveTime=po.getLastActiveTimestamp();
				if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
					po.setStatus(3);
				}
			}
		}
		for(FlingPappInstancePO po:pos){
			if(po.getStatus()!=0)
				instanceOut.add(po);
		}
		for(FlingPappInstancePO po:pos){
			if(po.getStatus()==0)
				instanceOut.add(po);
		}
		return instanceOut;
	}
	
	@Override
	public PageDataDTO<FlingPappInstancePO> listForPapp(int status, int limit, int page) {
		PageDataDTO<FlingPappInstancePO> pageDataDTO = new PageDataDTO<FlingPappInstancePO>();
		
		List<FlingPappInstancePO> instances= flingPappInstanceDAO.list(status, limit, page);
		if(instances==null || instances.size()==0){
			return pageDataDTO;
		}
		pageDataDTO.setDatas(instances);
		for(FlingPappInstancePO po:instances){
			if(po.getStatus()==0){
				long lastActiveTime=po.getLastActiveTimestamp();
				if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
					po.setStatus(3);
				}
			}
		}
		
		long count = flingPappInstanceDAO.getPappCount(status,null);
		pageDataDTO.setTotalSize(count);
		return pageDataDTO;
	}
	
	@Override
	public FlingPappMonitorMsgPO getInstanceDetails(String projectId,String pappName,
			String instanceIp) {
		if(pappName==null || (pappName=pappName.trim()).length()==0){
			throw new NullPointerException("pappName is null");
		}
		if(instanceIp==null || (instanceIp=instanceIp.trim()).length()==0){
			throw new NullPointerException("instanceIp is null");
		}
		FlingPappMonitorMsgPO po=flingPappMonitorMsgDAO.getLast(pappName, instanceIp);
		return po;
	}
	
	@Override
	public ModelMap getInstanceDetails(String projectId,String pappName,String sarName,
			String instanceIp) {
		if(pappName==null || (pappName=pappName.trim()).length()==0){
			return new ModelMap();
		}
		if(instanceIp==null || (instanceIp=instanceIp.trim()).length()==0){
			return new ModelMap();
		}
		FlingPappMonitorMsgPO po = new FlingPappMonitorMsgPO();
		FlingSARMonitorMsgPO poSar = new FlingSARMonitorMsgPO();
		ModelMap map = new ModelMap();
		if(sarName==null || (sarName=sarName.trim()).length()==0){
			po=flingPappMonitorMsgDAO.getLast(pappName, instanceIp);
			map = POUtils.toMap(po);
			DateFormat formatter = null;
			formatter = DateFormat.getDateTimeInstance();
			map.remove("createdTimestamp");//
			map.put("createdTime", formatter.format(new Date(po.getCreatedTimestamp())));
		}else{
			po=flingPappMonitorMsgDAO.getLast(pappName, instanceIp);
			poSar=flingSARMonitorMsgDAO.getLast(pappName, sarName, instanceIp);
			map = POUtils.toMap(po);
			DateFormat formatter = null;
			formatter = DateFormat.getDateTimeInstance();
			map.remove("createdTimestamp");//
			//map.remove("eventName");
			//map.remove("eventTimestamp");
			map.put("createdTime", formatter.format(new Date(po.getCreatedTimestamp())));
			map.put("sarName",poSar.getSarName());
			//map.put("eventName",poSar.getEventName());
			//map.put("eventTimestamp",poSar.getEventTimestamp());
		}
		
		return map;
	}
	
	@Override
	public FlingPappMonitorMsgPO getInstanceDetails(int status,String pappName,
			String instanceIp) {
		if(pappName==null || (pappName=pappName.trim()).length()==0){
			throw new NullPointerException("pappName is null");
		}
		if(instanceIp==null || (instanceIp=instanceIp.trim()).length()==0){
			throw new NullPointerException("instanceIp is null");
		}
		FlingPappMonitorMsgPO po=flingPappMonitorMsgDAO.getLast(pappName, instanceIp);
		return po;
	}

	@Override
	public List<FlingPappMonitorMsgPO> listInstanceDetails(String projectId,String pappName,
			String instanceIp) {
		if(pappName==null || (pappName=pappName.trim()).length()==0){
			throw new NullPointerException("pappName is null");
		}
		if(instanceIp!=null && (instanceIp=instanceIp.trim()).length()!=0){
			FlingPappMonitorMsgPO po=flingPappMonitorMsgDAO.getLast(pappName, instanceIp);
			if(po==null){
				return null;
			}else{
				return Arrays.asList(po);
			}
		}else{
			List<String> ips=flingPappInstanceDAO.listInstanceIps(projectId,pappName);
			if(ips==null || ips.size()==0){
				return null;
			}else{
				List<FlingPappMonitorMsgPO> list=new ArrayList<FlingPappMonitorMsgPO>();
				for(String ip:ips){
					FlingPappMonitorMsgPO po=flingPappMonitorMsgDAO.getLast(pappName, ip);
					if(po!=null){
						list.add(po);
					}
				}
				return list;
			}
		}
	}

	@Override
	public List<FlingSARInstancePO> listForSAR(String projectId,String sarName, String pappName) {
 
		List<FlingSARInstancePO> instances= flingSARInstanceDAO.list(projectId,pappName,sarName);
		if(instances==null || instances.size()==0){
			return null;
		}
		for(FlingSARInstancePO po:instances){
			if(po.getStatus()==0){
				if(!flingPappInstanceDAO.checkValid(po.getAppName(), po.getInstanceIp(), heartbeatExpired)){
					po.setStatus(3);
				}
			}
			if(po.getStatus()==1){
				long lastActiveTime=po.getLastActiveTimestamp();
				if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
					po.setStatus(3);
					po.setCreatedBy("组件已是停止状态-心跳过期");
				}
			}
		}
		return instances;
	}
	
	@Override
	public List<FlingSARInstancePO> listForSAR(int status) {
 
		List<FlingSARInstancePO> instances= flingSARInstanceDAO.list(status);
		if(instances==null || instances.size()==0){
			return null;
		}
		for(FlingSARInstancePO po:instances){
			if(po.getStatus()==0){
				if(!flingPappInstanceDAO.checkValid(po.getAppName(), po.getInstanceIp(), heartbeatExpired)){
					po.setStatus(3);
				}
			}
			if(po.getStatus()==1){
				long lastActiveTime=po.getLastActiveTimestamp();
				if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
					po.setStatus(3);
					po.setCreatedBy("组件已是停止状态-心跳过期");
				}
			}
		}
		return instances;
	}

	@Override
	public PageDataDTO<FlingSARInstancePO> listForSAR(String projectId,String sarName, 
			String pappName, int limit, int page) {
		PageDataDTO<FlingSARInstancePO> pageDataDTO = new PageDataDTO<FlingSARInstancePO>();
		
		List<FlingSARInstancePO> instances= flingSARInstanceDAO.list(projectId,sarName, pappName, limit, page);
		if(instances==null || instances.size()==0){
			return pageDataDTO;
		}
				
		pageDataDTO.setDatas(instances);
		for(FlingSARInstancePO po:instances){
			if(po.getStatus()==0){
				if(!flingPappInstanceDAO.checkValid(po.getAppName(), po.getInstanceIp(), heartbeatExpired)){
					po.setStatus(3);
				}
			}
			if(po.getStatus()==1){
				long lastActiveTime=po.getLastActiveTimestamp();
				if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
					po.setStatus(3);
					po.setCreatedBy("组件已是停止状态-心跳过期");
				}
			}
		}
		
		long count = flingSARInstanceDAO.getSarCount(projectId,sarName, pappName);
		pageDataDTO.setTotalSize(count);
		return pageDataDTO;
	}
	
	@Override
	public PageDataDTO<FlingSARInstancePO> listForSAR(String instanceIp, String projectId,String sarName, 
			String pappName, int limit, int page) {
		PageDataDTO<FlingSARInstancePO> pageDataDTO = new PageDataDTO<FlingSARInstancePO>();
		
		List<FlingSARInstancePO> instances= flingSARInstanceDAO.list(instanceIp, projectId,sarName, pappName, limit, page);
		if(instances==null || instances.size()==0){
			return pageDataDTO;
		}
				
		pageDataDTO.setDatas(instances);
		for(FlingSARInstancePO po:instances){
			if(po.getStatus()==0){
				if(!flingPappInstanceDAO.checkValid(po.getAppName(), po.getInstanceIp(), heartbeatExpired)){
					po.setStatus(3);
				}
			}
			if(po.getStatus()==1){
				long lastActiveTime=po.getLastActiveTimestamp();
				if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
					po.setStatus(3);
					po.setCreatedBy("组件已是停止状态-心跳过期");
				}
			}
		}
		
		long count = flingSARInstanceDAO.getSarCount(projectId,sarName, pappName);
		pageDataDTO.setTotalSize(count);
		return pageDataDTO;
	}
	
	@Override
	public List<FlingSARInstancePO> listForSAR(String instanceIp, String projectId,String sarName, String pappName) {
		
		List<FlingSARInstancePO> instances= flingSARInstanceDAO.list(instanceIp, projectId,sarName, pappName);
		List<FlingSARInstancePO> instanceOut = new ArrayList<FlingSARInstancePO>();
		if(instances==null || instances.size()==0){
			return instanceOut;
		}
				
		for(FlingSARInstancePO po:instances){
			if(po.getStatus()==0){
				if(!flingPappInstanceDAO.checkValid(po.getAppName(), po.getInstanceIp(), heartbeatExpired)){
					po.setStatus(3);
				}
			}
			if(po.getStatus()==1){
				long lastActiveTime=po.getLastActiveTimestamp();
				if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
					po.setStatus(3);
					po.setCreatedBy("组件已是停止状态-心跳过期");
				}
			}
		}
		
		for(FlingSARInstancePO po:instances){
			if(po.getStatus()!=0)
				instanceOut.add(po);
		}
		for(FlingSARInstancePO po:instances){
			if(po.getStatus()==0)
				instanceOut.add(po);
		}
		
		return instanceOut;
	}
	
	@Override
	public PageDataDTO<FlingSARInstancePO> listForSAR(int status, int limit, int page) {
		PageDataDTO<FlingSARInstancePO> pageDataDTO = new PageDataDTO<FlingSARInstancePO>();
		
		List<FlingSARInstancePO> instances= flingSARInstanceDAO.list(status, limit, page);
		if(instances==null || instances.size()==0){
			return pageDataDTO;
		}
				
		pageDataDTO.setDatas(instances);
		for(FlingSARInstancePO po:instances){
			if(po.getStatus()==0){
				if(!flingPappInstanceDAO.checkValid(po.getAppName(), po.getInstanceIp(), heartbeatExpired)){
					po.setStatus(3);
				}
			}
			if(po.getStatus()==1){
				long lastActiveTime=po.getLastActiveTimestamp();
				if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
					po.setStatus(3);
					po.setCreatedBy("组件已是停止状态-心跳过期");
				}
			}
		}
		
		long count = flingSARInstanceDAO.getSarCount(status);
		pageDataDTO.setTotalSize(count);
		return pageDataDTO;
	}

	public void setHeartbeatExpired(int heartbeatExpired) {
		this.heartbeatExpired = heartbeatExpired;
	}

	@Override
	public FlingPappInstancePO detailForPapp(String pappName, String instanceIp) {
		if(pappName==null || (pappName=pappName.trim()).length()==0){
			throw new NullPointerException("pappName is null");
		}
		if(instanceIp==null || (instanceIp=instanceIp.trim()).length()==0){
			throw new NullPointerException("instanceIp is null");
		}
		return flingPappInstanceDAO.getFlingPappInstancePO(pappName, instanceIp);
	}

	@Override
	public FlingSARInstancePO detailForSar(String sarName, String instanceIp) {
		if(sarName==null || (sarName=sarName.trim()).length()==0){
			throw new NullPointerException("sarName is null");
		}
		if(instanceIp==null || (instanceIp=instanceIp.trim()).length()==0){
			throw new NullPointerException("instanceIp is null");
		}
		return flingSARInstanceDAO.getFlingSarInstancePO(sarName, instanceIp);
	}
	
	@Override
	public boolean deletePapp(String projectId,String pappName, String instanceIp) {
		if(projectId==null || (projectId=projectId.trim()).length()==0){
			throw new NullPointerException("projectId is null");
		}
		if(pappName==null || (pappName=pappName.trim()).length()==0){
			throw new NullPointerException("pappName is null");
		}
		if(instanceIp==null || (instanceIp=instanceIp.trim()).length()==0){
			throw new NullPointerException("instanceIp is null");
		}
		return flingPappInstanceDAO.delete(projectId,pappName, instanceIp);
	}
	
	@Override
	@Transactional
	public boolean deleteSar(String projectId ,String sarName, String instanceIp, String pappName) {
		String projectId01[] = projectId.split(",");
		String sarName01[] = sarName.split(",");
		String instanceIp01[] = instanceIp.split(",");
		String pappName01[] = pappName.split(",");
		boolean a;
		for(int i = 0;i<projectId01.length;i++){
			if(projectId01[i]==null || (projectId01[i]=projectId01[i].trim()).length()==0){
				throw new NullPointerException("projectId is null");
			}
			if(sarName01[i]==null || (sarName01[i]=sarName01[i].trim()).length()==0){
				throw new NullPointerException("sarName is null");
			}
			if(instanceIp01[i]==null || (instanceIp01[i]=instanceIp01[i].trim()).length()==0){
				throw new NullPointerException("instanceIp is null");
			}
			a = flingSARInstanceDAO.delete(projectId01[i],sarName01[i], instanceIp01[i],pappName01[i]);
			if(a==false){
				return false;
			}
		}
		return true;
 		
		
		
//		if(projectId==null || (projectId=projectId.trim()).length()==0){
//			throw new NullPointerException("projectId is null");
//		}
//		if(sarName==null || (sarName=sarName.trim()).length()==0){
//			throw new NullPointerException("sarName is null");
//		}
//		if(instanceIp==null || (instanceIp=instanceIp.trim()).length()==0){
//			throw new NullPointerException("instanceIp is null");
//		}
//		return flingSARInstanceDAO.delete(projectId,sarName, instanceIp);
	}
	
	public void setFlingPappInstanceDAO(FlingPappInstanceDAO flingPappInstanceDAO) {
        this.flingPappInstanceDAO = flingPappInstanceDAO;
    }

    public void setFlingSARInstanceDAO(FlingSARInstanceDAO flingSARInstanceDAO) {
        this.flingSARInstanceDAO = flingSARInstanceDAO;
    }

    public void setFlingPappMonitorMsgDAO(
            FlingPappMonitorMsgDAO flingPappMonitorMsgDAO) {
        this.flingPappMonitorMsgDAO = flingPappMonitorMsgDAO;
    }

    public int getHeartbeatExpired() {
        return heartbeatExpired;
    }

	@Override
	public List<FlingPappInstancePO> getPappInstanceByIp(String instanceIp) {
		if(instanceIp==null || (instanceIp.trim()).length()==0){
			throw new NullPointerException("instanceIp is null");
		}
		List<FlingPappInstancePO> pos= flingPappInstanceDAO.list(instanceIp);

		for(FlingPappInstancePO po:pos){
			if(po.getStatus()==0){
				long lastActiveTime=po.getLastActiveTimestamp();
				if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
					po.setStatus(3);
				}
			}
		}
		return pos;
	}
	


	@Override
	public PageDataDTO<FlingSARInstancePO> getSarInstanceByIp(String instanceIp, int pageSizeSar, int pageNumSar) {
		PageDataDTO<FlingSARInstancePO> pageDataDTO = new PageDataDTO<FlingSARInstancePO>();
		
		List<FlingSARInstancePO> instances= flingSARInstanceDAO.list(instanceIp, pageSizeSar, pageNumSar);
		if(instances==null || instances.size()==0){
			return pageDataDTO;
		}
				
		pageDataDTO.setDatas(instances);
		for(FlingSARInstancePO po:instances){
			if(po.getStatus()==0){
				if(!flingPappInstanceDAO.checkValid(po.getAppName(), po.getInstanceIp(), heartbeatExpired)){
					po.setStatus(3);
				}
			}
			if(po.getStatus()==1){
				long lastActiveTime=po.getLastActiveTimestamp();
				if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
					po.setStatus(3);
					po.setCreatedBy("组件已是停止状态-心跳过期");
				}
			}
		}
		
		long count = flingSARInstanceDAO.getSarCount(instanceIp);
		pageDataDTO.setTotalSize(count);
		return pageDataDTO;
	}
	
	@Override
	public PageDataDTO<FlingSARInstancePO> getSarInstanceByIp(String instanceIp,String projectId, int pageSizeSar, int pageNumSar) {
		PageDataDTO<FlingSARInstancePO> pageDataDTO = new PageDataDTO<FlingSARInstancePO>();
		
		List<FlingSARInstancePO> instances= flingSARInstanceDAO.list(instanceIp, pageSizeSar, pageNumSar);
		if(instances==null || instances.size()==0){
			return pageDataDTO;
		}
				
		pageDataDTO.setDatas(instances);
		for(FlingSARInstancePO po:instances){
			if(po.getStatus()==0){
				if(!flingPappInstanceDAO.checkValid(po.getAppName(), po.getInstanceIp(), heartbeatExpired)){
					po.setStatus(3);
				}
			}
			if(po.getStatus()==1){
				long lastActiveTime=po.getLastActiveTimestamp();
				if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
					po.setStatus(3);
					po.setCreatedBy("组件已是停止状态-心跳过期");
				}
			}
		}
		
		long count = flingSARInstanceDAO.getSarCount(instanceIp);
		pageDataDTO.setTotalSize(count);
		return pageDataDTO;
	}
	
	
	
	@Override
	public boolean checkSarExistence(String sarName) {
		
		boolean result = flingSARInstanceDAO.checkSarExistenceByName(sarName);
		
		return result;
	}
	@Override
	public List<FlingPappInstancePO> listPappSearchResult(String projectId,
			String searchField) {
		List<FlingPappInstancePO> instance = flingPappInstanceDAO.listPappSearchResult(projectId,searchField);
		List<FlingPappInstancePO> normalInstances= new ArrayList<FlingPappInstancePO>();
		List<FlingPappInstancePO> abnormalInstances= new ArrayList<FlingPappInstancePO>();
		List<FlingPappInstancePO> instancesAll= new ArrayList<FlingPappInstancePO>();
		for(FlingPappInstancePO po:instance){
			if(po.getStatus()==0){
				long lastActiveTime=po.getLastActiveTimestamp();
				if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
					po.setStatus(3);
					abnormalInstances.add(po);
				}else{
					normalInstances.add(po);
				}
			}else{
				abnormalInstances.add(po);
			}
		}
		instancesAll.addAll(abnormalInstances);
		instancesAll.addAll(normalInstances);
		
		
		return instancesAll;
	}
	@Override
	public List<FlingSARInstancePO> listSarSearchResult(String projectId,
			String searchField) {
		List<FlingSARInstancePO> instance = flingSARInstanceDAO.listSarSearchResult(projectId,searchField);
		List<FlingSARInstancePO> normalInstances= new ArrayList<FlingSARInstancePO>();
		List<FlingSARInstancePO> abnormalInstances= new ArrayList<FlingSARInstancePO>();
		List<FlingSARInstancePO> instancesAll= new ArrayList<FlingSARInstancePO>();
		for(FlingSARInstancePO po:instance){
			if(po.getStatus()==0){
				if(!flingPappInstanceDAO.checkValid(po.getAppName(), po.getInstanceIp(), heartbeatExpired)){
					po.setStatus(3);
					abnormalInstances.add(po);
				}else{
					normalInstances.add(po);
				}
			}else{
				abnormalInstances.add(po);
			}
		}
		instancesAll.addAll(abnormalInstances);
		instancesAll.addAll(normalInstances);
		
		
		return instancesAll;
	}
	@Override
	public List<FlingPappInstancePO> listPappIndexPage(String projectId){
		List<FlingPappInstancePO> instance = flingPappInstanceDAO.listPappIndexPage(projectId);
		List<FlingPappInstancePO> normalInstances= new ArrayList<FlingPappInstancePO>();
		List<FlingPappInstancePO> abnormalInstances= new ArrayList<FlingPappInstancePO>();
		List<FlingPappInstancePO> instancesAll= new ArrayList<FlingPappInstancePO>();
		for(FlingPappInstancePO po:instance){
			if(po.getStatus()==0){
				long lastActiveTime=po.getLastActiveTimestamp();
				if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
					po.setStatus(3);
					abnormalInstances.add(po);
				}else{
					normalInstances.add(po);
				}
			}else{
				abnormalInstances.add(po);
			}
		}
		instancesAll.addAll(abnormalInstances);
		instancesAll.addAll(normalInstances);
		
		
		return instancesAll;
	}

	@Override
	public List<InstanceDTO> listForProjectId(String projectId,String instanceIp) {
		List<InstanceDTO> instanceDTOs = new ArrayList<InstanceDTO>();
		
		List<FlingPappInstancePO> instances = flingPappInstanceDAO.listPappIndexPage(projectId,instanceIp);
		if(instances!=null&&instances.size()>0) {
			Map<String,InstanceDTO> ipmaps = new HashMap<String, InstanceDTO>();
			InstanceDTO instanceDTO = null;
			for (FlingPappInstancePO flingPappInstancePO : instances) {
				instanceDTO = new InstanceDTO();
				instanceDTO.setInstanceIp(flingPappInstancePO.getInstanceIp());
				instanceDTO.setProjectId(projectId);
				
				if(flingPappInstancePO.getStatus()==0){
					long lastActiveTime=flingPappInstancePO.getLastActiveTimestamp();
					if(lastActiveTime<System.currentTimeMillis()-heartbeatExpired){
						flingPappInstancePO.setStatus(3);
					}
				}
				
				instanceDTO.setStatus(flingPappInstancePO.getStatus());
				if(ipmaps.containsKey(flingPappInstancePO.getInstanceIp())) {
					
					InstanceDTO oldIn = ipmaps.get(flingPappInstancePO.getInstanceIp());
					String oldPappName = oldIn.getPappName();
					if(!oldPappName.contains(flingPappInstancePO.getAppName())){
						instanceDTO.setPappName(oldPappName+","+flingPappInstancePO.getAppName());
					}
					instanceDTOs.remove(oldIn);
					instanceDTOs.add(instanceDTO);
				}else {
					//instanceDTO = new InstanceDTO();
					//instanceDTO.setInstanceIp(flingPappInstancePO.getInstanceIp());
					//instanceDTO.setProjectId(projectId);
					instanceDTO.setPappName(flingPappInstancePO.getAppName());
					ipmaps.put(flingPappInstancePO.getInstanceIp(), instanceDTO);
					instanceDTOs.add(instanceDTO);
				}
			}
			ipmaps.clear();
			ipmaps = null;
		}
		return instanceDTOs;
	}
}
