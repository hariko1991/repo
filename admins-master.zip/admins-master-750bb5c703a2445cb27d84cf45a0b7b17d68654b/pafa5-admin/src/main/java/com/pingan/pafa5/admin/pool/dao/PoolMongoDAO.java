package com.pingan.pafa5.admin.pool.dao;

import java.util.List;

import com.pingan.pafa5.admin.pool.po.PoolMongoPO;

public interface PoolMongoDAO extends PoolDAO {

	public abstract List<PoolMongoPO> list(String pizzaKey, String projectId,
			int limit, int page);

	public abstract PoolMongoPO getById(String pizzaKey);

}