package com.pingan.pafa5.admin.monitor.dao.impl;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa.mongodb.MongoPagination;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.monitor.dao.StatisMongoDAO;
import com.pingan.pafa5.admin.monitor.dtos.StatisticsDTO;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import java.util.List;

@Nosql
@Repository
public class StatisMongoDAOImpl extends BaseMongoDAO<StatisticsDTO> implements StatisMongoDAO {

	public StatisMongoDAOImpl() {
		
	}
	
	public void add(StatisticsDTO sti){
		this._add(sti);
	} 
	
	public int removeByProperty(String name ,String value){
		return this._removeByProperty(name, value);
	}
	
	public int removeByDate(String name ,String value){
		return _remove(Criteria.where(name).lt(value));
	}
	
	public boolean updateByProperty(String name,String value,StatisticsDTO sta){
		return this._updateByProperty(name, value, sta);
	}
	
	public StatisticsDTO getByProperty(String name,String value){
		return this._get(where(name).is(value));
	}
	public StatisticsDTO getByPropertys(String name,String value,String name2,String value2){
		return this._get(where(name).is(value).and(name2).is(value2));
	}
	
	public List<StatisticsDTO> listByProperty(String name,String value){
		return this._list(where(name).is(value));
	}
	public List<StatisticsDTO> listByType(String value,String value2,String value3,String value4){
		return this._list(where("service").is(value).and("methodName").is(value2).and("creatTime").is(value3).and("type").is(value4));
	}
	public List<StatisticsDTO> listByValues(String name,String value,String name2,String value2,String name3,String value3){
		return this._list(where(name).is(value).and(name2).is(value2).and(name3).is(value3));
	}
	public List<StatisticsDTO> listByPropertys(String name,String value,String name2,String value2){
		return this._list(where(name).is(value).and(name2).is(value2));
	}
	
	public MongoPagination<StatisticsDTO>  paginated(MongoPagination<StatisticsDTO> page,String name,String value){
		return this._paginated(where(name).is(value), page);
	}
	
	public long size(){
		return this._count(null);
	}

}
