package com.pingan.pafa5.admin.monitor.dao.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.monitor.dao.DubboStatisticsDAO;
import com.pingan.pafa5.admin.monitor.po.DubboStatisticsPO;

@Nosql
@Repository
public class DubboStatisticsDAOImpl extends BaseMongoDAO<DubboStatisticsPO> implements DubboStatisticsDAO {

    @Override
    public void save(DubboStatisticsPO po) {
        this._save(po);        
    }

    @Override
    public long count(String interfaceName, Date beginDate, Date endDate) {
        Criteria criteria = this.where("createTime").gte(beginDate).lt(endDate);
        if(StringUtils.isNotEmpty(interfaceName)) {
            criteria.and("interfaceName").is(interfaceName);
        }
        return this._count(criteria);
    }

    @Override
    public List<DubboStatisticsPO> list(String interfaceName, Date beginDate, Date endDate, int skip, int limit) {
        Criteria criteria = this.where("createTime").gte(beginDate).lt(endDate);
        if(StringUtils.isNotEmpty(interfaceName)) {
            criteria.and("interfaceName").is(interfaceName);
        }
        return this._list(criteria, skip, limit);
    }
    
    @Override
    public List<DubboStatisticsPO> list(Date createTime) {
    	long stime = createTime.getTime()-(30*60*1000);
        Criteria criteria = this.where("createTime").gte(new Date(stime)).lt(createTime);
        return this._list(criteria);
    }

    @Override
    public void removeByCreateTime(Date createTime) {
    	Criteria criteria = this.where("createTime").lt(createTime);
        this._remove(criteria);
    }

	@Override
	public void removeById(String id) {
		this._removeById(new ObjectId(id));
	}

}
