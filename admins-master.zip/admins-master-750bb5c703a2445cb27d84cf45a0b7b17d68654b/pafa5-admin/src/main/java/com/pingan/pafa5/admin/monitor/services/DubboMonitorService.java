package com.pingan.pafa5.admin.monitor.services;

import java.util.List;

import com.pingan.pafa5.admin.monitor.po.DubboInterfacePO;
import com.pingan.pafa5.admin.monitor.po.DubboMethodPO;
import com.pingan.pafa5.admin.monitor.po.DubboStatisticsPO;

/**
 * @author ZHANGJIAWEI370
 *
 */
public interface DubboMonitorService {
    
    /**
     * 
     * @param likeName
     * @param relDate
     * @param type
     * @return
     */
    long countMethod(String likeName, String relDate, String type);
    
    /**
     * 
     * @param likeName
     * @param relDate
     * @param type
     * @param page
     * @param limit
     * @return
     */
    List<DubboMethodPO> listMethod(String likeName, String relDate, String type, int page, int limit);
    
    /**
     * 
     * @param logDay
     * @param interfaceName
     * @return
     */
    long countInterface(String startTime,String endTime, String interfaceName);
    
    /**
     * 
     * @param logDay
     * @param interfaceName
     * @param page
     * @param limit
     * @return
     */
    List<DubboInterfacePO> listInterface(String startTime,String endTime, String interfaceName, int page, int limit);
    
    /**
     * 
     * @param logDay
     * @param interfaceName
     * @return
     */
    long countStatistics(String logDay, String interfaceName);
    
    /**
     * 
     * @param logDay
     * @param interfaceName
     * @param page
     * @param limit
     * @return
     */
    List<DubboStatisticsPO> listStatistics(String logDay, String interfaceName, int page, int limit);

    /**
     * 清理过期信息
     */
    void cleanData();
    
    /**
     * 计算接口调用信息
     */
    void calculateData();
    
}
