package com.pingan.pafa5.admin.pizza.dao.impl;

import java.util.List;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dao.PizzaOperationLogDAO;
import com.pingan.pafa5.admin.pizza.dto.OperationLogSearchDTO;
import com.pingan.pafa5.admin.pizza.po.PizzaOperationLogPO;

@Nosql
@Repository
public class PizzaOperationLogDAOImpl extends BaseMongoDAO<PizzaOperationLogPO> implements
        PizzaOperationLogDAO {

    @Override
    public PizzaOperationLogPO getById(String id) {
        return this._getById(id);
    }

    @Override
    public String add(PizzaOperationLogPO logDTO) {
        this._add(logDTO);
        return logDTO.getId();
    }

    @Override
    public void completed(String operationId) {
        this._update(Criteria.where("id").is(operationId),
                new Update().set("status", PizzaOperationLogPO.STATUS_COMPLETED));
    }
  
    @Override
    public PageDataDTO<PizzaOperationLogPO> pageQuery(OperationLogSearchDTO queryDTO) {
        PageDataDTO<PizzaOperationLogPO> pageDataDTO = new PageDataDTO<PizzaOperationLogPO>();
        Criteria where = new Criteria();
        String opType = queryDTO.getOperationType();
        if (opType != null && (opType = opType.trim()).length() > 0) {
            where.and("operationType").is(opType);
        }
        int skip = (queryDTO.getPage() - 1) * queryDTO.getLimit();
        List<PizzaOperationLogPO> datas =
                this._listAndDesc(where, skip, queryDTO.getLimit(), "createdDate");
        pageDataDTO.setDatas(datas);

        long count = this._count(where);
        pageDataDTO.setTotalSize(count);

        return pageDataDTO;
    }

    @Override
    public void updateStatus(PizzaOperationLogPO logDto) {
        this._update(Criteria.where("id").is(logDto.getId()),
                new Update().set("status", logDto.getStatus()));
    }

}
