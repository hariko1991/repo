package com.pingan.pafa5.admin.pizza.services;

import java.util.List;
import java.util.Map;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dto.EnvSyncLogDTO;
import com.pingan.pafa5.admin.pizza.po.EnvSyncFailurePO;

/**
 * 跨环境同步服务
 * @author ZHANGJIAWEI370
 *
 */
public interface EnvSyncService {

	/**
	 * 查询操作记录列表
	 * @param queryParams
	 * @param page
	 * @param limit
	 * @return
	 */
	public PageDataDTO<EnvSyncLogDTO> list(Map<String,Object> queryParams, int page, int limit);

	/**
	 * 查询操作记录
	 * @param id
	 * @return
	 */
	public EnvSyncLogDTO findLog(String id);

	/**
	 * 同步环境数据
	 * @param domainId
	 * @param domainName
	 * @param uri
	 * @param loginUser
	 * @param loginPwd
	 */
	public void manulSync(String domainId, String domainName, String uri, String loginUser, String loginPwd);

	/**
	 * 查询错误原因
	 * @param syncId
	 * @return
	 */
	public List<EnvSyncFailurePO> getFailuers(String syncId);

	/**
	 * 测试环境连通性
	 * @param uri
	 * @param loginUser
	 * @param loginPwd
	 * @return
	 */
	public boolean testLink(String uri, String loginUser, String loginPwd);

}