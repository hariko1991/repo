package com.pingan.pafa5.admin.fling.web;

import java.io.File;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutionException;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.job.TimerJob;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.fling.dto.InstanceDTO;
import com.pingan.pafa5.admin.fling.po.FlingPappInstancePO;
import com.pingan.pafa5.admin.fling.po.FlingPappMonitorMsgPO;
import com.pingan.pafa5.admin.fling.po.FlingSARInstancePO;
import com.pingan.pafa5.admin.fling.services.InstanceServices;
import com.pingan.pafa5.admin.fling.services.ServiceDetectionService;
import com.pingan.pafa5.admin.papp.dto.SarDTO;

@Controller
@RequestMapping("/fling")
public class InstancesController extends BaseController {

    @Autowired
    private InstanceServices instanceServices;

    @RequestMapping("/list-papp-instances.do")
    @ResponseBody
    public ResponseModel listForPapp(@RequestParam("projectId") String projectId,
            @RequestParam("pappName") String pappName, 
            @RequestParam(value = "formatDate", defaultValue = "true") boolean formatDate) {

        List<FlingPappInstancePO> pos = instanceServices.listForPapp(projectId, pappName);
        if (pos == null || pos.size() == 0) {
            return new ResponseModel("1", "应用:" + pappName + "未能找到对应节点信息。");
        }
        List<ModelMap> datas = new ArrayList<ModelMap>(pos.size());
        DateFormat formatter = null;
        if (formatDate) {
            formatter = DateFormat.getDateTimeInstance();
        }
        for (FlingPappInstancePO po : pos) {
            ModelMap map = new ModelMap();
            map.put("instanceIp", po.getInstanceIp());
            if (formatDate) {
                map.put("lastActiveTime", formatter.format(new Date(po.getLastActiveTimestamp())));
            } else {
                map.put("lastActiveTime", po.getLastActiveTimestamp());
            }
            map.put("lastActiveObjectId", po.getLastActiveObjectId());
            map.put("lastActiveCause", po.getUpdatedBy());
            map.put("status", po.getStatus());
            map.put("hostName", "-");
            map.put("instanceName", "-");
            map.put("pappName", pappName);
            FlingPappMonitorMsgPO detail = instanceServices.getInstanceDetails(projectId, pappName, po.getInstanceIp());
            if (detail != null) {
                if (detail.getInstanceName() != null) {
                    map.put("instanceName", detail.getInstanceName());
                }
                if (detail.getHostName() != null) {
                    map.put("hostName", detail.getHostName());
                }
            }
            datas.add(map);
        }
        ResponseModel model = new ResponseModel();
        model.addAttribute("datas", datas);
        model.addAttribute("totalSize", datas.size());
        return model;
    }


    @RequestMapping("/list-papps-instances.do")
    @ESA(value="pafa5-admin-fling.listPapps")
    @ResponseBody
    public ResponseModel listForPapp(@RequestParam("projectId") String projectId,
            @RequestParam("pappName") String pappName, 
            @RequestParam(value = "limit", defaultValue = "30") int limit, 
            @RequestParam(value = "page", defaultValue = "1") int page, 
            @RequestParam(value = "formatDate", defaultValue = "true") boolean formatDate) {

        PageDataDTO<FlingPappInstancePO> pageDataDTO = instanceServices.listForPapp(projectId, pappName, limit, page);

        List<FlingPappInstancePO> pos = pageDataDTO.getDatas();
        // instanceServices.listForPapp(pappName);
        if (pos == null || pos.size() == 0) {
            return new ResponseModel("1", "应用:" + pappName + "未能找到对应节点信息。");
        }
        List<ModelMap> datas = new ArrayList<ModelMap>(pos.size());
        DateFormat formatter = null;
        if (formatDate) {
            formatter = DateFormat.getDateTimeInstance();
        }
        for (FlingPappInstancePO po : pos) {
            ModelMap map = new ModelMap();
            map.put("instanceIp", po.getInstanceIp());
            if (formatDate) {
                map.put("lastActiveTime", formatter.format(new Date(po.getLastActiveTimestamp())));
            } else {
                map.put("lastActiveTime", po.getLastActiveTimestamp());
            }
            map.put("lastActiveObjectId", po.getLastActiveObjectId());
            map.put("lastActiveCause", po.getUpdatedBy());
            map.put("status", po.getStatus());
            map.put("hostName", "-");
            map.put("instanceName", "-");
            map.put("pappName", po.getAppName());

            String appName = po.getAppName();
            String ip = po.getInstanceIp();
            if (appName != null && !"".equals(appName.trim()) && ip != null&& !"".equals(ip.trim())) {
                FlingPappMonitorMsgPO detail = instanceServices.getInstanceDetails(projectId, appName, ip);
                if (detail != null) {
                    if (detail.getInstanceName() != null) {
                        map.put("instanceName", detail.getInstanceName());
                    }
                    if (detail.getHostName() != null) {
                        map.put("hostName", detail.getHostName());
                    }
                }
            }
            datas.add(map);
        }
        ResponseModel model = new ResponseModel();
        model.addAttribute("datas", datas);
        model.addAttribute("totalSize", pageDataDTO.getTotalSize());
        return model;
    }
    
    @ESA(value="pafa5-admin-fling.listIntances",local=true)
    @ResponseBody
    public ResponseModel listIntanse(@RequestParam("projectId") String projectId,
            @RequestParam(value = "limit", defaultValue = "99999") int limit, 
            @RequestParam(value = "page", defaultValue = "1") int page,
            @RequestParam(value="instanceIp",required=false) String instanceIp) {
    	ResponseModel model = new ResponseModel("0","成功");
    	List<InstanceDTO> instanceDTOs = instanceServices.listForProjectId(projectId,instanceIp);
    	if(instanceDTOs.size()==0) {
    		model.setResponseCode("-1");
    	}else {
    		model.put("datas", instanceDTOs);
    	}
        return model;
    }


    @RequestMapping("/list-sar-instances.do")
    @ResponseBody
    public ResponseModel listForSAR(@RequestParam("projectId") String projectId,
            @RequestParam("sarName") String sarName, @RequestParam(value = "pappName",
                    required = false) String pappName, @RequestParam(value = "formatDate",
                    defaultValue = "true") boolean formatDate) {
        List<FlingSARInstancePO> pos = instanceServices.listForSAR(projectId, sarName, pappName);
        if (pos == null || pos.size() == 0) {
            return new ResponseModel("1", "组件:" + sarName + "未能找到对应节点信息。");
        }
        List<ModelMap> datas = new ArrayList<ModelMap>(pos.size());
        DateFormat formatter = null;
        if (formatDate) {
            formatter = DateFormat.getDateTimeInstance();
        }
        for (FlingSARInstancePO po : pos) {
            ModelMap map = new ModelMap();
            map.put("instanceIp", po.getInstanceIp());
            if (formatDate) {
                map.put("lastActiveTime", formatter.format(new Date(po.getLastActiveTimestamp())));
            } else {
                map.put("lastActiveTime", po.getLastActiveTimestamp());
            }
            map.put("lastActiveObjectId", po.getLastActiveObjectId());
            map.put("lastActiveCause", po.getCreatedBy());
            map.put("pappName", po.getAppName());
            map.put("status", po.getStatus());
            datas.add(map);
        }
        ResponseModel model = new ResponseModel();
        model.addAttribute("datas", datas);
        model.addAttribute("totalSize", datas.size());
        return model;
    }
    
    @Resource
    private ServiceDetectionService serviceDetectionService;

    @RequestMapping("/list-sars-instances.do")
    @ResponseBody
    @ESA("pafa5-admin-fling.listSars")
    public ResponseModel listForSAR(
            @RequestParam(value = "projectId", required = false) String projectId, @RequestParam(
                    value = "sarName", required = false) String sarName, @RequestParam(
                    value = "pappName", required = false) String pappName, @RequestParam(
                    value = "limit", defaultValue = "30") int limit, @RequestParam(value = "page",
                    defaultValue = "1") int page, 
            @RequestParam(value = "formatDate", defaultValue = "true") boolean formatDate,
            @RequestParam(value = "serviceStatus", defaultValue = "false") boolean serviceStatus) {

        PageDataDTO<FlingSARInstancePO> pageDataDTO = instanceServices.listForSAR(projectId, sarName, pappName, limit, page);

        List<FlingSARInstancePO> pos = pageDataDTO.getDatas();
        if (pos == null || pos.size() == 0) {
            return new ResponseModel("1", "组件:" + sarName + "未能找到对应节点信息。");
        }
        List<ModelMap> datas = new ArrayList<ModelMap>(pos.size());
        DateFormat formatter = null;
        if (formatDate) {
            formatter = DateFormat.getDateTimeInstance();
        }
        for (FlingSARInstancePO po : pos) {
            ModelMap map = new ModelMap();
            map.put("instanceIp", po.getInstanceIp());
            if (formatDate) {
                map.put("lastActiveTime", formatter.format(new Date(po.getLastActiveTimestamp())));
            } else {
                map.put("lastActiveTime", po.getLastActiveTimestamp());
            }
            map.put("lastActiveObjectId", po.getLastActiveObjectId());
            map.put("lastActiveCause", po.getCreatedBy());
            map.put("pappName", po.getAppName());
            map.put("sarName", po.getSarName());
            map.put("projectId", po.getProjectId());
            map.put("status", po.getStatus());
           /* if(serviceStatus) {
            	long s = System.nanoTime();
                try {
    				int s1 = serviceDetectionService.processDubboAdmin(po.getSarName(),po.getInstanceIp());
    				map.put("serviceStatus", s1);
    			}finally {
    				logger.info((System.nanoTime()-s)/1000/1000.00+"ms");
    			}
            }*/
            datas.add(map);
        }
        
       if(serviceStatus) {
        	long s = System.nanoTime();
            try {
				serviceDetectionService.processDubboAdmin(datas);
			} catch (InterruptedException e) {
				e.printStackTrace();
			} catch (ExecutionException e) {
				e.printStackTrace();
			}finally {
				logger.info("抓取esa服务耗时："+(System.nanoTime()-s)/1000/1000.00+"ms");
			}
        }
        ResponseModel model = new ResponseModel();
        model.addAttribute("datas", datas);
        model.addAttribute("totalSize", pageDataDTO.getTotalSize());
        return model;
    }
    
    @RequestMapping("/list-sars-instances-papp.do")
    @ResponseBody
    public ResponseModel listForSAR_Papp(
            @RequestParam(value = "projectId", required = false) String projectId,  @RequestParam(
                    value = "pappName", required = false) String pappName ) {

        PageDataDTO<FlingSARInstancePO> pageDataDTO = instanceServices.listForSAR(projectId, null, pappName, Integer.MAX_VALUE, 1);

        List<FlingSARInstancePO> pos = pageDataDTO.getDatas();
        if (pos == null || pos.size() == 0) {
        	 ResponseModel model =new ResponseModel("1", "未能找到对应SAR信息。");
        	 List<ModelMap> datas = new ArrayList<ModelMap>();
        	 model.addAttribute("sarNames",datas);
        	 model.addAttribute("size",0);
            return model;
        }
        Set<String> sarNameSet  = new HashSet<String>();
        for(FlingSARInstancePO po : pos){
        	sarNameSet.add(po.getSarName());
        }
        List<SarDTO> datas = new ArrayList<SarDTO>(sarNameSet.size());
        for (String s : sarNameSet) {
        	SarDTO dto = new SarDTO();
        	dto.setId(s);
			dto.setSarName(s);
            datas.add(dto);
        }
        ResponseModel model = new ResponseModel();
        model.addAttribute("sarNames", datas);
        model.addAttribute("size", sarNameSet.size());
        return model;
    }

    @RequestMapping("/list-instance-details.do")
    @ResponseBody
    public ResponseModel listDetails(@RequestParam(value = "projectId") String projectId,
            @RequestParam(value = "pappName", required = true) String pappName, @RequestParam(
                    value = "instanceIp", required = false) String instanceIp, @RequestParam(
                    value = "formatDate", defaultValue = "true") boolean formatDate) {
        List<FlingPappMonitorMsgPO> pos =
                instanceServices.listInstanceDetails(projectId, pappName, instanceIp);
        if (pos == null || pos.size() == 0) {
            return new ResponseModel("1", "应用:" + pappName + "未能找到对应节点信息。");
        }
        List<ModelMap> datas = new ArrayList<ModelMap>(pos.size());
        DateFormat formatter = null;
        if (formatDate) {
            formatter = DateFormat.getDateTimeInstance();
        }
        for (FlingPappMonitorMsgPO po : pos) {
            ModelMap map = POUtils.toMap(po);
            
            map.remove("createdTimestamp");
            if (formatDate) {
                map.put("createdTime", formatter.format(new Date(po.getCreatedTimestamp())));
            } else {
                map.put("createdTime", po.getCreatedTimestamp());
            }
            datas.add(map);
        }
        ResponseModel model = new ResponseModel();
        model.addAttribute("datas", datas);
        return model;
    }

    @RequestMapping("/get-instance-details.do")
    @ResponseBody
    public ResponseModel getDetails(@RequestParam(value = "projectId") String projectId,
            @RequestParam(value = "pappName", required = true) String pappName, @RequestParam(
                    value = "sarName", required = true) String sarName, @RequestParam(
                    value = "instanceIp") String instanceIp, @RequestParam(value = "formatDate",
                    defaultValue = "true") boolean formatDate) {
        FlingPappMonitorMsgPO po =
                instanceServices.getInstanceDetails(projectId, pappName, instanceIp);
        if (po == null) {
            return new ResponseModel("1", "应用:" + pappName + "未能找到对应节点信息。");
        }

        DateFormat formatter = null;
        if (formatDate) {
            formatter = DateFormat.getDateTimeInstance();
        }
        ModelMap map = POUtils.toMap(po);
        
        map.remove("createdTimestamp");//
        if (formatDate) {
            map.put("createdTime", formatter.format(new Date(po.getCreatedTimestamp())));
        } else {
            map.put("createdTime", po.getCreatedTimestamp());
        }

        ResponseModel model = new ResponseModel();
        model.addAttribute("datas", map);
        return model;
    }

    @RequestMapping("/delete-instance-papp.do")
    @ResponseBody
    public ResponseModel deletePapp(@RequestParam(value = "projectId") String projectId,
            @RequestParam(value = "pappName", required = true) String pappName, @RequestParam(
                    value = "instanceIp", required = true) String instanceIp) {
        boolean success = instanceServices.deletePapp(projectId, pappName, instanceIp);
        ResponseModel model = new ResponseModel();
        model.addAttribute("success", success);
        return model;
    }

    @RequestMapping("/delete-instance-sar.do")
    @ResponseBody
    public ResponseModel deleteSar(@RequestParam(value = "projectId") String projectId,
            @RequestParam(value = "sarName", required = true) String sarName, @RequestParam(
                    value = "instanceIp", required = true) String instanceIp,@RequestParam(
                            value = "pappName", required = true) String pappName) {
        boolean success = instanceServices.deleteSar(projectId, sarName, instanceIp,pappName);
        ResponseModel model = new ResponseModel();
        model.addAttribute("success", success);
        return model;
    }

    public InstanceServices getInstanceServices() {
        return instanceServices;
    }

    public void setInstanceServices(InstanceServices instanceServices) {
        this.instanceServices = instanceServices;
    }


    /******************* 下拉列表IP *********************/

    @RequestMapping("/list-ips-combox.do")
    @ResponseBody
    public ResponseModel comboxForIps(@RequestParam(value = "projectId") String projectId,
            @RequestParam(value = "type", required = true) String type, @RequestParam(
                    value = "name", required = false) String name) {
        ResponseModel model = new ResponseModel();
        List<ModelMap> datas = new ArrayList<ModelMap>();
        if (name == null || "".equals(name)) {
            return model;
        }
        if (type.equals("sar")) {
            List<FlingSARInstancePO> pos = instanceServices.listForSAR(projectId, name, null);
            if (pos != null && pos.size() > 0) {
                for (FlingSARInstancePO po : pos) {
                    ModelMap map = new ModelMap();
                    map.put("id", po.getInstanceIp());
                    map.put("ip", po.getInstanceIp());
                    datas.add(map);
                }
            }
        } else {
            List<FlingPappInstancePO> pos = instanceServices.listForPapp(projectId, name);
            if (pos != null && pos.size() > 0) {
                for (FlingPappInstancePO po : pos) {
                    ModelMap map = new ModelMap();
                    map.put("id", po.getInstanceIp());
                    map.put("ip", po.getInstanceIp());
                    datas.add(map);
                }
            }
        }
        model.addAttribute("datas", datas);
        return model;
    }

    @RequestMapping("/list-papp-combox.do")
    @ResponseBody
    public ResponseModel comboxForPapp(@RequestParam("projectId") String projectId,
            @RequestParam("pappName") String pappName) {
        List<FlingPappInstancePO> pos = null;
        PageDataDTO<FlingPappInstancePO> pageData =
                instanceServices.listForPapp(projectId, pappName, 100, 1);
        if (pageData != null) {
            pos = pageData.getDatas();
        }
        if (pos == null) {
            pos = new ArrayList<FlingPappInstancePO>();
        }
        List<ModelMap> datas = new ArrayList<ModelMap>(pos.size());
        for (FlingPappInstancePO po : pos) {
            ModelMap map = new ModelMap();
            map.put("id", po.getInstanceIp());
            map.put("ip", po.getInstanceIp());
            datas.add(map);
        }
        ResponseModel model = new ResponseModel();
        model.addAttribute("datas", datas);
        return model;
    }

    @RequestMapping("/list-sar-combox.do")
    @ResponseBody
    public ResponseModel comboxForSAR(@RequestParam("projectId") String projectId,
            @RequestParam("sarName") String sarName, @RequestParam(value = "pappName",
                    required = false) String pappName) {
        List<FlingSARInstancePO> pos = null;
        PageDataDTO<FlingSARInstancePO> pageData =
                instanceServices.listForSAR(projectId, sarName, pappName, 100, 1);
        if (pageData != null) {
            pos = pageData.getDatas();
        }
        if (pos == null) {
            pos = new ArrayList<FlingSARInstancePO>();
        }
        List<ModelMap> datas = new ArrayList<ModelMap>(pos.size());
        for (FlingSARInstancePO po : pos) {
            ModelMap map = new ModelMap();
            map.put("id", po.getInstanceIp());
            map.put("ip", po.getInstanceIp());
            datas.add(map);
        }
        ResponseModel model = new ResponseModel();
        model.addAttribute("datas", datas);
        return model;
    }

    @RequestMapping("/clearf5file.do")
	@ResponseBody
    public ResponseModel clearf5file() {
		ResponseModel model = new ResponseModel("0","成功");
		
        try {
        	//f5check_2018-01-09.log
        	deleteFile();
		} catch (Exception e) {
			model.put("responseCode", "-101010");
			model.put("responseMsg", "磁盘回写失败");
		}
        return model;
    }
	
	@TimerJob(cronExpression="0 30 3 * * ?")
	public void deleteFile() throws Exception{
		String rootPath = System.getProperty("pafa.log.home", "");
		try {
			SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
	    	File file = new File(rootPath);
			if(file.isDirectory()) {
				File f[] = file.listFiles();
				if(f!=null&&f.length>0) {
					for (File file2 : f) {
						if(file2.isFile()&&file2.getName().startsWith("f5check_")&&file2.getName().endsWith(".log")) {
							String name = file2.getName().replaceAll("f5check_", "").replaceAll(".log", "");
							if(new Date().getTime()-dateFormat.parse(name).getTime()>7*24*60*60*1000) {
								file2.delete();
							}
						}
					}
				}
			}
		} catch (Exception e) {
			throw e;
		}
		
	}
}
