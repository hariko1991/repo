package com.pingan.pafa5.admin.fling.form;

public class SendCommandForm {

    private String projectId;// 项目ID

    private String type;// 类型：papp/sar

    private String pappName;// 应用

    private String sarName;// 组件

    private String dictateName;// 命令 shutdown/startup/restartup/echo

    private String executeIps;// 执行IP

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getPappName() {
        return pappName;
    }

    public void setPappName(String pappName) {
        this.pappName = pappName;
    }

    public String getSarName() {
        return sarName;
    }

    public void setSarName(String sarName) {
        this.sarName = sarName;
    }

    public String getDictateName() {
        return dictateName;
    }

    public void setDictateName(String dictateName) {
        this.dictateName = dictateName;
    }

    public String getExecuteIps() {
        return executeIps;
    }

    public void setExecuteIps(String executeIps) {
        this.executeIps = executeIps;
    }

}
