package com.pingan.pafa5.admin.commons;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

public final class WebUtils {

    /**
     * 获取当前选择的领域
     * @param request
     * @return
     */
    public static String getCurDomainId(HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        for(Cookie cookie : cookies){
            if("currentProject".equals(cookie.getName())){
                return cookie.getValue();
            }
        }
        return "def";
    }
    
}
