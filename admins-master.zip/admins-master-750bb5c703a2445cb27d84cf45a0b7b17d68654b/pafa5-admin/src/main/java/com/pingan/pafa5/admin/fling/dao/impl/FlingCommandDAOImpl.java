package com.pingan.pafa5.admin.fling.dao.impl;

import java.util.Date;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.fling.dao.FlingCommandDAO;
import com.pingan.pafa5.admin.fling.po.FlingCommandPO;

@Nosql
@Repository
public class FlingCommandDAOImpl extends BaseMongoDAO<FlingCommandPO> implements FlingCommandDAO {

    @Override
    public String add(FlingCommandPO po) {
        this._add(po);
        return po.getRid();
    }

    @Override
    public FlingCommandPO getById(String commandId) {
        return this._getById(commandId);
    }

    @Override
    public int removeBeforeDate(Date date) {
        Criteria criteria = Criteria.where("createdDate").lt(date);
        int affected = this._remove(criteria);
        return affected;
    }

}
