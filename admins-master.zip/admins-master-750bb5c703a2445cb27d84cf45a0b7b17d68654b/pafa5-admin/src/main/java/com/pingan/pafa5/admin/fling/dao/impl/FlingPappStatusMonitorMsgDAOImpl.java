package com.pingan.pafa5.admin.fling.dao.impl;

import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.fling.dao.FlingPappStatusMonitorMsgDAO;
import com.pingan.pafa5.admin.fling.po.FlingPappStatusMonitorMsgPO;

@Nosql
@Repository
public class FlingPappStatusMonitorMsgDAOImpl extends BaseMongoDAO<FlingPappStatusMonitorMsgPO>
        implements FlingPappStatusMonitorMsgDAO {

    @Override
    public void add(FlingPappStatusMonitorMsgPO po) {
        this._add(po);
    }

}
