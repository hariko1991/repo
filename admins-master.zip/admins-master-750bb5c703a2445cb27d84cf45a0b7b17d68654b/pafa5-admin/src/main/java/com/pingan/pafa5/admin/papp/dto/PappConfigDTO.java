package com.pingan.pafa5.admin.papp.dto;

/**
 * 组件配置.
 * 
 * @author linkaibin447
 * 
 */
public class PappConfigDTO {

	private String projectId;
	private String pappId;
	private String localHomeDir;
	private String jettyEnable;
	private String dubboEnable;
	private String defCharset;
	private String flingMonitorEnable;
	private String esaHttpExportEnable;
	private String resourcesSuffix;
	
	/**自定义配置*/
    private String id;//组件配置id
    private String cfgItem;//配置项
    private String cfgItemDes;//配置项说明
    private String cfgValues;//配置值

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getCfgItem() {
		return cfgItem;
	}

	public void setCfgItem(String cfgItem) {
		this.cfgItem = cfgItem;
	}

	public String getCfgItemDes() {
		return cfgItemDes;
	}

	public void setCfgItemDes(String cfgItemDes) {
		this.cfgItemDes = cfgItemDes;
	}

	public String getCfgValues() {
		return cfgValues;
	}

	public void setCfgValues(String cfgValues) {
		this.cfgValues = cfgValues;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getPappId() {
		return pappId;
	}

	public void setPappId(String pappId) {
		this.pappId = pappId;
	}

	public String getLocalHomeDir() {
		return localHomeDir;
	}

	public void setLocalHomeDir(String localHomeDir) {
		this.localHomeDir = localHomeDir;
	}

	public String getJettyEnable() {
		return jettyEnable;
	}

	public void setJettyEnable(String jettyEnable) {
		this.jettyEnable = jettyEnable;
	}

	public String getDubboEnable() {
		return dubboEnable;
	}

	public void setDubboEnable(String dubboEnable) {
		this.dubboEnable = dubboEnable;
	}

	public String getDefCharset() {
		return defCharset;
	}

	public void setDefCharset(String defCharset) {
		this.defCharset = defCharset;
	}

	public String getFlingMonitorEnable() {
		return flingMonitorEnable;
	}

	public void setFlingMonitorEnable(String flingMonitorEnable) {
		this.flingMonitorEnable = flingMonitorEnable;
	}

	public String getEsaHttpExportEnable() {
		return esaHttpExportEnable;
	}

	public void setEsaHttpExportEnable(String esaHttpExportEnable) {
		this.esaHttpExportEnable = esaHttpExportEnable;
	}

	public String getResourcesSuffix() {
		return resourcesSuffix;
	}

	public void setResourcesSuffix(String resourcesSuffix) {
		this.resourcesSuffix = resourcesSuffix;
	}

}
