package com.pingan.pafa5.admin.fling.dto;

import java.util.Date;

/**
 * 管控指令
 * 
 * @author ZHANGGANG871
 * 
 */
public class DictateLoggerDTO {

    private String id;
    private String instanceIp;// 目标地址

    private String posName;// papp或者sar名字

    private String posType;// papp应用/sar组件

    private String dictateName;// 指令

    private String dictateId;// 执行指令获取回执结果ID

    private String result;// 执行结果

    private String cause;// 失败原因

    private String createdBy;// 操作人

    private Date createdDate;// 操作时间

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPosName() {
        return posName;
    }

    public void setPosName(String posName) {
        this.posName = posName;
    }

    public String getPosType() {
        return posType;
    }

    public void setPosType(String posType) {
        this.posType = posType;
    }

    public String getDictateName() {
        return dictateName;
    }

    public void setDictateName(String dictateName) {
        this.dictateName = dictateName;
    }

    public String getDictateId() {
        return dictateId;
    }

    public void setDictateId(String dictateId) {
        this.dictateId = dictateId;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getCause() {
        return cause;
    }

    public void setCause(String cause) {
        this.cause = cause;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getInstanceIp() {
        return instanceIp;
    }

    public void setInstanceIp(String instanceIp) {
        this.instanceIp = instanceIp;
    }

}
