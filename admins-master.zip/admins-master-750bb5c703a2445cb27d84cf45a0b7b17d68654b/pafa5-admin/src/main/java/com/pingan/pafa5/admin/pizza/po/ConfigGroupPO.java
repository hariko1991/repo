package com.pingan.pafa5.admin.pizza.po;

import org.springframework.data.mongodb.core.mapping.Document;

/**
 * 配置分组信息
 * 
 * @author EX-YANGSHENGXIANG001
 */
@Document
public class ConfigGroupPO implements Cloneable {

	@org.springframework.data.annotation.Id
	private String id;
	/**
	 * 分组编码
	 */
	private String groupCode;
	/**
	 * 分组名称
	 */
	private String groupName;

	private boolean isBinary = false;

	private boolean isHide = false;

	public ConfigGroupPO() {
	}

	public ConfigGroupPO(String groupCode, String groupName, boolean isBinary) {
		this.groupCode = groupCode;
		this.groupName = groupName;
		this.isBinary = isBinary;
	}

	public ConfigGroupPO(String groupCode, String groupName, boolean isBinary, boolean isHide) {
		this.groupCode = groupCode;
		this.groupName = groupName;
		this.isBinary = isBinary;
		this.isHide = isHide;
	}

	public ConfigGroupPO(String groupCode, String groupName) {
		this.groupCode = groupCode;
		this.groupName = groupName;
		this.isBinary = false;
	}

	public String getGroupCode() {
		return groupCode;
	}

	public void setGroupCode(String groupCode) {
		this.groupCode = groupCode;
	}

	public String getGroupName() {
		return groupName;
	}

	public void setGroupName(String groupName) {
		this.groupName = groupName;
	}

	public boolean isHide() {
		return isHide;
	}

	public void setHide(boolean isHide) {
		this.isHide = isHide;
	}

	public Object clone() {
		try {
			return super.clone();
		} catch (CloneNotSupportedException e) {
			return null;
		}
	}

	public boolean isBinary() {
		return isBinary;
	}

	public void setBinary(boolean isBinary) {
		this.isBinary = isBinary;
	}

}
