package com.pingan.pafa5.admin.papp.services.impl;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Properties;

import org.apache.log4j.Logger;
import org.dom4j.Document;
import org.dom4j.DocumentFactory;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.springframework.stereotype.Component;

@Component
public class ConfigFileGenerate {

	private static final Logger log = Logger.getLogger(ConfigFileGenerate.class);

	public String generatePappProperties() {
		Properties properties = new Properties();
 
		properties.put("#papp.sar.list", "");
		properties.put("#papp.lib.list", "");
		properties.put("papp.protocols", "dubbo");
		properties.put("fling.monitor.enable", "true");
		properties.put("papp.resources.suffix", "js,html,css,jpg,png,gif,docx,doc,woff, woff2, ttf, svg, eot");
		properties.put("papp.jetty.enable", "false");
		properties.put("papp.dubbo.enable", "true");
		properties.put("papp.def.charset", "utf-8");
		properties.put("papp.esa.http.export.enable", "true");
		properties.put("papp.web.enable", "true");

		return toString(properties);

	}

	public String toString(Properties properties) {
		String result = "";
		List<String> key = new ArrayList<String>();
		for (Object obj : properties.keySet()) {
			key.add((String) obj);
		}
		Collections.sort(key);
		for(Object obj : key){
			result += obj + "=" + properties.get(obj) + "\n";
		}
		return result;
	}

	public String generatePappLog4jXml() {
		Document doc = DocumentFactory.getInstance().createDocument();

		Element root = doc.addElement("Configuration");
		root.addAttribute("status", "info");

		Element appenders = root.addElement("Appenders");
		/*Element console = appenders.addElement("Console");
		console.addAttribute("name", "CONSOLE");
		console.addAttribute("target", "SYSTEM_OUT");
		Element pattern = console.addElement("PatternLayout");
		pattern.addAttribute("pattern",
				"[%d{HH:mm:ss.SSS}] [%-3p] %x %c{1}:  %m%n");*/

		Element logFile = appenders.addElement("RollingRandomAccessFile");
		logFile.addAttribute("name", "logFile");
		logFile.addAttribute("fileName", "${sys:pafa.log.home}/pafa.log");
		logFile.addAttribute("filePattern",
				"${sys:pafa.log.home}/pafa.log.%d{yyyy-MM-dd}");
		logFile.addAttribute("immediateFlush", "false");
		logFile.addAttribute("bufferSize", "8192");

		Element layout = logFile.addElement("PatternLayout");
		layout.addAttribute("pattern",
				"[%d{HH:mm:ss.SSS}] [%-3p] %x %c{1}:  %m%n");

		Element policies = logFile.addElement("Policies");
		Element trigger = policies.addElement("TimeBasedTriggeringPolicy");
		trigger.addAttribute("interval", "1");
		trigger.addAttribute("modulate", "true");

		Element async = appenders.addElement("Async");
		async.addAttribute("name", "Async");
		/*Element ref = async.addElement("AppenderRef");
		ref.addAttribute("ref", "CONSOLE");*/
		Element fileRef = async.addElement("AppenderRef");
		fileRef.addAttribute("ref", "logFile");

		Element loggers = root.addElement("Loggers");
		/*Element ibatis = loggers.addElement("Logger");
		ibatis.addAttribute("name", "com.ibatis");
		ibatis.addAttribute("level", "ERROR");*/
		Element conn = loggers.addElement("Logger");
		conn.addAttribute("name", "java.sql.Connection");
		conn.addAttribute("level", "ERROR");
		Element statement = loggers.addElement("Logger");
		statement.addAttribute("name", "java.sql.Statement");
		statement.addAttribute("level", "ERROR");
		Element preStatement = loggers.addElement("Logger");
		preStatement.addAttribute("name", "java.sql.PreparedStatement");
		preStatement.addAttribute("level", "ERROR");
		Element apache = loggers.addElement("Logger");
		apache.addAttribute("name", "org.apache");
		apache.addAttribute("level", "ERROR");
		Element pafa = loggers.addElement("Logger");
		pafa.addAttribute("name", "com.paic.pafa");
		pafa.addAttribute("level", "INFO");
		Element pafa5 = loggers.addElement("Logger");
		pafa5.addAttribute("name", "com.pingan.pafa5");
		pafa5.addAttribute("level", "INFO");
		Element spring = loggers.addElement("Logger");
		spring.addAttribute("name", "org.springframework");
		spring.addAttribute("level", "INFO");
		Element secondRoot = loggers.addElement("Root");
		secondRoot.addAttribute("level", "ERROR");
		Element appRef = secondRoot.addElement("AppenderRef");
		appRef.addAttribute("ref", "Async");

		StringWriter writer = new StringWriter();
		OutputFormat out = OutputFormat.createPrettyPrint();

		XMLWriter xmlWriter = new XMLWriter(writer, out);
		if (log.isInfoEnabled()) {
			log.info("XML : " + doc.asXML());
		}
		try {
			xmlWriter.write(doc);
		} catch (IOException e) {
			log.error("Error occured when writing ivy.xml,detail is: "
					+ e.getMessage());
		}

		return writer.toString();
	}

}
