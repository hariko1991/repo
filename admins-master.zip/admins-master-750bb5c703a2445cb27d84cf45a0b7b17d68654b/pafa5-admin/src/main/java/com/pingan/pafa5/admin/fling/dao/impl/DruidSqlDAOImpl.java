package com.pingan.pafa5.admin.fling.dao.impl;

import java.util.List;
import java.util.Map;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.fling.dao.DruidSqlDAO;
import com.pingan.pafa5.admin.fling.po.DruidSqlPO;
@Nosql
@Repository
public class DruidSqlDAOImpl extends BaseMongoDAO<DruidSqlPO> implements DruidSqlDAO{

	@Override
	public void add(DruidSqlPO sql) {
		// TODO Auto-generated method stub
		this._add(sql);
	}

	@Override
	public void update(DruidSqlPO sql) {
		// TODO Auto-generated method stub
		this._updateById(sql);;
	}

	@Override
	public List<DruidSqlPO> list(Map<String, Object> map) {
		// TODO Auto-generated method stub
		Criteria criteria = this.where("druidDatasourceId").is(map.get("druidDatasourceId"))
								.and("identity").is(map.get("identify"));
		return this._list(criteria,(int)map.get("page"),(int)map.get("limit"));
	}

	@Override
	public long getDruidSqlCount(Map<String, Object> map) {
		// TODO Auto-generated method stub
		Criteria criteria = this.where("druidDatasourceId").is(map.get("druidDatasourceId"))
				.and("identity").is(map.get("identify"));
		return this._count(criteria);
	}

	@Override
	public DruidSqlPO getDruidSqlBySqlId(long sqlId, int identity) {
		// TODO Auto-generated method stub
		Criteria criteria = this.where("sqlId").is(sqlId)
				.and("identity").is(identity);
		return this._get(criteria);
	}

}
