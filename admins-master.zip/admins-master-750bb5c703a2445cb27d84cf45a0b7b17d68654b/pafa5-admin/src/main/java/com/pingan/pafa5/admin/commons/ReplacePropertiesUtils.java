package com.pingan.pafa5.admin.commons;

import java.util.Properties;
import java.util.Set;

import com.alibaba.dubbo.common.utils.ConfigUtils;

public class ReplacePropertiesUtils {
	
	public static Properties replace(Properties pro){
		ConfigUtils.setProperties(pro);
		
		Set<Object> keys = pro.keySet();
		
		for(Object key : keys){
			pro.setProperty(key.toString(), ConfigUtils.getProperty(key.toString()));
		}
		return pro;
	}
	
	
	
}
