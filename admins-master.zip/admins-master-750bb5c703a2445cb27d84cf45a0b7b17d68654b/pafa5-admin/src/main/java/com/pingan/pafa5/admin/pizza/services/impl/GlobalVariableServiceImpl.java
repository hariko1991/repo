package com.pingan.pafa5.admin.pizza.services.impl;

import java.io.IOException;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.commons.PizzaManagerHolder;
import com.pingan.pafa5.admin.commons.SARManagerConstants;
import com.pingan.pafa5.admin.pizza.dao.GlobalVariableDAO;
import com.pingan.pafa5.admin.pizza.dto.GlobalVariableDTO;
import com.pingan.pafa5.admin.pizza.form.GlobalVariableForm;
import com.pingan.pafa5.admin.pizza.po.GlobalVariablePO;
import com.pingan.pafa5.admin.pizza.services.GlobalVariableService;
import com.pingan.pafa5.admin.sso.UserPrincipal;

@Service
public class GlobalVariableServiceImpl extends BaseServices implements GlobalVariableService {

	@Autowired
	private GlobalVariableDAO globalVariableDAO;

	@Autowired
	private PizzaManagerHolder pizzaManagerHolder;

	static final String GROUP = "global";

	static final String GROUP_GLOBALVARS = "globalvars";

	@ActionClient(name = "pafa5-admin-systems.isOwner")
	private IServiceClient ownerService;

	@Override
	public PageDataDTO<GlobalVariableDTO> list(String proId, String property, int page, int limit) throws Exception {
		PageDataDTO<GlobalVariableDTO> pageData = new PageDataDTO<GlobalVariableDTO>();
		long size = globalVariableDAO.getCount(proId, property);
		if (size > 0) {
			List<GlobalVariablePO> pos = globalVariableDAO.list(proId, property, page, limit);
			if (logger.isInfoEnabled()) {
				logger.info("GlobalVariable Datas：" + JSONObject.toJSONString(pos));
			}
			List<GlobalVariableDTO> dtos = new ArrayList<GlobalVariableDTO>();
			for (GlobalVariablePO po : pos) {
				GlobalVariableDTO dto = new GlobalVariableDTO();
				POUtils.copyProperties(dto, po);
				dto.setAlValue(po.getValue());
				if(dto.isHidden()) {
					dto.setValue("******");
				}
				dtos.add(dto);
			}
			pageData.setDatas(dtos);
		}
		pageData.setTotalSize(size);
		return pageData;
	}

	@Override
	public GlobalVariableDTO getById(String id) throws Exception {
		GlobalVariablePO po = globalVariableDAO.getById(id);
		if (po == null) {
			throw new ResponseCodeException("256", "没有找到该变量");
		}
		GlobalVariableDTO dto = new GlobalVariableDTO();
		POUtils.copyProperties(dto, po);
		if (logger.isInfoEnabled()) {
			logger.info("find=" + JSONObject.toJSONString(dto));
		}

		return dto;
	}

	@Override
	public void add(GlobalVariableForm form) {
		isOwner(form.getProId());

		GlobalVariablePO po = new GlobalVariablePO();
		POUtils.copyProperties(po, form);
		if ("on".equals(form.getIsHidden())) {
			po.setHidden(true);
		} else {
			po.setHidden(false);
		}
		POUtils.setForAdd(UserPrincipal.get(true).getUid(), po);
		String id = po.getProId() + "." + po.getProperty();
		po.setId(id);
		GlobalVariablePO gvp = globalVariableDAO.getById(id);
		if (gvp != null) {
			throw new ResponseCodeException("256", "该变量名称已经存在，请更换");
		}
		globalVariableDAO.add(po);

		putPizzaManager(po.getProId());
	}

	@Override
	public boolean edit(GlobalVariableForm form) {
		isOwner(form.getProId());

		GlobalVariablePO po = globalVariableDAO.getById(form.getId());
		if (po == null) {
			throw new ResponseCodeException("256", "没有找到该变量");
		}
		POUtils.copyProperties(po, form);
		if ("on".equals(form.getIsHidden())) {
			po.setHidden(true);
		} else {
			po.setHidden(false);
		}
		POUtils.setForUpdate(UserPrincipal.get(true).getUid(), po);
		boolean success = globalVariableDAO.edit(po);
		if (success) {
			putPizzaManager(po.getProId());
		}
		return success;
	}

	@Override
	public boolean delete(String id) throws Exception {
		GlobalVariablePO po = globalVariableDAO.getById(id);

		if (po == null) {
			throw new ResponseCodeException("256", "没有找到该变量");
		}
		if (logger.isInfoEnabled()) {
			logger.info("delete " + JSONObject.toJSONString(po));
		}
		isOwner(po.getProId());

		boolean success = globalVariableDAO.delete(id);
		if (success) {
			String pizzKey = po.getProId() + ".properties";
			if (logger.isWarnEnabled()) {
				logger.warn("Delete Globalvars=" + pizzKey);
			}
			putPizzaManager(po.getProId());
		}
		return success;
	}

	public void putPizzaManager(String domainId) {
		String pizzaKey = domainId + ".properties";
		String properties = toProperties(domainId);
		String content = pizzaManagerHolder.getManager(domainId).get(GROUP_GLOBALVARS, pizzaKey);
		if (content != null && content.length() > 0) {
			if (logger.isInfoEnabled()) {
				logger.info("Set Globalvars=" + properties);
			}
			pizzaManagerHolder.getManager(domainId).set(GROUP_GLOBALVARS, pizzaKey, properties);
		} else {
			if (logger.isInfoEnabled()) {
				logger.info("Add Globalvars=" + properties);
			}
			pizzaManagerHolder.getManager(domainId).add(GROUP_GLOBALVARS, pizzaKey, properties);
		}
	}

	public String toProperties(String domainId) {
		List<GlobalVariablePO> pos = globalVariableDAO.list(domainId);
		if (pos == null) {
			throw new ResponseCodeException("256", "没有找到该变量");
		}
		Properties properties = new Properties();
		for (GlobalVariablePO po : pos) {
			properties.setProperty(po.getProperty(), po.getValue());
		}
		StringWriter writer = new StringWriter();
		try {
			properties.store(writer, domainId + ".properties");
		} catch (IOException e) {
			logger.error(e);
			return "";
		}
		return writer.toString();
	}

	public void isOwner(String proId) {
		if (proId == null || SARManagerConstants.DEF.equalsIgnoreCase(proId)) {
			// throw new ResponseCodeException("354", "对不起，你不是项目管理员，没有此操作权限");
			return;
		}
		ServiceParams params = new ServiceParams();
		params.set("groupId", proId);
		ServiceResults results = ownerService.invoke(params);
		boolean isBoo = results.getBool("isowner");
		if (!isBoo) {
			throw new ResponseCodeException("354", "对不起，你不是项目管理员，没有此操作权限");
		}
	}

	@Override
	public List<GlobalVariablePO> list(String proId) {
		return globalVariableDAO.list(proId);
	}

}
