package com.pingan.pafa5.admin.abtest.services.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.redis.Redis;
import com.pingan.pafa5.admin.abtest.services.ABTestingAdminDemoService;

/**
 * 灰度发布管控平台服务实现类
 * @author WANGJUN791
 *
 */
@Service
public class ABTestingAdminDemoServiceImpl extends BaseServices implements ABTestingAdminDemoService {
	
	@Autowired
	private Redis redis; 

	@Override
	public String applyPolicy(String key, String policy) {
		return redis.getCommands().set(key.getBytes(), policy.getBytes());
	}

	@Override
	public long editPolicyData(String key, String newIp, String oldIp) {
		long result = redis.getCommands().srem(key.getBytes(), oldIp.getBytes());
		if (result > 0) {
			return redis.getCommands().sadd(key.getBytes(), newIp.getBytes());
		} else {
			return 0;
		}
	}
	
	@Override
	public long delPolicyData(String key, String ip) {
		return redis.getCommands().srem(key.getBytes(), ip.getBytes());
	}

	@Override
	public long addPolicyData(String key, String ip) {
		return redis.getCommands().sadd(key.getBytes(), ip.getBytes());
	}

	@Override
	public List<String> listIpWhiteTable(String key) {
		Set<byte[]> values = redis.getCommands().smembers(key.getBytes());
		List<String> list = new ArrayList<String>(values.size());
		for(byte[] value : values) {
			list.add(new String(value));
		}
		return list;
	}
	
	@Override
	public List<String> listPolicyData(String key) {
		Set<byte[]> values = redis.getCommands().smembers(key.getBytes());
		List<String> list = new ArrayList<String>(values.size());
		for(byte[] value : values) {
			list.add(new String(value));
		}
		return list;
	}
	
	@Override
	public Map<String, String> listPolicy(String key) {
		Map<byte[], byte[]> values = redis.getCommands().hgetAll(key.getBytes());
		Map<String, String> map = new HashMap<String, String>(values.size());
		for(Entry<byte[], byte[]> entry : values.entrySet()) {
			map.put(new String(entry.getKey()), new String(entry.getValue()));
		}
		return map;
	}
	
	@Override
	public String addPolicy(String key, Map<String, String> value) {
		Map<byte[], byte[]> map = new HashMap<byte[], byte[]>(value.size());
		for(Entry<String, String> entry : value.entrySet()) {
			map.put(entry.getKey().getBytes(), entry.getValue().getBytes());
		}
		return redis.getCommands().hmset(key.getBytes(), map);
	}
}