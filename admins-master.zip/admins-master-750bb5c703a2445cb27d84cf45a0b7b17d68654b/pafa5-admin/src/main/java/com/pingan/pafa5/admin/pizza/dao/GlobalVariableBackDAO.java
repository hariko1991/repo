package com.pingan.pafa5.admin.pizza.dao;

import java.util.List;

import com.pingan.pafa5.admin.pizza.po.GlobalVariableBackupPO;

public interface GlobalVariableBackDAO {
	public void add(GlobalVariableBackupPO po);
	public List<GlobalVariableBackupPO> list(String proId,String versionId);
}