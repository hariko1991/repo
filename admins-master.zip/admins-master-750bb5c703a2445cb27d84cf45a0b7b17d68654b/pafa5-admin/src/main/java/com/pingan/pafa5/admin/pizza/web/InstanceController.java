package com.pingan.pafa5.admin.pizza.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa5.admin.commons.SARManagerConstants;
import com.pingan.pafa5.admin.pizza.dto.InstanceDTO;
import com.pingan.pafa5.admin.pizza.form.PizzaInstanceForm;
import com.pingan.pafa5.admin.pizza.services.PizzaInstanceService;

/**
 * 节点管理
 * 
 * @author chenqiang149
 *
 */
@Controller
@RequestMapping("/pizzamgr/instance")
public class InstanceController extends BaseController {

	@ActionClient(name = "pafa5-admin-systems.isOwner")
	private IServiceClient ownerService;

	@ActionClient(name = "pafa5-admin-fling.listIntances")
	private IServiceClient listIntances;

	@SuppressWarnings("unchecked")
	@RequestMapping("/list.do")
	@ResponseBody
	public ResponseModel list(@RequestParam(value = "projectId", required = true) String projectId,
			@RequestParam(value = "limit", required = true, defaultValue = "99999") int limit,
			@RequestParam(value = "page", required = true, defaultValue = "1") int page,
			@RequestParam(value = "instanceIp", required = false ) String instanceIp,
			@RequestParam(value = "group", required = false) String group) {
		ResponseModel model = new ResponseModel("0","成功");
		
		Map<String,String> instancesMap = new HashMap<String,String>();
		
		Map<String,String> pa = new HashMap<String,String>();
		pa.put("projectId", projectId);
		pa.put("instanceIp", instanceIp);
		ServiceResults results = listIntances.invoke(pa);
		List<InstanceDTO> dtos = new ArrayList<InstanceDTO>();
		if("0".equals(results.get("responseCode"))) {
			List<Map<String, String>> maps = (List<Map<String, String>>) results.get("datas");
			PizzaInstanceForm instanceForm = null;
			for (Map<String, String> map : maps) {
				InstanceDTO instanceDTO = JSON.parseObject(JSON.toJSONString(map), InstanceDTO.class);
				instanceDTO.setInstanceIp(instanceDTO.getInstanceIp()+".properties");
				instanceDTO.setGroup("");
				instanceForm = new PizzaInstanceForm();
				instanceForm.setInstanceIp(instanceDTO.getInstanceIp());
				instanceForm.setProjectId(instanceDTO.getProjectId());
				
				InstanceDTO instanceDTO2 = pizzaInstanceService.getById(instanceForm);
				if(instanceDTO2!=null) {
					instanceDTO.setGroup(instanceDTO2.getGroup());
					instanceDTO.setPappName(StringUtils.isNotEmpty(instanceDTO2.getPappName())?instanceDTO2.getPappName():instanceDTO.getPappName());
					instanceDTO.setSha1String(instanceDTO2.getSha1String());
					instanceDTO.setLength(instanceDTO2.getLength());
					instanceDTO.setUpdatedBy(instanceDTO2.getUpdatedBy());
					instanceDTO.setUpdatedDate(instanceDTO2.getUpdatedDate());
				}
				instanceDTO.setStatus(instanceDTO.getStatus());
				if(StringUtils.isNotEmpty(group)) {
					if(instanceDTO.getGroup().contains(group)) {
						dtos.add(instanceDTO);
						instancesMap.put(instanceDTO.getInstanceIp(), instanceDTO.getInstanceIp());
					}
				}else {
					dtos.add(instanceDTO);
					instancesMap.put(instanceDTO.getInstanceIp().replaceAll(".properties", ""), instanceDTO.getInstanceIp());
				}
			}
		}
		//查询节点配置表中存在，但在心跳表中不存在的数据，且符合查询条件的
		
		List<InstanceDTO> dtos2 = pizzaInstanceService.getInstances(projectId,group,instancesMap,instanceIp);
		dtos.addAll(dtos2);
		
		model.put("root", dtos);
		model.put("totalProperty", dtos.size());
		return model;
	}
	
	@Resource
	private PizzaInstanceService pizzaInstanceService;
	
	@RequestMapping("/saveConfig.do")
	@ResponseBody
	public ResponseModel saveConfig(HttpServletRequest request,PizzaInstanceForm instanceForm) throws Exception {
		ResponseModel model = new ResponseModel("0","成功");
		try {
			int status = pizzaInstanceService.saveConfig(instanceForm);
			switch (status) {
			case 1:
				model.setResponseMsg("保存成功");
				break;
			case 2:
				model.setResponseMsg("更新成功");
				break;
			case 3:
				model.setResponseCode("601");
				model.setResponseMsg("内容无变化，操作无效");
				break;
			case 4:
				model.setResponseCode("602");
				model.setResponseMsg("dubbo.service.group配置项的值只允许'字母、数字、中划线（-）、下划线（_）'");
				break;
			default:
				break;
			}
		} catch (Exception e) {
			logger.error("操作异常：",e);
			model.setResponseCode("602");
			model.setResponseMsg("操作失败："+e.getMessage());
		}
		
		return model;
	}
	
	@RequestMapping("/addConfig.do")
	@ResponseBody
	public ResponseModel addConfig(HttpServletRequest request,PizzaInstanceForm instanceForm) throws Exception {
		ResponseModel model = new ResponseModel("0","成功");
		try {
			int status = pizzaInstanceService.addConfig(instanceForm);
			switch (status) {
			case 1:
				model.setResponseCode("601");
				model.setResponseMsg("节点配置已存在,请更换IP");
				break;
			case 2:
				model.setResponseCode("602");
				model.setResponseMsg("节点IP不合法");
				break;
			case 3:
				model.setResponseMsg("保存成功");
				break;
			case 4:
				model.setResponseCode("602");
				model.setResponseMsg("dubbo.service.group配置项的值只允许'字母、数字、中划线（-）、下划线（_）'");
				break;
			default:
				break;
			}
		} catch (Exception e) {
			logger.error("操作异常：",e);
			model.setResponseCode("602");
			model.setResponseMsg("操作失败："+e.getMessage());
		}
		
		return model;
	}
	
	@RequestMapping("/getConfig.do")
	@ResponseBody
	public ResponseModel getConfig(HttpServletRequest request,PizzaInstanceForm instanceForm) {
		ResponseModel model = new ResponseModel("0","成功");
		InstanceDTO instanceDTO = pizzaInstanceService.getById(instanceForm);
		model.put("content", instanceDTO.getContent());
		model.put("group", instanceDTO.getGroup());
		return model;
	}

	public void isOwner(String domainId) {
		if (domainId == null || SARManagerConstants.DEF.equalsIgnoreCase(domainId)) {
			return;
		}
		ServiceParams params = new ServiceParams();
		params.set("groupId", domainId);
		ServiceResults results = ownerService.invoke(params);
		boolean isBoo = results.getBool("isowner");
		if (!isBoo) {
			throw new ResponseCodeException("354", "对不起，你不是领域负责人，没有此操作权限");
		}
	}

	public void setOwnerService(IServiceClient ownerService) {
		this.ownerService = ownerService;
	}

}
