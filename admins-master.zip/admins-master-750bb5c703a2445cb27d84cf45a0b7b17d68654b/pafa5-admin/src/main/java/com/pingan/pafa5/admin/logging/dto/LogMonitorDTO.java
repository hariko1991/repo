package com.pingan.pafa5.admin.logging.dto;

import java.util.Date;


public class LogMonitorDTO {
	
	private String id;

	/**队列ID*/
	private String queueName;
	
	private String projectId;
	
	/**监控目标App*/
	private String targetPapp;
	
	/**过期时间*/
	private Integer expiredTime;
	
	/**redis URL*/
	private String redisURL;

	/**redis pizza url*/
	private String pizzaURL;
	
	
	/**状态：0正常，1过期*/
	private Integer status;
	
	private String createdBy;
	private Date createdDate;


	public String getQueueName() {
		return queueName;
	}


	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	
	public String getProjectId() {
		return projectId;
	}


	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}


	public String getTargetPapp() {
		return targetPapp;
	}


	public void setTargetPapp(String targetPapp) {
		this.targetPapp = targetPapp;
	}


	public Integer getExpiredTime() {
		return expiredTime;
	}


	public void setExpiredTime(Integer expiredTime) {
		this.expiredTime = expiredTime;
	}


	public String getRedisURL() {
		return redisURL;
	}


	public void setRedisURL(String redisURL) {
		this.redisURL = redisURL;
	}




	public String getPizzaURL() {
		return pizzaURL;
	}


	public void setPizzaURL(String pizzaURL) {
		this.pizzaURL = pizzaURL;
	}


	public Integer getStatus() {
		return status;
	}


	public void setStatus(Integer status) {
		this.status = status;
	}


	public String getCreatedBy() {
		return createdBy;
	}


	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}


	public Date getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}


	public String getId() {
		return id;
	}


	public void setId(String id) {
		this.id = id;
	}
	
	
	
}
