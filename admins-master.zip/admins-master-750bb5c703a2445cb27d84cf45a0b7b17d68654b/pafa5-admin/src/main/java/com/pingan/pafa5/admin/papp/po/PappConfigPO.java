package com.pingan.pafa5.admin.papp.po;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.paic.pafa.validator.annotation.VLength;
import com.pingan.pafa5.admin.commons.BasePO;

/**
 * 组件配置
 *
 * @author linkaibin447
 */
@Document
public class PappConfigPO extends BasePO {
    /**
     * 组件配置id
     */
    @org.springframework.data.annotation.Id
    private String id;

    /**
     * 组件id
     */
    @VLength(max=250)
    private String pappId;
    /**
     * 项目id
     */
    @Indexed
    private String projectId;
    /**
     * 配置项
     */
    @VLength(max=250)
    private String cfgItem;
    /**
     * 配置项说明
     */
    @VLength(max=250)
    private String cfgItemDes;
    /**
     * 配置值
     */
    @VLength(max=250)
    private String cfgValues;

    public String getPappId() {
        return pappId;
    }

    public void setPappId(String pappId) {
        this.pappId = pappId;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getCfgItem() {
        return cfgItem;
    }

    public void setCfgItem(String cfgItem) {
        this.cfgItem = cfgItem;
    }

    public String getCfgItemDes() {
        return cfgItemDes;
    }

    public void setCfgItemDes(String cfgItemDes) {
        this.cfgItemDes = cfgItemDes;
    }

    public String getCfgValues() {
        return cfgValues;
    }

    public void setCfgValues(String cfgValues) {
        this.cfgValues = cfgValues;
    }

}
