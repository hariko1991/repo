package com.pingan.pafa5.admin.fling.job;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.paic.pafa.job.TimerJob;
import com.pingan.pafa.redis.lock.RedisLock;
import com.pingan.pafa.redis.lock.RedisLockFactory;
import com.pingan.pafa5.admin.fling.services.DruidDatasourceService;

/**
 * 运维中心-管控指令数据清理
 * 
 * @author ZHANGJIAWEI370
 * 
 */
@Component
public final class DruidHeartBeatJob {
	private static final String LOCK_OBJ_ID = "pizza-dubbo-druid-heart";
	private Log logger = LogFactory.getLog(this.getClass());
	//
	@Autowired
	private DruidDatasourceService druidDatasourceService;

	@Value("${druid.hearbeat.enable}")
	private boolean heartBeat;

	@Autowired
	private RedisLockFactory lockFactory;

	//
	@TimerJob(cronExpression = "${job.druid.hearbeat.time}")
	public void execute() throws Exception {
		if (heartBeat) {
			RedisLock lock = lockFactory.getLock(LOCK_OBJ_ID + System.getProperty("env.lock", ""));
			if (lock.tryLock()) {
				try {
					logger.info("开始druid心跳过期检测★★★★★★★★★★★★★★★★★★★★★★★★★★★");
					druidDatasourceService.druidHeartBeat();
					logger.info("结束druid心跳过期检测★★★★★★★★★★★★★★★★★★★★★★★★★★★");
				} finally {
					lock.unlock();
				}
			}
		}
	}
	//
	// public void setFlingCommandServices(FlingCommandServices
	// flingCommandServices) {
	// this.flingCommandServices = flingCommandServices;
	// }

}
