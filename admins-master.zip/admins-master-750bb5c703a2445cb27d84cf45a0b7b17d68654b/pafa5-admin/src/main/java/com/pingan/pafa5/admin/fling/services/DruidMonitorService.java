package com.pingan.pafa5.admin.fling.services;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.fling.po.DruidDatasourcePO;
import com.pingan.pafa5.admin.fling.po.DruidSqlPO;

public interface DruidMonitorService {
	/**
	 * 查询连接池列表
	 * @param domainId
	 * @param pappName
	 * @param limit
	 * @param page
	 * @return
	 */
	public PageDataDTO<DruidDatasourcePO> listForDatasource(String domainId, String pappName, int limit, int page);
	/**
	 * 查询连接池详情
	 * @param id
	 * @param identify
	 * @return
	 */
	public DruidDatasourcePO getDataSourceById(String id, int identify);
	/**
	 * 查询sql监控信息列表
	 * @param druidDatasourceId
	 * @param identify
	 * @param limit
	 * @param page
	 * @return
	 */
	public PageDataDTO<DruidSqlPO> listForSql(String druidDatasourceId, int identify, int limit, int page);
	
	
}
