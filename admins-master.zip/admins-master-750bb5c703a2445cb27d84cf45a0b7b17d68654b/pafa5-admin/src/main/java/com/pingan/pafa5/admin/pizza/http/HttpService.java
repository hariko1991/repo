package com.pingan.pafa5.admin.pizza.http;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpException;
import org.apache.http.HttpStatus;
import org.apache.http.NameValuePair;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSON;
import com.paic.pafa.biz.services.BaseServices;

@Component
public class HttpService extends BaseServices {
	
	protected Log logger = LogFactory.getLog(HttpService.class);

	/** 登录请求
	 * 
	 * @param uri
	 * @param params
	 * @return
	 * @throws HttpException
	 */
	public LoginResponse loginRequest(String uri, Map<String, String> params) throws HttpException {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost post = new HttpPost(uri);
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		for (Map.Entry<String, String> map : params.entrySet()) {
			formparams.add(new BasicNameValuePair(map.getKey(), map.getValue()));
		}
		//设置socketTimeout，表示数据传输处理时间||设置connectTimeout，表示建立连接的timeout时间
		RequestConfig requestConfig = RequestConfig.custom().setConnectTimeout(3000).build();
		post.setConfig(requestConfig);
		UrlEncodedFormEntity uefEntity;
		CloseableHttpResponse resp = null;
		LoginResponse response = null;
		try {
			uefEntity = new UrlEncodedFormEntity(formparams, "UTF-8");
			post.setEntity(uefEntity);
			logger.info("Do request:" + post.getURI());
			resp = httpclient.execute(post);
			if (HttpStatus.SC_OK == resp.getStatusLine().getStatusCode()) {
				HttpEntity entity = resp.getEntity();
				if (entity != null) {
					String result = EntityUtils.toString(entity, "UTF-8");
					response = JSON.parseObject(result, LoginResponse.class);
				}
				if (response == null) {
					throw new HttpException("HttpEntity is null");
				}
				if (response.getSuccess()) {
					for (Header h : resp.getHeaders("Set-Cookie")) {
						String value = h.getValue();
						if (value.startsWith("T_PAFA_PIZZA_ADMIN_SSO")) {
							response.setCookie(h.getValue());
						}
					}
				}
				return response;
			} else {
				throw new HttpException("HttpStatus=" + resp.getStatusLine());
			}
		} catch (Exception e) {
			logger.error("HttpRequest:" + uri + " error,cause:"
					+ e.getMessage(), e);
			throw new HttpException("HttpRequest:" + uri
					+ " error,cause:" + e.getMessage(), e);
		} finally {
			try {
				if (resp != null)
					resp.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/** 同步请求
	 * 
	 * @param uri
	 * @param params
	 * @return
	 * @throws HttpException
	 */
	public HttpResponse asyncRequest(String uri, String cookie, Map<String, String> params) throws HttpException {
		CloseableHttpClient httpclient = HttpClients.createDefault();
		HttpPost post = new HttpPost(uri);
		List<NameValuePair> formparams = new ArrayList<NameValuePair>();
		for (Map.Entry<String, String> map : params.entrySet()) {
			formparams.add(new BasicNameValuePair(map.getKey(), map.getValue()));
		}
		
		//设置请求和传输超时时间
		RequestConfig requestConfig = RequestConfig.custom()
				.setSocketTimeout(6000)
				.setConnectTimeout(6000)
				.build();
		post.setConfig(requestConfig);
		
		post.addHeader("Cookie", cookie);

		UrlEncodedFormEntity uefEntity;
		CloseableHttpResponse resp = null;
		LoginResponse response = null;
		try {
			uefEntity = new UrlEncodedFormEntity(formparams, "UTF-8");
			post.setEntity(uefEntity);
			logger.info("Do request:" + post.getURI());
			resp = httpclient.execute(post);
			if (HttpStatus.SC_OK == resp.getStatusLine().getStatusCode()) {
				HttpEntity entity = resp.getEntity();
				if (entity != null) {
					String result = EntityUtils.toString(entity, "UTF-8");
					response = JSON.parseObject(result, LoginResponse.class);
				}
				if (response == null) {
					throw new HttpException("HttpEntity is null");
				}
				if (response.getSuccess()) {
					for (Header h : resp.getHeaders("Set-Cookie")) {
						String value = h.getValue();
						if (value.startsWith("T_PAFA_PIZZA_ADMIN_SSO")) {
							response.setCookie(h.getValue());
						}
					}
				}
				return response;
			} else {
				throw new HttpException("HttpStatus=" + resp.getStatusLine());
			}
		} catch (Exception e) {
			logger.error("HttpRequest:" + uri + " error,cause:"
					+ e.getMessage(), e);
			throw new HttpException("HttpRequest:" + uri
					+ " error,cause:" + e.getMessage(), e);
		} finally {
			try {
				if (resp != null)
					resp.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
	
	public Map<String, String> allResourcesRequest(CloseableHttpClient httpclient,String uri) {
		HttpPost post = new HttpPost(uri);
		CloseableHttpResponse resp = null;
		Map<String, Object> response = null;
		try {
			logger.info("Do request:" + post.getURI());
			resp = httpclient.execute(post);
			if (HttpStatus.SC_OK == resp.getStatusLine().getStatusCode()) {
				HttpEntity entity = resp.getEntity();
				if (entity != null) {
					String result = EntityUtils.toString(entity, "UTF-8");
					response = JSON.parseObject(result, Map.class);
				}
				if (response == null) {
					throw new HttpException("HttpEntity is null");
				}
				List<Map<String, Object>> list = (List)response.get("datas");
				Map<String, String> mapping = new HashMap<String, String>();
				for(Map<String, Object> item : list) {
					String proId = (String)item.get("projectId");
					String group = (String)item.get("group");
					String key = (String)item.get("key");
					String md5 = (String)item.get("md5");
					if (proId == null) {
						mapping.put(group + "/" + key, md5);
					} else {
						mapping.put(proId + "/" + group + "/" + key, md5);
					}
				}
				return mapping;
			} else {
				throw new HttpException("HttpStatus=" + resp.getStatusLine());
			}
		} catch (Exception e) {
			logger.error("HttpRequest:" + uri + " error,cause:" + e.getMessage(), e);
			return new HashMap<String, String>();
		} finally {
			try {
				if (resp != null)
					resp.close();
			} catch (IOException e) {
				logger.info("",e);
			}
		}
	}

	public boolean test(String url) {
		boolean success = false;
		try {
			CloseableHttpClient httpclient = HttpClients.createDefault();
			HttpGet httpGet = new HttpGet(url);
			logger.info("Do request:" + url);
			
			CloseableHttpResponse httpResponse = httpclient.execute(httpGet);
			
			if (HttpStatus.SC_OK == httpResponse.getStatusLine().getStatusCode()) {
				success = true;	
			}
		} catch (ClientProtocolException e) {
			logger.error("Do request exception :", e);
			return false;
		} catch (IOException e) {
			logger.error("Do request exception :", e);
			return false;
		}
		return success;
	}
}
