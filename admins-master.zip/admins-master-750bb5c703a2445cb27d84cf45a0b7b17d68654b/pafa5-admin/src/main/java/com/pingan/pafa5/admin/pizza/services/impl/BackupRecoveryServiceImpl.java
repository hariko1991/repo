package com.pingan.pafa5.admin.pizza.services.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

import javax.annotation.Resource;

import org.bson.types.ObjectId;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.biz.services.BaseServices;
import com.paic.pafa.utils.MDCUtil;
import com.pingan.pafa.exception.Pafa5Exception;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa.pizza.PizzaManager;
import com.pingan.pafa.redis.lock.RedisLock;
import com.pingan.pafa.redis.lock.RedisLockFactory;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.commons.PizzaManagerHolder;
import com.pingan.pafa5.admin.pizza.dao.GlobalVariableBackDAO;
import com.pingan.pafa5.admin.pizza.dao.GlobalVariableDAO;
import com.pingan.pafa5.admin.pizza.dao.PizzaConfigBackupDAO;
import com.pingan.pafa5.admin.pizza.dao.PizzaConfigDAO;
import com.pingan.pafa5.admin.pizza.dao.PizzaOperationLogDAO;
import com.pingan.pafa5.admin.pizza.dao.PizzaRecoveryRegisterLogDAO;
import com.pingan.pafa5.admin.pizza.dto.OperationLogSearchDTO;
import com.pingan.pafa5.admin.pizza.po.ConfigGroupPO;
import com.pingan.pafa5.admin.pizza.po.GlobalVariableBackupPO;
import com.pingan.pafa5.admin.pizza.po.GlobalVariablePO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigBackupPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigPO;
import com.pingan.pafa5.admin.pizza.po.PizzaOperationLogPO;
import com.pingan.pafa5.admin.pizza.po.PizzaRecoveryRegisterLogPo;
import com.pingan.pafa5.admin.pizza.services.BackupRecoveryService;
import com.pingan.pafa5.admin.pizza.services.ConfigGroupServices;
import com.pingan.pafa5.admin.pizza.services.GlobalVariableService;
import com.pingan.pafa5.admin.pizza.services.PizzaConfigServices;
import com.pingan.pafa5.admin.pizza.utils.ConfigContentUtils;
import com.pingan.pafa5.admin.sso.UserPrincipal;

@Service
public class BackupRecoveryServiceImpl extends BaseServices implements BackupRecoveryService {
    
    @Value("${jute.maxbuffer}")
    private int juteMaxSize = 5 * 1024 * 1024;  //写入ZK时文件最大大小

    @Autowired
    private ConfigContentUtils configContentUtils;
    
	@Autowired
	private PizzaConfigServices pizzaConfigServices;

	@Autowired
	private ConfigGroupServices configGroupServices;
	
	@Autowired
	private GlobalVariableService globalVariableService;

	@Autowired
	private PizzaManagerHolder managerHolder;

	@Autowired
	private PizzaOperationLogDAO pizzaOperationLogDAO;
	
	@Autowired
    private PizzaConfigBackupDAO pizzaConfigBackupDAO;
	
	@Autowired
	private PizzaConfigDAO pizzaConfigDAO;
	
	@ActionClient(name = "pafa5-admin-systems.findAllProjects")
    private IServiceClient listAllDomainIds;
	
	@ActionClient(name="pafa5-admin-security.backUpSecurity")
	private IServiceClient backUpSecurity;
	
	@ActionClient(name="pafa5-admin-security.queryBackUpSecurity")
	private IServiceClient queryBackUpSecurity;
	
	@ActionClient(name="pafa5-admin-security.rollbackSecurity")
	private IServiceClient rollbackSecurity;
	
	@Autowired
    private RedisLockFactory lockFactory;
	
	@Resource
	private GlobalVariableBackDAO globalVariableBackDAO;
	
	private static ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors() + 1);

	@Override
	public PageDataDTO<PizzaOperationLogPO> search(OperationLogSearchDTO queryVO) {
		if (queryVO.getPage() <= 0) {
			queryVO.setPage(1);
		}
		int limit = queryVO.getLimit();
		if (limit <= 0) {
		    queryVO.setLimit(20);
		}		
		if (limit > 100) {
		    queryVO.setLimit(100);
		}		
		return pizzaOperationLogDAO.pageQuery(queryVO);
	}
	
	public String backup(String targetDomainId, String targetDomainName, String operationReason){
        if (logger.isInfoEnabled()) {
            logger.info("Backup pizza configures begin...");
        }
        
        RedisLock lock = lockFactory.getLock(LOCK_OBJ_ID);
        if (lock.tryLock()) {
            //计算需要备份的领域
            List<String> targetDomainIds;
            if(targetDomainId == null || "ALL".equals(targetDomainId.toUpperCase())) {
                targetDomainIds = allDomainIds();
            } else {
                targetDomainIds = new ArrayList<String>(1);
                targetDomainIds.add(targetDomainId);
            }
            //记录备份日志
            UserPrincipal up = UserPrincipal.get();
            String versionId = generateVersionId();
            PizzaOperationLogPO log = new PizzaOperationLogPO();
            log.setOperationType("Backup");
            log.setOperationName("备份资源数据库");
            log.setRemark("备份资源数据库以便回滚，版本号：" + versionId);
            log.setOperationReason(operationReason);
            log.setOperationIp(up.getIp());
            log.setProjectId(targetDomainId);
            log.setProjectName(targetDomainName);
            log.setReasonId(versionId);
            POUtils.setForAdd(up.getUid(), log);
            if (logger.isInfoEnabled()) {
                logger.info("Backup version : " + versionId);
            }       
            String logId = pizzaOperationLogDAO.add(log);
            Runnable task;
			try {
				task = new BackupTask(logId, targetDomainIds, versionId, lock);
				executor.execute(task);
			} catch (Exception e) {
				logger.error("",e);
			}
            return versionId;
        } else {
            logger.info("Another backup/rollback/recovery action is running.");
            throw new ResponseCodeException("456", "请稍后再试!另一个备份或回滚任务正在执行中...");
        }
    }
	
	private class BackupTask implements Runnable {
	    private String logId;
	    private List<String> targetDomainIds;
	    private String versionId;
	    private RedisLock lock;	    
	    
        public BackupTask(String logId, List<String> targetDomainIds, String versionId, RedisLock lock)throws Exception {
            super();
            this.logId = logId;
            this.targetDomainIds = targetDomainIds;
            this.versionId = versionId;
            this.lock = lock;
        }

        @Override
        public void run(){
        	boolean flag = true;
            try {
                CountDownLatch latch = new CountDownLatch(targetDomainIds.size());
                AtomicInteger dataIndex = new AtomicInteger();
                List<Future<Boolean>> results = new ArrayList<Future<Boolean>>(targetDomainIds.size());
                for(String domainId : targetDomainIds) {
                    Callable<Boolean> worker = new BackupWorker(latch, domainId, versionId, dataIndex);
                    Future<Boolean> future = executor.submit(worker);
                    results.add(future);                  
                }
                
                latch.await();
                
                for(Future<Boolean> result : results) {
                    try {
                        if(!result.get()) {
                            flag = false;
                            continue;
                        }
                    } catch (Exception e) {
                        logger.error("",e);
                        PizzaOperationLogPO dto = new PizzaOperationLogPO();
                        dto.setId(logId);
                        dto.setStatus(PizzaOperationLogPO.STATUS_FAILED);
                        dto.setRemark("备份操作出错.");
                        pizzaOperationLogDAO.updateStatus(dto);
                        throw new ResponseCodeException("456","备份出错！");
                    }
                }
                
                if(flag==true) {
                    pizzaOperationLogDAO.completed(logId);
                } else {
                    PizzaOperationLogPO dto = new PizzaOperationLogPO();
                    dto.setId(logId);
                    dto.setStatus(PizzaOperationLogPO.STATUS_FAILED);
                    dto.setRemark("备份操作出错.");
                    pizzaOperationLogDAO.updateStatus(dto);
                }
            } catch (InterruptedException e) {
            	flag=false;
                e.printStackTrace();
            } finally {
            	if(flag==false){
            		 PizzaOperationLogPO dto = new PizzaOperationLogPO();
                     dto.setId(logId);
                     dto.setStatus(PizzaOperationLogPO.STATUS_FAILED);
                     dto.setRemark("备份操作出错.");
                     pizzaOperationLogDAO.updateStatus(dto);
            	}
                lock.unlock();
            }
        }  
	}
	
	private class BackupWorker implements Callable<Boolean>{
	    private CountDownLatch latch;
	    private String domainId;
	    private String versionId; 
	    private AtomicInteger dataIndex;
	    
        public BackupWorker(CountDownLatch latch, String domainId, String versionId,
                AtomicInteger dataIndex){
            super();
            this.latch = latch;
            this.domainId = domainId;
            this.versionId = versionId;
            this.dataIndex = dataIndex;
        }

        @Override
        public Boolean call() throws Exception {
            try {
                return _backup(domainId, versionId, dataIndex);
            } catch(Exception e){
            	throw new ResponseCodeException("456","备份异常！");
            }finally {
                latch.countDown();
            }
        }
	    
	}
	
	private boolean _backup(String domainId, String versionId, AtomicInteger dataIndex) throws Exception{
        long t1 = System.nanoTime();
        MDCUtil.set(MDCUtil.generateRequestId());
        try {
            //1：先备份全局资源，每个组        	
        	List<ConfigGroupPO> groups = configGroupServices.listAll();
            for (ConfigGroupPO group : groups) {
                backupForGroup(domainId, group.getGroupCode(), versionId, dataIndex);
            }
            //2：备份全局变量
            backUpForGlobal(domainId, versionId);
            //3：备份密码
            //TODO 
            boolean bool = backUpSecurity(domainId, versionId);
            if (logger.isInfoEnabled()) {
                logger.info("Backup domainId : " + domainId + " completed, " + (System.nanoTime() - t1) / 1000 / 1000.0 + "ms.");
            }
            if(!bool){
            	return false;
            }
            
            return true;
        } catch (Exception ex) {
            if (logger.isErrorEnabled()) {
                logger.error("Backup failed， domainId : " + domainId + ", versionId : " + versionId, ex);
                throw new ResponseCodeException("456","备份数据文件名中不能包含除了'_'、'-'、'.'、'#'之外的其它特殊字符");
            }
            return false;
        }finally{
        	MDCUtil.clear();
        }
    }

	private boolean backUpSecurity(String domainId, String versionId){
		Map<String,String> params = new HashMap<String, String>();
		params.put("groupId", domainId);
		params.put("versionId", versionId);
		ServiceResults results = backUpSecurity.invoke(params);
		logger.info(results);
		if("0".equals(results.getString("responseCode"))){
			return true;
		}else{
			return false;
		}
	}
	
	/**
	 * 备份全局变量
	 * @param domainId	领域id
	 * @param versionId	版本号
	 */
	private void backUpForGlobal(String domainId,String versionId){
		List<GlobalVariablePO> globalVariablePOs = globalVariableService.list(domainId);
		GlobalVariableBackupPO po = null;
		
		if(globalVariablePOs!=null&&globalVariablePOs.size()>0){
			if(logger.isInfoEnabled()){
				logger.info("全局变量备份 size="+globalVariablePOs.size());
			}
			int index = 1;
			for (GlobalVariablePO globalVariablePO : globalVariablePOs) {
				po = new GlobalVariableBackupPO();
				po.setId(new ObjectId().toString());
				po.setIndex(index);
				po.setProId(domainId);
				po.setProName(globalVariablePO.getProName());
				po.setProperty(globalVariablePO.getProperty());
				po.setValue(globalVariablePO.getValue());
				po.setValueMd5(configContentUtils.md5(globalVariablePO.getValue()));
				po.setVersionId(versionId);
				po.setHidden(globalVariablePO.isHidden());
				
				po.setCreatedBy(globalVariablePO.getCreatedBy());
				po.setCreatedDate(globalVariablePO.getCreatedDate());
				po.setRequestId(globalVariablePO.getRequestId());
				po.setUpdatedBy(globalVariablePO.getUpdatedBy());
				po.setUpdatedDate(globalVariablePO.getUpdatedDate());
				po.setBackUpTime(new Date());
				globalVariableBackDAO.add(po);
				logger.info("BackUp Property:"+globalVariablePO.getId());
				index++;
			}
		}else{
			if(logger.isInfoEnabled()){
				logger.info("该领域["+domainId+"]下无全局变量,无需备份");
			}
		}
	}
	
    protected void backupForGroup(String domainId, String group, String versionId, AtomicInteger dataIndex) throws Exception{
        List<String> dbKeySet = pizzaConfigServices.listKeys(domainId, group);
        int size = dbKeySet == null ? 0 : dbKeySet.size();
        if (logger.isInfoEnabled()) {
            logger.info("backupForGroup:" + group + " keys size=" + size);
        }
        if (size == 0) {
            return;
        }
        for (String key : dbKeySet) {
            PizzaConfigPO configPo = pizzaConfigServices.get(domainId, group, key);
            String pizzaValue = pizzaConfigServices.getConfigContent(domainId, group, key);
            PizzaConfigBackupPO po = new PizzaConfigBackupPO();
            po.setProjectName(configPo.getProjectName());
            po.setVersionId(versionId);
            po.setIndex(dataIndex.incrementAndGet());
            po.setProjectId(configPo.getProjectId());
            po.setValueMd5(configPo.getValueMd5());
            po.setPizzaValue(pizzaValue);
            po.setPizzaGroup(configPo.getPizzaGroup());
            po.setPizzaKey(configPo.getPizzaKey());
            pizzaConfigBackupDAO.add(po);
        }
    }

	/************************************************************************************************************************************************************/
    
    public String rollback(String referOperationId, String operationReason) {
        RedisLock lock = lockFactory.getLock(LOCK_OBJ_ID);
        if (lock.tryLock()) {
            if (logger.isInfoEnabled()) {
                logger.info("Rollback pizza configures begin...");
            }
            PizzaOperationLogPO refer = pizzaOperationLogDAO.getById(referOperationId);
            if (refer == null) {
                throw new NullPointerException("Not found operationLog:" + referOperationId);
            }
            if (refer.getStatus() != PizzaOperationLogPO.STATUS_COMPLETED) {
                throw new NullPointerException("OperationLog:" + referOperationId + " status error.");
            }
          //计算需要回滚的领域
            List<String> targetDomainIds;
            String targetDomainId = refer.getProjectId();
            if(targetDomainId == null || "ALL".equals(targetDomainId.toUpperCase())) {
                targetDomainIds = allDomainIds();
            } else {
                targetDomainIds = new ArrayList<String>(1);
                targetDomainIds.add(targetDomainId);
            }
            UserPrincipal up = UserPrincipal.get(true);
            PizzaOperationLogPO log = new PizzaOperationLogPO();
            log.setOperationType("Rollback");
            log.setOperationIp(up.getIp());
            log.setProjectId(targetDomainId);
            log.setProjectName(refer.getProjectName());
            POUtils.setForAdd(up.getUid(), log);
            log.setOperationName("回滚资源数据库");
            log.setOperationReason(operationReason);
            String versionId = refer.getReasonId();
            log.setRemark("资源数据库回滚，版本号:" + versionId);
            log.setReasonId(versionId);
            String logId = pizzaOperationLogDAO.add(log);
            Runnable task = new RollbackTask(logId, targetDomainIds, versionId, lock,up);           
            executor.execute(task);
            boolean status = checkStatus(targetDomainId, versionId);
            if(status){
            	pizzaOperationLogDAO.completed(logId);
            	return versionId;
            }else{
            	PizzaOperationLogPO logDto= new PizzaOperationLogPO();
            	logDto.setStatus(PizzaOperationLogPO.STATUS_FAILED);
            	pizzaOperationLogDAO.updateStatus(logDto);
            }
            return null;
        } else {
            logger.info("Another backup/rollback/recovery action is running.");
            throw new ResponseCodeException("456","请稍后再试!另一个备份/回滚/恢复配置中心的任务正在执行中...");
        }
    }
    
    public class RollbackTask implements Runnable {
        private String logId;
        private List<String> targetDomainIds;
        private String versionId;
        private RedisLock lock;
		private UserPrincipal up;

        public RollbackTask(String logId, List<String> targetDomainIds, String versionId, RedisLock lock, UserPrincipal up) {
            super();
            this.logId = logId;
            this.targetDomainIds = targetDomainIds;
            this.versionId = versionId;
            this.lock = lock;
            this.up=up;
        }

        @Override
        public void run() {
            try {
                CountDownLatch latch = new CountDownLatch(targetDomainIds.size());
                List<Future<Boolean>> results = new ArrayList<Future<Boolean>>(targetDomainIds.size());
                //System.out.println();
                for(String domainId : targetDomainIds) {
                    Callable<Boolean> worker = new RollbackWorker(logId,latch, domainId, versionId,up);
                    Future<Boolean> future = executor.submit(worker);
                    results.add(future);                  
                }
                latch.await();
                boolean flag = true;
                for(Future<Boolean> result : results) {
                    try {
                        if(!result.get()) {
                            flag = false;
                            break;
                        }
                    } catch (ExecutionException e) {
                        e.printStackTrace();
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                PizzaOperationLogPO dto = new PizzaOperationLogPO();
                dto.setId(logId);
                dto.setStatus(PizzaOperationLogPO.STATUS_FAILED);
                dto.setRemark("回滚操作出错.");
                pizzaOperationLogDAO.updateStatus(dto);
            } finally {
                lock.unlock();
            }
        }
        
    }
    
    private class RollbackWorker implements Callable<Boolean> {
        private CountDownLatch latch;
        private String domainId;
        private String versionId; 
        private UserPrincipal up;
        private String logId;
        public RollbackWorker(String logId,CountDownLatch latch, String domainId, String versionId, UserPrincipal up) {
            super();
            this.latch = latch;
            this.domainId = domainId;
            this.versionId = versionId;
            this.up = up;
            this.logId=logId;
        }

        @Override
        public Boolean call()throws Exception{
            try {
            	boolean flag=_rollback(logId,domainId, versionId,up);
            	if(flag){
            		pizzaOperationLogDAO.completed(logId);
            	}else{
            		PizzaOperationLogPO dto = new PizzaOperationLogPO();
            		boolean checkStatus = checkStatus(domainId, versionId);
            		if(checkStatus){
            			pizzaOperationLogDAO.completed(logId);
            		}else{
            			dto.setId(logId);
            			dto.setStatus(PizzaOperationLogPO.STATUS_FAILED);
            			pizzaOperationLogDAO.updateStatus(dto);
            		}
            		 //latch.notify();
            	}
                return flag;
            }finally {
                latch.countDown();
            }
        }
        
    }

    public boolean _rollback(String logId,String domainId, String versionId,UserPrincipal up) {
        long t1 = System.nanoTime();

        try {
        	//回滚全局资源里面的数据
            List<ConfigGroupPO> groups = configGroupServices.listAll();
            for (ConfigGroupPO group : groups) {
            	String groupCode = group.getGroupCode();
                if (groupCode.length() > 0) {
                   rollbackForGroup(domainId, group.getGroupCode(), versionId,up,logId);
                }
            }
            
            //TODO 回滚全局变量数据
            rollBackForGlobal(domainId,versionId,up);
            //TODO 回滚密码数据
            boolean bool = rollBackForSecurity(domainId,versionId);
            
            if (logger.isInfoEnabled()) {
                logger.info("Rollback domainId : " + domainId + " completed, " + (System.nanoTime() - t1) / 1000 / 1000.0 + "ms.");
            }
            if(!bool){
            	return false;
            }
            
            return true;
        } catch (Exception ex) {
            if (logger.isErrorEnabled()) {
                logger.error("Rollback failed , domainId : " + domainId + ", versionId : " + versionId, ex);
            }
            return false;
        }
    }
    /**
     * 回滚密码
     * @param domainId
     * @param versionId
     * @return
     */
    private boolean rollBackForSecurity(String domainId,String versionId) {
    	Map<String,String> params = new HashMap<String, String>();
		params.put("groupId", domainId);
		params.put("versionId", versionId);
		ServiceResults results = rollbackSecurity.invoke(params);
		logger.info(results);
		if("0".equals(results.getString("responseCode"))) {
			return true;
		}else{
			logger.info(""+results.getString("responseMsg"));
			return false;
		}
    }
    
    @Autowired
	private GlobalVariableDAO globalVariableDAO;

    /**
     * 回滚全局变量
     * @param domainId
     * @param versionId
     * @param up
     */
    private void rollBackForGlobal(String domainId,String versionId,UserPrincipal up){
    	try {
    		Map<String,GlobalVariablePO> global = new HashMap<String, GlobalVariablePO>();
    		List<GlobalVariablePO> globalVariablePOs = globalVariableDAO.list(domainId);
    		for (GlobalVariablePO globalVariablePO : globalVariablePOs) {
    			global.put(globalVariablePO.getId(), globalVariablePO);
			}
    		
    		//查找出备份的全局变量数据
        	List<GlobalVariableBackupPO> list = globalVariableBackDAO.list(domainId, versionId);
        	if(list!=null&&list.size()>0){
	        	logger.info("rollback size = " + list.size());
	        	for (GlobalVariableBackupPO globalVariableBackupPO : list) {
	        		String id = globalVariableBackupPO.getProId()+"."+globalVariableBackupPO.getProperty();
	        		GlobalVariablePO po = globalVariableDAO.getById(id);
	        		if(global.containsKey(id)){
	        			global.remove(id);
	        		}
	        		if(po!=null){
	        			//修改数据
	        			po.setCreatedBy(globalVariableBackupPO.getCreatedBy());
	        			po.setCreatedDate(globalVariableBackupPO.getCreatedDate());
	        			po.setHidden(globalVariableBackupPO.isHidden());
	        			po.setProId(globalVariableBackupPO.getProId());
	        			po.setProName(globalVariableBackupPO.getProName());
	        			po.setProperty(globalVariableBackupPO.getProperty());
	        			po.setRequestId(globalVariableBackupPO.getRequestId());
	        			po.setUpdatedBy(globalVariableBackupPO.getUpdatedBy());
	        			po.setUpdatedDate(globalVariableBackupPO.getUpdatedDate());
	        			po.setValue(globalVariableBackupPO.getValue());
	        			globalVariableDAO.edit(po);
	        			logger.info("rollback globalvar update key="+id);
	        		}else{
	        			//新增数据
	        			po = new GlobalVariablePO();
	        			po.setId(id);
	        			po.setCreatedBy(globalVariableBackupPO.getCreatedBy());
	        			po.setCreatedDate(globalVariableBackupPO.getCreatedDate());
	        			po.setHidden(globalVariableBackupPO.isHidden());
	        			po.setProId(globalVariableBackupPO.getProId());
	        			po.setProName(globalVariableBackupPO.getProName());
	        			po.setProperty(globalVariableBackupPO.getProperty());
	        			po.setRequestId(globalVariableBackupPO.getRequestId());
	        			po.setUpdatedBy(globalVariableBackupPO.getUpdatedBy());
	        			po.setUpdatedDate(globalVariableBackupPO.getUpdatedDate());
	        			po.setValue(globalVariableBackupPO.getValue());
	        			globalVariableDAO.add(po);
	        			logger.info("rollback globalvar add key="+id);
	        		}
	        	}
        	}else{
        		logger.info("rollback globalvar size = 0,无全局变量备份");
        	}
        	
        	for (String key: global.keySet()) {
        		globalVariableDAO.delete(key);
        		logger.info("rollback globalvar delete key="+key);
			}
        	globalVariableService.putPizzaManager(domainId);
        	
		} catch (Exception e) {
			logger.info("回滚全局变量失败，原因",e);
		}
    }
    
    protected void rollbackForGroup(String domainId, String group, String versionId, UserPrincipal up,String logId) {
        List<String> keys = pizzaConfigBackupDAO.listKeys(domainId, versionId, group);

        int size = keys == null ? 0 : keys.size();
        if (logger.isInfoEnabled()) {
            logger.info("rollbackForGroup:" + group + " keys size=" + size);
        }
        if (size == 0) {
            return;
        }
        List<String> dbKeySet = pizzaConfigServices.listKeys(domainId, group);
        //删除备份时间点之后添加的配置文件
        /*for (String key : keys) {
        	pizzaConfigValueDAO.del(domainId, group, key);
        	pizzaConfigDAO.del(domainId, group, key);
        	logger.info("pizzaGroup="+group+"删除备份时间点之后"+"新增的文件"+"pizzaKey="+key);
		}*/
        for (String key : keys) {
            PizzaConfigBackupPO backupPO = pizzaConfigBackupDAO.getById(domainId, versionId, group, key);
            String content = (backupPO == null ? null : backupPO.getPizzaValue());
            if (content == null || content.length() == 0) {
                continue;
            }
            try {
                if (dbKeySet != null && dbKeySet.size() > 0) {
                    dbKeySet.remove(key);
                }
                String projectName=backupPO.getProjectName();
                pizzaConfigServices.rollback(group, key, content, domainId, up);

            } catch (Throwable th) {
                throw new Pafa5Exception("Recover config:" + group + "/" + key + " error,cause:" + th.getMessage(), th);
            }
        }
        if (dbKeySet != null && dbKeySet.size() > 0) {
            for (String deletedKey : dbKeySet) {
                pizzaConfigServices.del(domainId, group, deletedKey);
            }
        }
    }
    
    /************************************************************************************************************************************************************/

	public void recoveryRegister(String targetDomainId, String targetDomainName, String operationReason) {
		RedisLock lock = lockFactory.getLock(LOCK_OBJ_ID);
        if (lock.tryLock()) {
        	if (logger.isInfoEnabled()) {
    			logger.info("RecoveryRegister doing...");
    		}
            //计算需要备回滚的领域
            List<String> targetDomainIds;
            try {
	            if(targetDomainId == null || "ALL".equals(targetDomainId.toUpperCase())|| "def".equalsIgnoreCase(targetDomainId)) {
	                targetDomainIds = allDomainIds();
	            } else {
	                targetDomainIds = new ArrayList<String>(1);
	                targetDomainIds.add(targetDomainId);
	            }
	            
	            UserPrincipal up = UserPrincipal.get(false);
	            PizzaOperationLogPO log = new PizzaOperationLogPO();
	            log.setOperationType("RecoveryRegister");
	            if (up != null) {
	                log.setOperationIp(up.getIp());
	                POUtils.setForAdd(up.getUid(), log);
	            } else {
	                log.setOperationIp("127.0.0.1");
	                POUtils.setForAdd("SYSTEM", log);
	            }
	            log.setProjectId(targetDomainId);
	            log.setProjectName(targetDomainName);
	            log.setOperationName("恢复配置中心");
	            log.setOperationReason(operationReason);
	            log.setRemark("以数据库的配置数据为基准，恢复配置中心.");
	            String logId = pizzaOperationLogDAO.add(log);
	            
	            Runnable task = new RecoveryTask(logId, targetDomainIds, lock,MDCUtil.peek().getRequestId());           
	            executor.execute(task);
            } catch (Exception e) {
            	logger.error("",e);
            	lock.unlock();
            	throw new ResponseCodeException("123", "报错了"); 
			}
        } else {
            logger.info("Another backup/rollback/recovery action is running.");
            throw new ResponseCodeException("456", "请稍后再试!另一个备份或回滚任务正在执行中...");
        }
	}
	
	private class RecoveryTask implements Runnable {
	    
	    private String logId;
        private List<String> targetDomainIds;
        private RedisLock lock;
        private String requestId;
        
        public RecoveryTask(String logId, List<String> targetDomainIds, RedisLock lock,String requestId) {
            super();
            this.logId = logId;
            this.targetDomainIds = targetDomainIds;
            this.lock = lock;
            this.requestId = requestId;
        }

        @Override
        public void run() {
        	MDCUtil.set(requestId);
            try {
                CountDownLatch latch = new CountDownLatch(targetDomainIds.size());
                List<Future<Boolean>> results = new ArrayList<Future<Boolean>>(targetDomainIds.size());
                
                for(String domainId : targetDomainIds) {
                	recoveryRegisterLogDAO.deleteErrorLog(domainId);
                	
                    Callable<Boolean> worker = new RecoveryWorker(latch, domainId,requestId,logId);
                    Future<Boolean> future = executor.submit(worker);
                    results.add(future);                  
                }
                
                latch.await();
                
                boolean flag = true;
                for(Future<Boolean> result : results) {
                    try {
                        if(!result.get()) {
                            flag = false;
                            break;
                        }
                    } catch (ExecutionException e) {
                       logger.error("",e);
                    }
                }
                
              if(flag) {
                    pizzaOperationLogDAO.completed(logId);
                } else {
                    PizzaOperationLogPO dto = new PizzaOperationLogPO();
                    dto.setId(logId);
                    dto.setStatus(PizzaOperationLogPO.STATUS_FAILED);
                    dto.setRemark("恢复配置中心出错.");
                    pizzaOperationLogDAO.updateStatus(dto);
                }
            } catch (InterruptedException e) {
                logger.error("",e);
            } finally {
                lock.unlock();
                MDCUtil.clear();
            }
        }
	    
	}
	
	private class  RecoveryWorker implements Callable<Boolean> {
	    private CountDownLatch latch;
        private String domainId;
        private String requestId;
        private String logId;
        public RecoveryWorker(CountDownLatch latch, String domainId,String requestId,String logId) {
            super();
            this.latch = latch;
            this.domainId = domainId;
            this.requestId = requestId;
            this.logId = logId;
        }

        @Override
        public Boolean call() throws Exception {
        	MDCUtil.set(requestId);
            try {
                return _recoveryRegister(domainId,logId);
            } finally {
                latch.countDown();
                MDCUtil.clear();
            }
        }
	       
	}
	
	@ActionClient(name="pafa5-admin-security.alllistMA")
	private IServiceClient getmimaall;
	
	@SuppressWarnings("unchecked")
	protected void _recoveryMiMa(String domainId,String logId) throws Exception{
		PizzaRecoveryRegisterLogPo logPo = null;
		try {
			Map<String,String> map = new HashMap<>();
			map.put("groupId", domainId);
			ServiceResults results = getmimaall.invoke(map);
			if("0".equalsIgnoreCase(results.getString("responseCode"))) {
				PizzaManager manager = managerHolder.getManager(domainId);
				List<Map<String, String>> keyPOs = (List<Map<String, String>>) results.get("keyPOs");
				if(keyPOs!=null&&keyPOs.size()>0) {
					for (Map<String, String> map2 : keyPOs) {
						try {
							manager.set("passwords", map2.get("rid"), map2.get("password"));
						} catch (Exception e) {
							logger.error("failed. passwords=" + domainId+","+ map2.get("rid"),e);
							logPo = new PizzaRecoveryRegisterLogPo();
							logPo.setProjectId(domainId);
							logPo.setGroupId("passwords");
							logPo.setKeyConfig(map2.get("rid"));
							logPo.setLogId(logId);
							logPo.setErrorLog(e.getMessage());
							recoveryRegisterLogDAO.saveErrorLog(logPo);
						}
					}
				}
			}
		} catch (Exception e) {
			logger.error("failed. passwords=" + domainId,e);
			logPo = new PizzaRecoveryRegisterLogPo();
			logPo.setProjectId(domainId);
			logPo.setGroupId("passwords");
			logPo.setKeyConfig("");
			logPo.setLogId(logId);
			logPo.setErrorLog(e.getMessage());
			recoveryRegisterLogDAO.saveErrorLog(logPo);
		}
	}
	
	@Resource
	private PizzaRecoveryRegisterLogDAO recoveryRegisterLogDAO;

	public boolean _recoveryRegister(String domainId,String logId) {
		long t1 = System.nanoTime();
		try {
			//TODO 先恢复全局变量
			//_recoveryGlobal(domainId);
			
			//TODO 恢复密码
			_recoveryMiMa(domainId,logId);
			
			List<ConfigGroupPO> groups = configGroupServices.listAll();
			PizzaRecoveryRegisterLogPo logPo = null;
			for (ConfigGroupPO group : groups) {
				String groupCode = group.getGroupCode();
				if ("globalvars".equalsIgnoreCase(groupCode)) {//全局变量特殊处理
					try {
						globalVariableService.putPizzaManager(domainId);
					} catch (Exception e) {
						logger.error("failed. domainId=" + domainId+",globalVar",e);
						logPo = new PizzaRecoveryRegisterLogPo();
						logPo.setProjectId(domainId);
						logPo.setGroupId(groupCode);
						logPo.setKeyConfig("");
						logPo.setLogId(logId);
						logPo.setErrorLog(e.getMessage());
						recoveryRegisterLogDAO.saveErrorLog(logPo);
					}
					
				} else {
					try {
						recoveryRegisterForGroup(domainId,groupCode,logId);
					} catch (Exception e) {
						logger.error("failed. domainId=" + domainId+",group="+groupCode,e);
						logPo = new PizzaRecoveryRegisterLogPo();
						logPo.setProjectId(domainId);
						logPo.setGroupId(groupCode);
						logPo.setKeyConfig("");
						logPo.setLogId(logId);
						logPo.setErrorLog(e.getMessage());
						recoveryRegisterLogDAO.saveErrorLog(logPo);
					}
				}
			}
			if (logger.isInfoEnabled()) {
				logger.info("recovery Register from DB completed," + (System.nanoTime() - t1) / 1000 / 1000.0 + "ms.");
			}
			
			return true;
		} catch (Exception ex) {
			logger.error("do Register from DB failed. domainId=" + domainId,ex);
			return false;		
		}
	}

	protected void recoveryRegisterForGroup(String domainId, String group,String logId) {
		List<String> dbKeySet = pizzaConfigServices.listKeys(domainId, group);
		PizzaManager manager = managerHolder.getManager(domainId);
		int size = dbKeySet == null ? 0 : dbKeySet.size();
		if (logger.isInfoEnabled()) {
			logger.info("recoveryRegisterForGroup:" + group + " keys size=" + size + "  domainId=" + domainId);
		}
		if (size == 0) {
			return;
		}
		List<String> _keys = manager.searchKeys(group, null, 0, Integer.MAX_VALUE);
		Set<String> registerKeySet = null;
		if (_keys != null && _keys.size() > 0) {
			registerKeySet = new HashSet<String>();
			registerKeySet.addAll(_keys);
		}
		if(dbKeySet!=null){
			PizzaRecoveryRegisterLogPo logPo = null;
			for (String key : dbKeySet) {
				String content = pizzaConfigServices.getConfigContent(domainId, group, key);
				if (content == null || (content = content.trim()).length() == 0) {
					logPo = new PizzaRecoveryRegisterLogPo();
					logPo.setProjectId(domainId);
					logPo.setGroupId(group);
					logPo.setKeyConfig(key);
					logPo.setLogId(logId);
					logPo.setErrorLog("恢复的内容为空");
					recoveryRegisterLogDAO.saveErrorLog(logPo);
					continue;
				}
				if(content!=null&&content.length() >= juteMaxSize) {
				    logger.info("proId : "+domainId+" group : "+group+" key : "+key+" Size : " + content.length());		    
				    continue;
				}
				
				try {
					boolean flag = false;
					if (registerKeySet != null && registerKeySet.size() > 0) {
						flag = registerKeySet.remove(key);
					}
					if (flag) {
						String registerContent = manager.get(group, key);
	
						if (registerContent != null) {
							if (!configContentUtils.md5(registerContent).equals(configContentUtils.md5(content))) {
								if (logger.isInfoEnabled()) {
									logger.info("RecoveryConfig:" + domainId + "/" + group + "/" + key + ".");
								}
								manager.set(group, key, content);
							} else {
								if (logger.isInfoEnabled()) {
									logger.info("Config:" + domainId + "/" + group + "/" + key + " Not changed.");
								}
							}
						} else {
							if (logger.isInfoEnabled()) {
								logger.info("RecoveryConfig:" + domainId + "/" + group + "/" + key + ".");
							}
							manager.set(group, key, content);
						}
					} else {
						if (logger.isInfoEnabled()) {
							logger.info("RecoveryAddConfig:" + domainId + "/" + group + "/" + key + ".");
						}
						manager.add(group, key, content);
					}
				} catch (Throwable th) {
					logger.error("failed. domainId=" + domainId+",group="+group,th);
					logPo = new PizzaRecoveryRegisterLogPo();
					logPo.setProjectId(domainId);
					logPo.setGroupId(group);
					logPo.setKeyConfig(key);
					logPo.setLogId(logId);
					logPo.setErrorLog(th.getMessage());
					recoveryRegisterLogDAO.saveErrorLog(logPo);
					throw new Pafa5Exception("Recover config:" + domainId + "/" + group + "/" + key + " error,cause:" + th.getMessage(), th);
				}
			}
			if (registerKeySet != null && registerKeySet.size() > 0) {
				for (String deletedKey : registerKeySet) {
					if (logger.isInfoEnabled()) {
						logger.info("RecoveryDelConfig:" + domainId + "/" + group + "/" + deletedKey + ".");
					}
					manager.del(group, deletedKey);
				}
			}
		}
		//对keyset取值情况进行捕捉
		else{
			if (logger.isInfoEnabled()) {
				logger.info("Recovery:"+"dbKeyset取值为空！" );
			}
	   }
	}

    protected String generateVersionId() {
        SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
        return format.format(new Date());
    }
	
	protected List<String> allDomainIds() {
        ServiceResults results = listAllDomainIds.invoke(new HashMap<>());
        List<Map<String, Object>> list = (List)results.get("datas");
        
        List<String> domainIds = new ArrayList<String>(list.size());
        domainIds.add("def");
        for (Map<String, Object> map : list) {
            String domainId = (String)map.get("groupId");
            domainIds.add(domainId);
        }   
        return domainIds;
    }
	

    @Override
	public List<PizzaRecoveryRegisterLogPo> getErrorLog(String logId, String projectId) {
		return recoveryRegisterLogDAO.getErrorLogs(logId, projectId);
	}

	public void setJuteMaxSize(int juteMaxSize) {
        this.juteMaxSize = juteMaxSize;
    }

    public void setConfigContentUtils(ConfigContentUtils configContentUtils) {
        this.configContentUtils = configContentUtils;
    }

    public void setPizzaConfigServices(PizzaConfigServices pizzaConfigServices) {
        this.pizzaConfigServices = pizzaConfigServices;
    }

    public void setConfigGroupServices(ConfigGroupServices configGroupServices) {
        this.configGroupServices = configGroupServices;
    }

    public void setGlobalVariableService(GlobalVariableService globalVariableService) {
        this.globalVariableService = globalVariableService;
    }

    public void setManagerHolder(PizzaManagerHolder managerHolder) {
        this.managerHolder = managerHolder;
    }

    public void setPizzaOperationLogDAO(PizzaOperationLogDAO pizzaOperationLogDAO) {
        this.pizzaOperationLogDAO = pizzaOperationLogDAO;
    }

    public void setPizzaConfigBackupDAO(PizzaConfigBackupDAO pizzaConfigBackupDAO) {
        this.pizzaConfigBackupDAO = pizzaConfigBackupDAO;
    }

    public void setListAllDomainIds(IServiceClient listAllDomainIds) {
        this.listAllDomainIds = listAllDomainIds;
    }

    public void setLockFactory(RedisLockFactory lockFactory) {
        this.lockFactory = lockFactory;
    }

    public boolean checkStatus(String projectId,String versionId) {
		boolean flag=false;
		long backupCount = pizzaConfigBackupDAO.checkCount(projectId,versionId);
		long rollbackCount = pizzaConfigDAO.checkCount(projectId);
		if(backupCount==rollbackCount){
			flag=true;
		}
		return flag;
	}

}
