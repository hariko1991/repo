package com.pingan.pafa5.admin.fling.dao.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.fling.dao.FlingPappInstanceDAO;
import com.pingan.pafa5.admin.fling.po.FlingPappInstancePO;

@Nosql
@Repository
public class FlingPappInstanceDAOImpl extends BaseMongoDAO<FlingPappInstancePO> implements
        FlingPappInstanceDAO {

    @Override
    public void upset(FlingPappInstancePO po) {
        this._upsert(
                this.where("appName").is(po.getAppName()).and("instanceIp").is(po.getInstanceIp())
                        .and("projectId").is(po.getProjectId()), po);
    }

    @Override
    public FlingPappInstancePO getFlingPappInstancePO(String pappName, String instanceIp) {
        Criteria criteria = where("appName").is(pappName).and("instanceIp").is(instanceIp);
        return this._get(criteria);
    }
    
    @Override
    public FlingPappInstancePO getFlingPappInstancePO(String pappName, String instanceIp, String projectId) {
        Criteria criteria = where("appName").is(pappName).and("instanceIp").is(instanceIp).and("projectId").is(projectId);
        return this._get(criteria);
    }

    @Override
    public boolean delete(String projectId, String pappName, String instanceIp) {
        Criteria criteria = where("appName").is(pappName).and("instanceIp").is(instanceIp);
        if (StringUtils.isNotEmpty(projectId)) {
            criteria.and("projectId").is(projectId);
        }
        FlingPappInstancePO po = this._get(criteria);
        po.setStatus(9);
        return this._update(criteria, po);
    }

    @Override
    public List<FlingPappInstancePO> list(String instanceIp) {
        Criteria where = this.where("status").ne(9);
        if (StringUtils.isNotEmpty(instanceIp)) {
            where.and("instanceIp").is(instanceIp);
        }
        return this._list(where);
    }
    
    @Override
    public List<FlingPappInstancePO> list(int status) {
        Criteria where = this.where("status").is(status);
        return this._list(where);
    }
    
    @Override
    public List<FlingPappInstancePO> list(String projectId, String pappName) {
        Criteria where = this.where("status").ne(9);
        if (StringUtils.isNotEmpty(pappName)) {
            where.and("appName").is(pappName);
        }
        if (StringUtils.isNotEmpty(projectId)) {
            where.and("projectId").is(projectId);
        } 
        return this._list(where);
    }

    @Override
    public List<FlingPappInstancePO> list(int status, int limit, int page) {
        Criteria where = this.where("status").is(status);
        int skip = (page - 1) * limit;
        return this._list(where, skip, limit);
    }
    
    @Override
    public List<FlingPappInstancePO> list(String projectId, String pappName, int limit, int page) {
        Criteria where = this.where("status").ne(9);
        if (projectId != null && !"".equals(projectId.trim())) {
            where.and("projectId").is(projectId);
        } else {
            where.and("projectId").is(null);
        }
        if (pappName != null && !"".equals(pappName.trim())) {
            where.and("appName").is(pappName);
        }
        int skip = (page - 1) * limit;
        return this._list(where, skip, limit);
    }
    

    
    
    @Override
    public long getPappCount(String projectId, String pappName) {
        Criteria where = this.where("status").ne(9);
        if (projectId != null && !"".equals(projectId.trim())) {
            where.and("projectId").is(projectId);
        } else {
            where.and("projectId").is(null);
        }
        if (pappName != null && !"".equals(pappName.trim())) {
            where.and("appName").is(pappName);
        }
        return this._count(where);
    }
    @Override
    public long getPappCount(int status, String projectId) {
        Criteria where = this.where("status").is(status);
        if (projectId != null && !"".equals(projectId.trim())) {
            where.and("projectId").is(projectId);
        } 
        return this._count(where);
    }
    
    @Override
    public List<String> listInstanceIps(String projectId, String pappName) {
        List<FlingPappInstancePO> pos = list(projectId, pappName);
        if (pos == null || pos.size() == 0) {
            return null;
        }
        List<String> ips = new ArrayList<String>(pos.size());
        for (FlingPappInstancePO po : pos) {
            ips.add(po.getInstanceIp());
        }
        return ips;
    }

    @Override
    public List<String> listValidInstanceIps(String projectId,String pappName, int heartbeatExpired) {
        List<FlingPappInstancePO> pos =  this._list(this.where("appName").is(pappName).and("projectId").is(projectId).and("status").ne(9).and("lastActiveTimestamp").gt(System.currentTimeMillis() - heartbeatExpired));
        if (pos == null || pos.size() == 0) {
            return null;
        }
        List<String> ips = new ArrayList<String>(pos.size());
        for (FlingPappInstancePO po : pos) {
            ips.add(po.getInstanceIp());
        }
        return ips;
    }

    @Override
    public boolean checkValid(String pappName, String instanceIp, int heartbeatExpired) {
        List<FlingPappInstancePO> pos = this._list(this.where("appName").is(pappName)
        		.and("instanceIp").is(instanceIp)
        		.and("status").ne(9)
        		.and("lastActiveTimestamp")
        		.gt(System.currentTimeMillis() - heartbeatExpired));
        if (pos == null || pos.size() == 0) {
            return false;
        }
        return true;
    }

	@Override
	public List<FlingPappInstancePO> listPappSearchResult(String projectId,
			String searchField) {
		Pattern p = Pattern.compile("^.*"+searchField+".*$",Pattern.CASE_INSENSITIVE);
        Criteria where = this.where("status").ne(9).orOperator(where("appName").regex(p),where("instanceIp").regex(p));
        if (projectId != null && !"".equals(projectId.trim())) {
            where.and("projectId").is(projectId);
        }
        return this._list(where);
	}
	
	@Override
	public List<FlingPappInstancePO> listPappIndexPage(String projectId){
		Criteria where = this.where("status").ne(9);
        if (StringUtils.isNotEmpty(projectId)) {
            where.and("projectId").is(projectId);
        } 
        return this._list(where);
	}
	
	@Override
	public List<FlingPappInstancePO> listPappIndexPage(String projectId,String instanceIp){
		Criteria where = this.where("status").ne(9);
        if (StringUtils.isNotEmpty(projectId)) {
            where.and("projectId").is(projectId);
        }
        if(StringUtils.isNotEmpty(instanceIp)) {
        	Pattern p = Pattern.compile("^.*"+instanceIp+".*$",Pattern.CASE_INSENSITIVE);
        	where.and("instanceIp").regex(p);
        }
        return this._list(where);
	}
}
