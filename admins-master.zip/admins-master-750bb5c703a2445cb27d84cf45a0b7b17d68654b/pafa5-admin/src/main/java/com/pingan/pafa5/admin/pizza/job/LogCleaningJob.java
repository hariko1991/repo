package com.pingan.pafa5.admin.pizza.job;

import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.text.DateFormatter;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paic.pafa.job.TimerJob;
import com.pingan.pafa5.admin.pizza.services.HistoryConfigServices;

@Component
public class LogCleaningJob {
	
	private Log logger = LogFactory.getLog(this.getClass());

	@Autowired
    private HistoryConfigServices historyConfigServices;
	    
	    @TimerJob(disabled=true,startDelay=6000,cronExpression = "0 0 3 1/1 * ? *")
	    public void execute() throws Exception {
	    	String timeStamp = new SimpleDateFormat("yyyy-MM-dd").format(System.currentTimeMillis()-Long.valueOf("6048000000"));
            long itemNum = historyConfigServices.getRecordNum(timeStamp, null);
            logger.info("timeStamp:"+timeStamp+" num:"+itemNum);
            historyConfigServices.cleanUpRecord(timeStamp, "");
            logger.info("timeStamp:"+timeStamp+" num:"+itemNum+"删除完毕！");
	    }
}
