package com.pingan.pafa5.admin.logging.services.impl;

import java.io.StringReader;
import java.io.StringWriter;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.commons.beanutils.BeanUtils;
import org.dom4j.Attribute;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.SAXReader;
import org.dom4j.io.XMLWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.pizza.PizzaConstants;
import com.pingan.pafa.pizza.classloader.PizzaURL;
import com.pingan.pafa.redis.Redis;
import com.pingan.pafa.redis.RedisConfigDTO;
import com.pingan.pafa.redis.RedisFactoryBean;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.commons.PizzaManagerHolder;
import com.pingan.pafa5.admin.logging.dao.LogMonitorDAO;
import com.pingan.pafa5.admin.logging.dto.LogMonitorDTO;
import com.pingan.pafa5.admin.logging.form.LogMonitorForm;
import com.pingan.pafa5.admin.logging.po.LogMonitorPO;
import com.pingan.pafa5.admin.logging.services.LogMonitorServices;
import com.pingan.pafa5.admin.sso.UserPrincipal;

@Service
public class LogMonitorServicesImpl extends BaseServices implements LogMonitorServices{

	
	@Value("${user.sso.redis.url}")
	private String defRedisURL;
		
	
	/**默认过期时间,15分钟*/
	private int defExpiredTime=15*60;
	
	private Redis defRedis;
	
	
	@Autowired
	private LogMonitorDAO logMonitorDAO;


	@Autowired
	private PizzaManagerHolder pizzaManagerHolder;
	
	@ActionClient(name="pafa5-admin-pizza.logMonitorSave")
	private IServiceClient saveConfig;
	
	@PostConstruct
	public void init() throws Exception{
		RedisFactoryBean redisFactory=new RedisFactoryBean();
		RedisConfigDTO defConfig=new RedisConfigDTO();
		defConfig.setDefSerialization("json");
		redisFactory.setConfigure(defConfig);
		redisFactory.setConfigureURL(defRedisURL);
		defRedis=redisFactory.getObject();
	}
	@PreDestroy 
	public  void destroy(){
		if(defRedis!=null){
			defRedis.destroy();
		}
	}
	
	
	@Override
	public LogMonitorPO apply(String pappName, String redisPizzaKey) {
		if(pappName==null || (pappName=pappName.trim()).length()==0){
			throw new NullPointerException("应用ID不能为空.");
		}
		PizzaURL pizzaURL=null;
		if(redisPizzaKey!=null){
			int idx=redisPizzaKey.indexOf('/');
			if(idx!=-1){
				redisPizzaKey="/redis/"+redisPizzaKey;
			}
			pizzaURL=new PizzaURL(redisPizzaKey);
			if(!pizzaURL.getPizzaGroup().equals(PizzaConstants.GROUP_REDIS)){
				throw new IllegalArgumentException("redisPizzaKey:"+redisPizzaKey+" group error.");
			}
		}
		LogMonitorPO po=new LogMonitorPO();
		po.setQueueName(generateQueueName(pappName));
		po.setExpiredTime(defExpiredTime);
		if(pizzaURL==null){
			po.setRedisURL(this.defRedisURL);
		}else{
			po.setRedisURL(pizzaURL.toString());
		}
		po.setTargetPapp(pappName);
		po.setStatus(0);
		return null;
	}
	
	protected String generateQueueName(String pappName){
		return pappName+".logm."+UUID.randomUUID().toString().replaceAll("-","");
	}

	public String getDefRedisURL() {
		return defRedisURL;
	}

	public void setDefRedisURL(String defRedisURL) {
		this.defRedisURL = defRedisURL;
	}

	public int getDefExpiredTime() {
		return defExpiredTime;
	}

	public void setDefExpiredTime(int defExpiredTime) {
		this.defExpiredTime = defExpiredTime;
	}

	public LogMonitorDAO getLogMonitorDAO() {
		return logMonitorDAO;
	}

	public void setLogMonitorDAO(LogMonitorDAO logMonitorDAO) {
		this.logMonitorDAO = logMonitorDAO;
	}

	@Override
	public PageDataDTO<LogMonitorDTO> list(String projectId, String pappName, int limit, int page) {
		PageDataDTO<LogMonitorDTO> pageData = new PageDataDTO<LogMonitorDTO>();
		List<LogMonitorPO> pos = logMonitorDAO.list(projectId, pappName, limit, page);
		if (pos != null && pos.size() > 0) {
			List<LogMonitorDTO> dtos = new ArrayList<LogMonitorDTO>(pos.size());
			for (LogMonitorPO po : pos) {
				LogMonitorDTO dto = new LogMonitorDTO();
				dto.setCreatedBy(po.getCreatedBy());
				dto.setCreatedDate(po.getCreatedDate());
				dto.setExpiredTime(po.getExpiredTime());
				dto.setQueueName(po.getQueueName());
				dto.setStatus(po.getStatus());
				dto.setTargetPapp(po.getTargetPapp());
				dto.setId(po.getId());
				dtos.add(dto);
			}
			long total = logMonitorDAO.getTotal(projectId, pappName);
			pageData.setDatas(dtos);
			pageData.setTotalSize(total);
		}
		return pageData;
	}
	
	/** 生产记录，重新配置  log4j.xml 文件
	 * 
	 * @param po
	 * @return
	 * @throws DocumentException
	 */
	@Override
	public LogMonitorPO configXML(LogMonitorForm form, String currTime) {
		String config = form.getTargetPapp() + ".log4j.xml";
		String XMLContent = pizzaManagerHolder.getManager(form.getProjectId()).get("papp", config);
		if (XMLContent == null || "".equals(XMLContent.trim())) {
			throw new NullPointerException("没有发现 "+config+" 配置文件");
		}
		//用APP名称作为序列的名字   userid_pafa5_log_monitor_papp
		String queueName = LogOutputUtils.PAFA5_LOG_MONITOR + 
				"_" + form.getTargetPapp() + 
				"_" + form.getExpiredTime();
		queueName = queueName.toLowerCase();//全部转为小写
		
		if (logger.isInfoEnabled()) {
			logger.info("QueueName="+queueName);
		}
		
		boolean isLook = logMonitorDAO.isLooking(form.getProjectId(), form.getTargetPapp(), form.getExpiredTime(), 0);
		if (isLook) {
			throw new NullPointerException("监控目标已经有人在查看，不允许创建，请直接查看");
		}
		
		LogMonitorPO po = new LogMonitorPO();
		try {	
			String xml = parserXML(XMLContent, queueName, currTime);
			if(logger.isInfoEnabled()){
				logger.info("XML Content:\n"+xml);
			}
			
			BeanUtils.copyProperties(po, form);
			POUtils.setForAdd(UserPrincipal.peekUserId(), po);
			
			//po.setLog4j(XMLContent);
			po.setStartTime(currTime);
			po.setStatus(0);
			po.setQueueName(queueName);
			po.setIpaddr(UserPrincipal.get().getIp());
			logMonitorDAO.add(po);
			
			setLog4jToConfig(po.getCreatedBy(), config, xml, po.getIpaddr(),po.getProjectId());
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		return po;
	}
	
	
	/**  配置  log4j.xml 文件 用于日志查询 queneName为PAFA5_LOG_MONITOR+pappName
	 * 
	 * @param po
	 * @return
	 * @throws DocumentException
	 */
	@Override
	public LogMonitorPO configXML2(String pappName,String projectId) {
		String config = pappName + ".log4j.xml";
		String XMLContent = pizzaManagerHolder.getManager(projectId).get("papp", config);
		if (XMLContent == null || "".equals(XMLContent.trim())) {
			throw new NullPointerException("没有发现 "+config+" 配置文件");
		}
		//统一对列名 log.redis.quenename=pafa5admin_LogQueue 给log4j增加pappName节点
		
		LogMonitorPO po = new LogMonitorPO();
		try {	
			String xml = parserXML2(XMLContent, projectId+"_"+pappName);
			po.setIpaddr(UserPrincipal.get().getIp());
			setLog4jToConfig(po.getCreatedBy(), config, xml, po.getIpaddr(),projectId);
		} catch (Exception e) {
			e.printStackTrace();
			throw new RuntimeException(e);
		}
		return po;
	}
	
	/** 重新配置  log4j.xml 文件
	 * 
	 * @param po
	 * @return
	 * @throws DocumentException
	 */
	@Override
	public LogMonitorPO configXML(String id, String currTime) {
		LogMonitorPO po = logMonitorDAO.getById(id);
		if (po == null) {
			throw new NullPointerException("监控目标已不存在");
		}
		String config = po.getTargetPapp() + ".log4j.xml";
		String XMLContent = pizzaManagerHolder.getManager(po.getProjectId()).get("papp", config);
		if (XMLContent == null || "".equals(XMLContent.trim())) {
			throw new NullPointerException("没有发现 "+config+" 配置文件");
		}
		
		boolean isLook = logMonitorDAO.isLooking(po.getProjectId(), po.getTargetPapp(), po.getExpiredTime(), 0);
		if (!isLook) {
			throw new NullPointerException("监控目标已经过期，不能查看");
		}
		
		
		try {
			String xml = parserXML(XMLContent, po.getQueueName(), currTime);
			if(logger.isInfoEnabled()){
				logger.info("configXML Content:\n"+xml);
			}
			po.setLog4j(XMLContent);
			po.setStatus(0);
			POUtils.setForUpdate(UserPrincipal.peekUserId(), po);
			logMonitorDAO.update(po);
			setLog4jToConfig(po.getCreatedBy(), config, xml, po.getIpaddr(),po.getProjectId());
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
		return po;
	}
	
	/** 还原XML文件
	 * 
	 * @param queueName
	 */
	@Override
	public void restoreXML(String id, String currTime) {
		LogMonitorPO po = logMonitorDAO.getById(id);
		if (po == null) {
			throw new NullPointerException("目标对象不存在");
		}
		po.setStatus(1);
		String config = po.getTargetPapp() + ".log4j.xml";
		String XMLContent = pizzaManagerHolder.getManager(po.getProjectId()).get("papp", config);
		if (XMLContent == null || "".equals(XMLContent.trim())) {
			throw new NullPointerException("没有发现 "+config+" 配置文件");
		}
		
		try {
			String xml = removeMonitor(XMLContent, currTime);
			if(logger.isInfoEnabled()){
				logger.info("Restore XML Content:\n"+xml);
			}
			logMonitorDAO.update(po);
			setLog4jToConfig(po.getCreatedBy(), config, xml, po.getIpaddr(),po.getProjectId());
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	/** 还原XML文件 日志查询
	 * 
	 * @param queueName
	 */
	@Override
	public void restoreXML2(String pappName,String projectId) {
		
		String config = pappName + ".log4j.xml";
		String XMLContent = pizzaManagerHolder.getManager(projectId).get("papp", config);
		if (XMLContent == null || "".equals(XMLContent.trim())) {
			throw new NullPointerException("没有发现 "+config+" 配置文件");
		}
		
		try {
			String xml = removeMonitor2(XMLContent);			
				
			if(logger.isInfoEnabled()){
				logger.info("Restore XML Content:\n"+xml);
			}

			setLog4jToConfig(null, config, xml, null,projectId);
		} catch (Exception e) {
			throw new RuntimeException(e);
		}
	}
	
	
	/** 删除配置
	 * 
	 * @param queueName
	 */
	@Override
	public boolean delete(String queueName) {
		LogMonitorPO po = logMonitorDAO.getById(queueName);
		if (po == null) {
			throw new NullPointerException("目标对象不存在");
		}
		
		return logMonitorDAO.delete(queueName);
	}
	
	/**  移除监控
	 * 
	 * @param XMLContent
	 * @param pappName
	 * @return
	 * @throws DocumentException
	 */
	@SuppressWarnings("unchecked")
	private String removeMonitor(String XMLContent, String currTime) throws Exception {
		Document document = DocumentHelper.parseText(XMLContent);
		Element appenders =getAppenders(document);       
        Element[] elearr = getNosqlAppenders(appenders,LogOutputUtils.PAFA5_LOG_MONITOR);
        Element nosql =elearr[0];//nosql节点
        Element async =elearr[1];//async节点          
        List<Element> appenderChilds = appenders.elements();//获取 Appenders下的所有子元素
        if (nosql != null) {
        	boolean ready = checkReady(nosql, currTime);
        	if (ready) {
        		throw new Exception("其他人也在使用，不能还原Log4j配置文件");
			}
        	appenderChilds.remove(nosql);
        }
        removeAsycNode(async,LogOutputUtils.PAFA5_LOG_MONITOR);
        return document.asXML();
	}
	
	
	/** 解析xxx.log4j.xml文件
	 * 
	 * @param xmlContent
	 * @param UUID
	 * @param redisURL
	 * @return
	 * @throws DocumentException
	 */
	private String parserXML(String XMLContent, String queueName,String currTime) throws DocumentException {
		
		Document document = DocumentHelper.parseText(XMLContent);
		Element appenders =getAppenders(document);       
        Element[] elearr = getNosqlAppenders(appenders,LogOutputUtils.PAFA5_LOG_MONITOR);
        Element nosql =elearr[0];//nosql节点
        Element async =elearr[1];//async节点
        if (nosql==null){
        	nosql = DocumentHelper.createElement("NoSql");        	
        	nosql.addAttribute("name", LogOutputUtils.PAFA5_LOG_MONITOR);    
        	appenders.add(nosql);
        }
        Attribute attribute = nosql.attribute("time");
    	if (attribute == null) {
    		nosql.addAttribute("time", currTime);//追加时间戳
		} else {
			attribute.setValue(currTime);
		}   	
    	this.createRedisNode(nosql, queueName, null); 
    	createAsycNode(async,LogOutputUtils.PAFA5_LOG_MONITOR);
        
        return document.asXML();
	}
	
	/** 解析xxx.log4j.xml文件 用于日志查询
	 * 
	 * @param xmlContent
	 * @param UUID
	 * @param redisURL
	 * @return
	 * @throws DocumentException
	 */
	
	private String parserXML2(String XMLContent, String pappName) throws DocumentException {
		Document document = DocumentHelper.parseText(XMLContent);
		Element appenders =getAppenders(document);       
        Element[] elearr = getNosqlAppenders(appenders,"pafa5admin_LogQueue_NoSql");
        Element nosql =elearr[0];//nosql节点
        Element async =elearr[1];//async节点
        if (nosql==null){
        	nosql = DocumentHelper.createElement("NoSql");        	
        	nosql.addAttribute("name", "pafa5admin_LogQueue_NoSql");  
        	appenders.add(nosql);
        }
       
    	this.createRedisNode(nosql, null, pappName); 
    	createAsycNode(async,"pafa5admin_LogQueue_NoSql");
        
        return document.asXML();
	}
	
	/**  移除监控 用于日志查询
	 * 
	 * @param XMLContent
	 * @param pappName
	 * @return
	 * @throws DocumentException
	 */
	@SuppressWarnings("unchecked")
	private String removeMonitor2(String XMLContent) throws Exception {
		Document document = DocumentHelper.parseText(XMLContent);
		Element appenders =getAppenders(document);       
        Element[] elearr = getNosqlAppenders(appenders,"pafa5admin_LogQueue_NoSql");
        Element nosql =elearr[0];//nosql节点
        Element async =elearr[1];//async节点          
        List<Element> appenderChilds = appenders.elements();//获取 Appenders下的所有子元素
        if (nosql != null) {       	
        	appenderChilds.remove(nosql);
        }
        removeAsycNode(async,"pafa5admin_LogQueue_NoSql");
        return document.asXML();
	}
	
	/** 检验是否还有其他人也在读
	 * 
	 * @param currTime
	 * @return
	 */
	private boolean checkReady(Element nosql, String currTime) {
		if (nosql != null) {
			String time = nosql.attribute("time").getValue();
			if (!time.equals(currTime)) {
				//说明有人在使用
				return true;
			}
		}
		return false;
	}

	@Override
	public Redis getConfigRedis(String queueName) {
		
		return defRedis;
		
	}

	@Override
	public void setTimeOutStatus() {
		Date currDate = new Date();
		
		long nd = 1000*24*60*60;//一天的毫秒数
		long nh = 1000*60*60;//一小时的毫秒数
		long nm = 1000*60;//一分钟的毫秒数
		
		try {
			List<LogMonitorPO> list = logMonitorDAO.getUseList();
			if (logger.isInfoEnabled()) {
				logger.info("查询正在使用在线日志查看的队列数="+list.size());
			}
			if (list != null && list.size() > 0) {
				
				for (LogMonitorPO po : list) {
					Date date = po.getUpdatedDate();
					long diff = currDate.getTime() - date.getTime();
					long min = (int)diff % nd % nh / nm;//计算差多少分钟
					
					if (logger.isInfoEnabled()) {
						logger.info(po.getQueueName()+" = 超时时间 "+po.getExpiredTime()+" 分钟，剩余 "+min+" 分钟");
					}
					
					if (min >= po.getExpiredTime()) {
						logger.info(po.getQueueName()+" = 已经超时，可以移除");
						try {
							boolean isboo = this.imposedRemove(po);
							if (isboo) {
								logger.info(po.getQueueName()+" = 移除日志监控文件节点。。。。。。。。");
								
								po.setStatus(1);
								logMonitorDAO.update(po);
							}
						} catch (Exception e) {
							logger.error("移除日志监控文件【"+po.getTargetPapp()+".log4j.xml"+"】节点失败 ", e);
						}
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	@SuppressWarnings("unchecked")
	private boolean imposedRemove(LogMonitorPO po) throws Exception {
		String config = po.getTargetPapp() + ".log4j.xml";
		if (logger.isInfoEnabled()) {
			logger.info("移除日志监控节点配置文件："+config);
		}
		String XMLContent = pizzaManagerHolder.getManager(po.getProjectId()).get("papp", config);
		if (XMLContent == null || XMLContent.length() < 1) {
			return false;
		}
		if (logger.isInfoEnabled()) {
			logger.info(config+"文件内容："+XMLContent);
		}
		Document document = DocumentHelper.parseText(XMLContent);
		Element appenders =getAppenders(document);       
        Element[] elearr = getNosqlAppenders(appenders,LogOutputUtils.PAFA5_LOG_MONITOR);
        Element nosql =elearr[0];//nosql节点
        Element async =elearr[1];//async节点          
        List<Element> appenderChilds = appenders.elements();//获取 Appenders下的所有子元素
        if (nosql != null) {
        	appenderChilds.remove(nosql);
        }
        removeAsycNode(async,LogOutputUtils.PAFA5_LOG_MONITOR);
        XMLContent = document.asXML();
        if (logger.isInfoEnabled()) {
			logger.info("恢复后的"+config+"的配置文件内容："+XMLContent);
		}
        setLog4jToConfig(po.getCreatedBy(), config, XMLContent, po.getIpaddr(),po.getProjectId());
        return true;
	}
	
	
	private void setLog4jToConfig(String userid, String key, String XMLContent, String ipaddr,String projectId) {
		if (logger.isInfoEnabled()) {
			logger.info("更新配置文件："+key+"，更新内容："+XMLContent.replace('\n', '_'));
		}
		ServiceParams params = new ServiceParams();
		params.put("key", key);
		params.put("projectId", projectId);
		params.put("optype", "update");
		params.put("group", "papp");
		params.put("value", XMLContent);
		params.put("uid", userid);
		params.put("ipaddr", ipaddr);
		
		ServiceResults result = saveConfig.invoke(params);
		if (logger.isInfoEnabled()) {
			logger.info("invoke result = "+result.toString());
		}
	}


	@SuppressWarnings("unchecked")
	private  Element getAppenders(Document document){
        Element root = document.getRootElement();// 获取根元素
        List<Element> rootChilds = root.elements();//根元素下的所有子元素(Appenders)
        Element appenders = null;
        for (Element element : rootChilds) {
			String name = element.getName();
			if (name.equalsIgnoreCase("Appenders")) {
				appenders = element;
				break;
			}
		}
        
        if (appenders == null) {
			throw new NullPointerException("文件中不存在<Appenders/>节点");
		}
        return appenders;
	} 
	
	@SuppressWarnings("unchecked")
	private Element[] getNosqlAppenders(Element appenders,String nosqlName){
		  List<Element> appenderChilds = appenders.elements();//获取 Appenders下的所有子元素
		  	Element nosql = null;//nosql节点
	        Element async = null;//async节点	        
	        for (Element element : appenderChilds) {
				String name = element.getName();
				String attrName = element.attributeValue("name");
				if (name.equalsIgnoreCase("NoSql") && attrName.equals(nosqlName)) {
					nosql = element;
				}
				
				if (name.equalsIgnoreCase("Async") && attrName.equalsIgnoreCase("Async")) {
					async = element;
				}
			}
	        Element[] elements = {nosql,async};  
	        return elements;
	}
	
	private Element createRedisNode(Element nosql,String queueName,String pappName){
		Element redis = nosql.element("Redis");
    	nosql.remove(redis);
    	redis = DocumentHelper.createElement("Redis");
        redis.addAttribute("queueName", queueName);       
        if (!StringUtils.isEmpty(pappName)){
        	redis.addAttribute("appName", pappName); 
        }
        Element url = DocumentHelper.createElement("configureURL");
        if (!StringUtils.isEmpty(pappName)){
        	//url.addText(this.logredisurl);
        }else{
        	url.addText(this.defRedisURL);
        }       
        redis.add(url);
        nosql.add(redis);
        return nosql;
	}
	
	@SuppressWarnings("unchecked")
	private void createAsycNode(Element async ,String refName){
		  if (async != null) {
				List<Element> asyncs = async.elements();
				boolean exists = false;
				for (Element element : asyncs) {
					String ref = element.attributeValue("ref");
					if (ref != null && refName.equals(ref)) {
						exists = true;
						break;
					}
				}
				if (!exists) {
					//如果不存在，则添加一个
					Element ref = DocumentHelper.createElement("AppenderRef");
					ref.addAttribute("ref", refName);
			        async.add(ref);
				}
			} else {
				throw new NullPointerException("文件中不存在<Async/>节点");
			}
	}
	@SuppressWarnings("unchecked")
	private void removeAsycNode(Element async ,String refName){
		 if (async != null) {
	     	List<Element> asyncs = async.elements();
			for (Element element : asyncs) {
				String ref = element.attributeValue("ref");
				if (ref != null && refName.equals(ref)) {
					async.remove(element);
					break;
				}
			}
		}
	}
	
	
	
	public void setDefRedis(Redis defRedis) {
		this.defRedis = defRedis;
	}
	
	public void setPizzaManagerHolder(PizzaManagerHolder pizzaManagerHolder) {
		this.pizzaManagerHolder = pizzaManagerHolder;
	}
	
	public void setSaveConfig(IServiceClient saveConfig) {
		this.saveConfig = saveConfig;
	}	

	/**
	 * 配置kafka log4j日志输出
	 */
	@Override
	public void configKafkaXML(String pappName, String projectId,String kafkaurl) {
		this.doKafkaLog4jXml(pappName, projectId, kafkaurl, "open");		
	}
	
	
	/**
	 * 移除kafka log4j日志输出
	 */
	@Override
	public void restoreKafkaXML(String pappName , String projectId) {		
		this.doKafkaLog4jXml(pappName, projectId, null, "close");
	}	
	
	/**
	 * 判断log4j中kafka节点  是否存在
	 * @param pappName
	 * @param projectId
	 * @return
	 */
	public boolean checkKafkaExist(String pappName , String projectId){
		return this.doKafkaLog4jXml(pappName, projectId, null, "exist");
	}
	
	

	
	@SuppressWarnings("unchecked")
	private boolean doKafkaLog4jXml(String pappName, String projectId,String kafkaurl,String operator) {
		boolean flag = true;
		String config = pappName + ".log4j.xml";
		String XMLContent = pizzaManagerHolder.getManager(projectId).get("papp", config);
		if (XMLContent == null || "".equals(XMLContent.trim())) {
			throw new NullPointerException("没有发现 "+config+" 配置文件");
		}
		try{
			Document document = DocumentHelper.parseText(XMLContent);
			Element appenders =getAppenders(document);   
			
			List<Element> appenderChilds = appenders.elements();//获取 Appenders下的所有子元素
			Element async =null;
			Element kafka =null;
			 for (Element element : appenderChilds) {
					String name = element.getName();
					String attrName = element.attributeValue("name");
					if (name.equalsIgnoreCase("Kafka")  ) {
						kafka = element;
					}
					
					if (name.equalsIgnoreCase("Async") && attrName.equals("Async")) {
						async = element;
					}
				}
			if (operator .equals("open")) {//开启kafka日志输出
				//新加Async节点
				//关闭时，async节点没有子节点会删除这个async节点，则在开启时，需要添加async节点
		        if(async==null){
		        	async = DocumentHelper.createElement("Async");
		        	async.addAttribute("name", "Async").addAttribute("bufferSize", "2000").addAttribute("blocking", "false");
		        	appenders.add(async);
		        	
		        	//loggers-->root节点下添加AppenderRef Async
		        	Element loggersElement = getLoggersRoot(document);
			    	if(loggersElement!=null){
			    		Element appenderRef = DocumentHelper.createElement("AppenderRef");//<AppenderRef ref="Async" />
			    		appenderRef.addAttribute("ref", "Async");
			    		loggersElement.add(appenderRef);
			    	}
		        }
				//-------开启kafak开关，添加asyn节点结束
				if (kafka==null){
		        	kafka = DocumentHelper.createElement("Kafka");        	
		        	kafka.addAttribute("name", "kafkaAppender");      	
		        	appenders.add(kafka);
		        }
			    Element kafkaconfig = kafka.element("Config");
		        kafka.remove(kafkaconfig);
		        kafkaconfig = DocumentHelper.createElement("Config");
		        kafkaconfig.addAttribute("key", "kafka.bootstrap.servers");       
		        kafkaconfig.addAttribute("value",kafkaurl);    
		        kafka.add(kafkaconfig);
		        
		    	createAsycNode(async,"kafkaAppender");
		    	setLog4jToConfig(UserPrincipal.peekUserId(false), config,  xmlFormat(document.asXML()), UserPrincipal.get().getIp(),projectId);
			}else if (operator.equals("close")){ //关闭kafka日志输出
				if (kafka != null) {
					appenderChilds.remove(kafka);
				}
				removeAsycNode(async,"kafkaAppender");
				
				//修复关闭kafka日志bug，删除不完全，如果asyns节点不存在子节点，则要把Appenders 下的Async节点删除，还需要把loggers-->root下的AppenderRef Async也要删除，不然会报错
				if(async.elements().size()==0){
					appenders.remove(async);
					Element loggersElement = getLoggersRoot(document);
					removeAsycNode(loggersElement,"Async");
				}
				
				setLog4jToConfig(UserPrincipal.peekUserId(false), config,  xmlFormat(document.asXML()), UserPrincipal.get().getIp(),projectId);
			}else if (operator.equals("exist")) {
				flag = ( kafka!=null );
			}
		}catch (Exception e){
			throw new NullPointerException("更改配置文件失败");
		}
		 return flag;
		
	}
	
	public Element getLoggersRoot(Document document){
		Element root = document.getRootElement();// 获取根元素
		List<Element> rootChilds = root.elements();//根元素下的所有子元素(Loggers)
		Element appenders = null;
		for (Element element : rootChilds) {
			
			String name = element.getName();
			if (name.equalsIgnoreCase("Loggers")) {
				List<Element> loggersC = element.elements();
				for (Element element2 : loggersC) {
					String name1 = element2.getName();
					if("Root".equals(name1)){
						//List<Element> loggersR = element2.elements();
						//for (Element element3 : loggersR) {
						//String ref = element3.attributeValue("ref");
						//if(!StringUtils.isEmpty(ref)&&"Async".equals(ref)){
							appenders = element2;
							break;
						//}
					}
				}
			}
		}
		if (appenders == null) {
			throw new NullPointerException("文件中不存在<Appenders/>节点");
		}
		return appenders;
	}
	
	/**
	 * xml 格式化
	 * @param str
	 * @return
	 * @throws Exception
	 */
	private String xmlFormat(String str) throws Exception {
        SAXReader reader = new SAXReader();
        XMLWriter writer = null;
        StringWriter out = null;
        String formatString = null;
        try {
        	// 注释：创建一个串的字符输入流
        	StringReader in = new StringReader(str);
        	Document doc = reader.read(in);
        	// System.out.println(doc.getRootElement());
        	// 注释：创建输出格式
        	OutputFormat formater = OutputFormat.createPrettyPrint();
        	//formater=OutputFormat.createCompactFormat();
        	// 注释：设置xml的输出编码
        	formater.setEncoding("utf-8");
        	// 注释：创建输出(目标)
        	out = new StringWriter();
        	// 注释：创建输出流
        	writer = new XMLWriter(out, formater);
        	// 注释：输出格式化的串到目标中，执行后。格式化后的串保存在out中。
        	writer.write(doc);
        	
        	formatString = out.toString();
		}finally{
			if(out!=null){
				out.close();
			}
			if(writer!=null){
				writer.close();
			}
		}
        
        // 注释：返回我们格式化后的结果
        return formatString;
    }

	
}
