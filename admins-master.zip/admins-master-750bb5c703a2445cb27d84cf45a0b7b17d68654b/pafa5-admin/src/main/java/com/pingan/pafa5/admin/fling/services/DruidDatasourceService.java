package com.pingan.pafa5.admin.fling.services;

public interface DruidDatasourceService {
	
	public void druidHeartBeat();

}
