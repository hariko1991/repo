package com.pingan.pafa5.admin.pizza.services;

import com.pingan.pafa5.admin.pizza.dto.IvyLibWarehouseDTO;

/**
 * @see ivy仓库服务接口
 * @author JIECHANGKE805
 * @date 2016-12-14
 */
public interface IvyLibWarehouseService {
	
	/**
	 * @see 检查是否已经存在相同的jar包
	 * @param md5
	 * @return 存在:true,不存在:false
	 */
	public String  checkExistsAndReturnPath(String projectId,String md5);
	
	/**
	 * @see 保存lib包
	 * @param ivyLib
	 * @return void 
	 */
	public void saveIvyLib(IvyLibWarehouseDTO ivyLibDTO);
	
	/**
	 * @see 根据Id查询lib
	 * @param id
	 * @return lib和描述信息
	 */
	public IvyLibWarehouseDTO findById(String id);
	
	/**
	 * @see 清理上传jar包到ivy仓库产生的临时文件
	 */
	public void cleanIvyWarehouseTempFile();

}
