package com.pingan.pafa5.admin.fling.dao;

import java.util.List;
import java.util.Map;

import com.pingan.pafa5.admin.fling.po.DruidSqlPO;

public interface DruidSqlDAO {
	
	public void add(DruidSqlPO sql);
	public void update(DruidSqlPO sql);
	public List<DruidSqlPO> list(Map<String,Object> map);
	public long getDruidSqlCount(Map<String,Object> map);
	public DruidSqlPO getDruidSqlBySqlId(long sqlId, int identity);

}
