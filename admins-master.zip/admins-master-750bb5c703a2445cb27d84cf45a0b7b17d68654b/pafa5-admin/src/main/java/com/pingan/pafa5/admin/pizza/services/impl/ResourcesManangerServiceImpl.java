package com.pingan.pafa5.admin.pizza.services.impl;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.codec.binary.Base64;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa.pizza.PizzaConstants;
import com.pingan.pafa.pizza.classloader.ClasspathResourceContent;
import com.pingan.pafa.pizza.classloader.ClasspathResourceKey;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSaveDTO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSearchDTO;
import com.pingan.pafa5.admin.pizza.dto.ResourceFileDTO;
import com.pingan.pafa5.admin.pizza.dto.ResourceUploadDTO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigPO;
import com.pingan.pafa5.admin.pizza.services.PizzaConfigServices;
import com.pingan.pafa5.admin.pizza.services.ResourcesManangerService;
import com.pingan.pafa5.admin.pizza.utils.ConfigContentUtils;

@Service
public class ResourcesManangerServiceImpl extends BaseServices implements ResourcesManangerService {
	
	@Autowired
	private ConfigContentUtils configContentUtils;
	
	@Autowired
	private PizzaConfigServices pizzaConfigServices;
	
	public PageDataDTO<ResourceFileDTO> list(String domainId, String sarName, int limit, int page) {
		ConfigSearchDTO query = new ConfigSearchDTO();
		query.setGroup(PizzaConstants.GROUP_RESOURCES);
		query.setProjectId(domainId);
		query.setLikeKey(sarName);
		query.setLimit(limit);
		query.setPage(page);
		PageDataDTO<PizzaConfigPO> pageDataDTO = pizzaConfigServices.search(query);

		PageDataDTO<ResourceFileDTO> pageData = new PageDataDTO<ResourceFileDTO>();
		List<PizzaConfigPO> list = pageDataDTO.getDatas();
		if (list != null && list.size() > 0) {
			List<ResourceFileDTO> arys = new ArrayList<ResourceFileDTO>();
			for (PizzaConfigPO po : list) {
			    ResourceFileDTO dto =  new ResourceFileDTO();
				String key = po.getPizzaKey();//sar#file
				if (key != null && key.length() > 0) {
					//#pafa5_sample_helloworld#test.properties
					if (key.charAt(0) == '#') {
						key = key.substring(1, key.length() - 1);
					}
					String[] items = key.split("#");
					if (items.length == 2) {
					    dto.setSarName(items[0]);
					    dto.setFileName(items[1]);
					    dto.setId(po.getId());
					    dto.setDomainId(domainId);
					    dto.setFileMD5(po.getValueMd5());
					    dto.setSize(po.getValueSize());
					    dto.setCreatedBy(po.getCreatedBy());
                        dto.setCreatedDate(po.getCreatedDate());
                        dto.setUpdatedBy(po.getUpdatedBy());
                        dto.setUpdatedDate(po.getUpdatedDate());
						arys.add(dto);
					}
				}
			}
			pageData.setDatas(arys);
		}
		pageData.setTotalSize(pageDataDTO.getTotalSize());
		return pageData;
	}
	
	@Override
	public byte[] getFileContent(String domainId, String key) {
		String content = pizzaConfigServices.getConfigContent(domainId, PizzaConstants.GROUP_RESOURCES, key);
		if (content == null || content.length() == 0) {
			return null;
		}
		
		String base64 = ClasspathResourceContent.fromJSONString(content).getBase64datas();
		return Base64.decodeBase64(base64);
	}
	
	@Override
	public boolean delete(String domainId, String id) {
		PizzaConfigPO po = pizzaConfigServices.get(domainId, PizzaConstants.GROUP_RESOURCES, id);
		
		if (po == null) {
			throw new ResponseCodeException("343", "资源文件不存在");
		}
		
		boolean success = pizzaConfigServices.del(domainId, PizzaConstants.GROUP_RESOURCES, id);
		return success;
	}
	
	/** Resource 是将上传内容放到pizza中最终保存到ZK里面去
	 *  任何操作都是从PIZZA里面去操作的，而不需要创建一个PO来存储该对象。
	 *  pizzaConfigServices 里面包含了复杂的业务处理逻辑，比如 add,update,del等
	 */
	public int putPizza(ClasspathResourceKey _key, ResourceUploadDTO dto, String content) throws Exception{
		int result = 0;
		String key = _key.toString();
		if(logger.isInfoEnabled()){
			logger.info("save,Namespace="+_key.getNamespace()+",ResourceName="+_key.getResourceName());
		}
		if(content==null|| content.length()==0){
			throw new NullPointerException("content is null.");
		}
		if(key==null|| (key=key.trim()).length()==0){
			throw new NullPointerException("key is null.");
		}
		
		String proId = dto.getProjectId();
		boolean exists = pizzaConfigServices.checkExists(proId, PizzaConstants.GROUP_RESOURCES, key);
		
		if (exists) {
			//如果存在，则校验文件的内容是否发生了变化
			PizzaConfigPO pcf = pizzaConfigServices.get(proId, PizzaConstants.GROUP_RESOURCES, key);
			String nvmd5 = pcf.getValueMd5();//新值
			String ovmd5=configContentUtils.md5(content);//旧值
			if (nvmd5.equals(ovmd5)) {
				return 1;
			}
		}
		
		ConfigSaveDTO form = new ConfigSaveDTO();
        form.setProjectId(proId);
        form.setProjectName(dto.getProjectName());
        form.setKey(key);
        form.setGroup(PizzaConstants.GROUP_RESOURCES);
        form.setValue(content);
        form.setOptype(dto.getOtype());
        result = pizzaConfigServices.save(form);
		return result;
	}

    public void setConfigContentUtils(ConfigContentUtils configContentUtils) {
        this.configContentUtils = configContentUtils;
    }

    public void setPizzaConfigServices(PizzaConfigServices pizzaConfigServices) {
        this.pizzaConfigServices = pizzaConfigServices;
    }

}
