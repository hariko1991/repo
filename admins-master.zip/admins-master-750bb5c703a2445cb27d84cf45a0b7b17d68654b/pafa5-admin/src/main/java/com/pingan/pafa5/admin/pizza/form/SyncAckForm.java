package com.pingan.pafa5.admin.pizza.form;

public class SyncAckForm {
	
	private String syncId;
	
	private Integer total;
	
	private Integer success;

	public String getSyncId() {
		return syncId;
	}

	public void setSyncId(String syncId) {
		this.syncId = syncId;
	}

	public Integer getTotal() {
		return total;
	}

	public void setTotal(Integer total) {
		this.total = total;
	}

	public Integer getSuccess() {
		return success;
	}

	public void setSuccess(Integer success) {
		this.success = success;
	}

}
