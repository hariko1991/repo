package com.pingan.pafa5.admin.pizza.services.impl;

import java.io.IOException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Callable;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.HttpMultipartMode;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSON;
import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.biz.services.BaseServices;
import com.paic.pafa.utils.MDCUtil;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa.redis.lock.RedisLock;
import com.pingan.pafa.redis.lock.RedisLockFactory;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.PizzaConstants.EnvSyncType;
import com.pingan.pafa5.admin.pizza.dao.EnvSyncFailureDAO;
import com.pingan.pafa5.admin.pizza.dao.EnvSyncLogDAO;
import com.pingan.pafa5.admin.pizza.dto.EnvSyncLogDTO;
import com.pingan.pafa5.admin.pizza.http.HttpResponse;
import com.pingan.pafa5.admin.pizza.http.HttpService;
import com.pingan.pafa5.admin.pizza.http.LoginResponse;
import com.pingan.pafa5.admin.pizza.po.EnvSyncFailurePO;
import com.pingan.pafa5.admin.pizza.po.EnvSyncLogPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigPO;
import com.pingan.pafa5.admin.pizza.services.ConfigGroupServices;
import com.pingan.pafa5.admin.pizza.services.EnvSyncService;
import com.pingan.pafa5.admin.pizza.services.PizzaConfigServices;
import com.pingan.um.client.util.UUID;

@Service
public class EnvSyncServiceImpl extends BaseServices implements EnvSyncService {

    public final String LOGIN_PATH = "/login.do";
    public final String LIST_RESOURCES_PATH = "/pizzamgr/envsync/list-all-resources.do";
    public final String CONFIG_SYNC = "/pizzamgr/sync.do";

    public static final String LOCK_OBJ_ID = "pizza-env-sync";
    
    public CountDownLatch latch = null;
    
    private ExecutorService executor = Executors.newFixedThreadPool(Runtime.getRuntime().availableProcessors());

    @Autowired
    private EnvSyncLogDAO envSyncLogDAO;

    @Autowired
    private EnvSyncFailureDAO envSyncFailureDAO;

    @Autowired
    private ConfigGroupServices configGroupServices;

    @Autowired
    private PizzaConfigServices pizzaConfigServices;

    @Autowired
    private HttpService httpService;

    @Autowired
    private RedisLockFactory lockFactory;
    
    @ActionClient(name = "pafa5-admin-systems.findAllProjects")
    private IServiceClient listAllDomainIds;

    @Override
    public boolean testLink(String uri, String loginUser, String loginPwd) {
        boolean success = false;
        try {
            Map<String, String> params = new HashMap<String, String>();
            params.put("uname", loginUser);
            params.put("password", loginPwd);
            LoginResponse loginResponse = httpService.loginRequest(uri + LOGIN_PATH, params);
            String code = loginResponse.getResponseCode();
            success = loginResponse.getSuccess();
            if ( !code.equals("0") &&!success) {
            	throw new ResponseCodeException("256", "用户名或者密码错误，请检查");
            }
        }catch(ResponseCodeException e){
        	logger.error(e);
        	throw e;
        } catch (Exception e) {
            logger.error(e);
            throw new ResponseCodeException("256", "网络连接失败，请检查 URL地址");
        }
        return success;
    }

    @Override
    public PageDataDTO<EnvSyncLogDTO> list(Map<String,Object> queryParams, int page, int limit) {
        PageDataDTO<EnvSyncLogDTO> pageData = new PageDataDTO<EnvSyncLogDTO>();
        long count = envSyncLogDAO.getCount(queryParams);
        if (count > 0) {
            List<EnvSyncLogPO> pos = envSyncLogDAO.list(queryParams, page, limit);
            if (pos != null && pos.size() > 0) {
                List<EnvSyncLogDTO> dtos = new ArrayList<EnvSyncLogDTO>(pos.size());
                for (EnvSyncLogPO po : pos) {
                    EnvSyncLogDTO dto = new EnvSyncLogDTO();
                    POUtils.copyProperties(dto, po);
                    dto.setCause(dto.getStatus()==1?"失败":(dto.getStatus()==2?"成功":""));
                    dtos.add(dto);
                }
                pageData.setDatas(dtos);
            }
        }
        pageData.setTotalSize(count);
        return pageData;
    }

    @Override
    public EnvSyncLogDTO findLog(String id) {
        EnvSyncLogPO po = envSyncLogDAO.findById(id);
        if (po == null) {
            if (logger.isWarnEnabled()) {
                logger.warn("Env sync log id：" + id + " was not found!");
            }
            return null;
        }
        EnvSyncLogDTO dto = new EnvSyncLogDTO();
        POUtils.copyProperties(dto, po);
        return dto;
    }

    @Override
    public void manulSync(String domainId, String domainName, String uri, String loginUser, String loginPwd) {
        RedisLock lock = lockFactory.getLock(LOCK_OBJ_ID);
        EnvSyncLogPO syncLog = null;
    	if (lock.tryLock()) {
            try {
                LoginResponse response = login(uri, loginUser, loginPwd);
                if (response != null) {

                    String code = response.getResponseCode();
                    boolean success = response.getSuccess();
                    if (code.equals("0") && success) {
                        syncLog = record(domainId, domainName, EnvSyncType.MANUAL, loginUser,uri);
                        logger.info("syncLog="+syncLog);
                        if (syncLog != null) {
                            List<String> targetDomainIds;
//                                if(domainId == null || "ALL".equals(domainId.toUpperCase())) {
//                                    targetDomainIds = allDomainIds();
//                                } else {
//                                    targetDomainIds = new ArrayList<String>(1);
//                                    targetDomainIds.add(domainId);
//                                }
                            
                            if(domainId == null){
                            	throw new ResponseCodeException("256","领域名不能为空，请检查");
                            }else{
                            	 targetDomainIds = new ArrayList<String>(1);
                            	 targetDomainIds.add(domainId);
                            }
                            if(targetDomainIds!=null&&targetDomainIds.size()>0){
                            	String requestId = MDCUtil.peek().getRequestId();
                            	logger.info("开始执行同步方法：异步");
                            	SyncTask task = new SyncTask(requestId,syncLog.getId(), targetDomainIds, uri, response.getCookie(), lock);
                            	executor.execute(task);
                            	logger.info("开始执行同步方法：run方法运行");
                            }else{
                            	logger.info("targetDomainIds为null或者size=0，"+targetDomainIds);
                            }
                        }else{
                        	logger.info("初始化同步信息失败：");
                        }
                    } else {
                        throw new ResponseCodeException("256", "用户名或者密码错误，请检查");
                    }
                }
            } catch(ResponseCodeException e){
            	lock.unlock();
            	throw e;
            } catch (Exception e) {
            	lock.unlock();
                logger.error(e);
                throw new ResponseCodeException("256", "网络连接失败，请检查 URL地址");
            }
        } else {
            throw new IllegalArgumentException("EnvSync executing, not completed.");
        }
		
        
    }
 
    /**
     * 用户登录
     * @param uri
     * @param loginUser
     * @param password
     * @return
     * @throws Exception
     */
    private LoginResponse login(String uri, String loginUser, String password) throws Exception {
        Map<String, String> params = new HashMap<String, String>(2);
        params.put("uname", loginUser);
        params.put("password", password);
        return httpService.loginRequest(uri + LOGIN_PATH, params);
    }

    /**
     * 记录当前操作
     * @param domainId
     * @param domainName
     * @param syncType
     * @param loginUser
     * @return
     */
    private EnvSyncLogPO record(String domainId, String domainName, Integer syncType, String loginUser,String uri) throws Exception{
    	// 保存开始记录
    	EnvSyncLogPO syncLog = new EnvSyncLogPO();
    	syncLog.setLoginUser(loginUser);
    	syncLog.setDomainId(domainId);
    	syncLog.setDomainName(domainName);
    	syncLog.setSyncType(syncType);
    	POUtils.setForAdd(loginUser, syncLog);
    	syncLog.setStatus(0);
    	syncLog.setUri(uri);
    	String id = envSyncLogDAO.add(syncLog);
    	syncLog.setId(id);
    	return syncLog;
    }

    /**
     * 启动执行
     * @param domainId
     * @param syncId
     * @param uri
     * @param cookie
     */
    public Map<String, Long> startup(String domainId, String syncId, final String uri, String cookie) {
        long successCount = 0;// 成功计数器
        long totalCount = 0;// 总数计数器
        EnvSyncFailurePO failure = null;
        CloseableHttpClient client = null;
        try {
	        List<PizzaConfigPO> pos = pizzaConfigServices.queryAllByProject(domainId);
	        failure = new EnvSyncFailurePO();
	        totalCount = pos.size();
	        if (logger.isInfoEnabled()) {
	            logger.info("跨环境同步开始，领域："+domainId+"，资源数量=" + totalCount);
	        }
	        client = HttpClientBuilder.create().build();
	        Map<String, String> remoteMapping = httpService.allResourcesRequest(client,uri + LIST_RESOURCES_PATH + "?projectId=" + domainId);
	        
            for (PizzaConfigPO po : pos) {
                String group = po.getPizzaGroup();
                String key = po.getPizzaKey();
                String pid = po.getProjectId();
                if (pid != null) {
                    key = pid + "/" + group + "/" + key;
                } else {
                    key = group + "/" + key;
                }
                if (remoteMapping.containsKey(key)  && po.getValueMd5().equals(remoteMapping.get(key))) {
                    if (logger.isInfoEnabled()) {
                        logger.info("资源已经存在：" + po.getPizzaKey() + "，MD5：" + po.getValueMd5());
                    }
                    successCount++;
                } else {
                    if (logger.isInfoEnabled()) {
                        logger.info("同步资源：" + po.getPizzaKey() + "，MD5：" + po.getValueMd5() + "，资源大小=" + po.getValueSize());
                    }
                    
                    failure.setGroupId(po.getPizzaGroup());
                    failure.setPizzKey(po.getPizzaKey());
                    
                    String pizzaValue = pizzaConfigServices.getConfigContent(pid, group, po.getPizzaKey());
                    boolean flag = syncToBackup(client,uri, cookie, syncId, po, pizzaValue);

                    if (flag) {
                        successCount++;
                    }
                }
            }
            
            Map<String, Long> resultCount = new HashMap<String, Long>(2);
            resultCount.put("successCount", successCount);
            resultCount.put("totalCount", totalCount);
            return resultCount;
            
        } catch (Exception ex) {
            StackTraceElement[] stackTraceElements = ex.getStackTrace();
            String result = ex.toString() + "\n";
            for (int index = stackTraceElements.length - 1; index >= 0; --index) {
                result += "\tat [" + stackTraceElements[index].getClassName() + ",";
                result += stackTraceElements[index].getFileName() + ",";
                result += stackTraceElements[index].getMethodName() + ",";
                result += stackTraceElements[index].getLineNumber() + "]\n";
            }
            
            failure.setId(UUID.getRandomID());
            failure.setCause(result);
            failure.setCurrDate(new Date());
            failure.setSyncId(syncId);
            // 保存失败记录
            envSyncFailureDAO.add(failure);
            logger.error("",ex);
            
            Map<String, Long> resultCount = new HashMap<String, Long>(2);
            resultCount.put("successCount", successCount);
            resultCount.put("totalCount", totalCount);
            return resultCount;
        }finally{
        	latch.countDown();
        	if(client!=null){
        		try {
					client.close();
				} catch (IOException e) {
					logger.error("关闭httpclient失败：",e);
				}
        	}
        }
          
    }

    public boolean syncToBackup(CloseableHttpClient client,String uri, String cookie, String syncId, PizzaConfigPO po, String pizzaValue) {
        CloseableHttpResponse httpResponse = null;
        try {
        	ContentType contentType = ContentType.create("text/plain",Charset.forName("UTF-8"));

        	MultipartEntityBuilder builder = MultipartEntityBuilder.create();
        	builder.setMode(HttpMultipartMode.BROWSER_COMPATIBLE);

        	builder.addTextBody("projectId", po.getProjectId(), ContentType.DEFAULT_TEXT);
        	if (!StringUtils.isEmpty(po.getProjectName())) {
        		builder.addTextBody("projectName", po.getProjectName(), ContentType.DEFAULT_TEXT);
        	}
        	builder.addTextBody("group", po.getPizzaGroup(), ContentType.DEFAULT_TEXT);
        	builder.addTextBody("key", po.getPizzaKey(), ContentType.DEFAULT_TEXT);
        	builder.addTextBody("value", pizzaValue, contentType);
        	HttpEntity entity = builder.build();

        	HttpPost post = new HttpPost(uri + CONFIG_SYNC);
        	post.setEntity(entity);
        	post.addHeader("Cookie", cookie);

            httpResponse = client.execute(post);
            HttpEntity respEntity = httpResponse.getEntity();
            int httpcode = httpResponse.getStatusLine().getStatusCode();
            logger.info(post.getURI()+",httpcode="+httpcode);
            if (HttpStatus.SC_OK == httpcode) {
            	if (respEntity != null) {
	            	String result = EntityUtils.toString(respEntity, "UTF-8");
	                HttpResponse response = JSON.parseObject(result, HttpResponse.class);
	                if(!response.getSuccess()){
	                	 response = JSON.parseObject(result, HttpResponse.class);
	                     EnvSyncFailurePO failure = new EnvSyncFailurePO();
	                     failure.setId(UUID.getRandomID());
	                     failure.setGroupId(po.getPizzaGroup());
	                     failure.setPizzKey(po.getPizzaKey());
	                     failure.setCause(response.getResponseMsg());
	                     failure.setCurrDate(new Date());
	                     failure.setSyncId(syncId);
	                     // 保存失败记录
	                     envSyncFailureDAO.add(failure);
	                     if (logger.isWarnEnabled()) {
	                         logger.warn("记录同步失败：" + JSON.toJSON(failure));
	                     }
	                     
	                     return false;
	                }
            	}
                return true;
            } else {
                if (respEntity != null) {
                    EnvSyncFailurePO failure = new EnvSyncFailurePO();
                    failure.setId(UUID.getRandomID());
                    failure.setGroupId(po.getPizzaGroup());
                    failure.setPizzKey(po.getPizzaKey());
                    failure.setCause(httpResponse.getStatusLine().toString());
                    failure.setCurrDate(new Date());
                    failure.setSyncId(syncId);
                    // 保存失败记录
                    envSyncFailureDAO.add(failure);
                    if (logger.isWarnEnabled()) {
                        logger.warn("记录同步失败：" + JSON.toJSON(failure));
                    }
                }
                return false;
            }
        } catch (ClientProtocolException e) {
        	logger.error("",e);
            return false;
        } catch (IOException e) {
        	logger.error("",e);
            return false;
        }finally{
        	if(httpResponse!=null){
        		try {
					httpResponse.close();
				} catch (IOException e) {
					logger.error("",e);
				}
        	}
        }
    }

    @Override
    public List<EnvSyncFailurePO> getFailuers(String syncId) {
        return envSyncFailureDAO.list(syncId);
    }
    
    protected List<String> allDomainIds() {
        ServiceResults results = listAllDomainIds.invoke();
        List<Map<String, Object>> list = (List)results.get("datas");
        
        List<String> domainIds = new ArrayList<String>(list.size());
        domainIds.add("def");
        for (Map<String, Object> map : list) {
            String domainId = (String)map.get("groupId");
            domainIds.add(domainId);
        }   
        
        return domainIds;
    }
    
    public class SyncTask implements Runnable {
        
        private String syncId;
        private List<String> targetDomainIds;
        private String uri;
        private String cookie;
        private RedisLock lock;
        private String requestId;

        public SyncTask(String requestId,String syncId, List<String> targetDomainIds, String uri, String cookie, RedisLock lock) {
            //super();
        	this.requestId = requestId;
            this.syncId = syncId;
            this.targetDomainIds = targetDomainIds;
            this.uri = uri;
            this.cookie = cookie;
            this.lock = lock;
        }

        @Override
        public void run() {
        	MDCUtil.set(requestId);
        	logger.info("syncId="+syncId+",targetDomainIdSize="+targetDomainIds.size()+",uri="+uri+",cookie="+cookie+",lock="+lock);
        	long beginTime = System.nanoTime();
        	long successCount = 0;
            long totalCount = 0;
            EnvSyncLogPO syncLog = null;
            try {
                latch = new CountDownLatch(targetDomainIds.size());
                List<Future<Map<String, Long>>> results = new ArrayList<Future<Map<String, Long>>>(targetDomainIds.size());
                
                for(String targetDomainId : targetDomainIds) {
                    SyncWorker worker = new SyncWorker(requestId,targetDomainId, syncId, uri, cookie);
                    Future<Map<String, Long>> counts = executor.submit(worker);
                    results.add(counts);
                }    
                
                latch.await();
               
                for(Future<Map<String, Long>> future : results) {
                    Map<String, Long> counts = future.get();
                    successCount += counts.get("successCount");
                    totalCount += counts.get("totalCount");
                }
                
                syncLog = envSyncLogDAO.findById(syncId);
                long endTime = System.nanoTime();
                syncLog.setTime(((endTime - beginTime)/1000/1000/1000.00)+"");
                syncLog.setSuccessCount(successCount);
                syncLog.setTotalCount(totalCount);
                syncLog.setStatus(successCount == totalCount ? 2: 1);
                syncLog.setCause(successCount == totalCount?"同步成功":"同步成功数与需要同步的数目不匹配，请查看失败详情");
                
                logger.info("同步已完成……");
            } catch(Exception e) {
            	logger.error("",e);
            	long endTime = System.nanoTime();
            	syncLog = envSyncLogDAO.findById(syncId);
            	syncLog.setTime(((endTime - beginTime)/1000/1000/1000.00)+"");
                syncLog.setSuccessCount(successCount);
                syncLog.setTotalCount(totalCount);
                syncLog.setStatus(1);
                syncLog.setCause(e.getMessage());
            } finally {
            	envSyncLogDAO.update(syncLog);
                lock.unlock();
            }      
        }
    }

    public class SyncWorker implements Callable<Map<String, Long>> {
        private String requestId;
        private String domainId;
        private String syncId;
        private String uri;
        private String cookie;             

        public SyncWorker(String requestId,String domainId, String syncId, String uri, String cookie) {
            //super();
        	this.requestId = requestId;
            this.domainId = domainId;
            this.syncId = syncId;
            this.uri = uri;
            this.cookie = cookie;
        }

        @Override
        public Map<String, Long> call() throws Exception {
        	 MDCUtil.set(requestId);
        	logger.info("domainId="+domainId+",syncId="+syncId+",uri="+uri+",cookie="+cookie);
            return startup(domainId, syncId, uri, cookie);
        }
        
    }

    public void setEnvSyncLogDAO(EnvSyncLogDAO envSyncLogDAO) {
        this.envSyncLogDAO = envSyncLogDAO;
    }

    public void setEnvSyncFailureDAO(EnvSyncFailureDAO envSyncFailureDAO) {
        this.envSyncFailureDAO = envSyncFailureDAO;
    }

    public void setConfigGroupServices(ConfigGroupServices configGroupServices) {
        this.configGroupServices = configGroupServices;
    }

    public void setPizzaConfigServices(PizzaConfigServices pizzaConfigServices) {
        this.pizzaConfigServices = pizzaConfigServices;
    }

    public void setHttpService(HttpService httpService) {
        this.httpService = httpService;
    }

    public void setLockFactory(RedisLockFactory lockFactory) {
        this.lockFactory = lockFactory;
    }

    public void setListAllDomainIds(IServiceClient listAllDomainIds) {
        this.listAllDomainIds = listAllDomainIds;
    }

}
