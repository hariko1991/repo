package com.pingan.pafa5.admin.pizza.po;

import java.util.Date;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.paic.pafa.biz.dao.BasePO;

/**
 * 全局变量
 * 
 * @author zhanggang871
 * 
 *         <p>
 *         存储格式：global.project.${property}=value
 *         </p>
 */
@Document
public class GlobalVariableBackupPO extends BasePO{

	/**
	 * proId.property
	 * 
	 * id由service层生成uuid {@link com.pingan.pafa5.admin.pizza.services.impl.GlobalVariableServiceImpl#add}
	 */
	@org.springframework.data.annotation.Id
	private String id;

	/**
	 * 领域id
	 */
	private String proId;

	/**
	 * 领域名称
	 */
	private String proName;

	/**
	 * 配置项名称
	 */
	private String property;

	/**
	 * 值
	 */
	private String value;
	
	/**
	 * 版本号
	 */
	@Indexed
	private String versionId;

	private boolean isHidden = false;
	/**
	 * 备份下标
	 */
	private int index;
	
	private String valueMd5;
	
	private Date backUpTime;
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProperty() {
		return property;
	}

	public void setProperty(String property) {
		this.property = property;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getProId() {
		return proId;
	}

	public void setProId(String proId) {
		this.proId = proId;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public String getVersionId() {
		return versionId;
	}

	public void setVersionId(String versionId) {
		this.versionId = versionId;
	}

	public int getIndex() {
		return index;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public String getValueMd5() {
		return valueMd5;
	}

	public void setValueMd5(String valueMd5) {
		this.valueMd5 = valueMd5;
	}

	public boolean isHidden() {
		return isHidden;
	}

	public void setHidden(boolean isHidden) {
		this.isHidden = isHidden;
	}

	public Date getBackUpTime() {
		return backUpTime;
	}

	public void setBackUpTime(Date backUpTime) {
		this.backUpTime = backUpTime;
	}
	
}
