package com.pingan.pafa5.admin.monitor.web;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa5.admin.monitor.dao.InterfaceDAO;
import com.pingan.pafa5.admin.monitor.dao.MongoFileDAO;
import com.pingan.pafa5.admin.monitor.dtos.InterfaceDTO;
import com.pingan.pafa5.admin.monitor.dtos.MethodDTO;
import com.pingan.pafa5.admin.monitor.po.DubboInterfacePO;
import com.pingan.pafa5.admin.monitor.services.DubboMonitorService;

import sun.misc.BASE64Encoder;

@Controller
@RequestMapping("/monitor")
public class DubboMonitorController extends BaseController {

    @Autowired
    MongoFileDAO fileDAO;
    
    @Autowired
    InterfaceDAO interfaceDAO;

    private static Log logger = LogFactory.getLog(DubboMonitorController.class);
    
    @Autowired
    private DubboMonitorService dubboMonitorService;

    @ResponseBody
    @RequestMapping("/dubbo/list.do")
    public ResponseModel listName(@RequestParam(value = "limit", defaultValue = "30") int limit,
            @RequestParam(value = "page", defaultValue = "1") int page, 
            @RequestParam(value = "interfaceName", required = false) String interfaceName, 
            @RequestParam(value = "startTime", required = false) String startTime,
            @RequestParam(value = "endTime", required = false) String endTime) {
        ResponseModel model = new ResponseModel();
        long totalCount = dubboMonitorService.countInterface(startTime,endTime, interfaceName);
        List<DubboInterfacePO> pos = null;
        if(totalCount != 0L) {
            pos = dubboMonitorService.listInterface(startTime,endTime, interfaceName, page, limit);
        }
        model.put("datas", pos);
        model.put("total", totalCount);
        return model;
    }

    @ResponseBody
    @RequestMapping("/dubbo/chart.do")
    public ResponseModel getChart(
            @RequestParam(value = "chartname", required = false) String chartname) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        String result = "1";
        try {
            fileDAO.dumpOneFileToStreamAccordingToFilename(chartname, out);
        } catch (IOException e) {
            logger.error("getChartError,cause:" + e.getMessage(), e);

        }
        ResponseModel model = new ResponseModel();
        if (out.toString() != null && !out.toString().equals("")) {
            String base64 = new BASE64Encoder().encode(out.toByteArray());
            model.put("chart", base64);
            result = "0";
        }
        model.put("result", result);
        return model;
    }

    @ResponseBody
    @RequestMapping("/dubbo/papp.do")
    public ResponseModel listPapp() {
        // String day = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        ResponseModel model = new ResponseModel();
        List<InterfaceDTO> list = interfaceDAO.findAll();
        if (list == null) {
            return null;
        }
        List<MethodDTO> datas = new ArrayList<MethodDTO>();
        for (InterfaceDTO m : list) {
            MethodDTO method = new MethodDTO();
            String service = m.getInterfaceName() + "/" + m.getMethod();
            method.setService(service);
            datas.add(method);
        }
        model.put("pappNames", datas);
        return model;
    }
    
}
