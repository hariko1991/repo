package com.pingan.pafa5.admin.pizza.services.impl;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.UUID;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa.pizza.PizzaConstants;
import com.pingan.pafa5.admin.Constants;
import com.pingan.pafa5.admin.commons.POUtils;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.commons.PizzaManagerHolder;
import com.pingan.pafa5.admin.pizza.PizzaConstants.ConfigHistoryOperationType;
import com.pingan.pafa5.admin.pizza.PizzaConstants.VersionOperationType;
import com.pingan.pafa5.admin.pizza.dao.FileTempDAO;
import com.pingan.pafa5.admin.pizza.dao.IvyLibConfigDAO;
import com.pingan.pafa5.admin.pizza.dao.PizzaConfigDAO;
import com.pingan.pafa5.admin.pizza.dao.PizzaConfigValueDAO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSaveDTO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSearchDTO;
import com.pingan.pafa5.admin.pizza.dto.PizzaConfigHistoryDTO;
import com.pingan.pafa5.admin.pizza.form.PizzaConfigForm;
import com.pingan.pafa5.admin.pizza.po.ConfigGroupPO;
import com.pingan.pafa5.admin.pizza.po.FileTempPO;
import com.pingan.pafa5.admin.pizza.po.IvyLibConfigPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigHistoryPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigValuePO;
import com.pingan.pafa5.admin.pizza.services.ConfigGroupServices;
import com.pingan.pafa5.admin.pizza.services.HistoryConfigServices;
import com.pingan.pafa5.admin.pizza.services.PizzaConfigServices;
import com.pingan.pafa5.admin.pizza.utils.ConfigContentUtils;
import com.pingan.pafa5.admin.sso.CacheData;
import com.pingan.pafa5.admin.sso.UserPrincipal;
import com.pingan.um.client.util.StringUtil;


@Service
public class PizzaConfigServicesImpl extends BaseServices implements
		PizzaConfigServices {

	@Autowired
	private PizzaConfigDAO pizzaConfigDAO;

	@Autowired
	private PizzaConfigValueDAO pizzaConfigValueDAO;

	@Autowired
	private ConfigGroupServices configGroupServices;

	@Autowired
	private ConfigContentUtils configContentUtils;

	@Autowired
	private HistoryConfigServices historyConfigServices;

	@Autowired
	private IvyLibConfigDAO ivyConfigDAO;

	@Autowired
	private FileTempDAO fileTempDAO;

	@Autowired
	private PizzaManagerHolder pizzaManagerHolder;

	@ActionClient(name = "pafa5-admin-poolManager.asyncConfig")
	private IServiceClient poolManager;

	@ActionClient(name = "pafa5-admin-systems.isOwner")
	private IServiceClient ownerService;
	
	@Value(value="${pola.config.registry.projectList}")
	private String projectList= "";
	
	private boolean ifUploadToZookeeper(String projectId) {
		List<String> projects = Arrays.asList(projectList.split(","));
		return !(projects.contains(projectId));
	}

	@Override
	public PageDataDTO<PizzaConfigPO> search(ConfigSearchDTO searchDto) {
		if (searchDto.getPage() <= 0) {
			searchDto.setPage(1);
		}
		int limit = searchDto.getLimit();
		if (limit <= 0)
			searchDto.setLimit(30);
		if (limit > 100)
			searchDto.setLimit(100);

		return pizzaConfigDAO.pageQuery(searchDto);
	}

	// 资源中心lib 下保存依赖包
	@Override
	public int save(ConfigSaveDTO form) throws Exception{
		int result = 0;
		String proId = form.getProjectId();
		String group = form.getGroup();
		String key = form.getKey();
		String content = form.getValue();
		String operationType = form.getOptype();

		if (logger.isInfoEnabled()) {
			logger.info("Save pizza config, domainId=" + proId + ",group="+ group + ",key=" + key);
		}

		if (StringUtils.isEmpty(group)) {
			throw new NullPointerException("Save pizza config error, group is null.");
		}
		if (StringUtils.isEmpty(key)) {
			throw new NullPointerException("Save pizza config error, key is null.");
		}
		ConfigGroupPO groupDTO = configGroupServices.getGroup(group);
		//查询当前文件的现有配置信息，旧内容
		PizzaConfigPO curConfig = pizzaConfigDAO.get(proId, group, key);

		//新内容的md5值
		String valueMd5 = configContentUtils.md5(content);
		
		//判断当前修改的文件新内容md5值是否和就内容md5值一致，一致则提示前端，内容一致，不能修改
		if(curConfig!=null&&valueMd5.equals(curConfig.getValueMd5())){
			return 1;
		}
		
		Integer valueSize = 0;
		//valueSize = content.getBytes().length;
		
		valueSize = content.length();
		if(configContentUtils.isBinary(key)){
			valueSize = configContentUtils.decodeContent(content).length;
		}

//		PizzaConfigPO md5Exist=pizzaConfigDAO.isMD5Exist(proId, valueMd5);
//		if (md5Exist != null && curConfig !=null){
//			return 1;
//		}
		/*List<PizzaConfigPO> md5Exist = pizzaConfigDAO.listMD5Exist(proId,valueMd5, group);
		if (md5Exist != null && md5Exist.size() > 0 && curConfig !=null) {
			for (PizzaConfigPO md5ExistPO : md5Exist) {
				if (group.equals(md5ExistPO.getPizzaGroup())) {
					return 1;
				}
			}
		}*/
		
		// 0成功,1配置未变化,2保存失败
		PizzaConfigHistoryDTO historyDto = new PizzaConfigHistoryDTO();
		historyDto.setPizzaGroup(group);
		historyDto.setPizzaKey(key);
		historyDto.setPizzaValue(content);
		historyDto.setValueMd5(valueMd5);
		historyDto.setPizzaGroupName(groupDTO.getGroupName());
		historyDto.setValueSize(valueSize);
		historyDto.setProjectId(proId);
		historyDto.setProjectName(form.getProjectName());
		historyDto.setOperationType(operationType);
		if(curConfig == null){
			historyDto.setOperationType(ConfigHistoryOperationType.ADD);
		}else if(VersionOperationType.VERSION_ROLLBACK.equals(operationType)){
			historyDto.setOperationType(ConfigHistoryOperationType.UPDATE);
		}
		
//		if (operationType == null) {
//			if (curConfig == null) {
//				historyDto.setOperationType(ConfigHistoryOperationType.ADD);
//			}
//		} else {
//			if (curConfig == null) {
//				historyDto.setOperationType(ConfigHistoryOperationType.ADD);
//			}
//			else{
//				historyDto.setOperationType(operationType);
//			}
//		}
		UserPrincipal up = null;
		// 如果是ant打包请求ivy仓库，没有用户登录，做虚拟用户
		if (ConfigHistoryOperationType.IVY_ADD.equals(operationType)) {
			CacheData cd = new CacheData("IVY");
			cd.setIp("IVY-CLIENT-IP");
			up = new UserPrincipal("ivy-ticket-token", cd);
		} else if (ConfigHistoryOperationType.ROLLBACK.equals(operationType)) {
			CacheData cd = new CacheData("ROLLBACK");
			cd.setIp("127.0.0.1");
			up = new UserPrincipal("rollback-ticket-token", cd);

		} else if (ConfigHistoryOperationType.RECOVERY.equals(operationType)) {
			CacheData cd = new CacheData("RECOVERY");
			cd.setIp("127.0.0.1");
			up = new UserPrincipal("recovery-ticket-token", cd);
		} else {
			up = UserPrincipal.get(true);
		}
		historyDto.setOperationIp(up.getIp());
		historyDto.setOperationUser(up.getUid());

		if (curConfig == null) {
			try {
				if (!ConfigHistoryOperationType.RECOVERY.equals(operationType)) {
					if(ifUploadToZookeeper(proId)) {
						pizzaManagerHolder.getManager(proId).add(group, key, content);
					}else {
						logger.info("领域：" + proId + "在领域名单中。zip、lib不上传到ZK，只保存在DB。");
					}
				}
				historyConfigServices.save(historyDto);

				curConfig = new PizzaConfigPO();
				POUtils.copyProperties(curConfig, historyDto);
				POUtils.setForAdd(up.getUid(), curConfig);
				pizzaConfigDAO.add(curConfig);
				PizzaConfigValuePO curConfigValue = new PizzaConfigValuePO();
				curConfigValue.setId(curConfig.getId());
				curConfigValue.setPizzaValue(content);
				pizzaConfigValueDAO.save(curConfigValue);
			} catch (Exception ex) {
				logger.error("UpdateConfig failure,cause:" + ex.getMessage(), ex);
				return 2;
			}
		} else {//operationType is null and curCofig not null  optype is update
			try {
				if (!ConfigHistoryOperationType.RECOVERY.equals(operationType)) {
					if(ifUploadToZookeeper(proId)) {
						pizzaManagerHolder.getManager(proId).set(group, key, content);
					}else {
						logger.info("领域：" + proId + "在领域名单中。zip、lib不上传到ZK，只保存在DB。");
					}
				}
//				if(operationType==null){
//					historyDto.setOperationType(ConfigHistoryOperationType.UPDATE);
//				}else{
//					historyDto.setOperationType(operationType);
//				}
				historyConfigServices.save(historyDto);
				curConfig.setValueMd5(valueMd5);
				curConfig.setValueSize(valueSize);
				POUtils.setForUpdate(up.getUid(), curConfig);
				pizzaConfigDAO.update(curConfig);
				PizzaConfigValuePO curConfigValue = new PizzaConfigValuePO();
				curConfigValue.setId(curConfig.getId());
				curConfigValue.setPizzaValue(content);
				pizzaConfigValueDAO.update(curConfigValue);
			} catch (Exception ex) {
				logger.error("UpdateConfig failure,cause:" + ex.getMessage(), ex);
				return 2;
			}
		}

		// 如果是lib资源组，同步到依赖包仓库配置
		// if (Constants.LIB_GROUP.equals(group)) {
		// saveIvylib(form.getProjectId(), group, key, content);

		// 如果是lib资源组，同步到依赖包仓库配置
		if (Constants.LIB_GROUP.equals(group)) {
			saveIvylib(up, form.getProjectId(), group, key, content, operationType);
		}

		return result;
	}

	@Override
	public void addConfigContent(PizzaConfigForm form) {
		PizzaConfigPO po = new PizzaConfigPO();
		po.setPizzaGroup(PizzaConstants.GROUP_PAPP);
		po.setPizzaKey(form.getPizzaKey());
		po.setValueMd5(configContentUtils.md5(form.getPizzaValue()));
		po.setValueSize(form.getPizzaValue().length());
		POUtils.setForAdd(UserPrincipal.peekUserId(), po);
		pizzaConfigDAO.add(po);

		PizzaConfigValuePO valuePo = new PizzaConfigValuePO();
		valuePo.setId(po.getId());
		valuePo.setPizzaValue(form.getPizzaValue());
		pizzaConfigValueDAO.save(valuePo);
	}

	@Override
	public boolean updateConfigContent(PizzaConfigForm form) {
		PizzaConfigPO po = new PizzaConfigPO();
		po.setProjectId(form.getProjectId());
		po.setPizzaGroup(PizzaConstants.GROUP_PAPP);
		po.setPizzaKey(form.getPizzaKey());
		po.setValueMd5(configContentUtils.md5(form.getPizzaValue()));
		po.setValueSize(form.getPizzaValue().length());
		String id = "";
		String proId = form.getProjectId();
		if (proId == null ) {
			id = form.getPizzaGroup() + "/" + form.getPizzaKey();
		} else {
			id = proId + "/" + form.getPizzaGroup() + "/" + form.getPizzaKey();
		}
		po.setId(id);
		POUtils.setForUpdate(UserPrincipal.peekUserId(), po);

		PizzaConfigValuePO valuePo = new PizzaConfigValuePO();
		valuePo.setId(id);
		valuePo.setPizzaValue(form.getPizzaValue());

		boolean flag = pizzaConfigDAO.update(po);
		if (flag) {
			pizzaConfigValueDAO.save(valuePo);
		}

		return flag;
	}

	@Override
	public boolean checkExists(String domainId, String group, String key) {
		if (logger.isInfoEnabled()) {
			logger.info("checkExists,proId=" + domainId + ",group=" + group + ",key=" + key);
		}
		if (key == null || (key = key.trim()).length() == 0) {
			throw new NullPointerException("key is null.");
		}
		if (group == null || (group = group.trim()).length() == 0) {
			throw new NullPointerException("group is null.");
		}
		boolean result = false;
		if (domainId == null) {
			result = pizzaConfigDAO.exist(group, key);
		} else {
			result = pizzaConfigDAO.exist(domainId, group, key);
		}

		if (logger.isInfoEnabled()) {
			logger.info("checkExists,result=" + result);
		}
		return result;
	}

	@Override
	public boolean del(String domainId, String group, String key) {
		if (key == null || (key = key.trim()).length() == 0) {
			throw new NullPointerException("key is null.");
		}
		ConfigGroupPO groupDTO = configGroupServices.getGroup(group);
		if (logger.isInfoEnabled()) {
			logger.info("Del Config:" + groupDTO.getGroupCode() + "/" + key);
		}
		UserPrincipal up = UserPrincipal.get(false);
		String content = "";
		String valueMd5 = "";

		content = pizzaManagerHolder.getManager(domainId).get(group, key);

		if (content != null && !content.equals("")) {
			valueMd5 = configContentUtils.md5(content);
		}

		PizzaConfigHistoryDTO historyDto = new PizzaConfigHistoryDTO();
		historyDto.setPizzaGroup(group);
		historyDto.setPizzaKey(key);
		historyDto.setPizzaValue(content);
		historyDto.setValueMd5(valueMd5);
		historyDto.setPizzaGroupName(groupDTO.getGroupName());
		historyDto.setProjectId(domainId);
		historyDto.setOperationType(ConfigHistoryOperationType.DEL);
		if (up == null) {
			CacheData cd = new CacheData("QUENE");
			cd.setIp("127.0.0.1");
			up = new UserPrincipal("quene-ticket-token", cd);
		}
		historyDto.setOperationIp(up.getIp());
		historyDto.setOperationUser(up.getUid());
		historyConfigServices.save(historyDto);
		if (logger.isDebugEnabled()) {
			logger.debug("Pizza history=" + JSONObject.toJSONString(historyDto));
		}

		// 删除zk中存储的配置文件 del rootPath + "/" + group + "/" + key;
		pizzaManagerHolder.getManager(domainId).del(group, key);

		// 如果是lib资源，删除依赖仓库配置记录
		if (Constants.LIB_GROUP.equals(group)) {
			ivyConfigDAO.del(domainId, group, key);
		}

		pizzaConfigValueDAO.del(domainId, group, key);
		return pizzaConfigDAO.del(domainId, group, key);
	}

	@Override
	public PizzaConfigPO get(String domainId, String group, String key) {
		if (key == null || (key = key.trim()).length() == 0) {
			throw new NullPointerException("key is null.");
		}
		ConfigGroupPO groupDTO = configGroupServices.getGroup(group);
		if (logger.isInfoEnabled()) {
			logger.info("Get Config:" + domainId + "/" + groupDTO.getGroupCode() + "/" + key);
		}
		PizzaConfigPO config = pizzaConfigDAO.get(domainId, group, key);
		return config;
	}

	@Override
	public String getConfigContent(String domainId, String group, String key) {
		String id = domainId + "/" + group + "/" + key;
		PizzaConfigValuePO pizzaValuePO = pizzaConfigValueDAO.get(id);
		return pizzaValuePO == null ? null : pizzaValuePO.getPizzaValue();
	}

	@Override
	public byte[] getConfigByteContent(String domainId, String group, String key) {
		ConfigGroupPO groupDTO = configGroupServices.getGroup(group);
		if (domainId == null) {
			return configContentUtils.decodeContent(groupDTO,getConfigContent(null, group, key));
		}
		return configContentUtils.decodeContent(groupDTO,getConfigContent(domainId, group, key));
	}

	@Override
	public List<PizzaConfigPO> query(String group, String regexKey,
			String pattern) {
		return pizzaConfigDAO.query(group, regexKey, pattern);
	}

	@Override
	public List<PizzaConfigPO> query(String projectId, String group,
			String regexKey, String pattern) {
		return pizzaConfigDAO.query(projectId, group, regexKey, pattern);
	}

	@Override
	public List<PizzaConfigPO> queryByGroup(String group) {
		return pizzaConfigDAO.queryByGroup(group);
	}

	@Override
	public List<PizzaConfigPO> queryAll() {
		return pizzaConfigDAO.queryAll();
	}

	@Override
	public List<PizzaConfigPO> queryAllByProject(String proId) {
		return pizzaConfigDAO.queryAllByProject(proId);
	}

	/**
	 * 修改项目的项目配置信息
	 * 
	 * @param group
	 *            配置组
	 * @param key
	 *            配置key
	 * @param proId
	 *            项目id
	 * @param proName
	 *            项目名称
	 * @return
	 */
	@Override
	public boolean changeConfigProject(String group, String key, String proId,
			String proName) {
		PizzaConfigPO po = pizzaConfigDAO.get(group, key);
		if (po == null) {
			throw new ResponseCodeException("456", "没有找到到配置资源");
		}
		if (po.getProjectId() != null) {
			throw new ResponseCodeException("456", "配置资源已经存在项目组了");
		}

		po.setProjectId(proId);
		po.setProjectName(proName);
		return pizzaConfigDAO.addProject(po);
	}

	/**
	 * 保存IVY库
	 * 
	 * @param proId
	 * @param group
	 * @param pizzaKey
	 * @param content
	 */
	public void saveIvylib(UserPrincipal user, String proId, String group, String pizzaKey, String content, String operationType) throws Exception{
		try {
			String org, module, version;
			String[] vars = pizzaKey.split("#");
			if (vars.length == 1) {
				org = "unknown";
				int lastIndexOf = vars[0].lastIndexOf(".");
				if (lastIndexOf == -1) {
					lastIndexOf = vars.length;
				} else {
					lastIndexOf = vars.length - 1;
				}
				module = vars[0].substring(0, lastIndexOf);
				version = "unknown";
			} else if (vars.length == 3 && StringUtils.isNotEmpty(vars[0])
					&& StringUtils.isNotEmpty(vars[1])
					&& StringUtils.isNotEmpty(vars[2])) {
				org = StringUtil.isEmpty(vars[0]) ? "unknown" : vars[0];
				module = vars[1];
				int lastIndexOf = vars[0].lastIndexOf(".");
				if (lastIndexOf == -1) {
					lastIndexOf = vars.length;
				} else {
					lastIndexOf = vars.length - 1;
				}
				version = vars[2].substring(0, vars[2].lastIndexOf("."));
			} else {
				throw new ResponseCodeException("234",
						"配置键格式为jarName.jar或org#module#version.jar。");
			}
			// byte[] bytesValue = configContentUtils.decodeContent(content);
	
			IvyLibConfigPO ivyLibPO = new IvyLibConfigPO();
	
			if (proId == null ) {
				ivyLibPO.setId(group + "/" + pizzaKey);
			} else {
				ivyLibPO.setId(proId + "/" + group + "/" + pizzaKey);
			}
	
			ivyLibPO.setProjectId(proId);
			ivyLibPO.setGroup(group);
			ivyLibPO.setKey(pizzaKey);
			ivyLibPO.setOrg(org);
			ivyLibPO.setModule(module);
			ivyLibPO.setVersion(version);
			// if(module == null && version == null){
			ivyLibPO.setFileName(pizzaKey);
			// }else{
			// ivyLibPO.setFileName(module.concat("-").concat(version).concat(".jar"));
			// }
			ivyLibPO.setValueSize(configContentUtils.decodeContent(content).length);
	
			IvyLibConfigPO ivyLibConfigPO = ivyConfigDAO.find(proId, group, pizzaKey);
			UserPrincipal up = null;
	
			// 如果是ant打包请求ivy仓库，没有用户登录，做虚拟用户
			// if (operationType == null) {
			// String opTypeRollback = ConfigHistoryOperationType.ROLLBACK;
			// }
			if (ConfigHistoryOperationType.IVY_ADD.equals(operationType)) {
				CacheData cd = new CacheData("IVY");
				cd.setIp("IVY-CLIENT-IP");
				up = new UserPrincipal("ivy-ticket-token", cd);
			} else if (ConfigHistoryOperationType.ROLLBACK.equals(operationType)) {
				CacheData cd = new CacheData("ROLLBACK");
				cd.setIp("127.0.0.1");
				up = new UserPrincipal("rollback-ticket-token", cd);
			} else if (ConfigHistoryOperationType.RECOVERY.equals(operationType)) {
				CacheData cd = new CacheData("RECOVERY");
				cd.setIp("127.0.0.1");
				up = new UserPrincipal("recovery-ticket-token", cd);
			} else {
				up = UserPrincipal.get(true);
			}
			up = user;
			if (ivyLibConfigPO != null) {
				ivyLibPO.setCreatedBy(ivyLibConfigPO.getCreatedBy());
				ivyLibPO.setCreatedDate(ivyLibConfigPO.getCreatedDate());
				POUtils.setForUpdate(up.getUid(), ivyLibPO);
				ivyConfigDAO.update(ivyLibPO);
			} else {
				POUtils.setForAdd(up.getUid(), ivyLibPO);
				ivyConfigDAO.add(ivyLibPO);
			}
		} catch (Exception e) {
			logger.error("保存文件失败：",e);
			throw e;
		}
	}

	public void saveIvylib(UserPrincipal user, String group, String pizzaKey, String content, String operationType) {
		saveIvylib(user, group, pizzaKey, content, operationType);
	}

	/**
	 * 同步到连接池 管理
	 * 
	 * @param group
	 * @param key
	 * @param content
	 */
	private void async(String projectId, String group, String key,
			String content) {
		ServiceParams params = ServiceParams.newInstance();

		if (projectId != null) {
			params.put("projectId", projectId);
		}
		params.put("configs", content);
		params.put("group", group);
		params.put("pizzaKey", key);

		ServiceResults results = poolManager.invoke(params);
		logger.info(results);
	}

	@Override
	public int rollback(String group, String key, String content, String proId, UserPrincipal user) throws Exception{
		return save(proId, group, key, content,ConfigHistoryOperationType.ROLLBACK, user);
	}

	@Override
	public List<String> listKeys(String proId, String group,
			String pizzaKeyRegex) {
		if (group == null || (group = group.trim()).length() == 0) {
			throw new NullPointerException("group is null.");
		}
		if (proId.equalsIgnoreCase("def")) {
			return pizzaConfigDAO.listKeys(group, pizzaKeyRegex);
		}
		return pizzaConfigDAO.listKeys(proId, group, pizzaKeyRegex);
	}

	@Override
	public List<String> listKeys(String domainId, String group) {
		return listKeys(domainId, group, null);
	}

	@Override
	public int recoveryDB(String group, String key, String content, String proId) throws Exception{
		return save(proId, group, key, content, ConfigHistoryOperationType.RECOVERY, null);
	}

	public int save(String proId, String group, String key, String content, String operationType, UserPrincipal user) throws Exception{
		if (logger.isInfoEnabled()) {
			logger.info("save,group=" + group + ",key=" + key);
		}
		if (content == null || content.length() == 0) {
			throw new NullPointerException("content is null.");
		}
		if (key == null || (key = key.trim()).length() == 0) {
			throw new NullPointerException("key is null.");
		}
		ConfigGroupPO groupDTO = configGroupServices.getGroup(group);
		PizzaConfigPO curConfig = pizzaConfigDAO.get(proId, group, key);
		String valueMd5 = configContentUtils.md5(content);
		if (logger.isInfoEnabled()) {
			logger.info("md5=" + valueMd5);
		}
		if (curConfig != null && valueMd5.equals(curConfig.getValueMd5())) {
			if (logger.isInfoEnabled()) {
				logger.info("Config content not changed.");
			}
			if (logger.isDebugEnabled()) {
				logger.debug("Content=" + content);
			}
			return 1;
		}

		// 0成功,1配置未变化,2保存失败
		PizzaConfigHistoryDTO historyDto = new PizzaConfigHistoryDTO();
		historyDto.setProjectId(proId);
		historyDto.setPizzaGroup(group);
		historyDto.setPizzaKey(key);
		historyDto.setPizzaValue(content);
		historyDto.setValueMd5(valueMd5);
		historyDto.setPizzaGroupName(groupDTO.getGroupName());
		historyDto.setValueSize(content.length());
		if(Constants.LIB_GROUP.equals(group)||"zip".equals(group)){
			historyDto.setValueSize(configContentUtils.decodeContent(content).length);
		}
		
		if (operationType == null) {
			if (curConfig == null) {
				historyDto.setOperationType(ConfigHistoryOperationType.ADD);
			} else {
				historyDto.setOperationType(ConfigHistoryOperationType.UPDATE);
			}
		}else {
			historyDto.setOperationType(operationType);
		}
		UserPrincipal up = null;

		// 如果是ant打包请求ivy仓库，没有用户登录，做虚拟用户
		if (ConfigHistoryOperationType.IVY_ADD.equals(operationType)) {
			CacheData cd = new CacheData("IVY");
			cd.setIp("IVY-CLIENT-IP");
			up = new UserPrincipal("ivy-ticket-token", cd);
		} else if (ConfigHistoryOperationType.ROLLBACK.equals(operationType)) {
			CacheData cd = new CacheData("ROLLBACK");
			cd.setIp("127.0.0.1");
			up = new UserPrincipal("rollback-ticket-token", cd);
		} else if (ConfigHistoryOperationType.RECOVERY.equals(operationType)) {
			CacheData cd = new CacheData("RECOVERY");
			cd.setIp("127.0.0.1");
			up = new UserPrincipal("recovery-ticket-token", cd);
		} else {
			up = UserPrincipal.get(true);
		}
		up = user;
		historyDto.setOperationIp(up.getIp());
		historyDto.setOperationUser(up.getUid());
//		historyDto.setOperationType(operationType);
		if (logger.isDebugEnabled()) {
			logger.debug("history=" + JSONObject.toJSONString(historyDto));
		}

		if (curConfig == null) {
			if (logger.isInfoEnabled()) {
				logger.info("AddConfig for group=" + group + ",key=" + key);
			}
			try {
				if (!ConfigHistoryOperationType.RECOVERY.equals(operationType)) {
					if(ifUploadToZookeeper(proId)) {
						pizzaManagerHolder.getManager(proId).add(group, key, content);
					}else {
						logger.info("领域：" + proId + "在领域名单中。zip、lib不上传到ZK，只保存在DB。");
					}
					
				}
				// 增加记录记录历史记录表 并获取historyId 插入value表
				curConfig = new PizzaConfigPO();
				POUtils.copyProperties(curConfig, historyDto);
				// 如果操作类型为备份回滚，则查询文件的创建时间
				if (operationType.equals("5")) {
					List<PizzaConfigHistoryPO> list = historyConfigServices.search(proId, group, key,ConfigHistoryOperationType.ADD);
					if (list!=null&&list.size() > 0) {
						for (PizzaConfigHistoryPO po : list) {
							if (historyDto.getPizzaKey().equals(curConfig.getPizzaKey())) {
								curConfig.setCreatedDate(po.getCreatedDate());
								curConfig.setUpdatedDate(po.getUpdatedDate());
								curConfig.setCreatedBy(po.getCreatedBy());
								curConfig.setUpdatedBy(po.getUpdatedBy());
								curConfig.setProjectName(po.getProjectName());
								curConfig.setRequestId(po.getRequestId());
								historyDto.setProjectName(po.getProjectName());
								historyDto.setRecoveryDate(new Date());
								historyDto.setRecoveryUser(user.getName());
							}
						}
					}
				}
				historyConfigServices.save(historyDto);
				if (curConfig.getCreatedDate() == null) {
					curConfig.setCreatedDate(new Date());
				}
				if (curConfig.getUpdatedDate() == null) {
					curConfig.setUpdatedDate(new Date());
				}
				if (user != null && curConfig.getCreatedBy() == null) {
					curConfig.setUpdatedBy(user.getName());
					curConfig.setCreatedBy(user.getName());
				} else if (up != null && curConfig.getCreatedBy() == null) {
					curConfig.setUpdatedBy(up.getName());
					curConfig.setCreatedBy(up.getName());
				}
				pizzaConfigDAO.add(curConfig);
				PizzaConfigValuePO curConfigValue = new PizzaConfigValuePO();
				curConfigValue.setId(curConfig.getId());
				curConfigValue.setPizzaValue(historyDto.getPizzaValue());
				pizzaConfigValueDAO.save(curConfigValue);
			} catch (Exception ex) {
				logger.error("UpdateConfig failure,cause:" + ex.getMessage(), ex);
				return 2;
			}
		} else {
			if (logger.isInfoEnabled()) {
				logger.info("UpdateConfig for group=" + group + ",key=" + key);
			}
			try {
				if (!ConfigHistoryOperationType.RECOVERY.equals(operationType)) {
					if(ifUploadToZookeeper(proId)) {
						pizzaManagerHolder.getManager(proId).set(group, key, content);
					}else {
						logger.info("领域：" + proId + "在领域名单中。zip、lib不上传到ZK，只保存在DB。");
					}
				}
				// 增加记录记录
				historyConfigServices.save(historyDto);

				curConfig.setValueMd5(valueMd5);
				curConfig.setValueSize(content.length());
				//回滚会导致大小计算有误
				//TODO 
				if(Constants.LIB_GROUP.equals(group)||"zip".equals(group)){
					curConfig.setValueSize(configContentUtils.decodeContent(content).length);
				}
				
				// user为空报空指针 user为空 从up里面取id
				if (user != null) {
					POUtils.setForUpdate(user.getUid(), curConfig);
				} else {
					POUtils.setForUpdate(up.getUid(), curConfig);
				}
				pizzaConfigDAO.update(curConfig);
				PizzaConfigValuePO curConfigValue = new PizzaConfigValuePO();
				curConfigValue.setId(curConfig.getId());
				curConfigValue.setPizzaValue(content);
				pizzaConfigValueDAO.update(curConfigValue);
			} catch (Exception ex) {
				logger.error("UpdateConfig failure,cause:" + ex.getMessage(),ex);
				return 2;
			}
		}
		// 如果是lib资源组，同步到依赖包仓库配置
		if (Constants.LIB_GROUP.equals(group)) {
			saveIvylib(user, proId, group, key, content, operationType);
		}

		return 0;
	}

	/**
	 * 保存临时文件的二进制内容
	 * 
	 * @param bytes
	 * @return
	 */
	public String saveFileTemp(String bytes) {
		String uuid = UUID.randomUUID().toString();
		FileTempPO po = new FileTempPO();
		po.setUuid(uuid);
		po.setBytes(bytes);
		fileTempDAO.saveFileTemp(po);
		return uuid;
	}

	/**
	 * 根据ID获取临时文件内容
	 * 
	 * @param uuid
	 * @return
	 */
	public FileTempPO getFileTempById(String uuid) {
		return fileTempDAO.getFileTempById(uuid);
	}

	@Override
	public void delFileTempById(String uuid) {
		fileTempDAO.delFileTempById(uuid);
	}

	@Override
	public List<PizzaConfigPO> getPizzaKey(String pizzaGroup) {
		return pizzaConfigDAO.getPizzaKey(pizzaGroup);
	}

	@Override
	public List<PizzaConfigPO> getPizzaKey(String proId, String pizzaGroup) {
		return pizzaConfigDAO.getPizzaKey(proId, pizzaGroup);
	}

	@Override
	public List<String> listKeysByProId(String projectId, String group,
			String pizzaKeyRegex) {
		if (projectId == null || (projectId = projectId.trim()).length() == 0) {
			throw new NullPointerException("projectId is null.");
		}
		if (group == null || (group = group.trim()).length() == 0) {
			throw new NullPointerException("group is null.");
		}
		return pizzaConfigDAO.listKeysByProId(projectId, group, pizzaKeyRegex);
	}

}
