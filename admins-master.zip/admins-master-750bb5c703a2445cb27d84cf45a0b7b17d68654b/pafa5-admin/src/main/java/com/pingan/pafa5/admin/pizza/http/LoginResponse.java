package com.pingan.pafa5.admin.pizza.http;

public class LoginResponse extends HttpResponse {
	
	private String cookie;
	private String uname;
	
	
	public String getCookie() {
		return cookie;
	}
	public void setCookie(String cookie) {
		this.cookie = cookie;
	}
	public String getUname() {
		return uname;
	}
	public void setUname(String uname) {
		this.uname = uname;
	}
}
