package com.pingan.pafa5.admin.pizza.dto;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.paic.pafa.validator.annotation.VNotEmpty;

/**
 */
public class ResourceUploadDTO {

	@VNotEmpty
	private String sarName;
	@VNotEmpty
	private String projectId;
	private String projectName;
	
	private String resourceName;
	private long size;
	private String id;
	private String otype;//操作类型
	//上传文件
	private CommonsMultipartFile fileUpload;
	
	public CommonsMultipartFile getFileUpload() {
		return fileUpload;
	}

	public void setFileUpload(CommonsMultipartFile fileUpload) {
		this.fileUpload = fileUpload;
	}

	public String getSarName() {
		return sarName;
	}

	public void setSarName(String sarName) {
		this.sarName = sarName;
	}

	public String getResourceName() {
		return resourceName;
	}

	public void setResourceName(String resourceName) {
		this.resourceName = resourceName;
	}

	public long getSize() {
		return size;
	}

	public void setSize(long size) {
		this.size = size;
	}

	public String getOtype() {
		return otype;
	}

	public void setOtype(String otype) {
		this.otype = otype;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}
	
}
