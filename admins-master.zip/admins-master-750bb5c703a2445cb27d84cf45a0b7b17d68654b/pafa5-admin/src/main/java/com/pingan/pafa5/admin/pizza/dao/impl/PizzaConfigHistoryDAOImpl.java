package com.pingan.pafa5.admin.pizza.dao.impl;

import java.util.Date;
import java.util.List;
import java.util.regex.Pattern;

import org.bson.types.ObjectId;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa.mongodb.MongoPagination;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dao.PizzaConfigHistoryDAO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSearchDTO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigHistoryPO;

@Nosql
@Repository
public class PizzaConfigHistoryDAOImpl extends  BaseMongoDAO<PizzaConfigHistoryPO> implements PizzaConfigHistoryDAO{

	@Override
	public void add(PizzaConfigHistoryPO historyDTO) {
		this._add(historyDTO);
	}

	@Override
	public PageDataDTO<PizzaConfigHistoryPO> pageQuery(ConfigSearchDTO queryVO) {
		MongoPagination<PizzaConfigHistoryPO> page=new MongoPagination<PizzaConfigHistoryPO>(queryVO.getPage(),queryVO.getLimit());
		
		String proId = queryVO.getProjectId();
		Criteria where = null;
		if (proId == null ) {
			where=where("pizzaGroup").is(queryVO.getGroup()).and("projectId").is(null);
		} else {
			if(queryVO.getGroup().length()!=0){
				where = where("projectId").is(proId).and("pizzaGroup").is(queryVO.getGroup());
			}
			else
				where = where("projectId").is(proId);
		}
		String likeKey=queryVO.getLikeKey();
		if(likeKey!=null && (likeKey=likeKey.trim()).length()>0){
		    where.and("pizzaKey").regex(Pattern.compile("^.*" + likeKey + ".*$", Pattern.CASE_INSENSITIVE));
		}
		page.setDesc(true);
		page.setOrderBy(new String[]{"createdDate"});
		page.setTotalSize(-1);
		Query query=new Query(where);
		query.fields().exclude("pizzaValue");
		this._paginatedQuery(query, page);
		PageDataDTO<PizzaConfigHistoryPO> result=new PageDataDTO<PizzaConfigHistoryPO>();
		result.setDatas(page.getPojos());
		result.setTotalSize(page.getTotalSize());
		return result;
	}

	@Override
	public PizzaConfigHistoryPO getById(String historyId) {
		return this._getById(historyId);
	}

	@Override
	public PizzaConfigHistoryPO get(String group, String key, long createDate) {
		Criteria where=this.where("pizzaGroup").is(group).and("pizzaKey").is(key).and("createdDate").is(new Date(createDate));
		List<PizzaConfigHistoryPO> list=this._list(where);
		if(list!=null&& list.size()>0){
			return list.get(list.size()-1);
		}
		return null;
	}

	/** 记录被恢复的操作人以及操作时间
	 * 
	 * @param historyId
	 * @param recovery
	 * @param recoveryUser
	 * @return
	 */
	public boolean record(String historyId, String recovery,String recoveryUser) {
		Update update = new Update();
		update.set("recovery", recovery);
		update.set("recoveryDate", new Date());
		update.set("recoveryUser", recoveryUser);
		boolean result = this._update(where("historyId").is(historyId), update);
		return result;
	}
	
	@Override
	public List<PizzaConfigHistoryPO> search(String proId, String group,
		String pizzakey, String opterationType) {
		Criteria where=this.where("pizzaGroup").is(group).and("pizzaKey").is(pizzakey).and("operationType").is(opterationType);
		List<PizzaConfigHistoryPO> list=this._list(where);
		if(list!=null&& list.size()>0){
			return list;
		}
		return null;
	}
	
	@Override
	public long getRecordNum(Date cleanBeforeThisTime, String projectId) {
		Criteria where;
		if(projectId!=null&&projectId.length()>0)
			 where=this.where("updatedDate").lt(cleanBeforeThisTime).and("projectId").is(projectId);
		else
			where=this.where("updatedDate").lt(cleanBeforeThisTime);
		return this._count(where);
	}
	
	@Override
	public List<PizzaConfigHistoryPO> cleanUpRecord(Date cleanBeforeThisTime, String projectId/*, int recordNum*/) {
		Criteria where;
		if(projectId!=null&&projectId.length()>0)
			 where=this.where("updatedDate").lt(cleanBeforeThisTime).and("projectId").is(projectId);
		else
			where=this.where("updatedDate").lt(cleanBeforeThisTime);
		/*Query query=new Query(where);
		query.limit(recordNum);*/
		List<PizzaConfigHistoryPO> list = this._list(where);
		return list;
	}

	@Override
	public void deleteHistoryPo(String id) {
		this._removeById(new ObjectId(id));
	}
	
	
	
}
