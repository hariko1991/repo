package com.pingan.pafa5.admin.pizza.dao;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dto.IvyLibSearchDTO;
import com.pingan.pafa5.admin.pizza.po.IvyLibConfigPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigPO;

/**
 * @see Ivy配置数据访问层接口
 * @author JIECHANGKE805
 * @since 2016-05-23
 */

public interface IvyLibConfigDAO {

	public abstract void add(IvyLibConfigPO ivyConfigPO);

	public abstract IvyLibConfigPO find(String group, String key);

	public abstract boolean update(IvyLibConfigPO po);

	PageDataDTO<IvyLibConfigPO> pageQuery(IvyLibSearchDTO queryDTO);

	public boolean del(String proId, String group, String key);

	public boolean del(String group, String key);

	IvyLibConfigPO find(String proId, String group, String key);
//	要加md5比对方法
//	boolean isMD5Exist(String projectId, String md5);
	
	
}
