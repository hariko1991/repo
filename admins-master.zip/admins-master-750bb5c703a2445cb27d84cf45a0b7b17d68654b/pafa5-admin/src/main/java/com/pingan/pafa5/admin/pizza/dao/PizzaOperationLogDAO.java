package com.pingan.pafa5.admin.pizza.dao;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dto.OperationLogSearchDTO;
import com.pingan.pafa5.admin.pizza.po.PizzaOperationLogPO;

public interface PizzaOperationLogDAO {

	PizzaOperationLogPO getById(String id);

	void completed(String operationId);

	/**
	 * 更新操作日志状态及信息, 主要用于解决异步执行的状态更新, 以及执行结果,错误信息等
	 * 
	 * @param logDto
	 */
	void updateStatus(PizzaOperationLogPO logDto);

	String add(PizzaOperationLogPO logDTO);

	PageDataDTO<PizzaOperationLogPO> pageQuery(OperationLogSearchDTO queryDTO);
}
