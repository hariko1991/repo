package com.pingan.pafa5.admin.papp.dto;

import com.paic.pafa.validator.annotation.VNotEmpty;

public class AddSarForm {
	
	@VNotEmpty
	private String sarId;
	
	@VNotEmpty
	private String sarName;
	
	@VNotEmpty
	private String pappName;
	
	@VNotEmpty
	private String systemsName;

	public String getSarId() {
		return sarId;
	}

	public void setSarId(String sarId) {
		this.sarId = sarId;
	}

	public String getSarName() {
		return sarName;
	}

	public void setSarName(String sarName) {
		this.sarName = sarName;
	}

	public String getPappName() {
		return pappName;
	}

	public void setPappName(String pappName) {
		this.pappName = pappName;
	}

	public String getSystemsName() {
		return systemsName;
	}

	public void setSystemsName(String systemsName) {
		this.systemsName = systemsName;
	}
	
	

}
