package com.pingan.pafa5.admin.papp.services;

import java.util.List;

import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSaveDTO;
import com.pingan.pafa5.admin.pizza.dto.ConfigSearchDTO;
import com.pingan.pafa5.admin.pizza.form.PizzaConfigForm;
import com.pingan.pafa5.admin.pizza.po.FileTempPO;
import com.pingan.pafa5.admin.pizza.po.PizzaConfigPO;
import com.pingan.pafa5.admin.sso.UserPrincipal;

public interface GardenPizzaConfigServices {
    
   

    List<String> listKeys(String domainId, String group);

    

    List<String> listKeys(String proId, String group, String pizzaKeyRegex);

    

    

    
}
