package com.pingan.pafa5.admin.abtest.web;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa5.admin.abtest.form.PolicyDataForm;
import com.pingan.pafa5.admin.abtest.form.PolicyForm;
import com.pingan.pafa5.admin.abtest.services.ABTestingAdminDemoService;

/**
 * 灰度发布演示控制器
 * @author WANGJUN791
 *
 */
@Controller
@RequestMapping("/abtest")
public class ABTestingDemoController {

	private static Log logger = LogFactory.getLog(ABTestingDemoController.class);
	
	@Autowired
	private ABTestingAdminDemoService abTestingDemoService;

	@RequestMapping("/policyData-list.do")
	@ResponseBody
	public ResponseModel listPolicyData(String policy) {
		
		if (logger.isInfoEnabled()){
			logger.info("list policy data,policy=" + policy);
		}
		
		ResponseModel model = new ResponseModel();
		String key = "ab:test:policy:" + policy + ":divdata";
		List<String> data = abTestingDemoService.listPolicyData(key);
		
		List<PolicyDataForm> policyData = new ArrayList<PolicyDataForm>();
		if (data != null && data.size() > 0) {
			for (String ip : data) {
				PolicyDataForm form = new PolicyDataForm();
				form.setIpString(ip);
				policyData.add(form);
			}
		}
		
		model.put("datas", policyData);
		model.put("size", policyData.size());
		
		return model;
	}
	
	@RequestMapping("/policy-list.do")
	@ResponseBody
	public ResponseModel listPolicy() {
		
		ResponseModel model = new ResponseModel();
		String key = "ab:test:policy:divtype";
		Map<String, String> policyMap = abTestingDemoService.listPolicy(key);
		
		List<PolicyForm> policyList = new ArrayList<PolicyForm>();
		Set<Entry<String, String>> entrySet = policyMap.entrySet();
		Iterator<Entry<String, String>> it = entrySet.iterator();
		while (it.hasNext()) {
			Entry<String, String> entry = it.next();
			String jsonStr = entry.getValue();
			
			if (!StringUtils.isEmpty(jsonStr)) {
				PolicyForm entity = new PolicyForm();
				
				JSONObject jsonObj = JSONObject.parseObject(jsonStr);
				entity.setPolicy(entry.getKey());
				entity.setName(jsonObj.getString("name"));
				entity.setDesc(jsonObj.getString("desc"));
				
				policyList.add(entity);
			}
		}
		
		model.put("datas", policyList);
		model.put("size", policyList.size());
		
		return model;
	}
	
	@RequestMapping("/policy-add.do")
	@ResponseBody
	public ResponseModel addPolicy(PolicyForm policy) {
		
		if (logger.isInfoEnabled()){
			logger.info("add policy,items=" + JSON.toJSONString(policy));
		}
		
		ResponseModel model = new ResponseModel();
		String key = "ab:test:policy:divtype";
		
		JSONObject jsonObj = new JSONObject();
		jsonObj.put("name", policy.getName());
		jsonObj.put("desc", policy.getDesc());
		
		Map<String, String> policyMap = new HashMap<String, String>();
		policyMap.put(policy.getPolicy(), jsonObj.toJSONString());
		
		String result = abTestingDemoService.addPolicy(key, policyMap);
		
		if (StringUtils.isBlank(result)) {
			model.setResponseCode("1");
			model.setResponseMsg("新增策略失败！");
			return model;
		}
		
		model.put("success", Boolean.TRUE);
		model.setResponseMsg("新增成功！");
		return model;
	}
	
	@RequestMapping("/policyData-add.do")
	@ResponseBody
	public ResponseModel addPolicyData(PolicyDataForm policyData) {
		
		if (logger.isInfoEnabled()){
			logger.info("add policy data,item=" + JSON.toJSONString(policyData));
		}
		
		String key = "ab:test:policy:" + policyData.getPolicy() + ":divdata";
		ResponseModel model = new ResponseModel();
		long addNum = abTestingDemoService.addPolicyData(key, policyData.getIpString());
		if (addNum > 0) {
			model.put("success", Boolean.TRUE);
			model.setResponseMsg("新增成功！");
		} else {
			model.setResponseCode("1");
			model.setResponseMsg("新增失败！");
		}
		
		return model;
	}
	
	@RequestMapping("/policy-apply.do")
	@ResponseBody
	public ResponseModel applyPolicy(PolicyForm policy) {
		
		if (logger.isInfoEnabled()){
			logger.info("apply policy,item=" + JSON.toJSONString(policy));
		}
		
		String key = "ab:test:policy:apply:divtype";
		ResponseModel model = new ResponseModel();
		String result = abTestingDemoService.applyPolicy(key, policy.getPolicy());
		if (!StringUtils.isEmpty(result)) {
			model.put("success", Boolean.TRUE);
			model.setResponseMsg("操作成功！");
		} else {
			model.setResponseCode("1");
			model.setResponseMsg("操作失败！");
		}
		
		return model;
	}
	
	@RequestMapping("/policyData-edit.do")
	@ResponseBody
	public ResponseModel editPolicyData(PolicyDataForm policyData) {
		
		if (logger.isInfoEnabled()){
			logger.info("edit policy data,item=" + JSON.toJSONString(policyData));
		}
		
		String key = "ab:test:policy:" + policyData.getPolicy() + ":divdata";
		ResponseModel model = new ResponseModel();
		long editNum = abTestingDemoService.editPolicyData(key, policyData.getIpString(), policyData.getOldIp());
		if (editNum > 0) {
			model.put("success", Boolean.TRUE);
			model.setResponseMsg("修改成功！");
		} else {
			model.setResponseCode("1");
			model.setResponseMsg("修改失败！");
		}
		
		return model;
	}
	
	@RequestMapping("/policyData-del.do")
	@ResponseBody
	public ResponseModel delPolicyData(PolicyDataForm policyData) {
		
		if (logger.isInfoEnabled()){
			logger.info("delete policy data,item=" + JSON.toJSONString(policyData));
		}
		
		String key = "ab:test:policy:" + policyData.getPolicy() + ":divdata";
		ResponseModel model = new ResponseModel();
		long delNum = abTestingDemoService.delPolicyData(key, policyData.getIpString());
		if (delNum > 0) {
			model.put("success", Boolean.TRUE);
			model.setResponseMsg("删除成功！");
		} else {
			model.setResponseCode("1");
			model.setResponseMsg("删除失败！");
		}
		
		return model;
	}
}