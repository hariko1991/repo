package com.pingan.pafa5.admin.fling.dao;

import com.pingan.pafa5.admin.fling.po.FlingSARMonitorMsgPO;

public interface FlingSARMonitorMsgDAO {

    void add(FlingSARMonitorMsgPO po);
    
    FlingSARMonitorMsgPO getLast(String pappName,String sarName, String instanceIp);
}
