package com.pingan.pafa5.admin.fling.dao;

import java.util.List;

import com.pingan.pafa5.admin.fling.po.FlingSARInstancePO;

public interface FlingSARInstanceDAO {
	void updateStatus(FlingSARInstancePO po);
		
    void upset(FlingSARInstancePO po);

    List<FlingSARInstancePO> list(String sarName, String pappName);

    List<FlingSARInstancePO> list(String projectId, String pappName, String sarName);

    List<FlingSARInstancePO> listAll();

    List<FlingSARInstancePO> list(String projectId, String sarName, String pappName, int limit,
            int page);
    List<FlingSARInstancePO> list(String instanceIp, String projectId, String sarName, String pappName, int limit,
            int page);
    
    List<FlingSARInstancePO> list(String instanceIp , String projectId, String sarName, String pappName);

    long getSarCount(String projectId, String sarName, String pappName);

    FlingSARInstancePO getFlingSarInstancePO(String sarName, String instanceIp);

    boolean delete(String projectId, String sarName, String instanceIp,String pappName);
    
    List<FlingSARInstancePO> list(String instanceIp,int limit, int page);
    
    long getSarCount(String instanceIp);
    
    List<FlingSARInstancePO> list(int status,int limit, int page);
    long getSarCount(int  status);
    
    List<FlingSARInstancePO> list(int status);

	

	boolean checkSarExistenceByName(String sarName);

	
	
	List<FlingSARInstancePO> listSarSearchResult(String projectId,
			String searchField);

}
