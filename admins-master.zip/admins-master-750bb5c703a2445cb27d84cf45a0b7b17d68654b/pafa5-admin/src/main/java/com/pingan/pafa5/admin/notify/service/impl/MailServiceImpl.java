package com.pingan.pafa5.admin.notify.service.impl;

import javax.mail.MessagingException;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.task.TaskExecutor;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;
import org.springframework.web.servlet.view.freemarker.FreeMarkerConfigurer;

import com.pingan.pafa5.admin.notify.dto.Mail;
import com.pingan.pafa5.admin.notify.service.MailService;

import freemarker.template.Template;

@Service
public class MailServiceImpl implements MailService {

    private static final Log log = LogFactory.getLog(MailServiceImpl.class);

    @Autowired
    private JavaMailSender javaMailSender;

    @Autowired
    private FreeMarkerConfigurer freeMarkerConfigurer;

    @Autowired
    private TaskExecutor taskExecutor;

    @Value("${pafa5.base.url}")
    private String baseUrl;

    @Value("${mail.user}")
    private String mailUser;

    @Value("${mail.enabled}")
    private boolean mailEnabled = false;

    @Override
    public Mail createMail(String templateName, String subject) throws MessagingException {
        Mail mail = new Mail(javaMailSender.createMimeMessage());
        mail.setFrom(mailUser);
        mail.setTemplateName(templateName);
        mail.setSubject(subject);
        return mail;
    }

    @Override
    public void sendMail(Mail mail) {
        processText(mail);
        taskExecutor.execute(new SendMailThread(mail));
    }

    private void processText(Mail mail) {
        log.info("processText start...");
        try {
            Template template =
                    freeMarkerConfigurer.getConfiguration().getTemplate(mail.getTemplateName());

            String text =
                    FreeMarkerTemplateUtils.processTemplateIntoString(template, mail.getContext());
            // 设置为true表示html模板
            mail.setText(addStyle(text), true);

        } catch (Exception e) {
            log.error("Email content generate error,caused by:" + e);
        }
    }

    private String addStyle(String mailContent) {

        String footer =
                String.format(
                        "<br /><hr /><span class='font-sm' style='font-size: 14px;'>本邮件由<a href=\"%s\">Pafa5管控平台</a>自动发送，请不要直接回复。 </span>",
                        baseUrl);

        mailContent =
                mailContent
                        .replace(
                                "%SystemLinkPlaceHolder%",
                                String.format(
                                        "<span class='font-sm' style='font-size: 16px;'><a href=\"%s\">Pafa5管控平台</a></span>",
                                        baseUrl));

        return "\n<body style=\"font-size: 16px;font-family:'Microsoft YaHei';\">\n" + mailContent
                + "\n" + footer + "\n</body>\n";
    }


    private void doSend(Mail mail) {
        log.info("doSend mail : " + mail.getTemplateName());
        if (mailEnabled) {
            javaMailSender.send(mail.getMimeMessage());
        } else {
            log.debug("Mail ignored because 'mail.enabled' = false");
        }
    }

    class SendMailThread implements Runnable {

        private Mail mail;

        private SendMailThread(Mail mail) {
            super();
            this.mail = mail;
        }

        @Override
        public void run() {
            doSend(mail);
        }

    }

}
