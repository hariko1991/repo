package com.pingan.pafa5.admin.pizza.web;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.apache.commons.io.FileUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;

@Controller
@RequestMapping("/f5monweb")
public class SystemCheck extends BaseController {

	@RequestMapping("/f5check.do")
    @ResponseBody
    public ResponseModel f5check(HttpServletRequest request) {
		ResponseModel model = new ResponseModel("0","成功");
		String rootPath = System.getProperty("pafa.log.home", "");
        try {
        	File file = new File(rootPath,"f5check_"+new SimpleDateFormat("yyyy-MM-dd").format(new Date())+".log");
    		if(!file.exists()){
    			file.createNewFile();
    		}
    		FileUtils.writeStringToFile(file, "OK", "UTF-8", false);
    		model.put("fileWriteStatus", "OK");
    		String content = FileUtils.readFileToString(file, "UTF-8");
    		model.put("fileReadStatus", content);
		} catch (Exception e) {
			model.put("responseCode", "-101010");
			model.put("responseMsg", "磁盘回写失败");
		}
		return model;
    }
}
