package com.pingan.pafa5.admin.fling.job;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paic.pafa.job.TimerJob;
import com.pingan.pafa5.admin.fling.services.FlingCommandServices;

/**
 * 运维中心-管控指令数据清理
 * @author ZHANGJIAWEI370
 * 
 */
@Component
public final class FlingCommandCleanJob {

	private Log logger = LogFactory.getLog(this.getClass());
	
	@Autowired
	private FlingCommandServices flingCommandServices;
	
	@TimerJob(cronExpression="${job.ex.fling.command.clean.time}")
	public void execute() throws Exception{
		logger.info("开始清理管控指令数据★★★★★★★★★★★★★★★★★★★★★★★★★★★");
		
		flingCommandServices.delete15DaysBefore();
		
		logger.info("结束清理管控指令数据★★★★★★★★★★★★★★★★★★★★★★★★★★★");
	}

	public void setFlingCommandServices(FlingCommandServices flingCommandServices) {
		this.flingCommandServices = flingCommandServices;
	}
	
}
