package com.pingan.pafa5.admin.monitor.dao;

import com.pingan.pafa5.admin.monitor.dtos.InterfaceDTO;

import java.util.List;

/**
 * Created by ZHANGWENZHUO810 on 2016-11-14.
 */
public interface InterfaceDAO {
    void add(InterfaceDTO interfaceDTO);

    InterfaceDTO getByProperty(String value1, String value2);

    List<InterfaceDTO> findAll();

    int removeByProperty(String name, String value);
}
