package com.pingan.pafa5.admin.papp.web;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.pizza.PizzaConstants;
import com.pingan.pafa5.admin.commons.SqlUtils;
import com.pingan.pafa5.admin.papp.dto.PappDTO;

@Controller
public class PappQueryController {

	@ActionClient(name = "pafa5-admin-pizza.listKeys")
	private IServiceClient pizzaListKeysService;

	@ActionClient(name = "pafa5-admin-pizza.listKeysByProId")
	private IServiceClient listPappsService;

	private static final String APP_NAME_PATTERN_STRING = "^[\\w\\-]+$";

	private static final Pattern APP_NAME_PATTERN = Pattern.compile(APP_NAME_PATTERN_STRING);

	@RequestMapping("/papp/listNames.do")
	@ResponseBody
	public ResponseModel listKeys(@RequestParam(value = "pappName", required = false) String pappName,
			@RequestParam(value = "projectId", required = false) String projectId) throws Throwable {
		ServiceParams params = ServiceParams.newInstance();
		params.set("projectId", projectId);
		params.set("group", PizzaConstants.GROUP_PAPP);

		if (pappName != null && !APP_NAME_PATTERN.matcher(pappName).matches()) {
			return new ResponseModel("1", "pappName:" + pappName + " not matched by pattern:" + APP_NAME_PATTERN_STRING);
		}
		if (pappName == null) {
			pappName = "";
		}

		if (SqlUtils.SPRING_PROFILE_NOSQL.equalsIgnoreCase(SqlUtils.getSpringProfilesActive())) {
			String parttern = "^" + pappName + "[\\w\\-]*\\.properties$";
			params.set("keyRegex", parttern);
		} else {
			String parttern = pappName + "%.properties";
			params.set("keyRegex", parttern);
		}

		ServiceResults result = pizzaListKeysService.invoke(params);
		// -----------------------------------
		String responseCode = result.getString("responseCode");
		List<PappDTO> datas = new ArrayList<PappDTO>();
		if ("0".equals(responseCode) || "success".equals(responseCode)) {
			int keySize = result.getInt("keySize");
			ResponseModel model = new ResponseModel("0");
			model.put("size", keySize);
			int len = ".properties".length();
			if (keySize > 0) {
				List<String> keys = (List<String>) result.get("keys");
				for (String key : keys) {
					String name = key.substring(0, key.length() - len);
					PappDTO dto = new PappDTO();
					dto.setId(name);
					dto.setPappName(name);
					datas.add(dto);
				}
			}
			model.put("pappNames", datas);
			return model;
		} else {
			return new ResponseModel(responseCode, result.getString("responseMsg"));
		}
	}

	/**
	 * 根据项目ID获取项目下的所有应用
	 * 
	 * @param projectId
	 * @return
	 * @throws Throwable
	 */
	@RequestMapping("/papp/listPappsByProId.do")
	@ResponseBody
	public ResponseModel listPappsByProId(@RequestParam(value = "projectId", required = true) String projectId,
			@RequestParam(value = "pappName", required = false) String pappName) throws Throwable {
		ServiceParams params = ServiceParams.newInstance().set("group", PizzaConstants.GROUP_PAPP);
		if (pappName != null && !APP_NAME_PATTERN.matcher(pappName).matches()) {
			return new ResponseModel("1", "pappName:" + pappName + " not matched by pattern:" + APP_NAME_PATTERN_STRING);
		}
		if (pappName == null) {
			pappName = "";
		}
		if (SqlUtils.SPRING_PROFILE_NOSQL.equalsIgnoreCase(SqlUtils.getSpringProfilesActive())) {
			String parttern = "^" + pappName + "[\\w\\-]*\\.properties$";
			params.set("keyRegex", parttern);
		} else {
			String parttern = pappName + "%.properties";
			params.set("keyRegex", parttern);
		}

		params.set("projectId", projectId);
		ServiceResults result = listPappsService.invoke(params);
		// -----------------------------------
		String responseCode = result.getString("responseCode");
		if ("0".equals(responseCode)) {
			int keySize = result.getInt("keySize");
			ResponseModel model = new ResponseModel("0");
			model.put("size", keySize);
			int len = ".properties".length();
			if (keySize > 0) {
				List<PappDTO> datas = new ArrayList<PappDTO>();
				List<String> keys = (List<String>) result.get("keys");
				for (String key : keys) {
					String name = key.substring(0, key.length() - len);
					PappDTO dto = new PappDTO();
					dto.setId(name);
					dto.setPappName(name);
					datas.add(dto);
				}
				model.put("pappNames", datas);
			}
			return model;
		} else {
			return new ResponseModel(responseCode, result.getString("responseMsg"));
		}
	}

	public IServiceClient getPizzaListKeysService() {
		return pizzaListKeysService;
	}

	public void setPizzaListKeysService(IServiceClient pizzaListKeysService) {
		this.pizzaListKeysService = pizzaListKeysService;
	}

}
