package com.pingan.pafa5.admin.pizza.dao;

import com.pingan.pafa5.admin.pizza.po.FileTempPO;

public interface FileTempDAO {

	/**
	 * 保存临时文件内容
	 * 
	 * @param uuid
	 * @param bytes
	 * @return
	 */
	public abstract void saveFileTemp(FileTempPO po);

	/**
	 * 根据ID找到临时文件
	 * 
	 * @param uuid
	 * @return
	 */
	public abstract FileTempPO getFileTempById(String uuid);

	public abstract void delFileTempById(String uuid);

}