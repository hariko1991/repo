package com.pingan.pafa5.admin.pizza.web;

public class LogCleaner {

}
