package com.pingan.pafa5.admin.pizza.form;

import com.paic.pafa.validator.annotation.VNotEmpty;

public class PizzaInstanceForm {
	private String group;
	private String content;
	@VNotEmpty
	private String projectId;
	private String optype;
	@VNotEmpty
	private String instanceIp;

	public String getGroup() {
		return group;
	}

	public void setGroup(String group) {
		this.group = group;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getOptype() {
		return optype;
	}

	public void setOptype(String optype) {
		this.optype = optype;
	}

	public String getInstanceIp() {
		return instanceIp;
	}

	public void setInstanceIp(String instanceIp) {
		this.instanceIp = instanceIp;
	}

}
