package com.pingan.pafa5.admin.pizza.dao.impl;

import java.util.List;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Service;

import com.alibaba.dubbo.common.utils.StringUtils;
import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.pizza.dao.PizzaRecoveryRegisterLogDAO;
import com.pingan.pafa5.admin.pizza.po.PizzaRecoveryRegisterLogPo;

@Service
public class PizzaRecoveryRegisterLogDAOImpl extends BaseMongoDAO<PizzaRecoveryRegisterLogPo> implements PizzaRecoveryRegisterLogDAO {

	@Override
	public void saveErrorLog(PizzaRecoveryRegisterLogPo recoveryRegisterLogPo) {
		this._save(recoveryRegisterLogPo);
	}

	@Override
	public void deleteErrorLog(String projectId) {
		this._remove(Criteria.where("projectId").is(projectId));
	}

	@Override
	public List<PizzaRecoveryRegisterLogPo> getErrorLogs(String logId, String projectId) {
		Criteria criteria = Criteria.where("logId").is(logId);
		if(StringUtils.isNotEmpty(projectId)) {
			criteria = criteria.and("projectId").is(projectId);
		}
		return this._list(criteria);
	}

}
