package com.pingan.pafa5.admin.filter;

import java.io.IOException;
import java.util.Set;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.StringUtils;

import com.pingan.pafa.common.utils.Pafa5ConfigUtils;
import com.pingan.pafa.papp.PApp;
import com.pingan.pafa.papp.context.config.PAppConstants;
import com.pingan.pafa.papp.protocol.web.PappServletFilter;
import com.pingan.pafa.pizza.Pizza;

public class AdminWebFilter extends PappServletFilter {
	protected Log logger=LogFactory.getLog(this.getClass());
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private PApp papp;
	
	private String[] resourcesSuffix;
	

	@Override
	public void destroy() {
		papp.shutdown();
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse resp, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest processedRequest = (HttpServletRequest)request;
		HttpServletResponse  response=(HttpServletResponse)resp;
		String uri=processedRequest.getRequestURI().toLowerCase();
		//logger.info("uri="+uri);
		
		if(uri.endsWith(".do")||uri.endsWith(".xml")||uri.endsWith(".jar")){
			boolean isResource=false;
			if(resourcesSuffix!=null && resourcesSuffix.length>0){
				for(int i=0;i<resourcesSuffix.length;i++){
					if(uri.endsWith(resourcesSuffix[i])){
						isResource=true;
						break;
					}
				}
			}
			if(isResource){
				chain.doFilter(request,resp);
			}else{
				papp.handleWebRequest(processedRequest, response);
			}
		}else{
			if("/".equals(uri)||"/admin".equals(uri)||"/admin/".equals(uri)){
				if(StringUtils.isEmpty(processedRequest.getContextPath())){
					response.sendRedirect(processedRequest.getScheme()	+ "://" + processedRequest.getServerName()+ ":" + processedRequest.getServerPort() +"/login.html");
				}else{
					response.sendRedirect(processedRequest.getScheme()	+ "://" + processedRequest.getServerName()+ ":" + processedRequest.getServerPort() + processedRequest.getContextPath() +"/login.html");
				}
			}else{
				chain.doFilter(processedRequest, response);
			}
		}
	}

	@Override
	public void init(FilterConfig config) throws ServletException {
		String param=(config==null?null:config.getInitParameter("PizzaConfigFile"));
		String file=null;
		if(param!=null && (param=param.trim()).length()>0){
			file=param;
		}
		try{
			if(file!=null){
				System.out.println("PappServletFilter：\n\t"+Pizza.KEY_CONFIG_FILE+"="+file);
				System.setProperty(Pizza.KEY_CONFIG_FILE, file);
			}
			/*try {
				URL url=config.getServletContext().getResource("/WEB-INF/papp-lib");
				File libDir=new File(url.toURI());
				if(libDir.exists()){
					System.setProperty(PAppConstants.KEY_LIB_DIR, libDir.getAbsolutePath());
				}
			} catch (Exception e) {
				throw new ServletException(e.getMessage(),e);
			}*/
			papp=PApp.getInstance();
			papp.setServletContext(config.getServletContext());
			papp.startup();
			//----------------------------------------------------
			String resourcesSuffix=(config==null?null:config.getInitParameter("resourcesSuffix"));
			if(resourcesSuffix==null || resourcesSuffix.length()==0){
				resourcesSuffix=papp.getConfigProperties().getProperty(PAppConstants.KEY_RESOURCES_SUFFIX);
			}
			if(resourcesSuffix!=null && resourcesSuffix.length()>0){
				Set<String> set=Pafa5ConfigUtils.split(resourcesSuffix);
				this.resourcesSuffix=new String[set.size()];
				set.toArray(this.resourcesSuffix);
			}
			//
		}finally{
			if(file!=null){
				System.clearProperty(Pizza.KEY_CONFIG_FILE);
			}
		}
	}

}
