package com.pingan.pafa5.admin.fling.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.fling.dao.FlingPappMonitorMsgDAO;
import com.pingan.pafa5.admin.fling.po.FlingPappMonitorMsgPO;

@Nosql
@Repository
public class FlingPappMonitorMsgDAOImpl extends BaseMongoDAO<FlingPappMonitorMsgPO> implements
        FlingPappMonitorMsgDAO {

    @Override
    public void add(FlingPappMonitorMsgPO po) {
        this._add(po);
    }

    @Override
    public FlingPappMonitorMsgPO getLast(String pappName, String instanceIp) {
        List<FlingPappMonitorMsgPO> datas =
                this._listAndDesc(
                        this.where("appName").is(pappName).and("instanceIp").is(instanceIp), 0, 1,
                        "createdTimestamp");
        if (datas == null || datas.size() == 0) {
            return null;
        }
        return datas.get(0);
    }

}
