package com.pingan.pafa5.admin.logging.dao.impl;

import java.util.List;
import java.util.UUID;
import java.util.regex.Pattern;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.logging.dao.LogMonitorDAO;
import com.pingan.pafa5.admin.logging.po.LogMonitorPO;
import com.pingan.pafa5.admin.sso.UserPrincipal;
@Nosql
@Repository
public class LogMonitorDAOImpl extends  BaseMongoDAO<LogMonitorPO> implements LogMonitorDAO{

	@Override
	public void add(LogMonitorPO po) {
		String id = UUID.randomUUID().toString();
		po.setId(id);
		this._add(po);
	}
	
	@Override
	public boolean isLooking(String projectId, String pappName, int expiredTime, int status) {
		Criteria criteria = where("projectId").is(projectId).and("targetPapp").is(pappName);
		criteria.and("expiredTime").is(expiredTime).and("status").is(status);
		long count = this._count(criteria);
		return count > 0 ? true : false;
	}
	
	@Override
	public boolean update(LogMonitorPO po) {
		Update update = new Update();
		update.set("log4j", po.getLog4j());
		update.set("status", po.getStatus());
		update.set("updatedBy", po.getUpdatedBy());
		update.set("updatedDate", po.getUpdatedDate());
		//return this._update(where("id").is(po.getId()), update);
		return this._updateById(po);
	}
	
	@Override
	public boolean isUsed(String queueName) {
		//找出所有正在查看的
		String userid = UserPrincipal.peekUserId().toLowerCase();
		String max = UserPrincipal.peekUserId().toUpperCase();
		Criteria criteria = where("queueName").is(queueName).and("createdBy").in(userid, max);
		long count = this._count(criteria);
		return count > 0 ? true : false;
	}
	
	@Override
	public boolean isLock(String projectId, String targetPapp) {
		//找出所有正在查看的
		Criteria criteria = where("projectId").is(projectId).and("targetPapp").is(targetPapp).and("status").is(0);
		long count = this._count(criteria);
		return count > 0 ? true : false;
	}
	
	@Override
	public List<LogMonitorPO> getUseList() {
		//找出所有正在查看的
		Criteria criteria = where("status").is(0);
		return this._list(criteria);
	}
	
	@Override
	public LogMonitorPO getById(String id) {
		return this._getById(id);
	}
	
	@Override
	public boolean delete(String id) {
		return this._removeById(id);
	}

	@Override
	public List<LogMonitorPO> list(String projectId, String pappName, int limit, int page) {
		Criteria criteria = Criteria.where("projectId").is(projectId);
		if (pappName != null && !"".equals(pappName.trim())) {
			criteria = criteria.and("targetPapp").regex(Pattern.compile("^.*" + pappName + ".*$", Pattern.CASE_INSENSITIVE));
		}
		int skip = (page - 1) * limit;
		return this._listAndDesc(criteria, skip, limit, "createdDate");
	}
	
	@Override
	public long getTotal(String projectId, String pappName){
		Criteria criteria = Criteria.where("projectId").is(projectId);
		if (pappName != null && !"".equals(pappName.trim())) {
			criteria = criteria.and("targetPapp").regex(Pattern.compile("^.*" + pappName + ".*$", Pattern.CASE_INSENSITIVE));
		}
		return this._count(criteria);
	}
}
