package com.pingan.pafa5.admin.commons;

import java.util.Properties;

import org.springframework.beans.factory.InitializingBean;

import com.pingan.pafa.common.utils.PURL;
import com.pingan.pafa.mongodb.MongoTemplateFactoryBean;

public class MongoTemplateURLFactoryBean extends MongoTemplateFactoryBean implements InitializingBean {

    private String url;

    public MongoTemplateURLFactoryBean() {}

    protected Properties loadURLConfigProperties() {
        PURL purl = PURL.valueOf(url);
        Properties properties = new Properties();
        properties.putAll(purl.getParameters());
        properties.put("servers", purl.getBackupAddress());
        return properties;
    }

    @Override
    public void afterPropertiesSet() throws Exception {
        this.setConfigureProperties(loadURLConfigProperties());
        super.afterPropertiesSet();
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

}
