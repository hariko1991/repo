package com.pingan.pafa5.admin.pool.dao;

import com.pingan.pafa5.admin.pool.po.NodePO;


public interface PoolDAO {
	
	public abstract void add(Object object);
	
	public abstract boolean updateById(Object object);
	
	public abstract long getCount(String pizzaKey, String projectId);
	
	public abstract boolean delete(String pizzaId);

	public abstract boolean updateServers(String pizzaId, String servers);

	public abstract boolean findNode(String ip, String id);

	public abstract boolean addNode(NodePO node, String id);

	public abstract boolean deleteNode(String ip, String pizzaId);

}
