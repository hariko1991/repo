package com.pingan.pafa5.admin.pizza.po;

import org.springframework.data.mongodb.core.mapping.Document;

import com.pingan.pafa5.admin.commons.BasePO;

/**
 * pizza操作日志
 * 
 * @author SHICHENGCHENG316
 */
@Document
public class PizzaOperationLogPO extends BasePO {

	/**
	 * 默认
	 */
	public static final int STATUS_DEF = 0;

	/**
	 * 已完成操作
	 */
	public static final int STATUS_COMPLETED = 1;

	/**
	 * 执行失败
	 */
	public static final int STATUS_FAILED = 2;

	@org.springframework.data.annotation.Id
	private String id;
	
	/**
     * 项目ID
     */
    private String projectId;
    
    /**
     * 项目名
     */
    private String projectName;

	/**
	 * 操作类型
	 */
	private String operationType;

	/**
	 * 操作类型名称
	 */
	private String operationName;

	/**
	 * 操作者IP地址
	 */
	private String operationIp;

	/**
	 * 备注信息
	 */
	private String remark;

	/**
	 * 操作原因
	 */
	private String operationReason;

	/**
	 * 原因对象ID，用于还原时记录备份ID
	 */
	private String reasonId;

	/**
	 * 状态, {0: 默认, 1: 操作完成, 9: 失败}
	 */
	private int status;

    @Override
    public String toString() {
        return "PizzaOperationLogPO [id=" + id + ", projectId=" + projectId + ", projectName="
                + projectName + ", operationType=" + operationType + ", operationName="
                + operationName + ", operationIp=" + operationIp + ", remark=" + remark
                + ", operationReason=" + operationReason + ", reasonId=" + reasonId + ", status="
                + status + "]";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getProjectId() {
        return projectId;
    }

    public void setProjectId(String projectId) {
        this.projectId = projectId;
    }

    public String getProjectName() {
        return projectName;
    }

    public void setProjectName(String projectName) {
        this.projectName = projectName;
    }

    public String getOperationType() {
        return operationType;
    }

    public void setOperationType(String operationType) {
        this.operationType = operationType;
    }

    public String getOperationName() {
        return operationName;
    }

    public void setOperationName(String operationName) {
        this.operationName = operationName;
    }

    public String getOperationIp() {
        return operationIp;
    }

    public void setOperationIp(String operationIp) {
        this.operationIp = operationIp;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getOperationReason() {
        return operationReason;
    }

    public void setOperationReason(String operationReason) {
        this.operationReason = operationReason;
    }

    public String getReasonId() {
        return reasonId;
    }

    public void setReasonId(String reasonId) {
        this.reasonId = reasonId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

}
