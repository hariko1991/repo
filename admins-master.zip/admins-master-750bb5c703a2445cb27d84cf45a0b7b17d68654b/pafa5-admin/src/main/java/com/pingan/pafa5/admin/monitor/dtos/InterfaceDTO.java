package com.pingan.pafa5.admin.monitor.dtos;


import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class InterfaceDTO {
	private String interfaceName;
	private String method;
	private String createTime;
	public String getInterfaceName() {
		return interfaceName;
	}
	public void setInterfaceName(String interfaceName) {
		this.interfaceName = interfaceName;
	}
	public String getMethod() {
		return method;
	}
	public void setMethod(String method) {
		this.method = method;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	
	
}
