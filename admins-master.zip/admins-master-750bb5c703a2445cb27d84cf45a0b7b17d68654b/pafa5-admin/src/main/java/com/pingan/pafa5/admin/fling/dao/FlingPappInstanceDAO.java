package com.pingan.pafa5.admin.fling.dao;

import java.util.List;

import com.pingan.pafa5.admin.fling.po.FlingPappInstancePO;

public interface FlingPappInstanceDAO {

    void upset(FlingPappInstancePO po);

    List<FlingPappInstancePO> list(String projectId, String pappName);

    List<FlingPappInstancePO> list(String projectId, String pappName, int limit, int page);

    long getPappCount(String projectId, String pappName);

    List<String> listInstanceIps(String projectId, String pappName);

    boolean checkValid(String pappName, String instanceIp, int heartbeatExpired);

    List<String> listValidInstanceIps(String projectId,String pappName, int heartbeatExpired);

    FlingPappInstancePO getFlingPappInstancePO(String pappName, String instanceIp);
    
    FlingPappInstancePO getFlingPappInstancePO(String pappName, String instanceIp, String projectId);

    boolean delete(String projectId, String pappName, String instanceIp);

    List<FlingPappInstancePO> list(String instanceIp);
    List<FlingPappInstancePO> list(int status, int limit, int page);
    List<FlingPappInstancePO> list(int status);

	

	long getPappCount(int status, String projectId);

	

	
	
	List<FlingPappInstancePO> listPappSearchResult(String projectId,
			String searchField);
	
	List<FlingPappInstancePO> listPappIndexPage(String projectId);
	
	List<FlingPappInstancePO> listPappIndexPage(String projectId,String instanceIp);
}
