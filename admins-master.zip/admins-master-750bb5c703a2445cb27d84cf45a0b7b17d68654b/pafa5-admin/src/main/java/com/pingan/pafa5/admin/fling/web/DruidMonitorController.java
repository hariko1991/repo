package com.pingan.pafa5.admin.fling.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa5.admin.commons.PageDataDTO;
import com.pingan.pafa5.admin.fling.po.DruidDatasourcePO;
import com.pingan.pafa5.admin.fling.po.DruidSqlPO;
import com.pingan.pafa5.admin.fling.services.DruidMonitorService;

@RequestMapping("/druid")
@Controller
public class DruidMonitorController extends BaseController {
	
	@Autowired
	private DruidMonitorService druidMonitorService;
	
	/**
	 * 查看sql监控信息列表
	 * @param identify
	 * @param druidPappId
	 * @param limit
	 * @param page
	 * @return
	 */
	@RequestMapping("/druidSql.do")
	@ResponseBody
	public ResponseModel listForDruidSql(
			@RequestParam(value = "identify" ,required=true) int identify,
			@RequestParam(value = "druidDatasourceId" ,required=true) String druidDatasourceId,
			@RequestParam(value = "limit", defaultValue = "30") int limit,
            @RequestParam(value = "page", defaultValue = "1") int page){
		
		PageDataDTO<DruidSqlPO> po  = druidMonitorService.listForSql(druidDatasourceId, identify, limit, page);
		
		ResponseModel model = new ResponseModel();
		model.put("datas", po.getDatas());
		model.put("totalCount", po.getDatas().size());
		return model;
		
	}
	
	/**
	 * 查看连接池监控信息列表
	 * @param identify
	 * @param druidPappId
	 * @return
	 */
	@RequestMapping("/druidDatasourceList.do")
	@ResponseBody
	public ResponseModel getDruidDatasourceList(
			@RequestParam(value = "domainId") String domainId,
			@RequestParam(value = "pappName" ,required=false) String pappName,
			@RequestParam(value = "limit", defaultValue = "30") int limit,
            @RequestParam(value = "page", defaultValue = "1") int page){
		
		PageDataDTO<DruidDatasourcePO> po  = druidMonitorService.listForDatasource(domainId, pappName, limit, page);
		
		ResponseModel model = new ResponseModel();
		model.put("datas", po.getDatas());
		model.put("totalCount", po.getDatas().size());
		return model;
		
	}
	/**
	 * 查看连接池监控信息详情
	 * @param identify
	 * @param druidPappId
	 * @return
	 */
	@RequestMapping("/druidDatasource.do")
	@ResponseBody
	public ResponseModel getDruidDatasource(
			@RequestParam(value = "identify" ,required=true) int identify,
			@RequestParam(value = "id" ,required=true) String id){
		
		DruidDatasourcePO po  = druidMonitorService.getDataSourceById(id, identify);
		
		ResponseModel model = new ResponseModel();
		model.put("datas", po);
		return model;
		
	}

}
