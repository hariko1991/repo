package com.pingan.pafa5.admin.fling.services.impl;

import java.util.Calendar;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa5.admin.fling.dao.DruidDatasourceHistoryDAO;
import com.pingan.pafa5.admin.fling.services.DruidDatasourceHistoryService;

@Service("druidDatasourceHistoryService")
public class DruidDatasourceHistoryServiceImpl extends BaseServices implements
	DruidDatasourceHistoryService {
	
	@Autowired
	DruidDatasourceHistoryDAO druidDatasourceHistoryDAO;

	@Override
	public boolean deleteYesterday() {
		Calendar now = Calendar.getInstance();
		//now.add(Calendar.DATE, 1);
		now.set(Calendar.HOUR_OF_DAY, 0);
        now.set(Calendar.MINUTE, 0);
        now.set(Calendar.SECOND, 0);
        int affected = druidDatasourceHistoryDAO.removeByDate(now.getTime());
        logger.info("清理druid连接池数据条数：" + affected);
        return affected > 0;
		
	}

	
	

}
