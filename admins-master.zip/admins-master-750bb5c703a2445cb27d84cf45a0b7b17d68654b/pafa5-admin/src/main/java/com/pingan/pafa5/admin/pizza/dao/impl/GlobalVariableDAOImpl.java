package com.pingan.pafa5.admin.pizza.dao.impl;

import java.util.List;
import java.util.regex.Pattern;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa5.admin.commons.Nosql;
import com.pingan.pafa5.admin.pizza.dao.GlobalVariableDAO;
import com.pingan.pafa5.admin.pizza.po.GlobalVariablePO;

@Nosql
@Repository
public class GlobalVariableDAOImpl extends BaseMongoDAO<GlobalVariablePO> implements GlobalVariableDAO {
	@Override
	public List<GlobalVariablePO> list(String proId, String property, int page, int limit) {
		Criteria criteria = null;

		if (proId == null) {
			criteria = where("proId").is(null);
		} else {
			criteria = where("proId").is(proId);
		}
		if (property != null && property.length() > 0) {
			criteria.and("property").regex(Pattern.compile("^.*" + property + ".*$", Pattern.CASE_INSENSITIVE));
		}
		int skip = (page - 1) * limit;
		return this._list(criteria, skip, limit);
	}

	@Override
	public List<GlobalVariablePO> list(String proId) {
		Criteria criteria = null;
		if (proId == null) {
			criteria = where("proId").is(null);
		} else {
			criteria = where("proId").is(proId);
		}
		return this._list(criteria);
	}

	@Override
	public long getCount(String proId, String property) {
		Criteria criteria = null;

		if (proId == null) {
			criteria = where("proId").is(null);
		} else {
			criteria = where("proId").is(proId);
		}

		if (property != null && property.length() > 0) {
			criteria.and("property").regex(
					Pattern.compile("^.*" + property + ".*$",
							Pattern.CASE_INSENSITIVE));
		}
		return this._count(criteria);
	}

	@Override
	public GlobalVariablePO getById(String id) {
		return this._getById(id);
	}

	@Override
	public void add(GlobalVariablePO po) {
		this._add(po);
	}

	@Override
	public boolean edit(GlobalVariablePO po) {
		return this._updateById(po);
	}

	@Override
	public boolean delete(String id) {
		return this._removeById(id);
	}
}
