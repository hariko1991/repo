package com.pingan.pafa5.admin.abtest.services;

import java.util.List;
import java.util.Map;

/**
 * 灰度发布管控平台服务接口
 * @author WANGJUN791
 *
 */
public interface ABTestingAdminDemoService {
	
	public long editPolicyData(String key, String newIp, String oldIp);
	
	public String applyPolicy(String key, String policy);

	public long addPolicyData(String key, String ip);
	
	public long delPolicyData(String key, String ip);
	
	public List<String> listIpWhiteTable(String key);
	
	public List<String> listPolicyData(String key);
	
	public Map<String, String> listPolicy(String key);
	
	public String addPolicy(String key, Map<String, String> value);
}