package com.pingan.pafa5.admin.commons;

import org.apache.commons.lang.StringUtils;

import com.pingan.pafa.pizza.Pizza;
import com.pingan.pafa5.admin.exception.InvalidValueException;
import com.pingan.pafa5.admin.exception.NullOrEmptyValueException;

public class SqlUtils {

	/**
	 * spring.profiles sql
	 */
	public static final String SPRING_PROFILE_SQL = "sql";

	/**
	 * spring.profiles nosql
	 */
	public static final String SPRING_PROFILE_NOSQL = "nosql";

	/**
	 * 生成查询条件中where 后的 正则式匹配, mysql,oracle, postgresql都要生成各自的适配方式.
	 * <p>
	 * mysql: "prod_name REGEXP ?"
	 * </p>
	 * <p>
	 * postgresql: "column_name ~ ?"
	 * </p>
	 * <p>
	 * oralce:
	 * </p>
	 * 
	 * @param dbType
	 *            数据库类型, [mongodb, mysql, oracle]
	 * @param columnName
	 * @return
	 */
	public static String getRegexSql(String dbType, String columnName) {
		StringBuffer sb = new StringBuffer();
		if (DatabaseType.POSTGRESQL.equalsIgnoreCase(dbType)) {
			sb.append(columnName + " ~ ? ");
		}

		else if (DatabaseType.ORACLE.equalsIgnoreCase(dbType)) {
			sb.append("regexp_like(" + columnName + ", ? ,'i')");
		}

		else if (DatabaseType.MYSQL.equalsIgnoreCase(dbType)) {
			sb.append(columnName + " REGEXP ? ");
		} else {
			throw new InvalidValueException("db config error: does not support this kind of database. db.type=" + dbType);
		}

		return sb.toString();
	}

	/**
	 * 只针对对 mysql, postgresql, orcale
	 * 
	 * @param columnName
	 * @return
	 */
	public static String getRegexSql(String columnName) {
		String dbType = Pizza.getProperty("db.type");
		if (null == dbType || StringUtils.isEmpty(dbType)) {
			throw new NullOrEmptyValueException("db config error: db.type is null or empty.");
		}

		return getRegexSql(dbType, columnName.toLowerCase());
	}

	public static String getSpringProfilesActive() {
		String profile = Pizza.getProperty("spring.profiles.active");

		if (null == profile || StringUtils.isEmpty(profile)) {
			throw new NullOrEmptyValueException("db config error: db.type is null or empty.");
		}

		return profile;
	}
}
