/**
 * Function:
 * 
 * File Created at 2011-08-11
 * 
 * Copyright 2011 Alibaba.com Croporation Limited.
 * All rights reserved.
 */
package com.alibaba.dubbo.governance.web.common.interceptor;

import java.security.Principal;
import java.util.HashSet;
import java.util.Set;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;

import com.alibaba.citrus.service.pipeline.PipelineContext;
import com.alibaba.citrus.service.pipeline.support.AbstractValve;
import com.alibaba.dubbo.common.logger.Logger;
import com.alibaba.dubbo.common.logger.LoggerFactory;
import com.alibaba.dubbo.governance.web.util.WebConstants;
import com.alibaba.dubbo.registry.common.domain.User;
import com.alibaba.dubbo.registry.common.util.Coder;
import com.pingan.pafa.pizza.admin.sso.SSO;
import com.pingan.pafa.pizza.utils.PizzaConfigUtils;

/**
 * @author william.liangf
 * @author guanghui.shigh
 * @author ding.lid
 * @author tony.chenl
 */
public class AuthorizationValve extends AbstractValve {

    private static final Logger logger = LoggerFactory.getLogger(AuthorizationValve.class);

    @Autowired
    private HttpServletRequest  request;

    @Autowired
    private HttpServletResponse response;
    
    @Autowired
    private SSO sso;
    
    @Value("${user.sso.loginURL}")
    private String loginURL;
    
    @Value("${security.root.users}")
    private String rootUsers;
    
    private Set<String> rootUserSet;

    @Override
    protected void init() throws Exception {
    	if(rootUsers!=null && rootUsers.length()>0){
    		this.rootUserSet=PizzaConfigUtils.split(rootUsers);
    	}else{
    		this.rootUserSet=new HashSet<String>();
    	}
    	this.rootUserSet.add("ROOT");
    	this.rootUserSet.add("LIXINGNAN945");
    }

    public void invoke(PipelineContext pipelineContext) throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("AuthorizationValve of uri: " + request.getRequestURI());
        }
        String uri = request.getRequestURI();
		String contextPath = request.getContextPath();
		if (contextPath != null && contextPath.length() > 0  && ! "/".equals(contextPath)) {
		    uri = uri.substring(contextPath.length());
		}
        if (uri.equals(logout)) {
		   /* if (! isLogout()) {
		        setLogout(true);
    		    showLoginForm();
		    } else {
		        setLogout(false);
		        response.sendRedirect(contextPath == null || contextPath.length() == 0 ? "/" : contextPath);
		    }*/
        	sso.logout(request, response);
        	response.sendRedirect(loginURL);
            return;
		}
        //FIXME
        if(! uri.startsWith("/status/")){
        	Principal up=sso.getUserPrincipal(request, response);
            if (up == null) {
            	request.getSession().setAttribute(WebConstants.CURRENT_USER_KEY, findUser("guest"));
            	
            	//response.sendRedirect(loginURL);
            }else{
            	String username=up.getName();
                request.getSession().setAttribute(WebConstants.CURRENT_USER_KEY, findUser(username));
                pipelineContext.invokeNext();
            }
        }else{
            pipelineContext.invokeNext();
        }
    }
    
    public User findUser(String username) {
    	username=username.toUpperCase();
    	if (rootUserSet.contains(username)) {
    		User user = new User();
            user.setUsername(username);
            user.setPassword(Coder.encodeMd5(username + ":" + User.REALM + ":****"));
            user.setName(username);
            user.setRole(User.ROOT);
            user.setEnabled(true);
            user.setLocale("zh");
            user.setServicePrivilege("*");
            return user;
    	}else{
    		User user = new User();
            user.setUsername(username);
            user.setPassword(Coder.encodeMd5(username + ":" + User.REALM + ":****"));
            user.setName(username);
            user.setRole(User.GUEST);
            user.setEnabled(true);
            user.setLocale("zh");
            user.setServicePrivilege("");
            return user;
    	} 
    }

	private String logout = "/logout";
  /*

    private static final String BASIC_CHALLENGE  = "Basic";

    private static final String DIGEST_CHALLENGE = "Digest";

    private static final String CHALLENGE        = DIGEST_CHALLENGE;

    private static final String REALM            = User.REALM;

	
	private String logoutCookie = "logout";

    private void showLoginForm() throws IOException {
        if (DIGEST_CHALLENGE.equals(CHALLENGE)) {
            response.setHeader("WWW-Authenticate", CHALLENGE + " realm=\"" + REALM + "\", qop=\"auth\", nonce=\""
                                                   + UUID.randomUUID().toString().replace("-", "") + "\", opaque=\""
                                                   + Coder.encodeMd5(REALM) + "\"");
        } else {
            response.setHeader("WWW-Authenticate", CHALLENGE + " realm=\"" + REALM + "\"");
        }
        response.setHeader("Cache-Control", "must-revalidate,no-cache,no-store");
        response.setHeader("Content-Type", "text/html; charset=iso-8859-1");
        response.sendError(HttpServletResponse.SC_UNAUTHORIZED);
    }
    
    private User loginByBase(String authorization) {
        authorization = Coder.decodeBase64(authorization);
        int i = authorization.indexOf(':');
        String username = authorization.substring(0, i);
        if (username != null && username.length() > 0) {
            String password = authorization.substring(i + 1);
            if (password != null && password.length() > 0) {
                String passwordDigest = Coder.encodeMd5(username + ":" + REALM + ":" + password);
                User user = getUser(username);
                if (user != null) {
                    String pwd = user.getPassword();
                    if (pwd != null && pwd.length() > 0) {
                        if (passwordDigest.equals(pwd)) {
                            return user;
                        }
                    }
                }
            }
        }
        return null;
    }

    private User loginByDigest(String value) throws IOException {
        Map<String, String> params = parseParameters(value);
        String username = params.get("username");
        if (username != null && username.length() > 0) {
            String passwordDigest = params.get("response");
            if (passwordDigest != null && passwordDigest.length() > 0) {
                User user = getUser(username);
                if (user != null) {
                    String pwd = user.getPassword();
                    if (pwd != null && pwd.length() > 0) {
                        String uri = params.get("uri");
                        String nonce = params.get("nonce");
                        String nc = params.get("nc");
                        String cnonce = params.get("cnonce");
                        String qop = params.get("qop");
                        String method = request.getMethod();
                        String a1 = pwd;

                        String a2 = "auth-int".equals(qop)
                            ? Coder.encodeMd5(method + ":" + uri + ":" + Coder.encodeMd5(readToBytes(request.getInputStream())))
                            : Coder.encodeMd5(method + ":" + uri);
                        String digest = "auth".equals(qop) || "auth-int".equals(qop)
                            ? Coder.encodeMd5(a1 + ":" + nonce + ":" + nc + ":" + cnonce + ":" + qop + ":" + a2)
                            : Coder.encodeMd5(a1 + ":" + nonce + ":" + a2);
                        if (digest.equals(passwordDigest)) {
                            return user;
                        }
                    }
                }
            }
        }
        return null;
    }
    
    private boolean isLogout() {
        Cookie[] cookies = request.getCookies();
        if (cookies != null && cookies.length > 0) {
            for (Cookie cookie : cookies) {
                if (cookie != null && logoutCookie.equals(cookie.getName())) {
                    return "true".equals(cookie.getValue());
                }
            }
        }
        return false;
    }
    
    private void setLogout(boolean logoutValue) {
        response.addCookie(new Cookie(logoutCookie, String.valueOf(logoutValue)));
    }
    
    private static Pattern PARAMETER_PATTERN = Pattern.compile("(\\w+)=[\"]?([^,\"]+)[\"]?[,]?\\s*");

    static Map<String, String> parseParameters(String query) {
        Matcher matcher = PARAMETER_PATTERN.matcher(query);
        Map<String, String> map = new HashMap<String, String>();
        while (matcher.find()) {
            String key = matcher.group(1);
            String value = matcher.group(2);
            map.put(key, value);
        }
        return map;
    }

    static byte[] readToBytes(InputStream in) throws IOException {
        byte[] buf = new byte[in.available()];
        in.read(buf);
        return buf;
    }*/


	public String getLoginURL() {
		return loginURL;
	}

	public SSO getSSO() {
		return sso;
	}

	public void setSSO(SSO sso) {
		this.sso = sso;
	}

	public String getRootUsers() {
		return rootUsers;
	}

	public void setRootUsers(String rootUsers) {
		this.rootUsers = rootUsers;
	}

	public void setLoginURL(String loginURL) {
		this.loginURL = loginURL;
	}
	
	
	
}
