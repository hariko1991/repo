package com.alibaba.dubbo.governance.web.common.utils;

import java.util.Properties;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.config.PropertyPlaceholderConfigurer;

import com.pingan.pafa.pizza.Pizza;

public class PizzaStatupUtil  extends PropertyPlaceholderConfigurer{
	
	private Log log=LogFactory.getLog(this.getClass());
	
	
	public  PizzaStatupUtil() {
		log.info("*****PizzaStatupUtil***pizza.config.file=classpath:pizza-dubbo-admin.properties");
		System.setProperty("pizza.config.file", "classpath:pizza-dubbo-admin.properties");
		try{
			String appName=Pizza.getAppName();
			//
			Properties properties=new Properties();
			properties.setProperty("dubbo.registry.address", Pizza.getProperty("pizza.manager"));
			//
			this.setProperties(properties);
			
			log.info("*****PizzaStatupUtil***appName="+appName);
		}finally{
			System.clearProperty("pizza.config.file");
		}
	}


	

}
