package com.dashuf.dpbs.app.web.req.push;

import java.io.Serializable;
import java.math.BigDecimal;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "房产信息")
@Getter
@Setter
public class InfoEntryOfHouse implements Serializable {
    private static final long serialVersionUID = 8053750474195732302L;

    @ApiModelProperty(value = "房产地址编码")
    private String addressCode;

    @ApiModelProperty(value = "房产地址名称")
    private String addressName;

    @ApiModelProperty(value = "房产价值")
    private BigDecimal totalPriceAmt;

    @ApiModelProperty(value = "房产性质")
    private String estatesTypeCode;
}
