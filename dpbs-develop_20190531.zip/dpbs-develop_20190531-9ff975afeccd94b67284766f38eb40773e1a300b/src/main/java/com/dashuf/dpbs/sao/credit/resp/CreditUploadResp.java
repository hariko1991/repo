package com.dashuf.dpbs.sao.credit.resp;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class CreditUploadResp implements Serializable {
    /**
     * 返回码
     */
    @JsonProperty(value = "RETCODE")
    private String retCode;
    /**
     * 返回信息
     */
    @JsonProperty(value = "RETMSG")
    private String retMsg;
    /**
     * 业务流水号
     */
    @JsonProperty(value = "SERIALNO")
    private String serialNo;

}
