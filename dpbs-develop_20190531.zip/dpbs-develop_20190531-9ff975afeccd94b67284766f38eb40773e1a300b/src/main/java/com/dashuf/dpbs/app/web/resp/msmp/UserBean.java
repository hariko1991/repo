package com.dashuf.dpbs.app.web.resp.msmp;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "我的用户")
@Getter
@Setter
public class UserBean implements Serializable {
    private static final long serialVersionUID = 4326889152243981603L;

    @ApiModelProperty(value = "用户编号")
    private String userNo;
    @ApiModelProperty(value = "用户姓名")
    private String userName;
    @ApiModelProperty(value = "用户类型")
    private String userType;
    @ApiModelProperty(value = "移动手机号码")
    private String mobileNo;

    @ApiModelProperty(value = "用户所属公司")
    private String srcChannel;
    @ApiModelProperty(value = "用户所属公司编码")
    private String srcChannelCode;
}
