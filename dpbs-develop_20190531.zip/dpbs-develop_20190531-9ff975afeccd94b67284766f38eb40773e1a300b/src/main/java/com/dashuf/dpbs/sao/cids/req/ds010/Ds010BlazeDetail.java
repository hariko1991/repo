package com.dashuf.dpbs.sao.cids.req.ds010;

import com.dashuf.dpbs.sao.cids.req.ds010.blaze.BusinessDetail;
import com.dashuf.dpbs.sao.cids.req.ds010.blaze.CustomerListDetail;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
public class Ds010BlazeDetail implements Serializable {
    private static final long serialVersionUID = -44507081100768657L;

    /**
     * SYSTEM_ID	系统编号	VARCHAR(10)	Y
     */
    @JsonProperty(value = "SYSTEM_ID")
    private String systemId = "DBPS";

    /**
     * APPLY_ID	申请编号	VARCHAR (40)	Y
     */
    @JsonProperty(value = "APPLY_ID")
    private String applyId;

    /**
     * ENGINE_NODE	引擎节点	VARCHAR(10)	Y	必输
     */
    @JsonProperty(value = "ENGINE_NODE")
    private String engineMode = "DS010";
    /**
     * FICO_SCORE_WANTED	是否调用FICO评分	VARCHAR	N	0-不调 1-调用
     */
    @JsonProperty(value = "FICO_SCORE_WANTED")
    private String ficoScoreWanted = "1";

    /**
     * INVOKE_TYPE	调用方式	VARCHAR(3)	Y	SYN-同步 MSG-异步
     */
    @JsonProperty(value = "INVOKE_TYPE")
    private String invokeType = "SYN";

    @JsonProperty(value = "CUSTOMER_LIST")
    private List<CustomerListDetail> customerList;

    @JsonProperty(value = "BUSINESS")
    private BusinessDetail business;

}
