package com.dashuf.dpbs.sao.dsfg;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class UploadCreditFileResp implements Serializable {
    /**
     * 证件号码	Varchar(18)		certId	否
     */
    private String certId;
    /**
     * 客户姓名	Varchar(30)		custName	否
     */
    private String custName;
    /**
     * 查询渠道	Varchar(32)	DSRD/DD/DSPM/BANKE/WZSY/LIANYUN 大数融担/大道/信贷/半刻/微众税银/联云	queryChannel	否
     */
    private String queryChannel;
    /**
     * 上传返回码	Varchar(4)	"0000" 上传成功，其余失败	result	否
     */
    private String result;
    /**
     * 上传返回信息	Varchar(400)		msg	否
     */
    private String msg;


}
