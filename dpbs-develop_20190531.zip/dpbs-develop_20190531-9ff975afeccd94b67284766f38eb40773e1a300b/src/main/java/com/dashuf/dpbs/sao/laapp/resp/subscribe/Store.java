package com.dashuf.dpbs.sao.laapp.resp.subscribe;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class Store implements Serializable {
    /**
     * address	string 必须 门店地址
     */
    private String address;
    /**
     * serviceId	string 必须 门店id
     */
    private String serviceId;
    /**
     * serviceName	string 必须 门店名称
     */
    private String serviceName;
    /**
     * serviceMobilePhoneNum string 必须 联系电话
     */
    private String serviceMobilePhoneNum;
}
