package com.dashuf.dpbs.sao.cids.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
public class PushClientOfCarLoanDetail implements Serializable {

    /**
     * carLoanInd	string　非必须 车贷标识
     */
    private String carLoanInd;
    /**
     * carLoanAmt	string　非必须　汽车贷款金额
     */
    private String carLoanAmt;


    /**
     * loanAmt	number 非必须 车贷贷款金额（有车贷时必传）
     */
    private BigDecimal loanAmt;
    /**
     * monthlyRepaymentAmt	number 非必须 车贷月还款额（有车贷时必传）
     */
    private BigDecimal monthlyRepaymentAmt;
}
