package com.dashuf.dpbs.service.cpms;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.web.resp.support.GetExclusiveChannelListResp;
import com.dashuf.dpbs.app.web.resp.support.GetExclusiveChannelResp;
import com.dashuf.dpbs.app.web.resp.support.GetTeamOfUmResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.sao.cpms.MarketManagerSAO;
import com.dashuf.merlin.web.base.views.ResponseVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class MarketManagerSupportService {
    @Autowired
    private MarketManagerSAO marketManagerSAO;
    final String[] postTypeCodeList = {"CM", "EC"}; //为客户经理角色的类别

    public List<GetExclusiveChannelResp.ExclusiveChannel> getExclusiveChannel(String channelName, JSONObject jsonObj) {
        ResponseVo<JSONObject> getExclusiveChannelResp = marketManagerSAO.getExclusiveChannel(channelName);

        if (DpbsCnst.HTTP_OK.equals(getExclusiveChannelResp.getCode())) {

            if (null != getExclusiveChannelResp.getData()) {
                JSONArray jsonArray = getExclusiveChannelResp.getData().getJSONArray("list");
                if (null != jsonArray && jsonArray.size() >= 1) {
                    List<GetExclusiveChannelResp.ExclusiveChannel> exclusiveChannelList = new ArrayList<>();
                    for (int i = 0; i < jsonArray.size(); i++) {
                        JSONObject channelObj = jsonArray.getJSONObject(i);
                        if (null != channelObj) {
                            GetExclusiveChannelResp.ExclusiveChannel exclusiveChannel = new GetExclusiveChannelResp.ExclusiveChannel();
                            exclusiveChannel.setChannelName(channelObj.getString("channelName"));
                            exclusiveChannel.setChannelCode(channelObj.getString("exclusiveChannelId"));
                            exclusiveChannelList.add(exclusiveChannel);
                        }
                    }
                    return exclusiveChannelList;
                }
            }
            jsonObj.put(DpbsCnst.RTN_MSG, "专属渠道为空");
            return null;
        } else {
            jsonObj.put(DpbsCnst.RTN_MSG, getExclusiveChannelResp.getMessage());
            return null;
        }
    }


    public List<GetExclusiveChannelResp.ExclusiveChannel> getExclusiveChannelAvailable(String channelName, JSONObject jsonObj) {
        ResponseVo<JSONObject> getExclusiveChannelResp = marketManagerSAO.getExclusiveChannelAvailable(channelName);
        if (DpbsCnst.HTTP_OK.equals(getExclusiveChannelResp.getCode())) {

            if (null != getExclusiveChannelResp.getData()) {
                JSONArray jsonArray = getExclusiveChannelResp.getData().getJSONArray("list");
                if (null != jsonArray && jsonArray.size() >= 1) {
                    List<GetExclusiveChannelResp.ExclusiveChannel> getExclusiveChannelList = new ArrayList<>();
                    for (int i = 0; i < jsonArray.size(); i++) {
                        JSONObject channelObj = jsonArray.getJSONObject(i);
                        if (null != channelObj) {
                            GetExclusiveChannelResp.ExclusiveChannel getExclusiveChannel = new GetExclusiveChannelResp.ExclusiveChannel();
                            getExclusiveChannel.setChannelName(jsonArray.getJSONObject(i).getString("channelName"));
                            getExclusiveChannel.setChannelCode(jsonArray.getJSONObject(i).getString("exclusiveChannelId"));
                            getExclusiveChannelList.add(getExclusiveChannel);
                        }
                    }
                    return getExclusiveChannelList;
                }
            }
            jsonObj.put(DpbsCnst.RTN_MSG, "专属渠道为空");
            return null;
        } else {
            jsonObj.put(DpbsCnst.RTN_MSG, getExclusiveChannelResp.getMessage());
            return null;
        }
    }


    private boolean compareDate(String dateOne, String dateTwo) throws Exception {
        DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
        Date timeOne = null;
        Date timeTwo = null;
        Date now = new Date();
        if (StringUtils.isNotEmpty(dateOne) && StringUtils.isNotEmpty(dateTwo)) {//情况一，两个时间都不为空
            timeOne = dateFormat.parse(dateOne);
            timeTwo = dateFormat.parse(dateTwo);
            if (timeOne.getTime() <= now.getTime() && timeTwo.getTime() >= now.getTime()) {
                return true;
            }
        }
        if (StringUtils.isNotEmpty(dateOne) && StringUtils.isEmpty(dateTwo)) {//情况二，第二个时间为空
            timeOne = dateFormat.parse(dateOne);
            if (timeOne.getTime() <= now.getTime()) {
                return true;
            }
        }
        return false;
    }

    /**
     * 根据um 号查询所属团队,所属公司等信息
     *
     * @param umNo
     * @param jsonObject
     * @return
     */
    public GetTeamOfUmResp getTeamListOfUm(String umNo, JSONObject jsonObject) throws Exception {
        ResponseVo<JSONObject> teamListOfUmNo = marketManagerSAO.getTeamListOfUmNo(umNo);
        if (teamListOfUmNo.getCode().equals(DpbsCnst.HTTP_OK)) {
            if (null == teamListOfUmNo.getData()) {
                jsonObject.put(DpbsCnst.RTN_MSG, "用户不存在团队");
                return null;
            }
            JSONArray jsonArrayList = teamListOfUmNo.getData().getJSONArray("list");
            if (null == jsonArrayList) {
                jsonObject.put(DpbsCnst.RTN_MSG, "用户不存在团队");
                return null;
            }
            List<GetTeamOfUmResp.TeamOfUm> list = new ArrayList<>();
            for (int i = 0; i < jsonArrayList.size(); i++) {
                String userName = jsonArrayList.getJSONObject(i).getString("userName");
                String mobileTelephoneNum = jsonArrayList.getJSONObject(i).getString("mobileTelephoneNum");
                JSONArray memberRoleList = jsonArrayList.getJSONObject(i).getJSONArray("memberRole");
                if (null == memberRoleList) {
                    jsonObject.put(DpbsCnst.RTN_MSG, "不存在客户经理角色");
                    return null;
                }
                for (int j = 0; j < memberRoleList.size(); j++) {
                    String availableDate = memberRoleList.getJSONObject(j).getString("availableDate");
                    String unavailableDate = memberRoleList.getJSONObject(j).getString("unavailableDate");

                    if (("CM".equals(memberRoleList.getJSONObject(j).getString("postTypeCode")) ||
                            "EC".equals(memberRoleList.getJSONObject(j).getString("postTypeCode")))
                            && compareDate(availableDate,unavailableDate)) {
                        GetTeamOfUmResp.TeamOfUm team = new GetTeamOfUmResp.TeamOfUm();
                        team.setTeamName(memberRoleList.getJSONObject(j).getString("marketTeamName"));
                        team.setTeamCode(memberRoleList.getJSONObject(j).getString("marketTeamId"));
                        team.setCompanyName(memberRoleList.getJSONObject(j).getString("organizationName"));
                        team.setCompanyCode(memberRoleList.getJSONObject(j).getString("organizationId"));
                        team.setSrcUmMobileNo(mobileTelephoneNum);
                        team.setUMNo(memberRoleList.getJSONObject(j).getString("userId"));
                        team.setUMName(userName);
                        list.add(team);
                    }
                }
            }
            if (list.size() == 0) {
                jsonObject.put(DpbsCnst.RTN_MSG, "用户不存在团队");
                return null;
            }
            GetTeamOfUmResp getTeamOfUmResp = new GetTeamOfUmResp();
            getTeamOfUmResp.setTeamOfUmList(list);

            return getTeamOfUmResp;
        } else {
            jsonObject.put(DpbsCnst.RTN_MSG, teamListOfUmNo.getMessage());
            return null;
        }
    }

    /**
     * 模糊查询可用的客户经理列表
     *
     * @param umNo
     * @param jsonObject
     * @return
     */
    public List<String> getAvailableUmList(String umNo, JSONObject jsonObject) {
        ResponseVo<JSONObject> teamListAvailable = marketManagerSAO.getTeamListAvailable(postTypeCodeList, umNo);
        if (teamListAvailable.getCode().equals(DpbsCnst.HTTP_OK)) {
            if (teamListAvailable.getData() == null) {
                jsonObject.put(DpbsCnst.RTN_MSG, "不存在客户经理");
                return null;
            }
            JSONArray jsonArrayList = teamListAvailable.getData().getJSONArray("list");
            if (null == jsonArrayList) {
                jsonObject.put(DpbsCnst.RTN_MSG, "不存在客户经理");
                return null;
            }
            List<String> list = new ArrayList<>();
            for (int i = 0; i < jsonArrayList.size(); i++) {
                String userId = jsonArrayList.getJSONObject(i).getString("userId");
                list.add(userId);
            }
            if (list.size() == 0) {
                jsonObject.put(DpbsCnst.RTN_MSG, "不存在客户经理");
                return null;
            }
            return list;
        } else {
            jsonObject.put(DpbsCnst.RTN_MSG, teamListAvailable.getMessage());
            return null;
        }

    }

    /**
     * 模糊查询所有公司列表
     *
     * @param srcChannel
     * @param jsonObj
     * @return
     */
    public List<GetExclusiveChannelListResp> getOrganizationChannelsListAvailable(String srcChannel, JSONObject jsonObj) {
        ResponseVo<JSONObject> organizationChannelsListAvailable = marketManagerSAO.getOrganizationChannelsListAvailable(srcChannel);
        if (organizationChannelsListAvailable.getCode().equals(DpbsCnst.HTTP_OK)) {
            if (organizationChannelsListAvailable.getData() == null) {
                jsonObj.put(DpbsCnst.RTN_MSG, "不存在渠道");
                return null;
            }
            JSONArray list = organizationChannelsListAvailable.getData().getJSONArray("list");
            if (null == list) {
                jsonObj.put(DpbsCnst.RTN_MSG, "不存在渠道");
                return null;
            }
            List<GetExclusiveChannelListResp> getExclusiveChannelListRespList = new ArrayList<>();
            for (int i = 0; i < list.size(); i++) {
                GetExclusiveChannelListResp getExclusiveChannelListResp = new GetExclusiveChannelListResp();
                getExclusiveChannelListResp.setSrcChannel(list.getJSONObject(i).getString("channelName"));
                getExclusiveChannelListResp.setSrcChannelCode(list.getJSONObject(i).getString("organizationChannelId"));
                getExclusiveChannelListRespList.add(getExclusiveChannelListResp);
            }
            if (getExclusiveChannelListRespList.size() == 0) {
                jsonObj.put(DpbsCnst.RTN_MSG, "不存在渠道");
                return null;
            }
            return getExclusiveChannelListRespList;
        } else {
            jsonObj.put(DpbsCnst.RTN_MSG, organizationChannelsListAvailable.getMessage());
            return null;
        }

    }

}
