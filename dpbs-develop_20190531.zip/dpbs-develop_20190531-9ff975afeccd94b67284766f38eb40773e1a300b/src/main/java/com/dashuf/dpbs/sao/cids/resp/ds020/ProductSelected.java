package com.dashuf.dpbs.sao.cids.resp.ds020;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class ProductSelected implements Serializable {
    private static final long serialVersionUID = 2704399465694624679L;
}
