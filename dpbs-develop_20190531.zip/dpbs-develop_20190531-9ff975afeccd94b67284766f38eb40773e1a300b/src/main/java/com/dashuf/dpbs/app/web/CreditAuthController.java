package com.dashuf.dpbs.app.web;

import com.dashuf.dpbs.app.annotation.LoginRole;
import com.dashuf.dpbs.app.web.req.credit.*;
import com.dashuf.dpbs.app.web.req.push.FinishPushOrderReq;
import com.dashuf.dpbs.cnst.DpbsStatusCnst;
import com.dashuf.dpbs.cnst.SysConfCnst;
import com.dashuf.dpbs.model.PushOrderLog;
import com.dashuf.dpbs.service.blaze.DashufBlazeSupportService;
import com.dashuf.dpbs.service.blaze.ThirdPartyAccessSupportService;
import com.dashuf.dpbs.service.blaze.dto.DashufBlazeDto;
import com.dashuf.dpbs.service.support.VerifyCodeService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.DpbsUrl;
import com.dashuf.dpbs.app.web.resp.credit.AnalysisQrCodeResp;
import com.dashuf.dpbs.app.web.resp.credit.CreditAuthH5Resp;
import com.dashuf.dpbs.app.web.resp.credit.RefreshQrCodeResp;
import com.dashuf.dpbs.app.web.resp.credit.SkipCreditAuthResp;
import com.dashuf.dpbs.app.web.resp.credit.SubmitAuthH5Resp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.service.CreditAuthSupportService;
import com.dashuf.merlin.web.base.views.ResponseVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;


@Api(value = "征信授权控制类", tags = {"征信授权控制类"})
@Slf4j
@RestController
@RequestMapping(DpbsUrl.CREDIT_AUTH_REF)
public class CreditAuthController {
    @Autowired
    private CreditAuthSupportService creditAuthSupportService;
    @Autowired
    private VerifyCodeService verifyCodeService;
    @Autowired
    private DashufBlazeSupportService dashufBlazeSupportService;
    @Autowired
    private ThirdPartyAccessSupportService thirdPartyAccessSupportService;

    @ApiOperation(value = "获取银联h5认证页面")
    @PostMapping("/getCreditAuthH5")
    @LoginRole
    public ResponseVo<CreditAuthH5Resp> getCreditAuthH5(@RequestBody @Validated CreditAuthH5Req creditAuthH5Req) {
        try {
            JSONObject jsonObj = new JSONObject();
            if (!verifyCodeService.checkVerifyCode(SysConfCnst.MODULE_CODE_OF_CLIENT_CREDIT_AUTH, creditAuthH5Req.getMobileNo(), creditAuthH5Req.getVerifyCode(), jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            String creditAuthH5Page = creditAuthSupportService.getCreditAuthH5(creditAuthH5Req, jsonObj);
            if (StringUtils.isEmpty(creditAuthH5Page)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }

            CreditAuthH5Resp creditAuthH5Resp = new CreditAuthH5Resp();
            creditAuthH5Resp.setPushOrderNo(creditAuthH5Req.getPushOrderNo());
            creditAuthH5Resp.setH5AuthPage(creditAuthH5Page);
            return new ResponseVo<>(creditAuthH5Resp);
        } catch (Exception e) {
            log.error("推单编号[{}]获取征信h5页面过程中异常:{}", creditAuthH5Req.getPushOrderNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "提交征信授权码")
    @PostMapping("/submitCreditAuth")
    @LoginRole
    public ResponseVo<SubmitAuthH5Resp> submitCreditAuth(@RequestBody @Validated SubmitAuthH5Req submitAuthH5Req) {
        try {
            JSONObject jsonObj = new JSONObject();
            //1.校验推送订单状态
            DashufBlazeDto dashufBlazeDto = creditAuthSupportService.validSubmitCreditAuth(submitAuthH5Req, jsonObj);
            if (null == dashufBlazeDto || null == dashufBlazeDto.getPushOrderLog()) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            //如果没有做过征信查询
            if (DpbsStatusCnst.PUSH_ENTRY.equals(dashufBlazeDto.getPushOrderLog().getPushStatus())) {
                //2.调用BlazeDS010
                if (!dashufBlazeSupportService.submitCredit(submitAuthH5Req, dashufBlazeDto, jsonObj)) {
                    return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
                }
            } else {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, "阶段不对，不能做征信授权");
            }

            SubmitAuthH5Resp submitAuthH5Resp = new SubmitAuthH5Resp();
            submitAuthH5Resp.setPushOrderNo(submitAuthH5Req.getPushOrderNo());
            //公众号页面提交征信授权码后,需要提示评分成功，请稍后 …这个提示语
            return new ResponseVo<>(submitAuthH5Resp, "评分成功，请稍后 …");
        } catch (Exception e) {
            log.error("推单编号[{}]提交征信授权码过程中异常:{}", submitAuthH5Req.getPushOrderNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "解析二维码内容")
    @PostMapping("/analysisQrCode")
    @LoginRole
    public ResponseVo<AnalysisQrCodeResp> analysisQrCode(@RequestBody @Validated AnalysisQrCodeReq analysisQrCodeReq) {
        try {
            JSONObject jsonObj = new JSONObject();
            AnalysisQrCodeResp analysisQrCodeResp = creditAuthSupportService.analysisQrCode(analysisQrCodeReq, jsonObj);

            if (null == analysisQrCodeResp) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }

            return ResponseVo.success(analysisQrCodeResp);
        } catch (Exception e) {
            log.error("二维码编号[{}]解析过程中异常:{}", analysisQrCodeReq.getQrCodeInfoNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "跳过银联h5认证页面")
    @PostMapping("/skipCreditAuth")
    @LoginRole
    public ResponseVo<SkipCreditAuthResp> skipCreditAuth(@RequestBody @Validated SkipCreditAuthReq skipCreditAuthReq) {
        try {
            SkipCreditAuthResp skipCreditAuthResp = new SkipCreditAuthResp();
            skipCreditAuthResp.setPushOrderNo(skipCreditAuthReq.getPushOrderNo());
            return ResponseVo.success(skipCreditAuthResp);
        } catch (Exception e) {
            log.error("推单编号[{}]跳过银联h5认证页面过程中异常:{}", skipCreditAuthReq.getPushOrderNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "刷新征信授权二维码")
    @PostMapping("/refreshQrCode")
    public ResponseVo<RefreshQrCodeResp> refreshQrCode(@Validated @RequestBody RefreshQrCodeReq refreshQrCodeReq) {
        try {
            JSONObject jsonObj = new JSONObject();
            RefreshQrCodeResp refreshQrCodeResp = new RefreshQrCodeResp();
            refreshQrCodeResp.setPushOrderNo(refreshQrCodeReq.getPushOrderNo());

            if (!creditAuthSupportService.initCreditAuthPage(refreshQrCodeReq.getPushOrderNo(), refreshQrCodeResp, jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(refreshQrCodeResp);
        } catch (Exception e) {
            log.error("推单流水号[{}],刷新征信授权二维码异常:{}", refreshQrCodeReq.getPushOrderNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }


    @ApiOperation(value = "调用二代APP推送客户")
    @PostMapping("/pushClient")
    public ResponseVo<String> pushClient(@Validated @RequestBody PushClientReq pushClientReq) {
        try {
            JSONObject jsonObj = new JSONObject();

            if (!thirdPartyAccessSupportService.pushClient(pushClientReq.getPushOrderNo(), jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return ResponseVo.success();
        } catch (Exception e) {
            log.error("调用二代APP推送客户[{}]:{}", pushClientReq.getPushOrderNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "ds020评分")
    @PostMapping("/ds020")
    public ResponseVo<String> ds020OfBlaze(@Validated @RequestBody FinishPushOrderReq finishPushOrderReq) {
        try {
            JSONObject jsonObj = new JSONObject();

            PushOrderLog pushOrderLog = new PushOrderLog();
            pushOrderLog.setPushOrderNo(finishPushOrderReq.getPushOrderNo());
            if (!thirdPartyAccessSupportService.queryScoreDs020(pushOrderLog, jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return ResponseVo.success();
        } catch (Exception e) {
            log.error("推单号[{}]ds020评分过程中异常:{}", finishPushOrderReq.getPushOrderNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "调用融担")
    @PostMapping("/uploadZld")
    public ResponseVo<String> uploadZld(@Validated @RequestBody FinishPushOrderReq finishPushOrderReq) {
        try {
            JSONObject jsonObj = new JSONObject();

            PushOrderLog pushOrderLog = new PushOrderLog();
            pushOrderLog.setPushOrderNo(finishPushOrderReq.getPushOrderNo());
            if (!thirdPartyAccessSupportService.initScreenDs010(pushOrderLog, jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return ResponseVo.success();
        } catch (Exception e) {
            log.error("推单号[{}]ds020评分过程中异常:{}", finishPushOrderReq.getPushOrderNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

}
