package com.dashuf.dpbs.app.web.resp.push;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "初始化推单记录")
@Getter
@Setter
public class PushOrderResp implements Serializable {
	private static final long serialVersionUID = 26902995577450524L;

	@ApiModelProperty(value = "推送订单编号")
	private String pushOrderNo;

	@ApiModelProperty(value = "推送状态")
	private String pushStatus;

	@ApiModelProperty(value = "跳转页面")
	private String redirectPage;

}
