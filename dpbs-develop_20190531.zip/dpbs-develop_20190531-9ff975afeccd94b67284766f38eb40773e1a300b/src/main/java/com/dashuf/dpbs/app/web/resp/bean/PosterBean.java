package com.dashuf.dpbs.app.web.resp.bean;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "海报响应resp")
@Getter
@Setter
public class PosterBean implements Serializable {
	private static final long serialVersionUID = -4741133759063717162L;
	@ApiModelProperty(value = "标题")
	private String title;

	@ApiModelProperty(value = "网址")
	private String webSite;

	@ApiModelProperty(value = "图片地址")
	private String imgUrl;

}
