package com.dashuf.dpbs.sao.support.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;

@Getter
@Setter
public class GetFileTemplateDto implements Serializable {
    private String year;
    private String month;
    private String day;
    private String mobile;
    private String idNo;
    private String name;
    private Date signDate;
}
