package com.dashuf.dpbs.sao.wx;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@FeignClient(name = "weixin", url = "${application.weixin.url}")
public interface WxApiSao {
	public static final String JS_CODE = "jsCode";
	public static final String SECRET = "secret";
	public static final String APP_ID = "appId";
	public static final String GET_OPEN_ID_URL = "/sns/jscode2session?appid={appId}&secret={secret}&js_code={jsCode}&grant_type=authorization_code";

	@RequestMapping(value = GET_OPEN_ID_URL, method = RequestMethod.GET)
	public String getOpenId(@PathVariable(APP_ID) String appId, @PathVariable(SECRET) String corpSecret, @PathVariable(JS_CODE) String jsCode);

}
