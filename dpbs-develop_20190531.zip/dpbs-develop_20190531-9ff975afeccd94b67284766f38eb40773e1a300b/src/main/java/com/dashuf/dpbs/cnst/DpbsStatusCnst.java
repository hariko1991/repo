package com.dashuf.dpbs.cnst;

public final class DpbsStatusCnst {
    public static final String SUCCESS = "success";
    public static final String FAIL = "fail";
    public static final String NORMAL = "normal";


    public static final String INIT = "init";

    /**
     * init(初始化)
     */
    public static final String PUSH_INIT = "init";
    /**
     * scan(扫描身份证)
     */
    public static final String PUSH_SCAN = "scan";
    /**
     * movie(影像上传)
     */
    public static final String PUSH_MOVIE = "movie";
    /**
     * entry(信息录入)
     */
    public static final String PUSH_ENTRY = "entry";
    /**
     * credit(征信授权)
     */
    public static final String PUSH_CREDIT = "credit";
    /**
     * eval_ing(初评中)
     */
    public static final String PUSH_EVAL_ING = "eval_ing";
    /**
     * eval_fail(初评失败)
     */
    public static final String PUSH_EVAL_FAIL = "eval_fail";
    /**
     * eval_success(初评通过)
     */
    public static final String PUSH_EVAL_SUCCESS = "eval_success";

    /**
     * push_client_ing(推送客户中)
     */
    public static final String PUSH_CLIENT_ING = "push_client_ing";

    /**
     * push_client_ing(推送客户成功)
     */
    public static final String PUSH_CLIENT_SUCCESS = "push_client_success";

    /**
     * fail(推单失败)
     */
    public static final String PUSH_FAIL = "fail";
    /**
     * success(推单结束)
     */
    public static final String PUSH_SUCCESS = "success";
}
