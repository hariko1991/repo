package com.dashuf.dpbs.app.web.req.center;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

@ApiModel(value = "校验手机号请求")
@Setter
@Getter
public class VerifyMobileNoReq implements Serializable {

    @ApiModelProperty(value = "用户编号")
    private String userNo;

    /**
     * 手机号码
     */
    @ApiModelProperty(value = "手机号码")
    @NotBlank(message = "请输入正确的手机号")
    @Pattern(regexp = "^[1][0-9]{10}$", message = "请输入正确的手机号")
    private String mobileNo;


    @ApiModelProperty(value = "手机号码,user_reg用户注册,modify_mobile_no修改手机号,common_verify")
    @NotBlank(message = "请输入正确的校验类型")
    private String verifyType;
}
