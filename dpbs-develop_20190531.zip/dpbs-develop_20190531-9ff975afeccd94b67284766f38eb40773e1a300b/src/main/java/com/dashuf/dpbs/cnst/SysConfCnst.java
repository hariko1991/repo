package com.dashuf.dpbs.cnst;

public final class SysConfCnst {
    public static final String AUTH_FILE_ID = "auth_file_id";

    public static final String TEMPLATE_NO = "template_no";
    public static final String SEND_VERIFY_CODE = "send_verify_code";

    public static final String MODULE_CODE_USER_REG = "user_reg";
    public static final String MODULE_CODE_USER_LOGIN = "user_login_code";
    public static final String DATA_MOCK = "data_mock";
    public static final String USER_MODIFY_MOBILE_NO = "user_modify_mobile_no";
    public static final String USER_CERT_AUTH = "user_cert_auth";


    public static final String MODULE_CODE_CREDIT_AUTH = "credit_auth";

    public static final String MODULE_SUB_CODE_QR_CODE = "qr_code";

    public static final String URL = "url";

    public static final String MODULE_CODE_OF_UNIFY_VERIFY_CODE = "unify_verify_code";


    public static final String MODULE_CODE_OF_CLIENT_CREDIT_AUTH = "client_credit_auth";
    public static final String MODULE_CODE_OF_BLAZE_DS_020 = "blaze_ds020";
    public static final String MODULE_SUB_CODE_OF_GET_SCORE = "get_score";
    public static final String MODULE_KEY_OF_EXPIRE_DAY = "expire_day";
    public static final String MODULE_KEY_OF_MONTH_RATE = "month_rate";

    public static final String MODULE_CODE_OF_USER_CREDIT_AUTH = "user_credit_auth";
    public static final String MODULE_SUB_CODE_OF_GET_QR_CODE = "get_qr_code";
    public static final String MODULE_KEY_OF_LINK_VERIFY_URL = "link_verify_url";
    public static final String MODULE_KEY_OF_EXPIRE_SECOND = "expire_second";


    public static final String DATA_MOCK_OF_SEND_VERIFY_CODE = "send_verify_code";
    public static final String DATA_MOCK_OF_CLIENT_SIGN = "client_sign";
    public static final String DATA_MOCK_OF_UPLOAD_ZLD = "upload_zld";
    public static final String DATA_MOCK_OF_QUERY_CREDIT_STATUS = "query_credit_status";

    public static final String MODULE_KEY_OF_POS_BEAN = "pos_bean";
    public static final String MODULE_CODE_OF_SUBMIT_CREDIT = "submit_credit_report_req";
    public static final String MODULE_SUB_CODE_OF_SUBMIT_CREDIT = "submit_credit_report";
    public static final String MODULE_KEY_OF_SUBMIT_CREDIT = "submit_credit_report";

    public static final String MODULE_CODE_OF_ZLD_SFTP_CONF = "zld_sftp_conf";
    public static final String MODULE_SUB_CODE_OF_ZLD_SFTP_CONF = "zld_sftp_conf";
    public static final String MODULE_KEY_OF_ZLD_SFTP_CONF = "zld_sftp_conf";
}
