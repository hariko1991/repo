package com.dashuf.dpbs.sao.defi.req.apply;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
public class ProductInfo implements Serializable {
    /**
     * "productNumber": "1",
     */
    private String productNumber;
    /**
     * "partnerName": "RP20141128000002",
     */
    private String partnerName;
    /**
     * "fundProvider": "RL20141128000002",
     */
    private String fundProvider;
    /**
     * "guaranteeType": "DSRD",
     */
    private String guaranteeType;
    /**
     * "partnerLine": 500000.00,
     */
    private BigDecimal partnerLine;
    /**
     * "dtiline": 500,
     */
    private BigDecimal dtiline;
}
