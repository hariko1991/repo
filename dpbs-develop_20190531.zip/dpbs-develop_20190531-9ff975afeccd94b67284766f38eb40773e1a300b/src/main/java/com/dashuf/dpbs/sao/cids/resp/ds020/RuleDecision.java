package com.dashuf.dpbs.sao.cids.resp.ds020;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class RuleDecision implements Serializable {
    private static final long serialVersionUID = 9151233613888622455L;
}
