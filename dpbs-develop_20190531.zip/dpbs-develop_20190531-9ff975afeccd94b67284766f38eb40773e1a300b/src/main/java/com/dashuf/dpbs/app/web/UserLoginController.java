package com.dashuf.dpbs.app.web;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.annotation.LoginUser;
import com.dashuf.dpbs.app.web.req.user.DensityFreeLoginReq;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.DpbsHeadCnst;
import com.dashuf.dpbs.service.UserInfoSupportService;
import com.dashuf.dpbs.app.annotation.LoginRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dashuf.dpbs.app.DpbsUrl;
import com.dashuf.dpbs.app.web.req.user.LoginCodeReq;
import com.dashuf.dpbs.app.web.req.user.LoginPwdReq;
import com.dashuf.dpbs.app.web.resp.user.LoginResp;
import com.dashuf.merlin.web.base.views.ResponseVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Api(value = "用户登录相关", tags = {"用户登录相关"})
@Slf4j
@RestController
@RequestMapping(DpbsUrl.USER_LOGIN_REF)
public class UserLoginController {
    @Autowired
    private UserInfoSupportService userInfoSupportService;

    @ApiOperation(value = "密码方式登录")
    @PostMapping("/loginByPwd")
    @LoginRole(need = true)
    public ResponseVo<LoginResp> loginByPwd(HttpServletRequest request, HttpServletResponse response,
                                            @RequestBody @Validated LoginPwdReq loginPwdReq) {
        try {
            JSONObject jsonObj = new JSONObject();
            LoginResp loginResp = userInfoSupportService.loginByPwd(loginPwdReq, jsonObj);
            if (null == loginResp) {
                return ResponseVo.fail(jsonObj.getString(DpbsCnst.RTN_CODE), jsonObj.getString(DpbsCnst.RTN_MSG));
            }

            userInfoSupportService.initAccessTokenForUser(request, response, loginResp.getUserNo());
            return new ResponseVo<>(loginResp);
        } catch (Exception e) {
            log.error("手机号[{}]密码登录过程中异常:{}", loginPwdReq.getMobileNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "验证码方式登录")
    @PostMapping("/loginByCode")
    @LoginRole(need = true)
    public ResponseVo<LoginResp> loginByCode(HttpServletRequest request, HttpServletResponse response, @RequestBody @Validated LoginCodeReq loginCodeReq) {
        try {
            JSONObject jsonObj = new JSONObject();
            LoginResp loginResp = userInfoSupportService.loginByCode(loginCodeReq, jsonObj);
            if (null == loginResp) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }

            userInfoSupportService.initAccessTokenForUser(request, response, loginResp.getUserNo());
            return new ResponseVo<>(loginResp);
        } catch (Exception e) {
            log.error("手机号[{}]验证码登录过程中异常:{}", loginCodeReq.getMobileNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "免密码登录")
    @PostMapping("/densityFreeLogin")
    @LoginRole(need = true)
    public ResponseVo<LoginResp> densityFreeLogin(HttpServletRequest request, HttpServletResponse response, @RequestBody @Validated DensityFreeLoginReq densityFreeLoginReq) {
        try {
            JSONObject jsonObj = new JSONObject();
            LoginResp loginResp = userInfoSupportService.densityFreeLogin(densityFreeLoginReq, jsonObj);
            if (null == loginResp) {
                return ResponseVo.fail(DpbsHeadCnst.X_HEAD_RTN_CODE_NEED_LOGIN, jsonObj.getString(DpbsCnst.RTN_MSG));
            }

            userInfoSupportService.initAccessTokenForUser(request, response, loginResp.getUserNo());
            return new ResponseVo<>(loginResp);
        } catch (Exception e) {
            log.error("登录模式[{}]以第三方授权码[{}]免密码登录过程中异常:{}", densityFreeLoginReq.getThirdPartyType(), densityFreeLoginReq.getThirdPartyCode(), e);
            return ResponseVo.fail(DpbsHeadCnst.X_HEAD_RTN_CODE_NEED_LOGIN, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "免密码登录")
    @PostMapping("/securityLoginOut")
    public ResponseVo<String> securityLoginOut(@LoginUser String loginUserNo) {
        try {
            userInfoSupportService.securityLoginOut(loginUserNo);
            return new ResponseVo<>("成功安全退出");
        } catch (Exception e) {
            log.error("用户[{}]登出过程中异常:{}", loginUserNo, e);
            return ResponseVo.fail(DpbsHeadCnst.X_HEAD_RTN_CODE_NEED_LOGIN, DpbsCnst.SERVER_ERROR);
        }
    }

}
