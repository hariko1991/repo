package com.dashuf.dpbs.app.web.resp.bean;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "公告响应resp")
@Getter
@Setter
public class NoticeBean implements Serializable {
	private static final long serialVersionUID = -4741133759063717162L;
	@ApiModelProperty(value = "公告标题")
	private String noticeTitle;

	@ApiModelProperty(value = "公告内容")
	private String noticeContent;

}
