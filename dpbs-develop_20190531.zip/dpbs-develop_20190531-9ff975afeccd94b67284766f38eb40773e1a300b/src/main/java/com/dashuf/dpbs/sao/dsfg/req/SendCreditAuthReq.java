package com.dashuf.dpbs.sao.dsfg.req;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class SendCreditAuthReq implements Serializable {
	private static final long serialVersionUID = -6676367043068808420L;

	/**
	 * 身份证名字
	 */
	private String idcardName;

	/**
	 * 身份证号码
	 */
	private String idcardNo;

	/**
	 * 手机号码
	 */
	private String phone;

	/**
	 * 申请编号
	 */
	private String applyNo;

	/**
	 * 数据来源(1|pc端、2|移动app)
	 */
	private String sourceType;

	/**
	 * 调用方
	 */
	private String caller;

	/**
	 * 商家页面
	 */
	private String returnPageUrl;

}
