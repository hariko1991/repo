package com.dashuf.dpbs.app.web.req.center;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@ApiModel(value = "绑定客户经理请求")
@Setter
@Getter
public class BindClientManagerReq implements Serializable {
    @ApiModelProperty(value = "用户编号")
    private String userNo;


    @ApiModelProperty(value = "客户经理编码")
    @NotBlank(message = "请输入客户经理编码")
    private String srcUmNo;


    @ApiModelProperty(value = "客户经理名称")
    private String srcUmName;

    @ApiModelProperty(value = "客户经理所属公司名称")
    private String srcCompany;

    @ApiModelProperty(value = "客户经理所属公司编码")
    private String srcCompanyCode;

    @ApiModelProperty(value = "团队编码")
    private String teamCode;


    @ApiModelProperty(value = "团队名称")
    private String teamName;

    @ApiModelProperty(value = "客户经理手机")
    private String srcUmMobileNo;


}
