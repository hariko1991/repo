package com.dashuf.dpbs.service.cpms;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.sao.cpms.ClientTradingSAO;
import com.dashuf.merlin.web.base.views.ResponseVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


@Service
@Slf4j
public class ClientTradingSupportService {
    @Autowired
    private ClientTradingSAO clientTradingSAO;
    private static final String IND_01 = "Ind01";// 身份证类型
    private static final String IN_TRADING_1 = "1";//在途

    public boolean inTrading(String clientName, String certNo, JSONObject jsonObj) {
        ResponseVo<String> inTradingResp = clientTradingSAO.inTrading(clientName, IND_01, certNo);

        log.info("姓名[{}],身份证号码[{}]调用信贷返回在途结果:{}", clientName, certNo, JSONObject.toJSONString(inTradingResp));
        if (!DpbsCnst.HTTP_OK.equals(inTradingResp.getCode())) {
            jsonObj.put(DpbsCnst.RTN_MSG, inTradingResp.getMessage());
            return false;
        }

        boolean rtnBoolean = IN_TRADING_1.equals(inTradingResp.getData()) ? true : false;
        if (rtnBoolean) {
            jsonObj.put(DpbsCnst.RTN_MSG, "该客户存在在途业务，无法再次推荐");
            return false;
        }
        return true;
    }
}
