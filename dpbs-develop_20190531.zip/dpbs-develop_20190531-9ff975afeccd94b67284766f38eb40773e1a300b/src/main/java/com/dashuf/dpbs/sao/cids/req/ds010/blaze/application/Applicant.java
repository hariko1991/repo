package com.dashuf.dpbs.sao.cids.req.ds010.blaze.application;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class Applicant implements Serializable {
    private static final long serialVersionUID = 3446506023911927086L;

    /**
     * "applicationType": "1",
     */
    private String applicationType;
    /**
     * "cell": "18600500138",
     */
    private String cell;
    /**
     * "certtype": "Ind01",
     */
    @JsonProperty(value = "certtype")
    private String certType;
    /**
     * "customername": "钱汇明",
     */
    @JsonProperty(value = "customername")
    private String customerName;
    /**
     * "ficoScoreWanted": "1",
     */
    private String ficoScoreWanted;
    /**
     * "id": "360104196407031926"
     */
    private String id;
}
