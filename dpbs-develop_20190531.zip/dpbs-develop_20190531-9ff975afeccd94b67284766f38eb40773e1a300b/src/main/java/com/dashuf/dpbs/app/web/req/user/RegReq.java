package com.dashuf.dpbs.app.web.req.user;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "用户注册")
@Getter
@Setter
public class RegReq implements Serializable {
    private static final long serialVersionUID = -5582187965750153742L;

    /**
     * 手机号码
     */
    @ApiModelProperty(value = "手机号码")
    @NotBlank(message = "请输入正确的手机号")
    @Pattern(regexp = "^[1][0-9]{10}$", message = "请输入正确的手机号")
    private String mobileNo;

    /**
     * 验证码
     */
    @ApiModelProperty(value = "验证码")
    @NotBlank(message = "请输入验证码")
    private String verifyCode;

    /**
     * 密码
     */
    @ApiModelProperty(value = "密码")
    @NotBlank(message = "请输入密码")
    @Pattern(regexp = "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$", message = "密码不符合规则，需8-16位数字与字母组合密码，区分大小写")
    private String userPwd;

    /**
     * 确认密码
     */
    @ApiModelProperty(value = "确认密码")
    @NotBlank(message = "请输入确认密码")
    @Pattern(regexp = "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$", message = "密码不符合规则，需8-16位数字与字母组合密码，区分大小写")
    private String confirmPwd;

    @ApiModelProperty(value = "微信授权码")
    private String wxCode;

    @ApiModelProperty(value = "第三方授权码")
    private String thirdPartyCode;

    @ApiModelProperty(value = "第三方类型")
    private String thirdPartyType;
}
