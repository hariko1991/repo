package com.dashuf.dpbs.app.web.req.user;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@ApiModel(value = "免密登录req")
@Setter
@Getter
public class DensityFreeLoginReq implements Serializable {
    private static final long serialVersionUID = -4411491261345944259L;


    @ApiModelProperty(value = "登录类型")
    @NotBlank(message = "请输入登录类型: WX")
    private String thirdPartyType;

    @ApiModelProperty(value = "第三方授权唯一编码")
    @NotBlank(message = "请输入第三方授权唯一编码")
    private String thirdPartyCode;
}
