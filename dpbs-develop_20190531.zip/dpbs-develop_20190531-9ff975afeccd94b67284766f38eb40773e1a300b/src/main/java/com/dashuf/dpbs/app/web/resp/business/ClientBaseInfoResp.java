package com.dashuf.dpbs.app.web.resp.business;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

/**
 * @author yaojiaoyi
 * 客户基本信息
 */
@ApiModel("客户基本信息")
@Getter
@Setter
public class ClientBaseInfoResp {

    @ApiModelProperty(value = "客户姓名")
    private String clientName;

    @ApiModelProperty(value = "客户编号")
    private String clientNo;

    @ApiModelProperty(value = "客户手机号")
    private String mobileNo;

    @ApiModelProperty("身份证号")
    private String certNo;

    @ApiModelProperty("推荐时间")
    private Date reconDate;
}
