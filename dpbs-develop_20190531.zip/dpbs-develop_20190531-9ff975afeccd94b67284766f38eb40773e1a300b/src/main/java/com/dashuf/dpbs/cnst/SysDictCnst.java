package com.dashuf.dpbs.cnst;

public final class SysDictCnst {
	public static final String PROVINCE = "province";
	public static final String DIRECT_CITY = "direct_city";
	public static final String CITY = "city";
	public static final String AREA = "area";
}
