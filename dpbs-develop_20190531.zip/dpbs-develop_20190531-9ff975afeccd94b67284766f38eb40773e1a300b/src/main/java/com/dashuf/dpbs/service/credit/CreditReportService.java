package com.dashuf.dpbs.service.credit;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.SysConfCnst;
import com.dashuf.dpbs.model.ClientInfo;
import com.dashuf.dpbs.model.SysConf;
import com.dashuf.dpbs.sao.credit.CreditReportSAO;
import com.dashuf.dpbs.sao.credit.req.CreditReport25Req;
import com.dashuf.dpbs.sao.credit.req.CreditUploadReq;
import com.dashuf.dpbs.sao.credit.resp.CreditReport25Resp;
import com.dashuf.dpbs.sao.credit.resp.CreditUploadResp;
import com.dashuf.dpbs.service.SysConfSupportService;
import com.dashuf.dpbs.service.blaze.dto.DashufBlazeDto;
import com.dashuf.merlin.web.base.views.ResponseVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class CreditReportService {
    private static final String SUCCESS_RET_CODE = "SUC000";
    private static final String SUBMIT_CREDIT_QUERYORG = "queryOrg";
    private static final String SUBMIT_CREDIT_ORIGINID = "originId";
    @Autowired
    private CreditReportSAO creditReportSAO;
    @Autowired
    private SysConfSupportService sysConfSupportService;

    public String queryCreditReportWithin25Day(ClientInfo clientInfo, JSONObject jsonObj) {
        CreditReport25Req creditReport25Req = new CreditReport25Req();
        creditReport25Req.setCertType("1");
        creditReport25Req.setCertId(clientInfo.getCertNo());
        creditReport25Req.setCustomerName(clientInfo.getClientName());
        creditReport25Req.setChannel("DISP");
        creditReport25Req.setOrgId("");
        creditReport25Req.setLoanAlter("0");

        CreditReport25Resp creditReport25Resp = creditReportSAO.queryCreditReportWithin25Day(creditReport25Req);
        log.info("查询客户[{}]证件号[{}]征信报告编号结果:{}", clientInfo.getClientName(), clientInfo.getCertNo(), null != creditReport25Resp ? JSONObject.toJSONString(creditReport25Resp) : "空");

        if (null == creditReport25Resp) {
            jsonObj.put(DpbsCnst.RTN_MSG, "获取征信报告编号内容为空");
            return null;
        }

        if (SUCCESS_RET_CODE.equals(creditReport25Resp.getRetCode())) {
            List<CreditReport25Resp.CreditReport> creditReportList = creditReport25Resp.getReportList();
            if (CollectionUtils.isNotEmpty(creditReportList)) {
                return creditReportList.get(0).getReportNo();
            }

            return null;
        } else {
            jsonObj.put(DpbsCnst.RTN_MSG, creditReport25Resp.getRetCode() + creditReport25Resp.getRetMsg());
            return null;
        }

    }

    public String submitCreditReportReq(DashufBlazeDto dashufBlazeDto, JSONObject jsonObj) {
        SysConf sysConf = new SysConf();
        sysConf.setModuleCode(SysConfCnst.MODULE_CODE_OF_SUBMIT_CREDIT);
        sysConf.setModuleSubCode(SysConfCnst.MODULE_SUB_CODE_OF_SUBMIT_CREDIT);
        sysConf.setModuleKey(SysConfCnst.MODULE_KEY_OF_SUBMIT_CREDIT);
        String submitCreditReq = sysConfSupportService.selectValueFromCache(sysConf);
        JSONObject jsonObject = JSONObject.parseObject(submitCreditReq);

        CreditUploadReq creditUploadReq = new CreditUploadReq();
        creditUploadReq.setQueryOrg(jsonObject.getString(SUBMIT_CREDIT_QUERYORG));
        creditUploadReq.setQueryModel("02");
        creditUploadReq.setPhone(dashufBlazeDto.getInfoEntry().getMobileNo());
        creditUploadReq.setApplyId(dashufBlazeDto.getPushOrderLog().getPushOrderNo());
        creditUploadReq.setIsDisp("0");
        creditUploadReq.setChannel(DpbsCnst.SYSTEM_NAME);
        creditUploadReq.setCertId(dashufBlazeDto.getClientInfo().getCertNo());
        creditUploadReq.setManager(dashufBlazeDto.getUserInfo().getSrcUmName());
        creditUploadReq.setOriginId(jsonObject.getString(SUBMIT_CREDIT_ORIGINID));
        creditUploadReq.setCustomerName(dashufBlazeDto.getClientInfo().getClientName());
        creditUploadReq.setItMode(DpbsCnst.SYSTEM_NAME);
        List<CreditUploadReq.CreditAuthImge> creditAuthImgeList = new ArrayList<>();
        creditUploadReq.setImageList(creditAuthImgeList);

        CreditUploadResp creditUploadResp = creditReportSAO.submitCreditReportReq(creditUploadReq);
        log.info("推单编号[{}]发起中兰德征信报告查询结果:{}", dashufBlazeDto.getPushOrderLog().getPushOrderNo(), JSONObject.toJSONString(creditUploadResp));

        if (null == creditUploadResp) {
            jsonObj.put(DpbsCnst.RTN_MSG, "提问查询征信报告编号返回结果为空");
            return null;
        }

        if (SUCCESS_RET_CODE.equals(creditUploadResp.getRetCode())) {
            return creditUploadResp.getSerialNo();
        } else {
            jsonObj.put(DpbsCnst.RTN_MSG, creditUploadResp.getRetCode() + creditUploadResp.getRetMsg());
            return null;
        }
    }
}
