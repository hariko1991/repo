package com.dashuf.dpbs.sao.defi.resp.result;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class RuleDecision implements Serializable {
    private static final long serialVersionUID = 502984737803840935L;

    /**
     * ruleTriggerReason	string	必须
     */
    private String ruleTriggerReason;
    /**
     * index	number	必须
     */
    private String index;
    /**
     * ruleCode	string	必须
     */
    private String ruleCode;
    /**
     * ruleDecisionResult	string	必须
     */
    private String ruleDecisionResult;
    /**
     * rulesetCode	string	必须
     */
    private String rulesetCode;
    /**
     * ruleName	string	必须
     */
    private String ruleName;
    /**
     * rulesetName	string	必须
     */
    private String rulesetName;
    /**
     * reasonCode	string	必须
     */
    private String reasonCode;
    /**
     * ruleSeverityLevel	string	必须
     */
    private String ruleSeverityLevel;

}
