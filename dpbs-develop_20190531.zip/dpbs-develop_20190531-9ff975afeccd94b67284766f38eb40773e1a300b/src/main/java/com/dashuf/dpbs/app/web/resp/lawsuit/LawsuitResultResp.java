package com.dashuf.dpbs.app.web.resp.lawsuit;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author yaojiaoyi
 */
@Getter
@Setter
public class LawsuitResultResp {

    @ApiModelProperty("身份证号")
    private String certNo;

    @ApiModelProperty("姓名")
    private String name;

    @ApiModelProperty("查询日期")
    private Date queryDate;

    @ApiModelProperty("查询结果，json字符串")
    private String result;
}
