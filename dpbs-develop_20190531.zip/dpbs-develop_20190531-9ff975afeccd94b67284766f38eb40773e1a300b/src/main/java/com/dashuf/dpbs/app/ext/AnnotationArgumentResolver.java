package com.dashuf.dpbs.app.ext;

import com.dashuf.dpbs.app.annotation.LoginUser;
import com.dashuf.dpbs.cnst.DpbsHeadCnst;
import com.dashuf.dpbs.model.UserInfo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.core.MethodParameter;
import org.springframework.stereotype.Component;
import org.springframework.web.bind.support.WebDataBinderFactory;
import org.springframework.web.context.request.NativeWebRequest;
import org.springframework.web.context.request.RequestAttributes;
import org.springframework.web.method.support.HandlerMethodArgumentResolver;
import org.springframework.web.method.support.ModelAndViewContainer;
import org.springframework.web.multipart.support.MissingServletRequestPartException;

@Component
public class AnnotationArgumentResolver implements HandlerMethodArgumentResolver {

    @Override
    public boolean supportsParameter(MethodParameter parameter) {
        return parameter.getParameterType().isAssignableFrom(String.class)
                && parameter.hasParameterAnnotation(LoginUser.class);
    }

    @Override
    public Object resolveArgument(MethodParameter parameter, ModelAndViewContainer mavContainer,
                                  NativeWebRequest webRequest, WebDataBinderFactory binderFactory) throws Exception {
        String userNo = (String) webRequest.getAttribute(DpbsHeadCnst.X_HEAD_LOGIN_USER, RequestAttributes.SCOPE_REQUEST);
        if (StringUtils.isNotEmpty(userNo)) {
            return userNo;
        }
        throw new MissingServletRequestPartException(DpbsHeadCnst.X_HEAD_LOGIN_USER);
    }

}

