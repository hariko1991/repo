package com.dashuf.dpbs;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;

import com.dashuf.dpbs.service.CacheInitService;

@SpringBootApplication
@Configuration
@EnableFeignClients(basePackages = {"com.dashuf.dpbs", "com.dashuf.merlin.ftb.sao"})
@EnableAsync
public class Application {

    public static void main(String[] args) {
        ApplicationContext app = SpringApplication.run(Application.class, args);
        CacheInitService cacheInitService = app.getBean(CacheInitService.class);
        cacheInitService.initCache();
    }

}
