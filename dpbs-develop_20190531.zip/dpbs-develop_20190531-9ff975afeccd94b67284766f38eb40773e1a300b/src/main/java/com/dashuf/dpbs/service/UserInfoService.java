package com.dashuf.dpbs.service;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.mapper.UserInfoMapper;
import com.dashuf.dpbs.model.UserInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class UserInfoService {
    @Autowired
    private UserInfoMapper userInfoMapper;

    public UserInfo getUserInfo(String userNo, JSONObject jsonObj) {
        UserInfo userInfoParam = new UserInfo();
        userInfoParam.setUserNo(userNo);

        UserInfo userInfo = userInfoMapper.selectQuiqueUserInfo(userInfoParam);
        if (null == userInfo) {
            jsonObj.put(DpbsCnst.RTN_MSG, "用户不存在");
            return null;
        }
        return userInfo;
    }
}
