package com.dashuf.dpbs.app.web.req.user;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "忘记密码req")
@Getter
@Setter
public class ForgetPwdReq implements Serializable {
    private static final long serialVersionUID = -5843740177773993349L;

    /**
     * 手机号码
     */
    @ApiModelProperty(value = "手机号码")
    @NotBlank(message = "请输入正确的手机号")
    @Pattern(regexp = "^[1][0-9]{10}$", message = "请输入正确的手机号")
    private String mobileNo;

    /**
     * 用户登录密码
     */
    @ApiModelProperty(value = "用户登录密码")
    @NotBlank(message = "请输入密码")
    @Pattern(regexp = "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$", message = "密码不符合规则，需8-16位数字与字母组合密码，区分大小写")
    private String userPwd;

    /**
     * 确认密码
     */
    @ApiModelProperty(value = "确认密码")
    private String confirmPwd;

    /**
     * 手机验证码
     */
    @ApiModelProperty(value = "手机验证码")
    @NotBlank(message = "请输入验证码")
    private String verifyCode;
}
