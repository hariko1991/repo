package com.dashuf.dpbs.sao.defi.resp.result;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class IcDecision implements Serializable {
    private static final long serialVersionUID = 2395970085950506259L;

    /**
     * ruleCode	string	必须
     */
    private String ruleCode;
    /**
     * ruleAction	string	必须
     */
    private String ruleAction;
    /**
     * ruleDecisionResult	string	必须
     */
    private String ruleDecisionResult;
    /**
     * ruleSeverityLevel	number	必须
     */
    private String ruleSeverityLevel;

}
