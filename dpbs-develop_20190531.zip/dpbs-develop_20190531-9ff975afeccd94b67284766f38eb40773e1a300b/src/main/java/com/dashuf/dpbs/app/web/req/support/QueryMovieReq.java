package com.dashuf.dpbs.app.web.req.support;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "查询影像Req")
@Getter
@Setter
public class QueryMovieReq implements Serializable {
	private static final long serialVersionUID = -3768683746238382319L;

	/**
	 * 流水号
	 */
	@ApiModelProperty(value = "流水号")
	@NotBlank(message = "流水号不能为空")

	private String stepRefNo;

	/**
	 * 步骤
	 */
	@ApiModelProperty(value = "步骤")
	@NotBlank(message = "步骤不能为空")
	private String stepCode;

	/**
	 * 查询影象批次号
	 */
	@ApiModelProperty(value = "查询影象批次号")
	@NotBlank(message = "查询影象批次号不能为空")
	private String contentId;

}
