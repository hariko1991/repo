package com.dashuf.dpbs.sao.defi;

import com.dashuf.dpbs.sao.defi.req.ApplyRunEngineReq;
import com.dashuf.dpbs.sao.defi.req.GetDecisionResultReq;
import com.dashuf.dpbs.sao.defi.resp.ApplyRunEngineResp;
import com.dashuf.dpbs.sao.defi.resp.GetDecisionResultResp;
import com.dashuf.merlin.web.base.views.ResponseVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

/**
 * , url="http://10.21.0.23:8215" sit
 * , url="http://10.22.0.123:8215" uat
 */
@FeignClient(name = "DE-FrontInterface")
public interface DefiBlazeSAO {


    @PostMapping(value = "/api/applyRunEngine.do")
    public ApplyRunEngineResp applyRunEngine(@RequestBody ApplyRunEngineReq applyRunEngineReq);

    @PostMapping(value = "/api/getDecisionResult.do")
    public ResponseVo<GetDecisionResultResp> getDecisionResult(@RequestBody GetDecisionResultReq getDecisionResultReq);

}
