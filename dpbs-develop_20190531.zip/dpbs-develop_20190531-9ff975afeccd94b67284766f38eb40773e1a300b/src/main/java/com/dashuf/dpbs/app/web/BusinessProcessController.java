package com.dashuf.dpbs.app.web;

import com.dashuf.dpbs.app.DpbsUrl;
import com.dashuf.dpbs.app.annotation.LoginUser;
import com.dashuf.dpbs.app.web.resp.business.BusinessProcessDetailResp;
import com.dashuf.dpbs.app.web.resp.business.BusinessProcessResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.model.UserInfo;
import com.dashuf.dpbs.service.BusinessProcessService;
import com.dashuf.merlin.mybatis.page.Pagination;
import com.dashuf.merlin.web.base.views.ResponseVo;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 业务进度查询
 *
 * @author yaojiaoyi
 */
@Api(value = "APP首页相关", tags = {"业务进度查询相关"})
@Slf4j
@RestController
@RequestMapping(value = DpbsUrl.BUSINESS_PRO_REF)
public class BusinessProcessController {

    @Autowired
    private BusinessProcessService businessProcessService;

    /**
     * 业务进度查询概览
     *
     * @param processStatus 进度状态，1-待办，2-已办
     * @param userNo        用户编号
     * @param pagination    分页对象
     * @return
     */
    @ApiOperation(value = "业务查询已办待办列表")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "成功")})
    @GetMapping(value = "/process")
    public ResponseVo<PageInfo<BusinessProcessResp>> getBusinessProcess(@RequestParam("processStatus") Integer processStatus,
                                                                        @RequestParam("userNo") String userNo,
                                                                        @ApiIgnore @LoginUser String loginUserNo,
                                                                        Pagination pagination) {
        try {
            return ResponseVo.success(businessProcessService.getBusinessProcess(processStatus, loginUserNo, pagination));
        } catch (Exception e) {
            log.error("获取已办待办列表过程中异常:userNo={},exception={}", loginUserNo, e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }

    }

    /**
     * 订单状态详情
     *
     * @param pushOrderNo 推送订单编号
     * @return
     */
    @ApiOperation(value = "订单状态详情")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "成功")})
    @GetMapping(value = "/processDetail")
    public ResponseVo<BusinessProcessDetailResp> getProcessDetail(@RequestParam("pushOrderNo") String pushOrderNo) {
        try {
            return ResponseVo.success(businessProcessService.getBusinessDetail(pushOrderNo));
        } catch (Exception e) {
            log.error("获取业务详情过程中异常:pushOrderNo={},exception={}", pushOrderNo, e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }

    }
}
