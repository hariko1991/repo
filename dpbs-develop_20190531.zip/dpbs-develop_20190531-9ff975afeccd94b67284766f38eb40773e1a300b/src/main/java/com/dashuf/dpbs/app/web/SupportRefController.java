package com.dashuf.dpbs.app.web;

import com.dashuf.dpbs.app.annotation.LoginRole;
import com.dashuf.dpbs.app.annotation.LoginUser;
import com.dashuf.dpbs.app.web.req.center.VerifyMobileNoReq;
import com.dashuf.dpbs.app.web.req.support.GatherFormIdReq;
import com.dashuf.dpbs.app.web.req.support.GetCompanyOfUmReq;
import com.dashuf.dpbs.app.web.req.support.GetExclusiveChannelReq;
import com.dashuf.dpbs.app.web.resp.support.*;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.model.UserInfo;
import com.dashuf.dpbs.service.CacheInitService;
import com.dashuf.dpbs.service.SupportRefService;
import com.dashuf.dpbs.service.cpms.MarketManagerSupportService;
import com.dashuf.dpbs.service.laapp.ApkPackageSupportService;
import com.dashuf.dpbs.service.support.OcrForCertSupportService;
import com.dashuf.dpbs.service.ucss.UserAuthSupportService;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.DpbsUrl;
import com.dashuf.dpbs.app.web.req.QrOfLoanAppReq;
import com.dashuf.dpbs.app.web.resp.QrOfLoanAppResp;
import com.dashuf.dpbs.util.CacheUtil;
import com.dashuf.merlin.web.base.views.ResponseVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.web.multipart.MultipartFile;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

@Api(value = "辅助类控制", tags = {"辅助类控制"})
@Slf4j
@RestController
@RequestMapping(DpbsUrl.SUPPORT_REF)
public class SupportRefController {
    @Autowired
    private MarketManagerSupportService marketManagerSupportService;
    @Autowired
    private ApkPackageSupportService apkPackageSupportService;
    @Autowired
    private UserAuthSupportService userAuthSupportService;
    @Autowired
    private SupportRefService supportRefService;
    @Autowired
    private OcrForCertSupportService ocrForCertSupportService;
    @Autowired
    private CacheInitService cacheInitService;

    @ApiOperation(value = "获取贷款APP")
    @PostMapping("/getLoanApp")
    @LoginRole
    public ResponseVo<QrOfLoanAppResp> getLoanApp(@Validated @RequestBody QrOfLoanAppReq qrOfLoanAppReq) {
        try {
            JSONObject jsonObj = new JSONObject();

            String apkUrl = apkPackageSupportService.getLoanAppQr(qrOfLoanAppReq, jsonObj);
            if (StringUtils.isEmpty(apkUrl)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }

            QrOfLoanAppResp qrOfLoanAppResp = new QrOfLoanAppResp();
            qrOfLoanAppResp.setPushOrderNo(qrOfLoanAppReq.getPushOrderNo());
            qrOfLoanAppResp.setQrCodeUrl(apkUrl);
            return new ResponseVo<>(qrOfLoanAppResp);
        } catch (Exception e) {
            log.error("获取二代贷款APP过程中异常:{}", e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "初始化数据字典")
    @PostMapping("/initDataDict")
    public ResponseVo<JSONObject> initDataDict() {
        JSONObject json = new JSONObject();
        json.put("dict", CacheUtil.getSysDictOfJsonObj());
        json.put("address", CacheUtil.getSysAreaOfJsonArray());
        return new ResponseVo<>(json);
    }

    @ApiOperation(value = "用户所属公司查询")
    @PostMapping("/getExclusiveChannel")
    public ResponseVo<GetExclusiveChannelResp> getExclusiveChannel(@Validated @RequestBody GetExclusiveChannelReq getExclusiveChannelReq) {
        try {
            JSONObject jsonObj = new JSONObject();

            List<GetExclusiveChannelResp.ExclusiveChannel> getExclusiveChannelList = marketManagerSupportService.getExclusiveChannel(getExclusiveChannelReq.getChannelName(), jsonObj);
            if (CollectionUtils.isEmpty(getExclusiveChannelList)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }

            GetExclusiveChannelResp getExclusiveChannelResp = new GetExclusiveChannelResp();
            getExclusiveChannelResp.setChannelList(getExclusiveChannelList);
            return new ResponseVo<>(getExclusiveChannelResp);
        } catch (Exception e) {
            log.error("根据渠道名[{}]获取列表过程中异常:{}", getExclusiveChannelReq.getChannelName(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "用户所属公司/可用专属渠道查询")
    @PostMapping("/getExclusiveChannelAvailable")
    public ResponseVo<GetExclusiveChannelResp> getExclusiveChannelAvailable(@Validated @RequestBody GetExclusiveChannelReq getExclusiveChannelReq) {
        try {
            JSONObject jsonObj = new JSONObject();

            List<GetExclusiveChannelResp.ExclusiveChannel> getExclusiveChannelList = marketManagerSupportService.getExclusiveChannelAvailable(getExclusiveChannelReq.getChannelName(), jsonObj);
            if (CollectionUtils.isEmpty(getExclusiveChannelList)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }

            GetExclusiveChannelResp getExclusiveChannelResp = new GetExclusiveChannelResp();
            getExclusiveChannelResp.setChannelList(getExclusiveChannelList);
            return new ResponseVo<>(getExclusiveChannelResp);
        } catch (Exception e) {
            log.error("根据渠道名[{}]获取列表过程中异常:{}", getExclusiveChannelReq.getChannelName(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }


    @ApiOperation(value = "收集微信小程序formid")
    @PostMapping("/gatherFormIdForPushMsg")
    public ResponseVo<String> gatherFormIdForPushMsg(@RequestBody @Validated GatherFormIdReq gatherFormIdReq, @ApiIgnore @LoginUser String loginUserNo) {
        try {
            if (StringUtils.isEmpty(gatherFormIdReq.getFormIdList())) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, "收集表单为空,不予处理");
            }

            JSONObject jsonObj = new JSONObject();
            gatherFormIdReq.setUserNo(loginUserNo);
            if (!supportRefService.gatherFormIdForPushMsg(gatherFormIdReq, jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }

            return ResponseVo.success();
        } catch (Exception e) {
            log.error("收集微信用户[{}]formid过程中异常:{}", gatherFormIdReq.getUserNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "获取客户经理所属分公司")
    @PostMapping("/getCompanyOfUm")
    public ResponseVo<GetCompanyOfUmResp> getCompanyOfUm(@RequestBody @Validated GetCompanyOfUmReq getCompanyOfUmReq) {
        try {
            JSONObject jsonObj = new JSONObject();

            GetCompanyOfUmResp getCompanyOfUmResp = userAuthSupportService.getCompanyListOfUser(getCompanyOfUmReq.getSrcUmNo(), jsonObj);

            if (null == getCompanyOfUmResp) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(getCompanyOfUmResp);
        } catch (Exception e) {
            log.error("获取客户经理[{}]所属分公司过程中异常:{}", getCompanyOfUmReq.getSrcUmNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "获取所属分公司")
    @PostMapping("/getCompany")
    public ResponseVo<GetCompanyResp> getCompany() {
        try {
            JSONObject jsonObj = new JSONObject();
            GetCompanyResp getCompanyResp = userAuthSupportService.getCompanyList(jsonObj);

            if (null == getCompanyResp) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(getCompanyResp);
        } catch (Exception e) {
            log.error("获取分公司过程中异常:{}", e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "身份证ocr识别")
    @PostMapping("/ocrForCert")
    public ResponseVo<GetOcrOfCertResp> ocrForCert(@RequestParam("pushOrderNo") String pushOrderNo, @RequestParam("file") MultipartFile file) {
        try {
            JSONObject jsonObj = new JSONObject();
            GetOcrOfCertResp getOcrOfCertResp = ocrForCertSupportService.ocrForCert(pushOrderNo, file, jsonObj);

            if (null == getOcrOfCertResp) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(getOcrOfCertResp);
        } catch (Exception e) {
            log.error("推单号[{}]身份证ocr识别过程中异常:{}", pushOrderNo, e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "校验手机号码")
    @PostMapping("/verifyMobileNo")
    @LoginRole
    public ResponseVo<String> verifyMobileNo(@RequestBody @Validated VerifyMobileNoReq verifyMobileNoReq) {
        try {
            JSONObject jsonObj = new JSONObject();

            if (!supportRefService.verifyMobileNo(verifyMobileNoReq, jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(DpbsCnst.SUCCESS_RTN_CODE);
        } catch (Exception e) {
            log.error("修改手机号[{}]校验手机号过程中异常:{}", verifyMobileNoReq.getMobileNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "查询UM是否存在")
    @PostMapping("/findBySrcUmNo")
    public ResponseVo<GetTeamOfUmResp> findBySrcUmNo(@RequestBody @Validated FindUMReq findUMReq) {
        try {
            JSONObject jsonObject = new JSONObject();
            GetTeamOfUmResp teamListOfUm = marketManagerSupportService.getTeamListOfUm(findUMReq.getSrcUmNo(), jsonObject);
            if (null == teamListOfUm) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, " 邀请码不存在，请联系您的客户经理");
            }
            return new ResponseVo<>(teamListOfUm);
        } catch (Exception e) {
            log.error("查询UM[{}]过程中异常:{}", findUMReq.getSrcUmNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }

    }

    @ApiOperation(value = "刷新缓存")
    @PostMapping("/refreshCache")
    @LoginRole
    public ResponseVo<String> refreshCache() {
        try {
            cacheInitService.initCache();
            return new ResponseVo<>(DpbsCnst.SUCCESS_RTN_CODE);
        } catch (Exception e) {
            log.error("刷新缓存过程中异常:{}", e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

}
