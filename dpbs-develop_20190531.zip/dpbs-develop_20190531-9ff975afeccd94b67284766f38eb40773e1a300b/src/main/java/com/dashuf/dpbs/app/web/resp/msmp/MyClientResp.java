package com.dashuf.dpbs.app.web.resp.msmp;

import java.io.Serializable;

import com.github.pagehelper.PageInfo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "我的客户分页列表Resp")
@Getter
@Setter
public class MyClientResp implements Serializable {
	private static final long serialVersionUID = -7966836728403275180L;

	@ApiModelProperty(value = "客户分页列表")
	private PageInfo<ClientBean> clientBeanPage;
}
