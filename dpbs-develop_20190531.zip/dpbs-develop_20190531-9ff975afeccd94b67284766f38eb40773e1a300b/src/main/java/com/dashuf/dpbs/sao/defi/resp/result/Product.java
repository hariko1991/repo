package com.dashuf.dpbs.sao.defi.resp.result;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class Product implements Serializable {
    private static final long serialVersionUID = 2207855127906695313L;

    /**
     * riskLevel	string	必须
     */
    private String riskLevel;
    /**
     * productId	string	必须
     */
    private String productId;
    /**
     * partnerName	string	必须
     */
    private String partnerName;
    /**
     * loanTerm	number	非必须
     */
    private String loanTerm;
    /**
     * primaryProduct	string	必须
     */
    private String primaryProduct;
    /**
     * entryFlag	string	必须
     */
    private String entryFlag;
    /**
     * calCreditAmt	number	必须
     */
    private String calCreditAmt;

}
