package com.dashuf.dpbs.app.web.req.user;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

/**
 * @author juxiaodong
 * @date 2019/1/3 17:59
 */
@ApiModel(value = "个人中心-修改手机号码")
@Setter
@Getter
public class ModifyPhoneReq {


    /**
     * 手机号码
     */
    @ApiModelProperty(value = "手机号码")
    @NotBlank(message = "请输入正确的手机号")
    @Pattern(regexp = "^[1][0-9]{10}$", message = "请输入正确的手机号")
    private String mobileNo;


    /**
     * 手机验证码
     */
    @ApiModelProperty(value = "手机验证码")
    @NotBlank(message = "请输入验证码")
    private String verifyCode;


}
