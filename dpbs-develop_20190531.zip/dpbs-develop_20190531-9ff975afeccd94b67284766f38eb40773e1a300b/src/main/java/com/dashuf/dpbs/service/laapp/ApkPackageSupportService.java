package com.dashuf.dpbs.service.laapp;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.web.req.QrOfLoanAppReq;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.model.SysConf;
import com.dashuf.dpbs.sao.laapp.ApkPackageSAO;
import com.dashuf.dpbs.sao.laapp.resp.ApkPackageResp;
import com.dashuf.dpbs.service.SysConfSupportService;
import com.dashuf.merlin.web.base.views.ResponseVo;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ApkPackageSupportService {
    private static final String ANDORID = "andorid";
    private static final String ANDORID_APP = "ANDROID";
    private static final String IPHONE = "iphone";

    @Autowired
    private ApkPackageSAO apkPackageSAO;
    @Autowired
    private SysConfSupportService sysConfSupportService;

    public String getLoanAppQr(QrOfLoanAppReq qrOfLoanAppReq, JSONObject jsonObj) {

        if (ANDORID.equals(qrOfLoanAppReq.getDeviceType())) {
            ResponseVo<List<ApkPackageResp>> apkPackageResp = apkPackageSAO.getNewestApk();
            if (DpbsCnst.HTTP_OK.equals(apkPackageResp.getCode())) {

                List<ApkPackageResp> apkPackageList = apkPackageResp.getData();
                if (CollectionUtils.isNotEmpty(apkPackageResp.getData())) {
                    for (ApkPackageResp apkPackage : apkPackageList) {
                        if (ANDORID_APP.equals(apkPackage.getSysType())) {
                            return apkPackage.getApkUrl();
                        }
                    }
                }

                jsonObj.put(DpbsCnst.RTN_MSG, "获取安装包失败");
                return null;
            } else {
                jsonObj.put(DpbsCnst.RTN_MSG, apkPackageResp.getMessage());
                return null;
            }
        } else if (IPHONE.equals(qrOfLoanAppReq.getDeviceType())) {
            SysConf sysConfParam = new SysConf();
            sysConfParam.setModuleCode("download_app");
            sysConfParam.setModuleSubCode("ios_store_url");
            sysConfParam.setModuleKey("ios_store_url");

            return sysConfSupportService.selectValueFromCache(sysConfParam);
        } else {
            jsonObj.put(DpbsCnst.RTN_MSG, "不支持的机型:" + qrOfLoanAppReq.getDeviceType());
            return null;
        }
    }
}
