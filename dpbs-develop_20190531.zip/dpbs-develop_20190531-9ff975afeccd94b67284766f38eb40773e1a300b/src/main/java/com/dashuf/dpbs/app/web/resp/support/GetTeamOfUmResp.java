package com.dashuf.dpbs.app.web.resp.support;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * Created with IDEA
 * author:Likangcheng
 * Date:2019/2/21
 * Time:10:47
 */
@Getter
@Setter
@ApiModel(value = "所属团队")
public class GetTeamOfUmResp implements Serializable {
    private static final long serialVersionUID = -5022814071378612126L;

    @ApiModelProperty(value = "团队集合")
    private List<TeamOfUm> teamOfUmList;


    @ApiModel(value = "用户所属团队")
    @Getter
    @Setter
    public static class TeamOfUm {

        @ApiModelProperty(value = "公司编码")
        private String companyCode;


        @ApiModelProperty(value = "公司名称")
        private String companyName;

        @ApiModelProperty(value = "团队编码")
        private String teamCode;


        @ApiModelProperty(value = "团队名称")
        private String teamName;

        @ApiModelProperty(value = "客户经理名称")
        private String uMName;

        @ApiModelProperty(value = "客户经理编码")
        private String uMNo;

        @ApiModelProperty(value = "客户经理手机")
        private String srcUmMobileNo;


    }

}
