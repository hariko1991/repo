package com.dashuf.dpbs.app.web.req.credit;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "刷新征信授权二维码Req")
@Getter
@Setter
public class RefreshQrCodeReq implements Serializable {
	private static final long serialVersionUID = 6187887592207944587L;

	@ApiModelProperty(value = "推送订单编号", required = true)
	@NotBlank(message = "推送订单编号不能为空")
	private String pushOrderNo;
}
