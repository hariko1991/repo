package com.dashuf.dpbs.app.web.resp.business;

import lombok.Getter;
import lombok.Setter;

import java.math.BigDecimal;
import java.util.Date;

@Setter
@Getter
public class PushLoanStatus {

    private String applicationId;
    
    private String pushOrderNo;

    private String loanStatusCode;

    private String loanStatusDesc;

    private String productStatusCode;

    private String productStatusDesc;

    private String productId;

    private String putoutNo;

    private Date putoutDate;

    private BigDecimal putoutAmt;

}
