package com.dashuf.dpbs.sao.defi.req.apply;

import com.dashuf.dpbs.sao.defi.resp.result.Product;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Getter
@Setter
public class Application implements Serializable {
    private static final long serialVersionUID = 6566166065051108116L;

    /**
     * source	null 必须 业务来源
     */
    private String source;
    /**
     * 决策区域
     */
    private String decisionArea;

    /**
     * applicationDate	string 必须 申请日期
     */
    private String applicationDate;
    /**
     * applicationNumber	string 必须 申请编号
     */
    private String applicationNumber;
    /**
     * callNode	string 必须 决策节点编号
     */
    private String callNode;
    /**
     * flowStep	string 必须 流程阶段
     */
    private String flowStep;
    /**
     * 冠军挑战者随机数
     */
    private String randomDigit;
    /**
     * mqcode	null 非必须 面签意见代码
     */
    private String mqcode;
    /**
     * decisionUser	string 必须 决策调用方
     */
    private String decisionUser;
    /**
     * mhcode	null 非必须 面核意见代码
     */
    private String mhcode;

    @JsonProperty(value = "IDMaturity")
    private String certMaturity;
    /**
     * HouseAddress	string 必须  房产地址
     */
    @JsonProperty(value = "HouseAddress")
    private String houseAddress;
    /**
     * Area	string 必须 房产面积
     */
    @JsonProperty(value = "Area")
    private String area;
    /**
     * MorLoan	string 必须 是否抵押
     */
    @JsonProperty(value = "MorLoan")
    private String morLoan;
    /**
     * MutLoanBalance	string 必须  借款人和所有共同产权人在我司的房产贷贷款总余额
     */
    @JsonProperty(value = "MutLoanBalance")
    private String mutLoanBalance;
    /**
     * PreMorAgencyType	string 必须 一押机构类型
     */
    @JsonProperty(value = "PreMorAgencyType")
    private String preMorAgencyType;
    /**
     * PreMorAgency	string 必须  一押抵押机构名称
     */
    @JsonProperty(value = "PreMorAgency")
    private String preMorAgency;
    /**
     * PreMorTerm	integer 必须  一押期限
     */
    @JsonProperty(value = "PreMorTerm")
    private String PreMorTerm;
    /**
     * PreEstimatedClearDate	string 必须 预计结清日期
     */
    @JsonProperty(value = "PreEstimatedClearDate")
    private Date preEstimatedClearDate;
    /**
     * PreMorType	string 必须 一押抵押方式
     */
    @JsonProperty(value = "PreMorType")
    private String preMorType;
    /**
     * PreMorPaymentMethod	string 必须 一押还款方式
     */
    @JsonProperty(value = "PreMorPaymentMethod")
    private String preMorPaymentMethod;


    private List<ApplicationForm> applicationForm;

    private List<Applicant> applicant;

    private List<AmtCalcInfo> amtCalcInfo;

    private List<CustMgrInfo> custMgrInfo;

    private List<HousePropertyInfo> housePropertyInfo;

    private List<InsuranceInfo> insuranceInfo;

    private List<ProductInfo> applicationProductInfo;

}
