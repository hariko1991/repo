package com.dashuf.dpbs.job;

import com.alibaba.fastjson.JSON;
import com.dangdang.ddframe.job.api.ShardingContext;
import com.dangdang.ddframe.job.api.simple.SimpleJob;
import com.dashuf.dpbs.cnst.StatusCnst;
import com.dashuf.dpbs.mapper.LoanStatusMapMapper;
import com.dashuf.dpbs.mapper.PushLoanProductMapper;
import com.dashuf.dpbs.mapper.PushOrderLogMapper;
import com.dashuf.dpbs.model.LoanStatusMap;
import com.dashuf.dpbs.model.PushLoanProduct;
import com.dashuf.dpbs.model.PushOrderLog;
import com.dashuf.dpbs.sao.cids.resp.GetCreditStatusOfChargeOffDetail;
import com.dashuf.dpbs.sao.cids.resp.GetCreditStatusResp;
import com.dashuf.dpbs.sao.cpms.ClientTradingSAO;
import com.dashuf.merlin.core.support.MyThreadContext;
import com.dashuf.merlin.util.UUIDShort;
import com.dashuf.merlin.web.base.utils.ResponseHelper;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.log4j.MDC;
import org.joda.time.DateTime;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author yaojiaoyi
 * 定时获取信贷状态
 */
@Slf4j
@Component
public class PullLoanStatusJob implements SimpleJob {
    @Autowired
    private PushOrderLogMapper pushOrderLogMapper;
    @Autowired
    private ClientTradingSAO clientTradingSAO;
    @Autowired
    private PushLoanProductMapper pushLoanProductMapper;
    @Autowired
    private LoanStatusMapMapper loanStatusMapMapper;
    private static final String SOURCECODE = "DISP";
    //审批否决状态
    private static final String APPROVAL_VETO = "apr_reject";

    @Override
    public void execute(ShardingContext shardingContext) {
        String traceId = UUIDShort.generate();
        MDC.put(MyThreadContext.MDC_TRACE_ID, traceId);
        DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd HH:mm:ss");
        List<LoanStatusMap> list = loanStatusMapMapper.selectByModelSelective(new LoanStatusMap(), true);
        Map<String, LoanStatusMap> statusMap = list.stream().collect(Collectors.toMap(LoanStatusMap::getStatus, a -> a, (k1, k2) -> k1));
        List<PushOrderLog> pushOrderLogList = pushOrderLogMapper.getPullStatusOrderList();
        for (PushOrderLog pushOrderLog : pushOrderLogList) {
            try {
                GetCreditStatusResp creditStatusResp = ResponseHelper.of(clientTradingSAO.pullLoanStatus(null, pushOrderLog.getPushOrderNo(), SOURCECODE));
                log.info("获取信贷数据，creditStatusResp={}", JSON.toJSONString(creditStatusResp));
                if (null == creditStatusResp) {
                    continue;
                }

                List<GetCreditStatusOfChargeOffDetail> allotList = creditStatusResp.getAccountList();
                String firstStatus = null;
                String secondStatus = null;
                BigDecimal loanAmt = BigDecimal.ZERO;
                for (int i = 0; CollectionUtils.isNotEmpty(allotList) && i < allotList.size(); i++) {
                    if (i == 0) {
                        firstStatus = StringUtils.isBlank(allotList.get(0).getAccountAllotCode()) ? null : statusMap.get(allotList.get(0).getAccountAllotCode()).getMapCode();
                    }
                    if (i == 1) {
                        secondStatus = StringUtils.isBlank(allotList.get(1).getAccountAllotCode()) ? null : statusMap.get(allotList.get(1).getAccountAllotCode()).getMapCode();
                    }

                    GetCreditStatusOfChargeOffDetail allotProduct = allotList.get(i);
                    if (StringUtils.isNotBlank(allotProduct.getAccountAllotCode()) && StatusCnst.LOAN_SUCCESS.equals(statusMap.get(allotProduct.getAccountAllotCode()).getMapCode())) {
                        loanAmt = loanAmt.add(Optional.ofNullable(allotProduct.getPutoutAmt()).orElse(BigDecimal.ZERO));
                    }
                    String productStatus = allotProduct.getAccountAllotCode();
                    if (StringUtils.isEmpty(productStatus) && creditStatusResp.getLoanStatus().equals(StatusCnst.CUST_WAIVE)) {
                        productStatus = StatusCnst.CUST_WAIVE;
                    } else if (!allotProduct.isAvailableInd()) {
                        productStatus = APPROVAL_VETO;
                    } else {
                        productStatus = allotProduct.getAccountAllotCode();
                    }
                    PushLoanProduct pushLoanProductCond = new PushLoanProduct();
                    pushLoanProductCond.setPushOrderNo(pushOrderLog.getPushOrderNo());
                    pushLoanProductCond.setProductId(allotProduct.getProductId());
                    PushLoanProduct pushLoanProduct = pushLoanProductMapper.selectOneByModelSelective(pushLoanProductCond, true);
                    if (pushLoanProduct != null) {
                        pushLoanProduct.setPutoutAmt(allotProduct.getPutoutAmt());
                        pushLoanProduct.setProductId(allotProduct.getProductId());
                        pushLoanProduct.setPutoutNo(allotProduct.getAccountAllotId());
                        //出账成功，更新出账时间
                        if (StringUtils.isNotBlank(allotProduct.getAccountAllotCode()) && StatusCnst.LOAN_SUCCESS.equals(statusMap.get(allotProduct.getAccountAllotCode()).getMapCode())) {
                            pushLoanProduct.setPutoutDate(StringUtils.isBlank(allotProduct.getPutoutDate()) ? new Date() : DateTime.parse(allotProduct.getPutoutDate(), formatter).toDate());
                        }
                        //状态变更为放款否决，设置当前时间为放款否决时间
                        if (StringUtils.isNotBlank(allotProduct.getAccountAllotCode()) && StatusCnst.LOAN_VETO.equals(statusMap.get(allotProduct.getAccountAllotCode()).getMapCode()) &&
                                (StringUtils.isNotBlank(pushLoanProduct.getPutoutStatus()) && !StatusCnst.LOAN_VETO.equals(statusMap.get(pushLoanProduct.getPutoutStatus()).getMapCode()))) {
                            pushLoanProduct.setPutoutDate(new Date());
                        }
                        //审批否决，设置当前时间为审批否决时间
                        if (StringUtils.isNotBlank(allotProduct.getAccountAllotCode()) && StatusCnst.APPROVAL_VETO.equals(statusMap.get(allotProduct.getAccountAllotCode()).getMapCode()) &&
                                (StringUtils.isNotBlank(pushLoanProduct.getPutoutStatus()) && !StatusCnst.APPROVAL_VETO.equals(statusMap.get(pushLoanProduct.getPutoutStatus()).getMapCode()))) {
                            pushLoanProduct.setPutoutDate(new Date());
                        }
                        //客户放弃，设置当前时间为放款否决时间
                        if (StringUtils.isNotBlank(allotProduct.getAccountAllotCode()) && StatusCnst.CUST_WAIVE.equals(statusMap.get(allotProduct.getAccountAllotCode()).getMapCode()) &&
                                !StatusCnst.CUST_WAIVE.equals(pushLoanProduct.getPutoutStatus())) {
                            pushLoanProduct.setPutoutDate(new Date());
                        }
                        pushLoanProduct.setPutoutStatus(productStatus);
                        pushLoanProduct.setMapStatusDesc(StringUtils.isBlank(productStatus) ? null : statusMap.get(productStatus).getMapDesc());
                        pushLoanProductMapper.updateByModelSelective(pushLoanProductCond, true, pushLoanProduct);
                    } else {
                        PushLoanProduct pushLoanProductInsert = new PushLoanProduct();
                        pushLoanProductInsert.setPutoutAmt(allotProduct.getPutoutAmt());
                        pushLoanProductInsert.setApplicationId(creditStatusResp.getApplicationId());
                        pushLoanProductInsert.setPutoutStatus(productStatus);
                        pushLoanProductInsert.setMapStatusDesc(StringUtils.isBlank(productStatus) ? null : statusMap.get(productStatus).getMapDesc());

                        pushLoanProductInsert.setPutoutNo(allotProduct.getAccountAllotId());
                        pushLoanProductInsert.setPutoutDate(StringUtils.isBlank(allotProduct.getPutoutDate()) ? null : DateTime.parse(allotProduct.getPutoutDate(), formatter).toDate());
                        pushLoanProductInsert.setProductId(allotProduct.getProductId());
                        pushLoanProductInsert.setPushOrderNo(pushOrderLog.getPushOrderNo());
                        pushLoanProductInsert.setApplicationId(creditStatusResp.getApplicationId());
                        pushLoanProductMapper.insertSelective(pushLoanProductInsert);
                    }
                }
                //更新审批状态
                PushOrderLog param = new PushOrderLog();
                param.setId(pushOrderLog.getId());
                param.setLoanPayAmt(loanAmt);
                //两个都放款否决则显示大数否决
                if (StatusCnst.LOAN_VETO.equals(firstStatus) && StatusCnst.LOAN_VETO.equals(secondStatus)) {
                    param.setPushStatus(StatusCnst.LOAN_VETO);
                }
                //两个产品，一个放款否决一个审批否决，显示放款否决
                else if (StatusCnst.LOAN_VETO.equals(firstStatus) && StatusCnst.APPROVAL_VETO.equals(secondStatus)) {
                    param.setPushStatus(StatusCnst.LOAN_VETO);
                } else if (StatusCnst.APPROVAL_VETO.equals(firstStatus) && StatusCnst.LOAN_VETO.equals(secondStatus)) {
                    param.setPushStatus(StatusCnst.LOAN_VETO);
                } else if (CollectionUtils.isNotEmpty(allotList) && allotList.size() == 1 && (StatusCnst.LOAN_VETO.equals(firstStatus) || StatusCnst.LOAN_VETO.equals(secondStatus))) {
                    param.setPushStatus(StatusCnst.LOAN_VETO);
                }
                //两个产品都是客户放弃
                else if (StatusCnst.CUST_WAIVE.equals(firstStatus) && StatusCnst.CUST_WAIVE.equals(secondStatus)) {
                    param.setPushStatus(StatusCnst.CUST_WAIVE);
                } else if (CollectionUtils.isNotEmpty(allotList) && allotList.size() == 1 && (StatusCnst.CUST_WAIVE.equals(firstStatus) || StatusCnst.CUST_WAIVE.equals(secondStatus))) {
                    param.setPushStatus(StatusCnst.CUST_WAIVE);
                }
                //两个产品一个被否决、一个客户放弃则放款否决
                else if (StatusCnst.LOAN_VETO.equals(firstStatus) && StatusCnst.CUST_WAIVE.equals(secondStatus)) {
                    param.setPushStatus(StatusCnst.LOAN_VETO);
                } else if (StatusCnst.CUST_WAIVE.equals(firstStatus) && StatusCnst.LOAN_VETO.equals(secondStatus)) {
                    param.setPushStatus(StatusCnst.LOAN_VETO);
                }
                //两个有一个放款成功则显示放款成功
                else if (StatusCnst.LOAN_SUCCESS.equals(firstStatus) || StatusCnst.LOAN_SUCCESS.equals(secondStatus)) {
                    param.setPushStatus(StatusCnst.LOAN_SUCCESS);
                } else {
                    //否则放款审批中
                    if (!pushOrderLog.getPushStatus().equals(statusMap.get(creditStatusResp.getLoanStatus()).getMapCode())) {
                        param.setPushStatus(statusMap.get(creditStatusResp.getLoanStatus()).getMapCode());
                        param.setApprovalTime(new Date());
                    }
                }
                pushOrderLogMapper.updateByPrimaryKeySelective(param);
            } catch (Exception e) {
                log.error("定时任务出错，推单编号={},e={}", pushOrderLog.getPushOrderNo(), e);
                continue;
            }

        }
    }
}
