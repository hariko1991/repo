package com.dashuf.dpbs.app.web.req.lawsuit;

import lombok.Getter;
import lombok.Setter;

/**
 * @author yaojiaoyi 汇法网请求结果
 */
@Getter
@Setter
public class LawsuitParamReq {
    private String identifying_code;

    private String stype;

    private String id;

    private String n;
}
