package com.dashuf.dpbs.app.web.resp;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class QrCodeResp implements Serializable {

    @ApiModelProperty(value = "二维码地址", required = true)
    private String qrCodeUrl;

    @ApiModelProperty(value = "客户姓名", required = true)
    private String clientName;

    @ApiModelProperty(value = "身份证号码", required = true)
    private String certNo;

    @ApiModelProperty(value = "手机号码", required = true)
    private String mobileNo;

    @ApiModelProperty(value = "依据返回码进行操作")
    private String rtnCode;

    @ApiModelProperty(value = "返回码对应信息")
    private String rtnMsg;

}
