package com.dashuf.dpbs.service.support.dto;

import java.io.Serializable;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class ElecCreditAuthDto implements Serializable {
    private static final long serialVersionUID = -3637754624377539318L;
    private String moduleCode;
    private String moduleSubCode;
    private String certNo;
    private String certName;
    private String mobileNo;
    private String fileName;

    private boolean isSave = Boolean.FALSE;
}
