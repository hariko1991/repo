package com.dashuf.dpbs.app.web.req.cids;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@ApiModel(value = "通知信贷状态req")
@Getter
@Setter
public class NotifyCreditStatusReq implements Serializable {
    private static final long serialVersionUID = -7161700800267091823L;
    /**
     * loanApplicationNum	string 必须 信贷申请编号
     */
    @ApiModelProperty(value = "信贷申请编号")
    private String loanApplicationNum;
    /**
     * applicationNum	string 必须 申请编号
     */
    @ApiModelProperty(value = "渠道申请编号", required = true)
    @NotBlank(message = "渠道申请编号不能为空")
    private String applicationNum;
    /**
     * currentProcessName	string 必须 审批状态
     */
    @ApiModelProperty(value = "审批状态")
    private String currentProcessName;
    /**
     * putoutNum	string　必须　出账编号
     */
    @ApiModelProperty(value = "出账编号")
    private String putoutNum;
    /**
     * accountBusinessCd	string 必须 出账状态
     */
    @ApiModelProperty(value = "出账状态")
    private String accountBusinessCd;
    /**
     * channelNum	string 必须 渠道来源  LY/BK
     */
    @ApiModelProperty(value = "出账状态")
    private String channelNum;
    /**
     * ecifCustomerNum	string 必须 ecif客户号
     */
    private String ecifCustomerNum;
    /**
     * dataSourceChannelNum	string 必须 业务来源
     */
    private String dataSourceChannelNum;
    /**
     * putoutDt	string 必须 放款日期
     */
    private String putoutDt;
    /**
     * putoutAmt	string 必须　放款金额
     */
    private String putoutAmt;
    /**
     * productNo	string 必须 贷款产品ID，半刻专用
     */
    private String productNo;
    /**
     * productName	string 非必须 贷款产品名称，半刻专用
     */
    private String productName;
    /**
     * loanTermCnt	string 必须 贷款期限，半刻专用
     */
    private String loanTermCnt;
    /**
     * patchInd	boolean  非必须 是否需要补件，大道专用
     */
    private String patchInd;
}
