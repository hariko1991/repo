package com.dashuf.dpbs.app.web;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.SysConfCnst;
import com.dashuf.dpbs.service.support.VerifyCodeService;
import com.dashuf.dpbs.app.annotation.LoginRole;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dashuf.dpbs.app.DpbsUrl;
import com.dashuf.dpbs.app.web.req.support.GetVerifyCodeReq;
import com.dashuf.merlin.web.base.views.ResponseVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Api(value = "短信验证码相关", tags = {"短信验证码相关"})
@Slf4j
@RestController
@RequestMapping(DpbsUrl.VERIFY_CODE_REF)
public class VerifyCodeController {
    @Autowired
    private VerifyCodeService verifyCodeService;

    @ApiOperation(value = "发送验证码")
    @PostMapping("/getVerifyCode")
    @LoginRole
    public ResponseVo<String> getVerifyCode(@RequestBody @Validated GetVerifyCodeReq getVerifyCodeReq) {
        try {
            JSONObject jsonObj = new JSONObject();

            String moduleCode = StringUtils.isEmpty(getVerifyCodeReq.getModuleCode()) ? SysConfCnst.MODULE_CODE_OF_UNIFY_VERIFY_CODE : getVerifyCodeReq.getModuleCode();
            if (!verifyCodeService.sendVerifyCode(moduleCode, getVerifyCodeReq.getMobileNo(), jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(DpbsCnst.SUCCESS_RTN_CODE);
        } catch (Exception e) {
            log.error("手机号[{}]发送验证码过程中异常:{}", getVerifyCodeReq.getMobileNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

}
