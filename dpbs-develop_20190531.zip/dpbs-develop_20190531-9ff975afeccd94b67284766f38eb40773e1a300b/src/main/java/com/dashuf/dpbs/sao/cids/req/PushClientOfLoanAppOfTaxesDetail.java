package com.dashuf.dpbs.sao.cids.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
public class PushClientOfLoanAppOfTaxesDetail implements Serializable {
    /**
     * earliestTaxesDttm	string 非必须 借款人最早交税日期（有企业税时必传）
     */
    private String earliestTaxesDttm;
    /**
     * nearlyYearTaxesAmt	number 非必须 近一年缴税金额（有企业税时必传 只能含两位小数）
     */
    private BigDecimal nearlyYearTaxesAmt;
    /**
     * outstandingTaxesInd	string 非必须 是否有未缴清税款 0： 否， 1： 是（有企业税时必传）
     */
    private String outstandingTaxesInd;
}
