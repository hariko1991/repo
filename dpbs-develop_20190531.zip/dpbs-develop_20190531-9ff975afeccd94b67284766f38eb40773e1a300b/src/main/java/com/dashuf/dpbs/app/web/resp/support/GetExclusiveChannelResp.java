package com.dashuf.dpbs.app.web.resp.support;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@ApiModel(value = "用户所属公司查询resp")
@Getter
@Setter
public class GetExclusiveChannelResp implements Serializable {

    @ApiModelProperty(value = "所属公司列表")
    private List<ExclusiveChannel> channelList;

    @Getter
    @Setter
    @ApiModel(value = "用户所属公司查询resp")
    public static class ExclusiveChannel {
        @ApiModelProperty(value = "所属公司编码")
        private String channelCode;
        @ApiModelProperty(value = "所属公司名称")
        private String channelName;
    }
}
