package com.dashuf.dpbs.mapper;

import org.apache.ibatis.annotations.Mapper;

import com.dashuf.dpbs.model.SysConf;

import java.util.List;

@Mapper
public interface SysConfMapper {

    public String selectValue(SysConf sysConf);

    public int updateValue(SysConf sysConf);

    public List<SysConf> selectSysConfList();
}