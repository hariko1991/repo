package com.dashuf.dpbs.sao.defi.req.apply;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class Customer implements Serializable {
    private static final long serialVersionUID = 7221819038334589534L;

    /**
     * CUSTOMER_TYPE	string 必须 客户类型
     */
    @JsonProperty(value = "CUSTOMER_TYPE")
    private String customerType;
    /**
     * CUSTOMER_NAME	string 必须 客户姓名
     */
    @JsonProperty(value = "CUSTOMER_NAME")
    private String customerName;
    /**
     * CERT_TYPE	string 必须 证件类型
     */
    @JsonProperty(value = "CERT_TYPE")
    private String certType;
    /**
     * CERT_ID	string 必须 证件号码
     */
    @JsonProperty(value = "CERT_ID")
    private String certId;
    /**
     * PHONE_NUMBER	string 必须 手机号码
     */
    @JsonProperty(value = "PHONE_NUMBER")
    private String phoneNumber;
    /**
     * EMPLOYEE_TYPE	string 必须 客户职业类型
     */
    @JsonProperty(value = "EMPLOYEE_TYPE")
    private String employeeType;
    /**
     * CREDIT_REPORT_ID	string 非必须 征信报告编号
     */
    @JsonProperty(value = "CREDIT_REPORT_ID")
    private String creditReportId;
    /**
     * COMPANY_NAME	string  非必须 公司名称
     */
    @JsonProperty(value = "COMPANY_NAME")
    private String companyName;
    /**
     * COMPANY_CODE	string 非必须 组织机构代码
     */
    @JsonProperty(value = "COMPANY_CODE")
    private String companyCode;
    /**
     * ACCOUNT_EMAIL	string 非必须 邮箱
     */
    @JsonProperty(value = "ACCOUNT_EMAIL")
    private String accountEmail;
    /**
     * QQ_NUMBER	string 非必须 QQ号
     */
    @JsonProperty(value = "QQ_NUMBER")
    private String qqNumber;
    /**
     * CONTACT1_NAME	string 必须 第一联系人姓名
     */
    @JsonProperty(value = "CONTACT1_NAME")
    private String contact1Name;
    /**
     * CONTACT1_ID_NUMBER	string 必须 第一联系人身份证
     */
    @JsonProperty(value = "CONTACT1_ID_NUMBER")
    private String contact1IdNumber;
    /**
     * CONTACT1_MOBILE	string 必须 第一联系人手机
     */
    @JsonProperty(value = "CONTACT1_MOBILE")
    private String contact1Mobile;
    /**
     * CONTACT1_RELATION	string 必须 第一联系人关系
     */
    @JsonProperty(value = "CONTACT1_RELATION")
    private String contact1Relation;
    /**
     * CONTACT2_NAME	string 必须 第二联系人姓名
     */
    @JsonProperty(value = "CONTACT2_NAME")
    private String contact2Name;
    /**
     * CONTACT2_ID_NUMBER	string 必须 第二联系人身份证
     */
    @JsonProperty(value = "CONTACT2_ID_NUMBER")
    private String contact2IdNumber;
    /**
     * CONTACT2_MOBILE	string　必须 第二联系人手机
     */
    @JsonProperty(value = "CONTACT2_MOBILE")
    private String contact2Mobile;
    /**
     * CONTACT2_RELATION	string　必须　第二联系人关系
     */
    @JsonProperty(value = "CONTACT2_RELATION")
    private String contact2Relation;
    /**
     * CONTACT3_NAME	string　必须　第三联系人姓名
     */
    @JsonProperty(value = "CONTACT3_NAME")
    private String contact3Name;
    /**
     * CONTACT3_ID_NUMBER	string　必须　第三联系人身份证
     */
    @JsonProperty(value = "CONTACT3_ID_NUMBER")
    private String contact3IdNumber;
    /**
     * CONTACT3_MOBILE	string  必须　第三联系人手机
     */
    @JsonProperty(value = "CONTACT3_MOBILE")
    private String contact3Mobile;
    /**
     * CONTACT3_RELATION	string 必须 第三联系人关系
     */
    @JsonProperty(value = "CONTACT3_RELATION")
    private String contact3Relation;
    /**
     * CONTACT4_NAME	string 非必须  第四联系人姓名
     */
    @JsonProperty(value = "CONTACT4_NAME")
    private String contact4Name;
    /**
     * CONTACT4_ID_NUMBER	string 非必须  第四联系人身份证
     */
    @JsonProperty(value = "CONTACT4_ID_NUMBER")
    private String contact4IdNumber;
    /**
     * CONTACT4_MOBILE	string 非必须 第四联系人手机
     */
    @JsonProperty(value = "CONTACT4_MOBILE")
    private String contact4Mobile;
    /**
     * CONTACT4_RELATION	string 非必须  第四联系人关系
     */
    @JsonProperty(value = "CONTACT4_RELATION")
    private String contact4Relation;
    /**
     * CONTACT5_NAME	string 非必须  第五联系人姓名
     */
    @JsonProperty(value = "CONTACT5_NAME")
    private String contact5Name;
    /**
     * CONTACT5_ID_NUMBER	string  非必须  第五联系人身份证
     */
    @JsonProperty(value = "CONTACT5_ID_NUMBER")
    private String contact5IdNumber;
    /**
     * CONTACT5_MOBILE	string 非必须  第五联系人手机
     */
    @JsonProperty(value = "CONTACT5_MOBILE")
    private String contact5Mobile;
    /**
     * CONTACT5_RELATION	string 非必须  第五联系人关系
     */
    @JsonProperty(value = "CONTACT5_RELATION")
    private String contact5Relation;
    /**
     * WORK_CORP	string 必须  公司名称
     */
    @JsonProperty(value = "WORK_CORP")
    private String workCorp;
    /**
     * OPERATE_USER_ID	string 必须  客户经理ID
     */
    @JsonProperty(value = "OPERATE_USER_ID")
    private String operateUserId;
    /**
     * CHANNEL	string 必须 渠道编号
     */
    @JsonProperty(value = "CHANNEL")
    private String channel;
}
