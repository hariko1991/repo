package com.dashuf.dpbs.sao.defi.resp;

import com.dashuf.dpbs.sao.defi.resp.result.IcDecision;
import com.dashuf.dpbs.sao.defi.resp.result.Product;
import com.dashuf.dpbs.sao.defi.resp.result.RuleDecision;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
public class GetDecisionResultResp implements Serializable {
    private static final long serialVersionUID = 505501403482829574L;

    /**
     * DECISION_ID	string 非必须 决策编号
     */
    @JsonProperty(value = "DECISION_ID")
    private String decisionId;
    /**
     * RETMSG	string 非必须 调用接口异常信息
     */
    @JsonProperty(value = "RETMSG")
    private String retMsg;
    /**
     * RETCODE	string 非必须 调用接口返回码 SUC000成功
     */
    @JsonProperty(value = "RETCODE")
    private String retCode;
    /**
     * SYSTEM_ID	string 非必须 调用系统编号
     */
    @JsonProperty(value = "SYSTEM_ID")
    private String systemId;

    private List<RuleDecision> ruleDecision;

    private List<Product> productSelected;

    private List<IcDecision> icDecision;
}
