package com.dashuf.dpbs.app.web.resp.support;

import java.io.Serializable;
import java.util.List;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "上传影像Resp")
@Getter
@Setter
public class UploadMovieResp implements Serializable{

	private static final long serialVersionUID = 3067850567235022807L;

	/**
	 * 流水号
	 */
	@ApiModelProperty(value = "流水号")
	private String applicationId;

	/**
	 * 影象批次号
	 */
	@ApiModelProperty(value = "影象批次号")
	private String contentId;

	/**
	 * 上传文件集合
	 */
	@ApiModelProperty(value = "上传文件集合")
	private List<String> fileIdList;

}
