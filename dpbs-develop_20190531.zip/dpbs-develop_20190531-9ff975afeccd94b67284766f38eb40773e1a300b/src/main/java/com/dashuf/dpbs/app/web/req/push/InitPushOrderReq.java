package com.dashuf.dpbs.app.web.req.push;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "初始化推单请求req")
@Getter
@Setter
public class InitPushOrderReq implements Serializable {
    private static final long serialVersionUID = -4119924057483926542L;
    @ApiModelProperty(value = "用户编号", required = true)
    private String userNo;
}
