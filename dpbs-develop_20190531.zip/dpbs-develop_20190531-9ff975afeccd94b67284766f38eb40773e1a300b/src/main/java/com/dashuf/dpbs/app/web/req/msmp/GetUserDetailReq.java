package com.dashuf.dpbs.app.web.req.msmp;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "获取用户相关Req")
@Getter
@Setter
public class GetUserDetailReq implements Serializable {
	private static final long serialVersionUID = 2276195786829748733L;

	@ApiModelProperty(value = "用户编号")
	@NotBlank(message = "请输入用户编号")
	private String userNo;
}
