package com.dashuf.dpbs.sao.cids.resp;

import lombok.Getter;

import java.io.Serializable;

@Getter
public class PushClientOfStoreDetail implements Serializable {
    /**
     * address	string 必须 门店地址
     */
    private String address;
    /**
     * serviceId	string 必须 门店id
     */
    private String serviceId;
    /**
     * serviceName	string 必须 门店名称
     */
    private String serviceName;
    /**
     * serviceMobilePhoneNum string 必须 联系电话
     */
    private String serviceMobilePhoneNum;
}
