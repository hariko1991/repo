package com.dashuf.dpbs.sao.cids.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class GiveScoreDs020Req implements Serializable {
    /**
     * creditReportNum	string 非必须 征信编号
     */
    private String creditReportNum;
    /**
     * channelNum	string 必须 渠道号
     */
    private String channelNum;
    /**
     * applicationdtTm	string 必须 申请时间
     */
    private String applicationdtTm;
    /**
     * applicationNum	string 必须 申请号码  渠道标志大道订单编号
     */
    private String applicationNum;
    /**
     * fullName	string 必须 姓名
     */
    private String fullName;
    /**
     * genderCd	string 必须 性别
     */
    private String genderCd;
    /**
     * borrowerTelephoneNum	string 必须 借款人手机号码
     */
    private String borrowerTelephoneNum;
    /**
     * ageVal	string 必须 年龄
     */
    private String ageVal;
    /**
     * idNum	string 必须 身份证号
     */
    private String idNum;
    /**
     * licOrgPlName	string 非必须 发证机关所在地
     */
    private String licOrgPlName;
    /**
     * identificationExpireDt	string 非必须 证件到期日
     */
    private String identificationExpireDt;
    /**
     * permanentAddressVal	string 非必须 户籍地址
     */
    private String permanentAddressVal;
    /**
     * applicationAmt	string 非必须 申请金额
     */
    private String applicationAmt;
    /**
     * applicationTermVal	string 非必须 申请期限
     */
    private String applicationTermVal;
    /**
     * areaCd	string 必须 地区编码
     */
    private String areaCd;
    /**
     * customerTypeCd	string 必须 客户类型编码
     */
    private String customerTypeCd;
    /**
     * productNum	string 非必须  产品号
     */
    private String productNum;
    /**
     * liveAddressVal	string 非必须 居住地址
     */
    private String liveAddressVal;
    /**
     * workAddressVal	string 非必须  工作地址
     */
    private String workAddressVal;
    /**
     * regBusinessLicenseInd	string 非必须  是否注册营业执照
     */
    private String regBusinessLicenseInd;
    /**
     * shareholderInd	string 非必须  是否为股东
     */
    private String shareholderInd;
    /**
     * legalPersonInd	string 非必须 是否为法人
     */
    private String legalPersonInd;
    /**
     * lifeInsurancePolicyInd	string 非必须 是否有寿险保单
     */
    private String lifeInsurancePolicyInd;
    /**
     * insuranceCompanyName	string 非必须 保险公司名称
     */
    private String insuranceCompanyName;
    /**
     * yearInsuranceFeeAmt	string 非必须 年缴保费
     */
    private String yearInsuranceFeeAmt;
    /**
     * policyStartPaymentYearDt	string 非必须 保单最早缴费年
     */
    private String policyStartPaymentYearDt;
    /**
     * houseInd	string 必须 房产标识
     */
    private String houseInd;
    /**
     * housePropertyAddressDesc	string 非必须  房产详细地址
     */
    private String housePropertyAddressDesc;
    /**
     * houseTypeCd	string 非必须 房产类型
     */
    private String houseTypeCd;
    /**
     * houseValueAmt	string 非必须 房产价值
     */
    private String houseValueAmt;
    /**
     * carLoanInd	string 非必须 车贷标识
     */
    private String carLoanInd;
    /**
     * carLoanAmt	string 非必须 汽车贷款金额
     */
    private String carLoanAmt;
}
