package com.dashuf.dpbs.cnst;

public final class SaoCnst {
    public static final String SAO_SUCCESS_00 = "00";

    public static final String SAO_CODE = "code";
    public static final String SAO_MESSAGE = "message";
}
