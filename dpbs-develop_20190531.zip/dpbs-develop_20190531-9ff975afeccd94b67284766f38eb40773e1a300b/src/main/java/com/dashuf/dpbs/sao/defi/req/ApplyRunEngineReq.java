package com.dashuf.dpbs.sao.defi.req;

import com.dashuf.dpbs.sao.defi.req.apply.Business;
import com.dashuf.dpbs.sao.defi.req.apply.Customer;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
public class ApplyRunEngineReq implements Serializable {
    private static final long serialVersionUID = -3974144435365748974L;

    /**
     * SYSTEM_ID	string 必须  系统编号
     */
    @JsonProperty(value = "SYSTEM_ID")
    private String systemId;
    /**
     * APPLY_ID	string 必须 申请编号
     */
    @JsonProperty(value = "APPLY_ID")
    private String applyId;

    /**
     * TRADE_ID	string 必须 交易编号
     */
    @JsonProperty(value = "TRADE_ID")
    private String tradeId;
    /**
     * ENGINE_NODE	string 必须 引擎节点
     */
    @JsonProperty(value = "ENGINE_NODE")
    private String engineNode;
    /**
     * INVOKE_TYPE	string 必须 调用方式(SYN-同步 MSG-异步)
     */
    @JsonProperty(value = "INVOKE_TYPE")
    private String invokeType;
    /**
     * CALL_BACK_PROGRAM	string 必须  回调程序
     */
    @JsonProperty(value = "CALL_BACK_PROGRAM")
    private String callBackProgram;

    /**
     * FICO_SCORE_WANTED	是否调用FICO评分	VARCHAR	N	0-不调 1-调用
     */
    @JsonProperty(value = "FICO_SCORE_WANTED")
    private String ficoScoreWanted;

    @JsonProperty(value = "CUSTOMER_LIST")
    private List<Customer> customerList;

    @JsonProperty(value = "BUSINESS")
    private Business business;
}
