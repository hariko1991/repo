package com.dashuf.dpbs.service.blaze;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.cnst.DashufBlazeCnst;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.DpbsStatusCnst;
import com.dashuf.dpbs.mapper.ThirdPartyAccessMapper;
import com.dashuf.dpbs.model.PushOrderLog;
import com.dashuf.dpbs.sao.laapp.AppBlazeSAO;
import com.dashuf.dpbs.sao.laapp.req.PushClientReq;
import com.dashuf.dpbs.sao.laapp.req.subscribe.CarLoan;
import com.dashuf.dpbs.sao.laapp.req.subscribe.House;
import com.dashuf.dpbs.sao.laapp.req.subscribe.Insurance;
import com.dashuf.dpbs.sao.laapp.resp.PushClientResp;
import com.dashuf.dpbs.service.PushOrderLogService;
import com.dashuf.dpbs.service.blaze.dto.DashufBlazeDto;
import com.dashuf.merlin.web.base.views.ResponseVo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Service
public class ThirdPartyAccessSupportService {
    @Autowired
    private PushOrderLogService pushOrderLogService;
    @Autowired
    private AppBlazeSAO appBlazeSAO;
    @Autowired
    private ThirdPartyAccessMapper thirdPartyAccessMapper;
    @Autowired
    private DashufBlazeSupportService dashufBlazeSupportService;

    public boolean lockPushOrderLog(String pushOrderNo, JSONObject jsonObj) {
        int dealCnt = thirdPartyAccessMapper.lockPushOrderLog(pushOrderNo);

        return DpbsCnst.NUMBER_1 == dealCnt ? true : false;
    }

    public boolean unLockPushOrderLog(String pushOrderNo, JSONObject jsonObj) {
        int dealCnt = thirdPartyAccessMapper.unLockPushOrderLog(pushOrderNo);

        return DpbsCnst.NUMBER_1 == dealCnt ? true : false;
    }

    public List<PushOrderLog> queryNeedGetDs020List() {
        return thirdPartyAccessMapper.queryDs020GetScore();
    }

    public boolean initScreenDs010(PushOrderLog pushOrderLog, JSONObject jsonObj) {
        DashufBlazeDto dashufBlazeDto = dashufBlazeSupportService.gatherBlazeInfo(pushOrderLog.getPushOrderNo(), jsonObj);

        PushOrderLog pushOrderLogParam = new PushOrderLog();
        pushOrderLogParam.setPushOrderNo(pushOrderLog.getPushOrderNo());
        dashufBlazeSupportService.initScreenDs010(pushOrderLogParam, dashufBlazeDto, jsonObj);
        return true;
    }

    public boolean queryScoreDs020(PushOrderLog pushOrderLog, JSONObject jsonObj) {
        DashufBlazeDto dashufBlazeDto = dashufBlazeSupportService.gatherBlazeInfo(pushOrderLog.getPushOrderNo(), jsonObj);

        PushOrderLog pushOrderLogParam = new PushOrderLog();
        pushOrderLogParam.setPushOrderNo(pushOrderLog.getPushOrderNo());
        dashufBlazeSupportService.giveScoreDs020(pushOrderLogParam, dashufBlazeDto, jsonObj);
        return true;
    }

    private static final List<String> LAAPP_SUBSCRIBE_CODE_LIST = Arrays.asList(new String[]{"EAS0601", "EAS0602"});

    public boolean pushClient(String pushOrderNo, JSONObject jsonObj) {
        PushClientReq pushClientReq = new PushClientReq();
        DashufBlazeDto dashufBlazeDto = dashufBlazeSupportService.gatherBlazeInfo(pushOrderNo, jsonObj);
        fullPushClientReq(pushClientReq, dashufBlazeDto);

        ResponseVo<PushClientResp> pushClientResp = appBlazeSAO.pushClient(pushClientReq);
        PushOrderLog pushOrderLogParam = new PushOrderLog();
        pushOrderLogParam.setPushOrderNo(pushOrderNo);
        if (DpbsCnst.HTTP_OK.equals(pushClientResp.getCode())) {
            pushOrderLogParam.setPushClientTime(new Date());
            pushOrderLogParam.setPushStatus(DpbsStatusCnst.PUSH_CLIENT_SUCCESS);
        } else {
            pushOrderLogParam.setRtnCode(pushClientResp.getCode());
            pushOrderLogParam.setRtnMsg(pushClientResp.getMessage());
            if (LAAPP_SUBSCRIBE_CODE_LIST.contains(pushClientResp.getCode())) {
                pushOrderLogParam.setPushStatus(DpbsStatusCnst.PUSH_FAIL);
            }
        }

        if (!pushOrderLogService.updatePushOrderLogByOrgStatus(pushOrderLogParam, dashufBlazeDto.getPushOrderLog().getPushStatus(), jsonObj)) {
            return false;
        }
        return true;
    }

    private void fullPushClientReq(PushClientReq pushClientReq, DashufBlazeDto dashufBlazeDto) {
        pushClientReq.setAccountManagerId(dashufBlazeDto.getUserInfo().getSrcUmNo());
        pushClientReq.setBusinessSource("DISP");
        pushClientReq.setAge(dashufBlazeDto.getClientInfo().getClientAge() + "");
        pushClientReq.setOrganizationId(dashufBlazeDto.getUserInfo().getSrcCompanyCode());
        pushClientReq.setCertificateNum(dashufBlazeDto.getClientInfo().getCertNo());
        pushClientReq.setCertificateType("Ind01");
        pushClientReq.setChannelSource("DISP");
        pushClientReq.setCustName(dashufBlazeDto.getClientInfo().getClientName());
        pushClientReq.setCustType(dashufBlazeDto.getInfoEntry().getClientType());
        pushClientReq.setEnterprisesTaxesInd("0");
        pushClientReq.setHouseAddress(dashufBlazeDto.getInfoEntry().getLifeAddr());
        pushClientReq.setHouseAddressName(dashufBlazeDto.getInfoEntry().getLifeAddrName());
        pushClientReq.setHouseholdRegistrationAddressTxt(dashufBlazeDto.getClientInfo().getAddress());
        pushClientReq.setLegalPersonInd(DashufBlazeCnst.getCommonTrueFalseMap(dashufBlazeDto.getInfoEntry().getLegalPersonInd()));
        pushClientReq.setMobileTelephoneNum(dashufBlazeDto.getInfoEntry().getMobileNo());
        pushClientReq.setRegBusinessLicenseInd(DashufBlazeCnst.getCommonTrueFalseMap(dashufBlazeDto.getInfoEntry().getBusinessLicenseInd()));
        pushClientReq.setSex(dashufBlazeDto.getClientInfo().getGenderCd());
        pushClientReq.setShareholderInd(DashufBlazeCnst.getCommonTrueFalseMap(dashufBlazeDto.getInfoEntry().getShareholderInd()));
        pushClientReq.setThirdPartOrderId(dashufBlazeDto.getPushOrderLog().getPushOrderNo());
        pushClientReq.setWorkAddress(dashufBlazeDto.getInfoEntry().getWorkAddr());
        pushClientReq.setWorkAddressName(dashufBlazeDto.getInfoEntry().getWorkAddrName());
        pushClientReq.setImageBatchId(dashufBlazeDto.getPushOrderLog().getMovieNo());
        pushClientReq.setExpectLoanAmt(dashufBlazeDto.getInfoEntry().getExpectLoanAmt());
        pushClientReq.setExpectLoanTerm(dashufBlazeDto.getInfoEntry().getExpectLoanPeriod());
        pushClientReq.setSaleTeamId(dashufBlazeDto.getUserInfo().getSrcTeamCode());

        if (DpbsCnst.TRUE_STR.equals(dashufBlazeDto.getPushOrderLog().getIfCreditSupply())) {
            if (CollectionUtils.isNotEmpty(dashufBlazeDto.getCreditSupplyInfoList())) {
                pushClientReq.setCreditCarsupplyInd("1");
                List<CarLoan> carLoanList = new ArrayList<>();
                dashufBlazeDto.getCreditSupplyInfoList().forEach(creditSupplyInfo -> {
                    CarLoan carLoan = new CarLoan();
                    carLoan.setMonthlyRepaymentAmt(creditSupplyInfo.getMonthlyAmt());
                    carLoanList.add(carLoan);
                });
                pushClientReq.setCarLoanList(carLoanList);
            }
        } else {
            pushClientReq.setCreditCarsupplyInd("0");
        }

        if (DpbsCnst.TRUE_STR.equals(dashufBlazeDto.getPushOrderLog().getIfHouse())) {
            if (CollectionUtils.isNotEmpty(dashufBlazeDto.getHouseInfoList())) {
                pushClientReq.setHousePropertyInd("1");
                List<House> houseList = new ArrayList<>();
                dashufBlazeDto.getHouseInfoList().forEach(houseInfo -> {
                    House house = new House();
                    house.setAddressCode(houseInfo.getAddressCode());
                    house.setAddressName(houseInfo.getAddressCode());
                    house.setEstatesTypeCode(houseInfo.getEstatesTypeCode());
                    house.setTotalPriceAmt(houseInfo.getTotalPriceAmt());
                    houseList.add(house);
                });
                pushClientReq.setHouseList(houseList);
            }
        } else {
            pushClientReq.setHousePropertyInd("0");
        }

        if (DpbsCnst.TRUE_STR.equals(dashufBlazeDto.getPushOrderLog().getIfInsurance())) {
            if (CollectionUtils.isNotEmpty(dashufBlazeDto.getInsuranceList())) {
                pushClientReq.setInsurancePolicyInd("1");
                List<Insurance> insurancesList = new ArrayList<>();
                dashufBlazeDto.getInsuranceList().forEach(insuranceInfo -> {
                    Insurance insurance = new Insurance();
                    insurance.setInsuranceCompanyCode(insuranceInfo.getInsuranceCompanyCode());
                    insurance.setPremiumAnnualAmt(insuranceInfo.getPremiumAnnualAmt());
                    insurance.setMaxEffectiveCode(DateFormatUtils.format(insuranceInfo.getEffectiveDate(), "yyyy-MM-dd"));
                    insurancesList.add(insurance);
                });
                pushClientReq.setInsuranceList(insurancesList);
            }
        } else {
            pushClientReq.setInsurancePolicyInd("0");
        }

        PushClientReq.RecomUser recomUser = new PushClientReq.RecomUser();
        recomUser.setCertNo(dashufBlazeDto.getUserInfo().getCertNo());
        recomUser.setChannelId(dashufBlazeDto.getUserInfo().getSrcChannelCode());
        recomUser.setChannelName(dashufBlazeDto.getUserInfo().getSrcChannel());
        recomUser.setMobileNo(dashufBlazeDto.getUserInfo().getMobileNo());
        recomUser.setUserName(dashufBlazeDto.getUserInfo().getUserName());
        pushClientReq.setRecomUser(recomUser);
    }
}
