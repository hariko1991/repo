package com.dashuf.dpbs.app;

public final class DpbsForMsmpUrl {
	public static final String MSMP_MY_USER = "/dpbs/appWeb/msmp/myUser";

	public static final String MSMP_MY_CLIENT = "/dpbs/appWeb/msmp/myClient";
}
