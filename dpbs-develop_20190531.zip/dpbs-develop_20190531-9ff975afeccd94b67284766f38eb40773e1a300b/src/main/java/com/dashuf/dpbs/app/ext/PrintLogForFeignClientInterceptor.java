package com.dashuf.dpbs.app.ext;

import com.dashuf.merlin.core.support.MyThreadContext;
import com.dashuf.merlin.web.base.constant.WebConstants;
import feign.RequestInterceptor;
import feign.RequestTemplate;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.annotation.Configuration;

@Slf4j
@Configuration
public class PrintLogForFeignClientInterceptor implements RequestInterceptor {

    @Override
    public void apply(RequestTemplate requestTemplate) {

        requestTemplate.header(WebConstants.HEADER_FOR_TRACE_ID, MyThreadContext.getTraceId());
    }

}
