package com.dashuf.dpbs.sao.cids.resp;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

/**
 * @author yaojiaoyi
 */
@Getter
@Setter
public class GetCreditStatusResp implements Serializable {

    /**
     * loanApplicationNum	string 非必须 信贷申请编号，进入信贷流程才会有返回
     */
    private String applicationId;
    /**
     * applicationNum	string 必须 业务来源
     */
    private String businessSourceCode;
    /**
     * channelNum	string 渠道来源 LY/BK
     */
    private String channelCode;
    /**
     * ecifCustomerNum	string 非必须 ecif客户号，信贷生成才会有返回
     */
    private String custId;

    /**
     * loanOrderId	string 非必须 外围渠道申请编号
     */
    private String loanOrderId;
    /**
     * loanStatus 申请审批状态
     */
    private String loanStatus;
    /**
     * patchInd	boolean 非必须 是否需要补件
     */
    private String patchInd;
    /**
     * putoutList	object 非必须 出账List，一个信贷申请编号可能存在多个出账状态 备注: 出账List，一个信贷申请编号可能存在多个出账状态
     */
    private List<GetCreditStatusOfChargeOffDetail> accountList;


}
