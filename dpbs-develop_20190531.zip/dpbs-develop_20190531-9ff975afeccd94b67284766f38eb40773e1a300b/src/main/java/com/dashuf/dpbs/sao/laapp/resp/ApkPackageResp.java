package com.dashuf.dpbs.sao.laapp.resp;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
public class ApkPackageResp implements Serializable {

    private String apkUrl;

    private String sysType;
}
