package com.dashuf.dpbs.service;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.web.req.user.*;
import com.dashuf.dpbs.app.web.resp.user.LoginResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.DpbsHeadCnst;
import com.dashuf.dpbs.cnst.RtnCodeCnst;
import com.dashuf.dpbs.cnst.SysConfCnst;
import com.dashuf.dpbs.mapper.UserInfoMapper;
import com.dashuf.dpbs.model.UserInfo;
import com.dashuf.dpbs.service.support.VerifyCodeService;
import com.dashuf.dpbs.service.support.WxSupportService;
import com.dashuf.dpbs.util.DpbsUtil;
import com.dashuf.dpbs.util.MD5Util;
import com.dashuf.dpbs.util.TokenUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Date;
import java.util.concurrent.TimeUnit;

@Service
@Slf4j
public class UserInfoSupportService {
    private static final int ACCESS_TOKEN_EXPIRE = 1000 * 60 * 60;
    private static final String OPEN_ID = "openId";
    private static final Integer USER_SECRET_RETRY_COUNT = 5;
    private static final String USER_SECRET_RETRY_COUNT_KEY = "DPBS:PWD:RETRY:%s:%s";

    @Autowired
    private StringRedisTemplate redisTemplate;
    @Autowired
    private UserInfoMapper userInfoMapper;
    @Autowired
    private WxSupportService wxSupportService;
    @Autowired
    private VerifyCodeService verifyCodeService;
    @Autowired
    private TokenUtil tokenUtils;

    public UserInfo getUserInfo(String userNo) {
        UserInfo userInfoParam = new UserInfo();
        userInfoParam.setUserNo(userNo);

        UserInfo userInfo = userInfoMapper.selectQuiqueUserInfo(userInfoParam);
        return userInfo;
    }

    public LoginResp regUser(RegReq regReq, JSONObject jsonObj) throws Exception {
        if (!regReq.getUserPwd().equals(regReq.getConfirmPwd())) {
            jsonObj.put(DpbsCnst.RTN_MSG, "用户输入密码和确认密码不一致");
            return null;
        }

        String userNo = DpbsUtil.getTableNo(DpbsUtil.PREFIX_USER_INFO);
        UserInfo userInfo = new UserInfo();
        userInfo.setUserNo(userNo);
        userInfo.setUserPwd(MD5Util.EncoderByMd5(regReq.getUserPwd()));
        userInfo.setMobileNo(regReq.getMobileNo());
        if (!verifyCodeService.checkVerifyCode(SysConfCnst.MODULE_CODE_USER_REG, regReq.getMobileNo(), regReq.getVerifyCode(), jsonObj)) {
            return null;
        }

        String openId = wxSupportService.getOpenId(userNo, regReq.getWxCode(), jsonObj);
        if (StringUtils.isNotEmpty(openId)) {
            int dealCnt = userInfoMapper.unBindUserOfOpenId(openId, userNo);
            log.info("解绑已存在的微信[{}]绑定用户,不包括用户[{}]记录:[{}]", openId, userNo, dealCnt);
        }
        userInfo.setOpenId(openId);

        int dealCnt = userInfoMapper.initUserInfoByReg(userInfo);
        if (DpbsCnst.NUMBER_1 != dealCnt) {
            jsonObj.put(DpbsCnst.RTN_MSG, "此手机号已被注册，请登录");
            return null;
        }

        LoginResp loginResp = new LoginResp();
        loginResp.setUserNo(userNo);
        loginResp.setMobileNo(regReq.getMobileNo());
        return loginResp;
    }

    public LoginResp loginByPwd(LoginPwdReq loginPwdReq, JSONObject jsonObj) throws Exception {
        if (!judgeUserLogin(loginPwdReq.getMobileNo(), jsonObj)) {
            return null;
        }

        UserInfo userInfoParam = new UserInfo();
        userInfoParam.setMobileNo(loginPwdReq.getMobileNo());

        UserInfo userInfo = userInfoMapper.selectQuiqueUserInfo(userInfoParam);

        if (null != userInfo && StringUtils.isNotEmpty(userInfo.getUserPwd()) && userInfo.getUserPwd().equals(MD5Util.EncoderByMd5(loginPwdReq.getUserPwd()))) {
            getOpenId(loginPwdReq.getWxCode(), jsonObj, userInfoParam, userInfo);
            LoginResp loginResp = new LoginResp();
            loginResp.setUserNo(userInfo.getUserNo());
            loginResp.setStatus(userInfo.getStatus());
            loginResp.setMobileNo(loginPwdReq.getMobileNo());
            return loginResp;
        } else {
            if (!handleUserPwdRetry(loginPwdReq, jsonObj)) {
                return null;
            }
            jsonObj.put(DpbsCnst.RTN_CODE, RtnCodeCnst.RTN_CODE_LOGIN_SECRET_INCORRECT);
            jsonObj.put(DpbsCnst.RTN_MSG, "密码不正确,请检查");
            return null;
        }
    }

    private boolean judgeUserLogin(String mobileNo, JSONObject jsonObj) {
        String currentDate = DateFormatUtils.format(new Date(), "yyyy-MM-dd");

        //从redis中获取客户可登录次数
        String userPwdRetryCount = String.format(USER_SECRET_RETRY_COUNT_KEY, mobileNo, currentDate);

        Object retryCount = redisTemplate.opsForValue().get(userPwdRetryCount);

        if (null != retryCount) {
            Integer retryCountInteger = Integer.valueOf(retryCount.toString());
            log.info("登录用户[{}]已尝试次数[{}]", mobileNo, retryCountInteger.intValue());
            if (retryCountInteger.compareTo(USER_SECRET_RETRY_COUNT) >= 0) {
                jsonObj.put(DpbsCnst.RTN_CODE, RtnCodeCnst.RTN_CODE_LOGIN_SECRET_RETRY_EXCEED);
                jsonObj.put(DpbsCnst.RTN_MSG, "你的账号已被锁定，请明日在试");
                return false;
            }
        }

        return true;
    }

    private boolean handleUserPwdRetry(LoginPwdReq loginPwdReq, JSONObject jsonObj) {
        String currentDate = DateFormatUtils.format(new Date(), "yyyy-MM-dd");

        //从redis中获取客户可登录次数
        String userPwdRetryCount = String.format(USER_SECRET_RETRY_COUNT_KEY, loginPwdReq.getMobileNo(), currentDate);

        Object retryCount = redisTemplate.opsForValue().get(userPwdRetryCount);

        if (null != retryCount) {//修改次数
            Integer retryCountInteger = Integer.valueOf(retryCount.toString());

            retryCountInteger += 1;
            redisTemplate.opsForValue().set(userPwdRetryCount, retryCountInteger + "", 1, TimeUnit.DAYS);
            log.info("用户[{}]以密码登录,缓存[{}]值为[{}]", loginPwdReq.getMobileNo(), userPwdRetryCount, retryCountInteger);

            if (retryCountInteger.compareTo(USER_SECRET_RETRY_COUNT) >= 0) {
                jsonObj.put(DpbsCnst.RTN_CODE, RtnCodeCnst.RTN_CODE_LOGIN_SECRET_RETRY_EXCEED);
                jsonObj.put(DpbsCnst.RTN_MSG, "你的账号已被锁定，请明日在试");
                return false;
            }

            return true;
        } else {
            redisTemplate.opsForValue().set(userPwdRetryCount, 1 + "", 1, TimeUnit.DAYS);
            log.info("用户[{}]以密码登录,缓存[{}]值为[{}](用户当日密码没有输入错误)", loginPwdReq.getMobileNo(), userPwdRetryCount, 1);
            return true;
        }
    }

    private void getOpenId(String wxCode, JSONObject jsonObj, UserInfo userInfoParam, UserInfo userInfo) {
        String openId = wxSupportService.getOpenId(userInfo.getUserNo(), wxCode, jsonObj);
        userInfoParam.setUserNo(userInfo.getUserNo());
        if (StringUtils.isEmpty(userInfo.getOpenId())) {
            userInfoParam.setUserNo(userInfo.getUserNo());
            if (StringUtils.isNotEmpty(openId)) {
                userInfoParam.setOpenId(openId);
                userInfoMapper.updateUserInfo(userInfoParam);
            }
        }

        if (StringUtils.isNotEmpty(openId) && StringUtils.isNotEmpty(userInfo.getOpenId()) && !userInfo.getOpenId().equals(openId)) {
            userInfoParam.setOpenId(openId);
            userInfoMapper.updateUserInfo(userInfoParam);
            log.info("用户[{}]原openid[{}],新的openid[{}]", userInfo.getUserNo(), userInfo.getOpenId(), openId);
        }

        if (StringUtils.isNotEmpty(openId)) {
            int dealCnt = userInfoMapper.unBindUserOfOpenId(openId, userInfoParam.getUserNo());
            log.info("解绑已存在的微信[{}]绑定用户,不包括用户[{}]记录:[{}]", openId, userInfoParam.getUserNo(), dealCnt);
        }
    }

    public LoginResp loginByCode(LoginCodeReq loginCodeReq, JSONObject jsonObj) {
        if (!judgeUserLogin(loginCodeReq.getMobileNo(), jsonObj)) {
            return null;
        }

        if (!verifyCodeService.checkVerifyCode(SysConfCnst.MODULE_CODE_USER_LOGIN, loginCodeReq.getMobileNo(), loginCodeReq.getVerifyCode(), jsonObj)) {
            return null;
        }

        UserInfo userInfoParam = new UserInfo();
        userInfoParam.setMobileNo(loginCodeReq.getMobileNo());

        UserInfo userInfo = userInfoMapper.selectQuiqueUserInfo(userInfoParam);
        if (null == userInfo) {
            jsonObj.put(DpbsCnst.RTN_MSG, "手机号未注册,请检查");
            return null;
        }

        getOpenId(loginCodeReq.getWxCode(), jsonObj, userInfoParam, userInfo);

        LoginResp loginResp = new LoginResp();
        loginResp.setUserNo(userInfo.getUserNo());
        loginResp.setMobileNo(loginCodeReq.getMobileNo());
        loginResp.setStatus(userInfo.getStatus());
        return loginResp;
    }

    public LoginResp modifyPwd(ModifyPwdReq modifyPwdReq, JSONObject jsonObj) throws Exception {
        if (!modifyPwdReq.getUserPwd().equals(modifyPwdReq.getConfirmPwd())) {
            jsonObj.put(DpbsCnst.RTN_MSG, "用户输入密码和确认密码不一致");
            return null;
        }

        if (!verifyCodeService.checkVerifyCode("user_modify_pwd", modifyPwdReq.getMobileNo(), modifyPwdReq.getVerifyCode(), jsonObj)) {
            return null;
        }

        UserInfo userInfo = new UserInfo();
        userInfo.setUserNo(modifyPwdReq.getUserNo());
        userInfo.setUserPwd(MD5Util.EncoderByMd5(modifyPwdReq.getUserPwd()));
        userInfo.setMobileNo(modifyPwdReq.getMobileNo());

        int dealCnt = userInfoMapper.updateUserInfo(userInfo);
        if (DpbsCnst.NUMBER_1 != dealCnt) {
            jsonObj.put(DpbsCnst.RTN_MSG, "修改密码失败");
            return null;
        }

        LoginResp loginResp = new LoginResp();
        loginResp.setUserNo(modifyPwdReq.getUserNo());
        loginResp.setMobileNo(modifyPwdReq.getMobileNo());
        return loginResp;
    }

    public LoginResp forgetPwd(ForgetPwdReq forgetPwdReq, JSONObject jsonObj) throws Exception {
        if (!forgetPwdReq.getUserPwd().equals(forgetPwdReq.getConfirmPwd())) {
            jsonObj.put(DpbsCnst.RTN_MSG, "用户输入密码和确认密码不一致");
            return null;
        }

        if (!verifyCodeService.checkVerifyCode("user_forget_pwd", forgetPwdReq.getMobileNo(), forgetPwdReq.getVerifyCode(), jsonObj)) {
            return null;
        }

        UserInfo userInfoParam = new UserInfo();
        userInfoParam.setMobileNo(forgetPwdReq.getMobileNo());

        UserInfo userInfo = userInfoMapper.selectQuiqueUserInfo(userInfoParam);
        if (null == userInfo) {
            jsonObj.put(DpbsCnst.RTN_MSG, "手机号对应用户不存在,请检查");
            return null;
        }

        userInfoParam.setUserPwd(MD5Util.EncoderByMd5(forgetPwdReq.getUserPwd()));
        int dealCnt = userInfoMapper.updateUserInfo(userInfoParam);
        if (DpbsCnst.NUMBER_1 != dealCnt) {
            jsonObj.put(DpbsCnst.RTN_MSG, "修改密码失败");
            return null;
        }

        LoginResp loginResp = new LoginResp();
        loginResp.setUserNo(userInfo.getUserNo());
        loginResp.setMobileNo(forgetPwdReq.getMobileNo());
        return loginResp;
    }

    public LoginResp densityFreeLogin(DensityFreeLoginReq densityFreeLoginReq, JSONObject jsonObj) {
        String thirdPartyRtnCode = wxSupportService.authThirdPartyLogin(densityFreeLoginReq.getThirdPartyType(), densityFreeLoginReq.getThirdPartyCode(), jsonObj);

        if (StringUtils.isEmpty(thirdPartyRtnCode)) {
            return null;
        }

        UserInfo userInfoParam = new UserInfo();
        userInfoParam.setOpenId(thirdPartyRtnCode);
        UserInfo userInfo = userInfoMapper.selectOneByModelSelective(userInfoParam, DpbsCnst.SQL_PRECISE_STRICT);

        if (null == userInfo) {
            jsonObj.put(DpbsCnst.RTN_MSG, thirdPartyRtnCode + "对应用户不存在,需要登录");
            return null;
        }

        LoginResp loginResp = new LoginResp();
        loginResp.setUserNo(userInfo.getUserNo());
        loginResp.setStatus(userInfo.getStatus());
        loginResp.setMobileNo(userInfo.getMobileNo());
        return loginResp;
    }

    public void securityLoginOut(String userNo) {
        redisTemplate.delete(DpbsCnst.REDIS_DPBS_LOGIN + userNo);
        log.info("用户[{}]成功安全退出", userNo);
    }

    public void initAccessTokenForUser(HttpServletRequest request, HttpServletResponse response, String userNo) {
        String accessToken = tokenUtils.createJwtToken(userNo, ACCESS_TOKEN_EXPIRE);
        response.setHeader(DpbsHeadCnst.X_HEAD_ACCESS_TOKEN, accessToken);
        request.setAttribute(DpbsHeadCnst.X_HEAD_USER_NO, userNo);
    }
}
