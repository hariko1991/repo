package com.dashuf.dpbs.sao.laapp.req;

import com.dashuf.dpbs.sao.laapp.req.subscribe.CarLoan;
import com.dashuf.dpbs.sao.laapp.req.subscribe.House;
import com.dashuf.dpbs.sao.laapp.req.subscribe.Insurance;
import com.dashuf.dpbs.sao.laapp.req.subscribe.Taxes;
import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

@Getter
@Setter
public class PushClientReq implements Serializable {

    private static final long serialVersionUID = 8354974721256022771L;
    @ApiModelProperty(value = "业务来源")
    private String businessSource;

    @ApiModelProperty(value = "渠道来源")
    @NotBlank(message = "渠道来源不能为空")
    private String channelSource;

    @ApiModelProperty(value = "第三方推单编号")
    @NotBlank(message = "第三方推单编号不能为空")
    private String thirdPartOrderId;

    @ApiModelProperty(value = "客户姓名")
    @NotBlank(message = "客户姓名不能为空")
    private String custName;

    @ApiModelProperty(value = "性别 男=女 、F=女")
    private String sex;

    @ApiModelProperty(value = "客户手机号码")
    private String mobileTelephoneNum;

    @ApiModelProperty(value = "客户年龄")
    private String age;

    @ApiModelProperty(value = "客户证件号码")
    @NotBlank(message = "客户证件号码不能为空")
    private String certificateNum;

    @ApiModelProperty(value = "客户证件类型")
    @NotBlank(message = "客户证件类型不能为空")
    private String certificateType;

    @ApiModelProperty(value = "发证机关")
    private String authorityLocationTxt;

    @ApiModelProperty(value = "身份证有效期")
    private String validityPeriod;

    @ApiModelProperty(value = "户籍地址")
    private String householdRegistrationAddressTxt;

    @ApiModelProperty(value = "期望贷款金额")
    private BigDecimal expectLoanAmt;

    @ApiModelProperty(value = "期望贷款期限")
    private String expectLoanTerm;

    @ApiModelProperty(value = "地区（市）")
    private String areaCd;

    @ApiModelProperty(value = "客户类型")
    private String custType;

    @ApiModelProperty(value = "产品id")
    private String productId;

    @ApiModelProperty(value = "居住地址（省市区）code")
    private String houseAddress;

    @ApiModelProperty(value = "居住地址（省市区）name")
    private String houseAddressName;

    @ApiModelProperty(value = "单位地址（省市区）code")
    private String workAddress;

    @ApiModelProperty(value = "单位地址（省市区）name")
    private String workAddressName;

    @ApiModelProperty(value = "是否注册营业执照 0：否；1：是")
    private String regBusinessLicenseInd;

    @ApiModelProperty(value = "是否为股东 0：否；1：是")
    private String shareholderInd;

    @ApiModelProperty(value = "是否为法人 0：否；1：是")
    private String legalPersonInd;

    @ApiModelProperty(value = "是否有寿险保单 0：否；1：是")
    private String insurancePolicyInd;

    @ApiModelProperty(value = "是否有房产 0：否；1：是")
    private String housePropertyInd;

    @ApiModelProperty(value = "是否有信用卡分期车贷 0：否；1：是")
    private String creditCarsupplyInd;

    @ApiModelProperty(value = "是否有企业税 0：否；1：是")
    private String enterprisesTaxesInd;

    @ApiModelProperty(value = "客户经理UM账号")
    private String accountManagerId;

    @ApiModelProperty(value = "分公司")
    private String organizationId;

    @ApiModelProperty(value = "影像批次id")
    private String imageBatchId;

    private String saleTeamId;

    @ApiModelProperty(value = "保单集合")
    private List<Insurance> insuranceList;

    @ApiModelProperty(value = "房产集合")
    private List<House> houseList;

    @ApiModelProperty(value = "车贷集合")
    private List<CarLoan> carLoanList;

    @ApiModelProperty(value = "企业税集合")
    private List<Taxes> taxesList;

    @ApiModelProperty(value = "推荐用户")
    private RecomUser recomUser;

    @Getter
    @Setter
    public static class RecomUser {
        @ApiModelProperty(value = "用户名")
        private String userName;
        @ApiModelProperty(value = "证件号")
        private String certNo;
        @ApiModelProperty(value = "手机号")
        private String mobileNo;
        @ApiModelProperty(value = "专属渠道编码")
        private String channelId;
        @ApiModelProperty(value = "专属渠道名称")
        private String channelName;
    }
}