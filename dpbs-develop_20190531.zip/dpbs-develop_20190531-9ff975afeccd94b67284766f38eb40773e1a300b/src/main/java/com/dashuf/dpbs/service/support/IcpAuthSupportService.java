package com.dashuf.dpbs.service.support;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.SaoCnst;
import com.dashuf.dpbs.sao.icp.IcpAuthSAO;
import com.dashuf.dpbs.sao.icp.req.CheckIDCardReq;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class IcpAuthSupportService {

    @Autowired
    private IcpAuthSAO icpAuthSAO;

    public boolean checkPersonMsg(CheckIDCardReq checkIDCardReq, JSONObject jsonObj) {
        String rtnMsg = icpAuthSAO.checkPersonMsg(checkIDCardReq);
        log.info("姓名[{}],身份证号码[{}]二要素验证返回结果:{}", checkIDCardReq.getIdcardName(), checkIDCardReq.getIdcardNo(), rtnMsg);

        JSONObject jsonObject = JSONObject.parseObject(rtnMsg);

        if (!SaoCnst.SAO_SUCCESS_00.equals(jsonObject.getString(SaoCnst.SAO_CODE))) {
            jsonObj.put(DpbsCnst.RTN_MSG, jsonObject.getString(SaoCnst.SAO_MESSAGE));
            return false;
        }
        return true;
    }
}