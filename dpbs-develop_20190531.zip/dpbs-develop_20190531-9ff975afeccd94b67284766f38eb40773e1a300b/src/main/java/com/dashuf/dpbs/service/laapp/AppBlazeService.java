package com.dashuf.dpbs.service.laapp;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.sao.laapp.AppBlazeSAO;
import com.dashuf.dpbs.sao.laapp.req.AllowPushClientReq;
import com.dashuf.dpbs.sao.laapp.resp.AllowPushClientResp;
import com.dashuf.merlin.web.base.views.ResponseVo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AppBlazeService {
    @Autowired
    private AppBlazeSAO appBlazeSAO;

    public boolean queyClientIsAllownPush(AllowPushClientReq allowPushClientReq, JSONObject jsonObj) {
        ResponseVo<AllowPushClientResp> allowPushClientResp = appBlazeSAO.queyClientIsAllownPush(allowPushClientReq);

        if (DpbsCnst.HTTP_OK.equals(allowPushClientResp.getCode())) {
            if (allowPushClientResp.getData().isProdectedInd()) {
                jsonObj.put(DpbsCnst.RTN_MSG, "该客户已被推荐，无法再次推荐");
                return false;
            } else {
                return true;
            }
        } else {
            jsonObj.put(DpbsCnst.RTN_MSG, allowPushClientResp.getMessage());
            return false;
        }
    }
}
