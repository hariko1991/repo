package com.dashuf.dpbs.app.web.req.push;

import java.io.Serializable;
import java.util.Date;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Pattern;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

@ApiModel(value = "扫描身份证", description = "扫描身份证")
@Getter
@Setter
public class ScanCertReq implements Serializable {
    private static final long serialVersionUID = 26902995577450524L;

    @ApiModelProperty(value = "推送订单编号", required = true)
    private String pushOrderNo;

    @ApiModelProperty(value = "推荐用户编号")
    private String userNo;

    @ApiModelProperty(value = "客户姓名", required = true)
    @NotBlank(message = "请输入客户姓名")
    private String clientName;

    @ApiModelProperty(value = "身份证号", required = true)
    @NotBlank(message = "请输入身份证号")
    @Pattern(regexp = "^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$", message = "身份证号码有误")
    private String certNo;

    @ApiModelProperty(value = "民族名称", required = true)
    private String nation;

    @ApiModelProperty(value = "民族编码", required = true)
    private String nationCode;

    @ApiModelProperty(value = "户籍地址编码", required = true)
    private String houseReg;

    @ApiModelProperty(value = "户籍地址名称", required = true)
    private String houseRegCode;

    @ApiModelProperty(value = "民族", required = true)
    @NotBlank(message = "请输入民族")
    private String nationName;

    @ApiModelProperty(value = "住址", required = true)
    @NotBlank(message = "请输入住址")
    private String address;

    @ApiModelProperty(value = "发证机关", required = true)
    @NotBlank(message = "请输入发证机关")
    private String issuedBy;

    @ApiModelProperty(value = "有效期", required = true)
    @DateTimeFormat(pattern = "yyyyMMdd")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyyMMdd")
    @NotNull(message = "请输入证件有效期")
    private Date validDate;

}
