package com.dashuf.dpbs.sao.cids.req.ds020;

import com.dashuf.dpbs.sao.cids.req.ds010.blaze.BusinessDetail;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
public class Ds020BlazeDetail implements Serializable {
    private static final long serialVersionUID = -44507081100768657L;

    /**
     * SYSTEM_ID	系统编号	VARCHAR(10)	Y
     */
    @JsonProperty(value = "SYSTEM_ID")
    private String systemId = "DBPS";

    /**
     * "DECISION_ID": "g7nx6vfRsuT2ehoqveDnwm",
     */
    @JsonProperty(value = "DECISION_ID")
    private String decisionId;

    @JsonProperty(value = "PRODUCT_CODE")
    private String productCode;

    /**
     * ENGINE_NODE	引擎节点	VARCHAR(10)	Y	必输
     */
    @JsonProperty(value = "ENGINE_NODE")
    private String engineMode = "DS020";


    @JsonProperty(value = "BUSINESS")
    private BusinessDetail business;

}
