package com.dashuf.dpbs.sao.laapp.req;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Getter
@Setter
public class PushClientQueryReq implements Serializable {

    @ApiModelProperty(value = "渠道来源")
    @NotBlank(message = "渠道来源不能为空")
    private String channelSource;

    @ApiModelProperty(value = "第三方推单编号")
    @NotBlank(message = "第三方推单编号不能为空")
    private String thirdPartOrderId;

    @ApiModelProperty(value = "客户姓名")
    @NotBlank(message = "客户姓名不能为空")
    private String custName;

    @ApiModelProperty(value = "客户身份证号码")
    @NotBlank(message = "客户身份证号码不能为空")
    private String certificateNum;

    @ApiModelProperty(value = "客户证件类型")
    @NotBlank(message = "客户证件类型不能为空")
    private String certificateType;

}
