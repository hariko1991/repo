package com.dashuf.dpbs.app.web.resp.home;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@ApiModel(value = "海报Resp")
@Getter
@Setter
public class PosterResp implements Serializable {

    private static final long serialVersionUID = -142953788448873327L;

    @ApiModelProperty(value = "标题")
    private String title;

    @ApiModelProperty(value = "网址")
    private String webSite;

    @ApiModelProperty(value = "图片地址")
    private String imgUrl;
}
