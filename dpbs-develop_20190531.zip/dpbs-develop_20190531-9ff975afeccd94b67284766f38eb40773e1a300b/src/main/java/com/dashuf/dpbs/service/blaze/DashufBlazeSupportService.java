package com.dashuf.dpbs.service.blaze;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.web.req.credit.SubmitAuthH5Req;
import com.dashuf.dpbs.cnst.*;
import com.dashuf.dpbs.model.CreditSupplyInfo;
import com.dashuf.dpbs.model.HouseInfo;
import com.dashuf.dpbs.model.PushOrderLog;
import com.dashuf.dpbs.sao.defi.DefiBlazeSAO;
import com.dashuf.dpbs.sao.defi.req.ApplyRunEngineReq;
import com.dashuf.dpbs.sao.defi.req.apply.*;
import com.dashuf.dpbs.sao.defi.resp.ApplyRunEngineResp;
import com.dashuf.dpbs.service.CreditAuthSupportService;
import com.dashuf.dpbs.service.PushOrderLogService;
import com.dashuf.dpbs.service.SysConfSupportService;
import com.dashuf.dpbs.service.blaze.dto.DashufBlazeDto;
import com.dashuf.dpbs.service.credit.CreditReportService;
import com.dashuf.dpbs.service.support.ZldSignSupportService;
import com.dashuf.dpbs.service.support.dto.ElecCreditAuthDto;
import com.dashuf.dpbs.util.ArithUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class DashufBlazeSupportService {
    private static final String DECISION_RESULT = "P";
    private static final String SUC_000 = "SUC000";
    private static final String NUMBER_12_VAL = "12";
    private static final String NUMBER_1_VAL = "1";
    private static final int NUBMER_4_NEW_SCALE = 4;
    private static final String BLAZE_FINAL_RESULT = "";

    @Autowired
    private DefiBlazeSAO defiBlazeSAO;
    @Autowired
    private PushOrderLogService pushOrderLogService;
    @Autowired
    private CreditAuthSupportService creditAuthSupportService;
    @Autowired
    private SysConfSupportService sysConfSupportService;
    @Autowired
    private CreditReportService creditReportService;
    @Autowired
    private ZldSignSupportService zldSignSupportService;

    public DashufBlazeDto gatherBlazeInfo(String pushOrderNo, JSONObject jsonObj) {
        PushOrderLog pushOrderLogParam = new PushOrderLog();
        pushOrderLogParam.setPushOrderNo(pushOrderNo);

        PushOrderLog pushOrderLog = pushOrderLogService.selectOneByModelSelective(pushOrderLogParam, DpbsCnst.SQL_PRECISE_STRICT);

        if (null == pushOrderLog) {
            jsonObj.put(DpbsCnst.RTN_MSG, "对应推送订单为空,请检查");
            return null;
        }

        DashufBlazeDto dashufBlazeDto = pushOrderLogService.gatherBlazeInfo(pushOrderLog, jsonObj);
        return dashufBlazeDto;
    }

    public boolean submitCredit(SubmitAuthH5Req submitAuthH5Req, DashufBlazeDto dashufBlazeDto, JSONObject jsonObj) {
        PushOrderLog pushOrderLogParam = new PushOrderLog();
        pushOrderLogParam.setPushOrderNo(submitAuthH5Req.getPushOrderNo());
        pushOrderLogParam.setCreditAuthCode(submitAuthH5Req.getCreditAuthCode());
        pushOrderLogParam.setPushStatus(DpbsStatusCnst.PUSH_CREDIT);
        pushOrderLogParam.setPushEndTime(new Date());

        //调用融担查询征信
        if (!creditAuthSupportService.submitCreditAuth(submitAuthH5Req, jsonObj)) {
            return false;
        }

        //提交征信报告查询
        String submitCreditReportSerialNo = creditReportService.submitCreditReportReq(dashufBlazeDto, jsonObj);
        if (StringUtils.isEmpty(submitCreditReportSerialNo)) {
            return false;
        } else {
            pushOrderLogParam.setCreditAuthResult(submitCreditReportSerialNo);
        }

        if (!pushOrderLogService.updatePushOrderLogByOrgStatus(pushOrderLogParam, DpbsStatusCnst.PUSH_ENTRY, jsonObj)) {
            return false;
        }

        return true;
    }

    public boolean initScreenDs010(SubmitAuthH5Req submitAuthH5Req, PushOrderLog pushOrderLogParam, DashufBlazeDto dashufBlazeDto, JSONObject jsonObj) {
        ApplyRunEngineReq applyRunEngineReq = new ApplyRunEngineReq();

        fullDs010ApplyRunEngineReq(applyRunEngineReq, dashufBlazeDto);

        boolean ds010Result = true;
        ApplyRunEngineResp applyRunEngineResp = defiBlazeSAO.applyRunEngine(applyRunEngineReq);
        log.info("推单编号[{}]进行ds010初筛结果:{}", dashufBlazeDto.getPushOrderLog().getPushOrderNo(), JSONObject.toJSONString(applyRunEngineResp));
        pushOrderLogParam.setCreditAuthCode(submitAuthH5Req.getCreditAuthCode());
        if (!analysisApplyRunEngineResp(applyRunEngineResp, jsonObj)) {
            pushOrderLogParam.setEvalStartTime(new Date());
            pushOrderLogParam.setPushStatus(DpbsStatusCnst.PUSH_FAIL);
            pushOrderLogParam.setRtnMsg(jsonObj.getString(DpbsCnst.RTN_MSG));
            ds010Result = false;
        } else {
            pushOrderLogParam.setPushStatus(DpbsStatusCnst.PUSH_CREDIT);
            pushOrderLogParam.setEvalStartTime(new Date());
        }

        //3.调用融担查询征信
        if (ds010Result && !creditAuthSupportService.submitCreditAuth(submitAuthH5Req, jsonObj)) {
            return false;
        }

        //4.提交征信报告查询
        if (ds010Result) {
            String submitCreditReportSerialNo = creditReportService.submitCreditReportReq(dashufBlazeDto, jsonObj);
            if (StringUtils.isEmpty(submitCreditReportSerialNo)) {
                return false;
            } else {
                pushOrderLogParam.setCreditAuthResult(submitCreditReportSerialNo);
            }
        }

        //5.签约授权书
        if (ds010Result) {
            ElecCreditAuthDto elecCreditAuthDto = new ElecCreditAuthDto();
            elecCreditAuthDto.setCertName(dashufBlazeDto.getClientInfo().getClientName());
            elecCreditAuthDto.setMobileNo(dashufBlazeDto.getInfoEntry().getMobileNo());
            elecCreditAuthDto.setCertNo(dashufBlazeDto.getClientInfo().getCertNo());
            JSONObject creditSignResult = creditAuthSupportService.signFileList(elecCreditAuthDto, jsonObj);
            if (null == creditSignResult) {
                return false;
            }
            pushOrderLogParam.setCreditSignResult(creditSignResult.toJSONString());
        }

        if (!pushOrderLogService.updatePushOrderLogByOrgStatus(pushOrderLogParam, DpbsStatusCnst.PUSH_ENTRY, jsonObj)) {
            return false;
        }

        return ds010Result;
    }

    public boolean initScreenDs010(PushOrderLog pushOrderLogParam, DashufBlazeDto dashufBlazeDto, JSONObject jsonObj) {
         ApplyRunEngineReq applyRunEngineReq = new ApplyRunEngineReq();

        fullDs010ApplyRunEngineReq(applyRunEngineReq, dashufBlazeDto);

        boolean ds010Result = true;
        ApplyRunEngineResp applyRunEngineResp = defiBlazeSAO.applyRunEngine(applyRunEngineReq);
        log.info("推单编号[{}]进行ds010初筛结果:{}", dashufBlazeDto.getPushOrderLog().getPushOrderNo(), JSONObject.toJSONString(applyRunEngineResp));
        if (!analysisApplyRunEngineResp(applyRunEngineResp, jsonObj)) {
            if (StringUtils.isEmpty(jsonObj.getString(BLAZE_FINAL_RESULT))) {
                return false;
            }
            pushOrderLogParam.setEvalStartTime(new Date());
            pushOrderLogParam.setPushStatus(DpbsStatusCnst.PUSH_FAIL);
            pushOrderLogParam.setRtnMsg(jsonObj.getString(DpbsCnst.RTN_MSG));
            ds010Result = false;
        } else {
            pushOrderLogParam.setPushStatus(DpbsStatusCnst.PUSH_EVAL_ING);
            pushOrderLogParam.setEvalStartTime(new Date());
        }

        ElecCreditAuthDto elecCreditAuthDto = new ElecCreditAuthDto();
        elecCreditAuthDto.setCertName(dashufBlazeDto.getClientInfo().getClientName());
        elecCreditAuthDto.setMobileNo(dashufBlazeDto.getInfoEntry().getMobileNo());
        elecCreditAuthDto.setCertNo(dashufBlazeDto.getClientInfo().getCertNo());
        JSONObject creditSignResult = null;
        if (ds010Result) {
            creditSignResult = creditAuthSupportService.signFileList(elecCreditAuthDto, jsonObj);
            if (null == creditSignResult) {
                return false;
            }
            pushOrderLogParam.setCreditSignResult(creditSignResult.toJSONString());
        }

        if (ds010Result && !zldSignSupportService.uploadFileToZldSftp(elecCreditAuthDto, creditSignResult, jsonObj)) {
            return false;
        }

        if (!pushOrderLogService.updatePushOrderLogByOrgStatus(pushOrderLogParam, DpbsStatusCnst.PUSH_CREDIT, jsonObj)) {
            return false;
        }

        return ds010Result;
    }

    public boolean giveScoreDs020(PushOrderLog pushOrderLogParam, DashufBlazeDto dashufBlazeDto, JSONObject jsonObj) {
        ApplyRunEngineReq applyRunEngineReq = new ApplyRunEngineReq();

        String creditReportNo = creditReportService.queryCreditReportWithin25Day(dashufBlazeDto.getClientInfo(), jsonObj);
        if (StringUtils.isEmpty(creditReportNo)) {
            return false;
        }

        fullDs020ApplyRunEngineReq(applyRunEngineReq, dashufBlazeDto, creditReportNo);

        ApplyRunEngineResp applyRunEngineResp = defiBlazeSAO.applyRunEngine(applyRunEngineReq);
        log.info("推单编号[{}]进行ds020评分结果:{}", dashufBlazeDto.getPushOrderLog().getPushOrderNo(), JSONObject.toJSONString(applyRunEngineResp));
        pushOrderLogParam.setCreditReportNo(creditReportNo);
        if (!analysisApplyRunEngineResp(applyRunEngineResp, jsonObj)) {
            if (StringUtils.isEmpty(jsonObj.getString(BLAZE_FINAL_RESULT))) {
                return false;
            }
            pushOrderLogParam.setPushStatus(DpbsStatusCnst.PUSH_EVAL_FAIL);
            pushOrderLogParam.setRtnMsg(jsonObj.getString(DpbsCnst.RTN_MSG));
        } else {
            pushOrderLogParam.setPushStatus(DpbsStatusCnst.PUSH_EVAL_SUCCESS);
            BigDecimal evalLoanAmt = applyRunEngineResp.getDecision().getMaxCalCreditAmt();
            if (null == evalLoanAmt) {
                log.error("推单编号[{}]进行ds020评分结果有误,最大贷款金额为空,请检查", dashufBlazeDto.getPushOrderLog().getPushOrderNo());
                return false;
            }
            pushOrderLogParam.setEvalLoanAmt(evalLoanAmt);
            pushOrderLogParam.setEvalEndTime(new Date());
            pushOrderLogParam.setEvalLoanAmt(evalLoanAmt);
            pushOrderLogParam.setEvalPayMonthAmt(this.calMonthPay(evalLoanAmt, dashufBlazeDto.getInfoEntry().getExpectLoanPeriod()));

            String evalExpireDay = sysConfSupportService.selectValueFromCache(SysConfCnst.MODULE_CODE_OF_BLAZE_DS_020, SysConfCnst.MODULE_SUB_CODE_OF_GET_SCORE, SysConfCnst.MODULE_KEY_OF_EXPIRE_DAY);
            pushOrderLogParam.setEvalExpireTime(DateUtils.addDays(new Date(), Integer.valueOf(evalExpireDay)));
        }

        if (!pushOrderLogService.updatePushOrderLogByOrgStatus(pushOrderLogParam, DpbsStatusCnst.PUSH_EVAL_ING, jsonObj)) {
            return false;
        }
        return true;
    }

    private BigDecimal calMonthPay(BigDecimal maxCalCreditAmt, String loanPeriod) {
        String monthRate = sysConfSupportService.selectValueFromCache(SysConfCnst.MODULE_CODE_OF_BLAZE_DS_020, SysConfCnst.MODULE_SUB_CODE_OF_GET_SCORE, SysConfCnst.MODULE_KEY_OF_MONTH_RATE);

        return ArithUtil.calMonthPayAmount(maxCalCreditAmt, new BigDecimal(monthRate), loanPeriod);
    }

    private boolean analysisApplyRunEngineResp(ApplyRunEngineResp applyRunEngineResp, JSONObject jsonObj) {
        if (null != applyRunEngineResp) {
            if (SUC_000.equals(applyRunEngineResp.getRetCode())) {
                if (null != applyRunEngineResp.getDecision()) {
                    if (!DECISION_RESULT.equals(applyRunEngineResp.getDecision().getFinalResult())) {
                        jsonObj.put(DpbsCnst.RTN_MSG, applyRunEngineResp.getDecision().getFinalResult());
                        jsonObj.put(BLAZE_FINAL_RESULT, applyRunEngineResp.getDecision().getFinalResult());
                        return false;
                    } else {
                        return true;
                    }
                } else {
                    jsonObj.put(DpbsCnst.RTN_MSG, "返回决策结果为空");
                    return false;
                }
            } else {
                jsonObj.put(DpbsCnst.RTN_MSG, applyRunEngineResp.getRetCode() + applyRunEngineResp.getRetMsg());
                return false;
            }
        } else {
            jsonObj.put(DpbsCnst.RTN_MSG, "blaze返回结果为空");
            return false;
        }
    }

    private void fullDs010ApplyRunEngineReq(ApplyRunEngineReq applyRunEngineReq, DashufBlazeDto dashufBlazeDto) {
        applyRunEngineReq.setSystemId("DISP");
        applyRunEngineReq.setApplyId(dashufBlazeDto.getPushOrderLog().getPushOrderNo());
        applyRunEngineReq.setEngineNode("DS010");
        applyRunEngineReq.setInvokeType("SYN");
        applyRunEngineReq.setFicoScoreWanted("1");

        List<Customer> customerList = new ArrayList<>();
        Customer customer = new Customer();
        customer.setEmployeeType(dashufBlazeDto.getInfoEntry().getClientType());
        customer.setCustomerType("APPLICANT");
        customer.setCustomerName(dashufBlazeDto.getClientInfo().getClientName());
        customer.setCertType("Ind01");
        customer.setCertId(dashufBlazeDto.getClientInfo().getCertNo());
        customer.setPhoneNumber(dashufBlazeDto.getInfoEntry().getMobileNo());
        customerList.add(customer);
        applyRunEngineReq.setCustomerList(customerList);

        Business business = new Business();
        Data data = new Data();

        Application application = new Application();
        application.setDecisionArea("RISK");
        application.setCallNode("DS010");
        application.setFlowStep("apl_access_rule");
        application.setRandomDigit(StringUtils.substring(dashufBlazeDto.getClientInfo().getId() + "", -4));
        application.setDecisionUser("DISP");
        application.setApplicationNumber(dashufBlazeDto.getPushOrderLog().getPushOrderNo());
        application.setApplicationDate(DateFormatUtils.format(dashufBlazeDto.getPushOrderLog().getPushStartTime(), DpbsSymbolCnst.DATE_FORMAT_YYYY_MM_DD_HH_MM_SS));
        application.setSource("DISP");
        application.setCertMaturity("0");

        List<ApplicationForm> applicationFormList = new ArrayList<>();
        ApplicationForm applicationForm = new ApplicationForm();
        applicationForm.setCustomername(dashufBlazeDto.getClientInfo().getClientName());
        applicationForm.setCerttype("Ind01");
        applicationForm.setCertId(dashufBlazeDto.getClientInfo().getCertNo());
        applicationForm.setCell(dashufBlazeDto.getInfoEntry().getMobileNo());
        applicationForm.setGender(dashufBlazeDto.getClientInfo().getGenderCd());
        applicationForm.setNation(dashufBlazeDto.getClientInfo().getNationCode());
        applicationForm.setAge(dashufBlazeDto.getClientInfo().getClientAge());
        applicationForm.setEmployeeType(dashufBlazeDto.getInfoEntry().getClientType());
        applicationForm.setIdmaturity("0");
        applicationForm.setHouseholdRregister(dashufBlazeDto.getClientInfo().getHouseRegCode());
        applicationFormList.add(applicationForm);

        List<CustMgrInfo> custMgrInfoList = new ArrayList<>();
        CustMgrInfo custMgrInfo = new CustMgrInfo();
        custMgrInfo.setSerialNo(dashufBlazeDto.getUserInfo().getSrcUmNo());
        custMgrInfo.setOrgid(dashufBlazeDto.getUserInfo().getSrcCompanyCode());
        custMgrInfo.setTeamNo(dashufBlazeDto.getUserInfo().getSrcTeamCode());
        custMgrInfoList.add(custMgrInfo);
        application.setCustMgrInfo(custMgrInfoList);

        List<Applicant> applicantList = new ArrayList<>();
        Applicant applicant = new Applicant();
        applicant.setCell(dashufBlazeDto.getInfoEntry().getMobileNo());
        applicant.setApplicatType("1");
        applicant.setCustomername(dashufBlazeDto.getClientInfo().getClientName());
        applicant.setCerttype("Ind01");
        applicant.setId(dashufBlazeDto.getClientInfo().getCertNo());
        applicantList.add(applicant);
        application.setApplicant(applicantList);

        application.setApplicationForm(applicationFormList);
        data.setApplication(application);
        business.setData(data);
        applyRunEngineReq.setBusiness(business);
    }

    private void fullDs020ApplyRunEngineReq(ApplyRunEngineReq applyRunEngineReq, DashufBlazeDto dashufBlazeDto, String creditReportNo) {
        applyRunEngineReq.setSystemId("DISP");
        applyRunEngineReq.setApplyId(dashufBlazeDto.getPushOrderLog().getPushOrderNo());
        applyRunEngineReq.setEngineNode("DS020");
        applyRunEngineReq.setInvokeType("SYN");
        applyRunEngineReq.setFicoScoreWanted("1");

        List<Customer> customerList = new ArrayList<>();
        Customer customer = new Customer();
        customer.setCustomerType("APPLICANT");
        customer.setCustomerName(dashufBlazeDto.getClientInfo().getClientName());
        customer.setCertType("Ind01");
        customer.setEmployeeType(dashufBlazeDto.getInfoEntry().getClientType());
        customer.setCreditReportId(creditReportNo);
        customer.setCertId(dashufBlazeDto.getClientInfo().getCertNo());
        customer.setPhoneNumber(dashufBlazeDto.getInfoEntry().getMobileNo());
        customerList.add(customer);
        applyRunEngineReq.setCustomerList(customerList);

        Business business = new Business();
        Data data = new Data();

        Application application = new Application();
        application.setDecisionArea("RISK");
        application.setCallNode("DS020");
        application.setFlowStep("prepared_product_selected");
        application.setRandomDigit(StringUtils.substring(dashufBlazeDto.getClientInfo().getId() + "", -4));
        application.setDecisionUser("DISP");
        application.setApplicationNumber(dashufBlazeDto.getPushOrderLog().getPushOrderNo());
        application.setApplicationDate(DateFormatUtils.format(dashufBlazeDto.getPushOrderLog().getPushStartTime(), DpbsSymbolCnst.DATE_FORMAT_YYYY_MM_DD_HH_MM_SS));
        application.setSource("DISP");
        application.setCertMaturity("0");

        List<ApplicationForm> applicationFormList = new ArrayList<>();
        ApplicationForm applicationForm = new ApplicationForm();
        applicationForm.setCustomername(dashufBlazeDto.getClientInfo().getClientName());
        applicationForm.setCerttype("Ind01");
        applicationForm.setCertId(dashufBlazeDto.getClientInfo().getCertNo());
        applicationForm.setCell(dashufBlazeDto.getInfoEntry().getMobileNo());
        applicationForm.setGender(dashufBlazeDto.getClientInfo().getGenderCd());
        applicationForm.setNation(dashufBlazeDto.getClientInfo().getNationCode());
        applicationForm.setWorkAddress(dashufBlazeDto.getInfoEntry().getWorkAddr());
        applicationForm.setResidentialAddress(dashufBlazeDto.getInfoEntry().getLifeAddr());
        applicationForm.setAge(dashufBlazeDto.getClientInfo().getClientAge());
        applicationForm.setEmployeeType(dashufBlazeDto.getInfoEntry().getClientType());
        applicationForm.setIdmaturity("0");
        applicationForm.setAuthorizedMan(DashufBlazeCnst.getCommonTrueFalseMap(dashufBlazeDto.getInfoEntry().getLegalPersonInd()));
        applicationForm.setShareHolder(DashufBlazeCnst.getCommonTrueFalseMap(dashufBlazeDto.getInfoEntry().getShareholderInd()));
        applicationForm.setRegister("0");
        applicationForm.setHouseholdRregister(dashufBlazeDto.getClientInfo().getHouseRegCode());


        BigDecimal totalCreditSupplyVal = new BigDecimal("0");
        if (DpbsCnst.TRUE_STR.equals(dashufBlazeDto.getPushOrderLog().getIfCreditSupply())) {
            List<AmtCalcInfo> amtCalcInfoList = new ArrayList<>();
            for (CreditSupplyInfo creditSupplyInfo : dashufBlazeDto.getCreditSupplyInfoList()) {
                AmtCalcInfo amtCalcInfo = new AmtCalcInfo();
                amtCalcInfo.setCreditcardInCarLoan(creditSupplyInfo.getMonthlyAmt());
                totalCreditSupplyVal = totalCreditSupplyVal.add(creditSupplyInfo.getMonthlyAmt());
                amtCalcInfoList.add(amtCalcInfo);
            }

            application.setAmtCalcInfo(amtCalcInfoList);
        }
        applicationForm.setCreditcardInCarLoan(totalCreditSupplyVal);


        List<CustMgrInfo> custMgrInfoList = new ArrayList<>();
        CustMgrInfo custMgrInfo = new CustMgrInfo();
        custMgrInfo.setOrgid(dashufBlazeDto.getUserInfo().getSrcCompanyCode());
        custMgrInfo.setSerialNo(dashufBlazeDto.getUserInfo().getSrcUmNo());
        custMgrInfo.setTeamNo(dashufBlazeDto.getUserInfo().getSrcTeamCode());
        custMgrInfoList.add(custMgrInfo);
        application.setCustMgrInfo(custMgrInfoList);

        BigDecimal totalInsuranceVal = new BigDecimal("0");
        if (DpbsCnst.TRUE_STR.equals(dashufBlazeDto.getPushOrderLog().getIfInsurance())) {
            Date tempMaxEffectiveDate = null;
            List<InsuranceInfo> insuranceInfoList = new ArrayList<>();
            for (com.dashuf.dpbs.model.InsuranceInfo insuranceInfo : dashufBlazeDto.getInsuranceList()) {
                InsuranceInfo insurance = new InsuranceInfo();
                insurance.setEffectiveType("1");
                insurance.setPolicyStatus("1");
                insurance.setInsurancefee(insuranceInfo.getPremiumAnnualAmt());
                totalInsuranceVal = totalInsuranceVal.add(insuranceInfo.getPremiumAnnualAmt());
                insurance.setEffectiveDate(DateFormatUtils.format(insuranceInfo.getEffectiveDate(), DpbsSymbolCnst.DATE_FORMAT_YYYY_MM_DD));
                insuranceInfoList.add(insurance);
                if (null == tempMaxEffectiveDate || tempMaxEffectiveDate.after(insuranceInfo.getEffectiveDate())) {
                    tempMaxEffectiveDate = insuranceInfo.getEffectiveDate();
                }
            }
            application.setInsuranceInfo(insuranceInfoList);
            if (null != tempMaxEffectiveDate) {
                applicationForm.setMaxInsuranceYear(DateFormatUtils.format(tempMaxEffectiveDate, DpbsSymbolCnst.DATE_FORMAT_YYYY_MM_DD));
            }
        }
        applicationForm.setInsuranceFee(totalInsuranceVal);

        BigDecimal totalHouseVal = new BigDecimal("0");
        if (DpbsCnst.TRUE_STR.equals(dashufBlazeDto.getPushOrderLog().getIfHouse())) {
            List<HousePropertyInfo> housePropertyInfoList = new ArrayList<>();
            for (HouseInfo houseInfo : dashufBlazeDto.getHouseInfoList()) {
                totalHouseVal = totalHouseVal.add(houseInfo.getTotalPriceAmt());
                HousePropertyInfo housePropertyInfo = new HousePropertyInfo();
                housePropertyInfo.setHouseAddress(houseInfo.getAddressCode());
                housePropertyInfo.setHouseType(houseInfo.getEstatesTypeCode());
                housePropertyInfoList.add(housePropertyInfo);
            }
            application.setHousePropertyInfo(housePropertyInfoList);
        }
        applicationForm.setHouseValue(totalHouseVal);

        List<ProductInfo> productInfoList = new ArrayList<>();
        ProductInfo productInfo = new ProductInfo();
        productInfo.setGuaranteeType("DDDD");//担保方式：DDDD
        productInfo.setPartnerName("RP88888888888888");//合作机构：RP88888888888888
        productInfo.setFundProvider("RL88888888888888");//资金机构：RL88888888888888
        productInfoList.add(productInfo);
        application.setApplicationProductInfo(productInfoList);

        List<Applicant> applicantList = new ArrayList<>();
        Applicant applicant = new Applicant();
        applicant.setCell(dashufBlazeDto.getInfoEntry().getMobileNo());
        applicant.setApplicatType("1");
        applicant.setCustomername(dashufBlazeDto.getClientInfo().getClientName());
        applicant.setCerttype("Ind01");
        applicant.setId(dashufBlazeDto.getClientInfo().getCertNo());
        applicantList.add(applicant);
        application.setApplicant(applicantList);

        applicationFormList.add(applicationForm);
        application.setApplicationForm(applicationFormList);
        data.setApplication(application);
        business.setData(data);
        applyRunEngineReq.setBusiness(business);
    }

}
