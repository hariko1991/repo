package com.dashuf.dpbs.app.web;

import com.alibaba.fastjson.JSON;
import com.dashuf.dpbs.app.DpbsUrl;
import com.dashuf.dpbs.app.annotation.LoginUser;
import com.dashuf.dpbs.app.web.req.lawsuit.LawSuitReq;
import com.dashuf.dpbs.app.web.resp.lawsuit.LawsuitResultResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.model.LawsuitQueryRecord;
import com.dashuf.dpbs.model.UserInfo;
import com.dashuf.dpbs.service.LawsuitService;
import com.dashuf.dpbs.service.UserInfoSupportService;
import com.dashuf.merlin.mybatis.page.Pagination;
import com.dashuf.merlin.web.base.views.ResponseVo;
import com.github.pagehelper.PageInfo;
import io.swagger.annotations.*;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import springfox.documentation.annotations.ApiIgnore;

/**
 * 诉讼相关接口
 *
 * @author yaojiaoyi
 */
@Api(value = "诉讼", tags = {"诉讼相关"})
@Slf4j
@RestController
@RequestMapping(DpbsUrl.LAWSUIT_REF)
public class LawsuitController {

    @Autowired
    private LawsuitService lawsuitService;
    @Autowired
    private UserInfoSupportService userInfoSupportService;

    /**
     * 诉讼实时查询列表
     *
     * @param lawSuitReq
     * @return
     */
    @ApiOperation(value = "诉讼实时查询列表")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "成功")})
    @GetMapping(value = "/lawsuit")
    public ResponseVo<LawsuitResultResp> getLawSuit(@Validated LawSuitReq lawSuitReq) {
        try {
            if (StringUtils.isEmpty(lawSuitReq.getCertNo()) || StringUtils.isEmpty(lawSuitReq.getName())) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, "请输入姓名和身份证号");
            }
            Integer count = lawsuitService.getLeftCount(lawSuitReq.getUserNo());
            if (count == 0) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, "剩余诉讼查询次数已用完");
            }
            return ResponseVo.success(lawsuitService.getLawsuit(lawSuitReq.getCertNo(), lawSuitReq.getName(), lawSuitReq.getUserNo()));
        } catch (Exception e) {
            log.error("获取诉讼实时查询列表过程中异常:lawSuitReq={},exception={}", JSON.toJSONString(lawSuitReq), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }

    }

    /**
     * 是否实名认证接口
     *
     * @param userInfo
     * @return
     */
    @ApiOperation(value = "查询是否实名认证")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "成功")})
    @PostMapping(value = "/isCertification")
    public ResponseVo getCertification(@ApiIgnore @LoginUser String loginUserNo) {
        try {
            UserInfo userInfo = userInfoSupportService.getUserInfo(loginUserNo);

            if (null != userInfo && DpbsCnst.NOT_VERIFIED.equals(userInfo.getIsVerify())) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, "请先实名认证");
            }
            return ResponseVo.success();
        } catch (Exception e) {
            log.error("查询是否实名认证过程中异常:exception={}", e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }

    }

    /**
     * 诉讼查询历史记录
     * 查询用户的查询记录
     *
     * @param userNo 用户编号
     * @return
     */
    @ApiOperation(value = "诉讼查询历史记录")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "成功")})
    @GetMapping(value = "/history")
    public ResponseVo<PageInfo<LawsuitQueryRecord>> getHistorySuitList(@RequestParam("userNo") String userNo,
                                                                       @ApiParam(value = "分页对象") Pagination pagination,
                                                                       @ApiIgnore @LoginUser String loginUserNo) {
        try {
            return ResponseVo.success(lawsuitService.getHistoryQueryRecord(loginUserNo, pagination));
        } catch (Exception e) {
            log.error("获取诉讼查询历史记录过程中异常:exception={}", e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    /**
     * 用户编号
     *
     * @param userNo
     * @return
     */
    @ApiOperation(value = "诉讼剩余查询次数")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "成功")})
    @GetMapping(value = "/count")
    public ResponseVo<Integer> getLeftCount(@RequestParam("userNo") String userNo, @ApiIgnore @LoginUser String loginUserNo) {
        try {
            return ResponseVo.success(lawsuitService.getLeftCount(loginUserNo));
        } catch (Exception e) {
            log.error("获取诉讼剩余查询次数过程中异常:exception={}", e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }

    }

    /**
     * 本地查询结果
     *
     * @param requestId 请求Id
     * @return
     */
    @ApiOperation(value = "本地查询结果")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "成功")})
    @GetMapping(value = "/{requestId}")
    public ResponseVo<LawsuitResultResp> getLocalResult(@PathVariable("requestId") Integer requestId) {
        try {
            return ResponseVo.success(lawsuitService.getLocalResult(requestId));
        } catch (Exception e) {
            log.error("获取本地查询结果过程中异常:exception={}", e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }

    }
}
