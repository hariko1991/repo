package com.dashuf.dpbs.app.web.resp.bean;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "查询影像Req")
@Getter
@Setter
public class FileBean implements Serializable {
	private static final long serialVersionUID = -5486873156541093682L;

	/**
	 * 批次号
	 */
	@ApiModelProperty(value = "批次号")
	private String contentId;
	/**
	 * 文件明细号
	 */
	@ApiModelProperty(value = "文件明细号")
	private String fileId;
	/**
	 * 文件明细地址
	 */
	@ApiModelProperty(value = "文件明细地址")
	private String fileUrl;
}
