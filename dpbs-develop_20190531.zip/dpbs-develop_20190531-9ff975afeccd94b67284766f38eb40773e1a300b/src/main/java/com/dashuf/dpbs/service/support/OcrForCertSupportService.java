package com.dashuf.dpbs.service.support;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.web.resp.support.GetOcrOfCertResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.sao.ocr.OcrForCertSAO;
import com.dashuf.dpbs.util.DpbsUtil;
import com.dashuf.merlin.web.base.views.ResponseVo;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

@Service
@Slf4j
public class OcrForCertSupportService {
    @Autowired
    private OcrForCertSAO ocrForCertSAO;

    public GetOcrOfCertResp ocrForCert(String pushOrderNo, MultipartFile file, JSONObject jsonObj) {
        String ocrOfCertNo = DpbsUtil.getTableNo("OCR");

        ResponseVo<String> ocrForCertResp = ocrForCertSAO.ocrForCert(ocrOfCertNo, file);
        log.info("推单号[{}]身份证识别结果:{}", pushOrderNo, JSONObject.toJSONString(ocrForCertResp));

        if ("00".equals(ocrForCertResp.getCode())) {
            GetOcrOfCertResp getOcrOfCertResp = new GetOcrOfCertResp();
            getOcrOfCertResp.setData(ocrForCertResp.getData());
            return getOcrOfCertResp;
        } else {
            jsonObj.put(DpbsCnst.RTN_MSG, ocrForCertResp.getMessage());
            return null;
        }
    }
}
