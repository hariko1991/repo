package com.dashuf.dpbs.app.web.req.user;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "客户以密码登录")
@Getter
@Setter
public class LoginPwdReq implements Serializable {

	private static final long serialVersionUID = -9028306805689397984L;

	/**
	 * 手机号码
	 */
	@ApiModelProperty(value = "手机号码")
	@NotBlank(message = "请输入正确的手机号")
	@Pattern(regexp = "^[1][0-9]{10}$", message = "请输入正确的手机号")
	private String mobileNo;

	/**
	 * 客户登录密码
	 */
	@ApiModelProperty(value = "客户登录密码")
	@NotBlank(message = "请输入密码")
	@Pattern(regexp = "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{8,16}$", message = "密码不符合规则，需8-16位数字与字母组合密码，区分大小写")
	private String userPwd;

	/**
	 * 微信code
	 */
	@ApiModelProperty(value = "微信授权码")
	private String wxCode;
}
