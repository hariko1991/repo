package com.dashuf.dpbs.service;

import com.dashuf.dpbs.app.web.resp.home.PosterResp;
import com.dashuf.dpbs.cnst.DpbsStatusCnst;
import com.dashuf.dpbs.mapper.PosterInfoMapper;
import com.dashuf.dpbs.model.PosterInfo;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * 海报相关service
 * @author yaojiaoyi
 */
@Service
public class PosterInfoService {
    @Autowired
    private PosterInfoMapper posterInfoMapper;

    public List<PosterResp> getPosterList(){
        PosterInfo cond=new PosterInfo();
        cond.setStatus(DpbsStatusCnst.NORMAL);
        List<PosterInfo> list=posterInfoMapper.selectByModelSelective(cond,true);
        List<PosterResp> rtnList=new ArrayList<>();
        list.forEach(posterInfo -> {
            PosterResp posterResp=new PosterResp();
            BeanUtils.copyProperties(posterInfo,posterResp);
            rtnList.add(posterResp);
        });
        return rtnList;
    }
}
