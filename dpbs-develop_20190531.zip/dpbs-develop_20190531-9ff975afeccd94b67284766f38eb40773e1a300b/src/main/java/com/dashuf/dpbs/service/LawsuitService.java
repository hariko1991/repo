package com.dashuf.dpbs.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.web.req.lawsuit.LawsuitParamReq;
import com.dashuf.dpbs.app.web.resp.lawsuit.LawSuitResp;
import com.dashuf.dpbs.app.web.resp.lawsuit.LawsuitResultResp;
import com.dashuf.dpbs.mapper.LawsuitQueryRecordMapper;
import com.dashuf.dpbs.mapper.LawsuitRequestLogMapper;
import com.dashuf.dpbs.mapper.PushOrderLogMapper;
import com.dashuf.dpbs.model.LawsuitQueryRecord;
import com.dashuf.dpbs.model.LawsuitRequestLog;
import com.dashuf.dpbs.sao.huifa.LawxinDataSao;
import com.dashuf.merlin.core.support.UserContext;
import com.dashuf.merlin.mybatis.page.Pagination;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import lombok.extern.slf4j.Slf4j;
import org.joda.time.format.DateTimeFormat;
import org.joda.time.format.DateTimeFormatter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 诉讼查询
 *
 * @author yaojiaoyi
 */
@Slf4j
@Service
public class LawsuitService {

    @Autowired
    private LawsuitQueryRecordMapper lawsuitQueryRecordMapper;

    @Autowired
    private LawsuitRequestLogMapper lawsuitRequestLogMapper;

    @Autowired
    private PushOrderLogMapper pushOrderLogMapper;

    @Autowired
    private LawxinDataSao lawxinDataSao;

    @Value("${application.lawxin.idenCode}")
    private String idenCode;

    @Value("${lawsuit.count.equalZero}")
    private Integer equalZero;
    @Value("${lawsuit.count.lessHund}")
    private Integer lessHund;
    @Value("${lawsuit.count.moreHund}")
    private Integer moreHund;

    private static final BigDecimal HUND = BigDecimal.valueOf(1000000);

    /**
     * 根据身份证号和姓名查询诉讼信息
     *
     * @param certNo
     * @param name
     * @return
     */
    public LawsuitResultResp getLawsuit(String certNo, String name, String userNo) {
        LawsuitResultResp lawsuitResultResp = new LawsuitResultResp();
        //查询日志流水入库
        LawsuitRequestLog lawsuitRequestLog = new LawsuitRequestLog();
        lawsuitRequestLog.setCertNo(certNo);
        lawsuitRequestLog.setName(name);
        lawsuitRequestLog.setUserNo(userNo);
        lawsuitRequestLog.setCreatedBy(UserContext.id());
        //获取汇法网诉讼查询结果
        String result = this.LawxinInfo(certNo, name);
        lawsuitRequestLog.setResult(result);
        lawsuitRequestLogMapper.insertSelective(lawsuitRequestLog);
        //查询是否已存在历史记录
        LawsuitQueryRecord cond = new LawsuitQueryRecord();
        cond.setCertNo(certNo);
        cond.setName(name);
        cond.setUserNo(userNo);
        LawsuitQueryRecord lawsuitQueryRecord = lawsuitQueryRecordMapper.selectOneByModelSelective(cond, true);
        if (lawsuitQueryRecord != null) {
            lawsuitQueryRecord.setQueryDate(new Date());
            lawsuitQueryRecord.setRequestId(lawsuitRequestLog.getId());
            lawsuitQueryRecordMapper.updateByPrimaryKeySelective(lawsuitQueryRecord);
        } else {
            lawsuitQueryRecord = new LawsuitQueryRecord();
            lawsuitQueryRecord.setCertNo(certNo);
            lawsuitQueryRecord.setName(name);
            lawsuitQueryRecord.setQueryDate(new Date());
            lawsuitQueryRecord.setRequestId(lawsuitRequestLog.getId());
            lawsuitQueryRecord.setUserNo(userNo);
            lawsuitQueryRecordMapper.insertSelective(lawsuitQueryRecord);
        }
        lawsuitResultResp.setCertNo(certNo);
        lawsuitResultResp.setName(name);
        lawsuitResultResp.setResult(result);
        lawsuitResultResp.setQueryDate(lawsuitQueryRecord.getQueryDate());
        return lawsuitResultResp;
    }

    private String LawxinInfo(String certNo, String name) {
        LawsuitParamReq lawsuit = new LawsuitParamReq();
        lawsuit.setId(certNo);
        lawsuit.setIdentifying_code(idenCode);
        lawsuit.setN(name);
        lawsuit.setStype("1");
        String rtnString = lawxinDataSao.getLawxinData(lawsuit);
        JSONObject jsonObject = JSON.parseObject(rtnString);
        JSONArray jsonArray = jsonObject.getJSONArray("allmsglist");
        DateTimeFormatter formatter = DateTimeFormat.forPattern("yyyy-MM-dd");
        List<LawSuitResp> list = new ArrayList<>();
        for (int i = 0; i < jsonArray.size(); i++) {
            LawSuitResp lawSuitResp = new LawSuitResp();
            JSONArray oneList = jsonArray.getJSONObject(i).getJSONArray("onemsglist");
            for (int j = 0; j < oneList.size(); j++) {
                JSONObject oneObject = oneList.getJSONObject(j);
                if (oneObject.getString("propername").equals("被执行人姓名或名称")) {
                    lawSuitResp.setExecName(oneObject.getString("propervalue"));
                }
                if (oneObject.getString("propername").equals("证件号码")) {
                    lawSuitResp.setCertNo(oneObject.getString("propervalue"));
                }
                if (oneObject.getString("propername").equals("执行法院")) {
                    lawSuitResp.setExecCourt(oneObject.getString("propervalue"));
                }
                if (oneObject.getString("propername").equals("执行案号")) {
                    lawSuitResp.setExecCase(oneObject.getString("propervalue"));
                }
                if (oneObject.getString("propername").equals("执行内容")) {
                    lawSuitResp.setExecContent(oneObject.getString("propervalue"));
                }
                if (oneObject.getString("propername").equals("立案时间")) {
                    lawSuitResp.setLawsuitDate(oneObject.getString("propervalue"));
                }
                if (oneObject.getString("propername").equals("执行状态")) {
                    lawSuitResp.setStatus(oneObject.getString("propervalue"));
                }
                if (oneObject.getString("propername").equals("异议备注")) {
                    lawSuitResp.setRemark(oneObject.getString("propervalue"));
                }
            }
            lawSuitResp.setTitle(jsonArray.getJSONObject(i).getString("title"));
            list.add(lawSuitResp);
        }
        return JSON.toJSONString(list);
    }

    /**
     * 历史查询记录
     *
     * @param userNo
     * @return
     */
    public PageInfo<LawsuitQueryRecord> getHistoryQueryRecord(String userNo, Pagination pagination) {
        LawsuitQueryRecord cond = new LawsuitQueryRecord();
        cond.setUserNo(userNo);
        pagination.setOrderBy("query_date desc");
        PageHelper.startPage(pagination);
        List<LawsuitQueryRecord> list = lawsuitQueryRecordMapper.selectByModelSelective(cond, true);
        return PageInfo.of(list);
    }

    public Integer getLeftCount(String userNo) {
        BigDecimal loanSum = pushOrderLogMapper.getLoanSum(userNo);
        //查询当月已用查询次数
        Integer useCount = lawsuitRequestLogMapper.getCount(userNo);
        if (loanSum.compareTo(BigDecimal.valueOf(0)) == 0) {
            return equalZero - useCount <= 0 ? 0 : equalZero - useCount;
        } else if (loanSum.compareTo(HUND) < 0) {
            return lessHund - useCount <= 0 ? 0 : lessHund - useCount;
        } else {
            return moreHund - useCount <= 0 ? 0 : moreHund - useCount;
        }
    }


    /**
     * 诉讼查询结果页列表
     *
     * @param requestId
     * @return
     */
    public LawsuitResultResp getLocalResult(Integer requestId) {
        LawsuitResultResp result = lawsuitQueryRecordMapper.getLocalResult(requestId);
        return result;
    }
}
