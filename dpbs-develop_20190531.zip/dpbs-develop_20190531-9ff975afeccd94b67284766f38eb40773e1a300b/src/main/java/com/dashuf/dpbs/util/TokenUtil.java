package com.dashuf.dpbs.util;

import com.dashuf.merlin.jwt.autoconfigure.JwtTokens;
import io.jsonwebtoken.Claims;
import io.jsonwebtoken.Jws;
import io.jsonwebtoken.Jwts;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class TokenUtil {

	@Autowired
	private JwtTokens jwtTokens;

	/**
	 * 生成token
	 *
	 * @param id 一般传入手机号码
	 * @return
	 */
	public String createJwtToken(String id, long ttlMillis) {
		String issuer = "dashu";
		String subject = "xxxx@126.com";
		return createJwtToken(id, issuer, subject, ttlMillis);
	}

	/**
	 * 生成Token
	 *
	 * @param id        编号
	 * @param issuer    该JWT的签发者，是否使用是可选的
	 * @param subject   该JWT所面向的用户，是否使用是可选的；
	 * @param ttlMillis 签发时间 （有效时间，过期会报错）
	 * @return token String
	 */
	public String createJwtToken(String id, String issuer, String subject, long ttlMillis) {
		jwtTokens.create(ttlMillis);

		Claims claims = Jwts.claims();
		claims.setExpiration(new Date(System.currentTimeMillis() + ttlMillis));
		claims.setIssuer(issuer);
		claims.put("id", id);
		String token = jwtTokens.create(claims);
		return token;
	}

	/**
	 * 解析token
	 * 
	 * @param token
	 * @return
	 */
	public Claims parseJWT(String token) {
		Jws<Claims> claimsJws = jwtTokens.parser(token);
		Claims claims = claimsJws.getBody();
		return claims;
	}

}
