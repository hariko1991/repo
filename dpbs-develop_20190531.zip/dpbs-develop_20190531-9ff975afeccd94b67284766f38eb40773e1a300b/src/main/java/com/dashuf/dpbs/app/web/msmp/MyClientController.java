package com.dashuf.dpbs.app.web.msmp;

import com.dashuf.dpbs.app.annotation.LoginRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dashuf.dpbs.app.DpbsForMsmpUrl;
import com.dashuf.dpbs.app.web.req.msmp.ClientPageReq;
import com.dashuf.dpbs.app.web.resp.msmp.MyClientResp;
import com.dashuf.dpbs.service.MsmpSupportService;
import com.dashuf.merlin.web.base.views.ResponseVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Api(value = "移动销售平台我的客户相关", tags = { "移动销售平台我的客户相关" })
@Slf4j
@RestController
@RequestMapping(DpbsForMsmpUrl.MSMP_MY_CLIENT)
public class MyClientController {
	@Autowired
	private MsmpSupportService chipSupportService;

	@ApiOperation(value = "获取我的客户页面列表")
	@PostMapping("/getPage")
	@LoginRole
	public ResponseVo<MyClientResp> getPage(@RequestBody @Validated ClientPageReq clientPageReq) {
		MyClientResp myClientResp = new MyClientResp();
		myClientResp.setClientBeanPage(chipSupportService.selectClientPage(clientPageReq.getPageNum(), clientPageReq.getPageSize(),
				clientPageReq.getCustManager(), clientPageReq.getClientName()));
		return new ResponseVo<>(myClientResp);
	}
}
