package com.dashuf.dpbs.sao.cids.resp;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class GiveScoreDs020Resp implements Serializable {
    /**
     * fullName	string 必须 姓名
     */
    private String fullName;
    /**
     * idNum	string 必须 身份证号
     */
    private String idNum;
    /**
     * decisionId	string 必须 决策编号
     */
    private String decisionId;
}
