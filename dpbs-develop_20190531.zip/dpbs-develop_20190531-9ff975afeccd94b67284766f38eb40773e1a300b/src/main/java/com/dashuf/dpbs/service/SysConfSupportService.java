package com.dashuf.dpbs.service;

import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.SysConfCnst;
import com.dashuf.dpbs.mapper.SysConfMapper;
import com.dashuf.dpbs.model.SysConf;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class SysConfSupportService {

    @Autowired
    private SysConfMapper sysConfMapper;
    @Autowired
    private CacheInitService cacheInitService;
    @Autowired
    private StringRedisTemplate redisTemplate;

    public String selectValueFromDb(SysConf sysConf) {
        String confVal = sysConfMapper.selectValue(sysConf);
        log.info("查询模块编号[{}],模块子编码[{}],键[{}],值[{}]", sysConf.getModuleCode(), sysConf.getModuleSubCode(), sysConf.getModuleKey(), confVal);
        return confVal;
    }

    public String selectValueFromCache(String moduleCode, String moduleSubCode, String moduleKey) {
        SysConf sysConf = new SysConf();
        sysConf.setModuleCode(moduleCode);
        sysConf.setModuleSubCode(moduleSubCode);
        sysConf.setModuleKey(moduleKey);

        String redisKey = cacheInitService.getRedisKey(sysConf);
        String confVal = redisTemplate.opsForValue().get(DpbsCnst.REDIS_DPBS_SYS_CONF + redisKey);
        log.info("从缓存中获取键[{}]的值为[{}]", redisKey, confVal);
        return confVal;
    }

    public String selectValueFromCache(SysConf sysConf) {
        String redisKey = cacheInitService.getRedisKey(sysConf);
        String confVal = redisTemplate.opsForValue().get(DpbsCnst.REDIS_DPBS_SYS_CONF + redisKey);
        log.info("从缓存中获取键[{}]的值为[{}]", redisKey, confVal);
        return confVal;
    }

    public boolean selectMockValFromCache() {
        SysConf sysConfParam = new SysConf();
        sysConfParam.setModuleCode(SysConfCnst.DATA_MOCK);
        sysConfParam.setModuleSubCode(SysConfCnst.DATA_MOCK);
        sysConfParam.setModuleKey(SysConfCnst.DATA_MOCK);
        String isMock = selectValueFromCache(sysConfParam);
        return "true".equals(isMock);
    }

    public boolean selectMockValFromCache(String mockModuleCode) {
        SysConf sysConfParam = new SysConf();
        sysConfParam.setModuleCode(SysConfCnst.DATA_MOCK);
        sysConfParam.setModuleSubCode(SysConfCnst.DATA_MOCK);
        sysConfParam.setModuleKey(SysConfCnst.DATA_MOCK);
        String mockValue = selectValueFromCache(sysConfParam);

        if (StringUtils.isEmpty(mockValue)) {
            return false;
        }
        return mockValue.contains(mockModuleCode);
    }

    public int updateValueForDb(SysConf sysConf) {
        int dealCnt = sysConfMapper.updateValue(sysConf);
        log.info("更新模块编号[{}],模块子编码[{}],键[{}],值[{}]结果为:[{}]", sysConf.getModuleCode(), sysConf.getModuleSubCode(), sysConf.getModuleKey(), sysConf.getModuleVal(), dealCnt);
        return dealCnt;
    }

    public void updateValueFromCache(SysConf sysConf) {
        String redisKey = cacheInitService.getRedisKey(sysConf);
        redisTemplate.opsForValue().set(DpbsCnst.REDIS_DPBS_SYS_CONF + redisKey, sysConf.getModuleVal());
        log.info("更新缓存键[{}]的值[{}]", redisKey, sysConf.getModuleVal());
    }
}
