package com.dashuf.dpbs.job;


import com.alibaba.fastjson.JSONObject;
import com.dangdang.ddframe.job.api.ShardingContext;
import com.dangdang.ddframe.job.api.simple.SimpleJob;
import com.dashuf.dpbs.cnst.DpbsStatusCnst;
import com.dashuf.dpbs.model.PushOrderLog;
import com.dashuf.dpbs.service.blaze.ThirdPartyAccessSupportService;
import com.dashuf.merlin.core.support.MyThreadContext;
import com.dashuf.merlin.util.UUIDShort;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.MDC;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Slf4j
@Component
public class Ds020AndPushClientJob implements SimpleJob {
    @Autowired
    private ThirdPartyAccessSupportService thirdPartyAccessSupportService;

    @Override
    public void execute(ShardingContext shardingContext) {
        String traceId = UUIDShort.generate();
        MyThreadContext.setTraceId(traceId);
        MDC.put(MyThreadContext.MDC_TRACE_ID, MyThreadContext.getTraceId());

        List<PushOrderLog> needHandleList = thirdPartyAccessSupportService.queryNeedGetDs020List();

        log.info("Ds020AndPushClientJob任务需要处理任务条数[{}]", needHandleList.size());
        if (CollectionUtils.isEmpty(needHandleList)) {
            MDC.remove(MyThreadContext.MDC_TRACE_ID);
            return;
        }

        for (PushOrderLog pushOrderLog : needHandleList) {
            log.info("Ds020AndPushClientJob推送订单号[{}],推送状态为[{}]", pushOrderLog.getPushOrderNo(), pushOrderLog.getPushStatus());
            JSONObject jsonObj = new JSONObject();
            boolean isLock = false;

            try {
                if (thirdPartyAccessSupportService.lockPushOrderLog(pushOrderLog.getPushOrderNo(), jsonObj)) {
                    log.info("推单号[{}],状态为[{}],抢占成功继续执行业务逻辑", pushOrderLog.getPushOrderNo(), pushOrderLog.getPushStatus());
                    isLock = true;
                    //如果是征信授权成功,需要进行ds010
                    if (DpbsStatusCnst.PUSH_CREDIT.equals(pushOrderLog.getPushStatus())) {
                        thirdPartyAccessSupportService.initScreenDs010(pushOrderLog, jsonObj);
                    }

                    //如果是初评中,需要进行ds020
                    if (DpbsStatusCnst.PUSH_EVAL_ING.equals(pushOrderLog.getPushStatus())) {
                        thirdPartyAccessSupportService.queryScoreDs020(pushOrderLog, jsonObj);
                    }

                    //如果是初评成功或者推送客户中,就推送客户
                    if (DpbsStatusCnst.PUSH_EVAL_SUCCESS.equals(pushOrderLog.getPushStatus())) {
                        thirdPartyAccessSupportService.pushClient(pushOrderLog.getPushOrderNo(), jsonObj);
                    }
                } else {
                    log.error("推单号[{}],状态为[{}],抢占失败继续执行下一笔推单业务逻辑", pushOrderLog.getPushOrderNo(), pushOrderLog.getPushStatus());
                }

            } catch (Exception e) {
                log.error("Ds020AndPushClientJob推送订单号[{}]任务过程中异常:{}", pushOrderLog.getPushOrderNo(), e);
            } finally {
                if (isLock) {
                    thirdPartyAccessSupportService.unLockPushOrderLog(pushOrderLog.getPushOrderNo(), jsonObj);
                }
            }
        }

        MDC.remove(MyThreadContext.MDC_TRACE_ID);
    }
}
