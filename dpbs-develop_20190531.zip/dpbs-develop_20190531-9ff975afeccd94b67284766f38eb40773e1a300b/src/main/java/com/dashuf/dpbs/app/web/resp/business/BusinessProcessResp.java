package com.dashuf.dpbs.app.web.resp.business;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author yaojiaoyi
 */
@ApiModel("业务进度列表")
@Getter
@Setter
public class BusinessProcessResp {
    @ApiModelProperty(value = "推送订单编号")
    private String pushOrderNo;

    @ApiModelProperty(value = "客户姓名", required = true)
    private String clientName;

    @ApiModelProperty("推单开始时间-身份证扫描时间")
    private Date pushStartTime;

    @ApiModelProperty("推单结束时间-推单时间")
    private Date pushEndTime;
}
