package com.dashuf.dpbs.service;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.web.resp.QrCodeResp;
import com.dashuf.dpbs.app.web.resp.credit.AnalysisQrCodeResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.DpbsStatusCnst;
import com.dashuf.dpbs.mapper.ClientInfoMapper;
import com.dashuf.dpbs.mapper.InfoEntryMapper;
import com.dashuf.dpbs.mapper.QrCodeInfoMapper;
import com.dashuf.dpbs.model.ClientInfo;
import com.dashuf.dpbs.model.InfoEntry;
import com.dashuf.dpbs.model.QrCodeInfo;
import com.dashuf.dpbs.service.support.WxSupportService;
import com.dashuf.dpbs.util.DpbsUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
@Slf4j
public class QrCodeSupportService {
    private static final String GET_SHOW_QR_CODE_URL = "https://mp.weixin.qq.com/cgi-bin/showqrcode?ticket=%s";

    @Autowired
    private ClientInfoMapper clientInfoMapper;
    @Autowired
    private InfoEntryMapper infoEntryMapper;
    @Autowired
    private QrCodeInfoMapper qrCodeInfoMapper;
    @Autowired
    private WxSupportService wxSupportService;

    public QrCodeResp initQrCodeResp(String pushOrderNo, JSONObject jsonObj) {
        InfoEntry infoEntryParam = new InfoEntry();
        infoEntryParam.setPushOrderNo(pushOrderNo);
        InfoEntry infoEntry = infoEntryMapper.selectOneByModelSelective(infoEntryParam, DpbsCnst.SQL_PRECISE_STRICT);

        ClientInfo clientInfo = clientInfoMapper.selectByPushOrderNo(pushOrderNo);

        QrCodeResp qrCodeResp = new QrCodeResp();
        qrCodeResp.setClientName(clientInfo.getClientName());
        qrCodeResp.setCertNo(clientInfo.getCertNo());
        qrCodeResp.setMobileNo(clientInfo.getMobileNo());

        QrCodeInfo qrCodeInfo = new QrCodeInfo();
        String qrCodeInfoNo = DpbsUtil.getTableNo(DpbsUtil.PREFIX_QR_CODE_INFO);
        qrCodeInfo.setQrNo(qrCodeInfoNo);
        qrCodeInfo.setPushOrderNo(pushOrderNo);
        qrCodeInfo.setClientNo(clientInfo.getClientNo());
        qrCodeInfo.setClientName(clientInfo.getClientName());
        qrCodeInfo.setCertNo(clientInfo.getCertNo());
        qrCodeInfo.setMobileNo(infoEntry.getMobileNo());
        qrCodeInfo.setStatus(DpbsStatusCnst.INIT);

        String ticket = wxSupportService.getQrCodeUrl(qrCodeInfo, jsonObj);
        if (StringUtils.isEmpty(ticket)) {
            qrCodeResp.setRtnCode(jsonObj.getString(DpbsCnst.RTN_CODE));
            qrCodeResp.setRtnMsg(jsonObj.getString(DpbsCnst.RTN_MSG));
            return qrCodeResp;
        }

        qrCodeInfo.setTicket(ticket);
        String getQrCodeUrl = String.format(GET_SHOW_QR_CODE_URL, ticket);
        log.info("推送订单号[{}]生成二维码地址[{}]", pushOrderNo, getQrCodeUrl);

        qrCodeResp.setQrCodeUrl(getQrCodeUrl);
        int dealCnt = qrCodeInfoMapper.initQrCodeInfo(qrCodeInfo);
        if (DpbsCnst.NUMBER_1 > dealCnt) {
            jsonObj.put(DpbsCnst.RTN_MSG, "二维码信息初始化失败");
            return null;
        }
        return qrCodeResp;
    }


    public AnalysisQrCodeResp analysisQrCode(String qrCodeInfoNo, String analysisType, JSONObject jsonObj) {
        QrCodeInfo qrCodeInfo = qrCodeInfoMapper.selectUniqueQrCodeInfo(qrCodeInfoNo);
        if (null == qrCodeInfo) {
            jsonObj.put(DpbsCnst.RTN_MSG, "二维码信息不正确");
            return null;
        }

        if ("qr_code".equals(analysisType)) {
            QrCodeInfo qrCodeInfoParam = new QrCodeInfo();
            qrCodeInfoParam.setQrNo(qrCodeInfoNo);
            qrCodeInfoParam.setStatus(DpbsStatusCnst.SUCCESS);
            int dealCnt = qrCodeInfoMapper.updateQrCodeInfoByOrgStatus(qrCodeInfoParam, DpbsStatusCnst.INIT);
            if (DpbsCnst.NUMBER_1 != dealCnt) {
                jsonObj.put(DpbsCnst.RTN_MSG, "公众号链接已失效,请重新扫描征信二维码");
                return null;
            }
        }

        AnalysisQrCodeResp analysisQrCodeResp = new AnalysisQrCodeResp();
        BeanUtils.copyProperties(qrCodeInfo, analysisQrCodeResp);
        return analysisQrCodeResp;
    }
}
