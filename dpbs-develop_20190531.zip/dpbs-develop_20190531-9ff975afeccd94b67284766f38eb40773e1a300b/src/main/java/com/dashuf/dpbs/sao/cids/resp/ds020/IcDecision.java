package com.dashuf.dpbs.sao.cids.resp.ds020;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
public class IcDecision implements Serializable {
    private static final long serialVersionUID = -8352272194751257335L;
}
