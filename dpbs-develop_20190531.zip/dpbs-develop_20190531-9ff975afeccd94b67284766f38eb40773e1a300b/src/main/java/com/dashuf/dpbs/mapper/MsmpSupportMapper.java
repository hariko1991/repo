package com.dashuf.dpbs.mapper;

import java.util.List;
import java.util.Map;

import com.dashuf.dpbs.model.UserInfo;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import com.dashuf.dpbs.app.web.resp.msmp.ClientBean;
import com.dashuf.dpbs.app.web.resp.msmp.UserBean;

@Mapper
public interface MsmpSupportMapper {
    public static final String USER_NO = "userNo";
    public static final String CLIENT_NAME = "clientName";
    public static final String USER_NAME = "userName";
    public static final String CUST_MANAGER = "custManager";


    public List<UserBean> getUserList(@Param(CUST_MANAGER) String custManager, @Param(USER_NAME) String userName);

    public List<ClientBean> getClientList(@Param(CUST_MANAGER) String custManager, @Param(CLIENT_NAME) String clientName);

    public List<ClientBean> getPendClientList(@Param(USER_NO) String userNo, @Param(CLIENT_NAME) String clientName);

    public List<ClientBean> getAlreadyClientList(@Param(USER_NO) String userNo, @Param(CLIENT_NAME) String clientName);

    public int modifyUserCompany(UserInfo userInfo);

    public UserBean getDetailOfUser(@Param(USER_NO) String userNo);

    public Map<String, Object> statUserReconForm(@Param(USER_NO) String userNo);
}
