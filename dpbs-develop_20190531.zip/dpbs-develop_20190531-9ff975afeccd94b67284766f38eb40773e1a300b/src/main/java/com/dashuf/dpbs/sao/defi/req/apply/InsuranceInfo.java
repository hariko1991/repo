package com.dashuf.dpbs.sao.defi.req.apply;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
public class InsuranceInfo implements Serializable {

    private static final long serialVersionUID = 6443272747297835311L;

    /**
     * PolicyNo	string 非必须 保单编号
     */
    @JsonProperty(value = "PolicyNo")
    private String policyNo;
    /**
     * Insurancefee	string 非必须 年缴保费
     */
    private BigDecimal insurancefee;
    /**
     * PolicyStatus	string 非必须 保单状态
     */
    private String policyStatus;
    /**
     * PaymentType	string 非必须 缴费方式
     */
    @JsonProperty(value = "PaymentType")
    private String paymentType;
    /**
     * PayablePeriod	string 非必须 应交期次
     */
    @JsonProperty(value = "PayablePeriod")
    private String payablePeriod;
    /**
     * PaidinPeriod	string 非必须 交费次数
     */
    @JsonProperty(value = "PaidinPeriod")
    private String paidinPeriod;
    /**
     * IsChangeofHolder	string 非必须 两年内是否变更过投保人
     */
    @JsonProperty(value = "IsChangeofHolder")
    private String isChangeofHolder;
    /**
     * EffectiveType	string 非必须 保单是否有效
     */
    private String effectiveType;
    /**
     * EffectiveDate	string 非必须 保单生效日期
     */
    @JsonProperty(value = "effectiveDate")
    private String effectiveDate;
}
