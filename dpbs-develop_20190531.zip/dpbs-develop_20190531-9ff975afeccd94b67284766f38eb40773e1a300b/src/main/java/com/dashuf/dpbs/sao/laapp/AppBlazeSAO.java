package com.dashuf.dpbs.sao.laapp;

import com.dashuf.dpbs.sao.laapp.req.AllowPushClientReq;
import com.dashuf.dpbs.sao.laapp.req.PushClientQueryReq;
import com.dashuf.dpbs.sao.laapp.req.PushClientReq;
import com.dashuf.dpbs.sao.laapp.resp.AllowPushClientResp;
import com.dashuf.dpbs.sao.laapp.resp.PushClientResp;
import com.dashuf.merlin.web.base.views.ResponseVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "LAAPP")
public interface AppBlazeSAO {

    @PostMapping(value = "/laapp/v1/reservation/subscribe")
    public ResponseVo<PushClientResp> pushClient(@RequestBody PushClientReq pushClientReq);

    @PostMapping(value = "/laapp/v1/reservation/queryStatus")
    public void queryPushClient(@RequestBody PushClientQueryReq pushClientQueryReq);

    @PostMapping(value = "/laapp/v1/reservation/queryCustomerStatus")
    public ResponseVo<AllowPushClientResp> queyClientIsAllownPush(@RequestBody AllowPushClientReq allowPushClientReq);
}
