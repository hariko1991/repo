package com.dashuf.dpbs.service.support;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.DpbsSymbolCnst;
import com.dashuf.dpbs.cnst.SftpCnst;
import com.dashuf.dpbs.cnst.SysConfCnst;
import com.dashuf.dpbs.sao.dsfg.CreditAuthSAO;
import com.dashuf.dpbs.sao.dsfg.UploadCreditFileResp;
import com.dashuf.dpbs.sao.dsfg.req.UploadCreditFileReq;
import com.dashuf.dpbs.service.SysConfSupportService;
import com.dashuf.dpbs.service.support.dto.ElecCreditAuthDto;
import com.dashuf.merlin.ftb.service.FtbService;
import com.dashuf.merlin.web.base.views.ResponseVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.File;
import java.util.*;

@Service
@Slf4j
public class ZldSignSupportService {
    private static final String MAIN_SUCESS = "SUC000";
    private static final String SUB_SUCCESS = "0000";
    private static final String SIGN_FILE1 = "file1";
    private static final String SIGN_FILE2 = "file2";
    private static final Map<String, String> signFileMap = new HashMap<>();
    private static final List<String> signFileList = Arrays.asList(new String[]{SIGN_FILE1, SIGN_FILE2});
    private static final String PDF_SUFFIX = ".pdf";

    static {
        signFileMap.put(SIGN_FILE1, "EGDAHT");
        signFileMap.put(SIGN_FILE2, "ECQA");
    }

    @Autowired
    private SftpSupportService sftpSupportService;
    @Autowired
    private SysConfSupportService sysConfSupportService;
    @Autowired
    private FtbService ftbService;
    @Autowired
    private CreditAuthSAO creditAuthSAO;

    public boolean uploadFileToZldSftp(ElecCreditAuthDto elecCreditAuthDto, JSONObject signJsonObj, JSONObject jsonObj) {
        log.info("根据签章结果上传文件到zld文件服务器:{}", signJsonObj.toJSONString());

        if (sysConfSupportService.selectMockValFromCache(SysConfCnst.DATA_MOCK_OF_UPLOAD_ZLD)) {
            return true;
        }

        List<File> needUploadFileList = new ArrayList<>();
        try {
            String sftpConfForZld = sysConfSupportService.selectValueFromCache(SysConfCnst.MODULE_CODE_OF_ZLD_SFTP_CONF, SysConfCnst.MODULE_SUB_CODE_OF_ZLD_SFTP_CONF, SysConfCnst.MODULE_KEY_OF_ZLD_SFTP_CONF);
            JSONObject sftpConfForZldJsonObj = JSONObject.parseObject(sftpConfForZld);
            String localPath = sftpConfForZldJsonObj.getString(SftpCnst.SFTP_REQ_LOCAL_PATH);


            List<UploadCreditFileReq.UploadCreditFile> uploadCreditFileList = new ArrayList<>();
            for (String fileId : signJsonObj.keySet()) {
                if (signFileList.contains(fileId)) {
                    String fileName = new StringBuffer(elecCreditAuthDto.getCertName()).append(DpbsSymbolCnst.SYMBOL_VERTICAL).append(elecCreditAuthDto.getCertNo()).append(DpbsSymbolCnst.SYMBOL_VERTICAL).append(signJsonObj.getString(fileId)).append(PDF_SUFFIX).toString();
                    File file = ftbService.downloadFile(signJsonObj.getString(fileId), localPath, fileName);
                    needUploadFileList.add(file);
                    UploadCreditFileReq.UploadCreditFile uploadCreditFile = new UploadCreditFileReq.UploadCreditFile();
                    uploadCreditFile.setPath(sftpConfForZldJsonObj.getString(SftpCnst.SFTP_REQ_REMOTE_PATH) + "/" + fileName);
                    uploadCreditFile.setFileType(signFileMap.get(fileId));
                    uploadCreditFileList.add(uploadCreditFile);
                }
            }

            if (!sftpSupportService.localFileListToSftp(sftpConfForZldJsonObj, needUploadFileList)) {
                return false;
            }

            UploadCreditFileReq uploadCreditFileReq = new UploadCreditFileReq();
            uploadCreditFileReq.setCertId(elecCreditAuthDto.getCertNo());
            uploadCreditFileReq.setCustName(elecCreditAuthDto.getCertName());
            uploadCreditFileReq.setQueryChannel(DpbsCnst.SYSTEM_NAME);
            uploadCreditFileReq.setPaths(uploadCreditFileList);

            ResponseVo<UploadCreditFileResp> uploadCreditFileResp = creditAuthSAO.uploadCreditFile(uploadCreditFileReq);
            if (MAIN_SUCESS.equals(uploadCreditFileResp.getCode())) {
                UploadCreditFileResp resp = uploadCreditFileResp.getData();
                if (null != resp && SUB_SUCCESS.equals(resp.getResult())) {
                    return true;
                } else {
                    jsonObj.put(DpbsCnst.RTN_MSG, null != resp ? resp.getMsg() : "");
                    return false;
                }
            } else {
                jsonObj.put(DpbsCnst.RTN_MSG, uploadCreditFileResp.getMessage());
                return false;
            }
        } catch (Exception e) {
            log.error("根据签章结果上传文件到zld文件服务器过程中异常：{}", e);
            jsonObj.put(DpbsCnst.RTN_MSG, DpbsCnst.SERVER_ERROR);
            return false;
        } finally {
            if (CollectionUtils.isNotEmpty(needUploadFileList)) {
                needUploadFileList.forEach(needUploadFile -> {
                    FileUtils.deleteQuietly(needUploadFile);
                });
            }
        }
    }

}
