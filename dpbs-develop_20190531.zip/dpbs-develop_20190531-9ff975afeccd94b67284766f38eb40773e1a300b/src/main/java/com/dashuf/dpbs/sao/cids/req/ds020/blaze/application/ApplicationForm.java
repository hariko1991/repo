package com.dashuf.dpbs.sao.cids.req.ds020.blaze.application;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class ApplicationForm implements Serializable {

    private static final long serialVersionUID = 203566485179547058L;

    /**
     * "accumulationfund": "0",
     */
    private String accumulationfund;
    /**
     * "autreason": "010",
     */
    private String autreason;
    /**
     * "certId": "360104196407031926",
     */
    private String certId;
    /**
     * "certtype": "Ind01",
     */
    private String certtype;
    /**
     * "customername": "钱汇明",
     */
    private String customername;
    /**
     * "eduDegree": "01",
     */
    private String eduDegree;
    /**
     * "educationEx": "01",
     */
    private String educationEx;
    /**
     * "employeetype": "060",
     */
    private String employeetype;
    /**
     * "familyProvinces": "110105",
     */
    private String familyProvinces;
    /**
     * "graduateyear": "2010/07/01",
     */
    private String graduateyear;
    /**
     * "gwylevel": "",
     */
    private String gwylevel;
    /**
     * "housevalue": 0,
     */
    private String housevalue;
    /**
     * "iDMaturity": "0",
     */
    private String iDMaturity;
    /**
     * "idmaturity": "0",
     */
    private String idmaturity;
    /**
     * "incomeSource": "",
     */
    private String incomeSource;
    /**
     * "individualtype": "",
     */
    private String individualtype;
    /**
     * "insurancefee": 3902,
     */
    private String insurancefee;
    /**
     * "isDfgz": "0",
     */
    private String isDfgz;
    /**
     * "isGwy": "0",
     */
    private String isGwy;
    /**
     * "jobInfo": "1",
     */
    private String jobInfo;
    /**
     * "marriage": "50",
     */
    private String marriage;
    /**
     * "maxInsuranceYear": "1900",
     */
    private String maxInsuranceYear;
    /**
     * "monthIncome": 0,
     */
    private String monthIncome;
    /**
     * "originalPayment": 0,
     */
    private String originalPayment;
    /**
     * "partnerName": "BK20180118666666",
     */
    private String partnerName;
    /**
     * "register": "",
     */
    private String register;
    /**
     * "serviceCentre": "",
     */
    private String serviceCentre;
    /**
     * "sex": "2",
     */
    private String sex;
    /**
     * "sharesituation": "",
     */
    private String sharesituation;
    /**
     * "workProvinces": "110105",
     */
    private String workProvinces;
    /**
     * "ywBd": "1",
     */
    private String ywBd;
    /**
     * "ywFc": "1",
     */
    private String ywFc;
    /**
     * "ywXl": "1",
     */
    private String ywXl;
    /**
     * "ywXykcd": "0"
     */
    private String ywXykcd;
}
