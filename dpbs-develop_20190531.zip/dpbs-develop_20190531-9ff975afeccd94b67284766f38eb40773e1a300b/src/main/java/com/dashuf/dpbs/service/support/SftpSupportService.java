package com.dashuf.dpbs.service.support;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.cnst.SftpCnst;
import com.dashuf.dpbs.util.sftp.FileProgressMonitor;
import com.dashuf.dpbs.util.sftp.SFTPChannel;
import com.jcraft.jsch.ChannelSftp;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.io.*;
import java.util.List;

@Service
@Slf4j
public class SftpSupportService {

    public void closeChannelSftp(ChannelSftp channelSftp, SFTPChannel channel) throws Exception {
        if (channelSftp != null) {
            channelSftp.quit();
        }
        if (channel != null) {
            channel.closeChannel();
        }
    }

    public boolean localFileToSftp(JSONObject sftpJsonObj, File file) throws Exception {
        FileInputStream ins = null;
        SFTPChannel channel = null;
        ChannelSftp chSftp = null;
        try {
            int defaultTimeout = SftpCnst.SFTP_REQ_REMOTE_DEFAULT_TIMEOUT;
            String defaultRemoteTimeout = sftpJsonObj.getString(SftpCnst.SFTP_REQ_REMOTE_TIMEOUT);
            if (StringUtils.isNotEmpty(defaultRemoteTimeout)) {
                defaultTimeout = Integer.valueOf(defaultRemoteTimeout);
            }

            ins = new FileInputStream(file);
            channel = new SFTPChannel();
            chSftp = channel.getChannel(sftpJsonObj, defaultTimeout);
            String filePath = sftpJsonObj.getString(SftpCnst.SFTP_REQ_REMOTE_PATH) + "/" + file.getName();
            chSftp.put(ins, filePath, new FileProgressMonitor(ins.available()), ChannelSftp.OVERWRITE); // 代码段2
            return true;
        } catch (Exception e) {
            log.error(" error is fileStoreToSftp An exception is thrown here :  ", e);
            return false;
        } finally {
            if (chSftp != null) {
                chSftp.quit();
            }
            if (channel != null) {
                channel.closeChannel();
            }
            if (ins != null) {
                ins.close();
            }
        }
    }

    public boolean localFileListToSftp(JSONObject sftpJsonObj, List<File> fileList) throws Exception {
        SFTPChannel channel = null;
        ChannelSftp chSftp;
        try {
            int defaultTimeout = SftpCnst.SFTP_REQ_REMOTE_DEFAULT_TIMEOUT;
            String defaultRemoteTimeout = sftpJsonObj.getString(SftpCnst.SFTP_REQ_REMOTE_TIMEOUT);
            if (StringUtils.isNotEmpty(defaultRemoteTimeout)) {
                defaultTimeout = Integer.valueOf(defaultRemoteTimeout);
            }

            channel = new SFTPChannel();
            chSftp = channel.getChannel(sftpJsonObj, defaultTimeout);
        } catch (Exception sftpException) {
            if (null != channel) {
                channel.closeChannel();
            }
            log.error(" error is create sftp An exception is thrown here :  {}", sftpException);
            return false;
        }

        for (File file : fileList) {
            FileInputStream fis = null;
            try {
                fis = new FileInputStream(file);
                String filePath = sftpJsonObj.getString(SftpCnst.SFTP_REQ_REMOTE_PATH) + "/" + file.getName();
                chSftp.put(fis, filePath, new FileProgressMonitor(fis.available()), ChannelSftp.OVERWRITE); // 代码段2
            } catch (Exception e) {
                log.error(" error is upload file [{}] An exception is thrown here :  {}", file.getName(), e);
                return false;
            } finally {
                if (fis != null) {
                    fis.close();
                }
            }
        }

        if (chSftp != null) {
            chSftp.quit();
        }
        channel.closeChannel();

        return true;
    }

    public boolean sftpToLocalFile(JSONObject sftpJsonObj) throws Exception {
        InputStream ins = null;
        SFTPChannel channel = null;
        ChannelSftp chSftp = null;
        FileOutputStream fout = null;
        try {
            int defaultTimeout = SftpCnst.SFTP_REQ_REMOTE_DEFAULT_TIMEOUT;
            String defaultRemoteTimeout = sftpJsonObj.getString(SftpCnst.SFTP_REQ_REMOTE_TIMEOUT);
            if (StringUtils.isNotEmpty(defaultRemoteTimeout)) {
                defaultTimeout = Integer.valueOf(defaultRemoteTimeout);
            }

            channel = new SFTPChannel();
            chSftp = channel.getChannel(sftpJsonObj, defaultTimeout);
            ins = chSftp.get(sftpJsonObj.getString(SftpCnst.SFTP_REQ_REMOTE_PATH));
            File file = new File(sftpJsonObj.getString(SftpCnst.SFTP_REQ_LOCAL_PATH));
            fout = new FileOutputStream(file);
            fout.write(ins.read());
            fout.flush();
            return true;
        } catch (Exception e) {
            log.error(" error is fileStoreToSftp An exception is thrown here :  ", e);
            return false;
        } finally {
            if (fout != null) {
                fout.close();
            }
            if (chSftp != null) {
                chSftp.quit();
            }
            if (channel != null) {
                channel.closeChannel();
            }
            if (ins != null) {
                ins.close();
            }
        }
    }

}
