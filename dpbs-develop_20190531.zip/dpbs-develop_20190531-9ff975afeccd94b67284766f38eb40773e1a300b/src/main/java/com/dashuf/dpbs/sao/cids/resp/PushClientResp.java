package com.dashuf.dpbs.sao.cids.resp;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
public class PushClientResp implements Serializable {
    /**
     * applicationNum	string 必须 渠道申请编号
     */
    private String applicationNum;


    /**
     * 门店地址（当且仅当为半刻渠道且成功预约才返回此数据）
     */
    private List<PushClientOfStoreDetail> serviceList;
}
