package com.dashuf.dpbs.sao.defi.resp;

import com.dashuf.dpbs.sao.defi.resp.apply.Decision;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class ApplyRunEngineResp implements Serializable {
    private static final long serialVersionUID = -2392486047063909310L;

    /**
     * DECISION_ID	string 非必须 决策编号
     */
    @JsonProperty(value = "DECISION_ID")
    private String decisionId;
    /**
     * RETMSG	string 非必须 调用接口异常信息
     */
    @JsonProperty(value = "RETMSG")
    private String retMsg;
    /**
     * RETCODE	string 非必须 调用接口返回码 SUC000成功
     */
    @JsonProperty(value = "RETCODE")
    private String retCode;
    /**
     * SYSTEM_ID	string 非必须 调用系统编号
     */
    @JsonProperty(value = "SYSTEM_ID")
    private String systemId;

    @JsonProperty(value = "DECISION_RESPONSE")
    private Decision decision;

}
