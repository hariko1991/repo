package com.dashuf.dpbs.app.web.cids;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.DpbsForCidsUrl;
import com.dashuf.dpbs.app.web.req.cids.NofityScoreDs020Req;
import com.dashuf.dpbs.app.web.req.cids.NotifyCreditStatusReq;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.service.blaze.ThirdPartyAccessSupportService;
import com.dashuf.merlin.web.base.views.ResponseVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@Api(value = "第三方平台通知相关操作", tags = {"第三方平台通知相关操作"})
@Slf4j
@RestController
@RequestMapping(DpbsForCidsUrl.DPBS_CIDS_NOTIFY)
public class ThirdPartyNotifyController {
    @Autowired
    private ThirdPartyAccessSupportService thirdPartyAccessSupportService;

    @ApiOperation(value = "第三方平台通知信贷状态")
    @GetMapping(value = "/creditStatus")
    public ResponseVo<String> notifyCreditStatus(@RequestBody @Validated NotifyCreditStatusReq notifyCreditStatusReq) {
        if (StringUtils.isEmpty(notifyCreditStatusReq.getLoanApplicationNum())) {
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, "第三方平台通知贷款申请编号为空,不予处理");
        }

        try {
            JSONObject jsonObj = new JSONObject();
            return ResponseVo.success();
        } catch (Exception e) {
            log.error("第三方平台通知推单[{}]信贷状态异常:{}", notifyCreditStatusReq.getApplicationNum(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "第三方平台通知Ds020评分结果")
    @GetMapping(value = "/scoreDs020")
    public ResponseVo<String> nofityScoreDs020(@Validated @RequestBody NofityScoreDs020Req nofityScoreDs020Req) {
        try {
            JSONObject jsonObj = new JSONObject();
            return ResponseVo.success();
        } catch (Exception e) {
            log.error("第三方平台通知推单[{}]Ds020评分结果异常:{}", nofityScoreDs020Req.getApplicationNum(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }

    }
}
