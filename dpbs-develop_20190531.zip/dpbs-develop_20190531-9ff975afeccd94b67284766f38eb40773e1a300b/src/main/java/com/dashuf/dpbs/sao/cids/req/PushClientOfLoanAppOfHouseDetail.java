package com.dashuf.dpbs.sao.cids.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
public class PushClientOfLoanAppOfHouseDetail implements Serializable {
    /**
     * addressCode	string 非必须 房产地址code（6位数字）（有房产时必传）
     */
    private String addressCode;
    /**
     * addressName	string 非必须 房产地址中文名称（有房产时必传）
     */
    private String addressName;
    /**
     * estatesTypeCode	string 非必须 房屋性质（使用数据治理标准）（有房产时必传）
     */
    private String estatesTypeCode;
    /**
     * totalPriceAmt	number 非必须 房产价值（万元）（有房产时必传）
     */
    private String totalPriceAmt;
}
