package com.dashuf.dpbs.sao.cids.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class GetCreditStatusReq implements Serializable {
    /**
     * loanApplicationNum	string 非必须 信贷申请编号（字段名暂定）
     */
    private String loanApplicationNum;
    /**
     * ecifCustomerNum	string 非必须 客户号（字段名暂定）
     */
    private String ecifCustomerNum;
    /**
     * applicationNum	string 必须 申请编号（渠道编号）
     */
    private String applicationNum;
}
