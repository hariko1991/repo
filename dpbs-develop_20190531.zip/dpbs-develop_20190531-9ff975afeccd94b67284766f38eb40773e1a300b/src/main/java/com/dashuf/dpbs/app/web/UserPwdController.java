package com.dashuf.dpbs.app.web;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.annotation.LoginUser;
import com.dashuf.dpbs.app.web.resp.user.LoginResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.DpbsHeadCnst;
import com.dashuf.dpbs.model.UserInfo;
import com.dashuf.dpbs.service.UserInfoSupportService;
import com.dashuf.dpbs.app.annotation.LoginRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dashuf.dpbs.app.DpbsUrl;
import com.dashuf.dpbs.app.web.req.user.ForgetPwdReq;
import com.dashuf.dpbs.app.web.req.user.ModifyPwdReq;
import com.dashuf.merlin.web.base.views.ResponseVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import springfox.documentation.annotations.ApiIgnore;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Api(value = "用密码相关操作", tags = {"用密码相关操作"})
@Slf4j
@RestController
@RequestMapping(DpbsUrl.USER_PASSWOD_REF)
public class UserPwdController {

    @Autowired
    private UserInfoSupportService userInfoSupportService;

    @ApiOperation(value = "忘记密码")
    @PostMapping("/forgetPwd")
    @LoginRole(need = true)
    public ResponseVo<LoginResp> forgetPwd(HttpServletRequest request, HttpServletResponse response, @RequestBody @Validated ForgetPwdReq forgetPwdReq) {
        try {
            JSONObject jsonObj = new JSONObject();
            LoginResp loginResp = userInfoSupportService.forgetPwd(forgetPwdReq, jsonObj);
            if (null == loginResp) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }

            userInfoSupportService.initAccessTokenForUser(request, response, loginResp.getUserNo());
            return new ResponseVo<>(loginResp);
        } catch (Exception e) {
            log.error("手机号[{}]忘记密码过程中异常:{}", forgetPwdReq.getMobileNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "修改密码")
    @PostMapping("/modifyPwd")
    public ResponseVo<LoginResp> modifyPwd(@RequestBody @Validated ModifyPwdReq modifyPwdReq, @ApiIgnore @LoginUser String loginUserNo) {
        try {
            JSONObject jsonObj = new JSONObject();
            modifyPwdReq.setUserNo(loginUserNo);
            LoginResp loginResp = userInfoSupportService.modifyPwd(modifyPwdReq, jsonObj);
            if (null == loginResp) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(loginResp);
        } catch (Exception e) {
            log.error("手机号[{}]修改密码过程中异常:{}", modifyPwdReq.getMobileNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }
}
