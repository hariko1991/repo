package com.dashuf.dpbs.app.web.req.user;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

@ApiModel(value = "实名认证")
@Setter
@Getter
public class VerifyCertReq implements Serializable {

    @ApiModelProperty(value = "用户编号")
    private String userNo;

    @ApiModelProperty(value = "用户姓名")
    @NotBlank(message = "请输入正确的用户姓名")
    private String userName;

    @ApiModelProperty(value = "身份证号")
    @NotBlank(message = "请输入正确的身份证号")
    @Pattern(regexp = "^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$", message = "请输入正确的身份证号")
    private String certNo;

    @ApiModelProperty(value = "用户所属公司")
    private String srcChannel;

    @ApiModelProperty(value = "用户所属公司编码")
    private String srcChannelCode;

    /**
     * 手机号码
     */
    @ApiModelProperty(value = "手机号码")
    @NotBlank(message = "请输入正确的手机号")
    private String mobileNo;

    /**
     * 手机验证码
     */
    @ApiModelProperty(value = "手机验证码")
    @NotBlank(message = "请输入验证码")
    private String verifyCode;

}
