package com.dashuf.dpbs.app.web.resp.user;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "用户登录返回实体")
@Getter
@Setter
public class LoginResp implements Serializable {
    private static final long serialVersionUID = -966026968496467443L;

    @ApiModelProperty(value = "用户编号")
    private String userNo;

    /**
     * 手机号码
     */
    @ApiModelProperty(value = "手机号码")
    private String mobileNo;

    @ApiModelProperty(value = "用户状态")
    private String status;


}
