package com.dashuf.dpbs.app.web.req.support;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;
import java.util.List;

@ApiModel(value = "收集微信小程序req")
@Getter
@Setter
public class GatherFormIdReq implements Serializable {
    private static final long serialVersionUID = 5174984102198942154L;

    @ApiModelProperty(value = "用户编号")
    private String userNo;

    @ApiModelProperty(value = "用户提交表单事件集合")
    private String formIdList;

}
