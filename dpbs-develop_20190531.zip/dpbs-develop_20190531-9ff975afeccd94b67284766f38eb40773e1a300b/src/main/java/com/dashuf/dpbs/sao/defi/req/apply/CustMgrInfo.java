package com.dashuf.dpbs.sao.defi.req.apply;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class CustMgrInfo implements Serializable {

    /**
     * SerialNo	string 必须 营销人员代码
     */
    @JsonProperty(value = "serialNo")
    private String serialNo;
    /**
     * TeamNo	string 必须 营销单位代码
     */
    @JsonProperty(value = "teamNo")
    private String teamNo;
    /**
     * Orgid	string 必须 所属分公司
     */
    @JsonProperty(value = "orgid")
    private String orgid;

    @JsonProperty(value = "ChannelCode")
    private String channelCode;
    @JsonProperty(value = "ChannelName")
    private String channelName;
}
