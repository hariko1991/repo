package com.dashuf.dpbs.util;

import java.math.BigDecimal;

public final class ArithUtil {
    private ArithUtil() {
    }

    public static final String EXCTIONMESSAGE_0 = "精确度不能小于0";

    /**
     * Double 转double
     *
     * @param value
     * @return
     */
    public static double doubleValue(Double value) {
        if (value == null) {
            value = 0.0;
        }

        return value.doubleValue();
    }

    /**
     * 提供精确加法计算的add方法
     *
     * @param value1 被加数
     * @param value2 加数
     * @return 两个参数的和
     */
    public static double add(double value1, double value2) {
        BigDecimal b1 = BigDecimal.valueOf(value1);
        BigDecimal b2 = BigDecimal.valueOf(value2);
        return b1.add(b2).doubleValue();
    }

    /**
     * 提供精确加法计算的add方法
     *
     * @param value1 被加数
     * @param value2 加数
     * @return 两个参数的和
     */
    public static BigDecimal add(BigDecimal value1, BigDecimal value2) {
        if (null == value1) {
            value1 = BigDecimal.ZERO;
        }
        return value1.add(null == value2 ? BigDecimal.ZERO : value2);
    }

    /**
     * 提供精确减法运算的sub方法
     *
     * @param value1 被减数
     * @param value2 减数
     * @return 两个参数的差
     */
    public static double sub(double value1, double value2) {
        BigDecimal b1 = BigDecimal.valueOf(value1);
        BigDecimal b2 = BigDecimal.valueOf(value2);
        return b1.subtract(b2).doubleValue();
    }

    public static BigDecimal sub(BigDecimal value1, BigDecimal value2) {
        if (null == value1) {
            value1 = BigDecimal.ZERO;
        }
        return value1.subtract((null == value2 ? BigDecimal.ZERO : value2));
    }

    /**
     * 提供精确乘法运算的mul方法
     *
     * @param value1 被乘数
     * @param value2 乘数
     * @return 两个参数的积
     */
    public static double mul(double value1, double value2) {
        BigDecimal b1 = BigDecimal.valueOf(value1);
        BigDecimal b2 = BigDecimal.valueOf(value2);
        return b1.multiply(b2).doubleValue();
    }

    /**
     * 提供精确乘法运算的mul方法
     *
     * @param value1 被乘数
     * @param value2 乘数
     * @return 两个参数的积
     */
    public static BigDecimal mul(BigDecimal value1, BigDecimal value2) {
        return value1.multiply(value2);
    }

    public static double div(double v1, double v2) {
        return div(v1, v2, 10);
    }


    public static double div(double v1, double v2, int scale) {
        if (scale < 0) {
            throw new IllegalArgumentException();
        } else {
            BigDecimal b1 = new BigDecimal(Double.toString(v1));
            BigDecimal b2 = new BigDecimal(Double.toString(v2));
            return b1.divide(b2, scale, BigDecimal.ROUND_HALF_UP).doubleValue();
        }
    }

    /**
     * 提供精确的除法运算方法div
     *
     * @param v1 被除数
     * @param v2 除数
     * @param scale  精确范围
     * @return 两个参数的商
     * @throws IllegalAccessException
     */
    public static BigDecimal div(BigDecimal v1, BigDecimal v2, int scale) {
        if (scale < 0) {
            throw new IllegalArgumentException(EXCTIONMESSAGE_0);
        } else {
            return v1.divide(v2, scale, BigDecimal.ROUND_HALF_UP);
        }
    }

    public static double round(double v, int scale) {
        if (scale < 0) {
            throw new IllegalArgumentException(EXCTIONMESSAGE_0);
        } else {
            BigDecimal b = new BigDecimal(Double.toString(v));
            BigDecimal one = new BigDecimal("1");
            return b.divide(one, scale, BigDecimal.ROUND_HALF_UP).doubleValue();
        }
    }

    public static BigDecimal round(BigDecimal v, int scale) {
        if (scale < 0) {
            throw new IllegalArgumentException(EXCTIONMESSAGE_0);
        } else {
            BigDecimal one = new BigDecimal("1");
            return v.divide(one, scale, BigDecimal.ROUND_HALF_UP);
        }
    }

    public static double round(double v) {
        return round(v, 10);
    }


    public static BigDecimal calMonthPayAmount(BigDecimal loanbanlance, BigDecimal yearRate, String loanPeriod) {
        Integer totalPeriod = Integer.valueOf(loanPeriod);

        double monthRate = div(div(yearRate.doubleValue(), 100.0, 8), 12, 8);

        if (totalPeriod == null || totalPeriod == 0) {
            return BigDecimal.valueOf(round(mul(loanbanlance.doubleValue(), monthRate), 2));
        }

        if (monthRate <= 0.0) {
            return div(loanbanlance, BigDecimal.valueOf(totalPeriod), 2);
        }

        double instalmentAmount = loanbanlance.doubleValue() * monthRate
                * (1 + 1 / (java.lang.Math.pow(1 + monthRate, totalPeriod) - 1));

        return round(BigDecimal.valueOf(instalmentAmount), 2);
    }

}
