package com.dashuf.dpbs.service;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.web.req.center.VerifyMobileNoReq;
import com.dashuf.dpbs.app.web.req.support.GatherFormIdReq;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.mapper.PushMsgFormMapper;
import com.dashuf.dpbs.mapper.UserInfoMapper;
import com.dashuf.dpbs.model.PushMsgForm;
import com.dashuf.dpbs.model.UserInfo;
import com.dashuf.dpbs.util.DpbsUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service
@Slf4j
public class SupportRefService {

    private static Map<Integer, String> pushIndexMap = new HashMap<>();

    static {
        pushIndexMap.put(1, "FormIdOne");
        pushIndexMap.put(2, "FormIdTwo");
        pushIndexMap.put(3, "FormIdThree");
        pushIndexMap.put(4, "FormIdFour");
        pushIndexMap.put(5, "FormIdFive");
    }


    @Autowired
    private PushMsgFormMapper pushMsgFormMapper;
    @Autowired
    private UserInfoMapper userInfoMapper;

    public boolean gatherFormIdForPushMsg(GatherFormIdReq gatherFormIdReq, JSONObject jsonObj) throws Exception {
        String saveIndex = DateFormatUtils.format(new Date(), "yyyyMMdd");
        PushMsgForm pushMsgFormParam = new PushMsgForm();
        UserInfo userInfo = userInfoMapper.selectQuiqueUserInfo(new UserInfo(gatherFormIdReq.getUserNo()));
        pushMsgFormParam.setOpenId(userInfo.getOpenId());//设置open_id
        pushMsgFormParam.setUserNo(userInfo.getUserNo());
        PushMsgForm pushMsgForm = pushMsgFormMapper.selectOneByModelSelective(pushMsgFormParam, DpbsCnst.SQL_PRECISE_STRICT);
        pushMsgFormParam.setSaveIndex(saveIndex);
        pushMsgFormParam.setUserNo(gatherFormIdReq.getUserNo());
        if (null == pushMsgForm) {
            String msgFormNo = DpbsUtil.getTableNo(DpbsUtil.PREFIX_PUSH_MSG_FORM);
            pushMsgFormParam.setMsgFormNo(msgFormNo);
            pushMsgFormParam.setFormIdOne(gatherFormIdReq.getFormIdList());
            pushMsgFormParam.setPushIndex(1);
            pushMsgFormParam.setUseIndex(2);
            int dealCnt = pushMsgFormMapper.insert(pushMsgFormParam);
            log.info("用户[{}]第一次收集[{}]表单事件条数:[{}]", gatherFormIdReq.getUserNo(), saveIndex, dealCnt);
            return true;
        } else {
            if (pushMsgForm.getPushIndex() == 5 && pushMsgForm.getUseIndex() == 6) {
                log.info("用户[{}]收集[{}]表单已足够,不予处理", gatherFormIdReq.getUserNo(), saveIndex);
                jsonObj.put(DpbsCnst.RTN_MSG, "表单已足够,不予处理");
                return false;
            }
            pushMsgFormParam.setMsgFormNo(pushMsgForm.getMsgFormNo());
            //追加formId到6个后才进行下一个formId保存
            Method getMethod = pushMsgForm.getClass().getMethod(DpbsCnst.GET_METHOD + pushIndexMap.get(pushMsgForm.getPushIndex()));
            String formIdVal = getMethod.invoke(pushMsgForm).toString();//pushMsgForm.getFormIdOne();
            Method setMethod = pushMsgFormParam.getClass().getMethod(DpbsCnst.SET_METHOD + pushIndexMap.get(pushMsgForm.getPushIndex()), String.class);
            if (!StringUtils.isEmpty(formIdVal)) {
                if (pushMsgForm.getUseIndex() < 6) {
                    setMethod.invoke(pushMsgFormParam, formIdVal + DpbsCnst.COMMA_REGEX + gatherFormIdReq.getFormIdList());
                    pushMsgFormParam.setUseIndex(pushMsgForm.getUseIndex() + 2);
                }
                if (pushMsgForm.getUseIndex() == 6) {
                    pushMsgFormParam.setPushIndex(pushMsgForm.getPushIndex() + 1);
                    setMethod = pushMsgFormParam.getClass().getMethod(DpbsCnst.SET_METHOD + pushIndexMap.get(pushMsgForm.getPushIndex() + 1), String.class);
                    setMethod.invoke(pushMsgFormParam, gatherFormIdReq.getFormIdList());
                    pushMsgFormParam.setUseIndex(2);
                }
            }
            int dealCnt = pushMsgFormMapper.updatePushMsgForm(pushMsgFormParam);
            log.info("用户[{}]第[{}]次收集[{}]表单事件条数:[{}]", gatherFormIdReq.getUserNo(), pushMsgForm.getPushIndex() + 1, saveIndex, dealCnt);
            return true;
        }
    }


    public boolean verifyMobileNo(VerifyMobileNoReq verifyMobileNoReq, JSONObject jsonObj) {
        UserInfo userInfoParam = new UserInfo();
        userInfoParam.setMobileNo(verifyMobileNoReq.getMobileNo());

        UserInfo userInfo = userInfoMapper.selectQuiqueUserInfo(userInfoParam);

        if (null == userInfo) {
            if ("common_verify".equals(verifyMobileNoReq.getVerifyType())) {
                jsonObj.put(DpbsCnst.RTN_MSG, "您还未注册，请先注册");
                return false;
            }
        }

        if (null != userInfo) {
            if ("user_reg".equals(verifyMobileNoReq.getVerifyType())) {
                jsonObj.put(DpbsCnst.RTN_MSG, "此手机号已被注册，请登录");
                return false;
            } else if ("modify_mobile_no".equals(verifyMobileNoReq.getVerifyType())) {
                jsonObj.put(DpbsCnst.RTN_MSG, "该号码已注册，如有需要可联系您的专属客户经理");
                return false;
            }
        }

        return true;
    }
}
