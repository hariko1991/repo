package com.dashuf.dpbs.sao.support;

import com.dashuf.merlin.web.base.views.ResponseVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * , url="http://10.21.0.23:8250" sit
 * , url = "http://10.22.0.123:8250" uat
 */
@FeignClient(name = "PM-RequestRedirect")
public interface ElecSignPlatSAO {

    String FILE_ID = "fileId";
    String POS_BEAN = "posBean";
    String PERSON_INFO = "personInfo";
    String COLOR = "color";
    String SIGE_TYPE = "sigeType";
    String CHANNEL = "channel";
    String TEMPLATE = "template";


    @RequestMapping(value = "/ESignaturePlatform/api/presonSignature.do", method = RequestMethod.GET)
    ResponseVo<String> personSign(@RequestParam(FILE_ID) String fileId, @RequestParam(POS_BEAN) String posBean, @RequestParam(CHANNEL) String channel,
                                  @RequestParam(COLOR) String color, @RequestParam(PERSON_INFO) String personInfo, @RequestParam(TEMPLATE) String template,
                                  @RequestParam(SIGE_TYPE) String sigeType);

}
