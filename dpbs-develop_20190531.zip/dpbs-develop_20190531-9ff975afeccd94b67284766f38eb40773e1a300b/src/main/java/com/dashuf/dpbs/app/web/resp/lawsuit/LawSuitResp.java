package com.dashuf.dpbs.app.web.resp.lawsuit;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * 诉讼查询
 *
 * @author yaojiaoyi
 */
@ApiModel("诉讼查询")
@Getter
@Setter
public class LawSuitResp {

    @ApiModelProperty("执行编号")
    private String lawsuitNo;

    @ApiModelProperty("用户编号")
    private String userNo;

    @ApiModelProperty("客户编号")
    private String clientNo;

    @ApiModelProperty("执行人姓名")
    private String execName;

    @ApiModelProperty("身份证号")
    private String certNo;

    @ApiModelProperty("执行案件号码")
    private String execCase;

    @ApiModelProperty("执行法院")
    private String execCourt;

    @ApiModelProperty("执行内容")
    private String execContent;

    @ApiModelProperty("执行目标")
    private String execTarget;

    @ApiModelProperty("状态: nomal(正常)、invalid(无效)")
    private String status;

    @ApiModelProperty("诉讼时间")
    private String lawsuitDate;

    @ApiModelProperty("标题")
    private String title;

    @ApiModelProperty("备注")
    private String remark;
}
