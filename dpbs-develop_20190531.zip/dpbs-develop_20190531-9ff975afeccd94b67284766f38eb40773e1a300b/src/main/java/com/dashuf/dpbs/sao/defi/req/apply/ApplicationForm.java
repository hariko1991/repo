package com.dashuf.dpbs.sao.defi.req.apply;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
public class ApplicationForm implements Serializable {

    private static final long serialVersionUID = 9035438688859467199L;

    /**
     * businessSum	null 必须 申请金额
     */
    private String businessSum;
    /**
     * eduExperience	null 必须
     */
    private String eduExperience;
    /**
     * gender	string 必须  性别
     */
    private String gender;
    /**
     * marriage	null 必须 婚姻状态
     */
    private String marriage;
    /**
     * industryCode	null 必须 行业名称
     */
    private String industryCode;
    /**
     * certId	string 必须 证件号码
     */
    private String certId;

    private String nation;
    /**
     * workAddress	string 必须  单位地址
     */
    private String workAddress;
    /**
     * employeeType	null　必须　客户类型
     */
    private String employeeType;
    /**
     * certtype	string 必须　证件类型
     */
    private String certtype;
    /**
     * idmaturity	string 必须 证件是否到期
     */
    private String idmaturity;
    /**
     * shareHolder	null 必须 是否股东
     */
    private String shareHolder;
    /**
     * housevalue	null 必须 房产持有价值
     */
    private BigDecimal houseValue;
    /**
     * insurancefee null 必须 年缴保费
     */
    private BigDecimal insuranceFee;
    /**
     * authorizedMan	null 必须 是否法人代表
     */
    private String authorizedMan;
    /**
     * register	null 必须 是否注册
     */
    private String register;
    /**
     * oriLoanAmt	null 必须 原贷款金额
     */
    private BigDecimal oriLoanAmt;
    /**
     * serviceCentre	null 必须 个贷服务中心
     */
    private String serviceCentre;
    /**
     * oriLoanDate	null 必须 原贷款发放日期
     */
    private Date oriLoanDate;
    /**
     * cell	string  必须 手机号
     */
    private String cell;
    /**
     * customername	string 必须 客户姓名
     */
    private String customername;
    /**
     * age	null 必须 年龄
     */
    private Integer age;
    /**
     * maxFeeYear	null 必须
     */
    private String maxFeeYear;
    /**
     * accumulationfund	null 必须 最近6个月是否连续按月正常缴纳公积金
     */
    private String accumulationfund;
    /**
     * residentialAddress	null 必须 居住地址
     */
    private String residentialAddress;
    /**
     * maxInsuranceYear	null 必须 最早保单生效日期
     */
    private String maxInsuranceYear;
    /**
     * householdRregister	null 必须 户籍地址
     */
    private String householdRregister;
    /**
     * localhouseFlag	null 必须 有无本地房产
     */
    private String localhouseFlag;
    /**
     * creditcardInCarLoan	null 必须 信用卡分期车贷月还款额
     */
    private BigDecimal creditcardInCarLoan;
    /**
     * sharesituation	null 必须 占股情况
     */
    private String sharesituation;
    /**
     * businessEstTime	null 必须 营业执照企业成立日期
     */
    private String businessEstTime;
}
