package com.dashuf.dpbs.sao.support.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class GetFileTemplateReq implements Serializable {
    private String templateNo;

    private GetFileTemplateDto jsonString;

}
