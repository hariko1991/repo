package com.dashuf.dpbs.sao.cids.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
public class PushClientOfLoanAppOfInsuranceDetail implements Serializable {
    /**
     * insuranceCompanyCode	string 非必须 保险公司code（有保单时必传）
     */
    private String insuranceCompanyCode;
    /**
     * maxEffectiveCode	string 非必须 最早缴费年份（有保单时必传）
     */
    private String maxEffectiveCode;
    /**
     * premiumAnnualAmt	number 非必须 年缴保费（元）（有保单时必传）
     */
    private BigDecimal premiumAnnualAmt;
}
