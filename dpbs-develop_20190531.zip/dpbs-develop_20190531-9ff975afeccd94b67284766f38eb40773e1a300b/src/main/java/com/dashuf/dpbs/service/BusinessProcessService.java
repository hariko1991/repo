package com.dashuf.dpbs.service;

import com.dashuf.dpbs.app.web.resp.business.BusinessProcessDetailResp;
import com.dashuf.dpbs.app.web.resp.business.BusinessProcessResp;
import com.dashuf.dpbs.app.web.resp.business.ClientBaseInfoResp;
import com.dashuf.dpbs.app.web.resp.business.ProcessLog;
import com.dashuf.dpbs.cnst.StatusCnst;
import com.dashuf.dpbs.mapper.ClientInfoMapper;
import com.dashuf.dpbs.mapper.PushLoanProductMapper;
import com.dashuf.dpbs.mapper.PushOrderLogMapper;
import com.dashuf.dpbs.model.PushLoanProduct;
import com.dashuf.dpbs.model.PushOrderLog;
import com.dashuf.merlin.mybatis.page.Pagination;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/**
 * 业务进度查询
 *
 * @author yaojiaoyi
 */
@Service
public class BusinessProcessService {
    @Autowired
    private PushOrderLogMapper pushOrderLogMapper;
    @Autowired
    private ClientInfoMapper clientInfoMapper;

    @Autowired
    private PushLoanProductMapper pushLoanProductMapper;

    /**
     * 获取待办已办列表
     *
     * @param processStatus
     * @param userNo        用户编号
     * @return
     */
    public PageInfo<BusinessProcessResp> getBusinessProcess(Integer processStatus, String userNo, Pagination pagination) {
        PageHelper.startPage(pagination);
        List<BusinessProcessResp> list = pushOrderLogMapper.getBusinessProcess(processStatus, userNo);
        return PageInfo.of(list);
    }

    /**
     * 获取业务进度详情
     *
     * @param pushOrderNo
     * @return
     */
    public BusinessProcessDetailResp getBusinessDetail(String pushOrderNo) {
        BusinessProcessDetailResp resp = new BusinessProcessDetailResp();
        //推单信息
        PushOrderLog cond = new PushOrderLog();
        cond.setPushOrderNo(pushOrderNo);
        PushOrderLog pushOrderLog = pushOrderLogMapper.selectOneByModelSelective(cond, true);
        if (null == pushOrderLog) {
            return null;
        }
        //客户信息
        ClientBaseInfoResp clientBaseInfoResp = clientInfoMapper.getClientBaseInfo(pushOrderNo);
        if (null == clientBaseInfoResp) {
            return null;
        }
        resp.setClientName(clientBaseInfoResp.getClientName());
        resp.setMobileNo(clientBaseInfoResp.getMobileNo());
        resp.setPushOrderNo(pushOrderNo);
        resp.setClientNo(clientBaseInfoResp.getClientNo());
        resp.setReconDate(clientBaseInfoResp.getReconDate());
        resp.setCertNo(clientBaseInfoResp.getCertNo());
        //变量定义
        List<ProcessLog> localProcessLog = new ArrayList<>();
        List<ProcessLog> firstProduct = new ArrayList<>();
        List<ProcessLog> secondProduct = new ArrayList<>();
        ProcessLog initProcessLog = new ProcessLog();
        ProcessLog commitProcessLog = new ProcessLog();
        ProcessLog evalingProcessLog = new ProcessLog();
        ProcessLog evalSuccessProcessLog = new ProcessLog();
        ProcessLog approvalProcessLog = new ProcessLog();
        switch (pushOrderLog.getPushStatus()) {
            //推单中(返回英文状态，前端需将这四种状态聚合成"正在推单中"，其他状态不需要)
            case StatusCnst.INIT:
            case StatusCnst.SCAN:
            case StatusCnst.MOVIE:
            case StatusCnst.ENTRY:
                initProcessLog.setOrderStatus(pushOrderLog.getPushStatus());
                initProcessLog.setProcessDate(pushOrderLog.getCreatedDate());
                localProcessLog.add(initProcessLog);
                break;
            //提交成功
            case StatusCnst.CREDIT:
                commitProcessLog.setOrderStatus("提交成功");
                commitProcessLog.setProcessDate(pushOrderLog.getPushEndTime());
                localProcessLog.add(commitProcessLog);
                break;
            //初评中
            case StatusCnst.EVAL_ING:
                //提交成功
                commitProcessLog.setOrderStatus("提交成功");
                commitProcessLog.setProcessDate(pushOrderLog.getPushEndTime());
                localProcessLog.add(commitProcessLog);
                //初评中
                evalingProcessLog.setOrderStatus("初评中");
                evalingProcessLog.setProcessDate(pushOrderLog.getEvalStartTime());
                localProcessLog.add(evalingProcessLog);
                break;
            case StatusCnst.EVAL_FAIL:
                //提交成功
                commitProcessLog.setOrderStatus("提交成功");
                commitProcessLog.setProcessDate(pushOrderLog.getPushEndTime());
                localProcessLog.add(commitProcessLog);
                //初评中
                evalingProcessLog.setOrderStatus("初评不通过");
                evalingProcessLog.setProcessDate(pushOrderLog.getUpdatedDate());
                localProcessLog.add(evalingProcessLog);
                break;
            case StatusCnst.FAIL:
                //提交成功
                if (pushOrderLog.getPushEndTime() != null) {
                    commitProcessLog.setOrderStatus("提交成功");
                    commitProcessLog.setProcessDate(pushOrderLog.getPushEndTime());
                    localProcessLog.add(commitProcessLog);
                }
                //初评中
                evalingProcessLog.setOrderStatus("推单失败");
                evalingProcessLog.setProcessDate(pushOrderLog.getUpdatedDate());
                localProcessLog.add(evalingProcessLog);
                break;
            //初评通过
            case StatusCnst.EVAL_SUCCESS:
            case StatusCnst.PUSH_CLIENT_SUCCESS:
                commitProcessLog.setOrderStatus("提交成功");
                commitProcessLog.setProcessDate(pushOrderLog.getPushEndTime());
                localProcessLog.add(commitProcessLog);

                evalSuccessProcessLog.setOrderStatus("初评通过");
                evalSuccessProcessLog.setProcessDate(pushOrderLog.getEvalEndTime());
                localProcessLog.add(evalSuccessProcessLog);

                if (pushOrderLog.getPushClientTime() != null) {
                    approvalProcessLog.setOrderStatus("审批中");
                    approvalProcessLog.setProcessDate(pushOrderLog.getPushClientTime());
                    localProcessLog.add(approvalProcessLog);
                }
                break;
            case StatusCnst.APPROVAL_VETO:
            case StatusCnst.CUST_WAIVE:
                commitProcessLog.setOrderStatus("提交成功");
                commitProcessLog.setProcessDate(pushOrderLog.getPushEndTime());
                localProcessLog.add(commitProcessLog);

                evalSuccessProcessLog.setOrderStatus("初评通过");
                evalSuccessProcessLog.setProcessDate(pushOrderLog.getEvalEndTime());
                localProcessLog.add(evalSuccessProcessLog);

                PushLoanProduct pushLoanProductCondVeto = new PushLoanProduct();
                pushLoanProductCondVeto.setPushOrderNo(pushOrderNo);
                List<PushLoanProduct> listProduct = pushLoanProductMapper.selectByModelSelective(pushLoanProductCondVeto, true);

                //有一个或两个产品到出账流程
                if (CollectionUtils.isNotEmpty(listProduct)) {
                    for (int i = 0; i < listProduct.size(); i++) {
                        ProcessLog loanProcess = new ProcessLog();
                        if (i == 0) {
                            loanProcess.setOrderStatus(StringUtils.isBlank(listProduct.get(0).getMapStatusDesc()) ? "审批否决" : listProduct.get(0).getMapStatusDesc());
                            loanProcess.setProcessDate(listProduct.get(0).getPutoutDate() == null ? pushOrderLog.getApprovalTime() : listProduct.get(0).getPutoutDate());
                            firstProduct.add(loanProcess);
                        }
                        if (i == 1) {
                            loanProcess.setOrderStatus(StringUtils.isBlank(listProduct.get(1).getMapStatusDesc()) ? "审批否决" : listProduct.get(1).getMapStatusDesc());
                            loanProcess.setProcessDate(listProduct.get(1).getPutoutDate() == null ? pushOrderLog.getApprovalTime() : listProduct.get(1).getPutoutDate());
                            secondProduct.add(loanProcess);
                        }
                    }
                } else {
                    approvalProcessLog.setOrderStatus("审批否决");
                    approvalProcessLog.setProcessDate(pushOrderLog.getApprovalTime());
                    localProcessLog.add(approvalProcessLog);
                }
                break;
            case StatusCnst.LOAN_SUCCESS:
            case StatusCnst.LOAN_VETO:
            case StatusCnst.APPROVAL_FINISH:
            case StatusCnst.APPROVALING:
                commitProcessLog.setOrderStatus("提交成功");
                commitProcessLog.setProcessDate(pushOrderLog.getPushEndTime());
                localProcessLog.add(commitProcessLog);

                evalSuccessProcessLog.setOrderStatus("初评通过");
                evalSuccessProcessLog.setProcessDate(pushOrderLog.getEvalEndTime());
                localProcessLog.add(evalSuccessProcessLog);
                PushLoanProduct pushLoanProductCond = new PushLoanProduct();
                pushLoanProductCond.setPushOrderNo(pushOrderNo);
                List<PushLoanProduct> list = pushLoanProductMapper.selectByModelSelective(pushLoanProductCond, true);

                if (CollectionUtils.isEmpty(list)) {
                    approvalProcessLog.setOrderStatus("审批中");
                    approvalProcessLog.setProcessDate(pushOrderLog.getPushClientTime());
                    localProcessLog.add(approvalProcessLog);
                }

                //有一个或两个产品到出账流程
                for (int i = 0; i < list.size(); i++) {
                    ProcessLog loanProcess = new ProcessLog();
                    if (i == 0) {
                        loanProcess.setOrderStatus(StringUtils.isBlank(list.get(0).getMapStatusDesc()) ? "审批中" : list.get(0).getMapStatusDesc());
                        loanProcess.setProcessDate(list.get(0).getPutoutDate() == null ? pushOrderLog.getPushClientTime() : list.get(0).getPutoutDate());
                        firstProduct.add(loanProcess);
                    }
                    if (i == 1) {
                        loanProcess.setOrderStatus(StringUtils.isBlank(list.get(1).getMapStatusDesc()) ? "审批中" : list.get(1).getMapStatusDesc());
                        loanProcess.setProcessDate(list.get(1).getPutoutDate() == null ? pushOrderLog.getPushClientTime() : list.get(1).getPutoutDate());
                        secondProduct.add(loanProcess);
                    }
                }


                break;
            default:
                return resp;
        }
        //两个产品都被否决
        if (pushOrderLog.getPushStatus().equals(StatusCnst.LOAN_VETO)) {
            resp.setRejectProcess("合作机构否决");
        }
        //审批阶段否决
        if (pushOrderLog.getPushStatus().equals(StatusCnst.APPROVAL_VETO)) {
            resp.setRejectProcess("审批否决");
        }
        if (pushOrderLog.getPushStatus().equals(StatusCnst.CUST_WAIVE)) {
            resp.setRejectProcess("客户放弃");
        }
        if (pushOrderLog.getPushStatus().equals(StatusCnst.LOAN_SUCCESS)) {
            resp.setLoanAmt(pushOrderLog.getLoanPayAmt());
        }
        //如果出账金额大于0表示有放款成功
        resp.setProductFirst(firstProduct);
        resp.setProductSecond(secondProduct);
        resp.setLocalProcess(localProcessLog);
        return resp;
    }
}
