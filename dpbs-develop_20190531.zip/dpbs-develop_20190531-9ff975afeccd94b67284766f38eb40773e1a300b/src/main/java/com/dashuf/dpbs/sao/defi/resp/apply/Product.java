package com.dashuf.dpbs.sao.defi.resp.apply;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
public class Product implements Serializable {
    private static final long serialVersionUID = 7166491949274540442L;
    /**
     * 一级产品:010-大数时贷  020-小数云贷  030-大数嘉贷 040-企业福贷   050-大数V贷 060-飞钛秒贷     070-税务贷
     */
    private String primaryProduct;

    private BigDecimal dashuLimitAmt;

    private BigDecimal maxCalCreditAmt;

    private Integer loanterm;

    private String productcod;

    private BigDecimal personalIncomeMonthly;

    /**
     * riskLevel	string	必须		风险等级
     */
    private String riskLevel;
    /**
     * productId	string	必须		产品类型
     */
    private String productId;
    /**
     * partnerName	string	必须		合作方名称
     */
    private String partnerName;

    /**
     * entryFlag	string	必须		是否准入标识 1-是 0-否
     */
    private String entryFlag;
    /***
     * calCreditAmt	number	必须		系统计算授信额度
     */
    private BigDecimal calCreditAmt;

}
