package com.dashuf.dpbs.sao.cids.req.ds020.blaze;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class BusinessOfDataDetail implements Serializable {


    private static final long serialVersionUID = -8894901507656634254L;


    private BusinessOfDataOfApplicationDetail application;
}
