package com.dashuf.dpbs.app.web.resp.support;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Created with IDEA
 * author:Likangcheng
 * Date:2019/2/22
 * Time:10:38
 */
@ApiModel(value = "专属渠道")
@Getter
@Setter
public class GetExclusiveChannelListResp {

    @ApiModelProperty(value = "所属公司名称")
    private String srcChannel;
    @ApiModelProperty(value = "所属渠道编码")
    private String srcChannelCode;
}
