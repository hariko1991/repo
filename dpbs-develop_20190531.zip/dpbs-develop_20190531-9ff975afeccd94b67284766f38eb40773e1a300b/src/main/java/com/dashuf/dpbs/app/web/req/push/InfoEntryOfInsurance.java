package com.dashuf.dpbs.app.web.req.push;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotNull;

@ApiModel(value = "保险信息")
@Getter
@Setter
public class InfoEntryOfInsurance implements Serializable {
    private static final long serialVersionUID = -3962611634685943710L;

    @ApiModelProperty(value = "寿险公司")
    private String insuranceCompanyCode;

    @ApiModelProperty(value = "年缴保费")
    private BigDecimal premiumAnnualAmt;

    @ApiModelProperty(value = "生效日期")
    @DateTimeFormat(pattern = "yyyyMM")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyyMM")
    private Date effectiveDate;
}
