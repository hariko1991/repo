package com.dashuf.dpbs.sao.wx.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class Scene implements Serializable {
    private long scene_id;

    private String scene_str;
}
