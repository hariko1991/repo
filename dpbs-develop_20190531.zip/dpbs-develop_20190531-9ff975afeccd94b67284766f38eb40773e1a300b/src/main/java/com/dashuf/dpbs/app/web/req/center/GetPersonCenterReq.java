package com.dashuf.dpbs.app.web.req.center;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@ApiModel(value = "获取个人中心请求")
@Setter
@Getter
public class GetPersonCenterReq implements Serializable {
    @ApiModelProperty(value = "用户编号")
    private String userNo;
}
