package com.dashuf.dpbs.app.web.req.home;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;
import java.io.Serializable;

@ApiModel(value = "获取客户经理信息req")
@Getter
@Setter
public class GetUmInfoReq implements Serializable {
    private static final long serialVersionUID = -5843740177773993349L;

    @ApiModelProperty(value = "用户编号")
    private String userNo;

}
