package com.dashuf.dpbs.sao.laapp.req.subscribe;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
public class Insurance implements Serializable {
    @ApiModelProperty(value = "保险公司code")
    private String insuranceCompanyCode;

    @ApiModelProperty(value = "年缴保费（元）")
    private BigDecimal premiumAnnualAmt;

    @ApiModelProperty(value = "最早缴费年份")
    private String maxEffectiveCode;
}
