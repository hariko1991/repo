package com.dashuf.dpbs.sao.ocr;

import com.dashuf.merlin.web.base.views.ResponseVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.context.annotation.Bean;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartResolver;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

@FeignClient(name = "PM-RequestRedirect", configuration = OcrForCertSAO.FeignSupportConfig.class)
public interface OcrForCertSAO {

    @RequestMapping(
            value = "/IdentityConfirmPlatform/api/ocrIdCardInfo/{applicationNo}",
            method = RequestMethod.GET,
            consumes = MediaType.MULTIPART_FORM_DATA_VALUE
    )
    public ResponseVo<String> ocrForCert(@PathVariable("applicationNo") String applicationNo, @RequestPart("file") MultipartFile file);

    //@Configuration
    public class FeignSupportConfig {

        @Bean
        public MultipartResolver multipartResolver() {
            return new CommonsMultipartResolver();
        }
    }
}
