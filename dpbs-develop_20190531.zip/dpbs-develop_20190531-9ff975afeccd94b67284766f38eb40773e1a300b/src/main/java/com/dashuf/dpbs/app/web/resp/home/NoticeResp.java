package com.dashuf.dpbs.app.web.resp.home;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@ApiModel(value = "公告Resp")
@Getter
@Setter
public class NoticeResp implements Serializable {
    private static final long serialVersionUID = 7246154116849624968L;

    @ApiModelProperty(value = "公告标题")
    private String noticeTitle;

    @ApiModelProperty(value = "公告内容")
    private String noticeContent;
}
