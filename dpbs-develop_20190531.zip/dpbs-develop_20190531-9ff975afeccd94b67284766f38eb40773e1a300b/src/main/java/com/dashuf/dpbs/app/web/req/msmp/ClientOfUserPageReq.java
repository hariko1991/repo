package com.dashuf.dpbs.app.web.req.msmp;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "用户所属客户Req")
@Getter
@Setter
public class ClientOfUserPageReq implements Serializable {
	private static final long serialVersionUID = 4055392020910350026L;

	@ApiModelProperty(value = "用户编码", required = true)
	@NotBlank(message = "请输入用户编码")
	private String userNo;

	@ApiModelProperty(value = "客户名称")
	private String clientName;

	@ApiModelProperty(value = "页面大小")
	private Integer pageSize = 5;

	@ApiModelProperty(value = "页码")
	private Integer pageNum = 1;

}
