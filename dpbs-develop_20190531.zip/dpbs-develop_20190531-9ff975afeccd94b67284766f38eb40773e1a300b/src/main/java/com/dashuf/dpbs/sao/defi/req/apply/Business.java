package com.dashuf.dpbs.sao.defi.req.apply;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class Business implements Serializable {
    private static final long serialVersionUID = 6668608430504039447L;

    private Data data;
}
