package com.dashuf.dpbs.cnst;

public final class DpbsHeadCnst {
    public static final String X_HEAD_USER_NO = "user_no";
    public static final String X_HEAD_RTN_CODE = "rtn_code";

    public static final String X_HEAD_RTN_CODE_NEED_LOGIN = "need_login";
    public static final String X_HEAD_RTN_CODE_INVALID_TOKEN = "invalid_token";

    public static final String X_HEAD_ACCESS_TOKEN = "access_token";

    public static final String X_HEAD_LOGIN_USER = "login_user";

    public static final String X_HEAD_LOGIN_USER_STATUS = "login_user_status";

    public static final String X_HEAD_RTN_CODE_RE_LOGIN = "re_login";

}
