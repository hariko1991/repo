package com.dashuf.dpbs.app.web.resp.support;

import java.io.Serializable;
import java.util.List;

import com.dashuf.dpbs.app.web.resp.bean.FileBean;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * 查询影像Resp
 */
@ApiModel(value = "查询影像Resp")
@Getter
@Setter
public class QueryMovieResp implements Serializable {

	private static final long serialVersionUID = -7106514528908161570L;

	/**
	 * 流水号
	 */
	@ApiModelProperty(value = "流水号")
	private String stepRefNo;

	/**
	 * 查询影象批次号
	 */
	@ApiModelProperty(value = "查询影象批次号")
	private String contentId;

	/**
	 * 查询文件集合
	 */
	@ApiModelProperty(value = "查询文件集合")
	private List<FileBean> fileBeanList;

}
