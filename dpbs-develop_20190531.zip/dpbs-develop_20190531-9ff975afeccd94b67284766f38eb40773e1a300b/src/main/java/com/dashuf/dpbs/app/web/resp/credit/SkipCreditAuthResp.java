package com.dashuf.dpbs.app.web.resp.credit;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class SkipCreditAuthResp implements Serializable {
	private static final long serialVersionUID = -80045475266835905L;
	@ApiModelProperty(value = "推送订单编号", required = true)
	private String pushOrderNo;
	
	
	
}
