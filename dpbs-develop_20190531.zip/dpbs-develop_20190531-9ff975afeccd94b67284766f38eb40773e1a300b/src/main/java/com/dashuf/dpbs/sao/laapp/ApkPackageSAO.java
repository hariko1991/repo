package com.dashuf.dpbs.sao.laapp;

import com.dashuf.dpbs.sao.laapp.resp.ApkPackageResp;
import com.dashuf.merlin.web.base.views.ResponseVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;

import java.util.List;

@FeignClient(name = "LAAPP")
public interface ApkPackageSAO {

    @PostMapping("/laapp/v1/upgradePackage/get")
    public ResponseVo<List<ApkPackageResp>> getNewestApk();
}
