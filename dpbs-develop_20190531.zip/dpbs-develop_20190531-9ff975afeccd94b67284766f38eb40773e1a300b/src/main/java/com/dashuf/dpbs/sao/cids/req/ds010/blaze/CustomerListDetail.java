package com.dashuf.dpbs.sao.cids.req.ds010.blaze;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class CustomerListDetail implements Serializable {
    @JsonProperty(value = "CERT_ID")
    private String certId;
    @JsonProperty(value = "CERT_TYPE")
    private String certType;
    @JsonProperty(value = "CREDIT_REPORT_ID")
    private String creditReportId;
    @JsonProperty(value = "CUSTOMER_NAME")
    private String customerName;
    @JsonProperty(value = "CUSTOMER_TYPE")
    private String customerType;
    @JsonProperty(value = "OPERATE_USER_ID")
    private String operateUserId;
    @JsonProperty(value = "PHONE_NUMBER")
    private String phoneNumber;
}
