package com.dashuf.dpbs.app.web.resp.business;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author yaojiaoyi
 */
@Getter
@Setter
@ApiModel("进度日志")
public class ProcessLog {
    @ApiModelProperty("订单状态")
    private String orderStatus;
    @ApiModelProperty("流程状态时间")
    private Date processDate;
}
