package com.dashuf.dpbs.sao.cpms;

import com.dashuf.dpbs.sao.cids.resp.GetCreditStatusResp;
import com.dashuf.merlin.web.base.views.ResponseVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "CPMS")
public interface ClientTradingSAO {

    @RequestMapping(value = "/cpms/v1/channel/inTrading", method = RequestMethod.GET)
    ResponseVo<String> inTrading(@RequestParam("custName") String custName, @RequestParam("certType") String certificateTypeCode,
                                 @RequestParam("certNum") String certificateNum);

    @GetMapping(value = "/cpms/v1/channel/status")
    ResponseVo<GetCreditStatusResp> pullLoanStatus(@RequestParam(value = "applicationId", required = false) String applicationId,
                                                   @RequestParam(value = "loanOrderId", required = false) String loanOrderId,
                                                   @RequestParam(value = "businessSourceCode", defaultValue = "DISP") String businessSourceCode);

}
