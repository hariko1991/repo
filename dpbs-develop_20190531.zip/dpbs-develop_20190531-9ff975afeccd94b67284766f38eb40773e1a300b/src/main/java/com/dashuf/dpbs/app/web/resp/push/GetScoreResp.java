package com.dashuf.dpbs.app.web.resp.push;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

import com.dashuf.dpbs.util.BigDecimalJsonSerializer;
import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.format.annotation.NumberFormat;
import springfox.documentation.annotations.ApiIgnore;

@ApiModel(value = "获取评分结果")
@Getter
@Setter
public class GetScoreResp implements Serializable {
    private static final long serialVersionUID = -5386028542984742635L;

    @ApiModelProperty(value = "客户姓名", required = true)
    private String clientName;

    @ApiModelProperty(value = "可贷额度", required = true)
    @JsonSerialize(using = BigDecimalJsonSerializer.class)
    @NumberFormat(style = NumberFormat.Style.NUMBER, pattern = "#,##0.00")
    private BigDecimal loanAmt;

    @ApiModelProperty(value = "有效期", required = true)
    @DateTimeFormat(pattern = "yyyy年MM月dd日")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy年MM月dd日")
    private Date validDate;

    @ApiModelProperty(value = "每月还款额", required = true)
    @JsonSerialize(using = BigDecimalJsonSerializer.class)
    @NumberFormat(style = NumberFormat.Style.NUMBER, pattern = "#,##0.00")
    private BigDecimal payMonthAmt;

}
