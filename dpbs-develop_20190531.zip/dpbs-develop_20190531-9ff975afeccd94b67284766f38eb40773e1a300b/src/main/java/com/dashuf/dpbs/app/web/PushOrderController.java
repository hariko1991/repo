package com.dashuf.dpbs.app.web;

import javax.annotation.Resource;

import com.dashuf.dpbs.app.annotation.LoginUser;
import com.dashuf.dpbs.app.web.req.push.*;
import com.dashuf.dpbs.model.UserInfo;
import org.apache.commons.lang3.StringUtils;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.DpbsUrl;
import com.dashuf.dpbs.app.web.resp.push.GetScoreResp;
import com.dashuf.dpbs.app.web.resp.push.InfoEntryResp;
import com.dashuf.dpbs.app.web.resp.push.PushOrderResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.DpbsStatusCnst;
import com.dashuf.dpbs.service.PushOrderSupportService;
import com.dashuf.merlin.web.base.views.ResponseVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import springfox.documentation.annotations.ApiIgnore;

@Api(value = "立即推单", tags = {"立即推单相关"})
@Slf4j
@RestController
@RequestMapping(DpbsUrl.PUSH_ORDER_REF)
public class PushOrderController {
    @Resource
    private PushOrderSupportService pushOrderSupportService;

    @ApiOperation(value = "立即推单")
    @PostMapping("/initPushOrder")
    public ResponseVo<PushOrderResp> initPushOrder(@Validated @RequestBody InitPushOrderReq initPushOrderReq, @ApiIgnore @LoginUser String loginUserNo) {
        JSONObject jsonObj = new JSONObject();
        try {
            if (!pushOrderSupportService.initPushOrder(loginUserNo, jsonObj)) {
                return ResponseVo.fail(jsonObj.getString(DpbsCnst.RTN_CODE), jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            PushOrderResp pushOrderResp = new PushOrderResp();
            pushOrderResp.setPushOrderNo(jsonObj.getString(DpbsCnst.PUSH_ORDER_NO));
            pushOrderResp.setPushStatus(DpbsStatusCnst.PUSH_INIT);
            return new ResponseVo<>(pushOrderResp);
        } catch (Exception e) {
            log.error("初始化推单流水号异常:{}", e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "扫描身份证")
    @PostMapping("/scanCert")
    public ResponseVo<PushOrderResp> scanCert(@Validated @RequestBody ScanCertReq scanCertReq, @ApiIgnore @LoginUser String loginUserNo) {
        try {
            JSONObject jsonObj = new JSONObject();
            scanCertReq.setUserNo(loginUserNo);
            if (!pushOrderSupportService.scanCert(scanCertReq, jsonObj)) {
                if (StringUtils.isEmpty(jsonObj.getString(DpbsCnst.RTN_CODE))) {
                    return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
                } else {
                    return ResponseVo.fail(jsonObj.getString(DpbsCnst.RTN_CODE), jsonObj.getString(DpbsCnst.RTN_MSG));
                }
            }
            PushOrderResp pushOrderResp = new PushOrderResp();
            pushOrderResp.setPushOrderNo(scanCertReq.getPushOrderNo());
            pushOrderResp.setPushStatus(DpbsStatusCnst.PUSH_SCAN);
            return new ResponseVo<>(pushOrderResp);
        } catch (Exception e) {
            log.error("推单[{}]扫描身份证异常:{}", scanCertReq.getPushOrderNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "上传手持证件照片")
    @PostMapping("/uploadImg")
    public ResponseVo<PushOrderResp> uploadImg(@RequestParam("fileList") MultipartFile[] fileList, @RequestParam("pushOrderNo") String pushOrderNo) {
        log.info("推单流水号[{}],上传影象平台文件数量[{}]", pushOrderNo, null != fileList ? fileList.length : null);

        if (null == fileList || fileList.length == 0) {
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, "上传文件列表为空,请检查");
        }
        try {
            JSONObject jsonObj = new JSONObject();
            if (!pushOrderSupportService.uploadImg(fileList, pushOrderNo, jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            PushOrderResp pushOrderResp = new PushOrderResp();
            pushOrderResp.setPushOrderNo(pushOrderNo);
            pushOrderResp.setPushStatus(DpbsStatusCnst.PUSH_MOVIE);
            return new ResponseVo<>(pushOrderResp);
        } catch (Exception e) {
            log.error("推单流水号[{}],上传影象平台文件异常:{}", pushOrderNo, e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "信息录入")
    @PostMapping("/infoEntry")
    public ResponseVo<InfoEntryResp> infoEntry(@Validated @RequestBody InfoEntryReq infoEntryReq) {
        try {
            JSONObject jsonObj = new JSONObject();
            if (!pushOrderSupportService.infoEntry(infoEntryReq, jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            InfoEntryResp infoEntryResp = new InfoEntryResp();
            infoEntryResp.setPushOrderNo(infoEntryReq.getPushOrderNo());
            infoEntryResp.setPushStatus(DpbsStatusCnst.PUSH_ENTRY);

            if (!pushOrderSupportService.initCreditAuthPage(infoEntryReq.getPushOrderNo(), infoEntryResp, jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(infoEntryResp);
        } catch (Exception e) {
            log.error("推单流水号[{}],信息录入异常:{}", infoEntryReq.getPushOrderNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "完成推单并提交")
    @PostMapping("/finishPushOrder")
    public ResponseVo<PushOrderResp> finishPushOrder(@Validated @RequestBody FinishPushOrderReq finishPushOrderReq) {
        PushOrderResp pushOrderResp = new PushOrderResp();
        pushOrderResp.setPushOrderNo(finishPushOrderReq.getPushOrderNo());
        return new ResponseVo<>(pushOrderResp);
    }

    @ApiOperation(value = "获取评分结果")
    @PostMapping("/getScore")
    public ResponseVo<GetScoreResp> getScore(@Validated @RequestBody GetScoreReq getScoreReq) {
        try {
            JSONObject jsonObj = new JSONObject();
            GetScoreResp getScoreResp = pushOrderSupportService.getScore(getScoreReq.getPushOrderNo(), jsonObj);
            if (null == getScoreResp) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }

            return new ResponseVo<>(getScoreResp);
        } catch (Exception e) {
            log.error("推单[{}]获取评分结果异常:{}", getScoreReq.getPushOrderNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "放弃推单")
    @PostMapping("/giveUpPushOrder")
    public ResponseVo<PushOrderResp> giveUpPushOrder(@Validated @RequestBody GiveUpPushOrderReq giveUpPushOrderReq) {
        try {
            JSONObject jsonObj = new JSONObject();
            if (!pushOrderSupportService.giveUpPushOrder(giveUpPushOrderReq, jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            PushOrderResp pushOrderResp = new PushOrderResp();
            pushOrderResp.setPushOrderNo(giveUpPushOrderReq.getPushOrderNo());
            pushOrderResp.setPushStatus(DpbsStatusCnst.PUSH_FAIL);
            return new ResponseVo<>(pushOrderResp);
        } catch (Exception e) {
            log.error("推单[{}]扫描身份证异常:{}", giveUpPushOrderReq.getPushOrderNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

}
