package com.dashuf.dpbs.util.sftp;

import java.util.Properties;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.cnst.SftpCnst;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import com.jcraft.jsch.Channel;
import com.jcraft.jsch.ChannelSftp;
import com.jcraft.jsch.JSch;
import com.jcraft.jsch.JSchException;
import com.jcraft.jsch.Session;

@Slf4j
public class SFTPChannel {
    Session session = null;
    Channel channel = null;

    public ChannelSftp getChannel(JSONObject sftpJsonObj, int timeout) throws JSchException {

        String ftpHost = sftpJsonObj.getString(SftpCnst.SFTP_REQ_REMOTE_HOST);
        String port = sftpJsonObj.getString(SftpCnst.SFTP_REQ_REMOTE_PROT);
        String ftpUserName = sftpJsonObj.getString(SftpCnst.SFTP_REQ_REMOTE_USER);
        String ftpPassword = sftpJsonObj.getString(SftpCnst.SFTP_REQ_REMOTE_SECRET);

        int ftpPort = SftpCnst.SFTP_REQ_REMOTE_DEFAULT_PORT;
        if (StringUtils.isNotEmpty(port)) {
            ftpPort = Integer.valueOf(port);
        }

        JSch jsch = new JSch(); // 创建JSch对象
        session = jsch.getSession(ftpUserName, ftpHost, ftpPort); // 根据用户名，主机ip，端口获取一个Session对象
        session.setPassword(ftpPassword); // 设置密码

        log.debug("Session created.");

        Properties config = new Properties();
        config.put("StrictHostKeyChecking", "no");
        config.put("PreferredAuthentications", "publickey,keyboard-interactive,password");

        session.setConfig(config); // 为Session对象设置properties
        session.setTimeout(timeout); // 设置timeout时间
        session.connect(); // 通过Session建立链接
        log.debug("Session connected.");

        log.debug("Opening Channel.");
        channel = session.openChannel("sftp"); // 打开SFTP通道
        channel.connect(); // 建立SFTP通道的连接
        log.debug("Connected successfully to ftpHost = " + ftpHost + ",as ftpUserName = " + ftpUserName
                + ", returning: " + channel);
        return (ChannelSftp) channel;
    }

    public void closeChannel() throws Exception {
        if (channel != null) {
            channel.disconnect();
        }
        if (session != null) {
            session.disconnect();
        }
    }
}