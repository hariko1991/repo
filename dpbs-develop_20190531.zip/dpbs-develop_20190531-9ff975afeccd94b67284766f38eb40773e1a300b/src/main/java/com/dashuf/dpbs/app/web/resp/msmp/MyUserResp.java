package com.dashuf.dpbs.app.web.resp.msmp;

import java.io.Serializable;

import com.github.pagehelper.PageInfo;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "我的用户分页列表Resp")
@Getter
@Setter
public class MyUserResp implements Serializable {
	private static final long serialVersionUID = -7966836728403275180L;

	@ApiModelProperty(value = "用户分页列表")
	private PageInfo<UserBean> userBeanPage;
}
