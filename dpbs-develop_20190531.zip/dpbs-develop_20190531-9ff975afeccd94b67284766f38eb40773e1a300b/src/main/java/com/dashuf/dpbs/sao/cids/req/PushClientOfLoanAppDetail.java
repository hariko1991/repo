package com.dashuf.dpbs.sao.cids.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Getter
@Setter
public class PushClientOfLoanAppDetail implements Serializable {

    /**
     * accountManagerId	string  非必须 客户经理UM账号
     */
    private String accountManagerId;
    /**
     * age	string 非必须 客户年龄
     */
    private Integer age;
    /**
     * areaCd	string 非必须 地区（省市区）
     */
    private String areaCd;
    /**
     * authorityLocationTxt	string  非必须 发证机关
     */
    private String authorityLocationTxt;
    /**
     * organizationId	string 非必须 分公司id（如有多个用,分隔，例如：id1,id2）（半刻必传）（联云必传）
     */
    private String organizationId;
    /**
     * certificateNum	string 必须 客户证件号（目前只支持身份证）
     */
    private String certificateNum;
    /**
     * certificateType	string 必须 客户证件类型（使用数据治理标准）
     */
    private String certificateType;
    /**
     * channelSource	string 必须 渠道标识（BANKE:半刻，LY:联云，DADAO:大道，FEITAI:飞钛）
     */
    private String channelSource;
    /**
     * creditCarsupplyInd	string 非必须 是否有信用卡分期车贷 0：否；1：是（半刻必传）
     */
    private String creditCarsupplyInd;
    /**
     * custName	string  必须 客户名称
     */
    private String custName;
    /**
     * custType	string 非必须 客户类型（010：上班族，060：企业主）（半刻必传）
     */
    private String custType;
    /**
     * enterprisesTaxesInd	string 必须 是否有企业税 0：否；1：是（企业主必传）
     */
    private String enterprisesTaxesInd;
    /**
     * expectLoanAmt	number 必须 期望贷款金额（半刻必传）
     */
    private String expectLoanAmt;
    /**
     * expectLoanTerm	string 必须 期望贷款期限（半刻必传）
     */
    private String expectLoanTerm;
    /**
     * houseAddress	string 必须 居住地址（省市区）code（6位数字）（半刻必传）
     */
    private String houseAddress;
    /**
     * houseAddressName	string 必须 居住地址（省市区）中文名称（半刻必传）
     */
    private String houseAddressName;
    /**
     * housePropertyInd	string 必须 是否有房产 0：否；1：是（半刻必传）
     */
    private String housePropertyInd;
    /**
     * householdRegistrationAddressTxt	string 非必须 户籍地址
     */
    private String householdRegistrationAddressTxt;

    /**
     * insurancePolicyInd	string 必须 是否有寿险保单 0：否；1：是（半刻必传）
     */
    private String insurancePolicyInd;
    /**
     * legalPersonInd	string 非必须 是否为法人 0：否；1：是（企业主必传）
     */
    private String legalPersonInd;
    /**
     * mobileTelephoneNum	string 必须 客户手机号码（半刻必传）（联云必传）
     */
    private String mobileTelephoneNum;
    /**
     * productId	string 非必须 产品id
     */
    private String productId;
    /**
     * regBusinessLicenseInd	string 非必须 是否注册营业执照 0：否；1：是（企业主必传）
     */
    private String regBusinessLicenseInd;
    /**
     * sex	string 非必须 性别 男=M 、F=女
     */
    private String sex;
    /**
     * shareholderInd	string 非必须 是否为股东 0：否；1：是（企业主必传）
     */
    private String shareholderInd;

    /**
     * thirdPartOrderId	string 必须 第三方推单编号
     */
    private String thirdPartOrderId;
    /**
     * validityPeriod	string 非必须 身份证有效期
     */
    private Date validityPeriod;
    /**
     * workAddress	string 非必须 单位地址（省市区）code（6位数字）（半刻必传）
     */
    private String workAddress;
    /**
     * workAddressName	string 必须 单位地址（省市区）中文名称（半刻必传）
     */
    private String workAddressName;
    /**
     * imageBantchId	string  非必须 影像批次id（通过此id可查询影像系统）（半刻必传）
     */
    private String imageBantchId;

    private List<PushClientOfLoanAppOfCarLoanDetail> carLoanList;
    private List<PushClientOfLoanAppOfHouseDetail> houseList;
    private List<PushClientOfLoanAppOfInsuranceDetail> insuranceList;
    private List<PushClientOfLoanAppOfTaxesDetail> taxesList;

}
