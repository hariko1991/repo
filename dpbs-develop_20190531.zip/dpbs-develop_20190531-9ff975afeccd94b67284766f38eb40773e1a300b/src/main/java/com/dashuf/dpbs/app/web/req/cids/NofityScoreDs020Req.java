package com.dashuf.dpbs.app.web.req.cids;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@ApiModel(value = "通知信贷状态req")
@Getter
@Setter
public class NofityScoreDs020Req implements Serializable {

    private static final long serialVersionUID = 7523679267013409226L;

    /**
     * applicationNum	string 必须 申请编号
     */
    @ApiModelProperty(value = "渠道申请编号", required = true)
    @NotBlank(message = "渠道申请编号不能为空")
    private String applicationNum;
}
