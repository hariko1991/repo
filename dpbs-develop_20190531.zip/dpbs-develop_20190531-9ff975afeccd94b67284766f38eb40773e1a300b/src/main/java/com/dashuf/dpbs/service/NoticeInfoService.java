package com.dashuf.dpbs.service;

import com.dashuf.dpbs.app.web.resp.home.NoticeResp;
import com.dashuf.dpbs.cnst.DpbsStatusCnst;
import com.dashuf.dpbs.mapper.NoticeInfoMapper;
import com.dashuf.dpbs.model.NoticeInfo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * 通知service类
 *
 * @author yaojiaoyi
 */
@Service
public class NoticeInfoService {
    @Autowired
    private NoticeInfoMapper noticeInfoMapper;

    /**
     * 获取公告列表
     * @return
     */
    public List<NoticeResp> getNoticeList() {
        NoticeInfo cond = new NoticeInfo();
        List<NoticeResp> rtnList = new ArrayList<>();
        cond.setStatus(DpbsStatusCnst.NORMAL);
        List<NoticeInfo> list = noticeInfoMapper.selectByModelSelective(cond, true);
        list.stream().filter(s -> s.getStartDate().before(new Date()) && s.getEndDate().after(new Date())).forEach(p -> {
            NoticeResp noticeResp = new NoticeResp();
            noticeResp.setNoticeContent(p.getNoticeContent());
            noticeResp.setNoticeTitle(p.getNoticeTitle());
            rtnList.add(noticeResp);
        });
        return rtnList;
    }
}
