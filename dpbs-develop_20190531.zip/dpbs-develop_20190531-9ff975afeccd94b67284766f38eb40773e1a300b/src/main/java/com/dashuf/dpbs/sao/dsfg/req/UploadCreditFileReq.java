package com.dashuf.dpbs.sao.dsfg.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
public class UploadCreditFileReq implements Serializable {

    private String certId;

    private String custName;

    /**
     * 查询渠道	Varchar(32)	DSRD/DD/DSPM/BANKE/WZSY/LIANYUN 大数融担/大道/信贷/半刻/微众税银/联云
     */
    private String queryChannel;

    private List<UploadCreditFile> paths;

    @Getter
    @Setter
    public static class UploadCreditFile {
        /**
         * 文件类型		文件类型 EGDAHT/ECQA 查阅授权书/查询授权书
         */
        private String fileType;

        private String path;
    }
}
