package com.dashuf.dpbs.mapper;

import com.dashuf.dpbs.model.PushOrderLog;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;

@Mapper
public interface ThirdPartyAccessMapper {
    public List<PushOrderLog> queryDs020GetScore();

    public int lockPushOrderLog(@Param("pushOrderNo") String pushOrderNo);

    public int unLockPushOrderLog(@Param("pushOrderNo") String pushOrderNo);
}