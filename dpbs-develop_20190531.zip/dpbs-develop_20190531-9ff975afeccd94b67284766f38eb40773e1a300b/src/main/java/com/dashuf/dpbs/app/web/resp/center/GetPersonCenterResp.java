package com.dashuf.dpbs.app.web.resp.center;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@ApiModel(value = "个人中心详情数据")
@Setter
@Getter
public class GetPersonCenterResp implements Serializable {

    @ApiModelProperty(value = "手机号码")
    private String mobileNo;

    @ApiModelProperty(value = "实名认证用户姓名")
    private String userName;

    @ApiModelProperty(value = "所属客户经理名子")
    private String srcUmName;

    @ApiModelProperty(value = "所属客户经理编码")
    private String srcUmNo;

    @ApiModelProperty(value = "所属客户经理手机号")
    private String srcUmMobileNo;

    @ApiModelProperty(value = "是否实名认证，false未实名，true已实名")
    private String isVerify;
}
