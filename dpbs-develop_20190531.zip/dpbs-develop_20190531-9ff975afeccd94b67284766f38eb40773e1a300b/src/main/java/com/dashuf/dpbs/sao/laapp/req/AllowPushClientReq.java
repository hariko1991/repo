package com.dashuf.dpbs.sao.laapp.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class AllowPushClientReq implements Serializable {
    /**
     * custName	string 必须 客户姓名
     */
    private String custName;
    /**
     * certificateNum	string 必须 客户证件号码（目前只支持身份证号）
     */
    private String certificateNum;
    /**
     * certificateType	string 必须 客户证件类型
     */
    private String certificateType;
}
