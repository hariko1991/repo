package com.dashuf.dpbs.app.web.req.credit;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "提交征信授权Req")
@Getter
@Setter
public class SubmitAuthH5Req implements Serializable {
    private static final long serialVersionUID = -5290251496172927734L;
    @ApiModelProperty(value = "推送订单编号", required = true)
    @NotBlank(message = "推送订单编号不能为空")
    private String pushOrderNo;

    @ApiModelProperty(value = "客户姓名", required = true)
    @NotBlank(message = "请输入客户姓名")
    private String clientName;

    @ApiModelProperty(value = "身份证号", required = true)
    @NotBlank(message = "请输入身份证号")
    @Pattern(regexp = "^[1-9]\\d{5}(18|19|([23]\\d))\\d{2}((0[1-9])|(10|11|12))(([0-2][1-9])|10|20|30|31)\\d{3}[0-9Xx]$", message = "身份证号码有误")
    private String certNo;

    @ApiModelProperty(value = "银联征信授权码", required = true)
    private String creditAuthCode;

    @ApiModelProperty(value = "手机号码")
    @Pattern(regexp = "^[1][0-9]{10}$", message = "请输入正确的手机号")
    private String mobileNo;

}
