package com.dashuf.dpbs.app.web.req.user;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "客户以手机验证码登录")
@Getter
@Setter
public class LoginCodeReq implements Serializable {

	private static final long serialVersionUID = -9028306805689397984L;

	/**
	 * 手机号码
	 */
	@ApiModelProperty(value = "手机号码")
	@NotBlank(message = "请输入正确的手机号")
	@Pattern(regexp = "^[1][0-9]{10}$", message = "请输入正确的手机号")
	private String mobileNo;

	/**
	 * 手机验证码
	 */
	@ApiModelProperty(value = "手机验证码")
	private String verifyCode;
	
	/**
	 * 微信code
	 */
	@ApiModelProperty(value = "微信授权码")
	private String wxCode;
}
