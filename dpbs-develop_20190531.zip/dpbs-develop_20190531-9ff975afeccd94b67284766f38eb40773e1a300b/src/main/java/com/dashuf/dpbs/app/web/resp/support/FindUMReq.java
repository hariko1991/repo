package com.dashuf.dpbs.app.web.resp.support;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

/**
 * Created with IDEA
 * author:Likangcheng
 * Date:2019/1/29
 * Time:11:18
 */
@ApiModel(value = "查询客户经理UM")
@Getter
@Setter
public class FindUMReq {

    @ApiModelProperty(value = "客户经理UM")
    private String srcUmNo;
}
