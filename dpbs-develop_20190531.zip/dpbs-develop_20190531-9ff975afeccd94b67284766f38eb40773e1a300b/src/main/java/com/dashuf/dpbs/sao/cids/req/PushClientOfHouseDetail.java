package com.dashuf.dpbs.sao.cids.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
public class PushClientOfHouseDetail implements Serializable {
    /**
     * houseInd	string 非必须 房产标识
     */
    private String houseInd;
    /**
     * housePropertyAddressDesc	string 非必须 房产详细地址
     */
    private String housePropertyAddressDesc;
    /**
     * houseTypeCd	string  非必须 房产类型
     */
    private String houseTypeCd;
    /**
     * houseValueAmt	string　　非必须　房产价值
     */
    private BigDecimal houseValueAmt;
}
