package com.dashuf.dpbs.cnst;

/**
 * @author yaojiaoyi
 * 订单状态常量
 */
public class StatusCnst {
    /**
     * 初始化
     */
    public static final String INIT = "init";
    /**
     * 扫描身份证
     */
    public static final String SCAN = "scan";
    /**
     * 影像上传
     */
    public static final String MOVIE = "movie";
    /**
     * 信息录入
     */
    public static final String ENTRY = "entry";
    /**
     * 征信授权
     */
    public static final String CREDIT = "credit";
    /**
     * 初评中
     */
    public static final String EVAL_ING = "eval_ing";
    /**
     * 初评失败
     */
    public static final String EVAL_FAIL = "eval_fail";
    /**
     * 初评通过
     */
    public static final String EVAL_SUCCESS = "eval_success";
    /**
     * 推单失败
     */
    public static final String FAIL = "fail";

    /**
     * 审批中
     */
    public static final String APPROVALING = "approval";
    /**
     * 审批通过/完成
     */
    public static final String APPROVAL_FINISH = "approval_finish";
    /**
     * 审批否决
     */
    public static final String APPROVAL_VETO = "approval_veto";
    /**
     * 放款成功
     */
    public static final String LOAN_SUCCESS = "loan_success";
    /**
     * 放款否决
     */
    public static final String LOAN_VETO = "loan_veto";

    /**
     * 推送客户端成功
     */
    public static final String PUSH_CLIENT_SUCCESS = "push_client_success";

    /**
     * 推单完成
     */
    public static final String PUSH_SUCCESS = "success";

    /**
     * 客户放弃
     */
    public static final String CUST_WAIVE = "cust_waive";
}
