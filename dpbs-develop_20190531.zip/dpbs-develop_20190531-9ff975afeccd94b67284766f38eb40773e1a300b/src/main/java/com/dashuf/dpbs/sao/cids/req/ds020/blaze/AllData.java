package com.dashuf.dpbs.sao.cids.req.ds020.blaze;

import com.dashuf.dpbs.sao.cids.req.ds010.blaze.BusinessDetail;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class AllData implements Serializable {
    @JsonProperty(value = "CERT_ID")
    private String certId;
    @JsonProperty(value = "CERT_TYPE")
    private String creditReportId;
    @JsonProperty(value = "CUSTOMER_NAME")
    private String customerName;
    @JsonProperty(value = "CUSTOMER_TYPE")
    private String customerType;

    @JsonProperty(value = "BUSINESS")
    private BusinessDetail business;
}
