package com.dashuf.dpbs.cnst;

import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.Map;

public final class DashufBlazeCnst {

    public static final String CREDIT_QR_CODE_URL = "请点击以下链接进行征信授权，为保护您的权益，点击前请确认该微信号为本人使用。<a href='%s'>征信授权</a>";

    private static final Map<String, String> GENDER_CD_MAP = new HashMap<>();

    static {
        GENDER_CD_MAP.put("man", "M");
        GENDER_CD_MAP.put("woman", "F");
    }


    private static final Map<String, String> CREDIT_SUPPLY_MAP = new HashMap<>();

    static {
        CREDIT_SUPPLY_MAP.put("true", "1");
        CREDIT_SUPPLY_MAP.put("false", "0");
    }


    private static final Map<String, String> COMMON_TRUE_FALSE_MAP = new HashMap<>();

    static {
        COMMON_TRUE_FALSE_MAP.put("true", "1");
        COMMON_TRUE_FALSE_MAP.put("false", "0");
    }

    public static String getCommonTrueFalseMap(String mapKey) {
        String retStr = COMMON_TRUE_FALSE_MAP.get(mapKey);
        if (StringUtils.isEmpty(retStr)) {
            return "0";
        }
        return retStr;
    }

    public static String getGenderCd(String mapKey) {
        String retStr = GENDER_CD_MAP.get(mapKey);
        if (StringUtils.isEmpty(retStr)) {
            return "0";
        }
        return retStr;
    }


}
