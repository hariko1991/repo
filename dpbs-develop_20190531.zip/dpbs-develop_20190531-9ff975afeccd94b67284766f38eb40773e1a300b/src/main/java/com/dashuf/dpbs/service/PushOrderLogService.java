package com.dashuf.dpbs.service;

import com.dashuf.dpbs.app.web.req.push.InfoEntryReq;
import com.dashuf.dpbs.mapper.*;
import com.dashuf.dpbs.model.*;
import com.dashuf.dpbs.service.blaze.dto.DashufBlazeDto;
import com.dashuf.dpbs.util.DpbsUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.PropertyUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.cnst.DpbsCnst;

import java.lang.reflect.InvocationTargetException;
import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class PushOrderLogService {
    @Autowired
    private PushOrderLogMapper pushOrderLogMapper;
    @Autowired
    private InfoEntryMapper infoEntryMapper;
    @Autowired
    private HouseInfoMapper houseInfoMapper;
    @Autowired
    private CreditSupplyInfoMapper creditSupplyInfoMapper;
    @Autowired
    private InsuranceInfoMapper insuranceInfoMapper;
    @Autowired
    private ClientInfoMapper clientInfoMapper;
    @Autowired
    private UserInfoMapper userInfoMapper;

    public PushOrderLog queryPushOrderLog(PushOrderLog pushOrderLog) {
        return pushOrderLogMapper.queryPushOrderLog(pushOrderLog);
    }

    public PushOrderLog selectOneByModelSelective(PushOrderLog pushOrderLogParam, Boolean sqlStrict) {
        return pushOrderLogMapper.selectOneByModelSelective(pushOrderLogParam, sqlStrict);
    }

    public boolean updatePushOrderLogByOrgStatus(PushOrderLog pushOrderLog, String orgStatus, JSONObject jsonObj) {
        int dealCnt = pushOrderLogMapper.updatePushOrderLogByOrgStatus(pushOrderLog, orgStatus);
        if (DpbsCnst.NUMBER_1 != dealCnt) {
            jsonObj.put(DpbsCnst.RTN_MSG, "更新为" + pushOrderLog.getPushStatus() + "失败");
            return false;
        }
        return DpbsCnst.SQL_PRECISE_STRICT;
    }

    public int initPushOrder(String pushOrderNo) {
        return pushOrderLogMapper.initPushOrder(pushOrderNo);
    }

    public boolean giveUpPushOrderLog(PushOrderLog pushOrderLog, JSONObject jsonObj) {
        int dealCnt = pushOrderLogMapper.giveUpPushOrderLog(pushOrderLog);
        if (DpbsCnst.NUMBER_1 != dealCnt) {
            jsonObj.put(DpbsCnst.RTN_MSG, "更新为" + pushOrderLog.getPushStatus() + "失败");
            return false;
        }
        return DpbsCnst.SQL_PRECISE_STRICT;
    }

    public boolean fullPushOrderLog(InfoEntryReq infoEntryReq, JSONObject jsonObj, PushOrderLog pushOrderLog) throws IllegalAccessException, InvocationTargetException, NoSuchMethodException {
        InfoEntry infoEntry = new InfoEntry();
        PropertyUtils.copyProperties(infoEntry, infoEntryReq);
        String infoEntryNo = DpbsUtil.getTableNo(DpbsUtil.PREFIX_INFO_ENTRY_INFO);
        infoEntry.setInfoEntryNo(infoEntryNo);
        infoEntry.setPushOrderNo(infoEntryReq.getPushOrderNo());
        pushOrderLog.setInfoEntryNo(infoEntryNo);

        int dealCnt = infoEntryMapper.insertSelective(infoEntry);
        if (DpbsCnst.NUMBER_1 != dealCnt) {
            jsonObj.put(DpbsCnst.RTN_MSG, "信息录入失败");
            return false;
        }

        if (DpbsCnst.TRUE_STR.equals(infoEntryReq.getIfHouse())) {
            pushOrderLog.setIfHouse(DpbsCnst.TRUE_STR);

            List<HouseInfo> houseInfoList = new ArrayList<>();
            infoEntryReq.getHouseList().forEach(house -> {
                HouseInfo houseInfo = new HouseInfo();
                BeanUtils.copyProperties(house, houseInfo);
                houseInfo.setPushOrderNo(infoEntryReq.getPushOrderNo());
                houseInfo.setInfoEntryNo(infoEntryNo);

                String houseInfoNo = DpbsUtil.getTableNo(DpbsUtil.PREFIX_HOUSE_INFO);
                houseInfo.setHouseInfoNo(houseInfoNo);
                houseInfoList.add(houseInfo);
            });

            dealCnt = houseInfoMapper.insertBatchSelective(houseInfoList);
            if (DpbsCnst.NUMBER_1 > dealCnt) {
                jsonObj.put(DpbsCnst.RTN_MSG, "房产信息录入失败");
                return false;
            }
        }

        if (DpbsCnst.TRUE_STR.equals(infoEntryReq.getIfCreditSupply())) {
            pushOrderLog.setIfCreditSupply(DpbsCnst.TRUE_STR);

            List<CreditSupplyInfo> creditSupplyInfoList = new ArrayList<>();
            infoEntryReq.getCreditSupplyList().forEach(crediySupply -> {
                CreditSupplyInfo creditSupplyInfo = new CreditSupplyInfo();
                BeanUtils.copyProperties(crediySupply, creditSupplyInfo);
                creditSupplyInfo.setPushOrderNo(infoEntryReq.getPushOrderNo());

                String creditSupplyInfoNo = DpbsUtil.getTableNo(DpbsUtil.PREFIX_CREDIT_SUPPLY_INFO);
                creditSupplyInfo.setCreditSupplyNo(creditSupplyInfoNo);
                creditSupplyInfo.setInfoEntryNo(infoEntryNo);
                creditSupplyInfoList.add(creditSupplyInfo);
            });


            dealCnt = creditSupplyInfoMapper.insertBatchSelective(creditSupplyInfoList);
            if (DpbsCnst.NUMBER_1 > dealCnt) {
                jsonObj.put(DpbsCnst.RTN_MSG, "信用卡分期信息录入失败");
                return false;
            }
        }

        if (DpbsCnst.TRUE_STR.equals(infoEntryReq.getIfInsurance())) {
            pushOrderLog.setIfInsurance(DpbsCnst.TRUE_STR);

            List<InsuranceInfo> insuranceInfoList = new ArrayList<InsuranceInfo>();
            infoEntryReq.getInsuranceList().forEach(insurance -> {
                InsuranceInfo insuranceInfo = new InsuranceInfo();
                BeanUtils.copyProperties(insurance, insuranceInfo);
                insuranceInfo.setPushOrderNo(infoEntryReq.getPushOrderNo());

                String insuranceInfoNo = DpbsUtil.getTableNo(DpbsUtil.PREFIX_INSURANCE_INFO);
                insuranceInfo.setInsuranceInfoNo(insuranceInfoNo);
                insuranceInfo.setInfoEntryNo(infoEntryNo);
                insuranceInfoList.add(insuranceInfo);
            });
            dealCnt = insuranceInfoMapper.insertBatchSelective(insuranceInfoList);
            if (DpbsCnst.NUMBER_1 > dealCnt) {
                jsonObj.put(DpbsCnst.RTN_MSG, "寿险信息录入失败");
                return false;
            }
        }
        return DpbsCnst.SQL_PRECISE_STRICT;
    }

    public DashufBlazeDto gatherBlazeInfo(PushOrderLog pushOrderLog, JSONObject jsonObj) {
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        dashufBlazeDto.setPushOrderLog(pushOrderLog);

        ClientInfo clientInfoParam = new ClientInfo();
        clientInfoParam.setClientNo(pushOrderLog.getClientNo());
        ClientInfo clientInfo = clientInfoMapper.selectOneByModelSelective(clientInfoParam, DpbsCnst.SQL_PRECISE_STRICT);
        if (null == clientInfo) {
            jsonObj.put(DpbsCnst.RTN_MSG, "客户信息为空");
            return null;
        }

        dashufBlazeDto.setClientInfo(clientInfo);

        UserInfo userInfoParam = new UserInfo();
        userInfoParam.setUserNo(clientInfo.getReconUserNo());
        UserInfo userInfo = userInfoMapper.selectOneByModelSelective(userInfoParam, DpbsCnst.SQL_PRECISE_STRICT);
        if (null == userInfo) {
            jsonObj.put(DpbsCnst.RTN_MSG, "用户信息为空");
            return null;
        }
        dashufBlazeDto.setUserInfo(userInfo);

        InfoEntry infoEntryParam = new InfoEntry();
        infoEntryParam.setInfoEntryNo(pushOrderLog.getInfoEntryNo());
        InfoEntry infoEntry = infoEntryMapper.selectOneByModelSelective(infoEntryParam, DpbsCnst.SQL_PRECISE_STRICT);
        dashufBlazeDto.setInfoEntry(infoEntry);

        if (DpbsCnst.TRUE_STR.equals(pushOrderLog.getIfHouse())) {
            HouseInfo houseInfoParam = new HouseInfo();
            houseInfoParam.setInfoEntryNo(pushOrderLog.getInfoEntryNo());
            List<HouseInfo> houseInfoList = houseInfoMapper.selectByModelSelective(houseInfoParam, DpbsCnst.SQL_PRECISE_STRICT);
            dashufBlazeDto.setHouseInfoList(houseInfoList);
        }

        if (DpbsCnst.TRUE_STR.equals(pushOrderLog.getIfCreditSupply())) {
            CreditSupplyInfo creditSupplyInfoParam = new CreditSupplyInfo();
            creditSupplyInfoParam.setInfoEntryNo(pushOrderLog.getInfoEntryNo());
            List<CreditSupplyInfo> creditSupplyInfoList = creditSupplyInfoMapper.selectByModelSelective(creditSupplyInfoParam, DpbsCnst.SQL_PRECISE_STRICT);
            dashufBlazeDto.setCreditSupplyInfoList(creditSupplyInfoList);
        }

        if (DpbsCnst.TRUE_STR.equals(pushOrderLog.getIfInsurance())) {
            InsuranceInfo insuranceInfoParam = new InsuranceInfo();
            insuranceInfoParam.setInfoEntryNo(pushOrderLog.getInfoEntryNo());
            List<InsuranceInfo> insuranceInfoList = insuranceInfoMapper.selectByModelSelective(insuranceInfoParam, DpbsCnst.SQL_PRECISE_STRICT);
            dashufBlazeDto.setInsuranceList(insuranceInfoList);
        }
        return dashufBlazeDto;
    }

    public boolean updatePushOrderLog(PushOrderLog pushOrderLogParam, JSONObject jsonObj) {
        int dealCnt = pushOrderLogMapper.updatePushOrderLog(pushOrderLogParam);
        if (DpbsCnst.NUMBER_1 != dealCnt) {
            jsonObj.put(DpbsCnst.RTN_MSG, "更新为" + pushOrderLogParam.getApplicationId() + "失败");
            return false;
        }
        return DpbsCnst.SQL_PRECISE_STRICT;
    }
}
