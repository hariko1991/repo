package com.dashuf.dpbs.sao.sms;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * , url="http://10.21.0.23:8250" sit
 * , url = "http://10.22.0.123:8250" uat
 */
@FeignClient(name = "PM-RequestRedirect")
public interface SendMessageSAO {

    /**
     * 发送验证码
     *
     * @param phone      手机号码
     * @param applyNo    流水编号
     * @param templateId 短信模板id
     * @param smsType    短信类型 默认为14：通知类，其他2类分别为营销16和催收17
     * @return
     */
    @RequestMapping(value = "/ShortMessagePlatform/api/SendMessage/sendVerificationCode", method = RequestMethod.GET)
    String sendVerificationCode(@RequestParam("phone") String phone, @RequestParam("applyNo") String applyNo, @RequestParam("templateId") String templateId,
                                @RequestParam("smsType") Integer smsType);

    /**
     * 发送验证码
     *
     * @param phone      手机号码
     * @param applyNo    流水编号
     * @param templateId 短信模板id
     * @return
     */
    @RequestMapping(value = "/ShortMessagePlatform/api/SendMessage/sendVerificationCode", method = RequestMethod.GET)
    String sendVerificationCode(@RequestParam("phone") String phone, @RequestParam("applyNo") String applyNo, @RequestParam("templateId") String templateId);

    /**
     * 校验验证码
     *
     * @param applyNo          流水编号
     * @param phone            手机号码
     * @param verificationCode 验证码
     * @return
     */
    @RequestMapping(value = "/ShortMessagePlatform/api/SendMessage/checksumVerificationCode", method = RequestMethod.GET)
    String checksumVerificationCode(@RequestParam("applyNo") String applyNo, @RequestParam("phone") String phone,
                                    @RequestParam("verificationCode") String verificationCode, @RequestParam("effectiveTime") String effectiveTime);

    /**
     * 发送短信
     *
     * @param phones     一个或多个手机号用逗号分割
     * @param applyNo    流水编号
     * @param content    短信内容
     * @param smsType    短信类型（可以传或者不传）
     * @param smsChannel 短信渠道（11为大数金融 12为大数融担13为飞钛科技）
     * @return
     */
    @RequestMapping(value = "/ShortMessagePlatform/api/SendMessage/sendMsg", method = RequestMethod.GET)
    String sendMsg(@RequestParam("phones") String phones, @RequestParam("applyNo") String applyNo, @RequestParam("content") String content,
                   @RequestParam("smsType") Integer smsType, @RequestParam("smsChannel") Integer smsChannel);

    /**
     * 根据短信模板id发送短信消息
     *
     * @param phones     一个或多个手机号用逗号分割
     * @param applyNo    流水编号
     * @param templateId 短信模板id（特殊说明：模板里面的变量按照数目依次为$1,$2,$3,$4,$5依次类增，根据模板变量个数传模板变量值）
     * @param smsType    短信类型（可以传或者不传）
     * @param params     模板变量值
     * @return
     */
    @RequestMapping(value = "/ShortMessagePlatform/api/SendMessage/sendMsgByTemplate", method = RequestMethod.GET)
    String sendMsgByTemplate(@RequestParam("phones") String phones, @RequestParam("applyNo") String applyNo, @RequestParam("templateId") Integer templateId,
                             @RequestParam("smsType") Integer smsType, @RequestParam("params") String params);
}
