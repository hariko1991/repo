package com.dashuf.dpbs.app.web.req.push;

import java.io.Serializable;
import java.math.BigDecimal;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "信用卡分期")
@Getter
@Setter
public class InfoEntryOfCreditSupply implements Serializable {
	private static final long serialVersionUID = 5073571379927454267L;

	@ApiModelProperty(value = "月还款额")
	private BigDecimal monthlyAmt;
}
