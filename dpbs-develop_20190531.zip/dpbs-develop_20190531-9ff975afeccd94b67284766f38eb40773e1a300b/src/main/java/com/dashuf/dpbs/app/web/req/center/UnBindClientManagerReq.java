package com.dashuf.dpbs.app.web.req.center;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@ApiModel(value = "解绑客户经理请求")
@Setter
@Getter
public class UnBindClientManagerReq implements Serializable {
    @ApiModelProperty(value = "用户编号")
    private String userNo;

}
