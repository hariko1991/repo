package com.dashuf.dpbs.service.support;

import java.io.File;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.DpbsStatusCnst;
import com.dashuf.dpbs.mapper.StepRefLogMapper;
import com.dashuf.dpbs.model.StepRefLog;
import com.ubtech.client.UBCMPClient;
import com.ubtech.client.UBCMPClientHttpImpl;
import com.ubtech.cmp.bean.ContentBean;
import com.ubtech.cmp.bean.ContentDocBean;
import com.ubtech.cmp.bean.ContentIndexBean;
import com.ubtech.cmp.bean.FileBean;
import com.ubtech.cmp.bean.SDKResultBean;
import com.ubtech.global.GlobalDefine;
import com.ubtech.util.DateUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class MoviePlatRefService implements InitializingBean {

    private static UBCMPClient client;
    private static String MODEL_CODE = "CPMS"; // 内容模型代码
    private static String MODEL_DOC_CODE = "CPMS_DOC";// 文档部件模型代码
    private static String TOKEN_TYPE_NONE = "none";

    @Autowired
    private StepRefLogMapper stepRefLogMapper;

    @Value("${application.ubecm.user.no}")
    private String APPLICATION_UBECM_USER_NO;
    @Value("${application.ubecm.user.password}")
    private String APPLICATION_UBECM_USER_PASSWORD;
    @Value("${application.ubecm.server.ip}")
    private String APPLICATION_UBECM_SERVER_IP;
    @Value("${application.ubecm.server.port}")
    private int APPLICATION_UBECM_SERVER_PORT;
    @Value("${application.ubecm.server.name}")
    private String APPLICATION_UBECM_SERVER_NAME;
    @Value("${application.ubecm.save.path}")
    private String APPLICATION_UBECM_SAVE_PATH;

    public List<File> copyTempFileToServer(MultipartFile[] fileList) throws Exception {
        String dateStr = DateUtil.formatDate(new Date(), DateUtil.YYYYMMDD_ONLY);
        List<File> destFileList = new ArrayList<File>();
        // 把所有的文件全部遍历出来,以供后续处理
        for (int i = 0; i < fileList.length; i++) {
            File destFile = new File(APPLICATION_UBECM_SAVE_PATH + dateStr + "\\" + fileList[i].getOriginalFilename());
            FileUtils.copyToFile(fileList[i].getInputStream(), destFile);
            destFileList.add(destFile);
        }
        return destFileList;
    }

    public void deleteTempFileFromServer(List<File> destFileList) {
        destFileList.forEach(destFile -> {
            FileUtils.deleteQuietly(destFile);
        });
    }

    public JSONObject uploadHandler(String loanStepCode, String applicationId, List<File> fileList) {
        ContentBean cBean = packageUploadMovieReq(fileList);

        JSONObject rtnObj = new JSONObject();
        StepRefLog stepRefLog = new StepRefLog();
        try {
            SDKResultBean sdkBean = client.upload(cBean, "");
            log.info("关键流水号[{}],上传影象平台步骤[{}],返回结果{}", applicationId, loanStepCode, JSONObject.toJSONString(sdkBean));
            if (GlobalDefine.SUCCESS.equals(sdkBean.getResultCode())) {
                // 上传成功后只会返回一个内容对象，直接取就可以
                ContentBean contentBean = sdkBean.getContentBeans().get(0);

                rtnObj.put("contentId", contentBean.getINDEX_BEAN().getCONTENT_ID());

                List<String> fileIdList = new ArrayList<String>();
                contentBean.getDOC_BEANS().get(0).getFiles().forEach(fileBean -> {
                    fileIdList.add(fileBean.getFILE_ID());
                });

                rtnObj.put("uploadFileList", fileIdList);
                stepRefLog.setStepStatus(DpbsStatusCnst.SUCCESS);
            } else {
                rtnObj.put(DpbsCnst.RTN_CODE, DpbsCnst.FAIL_RTN_CODE);
                rtnObj.put(DpbsCnst.RTN_MSG, sdkBean.getResultCode() + sdkBean.getResultMsg());
                stepRefLog.setStepStatus(DpbsStatusCnst.FAIL);
            }

        } catch (Exception e) {
            log.error("关键流水号[{}],上传影象平台步骤[{}]发生异常", applicationId, loanStepCode, e);
            rtnObj.put(DpbsCnst.RTN_CODE, DpbsCnst.FAIL_RTN_CODE);
            rtnObj.put(DpbsCnst.RTN_MSG, DpbsCnst.SERVER_ERROR);
            stepRefLog.setStepStatus(DpbsStatusCnst.FAIL);
        }

        stepRefLog.setStepRefNo(applicationId);
        stepRefLog.setStepCode(loanStepCode);
        stepRefLog.setStepValOne(JSONObject.toJSONString(rtnObj));
        stepRefLogMapper.insertSelective(stepRefLog);
        return rtnObj;
    }

    private ContentBean packageUploadMovieReq(List<File> fileList) {
        // 新建批次描述对象
        ContentBean cBean = new ContentBean();
        // 必要信息，设置内容模型英文名，组合模型按照索引对象的名称
        cBean.setMODEL_CODE(MODEL_CODE);
        // 必要信息，设置用户，校验用户的权限
        cBean.setUSER_NO(APPLICATION_UBECM_USER_NO);
        cBean.setPASSWORD(APPLICATION_UBECM_USER_PASSWORD);
        // 可选信息,若内容模型配置有安全校验,需要设置令牌校验的值.
        // token_verify_code为用户定义的校验字符串
        // tokenCode为动态令牌
        cBean.setTOKEN_TYPE(TOKEN_TYPE_NONE);// 不校验token
        // cBean.setTOKEN_VERIFY_CODE(token_verify_code);
        // cBean.setTOKEN_CODE(tokenCode);

        // =========================设置索引对象信息开始=========================
        // 新建索引对象
        ContentIndexBean indexBean = new ContentIndexBean();
        // 必要信息,设置上传的批次文件数量
        indexBean.setCONTENT_COUNT(String.valueOf(fileList.size()));
        // 设置批次的内容ID（客户端指定则上传）
        // ciBean.setCONTENT_ID("20120620_6_146_1D60A0A0-F7EC-2AB1-5023-192CF3A50F6F-1");

        // 索引自定义属性
        // 自定义属性中必须有一个8位数字字段，用以分表，从内容模型模板中获取字段名 20180620
        indexBean.addCustomMap("BUSI_START_DATE", DateUtil.formatDate(new Date(), DateUtil.YYYYMMDD_ONLY));
        // =========================设置索引对象信息结束=========================

        // =========================设置文档部件信息开始=========================
        // 新建一个文档部件
        ContentDocBean docBean = new ContentDocBean();
        // 必要信息,设置文档对象的内容模型名称
        docBean.setMODEL_DOC_CODE(MODEL_DOC_CODE);
        // =========================设置文档部件信息结束=========================

        // =========================添加文件=========================
        fileList.forEach(file -> {
            FileBean fileBean = new FileBean();
            fileBean.setFILE_NAME(file.getAbsolutePath());
            fileBean.addOtherCustom("FILE_CN_NAME", "9010");
            docBean.addFile(fileBean);
        });
        // =========================添加文件=========================

        // 将文档索引信息和文档部件信息与批次信息关联
        cBean.setINDEX_BEAN(indexBean);
        cBean.addDOC_BEANS(docBean);
        return cBean;
    }

    public JSONObject queryHandler(String loanStepCode, String applicationId, String contentId) {
        ContentBean cBean = packageQueryMovieReq(contentId);
        JSONObject rtnObj = new JSONObject();
        StepRefLog stepRefLog = new StepRefLog();

        try {
            SDKResultBean sdkBean = client.queryContent(cBean, "");
            log.info("关键流水号[{}],查询影象平台步骤[{}],返回结果{}", applicationId, loanStepCode, JSONObject.toJSONString(sdkBean));

            if (GlobalDefine.SUCCESS.equals(sdkBean.getResultCode())) {
                List<ContentBean> sdkBeanList = sdkBean.getContentBeans();
                // 非null时表示有数据，且内容对象在不指定版本查询时，可能有多个版本
                if (CollectionUtils.isNotEmpty(sdkBeanList)) {
                    rtnObj.put("contentId", sdkBeanList.get(0).getINDEX_BEAN().getCONTENT_ID());

                    List<com.dashuf.dpbs.app.web.resp.bean.FileBean> fileBeanList = new ArrayList<com.dashuf.dpbs.app.web.resp.bean.FileBean>();
                    sdkBeanList.forEach(sdkInnerBean -> {
                        sdkInnerBean.getDOC_BEANS().forEach(docBean -> {
                            docBean.getFiles().forEach(fileBean -> {
                                com.dashuf.dpbs.app.web.resp.bean.FileBean rtnBean = new com.dashuf.dpbs.app.web.resp.bean.FileBean();
                                rtnBean.setContentId(fileBean.getCONTENT_ID());
                                rtnBean.setFileId(fileBean.getFILE_ID());
                                rtnBean.setFileUrl(fileBean.getURL());
                                fileBeanList.add(rtnBean);
                            });
                        });
                    });

                    rtnObj.put("queryFileList", fileBeanList);
                } else {
                    rtnObj.put(DpbsCnst.RTN_CODE, DpbsStatusCnst.FAIL);
                    rtnObj.put(DpbsCnst.RTN_MSG, "无具体内容");
                    stepRefLog.setStepStatus(DpbsStatusCnst.FAIL);
                }
            } else {
                rtnObj.put(DpbsCnst.RTN_CODE, sdkBean.getResultCode());
                rtnObj.put(DpbsCnst.RTN_MSG, sdkBean.getResultMsg());
                stepRefLog.setStepStatus(DpbsStatusCnst.FAIL);
            }

        } catch (Exception e) {
            log.error("关键流水号[{}],查询影象平台步骤[{}]发生异常", applicationId, loanStepCode, e);
            rtnObj.put(DpbsCnst.RTN_CODE, DpbsStatusCnst.FAIL);
            rtnObj.put(DpbsCnst.RTN_MSG, DpbsCnst.SERVER_ERROR);
            stepRefLog.setStepStatus(DpbsStatusCnst.FAIL);
        }

        stepRefLog.setStepRefNo(applicationId);
        stepRefLog.setStepCode(loanStepCode);
        stepRefLog.setStepValOne(JSONObject.toJSONString(rtnObj));
        stepRefLogMapper.insertSelective(stepRefLog);
        return rtnObj;
    }

    private ContentBean packageQueryMovieReq(String contentId) {
        ContentBean cBean = new ContentBean();
        // 必要信息,设置内容模型
        cBean.setMODEL_CODE(MODEL_CODE);
        // 必要信息,设置用户名
        cBean.setUSER_NO(APPLICATION_UBECM_USER_NO);
        // 必要信息,设置密码
        cBean.setPASSWORD(APPLICATION_UBECM_USER_PASSWORD);
        // 不校验token
        cBean.setTOKEN_TYPE(TOKEN_TYPE_NONE);
        // "21111113-EA12345678-330A-AA02-46D1-12345678E8"
        cBean.getINDEX_BEAN().setCONTENT_ID(contentId);
        // 必要信息,自定义属性中必须有一个8位数字字段,用以分表,从内容模型模板中获取字段名
        // "20180620"
        // cBean.getINDEX_BEAN().addCustomMap("BUSI_START_DATE", busiStartDate);
        // 可选信息,若设定批次版本,则返回该版本号的批次,若没有版本号则返回所有版本的批次
        // cBean.getINDEX_BEAN().setVERSION("0");
        // 可选信息,根据自定义属性信息来查询
        // ContentDocBean cdBean = new ContentDocBean();
        // 要查询的文档部件名
        // cdBean.setMODEL_DOC_CODE(modelDocCode);
        // cdBean.addFilter("FILE_ID", "01C2F9AACC-F20F-B992-A02C-F08ED93E3D");
        // 设置自定义属性信息作为过滤条件
        // cdBean.addFilter("FILE_CN_NAME", "111111");
        // cdBean.addFilter("BUSI_FILE_TYPE", "001");
        // cdBean.addFilter("BUSI_FILE_TYPE", "002");

        // cBean.addDOC_BEANS(cdBean);

        // 若内容模型配置有安全校验
        // cBean.setTOKEN_VERIFY_CODE(token_verify_code);
        // cBean.setTOKEN_CODE(tokenCode);
        return cBean;
    }

    @Override
    public void afterPropertiesSet() {
        String logMsg = String.format("初始化影像平台相关参数信息,服务器地址[%s],服务器端口[%s],服务器名称[%s]", APPLICATION_UBECM_SERVER_IP, APPLICATION_UBECM_SERVER_PORT,
                APPLICATION_UBECM_SERVER_NAME);
        try {
            client = new UBCMPClientHttpImpl(APPLICATION_UBECM_SERVER_IP, APPLICATION_UBECM_SERVER_PORT, APPLICATION_UBECM_SERVER_NAME);
            log.info("{}初始化成功", logMsg);
        } catch (Exception e) {
            log.error("{}初始化过程异常", logMsg, e);
        }
    }


}
