package com.dashuf.dpbs.cnst;

public final class RouteUrlCnst {
	/**
	 * 银联h5征信授权成功后跳转页面返回商户的页面
	 */
	public static final String CREDIT_AUTH_RETURN_PAGE = "creditAuthReturnPage";
	/**
	 * 二维码授权成功后公从号中弹出消息客户点击后把当前二维码置为过期
	 */
	public static final String ANALYSIS_QR_SESSION_TOKEN = "analysisQrSessionToken";
	/**
	 * 下载二代app链接
	 */
	public static final String DOWNLOAD_LOAN_APP = "downloadLoanApp";
}
