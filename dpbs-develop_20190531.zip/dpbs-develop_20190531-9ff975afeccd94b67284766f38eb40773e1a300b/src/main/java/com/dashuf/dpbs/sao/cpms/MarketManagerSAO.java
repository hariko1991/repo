package com.dashuf.dpbs.sao.cpms;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.merlin.web.base.views.ResponseVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "CPMS")
public interface MarketManagerSAO {

    @RequestMapping(value = "/cpms/v1/marketing-management/exclusive-channels", method = RequestMethod.GET)
    ResponseVo<JSONObject> getExclusiveChannel(@RequestParam("channelName") String channelName);

    @RequestMapping(value = "/cpms/v1/marketing-management/exclusive-channels/available", method = RequestMethod.GET)
    ResponseVo<JSONObject> getExclusiveChannelAvailable(@RequestParam("channelName") String channelName);


    /**
     * 根据UM 模糊查询客户经理列表
     *
     * @param userId uMno
     * @return
     */
    @RequestMapping(value = "/cpms/v1/marketing-management/members/{userId}", method = RequestMethod.GET)
    ResponseVo<JSONObject> getTeamListOfUmNo(@PathVariable("userId") String userId);

    /**
     * 根据UM查询客户经理信息
     *
     * @param postTypeCodeList CM EC
     * @param userId           uMno
     * @return
     */
    @RequestMapping(value = "/cpms/v1/marketing-management/members/available", method = RequestMethod.GET)
    ResponseVo<JSONObject> getTeamListAvailable(@RequestParam("postTypeCodeList") String[] postTypeCodeList, @RequestParam("userId") String userId);

    /**
     * 模糊查询公司渠道列表
     *
     * @param channelName 渠道名称
     * @return
     */
    @RequestMapping(value = "/cpms/v1/marketing-management/organization-channels/available", method = RequestMethod.GET)
    ResponseVo<JSONObject> getOrganizationChannelsListAvailable(@RequestParam("channelName") String channelName);

}
