package com.dashuf.dpbs.util;

import java.util.ArrayList;
import java.util.List;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.cnst.SysDictCnst;
import com.dashuf.dpbs.model.SysAreaInfo;
import com.dashuf.dpbs.model.SysDict;

public final class CacheUtil {
    private static final String SYS_DICT_PARENT_0 = "0";
    private static final String SHOW = "show";
    private static final String VALUE = "value";
    private static final String CHILD = "child";
    private static final String AREA_NAME = "areaName";
    private static final String SORT_NO = "sortNo";
    private static final String AREA_NO = "areaNo";
    private static final List<SysAreaInfo> sysAreaList = new ArrayList<SysAreaInfo>();
    private static final List<SysDict> sysDictList = new ArrayList<SysDict>();

    public static List<SysAreaInfo> getSysAreaInfoList() {
        return sysAreaList;
    }

    public static List<SysDict> getSysDictList() {
        return sysDictList;
    }

    public static JSONArray getSysAreaOfJsonArray() {
        List<SysAreaInfo> provinceList = new ArrayList<SysAreaInfo>();
        List<SysAreaInfo> directCityList = new ArrayList<SysAreaInfo>();
        List<SysAreaInfo> cityList = new ArrayList<SysAreaInfo>();
        List<SysAreaInfo> areaInfoList = new ArrayList<SysAreaInfo>();

        sysAreaList.forEach(sysArea -> {
            if (SysDictCnst.PROVINCE.equals(sysArea.getAreaType())) {
                provinceList.add(sysArea);
            } else if (SysDictCnst.DIRECT_CITY.equals(sysArea.getAreaType())) {
                directCityList.add(sysArea);
            } else if (SysDictCnst.CITY.equals(sysArea.getAreaType())) {
                cityList.add(sysArea);
            } else if (SysDictCnst.AREA.equals(sysArea.getAreaType())) {
                areaInfoList.add(sysArea);
            }
        });

        JSONArray result = new JSONArray();
        JSONArray cityArr = new JSONArray();
        for (SysAreaInfo city : cityList) {
            JSONObject cityObj = getAreaJson(city);
            JSONArray cityChild = new JSONArray();
            for (int i = 0; i < areaInfoList.size(); i++) {
                SysAreaInfo area = areaInfoList.get(i);
                if (area.getSortNo().startsWith(city.getSortNo())) {
                    JSONObject areaObj = getAreaJson(area);
                    cityChild.add(areaObj);
                    areaInfoList.remove(i);
                    i--;
                }
            }
            cityObj.put(CHILD, cityChild);
            cityArr.add(cityObj);
        }
        for (SysAreaInfo directCity : directCityList) {
            JSONObject directCityObj = getAreaJson(directCity);
            JSONArray directCityChild = new JSONArray();
            for (int i = 0; i < areaInfoList.size(); i++) {
                SysAreaInfo area = areaInfoList.get(i);
                if (area.getSortNo().startsWith(directCity.getSortNo())) {
                    JSONObject areaObj = getAreaJson(area);
                    directCityChild.add(areaObj);
                    areaInfoList.remove(i);
                    i--;
                }
            }
            directCityObj.put(CHILD, directCityChild);
            result.add(directCityObj);
        }
        for (SysAreaInfo province : provinceList) {
            JSONObject provinceObj = getAreaJson(province);
            JSONArray provinceChild = new JSONArray();
            for (int k = 0; k < cityArr.size(); k++) {
                JSONObject cityObj = cityArr.getJSONObject(k);
                if (cityObj.get(SORT_NO).toString().startsWith(province.getSortNo())) {
                    provinceChild.add(cityObj);
                }
            }
            provinceObj.put(CHILD, provinceChild);
            result.add(provinceObj);
        }
        return result;
    }

    private static JSONObject getAreaJson(SysAreaInfo areaInfo) {
        JSONObject jsonObj = new JSONObject();
        jsonObj.put(AREA_NO, areaInfo.getAreaNo());
        jsonObj.put(SORT_NO, areaInfo.getSortNo());
        jsonObj.put(AREA_NAME, areaInfo.getAreaName());
        return jsonObj;
    }

    public static JSONObject getSysDictOfJsonObj() {
        JSONObject jsonObj = new JSONObject();
        for (SysDict sysDict : sysDictList) {
            if (SYS_DICT_PARENT_0.equals(sysDict.getDictPid())) {
                List<JSONObject> jsonList = new ArrayList<>();
                for (SysDict sysSubDict : sysDictList) {
                    // 父节点的id和子节点pid相等则是一个集合
                    if (sysDict.getDictNo().equals(sysSubDict.getDictPid())) {
                        JSONObject json = new JSONObject();
                        json.put(VALUE, sysSubDict.getDictKey());
                        json.put(SHOW, sysSubDict.getDictVal());
                        jsonList.add(json);
                    }
                }
                jsonObj.put(sysDict.getDictKey(), jsonList);
            }
        }
        return jsonObj;
    }

}
