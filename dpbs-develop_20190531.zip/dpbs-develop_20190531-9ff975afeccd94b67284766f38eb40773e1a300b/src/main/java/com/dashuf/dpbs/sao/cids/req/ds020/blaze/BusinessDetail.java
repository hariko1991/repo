package com.dashuf.dpbs.sao.cids.req.ds020.blaze;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class BusinessDetail implements Serializable {
    private static final long serialVersionUID = 4111172394889665332L;


    private BusinessOfDataDetail data;
}
