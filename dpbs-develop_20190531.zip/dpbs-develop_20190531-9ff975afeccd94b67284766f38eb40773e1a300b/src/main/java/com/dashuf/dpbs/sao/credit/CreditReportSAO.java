package com.dashuf.dpbs.sao.credit;

import com.dashuf.dpbs.sao.credit.req.CreditReport25Req;
import com.dashuf.dpbs.sao.credit.req.CreditUploadReq;
import com.dashuf.dpbs.sao.credit.resp.CreditReport25Resp;
import com.dashuf.dpbs.sao.credit.resp.CreditUploadResp;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * , url = "http://10.21.0.23:8250" sit
 * , url = "http://10.22.0.123:8250" uat
 */
@FeignClient(name = "PM-REQUESTREDIRECT")
public interface CreditReportSAO {

    /**
     * 查询人行征信报告25天内报告
     */
    @PostMapping(value = "/EDQ-CreditQuery/api/ICR_Q_003.do")
    CreditReport25Resp queryCreditReportWithin25Day(@RequestBody CreditReport25Req creditReport25Req);


    @PostMapping(value = "/CreditReportAuthorizeService/api/creditAuthorizeMaterialUpload.do", produces = "application/json")
    @ResponseBody
    CreditUploadResp submitCreditReportReq(@RequestBody CreditUploadReq creditUploadReq);
}


