package com.dashuf.dpbs.app.web.resp.credit;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "获取银联认证h5Resp")
@Getter
@Setter
public class CreditAuthH5Resp implements Serializable {
	private static final long serialVersionUID = -5290251496172927734L;
	@ApiModelProperty(value = "推送订单编号", required = true)
	private String pushOrderNo;

	@ApiModelProperty(value = "银联认证h5页面", required = true)
	private String h5AuthPage;
}
