package com.dashuf.dpbs.app.web.resp.center;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@ApiModel(value = "联系我们resp")
@Setter
@Getter
public class GetContactMsgResp implements Serializable {

    @ApiModelProperty(value = "手机号码")
    private String mobileNo;

    @ApiModelProperty(value = "实名认证用户姓名")
    private String userName;

    @ApiModelProperty(value = "所属客户经理名子")
    private String srcUmName;

    @ApiModelProperty(value = "所属客户经理编码")
    private String srcUmNo;

    @ApiModelProperty(value = "所属客户经理手机号")
    private String srcUmMobileNo;

    @ApiModelProperty(value = "客服电话")
    private String clientServicePhone;

    @ApiModelProperty(value = "服务时间")
    private String serviceTime;
}
