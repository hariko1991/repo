package com.dashuf.dpbs.sao.cids.req.ds010.blaze;

import com.dashuf.dpbs.sao.cids.req.ds010.blaze.application.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Getter
@Setter
public class BusinessOfDataOfApplicationDetail implements Serializable {

    private static final long serialVersionUID = 333483833695210541L;

    private String applicationDate;

    private String applicationNumber;

    private String callNode = "DS010";

    private String channel = "01";

    private String decisionArea = "RISK";

    private Integer randomDigit = 1;

    private List<AmtCalcInfo> amtCalcInfo;

    private List<Applicant> applicant;

    private List<ApplicationForm> applicationForm;

    private List<CustMgrInfo> custMgrInfo;

    private List<IntermediaryInfo> intermediaryInfo;
}
