package com.dashuf.dpbs.app.web.req.lawsuit;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotNull;

/**
 * @author yaojiaoyi
 */
@ApiModel(value = "获取验证码Req")
@Getter
@Setter
public class LawSuitReq {

    private String userNo;
    @NotNull(message = "请输入姓名")
    @ApiModelProperty(value = "姓名", required = true)
    private String name;
    @NotNull(message = "请输入身份证号码")
    @ApiModelProperty(value = "身份证号码", required = true)
    private String certNo;
}
