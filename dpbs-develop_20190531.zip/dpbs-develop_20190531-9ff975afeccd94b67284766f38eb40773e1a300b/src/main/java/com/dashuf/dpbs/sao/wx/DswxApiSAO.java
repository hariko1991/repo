package com.dashuf.dpbs.sao.wx;


import com.dashuf.dpbs.sao.wx.req.GetDashuQrTicketReq;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * , url = "http://10.21.0.23:8250" sit
 * , url = "http://10.22.0.123:8250" uat
 */
@FeignClient(name = "PM-RequestRedirect")
public interface DswxApiSAO {

    @RequestMapping(value = "/dswx/dswx/weixin/getTicket.do", method = RequestMethod.POST)
    public String getQrTicket(@RequestBody GetDashuQrTicketReq getDashuQrTicketReq);

}
