package com.dashuf.dpbs.sao.cids;

import com.dashuf.dpbs.sao.cids.req.*;
import com.dashuf.dpbs.sao.cids.req.ds010.Ds020Req;
import com.dashuf.dpbs.sao.cids.resp.*;
import com.dashuf.merlin.web.base.views.ResponseVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@FeignClient(name = "CIDS")
public interface ThirdPartyAccessSAO {

    @PostMapping(value = "/cids/api/dpbs/initialScreen")
    public ResponseVo<InitScreenDs010Resp> initScreenDs010(@RequestBody Ds020Req initScreenDs010Req);

    @PostMapping(value = "/cids/api/dpbs/getSoreAndQuota")
    public ResponseVo<GiveScoreDs020Resp> giveScoreDs020(@RequestBody GiveScoreDs020Req giveScoreDs020Req);

    @PostMapping(value = "/cids/api/dpbs/getCreditStatus")
    public ResponseVo<GetCreditStatusResp> getCreditStatus(@RequestBody GetCreditStatusReq getCreditStatusReq);

    @PostMapping(value = "/cids/api/dpbs/queryBlazeResult")
    public ResponseVo<QueryScoreDs020Resp> queryScoreDs020(@RequestBody QueryScoreDs020Req queryScoreDs020Req);

    @PostMapping(value = "/cids/api/dpbs/customerPush")
    public ResponseVo<PushClientResp> pushClient(@RequestBody PushClientReq pushClientReq);
}
