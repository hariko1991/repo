package com.dashuf.dpbs.service;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.web.req.credit.AnalysisQrCodeReq;
import com.dashuf.dpbs.app.web.req.credit.CreditAuthH5Req;
import com.dashuf.dpbs.app.web.req.credit.SubmitAuthH5Req;
import com.dashuf.dpbs.app.web.resp.QrCodeResp;
import com.dashuf.dpbs.app.web.resp.credit.AnalysisQrCodeResp;
import com.dashuf.dpbs.app.web.resp.credit.RefreshQrCodeResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.DpbsStatusCnst;
import com.dashuf.dpbs.mapper.SysConfMapper;
import com.dashuf.dpbs.model.PushOrderLog;
import com.dashuf.dpbs.model.SysConf;
import com.dashuf.dpbs.sao.defi.resp.ApplyRunEngineResp;
import com.dashuf.dpbs.sao.dsfg.CreditAuthSAO;
import com.dashuf.dpbs.service.blaze.DashufBlazeSupportService;
import com.dashuf.dpbs.service.blaze.dto.DashufBlazeDto;
import com.dashuf.dpbs.service.support.ElecSignService;
import com.dashuf.dpbs.service.support.dto.ElecCreditAuthDto;
import com.dashuf.merlin.web.base.views.ResponseVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Service
@Slf4j
public class CreditAuthSupportService {
    public static final String USER_CREDIT_AUTH = "user_credit_auth";
    private static final String SOURCE_TYPE_2 = "2";
    public static final String GET_UNIONPAY_H_5 = "get_unionpay_h5";
    public static final String RETURN_URL = "return_url";
    private static List<String> fileList = new ArrayList<String>();

    static {
        fileList.add("file1");
        fileList.add("file2");
        fileList.add("file3");
    }

    @Autowired
    private CreditAuthSAO creditAuthSAO;
    @Autowired
    private QrCodeSupportService qrCodeSupportService;
    @Autowired
    private ElecSignService elecSignService;
    @Autowired
    private DashufBlazeSupportService dashufBlazeSupportService;
    @Autowired
    private SysConfSupportService sysConfSupportService;

    public String getCreditAuthH5(CreditAuthH5Req creditAuthH5Req, JSONObject jsonObj) {
        SysConf sysConf = new SysConf();
        sysConf.setModuleCode(USER_CREDIT_AUTH);
        sysConf.setModuleSubCode(GET_UNIONPAY_H_5);
        sysConf.setModuleKey(RETURN_URL);
        String returnPageUrl = sysConfSupportService.selectValueFromCache(sysConf);
        if (StringUtils.isEmpty(returnPageUrl)) {
            jsonObj.put(DpbsCnst.RTN_MSG, "获取银联h5主界面过程未配置商户主页面");
            return null;
        }

        String merchantPageUrl = returnPageUrl + "/" + creditAuthH5Req.getPushOrderNo() + "/"
                + creditAuthH5Req.getCertNo() + "/" + creditAuthH5Req.getClientName() + "/" + creditAuthH5Req.getMobileNo();

        String creditAuthResp = creditAuthSAO.sendCreditAuth(creditAuthH5Req.getClientName(), creditAuthH5Req.getCertNo(),
                creditAuthH5Req.getMobileNo(), creditAuthH5Req.getPushOrderNo(), SOURCE_TYPE_2, DpbsCnst.SYSTEM_NAME, merchantPageUrl);
        log.error("推单号[{}]解析获取银联h5主界面结果:{}", creditAuthH5Req.getPushOrderNo(), creditAuthResp);

        if (StringUtils.isEmpty(creditAuthResp)) {
            jsonObj.put(DpbsCnst.RTN_MSG, "获取银联h5页面异常");
            return null;
        }

        try {
            JSONObject jsonRespObj = JSONObject.parseObject(creditAuthResp);
            jsonObj.put(DpbsCnst.RTN_MSG, jsonRespObj.getString("message"));
            return null;
        } catch (Exception e) {
            return creditAuthResp;
        }
    }

    private static final String QUERY_CREDIT_SUCCESS_RESULT = "0000";

    public boolean submitCreditAuth(SubmitAuthH5Req submitAuthH5Req, JSONObject jsonObj) {
        try {
            ResponseVo<String> creditAuthResp = creditAuthSAO.queryCreditAuthResult(submitAuthH5Req.getClientName(), submitAuthH5Req.getCreditAuthCode(),
                    submitAuthH5Req.getCertNo());

            if (null == creditAuthResp || !QUERY_CREDIT_SUCCESS_RESULT.equals(creditAuthResp.getCode())) {
                jsonObj.put(DpbsCnst.RTN_MSG, null == creditAuthResp ? DpbsCnst.SERVER_ERROR : creditAuthResp.getMessage());
                return false;
            }
        } catch (Exception e) {
            log.error("推送订单号[{}]提交征信码过程中异常:{}", submitAuthH5Req.getPushOrderNo(), e);
            jsonObj.put(DpbsCnst.RTN_MSG, DpbsCnst.SERVER_ERROR);
            return false;
        }

        return true;
    }


    public DashufBlazeDto validSubmitCreditAuth(SubmitAuthH5Req submitAuthH5Req, JSONObject jsonObj) {

        return dashufBlazeSupportService.gatherBlazeInfo(submitAuthH5Req.getPushOrderNo(), jsonObj);
    }

    public boolean initCreditAuthPage(String pushOrderNo, RefreshQrCodeResp refreshQrCodeResp, JSONObject jsonObj) {
        QrCodeResp qrCodeResp = qrCodeSupportService.initQrCodeResp(pushOrderNo, jsonObj);

        if (null == qrCodeResp) {
            return false;
        }

        refreshQrCodeResp.setPushOrderNo(pushOrderNo);
        BeanUtils.copyProperties(qrCodeResp, refreshQrCodeResp);
        return true;
    }

    public AnalysisQrCodeResp analysisQrCode(AnalysisQrCodeReq analysisQrCodeReq, JSONObject jsonObj) {
        return qrCodeSupportService.analysisQrCode(analysisQrCodeReq.getQrCodeInfoNo(), analysisQrCodeReq.getAnalysisType(), jsonObj);
    }

    public JSONObject signFileList(ElecCreditAuthDto elecCreditAuthDto, JSONObject jsonObj) {
        boolean rtnBoolean = true;
        JSONObject signJsonObj = new JSONObject();

        for (String signFileName : fileList) {
            elecCreditAuthDto.setModuleCode("client_credit_auth");
            elecCreditAuthDto.setModuleSubCode(signFileName);
            if (!elecSignService.elecCreditAuth(elecCreditAuthDto, jsonObj)) {
                rtnBoolean = false;
                break;
            }
            signJsonObj.put(signFileName, jsonObj.getString("authCode"));
        }

        return rtnBoolean ? signJsonObj : null;
    }

}
