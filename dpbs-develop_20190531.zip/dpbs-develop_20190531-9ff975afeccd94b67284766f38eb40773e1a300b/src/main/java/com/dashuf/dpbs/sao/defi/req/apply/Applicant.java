package com.dashuf.dpbs.sao.defi.req.apply;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class Applicant implements Serializable {
    private static final long serialVersionUID = 8315920140117006972L;

    /**
     * id	string 必须 证件号码
     */
    private String id;
    /**
     * applicatType	string 必须 申请人类型
     */
    private String applicatType;
    /**
     * officeTel	null 必须 单位电话
     */
    private String officeTel;
    /**
     * certtype	string 必须 证件类型
     */
    private String certtype;
    /**
     * cell	string 必须 手机号
     */
    private String cell;
    /**
     * customername	string 必须 姓名
     */
    private String customername;

    private String pbocReport;
}
