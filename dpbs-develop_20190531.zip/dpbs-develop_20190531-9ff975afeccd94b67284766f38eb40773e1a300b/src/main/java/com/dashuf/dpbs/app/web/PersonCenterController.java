package com.dashuf.dpbs.app.web;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.annotation.LoginRole;
import com.dashuf.dpbs.app.annotation.LoginUser;
import com.dashuf.dpbs.app.web.req.center.*;
import com.dashuf.dpbs.app.web.resp.center.GetContactMsgResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.model.UserInfo;
import com.dashuf.dpbs.service.PersonCenterSupportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dashuf.dpbs.app.DpbsUrl;
import com.dashuf.dpbs.app.web.req.user.VerifyCertReq;
import com.dashuf.dpbs.app.web.resp.center.GetPersonCenterResp;
import com.dashuf.merlin.web.base.views.ResponseVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import springfox.documentation.annotations.ApiIgnore;

@Slf4j
@RestController
@RequestMapping(DpbsUrl.PERSON_CENTER_REF)
@Api(value = "个人中心相关", tags = {"个人中心相关"})
public class PersonCenterController {
    @Autowired
    private PersonCenterSupportService personCenterSupportService;

    @ApiOperation(value = "修改手机号码")
    @PostMapping("/modifyMobileNo")
    public ResponseVo<String> modifyMobileNo(@Validated @RequestBody ModifyMobileNoReq modifyMobileNoReq, @ApiIgnore @LoginUser String loginUserNo) {
        try {
            JSONObject jsonObj = new JSONObject();

            modifyMobileNoReq.setUserNo(loginUserNo);
            if (!personCenterSupportService.modifyMobileNo(modifyMobileNoReq, jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(DpbsCnst.SUCCESS_RTN_CODE);
        } catch (Exception e) {
            log.error("用户[{}]修改手机号[{}]过程中异常:{}", loginUserNo, modifyMobileNoReq.getMobileNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "实名认证")
    @PostMapping("/verifyCert")
    public ResponseVo<String> verifyCert(@Validated @RequestBody VerifyCertReq verifyCertReq, @ApiIgnore @LoginUser String loginUserNo) {
        try {
            JSONObject jsonObj = new JSONObject();

            verifyCertReq.setUserNo(loginUserNo);
            if (!personCenterSupportService.verifyCert(verifyCertReq, jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(DpbsCnst.SUCCESS_RTN_CODE);
        } catch (Exception e) {
            log.error("用户[{}]实名认证过程中异常:{}", verifyCertReq.getUserNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "绑定客户经理")
    @PostMapping("/bindClientManager")
    public ResponseVo<String> bindClientManager(@Validated @RequestBody BindClientManagerReq bindClientManagerReq,
                                                @ApiIgnore @LoginUser String loginUserNo) {
        try {
            JSONObject jsonObj = new JSONObject();

            bindClientManagerReq.setUserNo(loginUserNo);
            if (!personCenterSupportService.bindClientManager(bindClientManagerReq, jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(DpbsCnst.SUCCESS_RTN_CODE);
        } catch (Exception e) {
            log.error("用户[{}]绑定客户经理过程中异常:{}", bindClientManagerReq.getUserNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "解绑客户经理")
    @PostMapping("/unBindClientManager")
    public ResponseVo<String> unBindClientManager(@Validated @RequestBody UnBindClientManagerReq unBindClientManagerReq,
                                                  @ApiIgnore @LoginUser String loginUserNo) {
        try {
            JSONObject jsonObj = new JSONObject();

            unBindClientManagerReq.setUserNo(loginUserNo);
            if (!personCenterSupportService.unBindClientManager(unBindClientManagerReq, jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(DpbsCnst.SUCCESS_RTN_CODE);
        } catch (Exception e) {
            log.error("用户[{}]解绑客户经理过程中异常:{}", unBindClientManagerReq.getUserNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "获取个人中心")
    @PostMapping("/getPersonCenter")
    public ResponseVo<GetPersonCenterResp> getPersonCenter(@Validated @RequestBody GetPersonCenterReq getPersonCenterReq,
                                                           @ApiIgnore @LoginUser String loginUserNo) {
        try {
            JSONObject jsonObj = new JSONObject();

            getPersonCenterReq.setUserNo(loginUserNo);
            GetPersonCenterResp getPersonCenterResp = personCenterSupportService.getPersonCenter(getPersonCenterReq, jsonObj);
            if (null == getPersonCenterResp) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(getPersonCenterResp);
        } catch (Exception e) {
            log.error("用户[{}]获取个人中心详情过程中异常:{}", getPersonCenterReq.getUserNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }


    @ApiOperation(value = "校验手机号码")
    @PostMapping("/verifyMobileNo")
    public ResponseVo<String> verifyMobileNo(@RequestBody @Validated VerifyMobileNoReq verifyMobileNoReq, @ApiIgnore @LoginUser String loginUserNo) {
        try {
            JSONObject jsonObj = new JSONObject();

            verifyMobileNoReq.setUserNo(loginUserNo);
            if (!personCenterSupportService.verifyMobileNo(verifyMobileNoReq, jsonObj)) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(DpbsCnst.SUCCESS_RTN_CODE);
        } catch (Exception e) {
            log.error("用户[{}]修改手机号[{}]校验手机号过程中异常:{}", verifyMobileNoReq.getUserNo(), verifyMobileNoReq.getMobileNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "联系我们")
    @PostMapping("/getContactMsg")
    public ResponseVo<GetContactMsgResp> getContactMsg(@Validated @RequestBody GetContactMsgReq getContactMsgReq, @ApiIgnore @LoginUser String loginUserNo) {
        try {
            JSONObject jsonObj = new JSONObject();

            getContactMsgReq.setUserNo(loginUserNo);
            GetContactMsgResp getContactMsgResp = personCenterSupportService.getContactMsg(getContactMsgReq, jsonObj);
            if (null == getContactMsgResp) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(getContactMsgResp);
        } catch (Exception e) {
            log.error("用户[{}]获取联系信息过程中异常:{}", getContactMsgReq.getUserNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "联系我们")
    @PostMapping("/getContactMsgNoLogin")
    @LoginRole
    public ResponseVo<GetContactMsgResp> getContactMsg(@Validated @RequestBody GetContactMsgReq getContactMsgReq) {
        try {
            JSONObject jsonObj = new JSONObject();

            GetContactMsgResp getContactMsgResp = personCenterSupportService.getContactMsg(getContactMsgReq, jsonObj);
            if (null == getContactMsgResp) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(getContactMsgResp);
        } catch (Exception e) {
            log.error("用户[{}]获取联系信息过程中异常:{}", getContactMsgReq.getUserNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

}
