package com.dashuf.dpbs.cnst;

public final class RtnCodeCnst {

    public static final String RTN_CODE_NEED_VERIFY_CERT = "need_verify_cert";
    public static final String RTN_CODE_NEED_BIND_CLIENT_MANAGER = "need_bind_client_manager";
    public static final String RTN_CODE_ALREADY_VERIFY_CERT = "already_verify_cert";

    public static final String RTN_CODE_LOGIN_SECRET_INCORRECT = "login_pwd_incorrect";

    public static final String RTN_CODE_LOGIN_SECRET_RETRY_EXCEED = "login_pwd_retry_exceed";


    public static final String RTN_CODE_WX_ERROR = "wx_error";

    public static final String RTN_CODE_REFRESH = "refresh";

    public static final String USER_STOP_USED = "stop_use";
    public static final String USER_FORBID_PUSH = "forbid_push";

}
