package com.dashuf.dpbs.sao.laapp.req.subscribe;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
public class CarLoan implements Serializable {
    private static final long serialVersionUID = 2188229083892397589L;

    @ApiModelProperty(value = "车贷月还款额")
    private BigDecimal monthlyRepaymentAmt;

    @ApiModelProperty(value = "车贷贷款金额")
    private BigDecimal loanAmt;
}
