package com.dashuf.dpbs.sao.defi.resp.result;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class Result implements Serializable {
    private static final long serialVersionUID = -4659710669177798869L;

    /**
     * riskLevel	string	非必须
     */
    private String riskLevel;
    /**
     * preReviewFlag	string	非必须
     */
    private String preReviewFlag;
    /**
     * riskScoreResult	string	非必须
     */
    private String riskScoreResult;
    /**
     * scoreValidDate	integer	非必须
     */
    private String scoreValidDate;
    /**
     * xScoreWanted	string	非必须
     */
    private String xScoreWanted;
    /**
     * creLoanPmt	number	非必须
     */
    private String creLoanPmt;
    /**
     * telInvestFlag	string	非必须
     */
    private String telInvestFlag;
    /**
     * calCreditAmt	number	非必须
     */
    private String calCreditAmt;
    /**
     * morLoanType	string	非必须
     */
    private String morLoanType;
    /**
     * exceptionPrompt	string	非必须
     */
    private String exceptionPrompt;
    /**
     * versionId	string	非必须
     */
    private String versionId;
    /**
     * creLoanBalance	number	非必须
     */
    private String creLoanBalance;
    /**
     * investigateFlag	string	非必须
     */
    private String investigateFlag;
    /**
     * exceptionCode	string	非必须
     */
    private String exceptionCode;
    /**
     * fiCreLoan	number	非必须
     */
    private String fiCreLoan;
    /**
     * finalResult	string	非必须
     */
    private String finalResult;

}
