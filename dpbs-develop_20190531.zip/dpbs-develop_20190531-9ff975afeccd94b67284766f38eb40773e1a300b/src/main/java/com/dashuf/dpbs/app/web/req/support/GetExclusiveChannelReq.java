package com.dashuf.dpbs.app.web.req.support;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import java.io.Serializable;

@ApiModel(value = "用户所属公司查询req")
@Getter
@Setter
public class GetExclusiveChannelReq implements Serializable {

    @ApiModelProperty(value = "用户所属公司")
    private String channelName;
}
