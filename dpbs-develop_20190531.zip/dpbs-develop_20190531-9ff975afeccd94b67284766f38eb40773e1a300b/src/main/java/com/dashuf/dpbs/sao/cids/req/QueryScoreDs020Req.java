package com.dashuf.dpbs.sao.cids.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class QueryScoreDs020Req implements Serializable {
    /**
     * systemId	string 必须  系统编号
     */
    private String systemId;
    /**
     * decisionId	string 必须 决策编号
     */
    private String decisionId;
}
