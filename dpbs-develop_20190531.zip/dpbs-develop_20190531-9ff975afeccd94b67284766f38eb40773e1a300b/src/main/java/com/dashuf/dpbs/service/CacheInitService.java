package com.dashuf.dpbs.service;

import java.util.List;
import java.util.concurrent.CopyOnWriteArrayList;

import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.DpbsSymbolCnst;
import com.dashuf.dpbs.mapper.SysConfMapper;
import com.dashuf.dpbs.model.SysConf;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;

import com.dashuf.dpbs.mapper.SysAreaInfoMapper;
import com.dashuf.dpbs.mapper.SysDictMapper;
import com.dashuf.dpbs.model.SysAreaInfo;
import com.dashuf.dpbs.model.SysDict;
import com.dashuf.dpbs.util.CacheUtil;

@Service
@Slf4j
public class CacheInitService {
    @Autowired
    private SysAreaInfoMapper sysAreaInfoMapper;
    @Autowired
    private SysDictMapper sysDictMapper;
    @Autowired
    private SysConfMapper sysConfMapper;
    @Autowired
    private StringRedisTemplate redisTemplate;

    public void initCache() {
        initSysAreaInfo();
        initSysDictInfo();
        initSysConf();
    }

    public void initSysAreaInfo() {
        CacheUtil.getSysAreaInfoList().clear();
        List<SysAreaInfo> areaList = sysAreaInfoMapper.selectByModelSelective(new SysAreaInfo(), true);
        if (CollectionUtils.isNotEmpty(areaList)) {
            CacheUtil.getSysAreaInfoList().addAll(new CopyOnWriteArrayList<SysAreaInfo>(areaList));
        }
    }

    public void initSysDictInfo() {
        CacheUtil.getSysDictList().clear();
        List<SysDict> dictList = sysDictMapper.selectByModelSelective(new SysDict(), true);
        if (CollectionUtils.isNotEmpty(dictList)) {
            CacheUtil.getSysDictList().addAll(new CopyOnWriteArrayList<SysDict>(dictList));
        }
    }

    public void initSysConf() {
        List<SysConf> sysConfList = sysConfMapper.selectSysConfList();
        if (CollectionUtils.isNotEmpty(sysConfList)) {
            sysConfList.forEach(sysConf -> {
                String redisKey = getRedisKey(sysConf);
                if (StringUtils.isNotEmpty(sysConf.getModuleVal())) {
                    redisTemplate.opsForValue().set(DpbsCnst.REDIS_DPBS_SYS_CONF + redisKey, sysConf.getModuleVal());
                    log.info("初始化缓存键[{}]值[{}]", redisKey, sysConf.getModuleVal());
                } else {
                    redisTemplate.delete(DpbsCnst.REDIS_DPBS_SYS_CONF + redisKey);
                    log.info("初始化删除缓存键[{}]值[{}]", redisKey);
                }
            });
        }
    }

    public String getRedisKey(SysConf sysConf) {
        return new StringBuilder(sysConf.getModuleCode()).append(DpbsSymbolCnst.SYMBOL_VERTICAL).append(sysConf.getModuleSubCode())
                .append(DpbsSymbolCnst.SYMBOL_VERTICAL).append(sysConf.getModuleKey()).toString();
    }

    public void updateSysConfFromRedis(SysConf sysConf) {
        String redisKey = getRedisKey(sysConf);
        redisTemplate.opsForValue().set(redisKey, sysConf.getModuleVal());
        log.info("更新缓存键[{}]值[{}]", redisKey, sysConf.getModuleVal());
    }

}
