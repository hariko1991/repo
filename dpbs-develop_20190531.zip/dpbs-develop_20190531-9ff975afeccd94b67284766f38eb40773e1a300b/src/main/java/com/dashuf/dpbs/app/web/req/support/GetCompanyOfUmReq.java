package com.dashuf.dpbs.app.web.req.support;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@ApiModel(value = "获取客户经理所属分公司")
@Getter
@Setter
public class GetCompanyOfUmReq implements Serializable {
    private static final long serialVersionUID = 5547414753803076808L;

    @ApiModelProperty(value = "客户经理编号")
    @NotBlank(message = "请输入客户经理编号")
    private String srcUmNo;
}
