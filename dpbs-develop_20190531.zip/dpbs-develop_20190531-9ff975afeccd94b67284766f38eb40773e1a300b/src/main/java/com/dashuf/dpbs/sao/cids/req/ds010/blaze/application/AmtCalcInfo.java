package com.dashuf.dpbs.sao.cids.req.ds010.blaze.application;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
public class AmtCalcInfo implements Serializable {

    private static final long serialVersionUID = 8416978654182162176L;

    private String eduDegree;
    private String educationEx;
    private String graduatetime;
    private String gwylevel;
    private BigDecimal insurancefee;
}
