package com.dashuf.dpbs.service.support;

import com.dashuf.dpbs.sao.support.req.GetFileTemplateDto;
import com.dashuf.dpbs.sao.support.req.GetFileTemplateReq;
import com.dashuf.dpbs.sao.support.resp.GetFileTemplateResp;
import com.dashuf.dpbs.sao.support.resp.GetPersonSignResp;
import com.dashuf.dpbs.service.SysConfSupportService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.SysConfCnst;
import com.dashuf.dpbs.mapper.SysConfMapper;
import com.dashuf.dpbs.model.SysConf;
import com.dashuf.dpbs.sao.support.ElecSignPlatSAO;
import com.dashuf.dpbs.sao.support.PdfTempPlatSAO;
import com.dashuf.dpbs.service.support.dto.ElecCreditAuthDto;
import com.dashuf.merlin.web.base.views.ResponseVo;

import lombok.extern.slf4j.Slf4j;

import java.util.Calendar;
import java.util.Date;

@Service
@Slf4j
public class ElecSignService {
    private static final String SUCCESS_RTN_CODE = "0000";
    private static final String MOBILE = "mobile";
    private static final String NAME = "name";
    private static final String ID_NO = "idNo";
    @Autowired
    private PdfTempPlatSAO pdfTempPlatSAO;
    @Autowired
    private ElecSignPlatSAO elecSignPlatSAO;
    @Autowired
    private SysConfSupportService sysConfSupportService;

    public boolean elecCreditAuth(ElecCreditAuthDto elecCreditAuthDto, JSONObject jsonObj) {
        log.info("签章参数信息为:{}", JSONObject.toJSONString(elecCreditAuthDto));
        // 获取数据库中的模板文件编码
        SysConf sysConf = new SysConf();
        sysConf.setModuleCode(elecCreditAuthDto.getModuleCode());
        sysConf.setModuleSubCode(elecCreditAuthDto.getModuleSubCode());
        sysConf.setModuleKey(SysConfCnst.AUTH_FILE_ID);

        String authFileId = sysConfSupportService.selectValueFromCache(sysConf);
        if (!elecCreditAuthDto.isSave()) {
            if (!getAuthFileId(elecCreditAuthDto, sysConf, jsonObj)) {
                return false;
            }
            authFileId = jsonObj.getString("authFileId");
        } else {
            if (StringUtils.isEmpty(authFileId)) {
                if (!getAuthFileId(elecCreditAuthDto, sysConf, jsonObj)) {
                    return false;
                }
                authFileId = jsonObj.getString("authFileId");
            }
        }

        JSONObject personInfo = new JSONObject();
        personInfo.put(ID_NO, elecCreditAuthDto.getCertNo());
        personInfo.put(NAME, elecCreditAuthDto.getCertName());
        personInfo.put(MOBILE, elecCreditAuthDto.getMobileNo());

        sysConf.setModuleKey(SysConfCnst.MODULE_KEY_OF_POS_BEAN);
        String posBeanJson = sysConfSupportService.selectValueFromCache(sysConf);

        if (sysConfSupportService.selectMockValFromCache(SysConfCnst.DATA_MOCK_OF_CLIENT_SIGN)) {
            jsonObj.put("authCode", "testMock");
            return true;
        }

        ResponseVo<String> responseVo = elecSignPlatSAO.personSign(authFileId, posBeanJson, DpbsCnst.SYSTEM_NAME, null,
                personInfo.toJSONString(), null, null);
        log.info("模块[{}]身份证号[{}]手机号[{}]模板平台签署结果为:{}", elecCreditAuthDto.getModuleCode() + "_" + elecCreditAuthDto.getModuleSubCode(), elecCreditAuthDto.getCertNo(), elecCreditAuthDto.getMobileNo(), JSONObject.toJSONString(responseVo));

        if ("00".equals(responseVo.getCode()) && StringUtils.isNotEmpty(responseVo.getData())) {
            JSONObject personSignObj = JSONObject.parseObject(responseVo.getData());
            jsonObj.put("authCode", personSignObj.getString("fileId"));
            return true;
        } else {
            jsonObj.put(DpbsCnst.RTN_MSG, responseVo.getMessage());
            return false;
        }

    }

    private Boolean getAuthFileId(ElecCreditAuthDto elecCreditAuthDto, SysConf sysConf, JSONObject jsonObj) {
        sysConf.setModuleKey(SysConfCnst.TEMPLATE_NO);

        GetFileTemplateReq getFileTemplateReq = new GetFileTemplateReq();
        getFileTemplateReq.setTemplateNo(sysConfSupportService.selectValueFromCache(sysConf));

        Calendar calendar = Calendar.getInstance();
        calendar.setTime(new Date());
        GetFileTemplateDto getFileTemplateDto = new GetFileTemplateDto();
        getFileTemplateDto.setYear(calendar.get(Calendar.YEAR) + "");
        getFileTemplateDto.setMonth(calendar.get(Calendar.MONTH) + 1 + "");
        getFileTemplateDto.setDay(calendar.get(Calendar.DATE) + "");
        getFileTemplateDto.setMobile(elecCreditAuthDto.getMobileNo());
        getFileTemplateDto.setIdNo(elecCreditAuthDto.getCertNo());
        getFileTemplateDto.setName(elecCreditAuthDto.getCertName());
        getFileTemplateReq.setJsonString(getFileTemplateDto);

        ResponseVo<GetFileTemplateResp> responseVo = pdfTempPlatSAO.getFileTemplate(getFileTemplateReq);

        log.info("模块[{}]模板编号[{}]调用模板平台返回结果:{}", sysConf.getModuleCode() + "_" + sysConf.getModuleSubCode(), getFileTemplateReq.getTemplateNo(), JSONObject.toJSONString(responseVo));
        if (!SUCCESS_RTN_CODE.equals(responseVo.getCode()) || null == responseVo.getData()) {
            jsonObj.put(DpbsCnst.RTN_MSG, responseVo.getMessage());
            return false;
        }

        jsonObj.put("authFileId", responseVo.getData().getFileId());

        if (elecCreditAuthDto.isSave()) {
            sysConf.setModuleKey(SysConfCnst.AUTH_FILE_ID);
            sysConf.setModuleVal(responseVo.getData().getFileId());
            int dealCnt = sysConfSupportService.updateValueForDb(sysConf);
            if (DpbsCnst.NUMBER_1 == dealCnt) {
                sysConfSupportService.updateValueFromCache(sysConf);
            }
        }
        return true;
    }
}
