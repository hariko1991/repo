package com.dashuf.dpbs.service;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.web.resp.business.BusinessProcessDetailResp;
import com.dashuf.dpbs.app.web.resp.business.ClientBaseInfoResp;
import com.dashuf.dpbs.app.web.resp.business.ProcessLog;
import com.dashuf.dpbs.cnst.*;
import com.dashuf.dpbs.mapper.ClientInfoMapper;
import com.dashuf.dpbs.mapper.PushLoanMapper;
import com.dashuf.dpbs.mapper.PushLoanProductMapper;
import com.dashuf.dpbs.model.LoanStatusMap;
import com.dashuf.dpbs.model.PushLoan;
import com.dashuf.dpbs.model.PushLoanProduct;
import com.dashuf.dpbs.model.PushOrderLog;
import com.dashuf.dpbs.sao.cids.resp.GetCreditStatusOfChargeOffDetail;
import com.dashuf.dpbs.sao.cids.resp.GetCreditStatusResp;
import com.dashuf.dpbs.sao.cpms.ClientTradingSAO;
import com.dashuf.merlin.web.base.views.ResponseVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

@Service
@Slf4j
public class BusinessSupportService {
    @Autowired
    private ClientTradingSAO clientTradingSAO;
    @Autowired
    private PushOrderLogService pushOrderLogService;
    @Autowired
    private ClientInfoMapper clientInfoMapper;
    @Autowired
    private PushLoanMapper pushLoanMapper;
    @Autowired
    private PushLoanProductMapper pushLoanProductMapper;

    private static List<String> CPMS_FINAL_STATUS_LIST = Arrays.asList(new String[]{StatusCnst.LOAN_VETO, StatusCnst.APPROVAL_VETO, StatusCnst.LOAN_SUCCESS,
            StatusCnst.CUST_WAIVE});

    private static final String CPMS_PUTOUT_PASS = "putout_pass";

    public boolean handleRespForCmps(PushOrderLog pushOrderLog, Map<String, LoanStatusMap> loanStatusMapList, JSONObject jsonObj) {
        boolean isPushResult = false;

        ResponseVo<GetCreditStatusResp> getCreditStatusResp = clientTradingSAO.pullLoanStatus(null, pushOrderLog.getPushOrderNo(), DpbsCnst.SYSTEM_NAME);
        log.info("推单号[{}]获取信贷状态返回结果:{}", pushOrderLog.getPushOrderNo(), JSON.toJSONString(getCreditStatusResp));
        if (!DpbsCnst.HTTP_OK.equals(getCreditStatusResp.getCode())) {
            return false;
        }

        GetCreditStatusResp creditStatusResp = getCreditStatusResp.getData();
        List<GetCreditStatusOfChargeOffDetail> productChargeList = creditStatusResp.getAccountList();

        PushLoan pushLoanInfo = new PushLoan();
        if (null != creditStatusResp && StringUtils.isNotEmpty(creditStatusResp.getLoanOrderId())) {
            pushLoanInfo.setPushOrderNo(creditStatusResp.getLoanOrderId());
            pushLoanInfo.setApplicationId(creditStatusResp.getApplicationId());
        } else {
            return false;
        }

        List<PushLoanProduct> pushLoanProductList = new ArrayList<>();
        BigDecimal totalPutoutAmt = new BigDecimal("0");
        PushLoan pushLoanInfoParam = new PushLoan();
        pushLoanInfo.setPushOrderNo(creditStatusResp.getLoanOrderId());
        pushLoanInfo.setApplicationId(creditStatusResp.getApplicationId());
        PushLoan pushLoanInfoAlready = pushLoanMapper.selectOneByModelSelective(pushLoanInfoParam, DpbsCnst.SQL_PRECISE_STRICT);

        LoanStatusMap loanStatusMap = loanStatusMapList.get(creditStatusResp.getLoanStatus());
        pushLoanInfo.setLoanStatus(creditStatusResp.getLoanStatus());
        pushLoanInfo.setMapStatusDesc(loanStatusMap.getMapDesc());
        if (null == pushLoanInfoAlready) {
            pushLoanMapper.insertSelective(pushLoanInfo);
        }

        if (CollectionUtils.isEmpty(productChargeList)) {
            if (DpbsCnst.FINAL_STATUS_IND_1.equals(loanStatusMap.getFinalStatusInd())) {
                pushLoanMapper.updateByModelSelective(pushLoanInfoParam, DpbsCnst.SQL_PRECISE_STRICT, pushLoanInfo);
                isPushResult = true;
            }
        } else {
            Date loanPayDate = null;
            for (int i = 0; i < productChargeList.size(); i++) {
                boolean needHandleProduct = false;
                GetCreditStatusOfChargeOffDetail productCharge = productChargeList.get(i);
                loanStatusMap = loanStatusMapList.get(productCharge.getAccountAllotCode());

                PushLoanProduct pushLoanProductParam = new PushLoanProduct();
                pushLoanProductParam.setPushOrderNo(pushOrderLog.getPushOrderNo());
                pushLoanProductParam.setProductId(productCharge.getProductId());
                PushLoanProduct pushLoanProductAlready = pushLoanProductMapper.selectOneByModelSelective(pushLoanProductParam, DpbsCnst.SQL_PRECISE_STRICT);

                if (i == 0) {
                    pushLoanInfo.setFirstProductStatus(loanStatusMap.getMapCode());
                }
                if (i == 1) {
                    pushLoanInfo.setSecondProductStatus(loanStatusMap.getMapCode());
                }

                Date payoutDate = getPayoutDateForProduct(pushOrderLog, productCharge);

                PushLoanProduct pushLoanProduct = new PushLoanProduct();
                pushLoanProduct.setPushOrderNo(pushOrderLog.getPushOrderNo());
                pushLoanProduct.setProductId(productCharge.getProductId());
                pushLoanProduct.setPutoutAmt(productCharge.getPutoutAmt());
                pushLoanProduct.setProductId(productCharge.getProductId());
                pushLoanProduct.setPutoutNo(productCharge.getAccountAllotId());
                pushLoanProduct.setPutoutDate(payoutDate);
                pushLoanProduct.setPutoutStatus(productCharge.getAccountAllotCode());

                if (null == pushLoanProductAlready) {
                    pushLoanProductMapper.insertSelective(pushLoanProduct);
                }

                //无效产品
                if (!productCharge.isAvailableInd()) {
                    pushLoanProduct.setMapStatusDesc("审批否决");
                    needHandleProduct = true;
                    log.info("推单号[{}]对应产品[{}]无效,默认为审批否决", pushOrderLog.getPushOrderNo(), productCharge.getProductId());
                } else {
                    log.info("推单号[{}]对应产品[{}]状态[{}]映射状态为[{}]", pushOrderLog.getPushOrderNo(), productCharge.getProductId(), productCharge.getAccountAllotCode(), loanStatusMap.getMapDesc());
                    if (DpbsCnst.FINAL_STATUS_IND_1.equals(loanStatusMap.getFinalStatusInd())) {
                        pushLoanProduct.setMapStatusDesc(loanStatusMap.getMapDesc());
                        needHandleProduct = true;
                    }
                }

                if (needHandleProduct) {
                    log.info("推单号[{}]对应产品[{}]不存在,需要操作", pushOrderLog.getPushOrderNo(), productCharge.getProductId());
                    if (StatusCnst.LOAN_SUCCESS.equals(loanStatusMap.getMapCode())) {
                        totalPutoutAmt = totalPutoutAmt.add(productCharge.getPutoutAmt());
                        loanPayDate = payoutDate;
                    }
                    pushLoanProductList.add(pushLoanProduct);
                    pushLoanProductMapper.updateByModelSelective(pushLoanProductParam, DpbsCnst.SQL_PRECISE_STRICT, pushLoanProduct);
                }
            }

            pushLoanInfo.setLoanPayAmt(totalPutoutAmt);
            pushLoanInfo.setLoanPayTime(loanPayDate);

            fullPushLoanInfo(productChargeList.size(), pushLoanInfo);

            //只处理处于终态的产品,不是终态的无需处理
            log.info("推单号[{}]需要处理对应产品个数为:[{}]", pushOrderLog.getPushOrderNo(), pushLoanProductList.size());
            if (CollectionUtils.isNotEmpty(pushLoanProductList)) {
                pushLoanMapper.updateByModelSelective(pushLoanInfoParam, DpbsCnst.SQL_PRECISE_STRICT, pushLoanInfo);
            }

            if (CPMS_FINAL_STATUS_LIST.contains(pushLoanInfo.getFirstProductStatus()) && CPMS_FINAL_STATUS_LIST.contains(pushLoanInfo.getSecondProductStatus())) {
                isPushResult = true;
            }
        }

        if (isPushResult) {
            PushOrderLog pushOrderLogParam = new PushOrderLog();
            pushOrderLogParam.setPushOrderNo(pushOrderLog.getPushOrderNo());
            pushOrderLogParam.setPushStatus(DpbsStatusCnst.PUSH_SUCCESS);
            pushOrderLogService.updatePushOrderLogByOrgStatus(pushOrderLogParam, pushOrderLog.getPushStatus(), jsonObj);
        }

        return true;
    }

    private void fullPushLoanInfo(int productCount, PushLoan pushLoanInfo) {
        if (productCount == 2) {
            if (StatusCnst.LOAN_VETO.equals(pushLoanInfo.getFirstProductStatus()) && StatusCnst.LOAN_VETO.equals(pushLoanInfo.getSecondProductStatus())) {
                //若在大数面签至审批审计阶段被否决或两个产品均被放款否决，则显示否决阶段，若被大数否决则显示“审批否决“，若为放款否决则显示”合作机构否决”。
                pushLoanInfo.setMapStatusDesc("合作机构否决");
            } else if (StatusCnst.APPROVAL_VETO.equals(pushLoanInfo.getFirstProductStatus()) && StatusCnst.APPROVAL_VETO.equals(pushLoanInfo.getSecondProductStatus())) {
                //两个有一个放款成功则显示放款成功
                pushLoanInfo.setMapStatusDesc("审批否决");
            } else if (StatusCnst.LOAN_SUCCESS.equals(pushLoanInfo.getFirstProductStatus()) || StatusCnst.LOAN_SUCCESS.equals(pushLoanInfo.getSecondProductStatus())) {
                //两个有一个放款成功则显示放款成功
                pushLoanInfo.setMapStatusDesc("放款成功");
            } else if (StatusCnst.CUST_WAIVE.equals(pushLoanInfo.getFirstProductStatus()) && StatusCnst.CUST_WAIVE.equals(pushLoanInfo.getSecondProductStatus())) {
                //两个都是客户放弃则显示为客户放弃
                pushLoanInfo.setMapStatusDesc("客户放弃");
            }
        }

        if (productCount == 1) {
            if (StatusCnst.LOAN_VETO.equals(pushLoanInfo.getFirstProductStatus())) {
                //若在大数面签至审批审计阶段被否决或两个产品均被放款否决，则显示否决阶段，若被大数否决则显示“审批否决“，若为放款否决则显示”合作机构否决”。
                pushLoanInfo.setMapStatusDesc("合作机构否决");
            } else if (StatusCnst.APPROVAL_VETO.equals(pushLoanInfo.getFirstProductStatus())) {
                //两个有一个放款成功则显示放款成功
                pushLoanInfo.setMapStatusDesc("审批否决");
            } else if (StatusCnst.LOAN_SUCCESS.equals(pushLoanInfo.getFirstProductStatus())) {
                //两个有一个放款成功则显示放款成功
                pushLoanInfo.setMapStatusDesc("放款成功");
            } else if (StatusCnst.CUST_WAIVE.equals(pushLoanInfo.getFirstProductStatus())) {
                //两个都是客户放弃则显示为客户放弃
                pushLoanInfo.setMapStatusDesc("客户放弃");
            }
        }
    }

    private Date getPayoutDateForProduct(PushOrderLog pushOrderLog, GetCreditStatusOfChargeOffDetail productCharge) {
        Date payoutDate = new Date();

        if (CPMS_PUTOUT_PASS.equals(productCharge.getAccountAllotCode())) {
            try {
                if (StringUtils.isNotEmpty(productCharge.getPutoutDate())) {
                    return DateUtils.parseDate(productCharge.getPutoutDate(), DpbsSymbolCnst.YYYY_MM_DD_HH_MM_SS);
                }
            } catch (Exception e) {
                log.error("推单号[{}]产品[{}]放款日期为[{}]格式化失败", pushOrderLog.getPushOrderNo(), productCharge.getProductId(), productCharge.getPutoutDate());
            }
            return payoutDate;
        }

        return null;
    }

    public BusinessProcessDetailResp getBusinessDetail(String pushOrderNo, JSONObject jsonObj) {
        BusinessProcessDetailResp businessProcessDetailResp = new BusinessProcessDetailResp();

        //推单信息
        PushOrderLog pushOrderLogParam = new PushOrderLog();
        pushOrderLogParam.setPushOrderNo(pushOrderNo);
        PushOrderLog pushOrderLog = pushOrderLogService.selectOneByModelSelective(pushOrderLogParam, DpbsCnst.SQL_PRECISE_STRICT);
        if (null == pushOrderLog) {
            return null;
        }
        //客户信息
        ClientBaseInfoResp clientBaseInfoResp = clientInfoMapper.getClientBaseInfo(pushOrderNo);
        if (null == clientBaseInfoResp) {
            return null;
        }
        businessProcessDetailResp.setClientName(clientBaseInfoResp.getClientName());
        businessProcessDetailResp.setMobileNo(clientBaseInfoResp.getMobileNo());
        businessProcessDetailResp.setPushOrderNo(pushOrderNo);
        businessProcessDetailResp.setClientNo(clientBaseInfoResp.getClientNo());
        businessProcessDetailResp.setReconDate(clientBaseInfoResp.getReconDate());
        businessProcessDetailResp.setCertNo(clientBaseInfoResp.getCertNo());
        //变量定义
        List<ProcessLog> localProcessLog = new ArrayList<>();
        List<ProcessLog> firstProduct = new ArrayList<>();
        List<ProcessLog> secondProduct = new ArrayList<>();
        ProcessLog initProcessLog = new ProcessLog();
        ProcessLog commitProcessLog = new ProcessLog();
        ProcessLog evalingProcessLog = new ProcessLog();
        ProcessLog evalSuccessProcessLog = new ProcessLog();
        ProcessLog approvalProcessLog = new ProcessLog();

        PushLoan pushLoanInfoParam = new PushLoan();
        pushLoanInfoParam.setPushOrderNo(pushOrderLog.getPushOrderNo());
        PushLoan pushLoanInfo = pushLoanMapper.selectOneByModelSelective(pushLoanInfoParam, DpbsCnst.SQL_PRECISE_STRICT);
        switch (pushOrderLog.getPushStatus()) {
            //推单中(返回英文状态，前端需将这四种状态聚合成"正在推单中"，其他状态不需要)
            case DpbsStatusCnst.PUSH_INIT:
            case DpbsStatusCnst.PUSH_SCAN:
            case DpbsStatusCnst.PUSH_MOVIE:
            case DpbsStatusCnst.PUSH_ENTRY:
                //未完成阶段
                initProcessLog.setOrderStatus(pushOrderLog.getPushStatus());
                initProcessLog.setProcessDate(pushOrderLog.getPushStartTime());
                localProcessLog.add(initProcessLog);
                break;
            //提交成功
            case DpbsStatusCnst.PUSH_CREDIT:
                commitProcessLog.setOrderStatus("提交成功");
                commitProcessLog.setProcessDate(pushOrderLog.getPushEndTime());
                localProcessLog.add(commitProcessLog);
                break;
            //初评中
            case DpbsStatusCnst.PUSH_EVAL_ING:
                //提交成功
                commitProcessLog.setOrderStatus("提交成功");
                commitProcessLog.setProcessDate(pushOrderLog.getPushEndTime());
                localProcessLog.add(commitProcessLog);
                //初评中
                evalingProcessLog.setOrderStatus("初评中");
                evalingProcessLog.setProcessDate(pushOrderLog.getEvalStartTime());
                localProcessLog.add(evalingProcessLog);
                break;
            case DpbsStatusCnst.PUSH_EVAL_FAIL:
                //提交成功
                commitProcessLog.setOrderStatus("提交成功");
                commitProcessLog.setProcessDate(pushOrderLog.getPushEndTime());
                localProcessLog.add(commitProcessLog);
                //初评中
                evalingProcessLog.setOrderStatus("初评不通过");
                evalingProcessLog.setProcessDate(pushOrderLog.getUpdatedDate());
                localProcessLog.add(evalingProcessLog);
                break;
            case DpbsStatusCnst.PUSH_FAIL:
                //提交成功
                commitProcessLog.setOrderStatus("提交成功");
                commitProcessLog.setProcessDate(pushOrderLog.getPushEndTime());
                localProcessLog.add(commitProcessLog);
                //初评中
                evalingProcessLog.setOrderStatus("推单失败");
                evalingProcessLog.setProcessDate(pushOrderLog.getUpdatedDate());
                localProcessLog.add(evalingProcessLog);
                break;
            //初评通过
            case DpbsStatusCnst.PUSH_EVAL_SUCCESS:
                commitProcessLog.setOrderStatus("提交成功");
                commitProcessLog.setProcessDate(pushOrderLog.getPushEndTime());
                localProcessLog.add(commitProcessLog);

                evalSuccessProcessLog.setOrderStatus("初评通过");
                evalSuccessProcessLog.setProcessDate(pushOrderLog.getEvalEndTime());
                localProcessLog.add(evalSuccessProcessLog);
                break;
            case DpbsStatusCnst.PUSH_CLIENT_SUCCESS:
            case DpbsStatusCnst.PUSH_SUCCESS:
                commitProcessLog.setOrderStatus("提交成功");
                commitProcessLog.setProcessDate(pushOrderLog.getPushEndTime());
                localProcessLog.add(commitProcessLog);

                evalSuccessProcessLog.setOrderStatus("初评通过");
                evalSuccessProcessLog.setProcessDate(pushOrderLog.getEvalEndTime());
                localProcessLog.add(evalSuccessProcessLog);

                if (null == pushLoanInfo) {
                    approvalProcessLog.setOrderStatus("审批中");
                    approvalProcessLog.setProcessDate(pushOrderLog.getPushClientTime());
                    localProcessLog.add(approvalProcessLog);
                } else {
                    PushLoanProduct pushLoanProductParam = new PushLoanProduct();
                    pushLoanProductParam.setPushOrderNo(pushOrderNo);
                    List<PushLoanProduct> pushLoanProductList = pushLoanProductMapper.selectByModelSelective(pushLoanProductParam, DpbsCnst.SQL_PRECISE_STRICT);
                    //有一个或两个产品到出账流程
                    if (CollectionUtils.isNotEmpty(pushLoanProductList)) {
                        for (int i = 0; i < pushLoanProductList.size(); i++) {
                            PushLoanProduct pushLoanProduct = pushLoanProductList.get(i);

                            ProcessLog loanProcess = new ProcessLog();
                            loanProcess.setOrderStatus(StringUtils.isEmpty(pushLoanProduct.getMapStatusDesc()) ? "审批中" : pushLoanProduct.getMapStatusDesc());
                            loanProcess.setProcessDate(null == pushLoanProduct.getPutoutDate() ? pushOrderLog.getPushClientTime() : pushLoanProduct.getPutoutDate());

                            if (i == 0) {
                                firstProduct.add(loanProcess);
                            }
                            if (i == 1) {
                                secondProduct.add(loanProcess);
                            }

                        }
                    } else {
                        approvalProcessLog.setOrderStatus(StringUtils.isEmpty(pushLoanInfo.getMapStatusDesc()) ? "审批中" : pushLoanInfo.getMapStatusDesc());
                        approvalProcessLog.setProcessDate(null == pushLoanInfo.getLoanTime() ? pushOrderLog.getPushClientTime() : pushLoanInfo.getLoanTime());
                        localProcessLog.add(approvalProcessLog);
                    }
                }
                break;

            default:
                return businessProcessDetailResp;
        }


        if (null != pushLoanInfo && StringUtils.isNotEmpty(pushLoanInfo.getMapStatusDesc())) {
            businessProcessDetailResp.setRejectProcess(pushLoanInfo.getMapStatusDesc());
        }

        if (null != pushLoanInfo && null != pushLoanInfo.getLoanPayAmt()) {
            businessProcessDetailResp.setLoanAmt(pushLoanInfo.getLoanPayAmt());
        }

        if (null != pushLoanInfo && null != pushLoanInfo.getLoanPayTime()) {
            businessProcessDetailResp.setLoanPayDate(pushLoanInfo.getLoanPayTime());
        }

        //如果出账金额大于0表示有放款成功
        businessProcessDetailResp.setProductFirst(firstProduct);
        businessProcessDetailResp.setProductSecond(secondProduct);
        businessProcessDetailResp.setLocalProcess(localProcessLog);
        return businessProcessDetailResp;
    }

}
