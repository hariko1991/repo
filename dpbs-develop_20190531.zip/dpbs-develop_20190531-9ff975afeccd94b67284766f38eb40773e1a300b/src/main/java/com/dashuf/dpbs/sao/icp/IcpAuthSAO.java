package com.dashuf.dpbs.sao.icp;

import com.dashuf.dpbs.sao.icp.req.CheckIDCardReq;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * , url = "http://10.21.0.23:8250" sit
 * , url = "http://10.22.0.123:8250" uat
 */
@FeignClient(name = "PM-RequestRedirect")
public interface IcpAuthSAO {

    @RequestMapping(value = "/IdentityConfirmPlatform/api/checkPersonMsg.do", method = RequestMethod.POST)
    String checkPersonMsg(@RequestBody CheckIDCardReq checkIDCardReq);
}

