package com.dashuf.dpbs.app.web.resp.business;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

/**
 * @author yaojiaoyi
 */
@ApiModel("推荐列表")
@Getter
@Setter
public class BusinessProcessDetailResp {

    @ApiModelProperty("推送订单编号")
    private String pushOrderNo;

    @ApiModelProperty(value = "客户姓名")
    private String clientName;

    @ApiModelProperty(value = "客户编号")
    private String clientNo;

    @ApiModelProperty("身份证号")
    private String certNo;

    @ApiModelProperty(value = "客户手机号")
    private String mobileNo;

    @ApiModelProperty(value = "推荐时间")
    private Date reconDate;

    @ApiModelProperty("放款金额")
    private BigDecimal loanAmt;

    @ApiModelProperty("放款否决原因：大数否决or机构否决")
    private String rejectProcess;

    @ApiModelProperty("放款时间")
    @DateTimeFormat(pattern = "yyyy-MM-dd HH:mm:ss")
    @JsonFormat(timezone = "GMT+8", pattern = "yyyy-MM-dd HH:mm:ss")
    private Date loanPayDate;

    @ApiModelProperty("本地状态：开始推单、提交成功、初评")
    private List<ProcessLog> localProcess;

    @ApiModelProperty(value = "产品1信贷状态流转")
    private List<ProcessLog> productFirst;

    @ApiModelProperty(value = "产品2信贷状态流转")
    private List<ProcessLog> productSecond;
}
