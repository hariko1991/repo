package com.dashuf.dpbs.service.support;

import com.dashuf.dpbs.cnst.*;
import com.dashuf.dpbs.model.QrCodeInfo;
import com.dashuf.dpbs.sao.wx.DswxApiSAO;
import com.dashuf.dpbs.sao.wx.WxQrCodeSAO;
import com.dashuf.dpbs.sao.wx.req.ActionInfo;
import com.dashuf.dpbs.sao.wx.req.GetDashuQrTicketReq;
import com.dashuf.dpbs.sao.wx.req.GetQrTicketReq;
import com.dashuf.dpbs.sao.wx.req.Scene;
import com.dashuf.dpbs.service.SysConfSupportService;
import com.netflix.discovery.converters.Auto;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.connection.jedis.JedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;
import org.springframework.data.redis.support.atomic.RedisAtomicLong;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.sao.wx.WxApiSao;

import lombok.extern.slf4j.Slf4j;

import java.util.concurrent.TimeUnit;

@Service
@Slf4j
public class WxSupportService {
    private static final String OPEN_ID = "openid";
    private static final String ERR_CODE = "errcode";
    private static final String ERR_MSG = "errmsg";
    private static final String SUCCESS_ERR_CODE = "0000";
    public static final String QR_STR_SCENE = "QR_STR_SCENE";
    public static final String QR_EVENT_CREDIT_AUTHORIZATION = "CreditAuthorization_";
    private static final String REDIS_WX_ACCESS_TOKEN_KEY = "DPBS_WX_ACCESS_TOKEN";

    @Value("${we.chat.app.id}")
    private String appId;
    @Value("${we.chat.app.secret}")
    private String appSecret;
    @Autowired
    private WxApiSao wxApiSao;
    @Autowired
    private WxQrCodeSAO wxQrCodeSAO;
    private String qrAppId;
    private String qrAppSecret;
    @Autowired
    private RedisAtomicInteger redisDistributeLock;
    @Autowired
    private StringRedisTemplate redisTemplateAccessToken;
    @Autowired
    private DswxApiSAO dswxApiSAO;
    @Autowired
    private SysConfSupportService sysConfSupportService;

    public String getOpenId(String userNo, String wxCode, JSONObject jsonObj) {
        try {
            String rtnStr = wxApiSao.getOpenId(appId, appSecret, wxCode);
            log.info("根据微信授权码[{}],查找用户[{}]的openId信息结果[{}]", wxCode, userNo, rtnStr);

            if (StringUtils.isNotEmpty(rtnStr)) {
                JSONObject rtnJsonObj = JSONObject.parseObject(rtnStr);

                String openId = rtnJsonObj.getString(OPEN_ID);
                if (StringUtils.isNotEmpty(openId)) {
                    return openId;
                }
                jsonObj.put(DpbsCnst.RTN_MSG, "微信返回内容有误:" + rtnStr);
                return null;
            } else {
                jsonObj.put(DpbsCnst.RTN_MSG, "微信返回内容有误:" + rtnStr);
                return null;
            }
        } catch (Exception e) {
            log.error("根据微信授权码[{}],查找用户[{}]的openId信息结果过程中异常:{}", wxCode, userNo, e);
            return null;
        }
    }

    public String authThirdPartyLogin(String thirdPartyType, String thirdPartyCode, JSONObject jsonObj) {
        try {
            String rtnStr = wxApiSao.getOpenId(appId, appSecret, thirdPartyCode);
            log.info("根据第三方[{}]授权码[{}]查找信息结果[{}]", thirdPartyType, thirdPartyCode, rtnStr);

            if (StringUtils.isNotEmpty(rtnStr)) {
                JSONObject rtnJsonObj = JSONObject.parseObject(rtnStr);

                String openId = rtnJsonObj.getString(OPEN_ID);
                if (StringUtils.isNotEmpty(openId)) {
                    return openId;
                }
                jsonObj.put(DpbsCnst.RTN_MSG, "微信返回内容有误:" + rtnStr);
                return null;
            } else {
                jsonObj.put(DpbsCnst.RTN_MSG, "微信返回内容有误:" + rtnStr);
                return null;
            }
        } catch (Exception e) {
            jsonObj.put(DpbsCnst.RTN_MSG, e.getMessage());
            log.error("根据第三方[{}]授权码[{}]查找信息结果过程中异常:{}", thirdPartyType, thirdPartyCode, e);
            return null;
        }
    }

    public String getQrCodeUrl(QrCodeInfo qrCodeInfo, JSONObject jsonObj) {
        GetDashuQrTicketReq getDashuQrTicketReq = new GetDashuQrTicketReq();
        getDashuQrTicketReq.setSceneStr(QR_EVENT_CREDIT_AUTHORIZATION + qrCodeInfo.getQrNo() + "_" + qrCodeInfo.getCertNo());
        getDashuQrTicketReq.setExpireSeconds(sysConfSupportService.selectValueFromCache(SysConfCnst.MODULE_CODE_OF_USER_CREDIT_AUTH, SysConfCnst.MODULE_SUB_CODE_OF_GET_QR_CODE, SysConfCnst.MODULE_KEY_OF_EXPIRE_SECOND));

        String replayInfo = sysConfSupportService.selectValueFromCache(SysConfCnst.MODULE_CODE_OF_USER_CREDIT_AUTH, SysConfCnst.MODULE_SUB_CODE_OF_GET_QR_CODE, SysConfCnst.MODULE_KEY_OF_LINK_VERIFY_URL);
        replayInfo = String.format(replayInfo, qrCodeInfo.getQrNo());
        getDashuQrTicketReq.setReplyInfo(String.format(DashufBlazeCnst.CREDIT_QR_CODE_URL, replayInfo));

        log.info("推送订单[{}]生成二维码的请求参数为:{}", qrCodeInfo.getPushOrderNo(), JSONObject.toJSONString(getDashuQrTicketReq));
        String rtnStr = dswxApiSAO.getQrTicket(getDashuQrTicketReq);
        log.info("推送订单号[{}]生成二维码期间获取访问ticket结果为:{}", qrCodeInfo.getPushOrderNo(), rtnStr);

        if (StringUtils.isNotEmpty(rtnStr)) {
            JSONObject ticketJsonObj = JSONObject.parseObject(rtnStr);
            String ticket = ticketJsonObj.getString("data");
            if (!SUCCESS_ERR_CODE.equals(ticketJsonObj.getString("code")) || StringUtils.isEmpty(ticket)) {
                jsonObj.put(DpbsCnst.RTN_CODE, RtnCodeCnst.RTN_CODE_REFRESH);
                jsonObj.put(DpbsCnst.RTN_MSG, "获取ticket内容有误:" + rtnStr);
                return null;
            }
            return ticket;
        } else {
            jsonObj.put(DpbsCnst.RTN_CODE, RtnCodeCnst.RTN_CODE_REFRESH);
            jsonObj.put(DpbsCnst.RTN_MSG, "获取ticket内容有误:" + rtnStr);
            return null;
        }
    }

    public String getQrCodeUrl(String pushOrderNo, QrCodeInfo qrCodeInfo, JSONObject jsonObj) {
        String accessToken = redisTemplateAccessToken.opsForValue().get(DpbsCnst.REDIS_DPBS_LOCK + REDIS_WX_ACCESS_TOKEN_KEY);
        log.info("推送订单号[{}],获取缓存中的授权accessToken为[{}]", pushOrderNo, accessToken);
        if (StringUtils.isEmpty(accessToken)) {
            accessToken = getNewAccessToken(pushOrderNo, jsonObj);
            if (StringUtils.isEmpty(accessToken)) {
                return null;
            }
        }

        GetQrTicketReq getQrTicketReq = new GetQrTicketReq();
        getQrTicketReq.setExpire_seconds(36000l);
        getQrTicketReq.setAction_name(QR_STR_SCENE);
        ActionInfo actionInfo = new ActionInfo();
        Scene scene = new Scene();
        scene.setScene_str(QR_EVENT_CREDIT_AUTHORIZATION + qrCodeInfo.getQrNo() + "_" + qrCodeInfo.getCertNo());
        actionInfo.setScene(scene);
        getQrTicketReq.setAction_info(actionInfo);
        log.info("推送订单[{}]生成二维码的请求参数为:{}", pushOrderNo, JSONObject.toJSONString(getQrTicketReq));
        String rtnStr = wxQrCodeSAO.getQrTicket(accessToken, getQrTicketReq);
        log.info("推送订单号[{}]生成二维码期间获取访问ticket结果为:{}", pushOrderNo, rtnStr);
        if (StringUtils.isNotEmpty(rtnStr)) {
            JSONObject ticketJsonObj = JSONObject.parseObject(rtnStr);
            String ticket = ticketJsonObj.getString("ticket");
            if (StringUtils.isEmpty(ticket)) {
                redisTemplateAccessToken.delete(DpbsCnst.REDIS_DPBS_LOCK + REDIS_WX_ACCESS_TOKEN_KEY);
                jsonObj.put(DpbsCnst.RTN_CODE, RtnCodeCnst.RTN_CODE_REFRESH);
                jsonObj.put(DpbsCnst.RTN_MSG, "微信获取ticket内容有误:" + rtnStr);
                return null;
            }
            return ticket;
        } else {
            jsonObj.put(DpbsCnst.RTN_CODE, DpbsCnst.FAIL_RTN_CODE);
            jsonObj.put(DpbsCnst.RTN_MSG, "微信获取ticket内容有误:" + rtnStr);
            return null;
        }
    }

    private String getNewAccessToken(String pushOrderNo, JSONObject jsonObj) {
        String accessToken;
        try {
            if (redisDistributeLock.compareAndSet(0, 1)) {
                String rtnStr = wxQrCodeSAO.getAccessToken(qrAppId, qrAppSecret);
                log.info("推送订单号[{}]生成二维码期间获取访问token结果为:{}", pushOrderNo, rtnStr);

                JSONObject tokenJsonObj = JSONObject.parseObject(rtnStr);
                accessToken = tokenJsonObj.getString("access_token");
                if (StringUtils.isNotEmpty(accessToken)) {
                    redisTemplateAccessToken.opsForValue().set(DpbsCnst.REDIS_DPBS_LOCK + REDIS_WX_ACCESS_TOKEN_KEY, accessToken, 60, TimeUnit.MINUTES);
                } else {
                    jsonObj.put(DpbsCnst.RTN_CODE, RtnCodeCnst.RTN_CODE_REFRESH);
                    jsonObj.put(DpbsCnst.RTN_MSG, "微信获取access_token内容有误:" + rtnStr);
                    return null;
                }
            } else {
                jsonObj.put(DpbsCnst.RTN_CODE, RtnCodeCnst.RTN_CODE_REFRESH);
                jsonObj.put(DpbsCnst.RTN_MSG, "因为锁抢占,请刷新");
                return null;
            }
        } catch (Exception e) {
            log.error("推送订单号[{}],更新缓存中的accessToken过程中异常:{}", pushOrderNo, e);
            jsonObj.put(DpbsCnst.RTN_CODE, RtnCodeCnst.RTN_CODE_REFRESH);
            jsonObj.put(DpbsCnst.RTN_MSG, e.getMessage());
            return null;
        } finally {
            redisDistributeLock.set(0);
        }
        return accessToken;
    }


}
