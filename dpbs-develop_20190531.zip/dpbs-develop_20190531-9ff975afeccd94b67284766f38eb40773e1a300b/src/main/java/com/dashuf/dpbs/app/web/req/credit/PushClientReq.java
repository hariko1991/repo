package com.dashuf.dpbs.app.web.req.credit;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@ApiModel(value = "推送客户Req")
@Getter
@Setter
public class PushClientReq implements Serializable {
    private static final long serialVersionUID = 6653710326688809949L;

    @ApiModelProperty(value = "推送订单编号", required = true)
    @NotBlank(message = "推送订单编号不能为空")
    private String pushOrderNo;
}
