package com.dashuf.dpbs.service.blaze.dto;

import com.dashuf.dpbs.model.*;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@Setter
@Getter
public class DashufBlazeDto implements Serializable {
    private static final long serialVersionUID = -1647626054136663536L;

    private PushOrderLog pushOrderLog;

    private InfoEntry infoEntry;

    private ClientInfo clientInfo;

    private List<InsuranceInfo> insuranceList;

    private List<HouseInfo> houseInfoList;

    private List<CreditSupplyInfo> creditSupplyInfoList;

    private UserInfo userInfo;
}
