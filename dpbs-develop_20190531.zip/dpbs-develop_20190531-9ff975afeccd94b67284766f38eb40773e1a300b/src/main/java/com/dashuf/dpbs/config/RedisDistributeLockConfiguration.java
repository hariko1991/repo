package com.dashuf.dpbs.config;

import com.dashuf.dpbs.cnst.DpbsCnst;
import org.springframework.boot.autoconfigure.AutoConfigureAfter;
import org.springframework.boot.autoconfigure.condition.ConditionalOnMissingBean;
import org.springframework.boot.autoconfigure.data.redis.RedisAutoConfiguration;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.serializer.GenericToStringSerializer;
import org.springframework.data.redis.serializer.StringRedisSerializer;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;

import java.net.UnknownHostException;

@Configuration
@AutoConfigureAfter(RedisAutoConfiguration.class)
public class RedisDistributeLockConfiguration {

    private static final String REDIS_WX_ACCESS_TOKEN_KEY_LOCK = "DPBS_WX_ACCESS_TOKEN_LOCK";

    @Bean("redisTemplateForDistributeLock")
    @ConditionalOnMissingBean(name = "redisTemplateForDistributeLock")
    public RedisTemplate<String, Integer> redisTemplate(
            RedisConnectionFactory redisConnectionFactory) throws UnknownHostException {
        RedisTemplate<String, Integer> template = new RedisTemplate<>();
        template.setConnectionFactory(redisConnectionFactory);
        return template;
    }

    @Bean("redisDistributeLock")
    public RedisAtomicInteger redisDistributeLock(RedisTemplate<String, Integer> redisTemplateForDistributeLock) {
        redisTemplateForDistributeLock.setKeySerializer(new StringRedisSerializer());
        redisTemplateForDistributeLock.setHashKeySerializer(new StringRedisSerializer());
        redisTemplateForDistributeLock.setValueSerializer(new GenericToStringSerializer<>(Integer.class));

        return new RedisAtomicInteger(DpbsCnst.REDIS_DPBS_LOCK + REDIS_WX_ACCESS_TOKEN_KEY_LOCK, redisTemplateForDistributeLock, 0);
    }
}
