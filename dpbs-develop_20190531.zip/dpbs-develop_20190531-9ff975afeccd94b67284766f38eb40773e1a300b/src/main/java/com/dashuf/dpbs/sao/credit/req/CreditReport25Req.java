package com.dashuf.dpbs.sao.credit.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class CreditReport25Req implements Serializable {
    /**
     * 证件类型，目前只支持身份证，默认为1
     */
    @JsonProperty(value = "CERTTYPE")
    private String certType = "1";
    /**
     * 证件号码
     */
    @JsonProperty(value = "CERTID")
    private String certId;
    /**
     * 客户姓名
     */
    @JsonProperty(value = "CUSTOMERNAME")
    private String customerName;
    /**
     * 渠道
     */
    @JsonProperty(value = "CHANNEL")
    private String channel;
    /**
     * 合作机构
     */
    @JsonProperty(value = "ORGID")
    private String orgId;
    /**
     * 贷后标识 贷前：0 (默认) 贷后：1
     */
    @JsonProperty(value = "LOANALTER")
    private String loanAlter;

}
