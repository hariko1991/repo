package com.dashuf.dpbs.sao.defi.req.apply;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
public class AmtCalcInfo implements Serializable {
    private static final long serialVersionUID = 8091682244201474685L;

    /**
     * CreditcardInCarLoan	string 非必须 信用卡分期车贷月还款额
     */
    private BigDecimal creditcardInCarLoan;
    /**
     * OriLoanAmt	string 非必须 原贷款金额
     */
    @JsonProperty(value = "OriLoanAmt")
    private BigDecimal oriLoanAmt;
    /**
     * OriLoanDate	string 非必须 原贷款发放日期
     */
    @JsonProperty(value = "OriLoanDate")
    private Date oriLoanDate;
}
