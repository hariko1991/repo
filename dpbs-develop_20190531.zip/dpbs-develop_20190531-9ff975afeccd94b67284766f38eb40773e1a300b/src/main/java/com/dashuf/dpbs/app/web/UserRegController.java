package com.dashuf.dpbs.app.web;

import com.dashuf.dpbs.cnst.DpbsHeadCnst;
import com.dashuf.dpbs.service.UserInfoSupportService;
import com.dashuf.dpbs.app.annotation.LoginRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.DpbsUrl;
import com.dashuf.dpbs.app.web.req.user.RegReq;
import com.dashuf.dpbs.app.web.resp.user.LoginResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.merlin.web.base.views.ResponseVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Api(value = "用户注册相关", tags = {"用户注册相关"})
@Slf4j
@RestController
@RequestMapping(DpbsUrl.USER_REG_REF)
public class UserRegController {
    @Autowired
    private UserInfoSupportService userInfoSupportService;

    @ApiOperation(value = "用户注册")
    @PostMapping("/regUser")
    @LoginRole(need = true)
    public ResponseVo<LoginResp> regUser(HttpServletRequest request, HttpServletResponse response, @RequestBody @Validated RegReq regReq) {
        try {
            JSONObject jsonObj = new JSONObject();
            LoginResp loginResp = userInfoSupportService.regUser(regReq, jsonObj);
            if (null == loginResp) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }

            userInfoSupportService.initAccessTokenForUser(request, response, loginResp.getUserNo());
            return new ResponseVo<>(loginResp);
        } catch (Exception e) {
            log.error("手机号[{}]注册过程中异常:{}", regReq.getMobileNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }
}
