package com.dashuf.dpbs.sao.defi.resp.apply;

import com.dashuf.dpbs.sao.defi.resp.result.RuleDecision;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

@Getter
@Setter
public class Decision implements Serializable {
    private static final long serialVersionUID = 8556840594075557023L;
    @JsonProperty(value = "VersionID")
    private String versionId;
    @JsonProperty(value = "SpecialFlag")
    private String specialFlag;

    /**
     * riskScoreResult	string	非必须	风险评分决策结果：P-通过 D-拒绝
     */
    private String riskScoreResult;
    /**
     * finalResult	string	非必须		最终决策结果 P-通过 D-拒绝 R-人工审批
     */
    private String finalResult;
    /**
     * 最高授信额度
     */
    private BigDecimal maxCalCreditAmt;
    /**
     * 大数已授信贷款余额
     */
    private BigDecimal creLoanBalance;
    /**
     * riskLevel	string	非必须	风险等级
     */
    private String riskLevel;
    /**
     * preReviewFlag	string	非必须	是否审核
     */
    private String preReviewFlag;

    /**
     * xScoreWanted	string	非必须	是否查询X评分 1：查询，0：不查询
     */
    private String xScoreWanted;
    /**
     * creLoanPmt	number	非必须	已有无担保贷款月付额
     */
    private BigDecimal creLoanPmt;
    /**
     * telInvestFlag	string	非必须	是否需要电核
     */
    private String telInvestFlag;
    /**
     * calCreditAmt	number	非必须	系统计算授信额度
     */
    private BigDecimal calCreditAmt;
    /**
     * morLoanType	string	非必须	原房贷贷款类型 01-按揭 02-抵押
     */
    private String morLoanType;
    /**
     * exceptionPrompt	string	非必须	异常代码提示
     */
    private String exceptionPrompt;
    /**
     * investigateFlag	string	非必须		是否调查
     */
    private String investigateFlag;
    /**
     * exceptionCode	string	非必须		异常编码
     */
    private BigDecimal exceptionCode;
    /**
     * fiCreLoan	number	非必须		所有金融机构无担保授信额度
     */
    private BigDecimal fiCreLoan;


    private List<Product> productSelected;

    private List<RuleDecision> ruleDecision;

}
