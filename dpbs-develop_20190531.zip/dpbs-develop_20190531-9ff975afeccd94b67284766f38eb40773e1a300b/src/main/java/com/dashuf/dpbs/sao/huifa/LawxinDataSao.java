/*
 * @(#)LawxinDataSao.java 2018年10月10日 Copy Right 2018 Shenzhen Qianhai Dashu Financial Service
 * Co.Ltd. All Copyright Reserved
 */

package com.dashuf.dpbs.sao.huifa;

import com.dashuf.dpbs.app.web.req.lawsuit.LawsuitParamReq;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;

/**
 * 第三方平台-汇法网信息
 * <p>
 * 
 * @version 1.0.0,2018年10月10日
 * @author yaojiaoyi
 * @since 1.0.0
 */
@FeignClient(value = "EDQ-HUIFAQUERY")
public interface LawxinDataSao {

  /**
   * 精确单笔数据查询接口
   *
   * @return
   */
  @PostMapping("/api/LawxinServer/get_lawxin_data.do")
  @ResponseBody
  String getLawxinData(@RequestBody LawsuitParamReq lawsuitParamReq);
}
