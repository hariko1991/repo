package com.dashuf.dpbs.sao.laapp.resp;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class AllowPushClientResp implements Serializable {

    /**
     * prodectedInd	boolean 必须 是否被保护
     */
    private boolean prodectedInd;
    /**
     * prodectedChannelCode	null 必须 保护的渠道code
     */
    private String prodectedChannelCode;
    /**
     * prodectedChannelName	null  必须 保护的渠道名称
     */
    private String prodectedChannelName;
}
