package com.dashuf.dpbs.app.web;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.DpbsUrl;
import com.dashuf.dpbs.app.annotation.LoginRole;
import com.dashuf.dpbs.app.annotation.LoginUser;
import com.dashuf.dpbs.app.web.req.home.GetUmInfoReq;
import com.dashuf.dpbs.app.web.resp.home.GetUmInfoResp;
import com.dashuf.dpbs.app.web.resp.home.NoticeResp;
import com.dashuf.dpbs.app.web.resp.home.PosterResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.model.UserInfo;
import com.dashuf.dpbs.service.NoticeInfoService;
import com.dashuf.dpbs.service.PosterInfoService;
import com.dashuf.dpbs.service.UserInfoService;
import com.dashuf.merlin.web.base.views.ResponseVo;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import springfox.documentation.annotations.ApiIgnore;

import java.util.List;

@Api(value = "App首页相关", tags = {"App首页相关"})
@RestController
@Slf4j
@RequestMapping(DpbsUrl.HOME_REF)
public class HomeController {
    @Autowired
    private NoticeInfoService noticeInfoService;
    @Autowired
    private PosterInfoService posterInfoService;
    @Autowired
    private UserInfoService userInfoService;

    @ApiOperation(value = "公告查询")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "成功")})
    @PostMapping("/getNotice")
    @LoginRole
    public ResponseVo<List<NoticeResp>> getNotice() {
        try {
            return ResponseVo.success(noticeInfoService.getNoticeList());
        } catch (Exception e) {
            log.error("获取已办待办列表过程中异常:exception={}", e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }

    }

    @ApiOperation(value = "获取客户经理信息")
    @PostMapping("/getUmInfo")
    public ResponseVo<GetUmInfoResp> getUmInfo(@Validated @RequestBody GetUmInfoReq getUmInfoReq, @ApiIgnore @LoginUser String loginUserNo) {
        try {
            JSONObject jsonObj = new JSONObject();
            UserInfo userInfo = userInfoService.getUserInfo(loginUserNo, jsonObj);

            if (null == userInfo) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }

            GetUmInfoResp getUmInfoResp = new GetUmInfoResp();
            BeanUtils.copyProperties(userInfo, getUmInfoResp);
            return new ResponseVo<>(getUmInfoResp);
        } catch (Exception e) {
            log.error("获取用户[{}]客户经理信息过程中异常:{}", getUmInfoReq.getUserNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "海报查询")
    @ApiResponses(value = {@ApiResponse(code = 200, message = "成功")})
    @PostMapping("/getPoster")
    @LoginRole
    public ResponseVo<List<PosterResp>> getPoster() {

        try {
            return ResponseVo.success(posterInfoService.getPosterList());
        } catch (Exception e) {
            log.error("获取已办待办列表过程中异常:exception={}", e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

}
