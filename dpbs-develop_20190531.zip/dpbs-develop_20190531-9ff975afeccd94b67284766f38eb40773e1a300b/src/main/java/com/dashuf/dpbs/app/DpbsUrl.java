package com.dashuf.dpbs.app;

public final class DpbsUrl {
	public static final String MOVIE_PLAT_REF = "/dpbs/appWeb/moviePlatRef";

	public static final String USER_REG_REF = "/dpbs/appWeb/userRegRef";

	public static final String USER_LOGIN_REF = "/dpbs/appWeb/userLoginRef";

	public static final String USER_PASSWOD_REF = "/dpbs/appWeb/userPwdRef";

	public static final String VERIFY_CODE_REF = "/dpbs/appWeb/verifyCodeRef";

	public static final String HOME_REF = "/dpbs/appWeb/homeRef";

	public static final String LAWSUIT_REF = "/dpbs/appWeb/lawsuitRef";

	public static final String PUSH_ORDER_REF = "/dpbs/appWeb/pushOrderRef";

	public static final String CREDIT_AUTH_REF = "/dpbs/appWeb/creditAuthRef";

	public static final String SUPPORT_REF = "/dpbs/appWeb/supportRef";

	public static final String BUSINESS_PRO_REF = "/dpbs/appWeb/businessRef";

	public static final String PERSON_CENTER_REF = "/dpbs/appWeb/personCenterRef";

}
