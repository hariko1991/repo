package com.dashuf.dpbs.app.web.req.credit;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "解析银联认证h5的token的Req")
@Getter
@Setter
public class AnalysisQrCodeReq implements Serializable {
    private static final long serialVersionUID = -5290251496172927734L;
    @ApiModelProperty(value = "二维内包含的编号", required = true)
    @NotBlank(message = "二维内包含的编号不能为空")
    private String qrCodeInfoNo;

    @ApiModelProperty(value = "解析类型,区别从哪里进入,qr_code,")
    private String analysisType;

}
