package com.dashuf.dpbs.sao.icp.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
public class CheckIDCardReq implements Serializable {

    /**
     * 身份证号
     */
    private String idcardNo;

    /**
     * 身份证姓名
     */
    private String idcardName;

}
