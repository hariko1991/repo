package com.dashuf.dpbs.sao.ucss;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.sao.ucss.resp.GetDetailOfUserResp;
import com.dashuf.merlin.web.base.views.ResponseVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

@FeignClient(name = "UCSS")
public interface UserAuthSAO {

    /**
     * 根据UM用户名获取分公司
     *
     * @param userId
     * @return
     */
    @RequestMapping(value = "/ucss/v1/UserAuthorizationSystem/Users/{userId}/Organizations/not-login", method = RequestMethod.GET)
    ResponseVo<JSONObject> getCompanyListOfUser(@PathVariable("userId") String userId);


    /**
     * 根据UM用户名从统一账户服务获取用户信息
     *
     * @param userId
     * @return
     */
    @RequestMapping(value = "/ucss/v1/UserAuthorizationSystem/Users/{userId}/not-login", method = RequestMethod.GET)
    ResponseVo<GetDetailOfUserResp> getDetailOfUser(@PathVariable("userId") String userId);

    @RequestMapping(value = "/ucss/v1/UserAuthorizationSystem/Organizations/not-login", method = RequestMethod.GET)
    ResponseVo<JSONObject> getCompanyOfUm(@RequestParam("statusCode") String statusCode);
}
