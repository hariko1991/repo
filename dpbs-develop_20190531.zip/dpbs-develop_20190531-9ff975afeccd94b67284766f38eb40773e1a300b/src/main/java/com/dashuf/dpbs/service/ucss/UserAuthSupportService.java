package com.dashuf.dpbs.service.ucss;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.web.resp.support.GetCompanyOfUmResp;
import com.dashuf.dpbs.app.web.resp.support.GetCompanyResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.model.UserInfo;
import com.dashuf.dpbs.sao.ucss.UserAuthSAO;
import com.dashuf.dpbs.sao.ucss.resp.GetDetailOfUserResp;
import com.dashuf.merlin.web.base.views.ResponseVo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
@Slf4j
public class UserAuthSupportService {
    @Autowired
    private UserAuthSAO userAuthSAO;

    public boolean getCompanyListOfUser(String srcUmNo, UserInfo userInfo, JSONObject jsonObj) {
        ResponseVo<JSONObject> getCompanyListOfUserResp = userAuthSAO.getCompanyListOfUser(srcUmNo);
        if (DpbsCnst.HTTP_OK.equals(getCompanyListOfUserResp.getCode())) {
            if (null == getCompanyListOfUserResp.getData()) {
                return true;
            }


            JSONArray jsonArray = getCompanyListOfUserResp.getData().getJSONArray("list");
            if (null == jsonArray) {
                return true;
            }

            StringBuffer srcCompanyBuf = new StringBuffer();
            StringBuffer srcCompanyCodeBuf = new StringBuffer();
            for (int i = 0; i < jsonArray.size(); i++) {
                srcCompanyBuf.append(jsonArray.getJSONObject(i).getJSONObject("organization").getString("organizationName")).append(",");
                srcCompanyCodeBuf.append(jsonArray.getJSONObject(i).getJSONObject("organization").getString("organizationId")).append(",");

            }
            userInfo.setSrcCompany(srcCompanyBuf.toString());
            userInfo.setSrcCompanyCode(srcCompanyCodeBuf.toString());
            return true;
        } else {
            jsonObj.put(DpbsCnst.RTN_MSG, getCompanyListOfUserResp.getMessage());
            return false;
        }
    }

    public GetCompanyOfUmResp getCompanyListOfUser(String srcUmNo, JSONObject jsonObj) {
        ResponseVo<JSONObject> getCompanyListOfUserResp = userAuthSAO.getCompanyListOfUser(srcUmNo);
        if (DpbsCnst.HTTP_OK.equals(getCompanyListOfUserResp.getCode())) {
            if (null == getCompanyListOfUserResp.getData()) {
                jsonObj.put(DpbsCnst.RTN_MSG, "用户不存在分公司");
                return null;
            }

            JSONArray jsonArray = getCompanyListOfUserResp.getData().getJSONArray("list");
            if (null == jsonArray) {
                jsonObj.put(DpbsCnst.RTN_MSG, "用户不存在分公司");
                return null;
            }

            List<GetCompanyOfUmResp.CompanyOfUm> companyOfUmList = new ArrayList<>();
            for (int i = 0; i < jsonArray.size(); i++) {
                GetCompanyOfUmResp.CompanyOfUm companyOfUm = new GetCompanyOfUmResp.CompanyOfUm();
                companyOfUm.setCompanyCode(jsonArray.getJSONObject(i).getJSONObject("organization").getString("organizationId"));
                companyOfUm.setCompanyName(jsonArray.getJSONObject(i).getJSONObject("organization").getString("organizationName"));
                companyOfUmList.add(companyOfUm);
            }

            if (companyOfUmList.size() == 0) {
                jsonObj.put(DpbsCnst.RTN_MSG, "用户不存在分公司");
                return null;
            }

            GetCompanyOfUmResp getCompanyOfUmResp = new GetCompanyOfUmResp();
            getCompanyOfUmResp.setCompanyList(companyOfUmList);
            return getCompanyOfUmResp;
        } else {
            jsonObj.put(DpbsCnst.RTN_MSG, getCompanyListOfUserResp.getMessage());
            return null;
        }
    }

    public GetCompanyResp getCompanyList(JSONObject jsonObj) {
        ResponseVo<JSONObject> getCompanyListResp = userAuthSAO.getCompanyOfUm("N");
        if (DpbsCnst.HTTP_OK.equals(getCompanyListResp.getCode())) {
            if (null == getCompanyListResp.getData()) {
                jsonObj.put(DpbsCnst.RTN_MSG, "不存在分公司");
                return null;
            }


            JSONArray jsonArray = getCompanyListResp.getData().getJSONArray("list");
            if (null == jsonArray) {
                jsonObj.put(DpbsCnst.RTN_MSG, "不存在分公司");
                return null;
            }

            List<GetCompanyResp.CompnayOfUm> compnayOfUmList = new ArrayList<>();
            for (int i = 0; i < jsonArray.size(); i++) {
                GetCompanyResp.CompnayOfUm compnayOfUm = new GetCompanyResp.CompnayOfUm();
                compnayOfUm.setCompanyCode(jsonArray.getJSONObject(i).getString("organizationId"));
                compnayOfUm.setCompanyName(jsonArray.getJSONObject(i).getString("organizationName"));
                compnayOfUmList.add(compnayOfUm);
            }

            if (compnayOfUmList.size() == 0) {
                jsonObj.put(DpbsCnst.RTN_MSG, "不存在分公司");
                return null;
            }

            GetCompanyResp getCompanyResp = new GetCompanyResp();
            getCompanyResp.setCompnayList(compnayOfUmList);
            return getCompanyResp;
        } else {
            jsonObj.put(DpbsCnst.RTN_MSG, getCompanyListResp.getMessage());
            return null;
        }
    }

    public boolean getDetailOfUser(String srcUmNo, UserInfo userInfo, JSONObject jsonObj) {
        ResponseVo<GetDetailOfUserResp> getDetailOfUserResp = userAuthSAO.getDetailOfUser(srcUmNo);

        if (DpbsCnst.HTTP_OK.equals(getDetailOfUserResp.getCode())) {
            if (null == getDetailOfUserResp.getData()) {
                jsonObj.put(DpbsCnst.RTN_MSG, "用户不存在");
                return false;
            }


            userInfo.setSrcUmName(getDetailOfUserResp.getData().getUserName());
            userInfo.setSrcUmMobileNo(getDetailOfUserResp.getData().getMobilePhoneNum());
            return true;
        } else {
            jsonObj.put(DpbsCnst.RTN_MSG, getDetailOfUserResp.getMessage());
            return false;
        }
    }


}



