package com.dashuf.dpbs.app.web.req.push;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "信息录入req")
@Getter
@Setter
public class InfoEntryReq implements Serializable {
    private static final long serialVersionUID = 26902995577450524L;

    @ApiModelProperty(value = "推送订单编号", required = true)
    @NotBlank(message = "推送订单编号不能为空")
    private String pushOrderNo;

    @ApiModelProperty(value = "工作地址", required = true)
    @NotBlank(message = "请输入工作地址编码")
    private String workAddr;

    @ApiModelProperty(value = "工作地址", required = true)
    @NotBlank(message = "请输入工作地址名称")
    private String workAddrName;

    @ApiModelProperty(value = "客户类型", required = true)
    @NotBlank(message = "客户类型不能为空")
    private String clientType;

    @ApiModelProperty(value = "手机号码")
    @NotBlank(message = "请输入正确的手机号")
    @Pattern(regexp = "^[1][0-9]{10}$", message = "请输入正确的手机号")
    private String mobileNo;

    @ApiModelProperty(value = "期望贷款期限")
    private String expectLoanPeriod;

    @ApiModelProperty(value = "期望贷款金额")
    private BigDecimal expectLoanAmt;

    @ApiModelProperty(value = "居住地址编码")
    private String lifeAddr;

    @ApiModelProperty(value = "居住地址名称")
    private String lifeAddrName;

    @ApiModelProperty(value = "是否有寿险保单")
    private String ifInsurance;

    @ApiModelProperty(value = "是否有信用卡分期")
    private String ifCreditSupply;

    @ApiModelProperty(value = "是否有房产信息")
    private String ifHouse;

    @ApiModelProperty(value = "是否有营业执照:true(有)、false(无)、unknown(未知)")
    private String businessLicenseInd;
    @ApiModelProperty(value = "是否法人:true(有)、false(无)、unknown(未知)")
    private String legalPersonInd;

    @ApiModelProperty(value = "是否股东:true(有)、false(无)、unknown(未知)")
    private String shareholderInd;

    @ApiModelProperty(value = "信用卡分期")
    private List<InfoEntryOfCreditSupply> creditSupplyList;

    @ApiModelProperty(value = "房产信息")
    private List<InfoEntryOfHouse> houseList;

    @ApiModelProperty(value = "寿险保单信息")
    private List<InfoEntryOfInsurance> insuranceList;

}
