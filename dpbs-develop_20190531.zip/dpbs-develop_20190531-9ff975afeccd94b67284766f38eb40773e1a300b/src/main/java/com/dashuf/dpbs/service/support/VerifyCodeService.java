package com.dashuf.dpbs.service.support;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.dashuf.dpbs.service.SysConfSupportService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.SysConfCnst;
import com.dashuf.dpbs.model.SysConf;
import com.dashuf.dpbs.sao.sms.SendMessageSAO;
import com.dashuf.dpbs.util.DpbsUtil;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class VerifyCodeService {
    private static final String REG = "REG";
    private static final Map<String, String> PREFIX_MAP = new HashMap<String, String>();

    static {
        PREFIX_MAP.put(SysConfCnst.MODULE_CODE_USER_REG, REG);
        PREFIX_MAP.put("user_verify_cert", "UVC");
        PREFIX_MAP.put("client_credit_auth", "CCA");
    }

    @Autowired
    private SendMessageSAO sendMessageSAO;
    @Autowired
    private StringRedisTemplate redisTemplate;
    @Autowired
    private SysConfSupportService sysConfSupportService;

    public boolean sendVerifyCode(String moduleCode, String phone, JSONObject jsonObj) {
        SysConf sysConf = new SysConf();
        sysConf.setModuleCode(moduleCode);
        sysConf.setModuleSubCode(SysConfCnst.SEND_VERIFY_CODE);
        sysConf.setModuleKey(SysConfCnst.TEMPLATE_NO);

        String prefix = StringUtils.isEmpty(PREFIX_MAP.get(moduleCode)) ? "DEF" : PREFIX_MAP.get(moduleCode);
        String applyNo = DpbsUtil.getTableNo(prefix);

        String templateId = sysConfSupportService.selectValueFromCache(sysConf);
        String rtnMsg = sendMessageSAO.sendVerificationCode(phone, applyNo, templateId);
        log.info("手机号[{}]依据模板编码[{}]发送验证码结果为:{}", phone, templateId, rtnMsg);

        JSONObject jsonObject = JSONObject.parseObject(rtnMsg);
        if (jsonObject.get("code").equals("0000")) {
            String redisKey = moduleCode + DpbsCnst.VERTICAL_SYMBOL + SysConfCnst.SEND_VERIFY_CODE + phone;
            log.info("模块[{}]发送验证码手机号[{}]缓存键[{}]缓存值[{}]", moduleCode, phone, redisKey, applyNo);
            redisTemplate.opsForValue().set(DpbsCnst.REDIS_DPBS_VERIFY_CODE + redisKey, applyNo, 2, TimeUnit.MINUTES);
            return true;
        } else {
            jsonObj.put(DpbsCnst.RTN_CODE, jsonObject.getString("code"));
            jsonObj.put(DpbsCnst.RTN_MSG, jsonObject.getString("message"));
            return false;
        }
    }

    public boolean checkVerifyCode(String moduleCode, String phone, String verifyCode, JSONObject jsonObj) {
        String redisKey = moduleCode + DpbsCnst.VERTICAL_SYMBOL + SysConfCnst.SEND_VERIFY_CODE + phone;
        String applyNo = redisTemplate.opsForValue().get(DpbsCnst.REDIS_DPBS_VERIFY_CODE + redisKey);
        log.info("模块[{}]校验验证码手机号[{}]缓存键[{}]缓存值[{}]验证码[{}]", moduleCode, phone, redisKey, applyNo, verifyCode);
        if (StringUtils.isEmpty(applyNo)) {
            jsonObj.put(DpbsCnst.RTN_MSG, "验证码过期或者未发送验证码");
            return false;
        }

        String rtnMsg = sendMessageSAO.checksumVerificationCode(applyNo, phone, verifyCode, "1");
        JSONObject jsonObject = JSONObject.parseObject(rtnMsg);
        if (!jsonObject.get("code").equals("0000")) {
            jsonObj.put(DpbsCnst.RTN_CODE, jsonObject.getString("code"));
            jsonObj.put(DpbsCnst.RTN_MSG, jsonObject.getString("message"));

            if (sysConfSupportService.selectMockValFromCache(SysConfCnst.DATA_MOCK_OF_SEND_VERIFY_CODE)) {
                return true;
            }
            return false;
        }
        return true;
    }

}
