package com.dashuf.dpbs.sao.cids.req.ds010.blaze.application;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class ApplicationProductInfo implements Serializable {
    private static final long serialVersionUID = -6209864218250159462L;

    /**
     * "creCustomerType": "060"
     */
    private String creCustomerType;
}
