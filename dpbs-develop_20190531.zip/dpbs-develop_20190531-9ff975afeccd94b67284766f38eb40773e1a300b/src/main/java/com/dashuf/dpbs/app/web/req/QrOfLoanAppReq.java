package com.dashuf.dpbs.app.web.req;

import java.io.Serializable;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "贷款APP二维码")
@Getter
@Setter
public class QrOfLoanAppReq implements Serializable {
    private static final long serialVersionUID = 6792175086448081741L;

    @ApiModelProperty(value = "推送订单编号", required = true)
    private String pushOrderNo;

    @ApiModelProperty(value = "设备类型:andorid、iphone", required = true)
    private String deviceType;
}
