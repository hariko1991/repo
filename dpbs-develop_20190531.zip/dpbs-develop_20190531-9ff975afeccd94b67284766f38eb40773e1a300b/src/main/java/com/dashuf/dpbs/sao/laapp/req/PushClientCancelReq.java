package com.dashuf.dpbs.sao.laapp.req;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Getter
@Setter
public class PushClientCancelReq implements Serializable {

    private static final long serialVersionUID = -5807218381029247644L;
    @ApiModelProperty(value = "渠道来源")
    private String channelSource;

    @ApiModelProperty(value = "第三方推单编号")
    private String thirdPartOrderId;

    @ApiModelProperty(value = "客户姓名")
    private String custName;

    @ApiModelProperty(value = "客户身份证号码")
    private String certificateNum;

    @ApiModelProperty(value = "客户证件类型")
    private String certificateType;

}
