package com.dashuf.dpbs.app.web.req.msmp;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "用户分页查询Req")
@Getter
@Setter
public class UserPageReq implements Serializable {
	private static final long serialVersionUID = 4055392020910350026L;

	@ApiModelProperty(value = "客户经理号", required = true)
	@NotBlank(message = "请输入客户经理号")
	private String custManager;

	@ApiModelProperty(value = "用户名称")
	private String userName;

	@ApiModelProperty(value = "页面大小")
	private Integer pageSize = 5;

	@ApiModelProperty(value = "页码")
	private Integer pageNum = 1;
}
