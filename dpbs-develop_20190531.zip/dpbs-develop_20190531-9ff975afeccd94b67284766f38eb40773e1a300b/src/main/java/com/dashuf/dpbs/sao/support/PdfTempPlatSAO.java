package com.dashuf.dpbs.sao.support;

import com.dashuf.dpbs.sao.support.req.GetFileTemplateReq;
import com.dashuf.dpbs.sao.support.resp.GetFileTemplateResp;
import com.dashuf.merlin.web.base.views.ResponseVo;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 * , url="http://10.21.0.63:8124"
 */
@FeignClient(name = "TemplatePlatform")
public interface PdfTempPlatSAO {

    @RequestMapping(value = "/api/getFileTemplate.do", method = RequestMethod.POST)
    public ResponseVo<GetFileTemplateResp> getFileTemplate(@RequestBody GetFileTemplateReq getFileTemplateReq);
}
