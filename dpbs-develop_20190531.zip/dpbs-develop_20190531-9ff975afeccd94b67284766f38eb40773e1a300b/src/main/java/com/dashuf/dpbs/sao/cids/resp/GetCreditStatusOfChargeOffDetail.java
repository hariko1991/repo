package com.dashuf.dpbs.sao.cids.resp;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author yaojiaoyi
 */
public class GetCreditStatusOfChargeOffDetail implements Serializable {
    /**
     * 出账编号
     */
    private String accountAllotId;
    /**
     * 出账状态
     */
    private String accountAllotCode;
    /**
     * 贷款期限
     */
    private String loanTerm;

    /**
     * 放款金额
     */
    private BigDecimal putoutAmt;

    /**
     * 放款日期
     */
    private String putoutDate;

    /**
     * 产品ID
     */
    private String productId;

    /**
     * 产品名称
     */
    private String productName;

    /**
     * 是否需要补件
     */
    private boolean patchInd;
    /**
     * 是否有效
     */
    private boolean availableInd;

    public String getAccountAllotId() {
        return accountAllotId;
    }

    public void setAccountAllotId(String accountAllotId) {
        this.accountAllotId = accountAllotId;
    }

    public String getAccountAllotCode() {
        return accountAllotCode;
    }

    public void setAccountAllotCode(String accountAllotCode) {
        this.accountAllotCode = accountAllotCode;
    }

    public String getLoanTerm() {
        return loanTerm;
    }

    public void setLoanTerm(String loanTerm) {
        this.loanTerm = loanTerm;
    }

    public BigDecimal getPutoutAmt() {
        return putoutAmt;
    }

    public void setPutoutAmt(BigDecimal putoutAmt) {
        this.putoutAmt = putoutAmt;
    }

    public String getPutoutDate() {
        return putoutDate;
    }

    public void setPutoutDate(String putoutDate) {
        this.putoutDate = putoutDate;
    }

    public String getProductId() {
        return productId;
    }

    public void setProductId(String productId) {
        this.productId = productId;
    }

    public String getProductName() {
        return productName;
    }

    public void setProductName(String productName) {
        this.productName = productName;
    }

    public boolean isPatchInd() {
        return patchInd;
    }

    public void setPatchInd(boolean patchInd) {
        this.patchInd = patchInd;
    }

    public boolean isAvailableInd() {
        return availableInd;
    }

    public void setAvailableInd(boolean availableInd) {
        this.availableInd = availableInd;
    }
}
