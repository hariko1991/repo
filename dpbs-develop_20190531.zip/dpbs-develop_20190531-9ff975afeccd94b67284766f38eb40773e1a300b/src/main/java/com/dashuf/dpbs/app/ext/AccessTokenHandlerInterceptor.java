package com.dashuf.dpbs.app.ext;

import java.lang.reflect.Method;
import java.util.concurrent.TimeUnit;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dashuf.dpbs.app.annotation.LoginRole;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.DpbsHeadCnst;
import com.dashuf.dpbs.util.TokenUtil;
import io.jsonwebtoken.Claims;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.StringRedisTemplate;
import org.springframework.lang.Nullable;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

@Slf4j
public class AccessTokenHandlerInterceptor extends HandlerInterceptorAdapter {
    private static final String CLAIMS_ID = "id";
    @Autowired
    private TokenUtil tokenUtils;
    @Autowired
    private StringRedisTemplate redisTemplate;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {

        if (!(handler instanceof HandlerMethod)) {
            return true;
        }
        HandlerMethod handlerMethod = (HandlerMethod) handler;
        Method method = handlerMethod.getMethod();

        if (request.getRequestURI().contains("/dpbs/")) {
            String accessToken = request.getHeader(DpbsHeadCnst.X_HEAD_ACCESS_TOKEN);
            LoginRole loginRole = method.getAnnotation(LoginRole.class);

            if (null == loginRole) {
                if (StringUtils.isEmpty(accessToken)) {
                    response.setHeader(DpbsHeadCnst.X_HEAD_RTN_CODE, DpbsHeadCnst.X_HEAD_RTN_CODE_NEED_LOGIN);
                    log.error("请求前置处理器,处理头中访问token为空,需要传入");
                    return false;
                } else {
                    try {
                        Claims userNoClaims = tokenUtils.parseJWT(accessToken);
                        String userNo = null == userNoClaims.get(CLAIMS_ID) ? "" : userNoClaims.get(CLAIMS_ID).toString();
                        log.info("请求前置处理器,解析请求访问token[{}]对应用户编号为[{}]", accessToken, userNo);
                        if (StringUtils.isEmpty(userNo)) {
                            response.setHeader(DpbsHeadCnst.X_HEAD_RTN_CODE, DpbsHeadCnst.X_HEAD_RTN_CODE_INVALID_TOKEN);
                            return false;
                        }

                        String saveAccessToken = redisTemplate.opsForValue().get(DpbsCnst.REDIS_DPBS_LOGIN + userNo);
                        log.info("请求前置处理器,解析请求访问token[{}]对应用户编号[{}]的存储token为[{}]", accessToken, userNo, saveAccessToken);
                        if (!accessToken.equals(saveAccessToken)) {
                            response.setHeader(DpbsHeadCnst.X_HEAD_RTN_CODE, DpbsHeadCnst.X_HEAD_RTN_CODE_RE_LOGIN);
                            log.error("请求前置处理器,请求token和实际存储token不一致,退出登录");
                            return false;
                        }

                        request.setAttribute(DpbsHeadCnst.X_HEAD_LOGIN_USER, userNo);
                    } catch (Exception e) {
                        response.setHeader(DpbsHeadCnst.X_HEAD_RTN_CODE, DpbsHeadCnst.X_HEAD_RTN_CODE_INVALID_TOKEN);
                        log.error("请求前置处理器,处理头中访问token[{}]过期异常为:{}", accessToken, e);
                        return false;
                    }
                }
            }
        }
        return true;
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler,
                           @Nullable ModelAndView modelAndView) throws Exception {

        String accessToken = response.getHeader(DpbsHeadCnst.X_HEAD_ACCESS_TOKEN);
        String userNo = null == request.getAttribute(DpbsHeadCnst.X_HEAD_USER_NO) ? "" : request.getAttribute(DpbsHeadCnst.X_HEAD_USER_NO).toString();
        if (StringUtils.isNotEmpty(userNo) && StringUtils.isNotEmpty(accessToken)) {
            log.info("请求后置处理器,为用户[{}]生成新token为[{}]", userNo, accessToken);

            redisTemplate.opsForValue().set(DpbsCnst.REDIS_DPBS_LOGIN + userNo, accessToken, 2, TimeUnit.HOURS);
            log.info("请求后置处理器,缓存对应值用户编号[{}]访问编码[{}]", userNo, accessToken);

            request.removeAttribute(DpbsHeadCnst.X_HEAD_USER_NO);
        }
    }
}