package com.dashuf.dpbs.app.web.msmp;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.annotation.LoginRole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.dashuf.dpbs.app.DpbsForMsmpUrl;
import com.dashuf.dpbs.app.web.req.msmp.ClientOfUserPageReq;
import com.dashuf.dpbs.app.web.req.msmp.GetUserDetailReq;
import com.dashuf.dpbs.app.web.req.msmp.ModifyUserCompanyReq;
import com.dashuf.dpbs.app.web.req.msmp.UserPageReq;
import com.dashuf.dpbs.app.web.resp.msmp.MyClientResp;
import com.dashuf.dpbs.app.web.resp.msmp.MyUserDetailResp;
import com.dashuf.dpbs.app.web.resp.msmp.MyUserResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.service.MsmpSupportService;
import com.dashuf.merlin.web.base.views.ResponseVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Api(value = "移动销售平台我的用户相关", tags = {"移动销售平台我的用户相关"})
@Slf4j
@RestController
@RequestMapping(DpbsForMsmpUrl.MSMP_MY_USER)
public class MyUserController {
    @Autowired
    private MsmpSupportService chipSupportService;

    @ApiOperation(value = "获取我的用户页面列表")
    @PostMapping("/getPage")
    @LoginRole
    public ResponseVo<MyUserResp> getPage(@RequestBody @Validated UserPageReq userPageReq) {
        try {
            MyUserResp myUserResp = new MyUserResp();
            myUserResp.setUserBeanPage(chipSupportService.selectUserPage(userPageReq.getPageNum(), userPageReq.getPageSize(), userPageReq.getCustManager(),
                    userPageReq.getUserName()));
            return new ResponseVo<>(myUserResp);
        } catch (Exception e) {
            log.error("获取客户经理[{}]列表异常:{}", userPageReq.getCustManager(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "获取我的用户详情")
    @PostMapping("/getDetail")
    @LoginRole
    public ResponseVo<MyUserDetailResp> getDetail(@RequestBody @Validated GetUserDetailReq getUserRefReq) {
        try {
            JSONObject jsonObj = new JSONObject();
            MyUserDetailResp myUserDetailResp = chipSupportService.getDetail(getUserRefReq, jsonObj);
            if (null == myUserDetailResp) {
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, jsonObj.getString(DpbsCnst.RTN_MSG));
            }
            return new ResponseVo<>(myUserDetailResp);
        } catch (Exception e) {
            log.error("获取用户[{}]详情异常:{}", getUserRefReq.getUserNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "修改用户所属公司")
    @PostMapping("/modifyUserCompany")
    @LoginRole
    public ResponseVo<String> modifyUserCompany(@RequestBody @Validated ModifyUserCompanyReq modifyUserCompanyReq) {
        try {
            chipSupportService.modifyUserCompany(modifyUserCompanyReq.getUserNo(), modifyUserCompanyReq.getSrcChannel(), modifyUserCompanyReq.getSrcChannelCode());
            return new ResponseVo<>(DpbsCnst.SUCCESS_RTN_CODE);
        } catch (Exception e) {
            log.error("用户[{}]修改所属公司为[{}]过程中发生异常:{}", modifyUserCompanyReq.getUserNo(), modifyUserCompanyReq.getSrcChannel(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "获取我的待办列表")
    @PostMapping("/getPendPage")
    @LoginRole
    public ResponseVo<MyClientResp> getPendPage(@RequestBody @Validated ClientOfUserPageReq clientOfUserPageReq) {
        try {
            MyClientResp myClientResp = new MyClientResp();
            myClientResp.setClientBeanPage(chipSupportService.selectPendClientPage(clientOfUserPageReq.getPageNum(), clientOfUserPageReq.getPageSize(),
                    clientOfUserPageReq.getUserNo(), clientOfUserPageReq.getClientName()));
            return new ResponseVo<>(myClientResp);
        } catch (Exception e) {
            log.error("获取用户[{}]待办列表异常:{}", clientOfUserPageReq.getUserNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }

    @ApiOperation(value = "获取我的已办列表")
    @PostMapping("/getAlreadyPage")
    @LoginRole
    public ResponseVo<MyClientResp> getAlreadyPage(@RequestBody @Validated ClientOfUserPageReq clientOfUserPageReq) {
        try {
            MyClientResp myClientResp = new MyClientResp();
            myClientResp.setClientBeanPage(chipSupportService.selectAlreadyClientPage(clientOfUserPageReq.getPageNum(), clientOfUserPageReq.getPageSize(),
                    clientOfUserPageReq.getUserNo(), clientOfUserPageReq.getClientName()));
            return new ResponseVo<>(myClientResp);
        } catch (Exception e) {
            log.error("获取用户[{}]已办列表异常:{}", clientOfUserPageReq.getUserNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }
}
