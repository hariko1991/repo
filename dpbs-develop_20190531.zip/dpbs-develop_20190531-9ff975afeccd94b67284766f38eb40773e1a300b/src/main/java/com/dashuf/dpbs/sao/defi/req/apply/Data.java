package com.dashuf.dpbs.sao.defi.req.apply;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class Data implements Serializable {
    private static final long serialVersionUID = 4260613432377234775L;

    private String matchData;

    private Application application;
}
