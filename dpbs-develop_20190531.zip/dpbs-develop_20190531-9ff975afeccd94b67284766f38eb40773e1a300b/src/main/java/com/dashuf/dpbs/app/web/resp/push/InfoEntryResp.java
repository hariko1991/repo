package com.dashuf.dpbs.app.web.resp.push;

import java.io.Serializable;

import com.dashuf.dpbs.app.web.resp.QrCodeResp;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "信息录入响应resp")
@Getter
@Setter
public class InfoEntryResp extends QrCodeResp {
    private static final long serialVersionUID = 26902995577450524L;

    @ApiModelProperty(value = "推送订单编号", required = true)
    private String pushOrderNo;

    @ApiModelProperty(value = "推送状态", required = true)
    private String pushStatus;

    @ApiModelProperty(value = "跳转页面")
    private String redirectPage;

}
