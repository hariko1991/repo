package com.dashuf.dpbs.app.web.resp.home;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "获取客户经理信息resp")
@Setter
@Getter
public class GetUmInfoResp {
    @ApiModelProperty(value = "所属客户经理名子")
    private String srcUmName;

    @ApiModelProperty(value = "所属客户经理编码")
    private String srcUmNo;

    @ApiModelProperty(value = "所属客户经理手机号")
    private String srcUmMobileNo;
}
