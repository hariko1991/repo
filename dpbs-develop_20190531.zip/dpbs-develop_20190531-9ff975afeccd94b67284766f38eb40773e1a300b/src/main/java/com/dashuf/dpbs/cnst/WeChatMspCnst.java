package com.dashuf.dpbs.cnst;

public final class WeChatMspCnst {
	/**
	 * 第一步、调用微信获取accesstoken
	 */
	public static final String GET_ACCESS_TOKEN_URL = "https://qyapi.weixin.qq.com/cgi-bin/gettoken?corpid=%s&corpsecret=%s";
	/**
	 * 第二步、调用微信获取用户信息
	 */
	public static final String GET_USER_INFO_URL = "https://qyapi.weixin.qq.com/cgi-bin/user/getuserinfo?access_token=%s&code=%s";
	/**
	 * 第三步、调用微信获取用户明细信息
	 */
	public static final String GET_USER_DETAIL_INFO_URL = "https://qyapi.weixin.qq.com/cgi-bin/user/get?access_token=%s&userid=%s";
	/**
	 * 第四步、调用微信获取ticket
	 */
	public static final String GET_TICKET_URL = "https://qyapi.weixin.qq.com/cgi-bin/get_jsapi_ticket?access_token=%s";

	public static final String GET_SHA1_URL = "jsapi_ticket=%s&noncestr=%s&timestamp=%s&url=%s?code=%s&state=";

	public static final String ERR_CODE = "errcode";
	public static final String ERR_MSG = "errmsg";
	public static final String SUCCESS_ERR_CODE = "0";

	public static final String GET_ACCESS_TOKEN_PHASE = "getAccessToken";
	public static final String GET_USER_INFO_PHASE = "getUserInfo";
	public static final String GET_USER_DETAIL_INFO_PHASE = "getUserDetailInfo";
	public static final String GET_TICKET_PHASE = "getTicket";
	
	
	public static final String WE_CHAT_AUTH_CODE = "code";

}
