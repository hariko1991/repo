package com.dashuf.dpbs.sao.dsfg;

import com.dashuf.dpbs.sao.dsfg.req.UploadCreditFileReq;
import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.*;

import com.dashuf.merlin.web.base.views.ResponseVo;

@FeignClient(name = "ZLD", url = "${application.zld.url}")
public interface CreditAuthSAO {

    public static final String AUTH_CODE = "authCode";
    public static final String ZLD_PHONE = "phone";
    public static final String ZLD_CALLER = "caller";
    public static final String SOURCE_TYPE = "sourceType";
    public static final String IDCARD_NO = "idcardNo";
    public static final String IDCARD_NAME = "idcardName";
    public static final String APPLY_NO = "applyNo";
    public static final String RETURN_PAGE_URL = "returnPageUrl";

    /**
     * 提交信息给后台接口，加密后发送给银联进行五要素认证。
     *
     * @param idcardName    身份证名字
     * @param idcardNo      身份证号码
     * @param phone
     * @param applyNo       每笔业务的唯一标识
     * @param sourceType    1是pc端，2移动app
     * @param caller        调用方用于标识自己的字段，便于区分调用渠道 ：BANKE
     * @param returnPageUrl 进行五要素结束后，点击返回商家按钮的时候返回的页面
     * @return ResponseVo<String>
     */
    @RequestMapping(value = "/dsf/zld/api/sendCreditAuth.do", method = RequestMethod.POST, consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE)
    String sendCreditAuth(@RequestParam(IDCARD_NAME) String idcardName,
                          @RequestParam(IDCARD_NO) String idcardNo,
                          @RequestParam(ZLD_PHONE) String phone,
                          @RequestParam(APPLY_NO) String applyNo,
                          @RequestParam(SOURCE_TYPE) String sourceType,
                          @RequestParam(ZLD_CALLER) String caller,
                          @RequestParam(RETURN_PAGE_URL) String returnPageUrl);

    /**
     * 提交银联认证之后，可以查询提交的认证是否完成。
     *
     * @param idcardName 身份证名字
     * @param authCode   授权码
     * @param idacrdNo   证件号码
     * @return ResponseVo<String>
     */
    @RequestMapping(value = "/dsf/zld/api/queryCreditAuthResult.do", consumes = MediaType.APPLICATION_FORM_URLENCODED_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
    ResponseVo<String> queryCreditAuthResult(@RequestParam(IDCARD_NAME) String idcardName, @RequestParam(AUTH_CODE) String authCode,
                                             @RequestParam(IDCARD_NO) String idacrdNo);


    @PostMapping(value = "/dsfg/api/credit/sign/upLoad.do")
    ResponseVo<UploadCreditFileResp> uploadCreditFile(@RequestBody UploadCreditFileReq uploadCreditFileReq);


}
