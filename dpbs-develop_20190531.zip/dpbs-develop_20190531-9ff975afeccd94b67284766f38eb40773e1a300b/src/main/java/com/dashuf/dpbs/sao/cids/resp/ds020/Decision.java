package com.dashuf.dpbs.sao.cids.resp.ds020;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
public class Decision implements Serializable {
    private static final long serialVersionUID = -2151937853660668372L;

    private ProductSelected productSelected;
    private ProductDetail productDetail;
    private RuleDecision ruleDecision;
    private ScoreModelReturnInfo scoreModelReturnInfo;
    private String versionID;
    private String specialFlag;
    private String riskScoreResult;
    private String finalResult;
    private BigDecimal maxCalCreditAmt;
    private String morLoanType;
    private String morLoanPMT;
    private String carLoanPMT;
    private String creLoanPMT;
    private String creLoanBalance;
    private String investigateFlag;
    private String telInvestFlag;
    private String telInvestResult;
    private String specialProduct;
    private String score01;
    private String score02;
    private String score03;
    private String score04;
    private String ficreLoan;
    private String xscoreWanted;
    private IcDecision icdecision;
    private ParamMap paramMap;
}
