package com.dashuf.dpbs.app.web.resp.credit;

import java.io.Serializable;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class AnalysisQrCodeResp implements Serializable {
    private static final long serialVersionUID = -80045475266835905L;
    @ApiModelProperty(value = "推送订单编号", required = true)
    private String pushOrderNo;

    @ApiModelProperty(value = "客户姓名", required = true)
    private String clientName;

    @ApiModelProperty(value = "身份证号码", required = true)
    private String certNo;

    @ApiModelProperty(value = "手机号码", required = true)
    private String mobileNo;

}
