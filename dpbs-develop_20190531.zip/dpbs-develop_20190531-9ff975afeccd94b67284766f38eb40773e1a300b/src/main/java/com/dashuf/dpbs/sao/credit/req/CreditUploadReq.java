package com.dashuf.dpbs.sao.credit.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;


@Getter
@Setter
public class CreditUploadReq implements Serializable {

    /**
     * 合作机构(必传)
     */
    @JsonProperty(value = "QUERYORG")
    private String queryOrg;

    /**
     * 申请编号(必传)
     */
    @JsonProperty(value = "APPLYID")
    private String applyId;

    /**
     * 所属分公司(必传)
     */
    @JsonProperty(value = "BELONGORG")
    private String belongOrg;

    /**
     * 所属分公司名称(必传)
     */
    @JsonProperty(value = "ORGNAME")
    private String orgName;

    /**
     * 证件号码(必传)
     */
    @JsonProperty(value = "CERTID")
    private String certId;

    /**
     * 客户姓名(必传)
     */
    @JsonProperty(value = "CUSTOMERNAME")
    private String customerName;

    /**
     * 渠道(必传)
     */
    @JsonProperty(value = "CHANNEL")
    private String channel;

    /**
     * 是否评估神(必传) 1是 0否
     */
    @JsonProperty(value = "ISDISP")
    private String isDisp;

    /**
     * 客户经理名称
     */
    @JsonProperty(value = "MANAGER")
    private String manager;

    /**
     * 手机号
     */
    @JsonProperty(value = "PHONE")
    private String phone;

    /**
     * 申请金额
     */
    @JsonProperty(value = "REQMONEY")
    private String reqMoney;

    /**
     * 房抵贷(必传) 030:房抵贷
     */
    @JsonProperty(value = "PRIMARYPRODUCT")
    private String primaryProduct;

    /**
     * 人脸识别度
     */
    @JsonProperty(value = "CONTRAST")
    private String contrast;

    /**
     * 报告来源(必传) 第三方:002 陪同:003 自带:004
     */
    @JsonProperty(value = "ORIGINID")
    private String originId;

    /**
     * 查询模式（中兰德时必传） 01：扫描件模式 02：电子签名模式
     */
    @JsonProperty(value = "QUERYMODEL")
    private String queryModel;

    /**
     * 产品ID(必传)
     */
    @JsonProperty(value = "PRODUCTID")
    private String productId;

    /**
     * 个贷服务中心
     */
    @JsonProperty(value = "SERVICECENTER")
    private String serviceCenter;

    /**
     * 登记人
     */
    @JsonProperty(value = "REGISTRAR")
    private String registrar;

    @JsonProperty(value = "ITMODE")
    private String itMode;

    /**
     * 工作数组(必传)
     */
    @JsonProperty(value = "IMAGELIST")
    List<CreditAuthImge> imageList;

    @Getter
    @Setter
    public static class CreditAuthImge {
        /**
         * 文件名，必传
         */
        @JsonProperty(value = "FILENAME")
        private String fileName;

        /**
         * 影像路径，必传
         */
        @JsonProperty(value = "IMAGEPATH")
        private String imagePath;

        /**
         * 影像类型，必传  上海资信查询授权:4240 上海资信身份证:4250 上海资信其他资料:4260
         */
        @JsonProperty(value = "IMAGETYPE")
        private String imageType;
    }
}
