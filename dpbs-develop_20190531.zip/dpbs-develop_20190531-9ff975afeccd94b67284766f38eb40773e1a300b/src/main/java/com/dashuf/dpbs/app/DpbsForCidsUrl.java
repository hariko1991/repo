package com.dashuf.dpbs.app;

public final class DpbsForCidsUrl {
    public static final String DPBS_CIDS_NOTIFY = "/dpbs/appWeb/cids/notify/";
}
