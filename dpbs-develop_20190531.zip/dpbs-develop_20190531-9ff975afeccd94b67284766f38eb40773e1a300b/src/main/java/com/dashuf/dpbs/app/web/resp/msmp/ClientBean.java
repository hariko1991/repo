package com.dashuf.dpbs.app.web.resp.msmp;

import java.io.Serializable;
import java.util.Date;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "我的客户")
@Getter
@Setter
public class ClientBean implements Serializable {
	private static final long serialVersionUID = 4326889152243981603L;
	@ApiModelProperty(value = "推单编号")
	private String pushOrderNo;
	@ApiModelProperty(value = "推单开始时间")
	private Date pushStartTime;
	@ApiModelProperty(value = "推单结束时间")
	private Date pushEndTime;
	@ApiModelProperty(value = "返回码")
	private String rtnCode;
	@ApiModelProperty(value = "返回信息")
	private String rtnMsg;

	@ApiModelProperty(value = "客户编号")
	private String clientNo;
	@ApiModelProperty(value = "客户姓名")
	private String clientName;
	@ApiModelProperty(value = "证件号")
	private String certNo;
	@ApiModelProperty(value = "用户编号")
	private String userNo;
	@ApiModelProperty(value = "用户姓名")
	private String userName;
	@ApiModelProperty(value = "推单状态")
	private String pushStatus;
	@ApiModelProperty(value = "贷款状态")
	private String loanStatus;

	@ApiModelProperty(value = "贷款申请编号")
	private String applicationId;

	@ApiModelProperty(value = "手机号码")
	private String mobileNo;

}
