package com.dashuf.dpbs.sao.cids.resp;

import com.dashuf.dpbs.sao.cids.resp.ds020.Decision;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class QueryScoreDs020Resp implements Serializable {
    private static final long serialVersionUID = -4776735254569599403L;

    @JsonProperty(value = "DECISION_RESPONSE")
    private Decision decision;

    @JsonProperty(value = "RETCODE")
    private String retCode;

    @JsonProperty(value = "RETMSG")
    private String retMsg;
}
