package com.dashuf.dpbs.service;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.web.req.msmp.GetUserDetailReq;
import com.dashuf.dpbs.app.web.resp.msmp.MyUserDetailResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.model.UserInfo;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dashuf.dpbs.app.web.resp.msmp.ClientBean;
import com.dashuf.dpbs.app.web.resp.msmp.UserBean;
import com.dashuf.dpbs.mapper.MsmpSupportMapper;
import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;

import java.math.BigDecimal;
import java.util.Map;

@Service
@Slf4j
public class MsmpSupportService {
    @Autowired
    private MsmpSupportMapper msmpSupportMapper;

    public PageInfo<ClientBean> selectClientPage(Integer startPage, Integer pageSize, String clientManager, String clientName) {
        PageHelper.startPage(startPage, pageSize);
        return PageInfo.of(msmpSupportMapper.getClientList(clientManager, clientName));
    }

    public PageInfo<UserBean> selectUserPage(Integer startPage, Integer pageSize, String clientManager, String userName) {
        PageHelper.startPage(startPage, pageSize);
        return PageInfo.of(msmpSupportMapper.getUserList(clientManager, userName));
    }

    public PageInfo<ClientBean> selectPendClientPage(Integer startPage, Integer pageSize, String userNo, String clientName) {
        PageHelper.startPage(startPage, pageSize);
        return PageInfo.of(msmpSupportMapper.getPendClientList(userNo, clientName));
    }

    public PageInfo<ClientBean> selectAlreadyClientPage(Integer startPage, Integer pageSize, String userNo, String clientName) {
        PageHelper.startPage(startPage, pageSize);
        return PageInfo.of(msmpSupportMapper.getAlreadyClientList(userNo, clientName));
    }

    public int modifyUserCompany(String userNo, String srcChannel, String srcChannelCode) {
        UserInfo userInfoParam = new UserInfo();
        userInfoParam.setUserNo(userNo);
        userInfoParam.setSrcChannelCode(srcChannelCode);
        userInfoParam.setSrcChannel(srcChannel);
        if (StringUtils.isNotEmpty(srcChannelCode)) {
            userInfoParam.setUserType("exclusive");
        } else {
            userInfoParam.setUserType("personal");
        }

        return msmpSupportMapper.modifyUserCompany(userInfoParam);
    }

    public MyUserDetailResp getDetail(GetUserDetailReq getUserRefReq, JSONObject jsonObj) {
        UserBean userBean = msmpSupportMapper.getDetailOfUser(getUserRefReq.getUserNo());
        if (null == userBean) {
            jsonObj.put(DpbsCnst.RTN_MSG, "所查询用户不存在");
            return null;
        }

        MyUserDetailResp myUserDetailResp = new MyUserDetailResp();
        BeanUtils.copyProperties(userBean, myUserDetailResp);

        Map<String, Object> statMap = msmpSupportMapper.statUserReconForm(getUserRefReq.getUserNo());
        log.info("用户[{}]获取推单量和放款金额:{}", getUserRefReq.getUserNo(), statMap);

        myUserDetailResp.setPayAmt(null == statMap.get("total_pay_amt") ? new BigDecimal(0) : new BigDecimal(statMap.get("total_pay_amt").toString()));
        myUserDetailResp.setPushCnt(Long.valueOf(statMap.get("total_cnt").toString()));
        return myUserDetailResp;
    }

}
