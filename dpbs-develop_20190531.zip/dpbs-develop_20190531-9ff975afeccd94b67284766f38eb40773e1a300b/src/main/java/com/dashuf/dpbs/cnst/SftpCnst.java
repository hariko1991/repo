package com.dashuf.dpbs.cnst;

public final class SftpCnst {
    public static final String SFTP_REQ_REMOTE_HOST = "host";
    public static final String SFTP_REQ_REMOTE_PROT = "port";
    public static final String SFTP_REQ_REMOTE_USER = "user";
    public static final String SFTP_REQ_REMOTE_SECRET = "secret";
    public static final String SFTP_REQ_REMOTE_PATH = "remote";
    public static final String SFTP_REQ_REMOTE_TIMEOUT = "timeout";
    public static final String SFTP_REQ_LOCAL_PATH = "local";

    public static final int SFTP_REQ_REMOTE_DEFAULT_TIMEOUT = 6000;
    public static final int SFTP_REQ_REMOTE_DEFAULT_PORT = 22;
}