package com.dashuf.dpbs.app.web;

import java.io.File;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.DpbsUrl;
import com.dashuf.dpbs.app.web.req.support.QueryMovieReq;
import com.dashuf.dpbs.app.web.resp.bean.FileBean;
import com.dashuf.dpbs.app.web.resp.support.QueryMovieResp;
import com.dashuf.dpbs.app.web.resp.support.UploadMovieResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.service.support.MoviePlatRefService;
import com.dashuf.merlin.web.base.views.ResponseVo;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;

@Api(value = "影像平台", tags = {"影像平台相关"})
@Slf4j
@RestController
@RequestMapping(DpbsUrl.MOVIE_PLAT_REF)
public class MoviePlatRefController {
    @Resource
    private MoviePlatRefService moviePlatRefService;

    @ApiOperation(value = "上传影像信息")
    @PostMapping("/uploadMoviePlat")
    public ResponseVo<UploadMovieResp> uploadMoviePlat(@RequestParam("fileList") MultipartFile[] fileList, String stepRefNo, String stepCode) {
        log.info("注册流水号[{}],上传影象平台文件数量[{}]", stepRefNo, null != fileList ? fileList.length : null);

        if (null == fileList || 0 == fileList.length) {
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, "上传文件列表为空,请检查");
        }

        List<File> localFileList = null;
        try {
            localFileList = moviePlatRefService.copyTempFileToServer(fileList);
        } catch (Exception e) {
            log.info("注册流水号[{}],转换文件异常", stepRefNo, e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }

        try {
            JSONObject jsonObj = moviePlatRefService.uploadHandler(stepCode, stepRefNo, localFileList);
            if (null == jsonObj || DpbsCnst.FAIL_RTN_CODE.equals(jsonObj.getString(DpbsCnst.RTN_CODE))) {
                String result = jsonObj == null ? DpbsCnst.SERVER_ERROR : jsonObj.getString(DpbsCnst.RTN_MSG);
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, result);
            }

            UploadMovieResp uploadMovieResp = new UploadMovieResp();
            uploadMovieResp.setApplicationId(stepRefNo);
            uploadMovieResp.setContentId(jsonObj.getString("contentId"));
            uploadMovieResp.setFileIdList(JSONObject.parseArray(jsonObj.getJSONArray("uploadFileList").toJSONString(), String.class));
            return new ResponseVo<>(uploadMovieResp);
        } catch (Exception e) {
            log.error("注册流水号[{}],上传影象平台文件异常:{}", stepRefNo, e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        } finally {
            // 删除临时文件
            moviePlatRefService.deleteTempFileFromServer(localFileList);
        }
    }

    @ApiOperation(value = "查询影像信息")
    @PostMapping("/queryMoviePlat")
    public ResponseVo<QueryMovieResp> queryMoviePlat(@Validated @RequestBody QueryMovieReq queryMovieReq) {
        try {
            JSONObject jsonObj = moviePlatRefService.queryHandler(queryMovieReq.getStepCode(), queryMovieReq.getStepRefNo(), queryMovieReq.getContentId());
            if (null == jsonObj || DpbsCnst.FAIL_RTN_CODE.equals(jsonObj.getString(DpbsCnst.RTN_CODE))) {
                String result = jsonObj == null ? DpbsCnst.SERVER_ERROR : jsonObj.getString(DpbsCnst.RTN_MSG);
                return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, result);
            }

            QueryMovieResp queryMovieResp = new QueryMovieResp();
            queryMovieResp.setStepRefNo(queryMovieReq.getStepRefNo());
            queryMovieResp.setContentId(queryMovieReq.getContentId());
            queryMovieResp.setFileBeanList(JSONObject.parseArray(jsonObj.getJSONArray("queryFileList").toJSONString(), FileBean.class));
            return new ResponseVo<>(queryMovieResp);
        } catch (Exception e) {
            log.error("流水号[{}],上传影象平台文件异常:{}", queryMovieReq.getStepRefNo(), e);
            return ResponseVo.fail(DpbsCnst.FAIL_RTN_CODE, DpbsCnst.SERVER_ERROR);
        }
    }
}
