package com.dashuf.dpbs.sao.credit.resp;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

@Getter
@Setter
public class CreditReport25Resp implements Serializable {
    /**
     * 返回码
     */
    @JsonProperty(value = "RETCODE")
    private String retCode;
    /**
     * 返回信息
     */
    @JsonProperty(value = "RETMSG")
    private String retMsg;
    /**
     * 报告记录列表
     */
    @JsonProperty(value = "REPORTLIST")
    private List<CreditReport> reportList;

    @Getter
    @Setter
    public static class CreditReport {
        /**
         * 报告编号
         */
        @JsonProperty(value = "REPORTNO")
        private String reportNo;
        /**
         * 报告获取时间
         */
        @JsonProperty(value = "REPORTCREATETIME")
        @JsonFormat(pattern = "yyyy/MM/dd HH:mm:ss")
        private Date reportCreateTime;
        /**
         * 报告来源
         */
        @JsonProperty(value = "ORIGINID")
        private String originId;
    }

}
