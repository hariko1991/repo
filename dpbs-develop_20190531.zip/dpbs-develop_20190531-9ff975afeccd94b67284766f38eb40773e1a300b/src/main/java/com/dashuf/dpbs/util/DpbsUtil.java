package com.dashuf.dpbs.util;

import org.apache.commons.lang3.StringUtils;

import java.text.SimpleDateFormat;
import java.util.Date;

public final class DpbsUtil {
    private static final String YYYY_M_MDD_H_HMMSS_SSS = "yyyyMMddHHmmssSSS";
    public static final String PREFIX_PUSH_ORDER_LOG = "P";
    public static final String PREFIX_INFO_ENTRY_INFO = "I";
    public static final String PREFIX_CLIENT_INFO = "C";
    public static final String PREFIX_USER_INFO = "U";
    public static final String PREFIX_HOUSE_INFO = "H";
    public static final String PREFIX_CREDIT_SUPPLY_INFO = "CS";
    public static final String PREFIX_INSURANCE_INFO = "I";
    public static final String PREFIX_QR_CODE_INFO = "QR";
    public static final String PREFIX_PUSH_MSG_FORM = "PMF";

    public static final String getTableNo(String prefix) {
        SimpleDateFormat sdf = new SimpleDateFormat(YYYY_M_MDD_H_HMMSS_SSS);
        StringBuffer tableUniqueNo = new StringBuffer(prefix);
        tableUniqueNo.append(sdf.format(new Date()));

        tableUniqueNo.append(StringUtils.leftPad((int) (Math.random() * 8888) + "", 4, "0"));
        return tableUniqueNo.toString();
    }


    public static String judgeManOrWoman(String certNo) {
        certNo = certNo.trim();
        if (certNo == null || (certNo.length() != 15 && certNo.length() != 18)) {
            return "2";
        }
        if (certNo.length() == 15 || certNo.length() == 18) {
            String lastValue = certNo.substring(certNo.length() - 1, certNo.length());
            int sex;
            if (lastValue.trim().toLowerCase().equals("x") || lastValue.trim().toLowerCase().equals("e")) {
                return "2";
            } else {
                sex = Integer.parseInt(lastValue) % 2;
                return sex == 0 ? "1" : "2";
            }
        } else {
            return "2";
        }
    }

    public static int judgeAgeByCertNo(String certNo) throws Exception {
        String birthday = "";
        if (certNo.length() == 18) {
            birthday = certNo.substring(6, 10) + "/"
                    + certNo.substring(10, 12) + "/"
                    + certNo.substring(12, 14);
        }
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy/MM/dd");
        Date now = new Date();
        Date birth = sdf.parse(birthday);
        long intervalMilli = now.getTime() - birth.getTime();
        int age = (int) (intervalMilli / (24 * 60 * 60 * 1000)) / 365;
        return age;
    }
}
