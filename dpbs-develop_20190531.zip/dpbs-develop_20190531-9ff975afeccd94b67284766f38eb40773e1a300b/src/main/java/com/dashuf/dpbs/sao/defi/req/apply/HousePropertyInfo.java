package com.dashuf.dpbs.sao.defi.req.apply;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class HousePropertyInfo implements Serializable {
    private static final long serialVersionUID = -2445610445620096064L;

    /**
     * PreIsMortgage	string　非必须  一押是否按揭
     */
    private String PreIsMortgage;
    /**
     * PreCredtAmount	string　非必须   一押授信金额
     */
    private String PreCredtAmount;
    /**
     * PreMorOS	string　非必须   一押贷款余额
     */
    private String PreMorOS;
    /**
     * PreCollateralAmt	string　非必须　  一押抵押债权金额
     */
    private String PreCollateralAmt;
    /**
     * PreLoanAgency	string　非必须　 一押放款机构
     */
    private String PreLoanAgency;
    /**
     * PreLoanAgencyType	string　非必须　 一押放款机构类型
     */
    private String PreLoanAgencyType;
    /**
     * MutIDType1	string　非必须  共同产权人1的证件类型
     */
    private String MutIDType1;
    /**
     * MutID01	string　 非必须   共同产权人1的证件号码
     */
    private String MutID01;
    /**
     * MutIDType2	string　非必须   共同产权人2的证件类型
     */
    private String MutIDType2;
    /**
     * MutID02	string　非必须   共同产权人2的证件号码
     */
    private String MutID02;
    /**
     * MutIDType3	string　非必须   共同产权人3的证件类型
     */
    private String MutIDType3;
    /**
     * MutID03	string　非必须   共同产权人3的证件号码
     */
    private String MutID03;
    /**
     * Mut01ProRightRatio	string　非必须　  共同产权人1的产权份额
     */
    private String Mut01ProRightRatio;
    /**
     * Mut02ProRightRatio	string　非必须  共同产权人2的产权份额
     */
    private String Mut02ProRightRatio;
    /**
     * Mut03ProRightRatio	string　非必须   共同产权人3的产权份额
     */
    private String Mut03ProRightRatio;
    /**
     * Liveness	integer　非必须　  世联楼盘活跃度
     */
    private String Liveness;
    /**
     * SLAvePrice	string　非必须　 世联均价
     */
    private String SLAvePrice;
    /**
     * FXTAvePrice	string　非必须  房讯通均价
     */
    private String FXTAvePrice;
    /**
     * YunFPrice	string　非必须   云房均价
     */
    private String YunFPrice;
    /**
     * ManuallyAvePrice	string　非必须　  人工录入均价
     */
    private String ManuallyAvePrice;
    /**
     * Housevalue	string　非必须　 房产综合价值
     */
    private String Housevalue;
    /**
     * PledgeHousework	string　 非必须  房屋结构
     */
    private String PledgeHousework;
    /**
     * RentoutCondition	string　非必须   出租情况
     */
    private String RentoutCondition;
    /**
     * LandSource	string　非必须 土地使用权取得方式/类型
     */
    private String LandSource;
    /**
     * LandType	string 非必须　地类
     */
    private String LandType;
    /**
     * HousePropertyType	string　非必须　房屋用途
     */
    private String HousePropertyType;
    /**
     * HouseType	string 非必须  房屋性质
     */
    private String houseType;
    /**
     * HouseAge	string　非必须　房龄
     */
    private String HouseAge;
    /**
     * CompDate	string　非必须 竣工日期
     */
    private String CompDate;
    /**
     * HousePosDate	string　非必须　   持有房产日期
     */
    private String HousePosDate;

    private String houseAddress;

}
