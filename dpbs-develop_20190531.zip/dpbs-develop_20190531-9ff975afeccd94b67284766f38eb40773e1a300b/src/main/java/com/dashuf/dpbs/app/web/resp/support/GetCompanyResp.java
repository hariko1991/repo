package com.dashuf.dpbs.app.web.resp.support;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.util.List;

@ApiModel(value = "分公司查询resp")
@Getter
@Setter
public class GetCompanyResp implements Serializable {
    private static final long serialVersionUID = 5547414753803076808L;

    @ApiModelProperty(value = "公司集合")
    private List<CompnayOfUm> compnayList;

    @ApiModel(value = "用户所属公司")
    @Getter
    @Setter
    public static class CompnayOfUm {

        @ApiModelProperty(value = "公司编码")
        private String companyCode;


        @ApiModelProperty(value = "公司名称")
        private String companyName;

    }

}
