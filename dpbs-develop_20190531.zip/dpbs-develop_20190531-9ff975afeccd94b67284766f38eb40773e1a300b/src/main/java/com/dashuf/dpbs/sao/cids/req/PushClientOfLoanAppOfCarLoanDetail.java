package com.dashuf.dpbs.sao.cids.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
public class PushClientOfLoanAppOfCarLoanDetail implements Serializable {
    /**
     * loanAmt	number 非必须 车贷贷款金额（有车贷时必传）
     */
    private BigDecimal loanAmt;
    /**
     * monthlyRepaymentAmt	number 非必须 车贷月还款额（有车贷时必传）
     */
    private BigDecimal monthlyRepaymentAmt;
}
