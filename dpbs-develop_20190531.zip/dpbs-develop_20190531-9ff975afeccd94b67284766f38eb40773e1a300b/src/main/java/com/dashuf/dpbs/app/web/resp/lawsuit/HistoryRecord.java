package com.dashuf.dpbs.app.web.resp.lawsuit;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.util.Date;

/**
 * @author yaojiaoyi
 */
@Getter
@Setter
public class HistoryRecord {
    @ApiModelProperty("查询流水记录编号")
    private Integer requestId;

    @ApiModelProperty("查询日期")
    private Date queryDate;

    @ApiModelProperty("身份证号")
    private String certNo;

    @ApiModelProperty("姓名")
    private String name;
}
