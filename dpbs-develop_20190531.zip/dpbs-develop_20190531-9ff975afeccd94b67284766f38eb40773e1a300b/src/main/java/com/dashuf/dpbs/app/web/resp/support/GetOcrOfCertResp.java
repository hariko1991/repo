package com.dashuf.dpbs.app.web.resp.support;

import io.swagger.annotations.ApiModel;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@ApiModel(value = "识别身份证resp")
@Getter
@Setter
public class GetOcrOfCertResp implements Serializable {
    private static final long serialVersionUID = -2278424776435141754L;

    private String data;
}
