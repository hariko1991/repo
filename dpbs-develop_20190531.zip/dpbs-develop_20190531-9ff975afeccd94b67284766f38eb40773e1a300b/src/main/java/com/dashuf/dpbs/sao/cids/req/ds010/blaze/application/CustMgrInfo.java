package com.dashuf.dpbs.sao.cids.req.ds010.blaze.application;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class CustMgrInfo implements Serializable {
    private static final long serialVersionUID = -2616710127545374759L;

    /**
     * "orgid": "100500",
     */
    private String orgid;
    /**
     * "serialNo": "HOUZHUANG",
     */
    private String serialNo;
    /**
     * "teamNo": "005001"
     */
    private String teamNo;
}
