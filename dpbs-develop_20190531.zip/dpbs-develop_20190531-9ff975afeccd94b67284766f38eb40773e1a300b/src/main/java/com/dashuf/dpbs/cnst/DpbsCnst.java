package com.dashuf.dpbs.cnst;

import org.springframework.http.HttpStatus;

public final class DpbsCnst {
    public static final int NUMBER_1 = 1;

    public static final String RTN_CODE = "rtnCode";
    public static final String RTN_MSG = "rtnMsg";

    public static final String SUCCESS_RTN_CODE = "success";
    public static final String FAIL_RTN_CODE = "fail";

    public static final String HTTP_OK = HttpStatus.OK.toString();

    public static final String SYSTEM_NAME = "DISP";
    public static final String PUSH_ORDER_NO = "pushOrderNo";

    public static final String VERTICAL_SYMBOL = "_";

    public static final String TRUE_STR = "true";
    public static final boolean SQL_PRECISE_STRICT = true;


    public static final String REDIS_DPBS_LOGIN = "DPBS:LOGIN:";
    public static final String REDIS_DPBS_LOCK = "DPBS:LOCK:";
    public static final String REDIS_DPBS_VERIFY_CODE = "DPBS:VERIFY:CODE:";
    public static final String REDIS_DPBS_SYS_CONF = "DPBS:SYS:CONF:";
    public static final String COMMA_REGEX = ",";
    public static final String SERVER_ERROR = "系统异常";
    public static final String VERIFIED = "true";//已实认证
    public static final String NOT_VERIFIED = "false";//未实名认证
    public static final String STOP_USE = "stop_use";//停用
    public static final String FORBID_PUSH = "forbid_push";//禁止推单
    public static final String GET_METHOD = "get";
    public static final String SET_METHOD = "set";


    public static final String FINAL_STATUS_IND_1 = "1";
}

