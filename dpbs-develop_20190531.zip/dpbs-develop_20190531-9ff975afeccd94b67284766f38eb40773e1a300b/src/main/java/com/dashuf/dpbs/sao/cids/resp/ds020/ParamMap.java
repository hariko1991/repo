package com.dashuf.dpbs.sao.cids.resp.ds020;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class ParamMap implements Serializable {
    private static final long serialVersionUID = 2589206241756978009L;

    private String engineNode;
    private String systemId;
}
