package com.dashuf.dpbs.sao.ucss.resp;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class GetDetailOfUserResp implements Serializable {

    private String userId;
    private String userName;
    private String mobilePhoneNum;
    private String statusCode;
    private String updatedBy;
}
