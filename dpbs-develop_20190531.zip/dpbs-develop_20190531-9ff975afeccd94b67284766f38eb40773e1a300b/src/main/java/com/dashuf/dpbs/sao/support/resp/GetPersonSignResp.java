package com.dashuf.dpbs.sao.support.resp;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Setter
@Getter
public class GetPersonSignResp implements Serializable {
    private String fileId;
}
