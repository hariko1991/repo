package com.dashuf.dpbs.util;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.BeanProperty;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.JsonSerializer;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.ContextualSerializer;
import org.apache.commons.lang3.StringUtils;
import org.springframework.format.annotation.NumberFormat;

import java.io.IOException;
import java.math.BigDecimal;
import java.text.DecimalFormat;

public class BigDecimalJsonSerializer extends JsonSerializer<BigDecimal> implements ContextualSerializer {
	private String pattern = "##.00";

	public BigDecimalJsonSerializer() {
		this("##.00");
	}

	public BigDecimalJsonSerializer(String pattern) {
		this.pattern = pattern;
	}

	@Override
	public void serialize(BigDecimal value, JsonGenerator jgen, SerializerProvider provider) throws IOException, JsonProcessingException {
		if (value != null) {
			if (StringUtils.isNotBlank(pattern)) {
				DecimalFormat decimalFormat = new DecimalFormat(pattern);
				jgen.writeString(decimalFormat.format(value));

			} else {
				jgen.writeString(value.toString());
			}
		}
	}

	@Override
	public JsonSerializer<?> createContextual(SerializerProvider prov, BeanProperty property) throws JsonMappingException {
		if (property != null) {
			if (Number.class.isAssignableFrom(property.getType().getRawClass())) {
				NumberFormat format = property.getAnnotation(NumberFormat.class);
				if (format == null) {
					format = property.getContextAnnotation(NumberFormat.class);
				}
				if (format != null) {
					return new BigDecimalJsonSerializer(format.pattern());
				}
			}
			return prov.findValueSerializer(property.getType(), property);
		}
		return prov.findNullValueSerializer(null);
	}

}