package com.dashuf.dpbs.sao.cids.req.ds020.blaze.application;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class IntermediaryInfo implements Serializable {
    private static final long serialVersionUID = -2339582075383775499L;

    /**
     * "channelCode": "7eb21222a9c34c61a8f0c75d58e0334c",
     */
    private String channelCode;
    /**
     * "channelHeadCell": "13466350330",
     */
    private String channelHeadCell;
    /**
     * "channelHeadId": "110109199302211217",
     */
    private String channelHeadId;
    /**
     * "channelHeadName": "侯壮",
     */
    private String channelHeadName;
    /**
     * "channelName": "7eb21222a9c34c61a8f0c75d58e0334c",
     */
    private String channelName;
    /**
     * "channelType": "01"
     */
    private String channelType;
}
