package com.dashuf.dpbs.service;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.web.req.push.GiveUpPushOrderReq;
import com.dashuf.dpbs.app.web.req.push.InfoEntryReq;
import com.dashuf.dpbs.app.web.req.push.InitPushOrderReq;
import com.dashuf.dpbs.app.web.req.push.ScanCertReq;
import com.dashuf.dpbs.app.web.resp.QrCodeResp;
import com.dashuf.dpbs.app.web.resp.push.GetScoreResp;
import com.dashuf.dpbs.app.web.resp.push.InfoEntryResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.DpbsStatusCnst;
import com.dashuf.dpbs.cnst.RtnCodeCnst;
import com.dashuf.dpbs.mapper.ClientInfoMapper;
import com.dashuf.dpbs.mapper.UserInfoMapper;
import com.dashuf.dpbs.model.ClientInfo;
import com.dashuf.dpbs.model.PushOrderLog;
import com.dashuf.dpbs.model.UserInfo;
import com.dashuf.dpbs.sao.icp.req.CheckIDCardReq;
import com.dashuf.dpbs.sao.laapp.req.AllowPushClientReq;
import com.dashuf.dpbs.service.cpms.ClientTradingSupportService;
import com.dashuf.dpbs.service.laapp.AppBlazeService;
import com.dashuf.dpbs.service.support.IcpAuthSupportService;
import com.dashuf.dpbs.service.support.MoviePlatRefService;
import com.dashuf.dpbs.util.DpbsUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.Date;
import java.util.List;

@Slf4j
@Service
public class PushOrderSupportService {
    private static final String PUSH_ORDER_MOVIE_UPLOAD = "pushOrderMovieUpload";
    @Autowired
    private MoviePlatRefService moviePlatRefService;
    @Autowired
    private PushOrderLogService pushOrderLogService;
    @Autowired
    private ClientTradingSupportService clientTradingSupportService;
    @Autowired
    private ClientInfoMapper clientInfoMapper;
    @Autowired
    private UserInfoMapper userInfoMapper;
    @Autowired
    private IcpAuthSupportService icpAuthSupportService;
    @Autowired
    private QrCodeSupportService qrCodeSupportService;
    @Autowired
    private AppBlazeService appBlazeService;

    public GetScoreResp getScore(String pushOrderNo, JSONObject jsonObj) {
        PushOrderLog pushOrderLogParam = new PushOrderLog();
        pushOrderLogParam.setPushOrderNo(pushOrderNo);
        PushOrderLog pushOrderLog = pushOrderLogService.selectOneByModelSelective(pushOrderLogParam, DpbsCnst.SQL_PRECISE_STRICT);
        if (null == pushOrderLog) {
            jsonObj.put(DpbsCnst.RTN_MSG, "对应推单不存在");
            return null;
        }

        ClientInfo clientInfoParam = new ClientInfo();
        clientInfoParam.setClientNo(pushOrderLog.getClientNo());
        ClientInfo clientInfo = clientInfoMapper.selectOneByModelSelective(clientInfoParam, DpbsCnst.SQL_PRECISE_STRICT);

        GetScoreResp getScoreResp = new GetScoreResp();
        getScoreResp.setLoanAmt(pushOrderLog.getEvalLoanAmt());
        getScoreResp.setPayMonthAmt(pushOrderLog.getEvalPayMonthAmt());
        getScoreResp.setValidDate(pushOrderLog.getEvalExpireTime());
        getScoreResp.setClientName(clientInfo.getClientName());
        return getScoreResp;
    }

    public boolean initPushOrder(String loginUserNo, JSONObject jsonObj) {
        UserInfo userInfoParam = new UserInfo();
        userInfoParam.setUserNo(loginUserNo);
        UserInfo userInfo = userInfoMapper.selectQuiqueUserInfo(userInfoParam);

        if (DpbsCnst.STOP_USE.equals(userInfo.getStatus())) {
            jsonObj.put(DpbsCnst.RTN_CODE, RtnCodeCnst.USER_STOP_USED);
            jsonObj.put(DpbsCnst.RTN_MSG, "您已经被停用，请联系客户经理");
            return false;
        }
        if (DpbsCnst.FORBID_PUSH.equals(userInfo.getStatus())) {
            jsonObj.put(DpbsCnst.RTN_CODE, RtnCodeCnst.USER_FORBID_PUSH);
            jsonObj.put(DpbsCnst.RTN_MSG, "您已经被禁止推单了，请联系客户经理");
            return false;
        }

        if (StringUtils.isEmpty(userInfo.getSrcUmNo())) {
            jsonObj.put(DpbsCnst.RTN_CODE, RtnCodeCnst.RTN_CODE_NEED_BIND_CLIENT_MANAGER);
            jsonObj.put(DpbsCnst.RTN_MSG, "请先绑定客户经理后再进行推单操作");
            return false;
        }

        if (DpbsCnst.NOT_VERIFIED.equals(userInfo.getIsVerify())) {
            jsonObj.put(DpbsCnst.RTN_CODE, RtnCodeCnst.RTN_CODE_NEED_VERIFY_CERT);
            jsonObj.put(DpbsCnst.RTN_MSG, "请先进行实名认证");
            return false;
        }
        return true;
    }

    public boolean scanCert(ScanCertReq scanCertReq, JSONObject jsonObj) throws Exception {
        AllowPushClientReq allowPushClientReq = new AllowPushClientReq();
        allowPushClientReq.setCertificateNum(scanCertReq.getCertNo());
        allowPushClientReq.setCustName(scanCertReq.getClientName());
        allowPushClientReq.setCertificateType("Ind01");
        if (!appBlazeService.queyClientIsAllownPush(allowPushClientReq, jsonObj)) {
            return false;
        }

        UserInfo userInfo = new UserInfo();
        userInfo.setUserNo(scanCertReq.getUserNo());
        userInfo = userInfoMapper.selectQuiqueUserInfo(userInfo);

        if (StringUtils.isEmpty(userInfo.getSrcUmNo())) {
            jsonObj.put(DpbsCnst.RTN_MSG, "请先绑定客户经理后再进行推单操作");
            return false;
        }

        String pushOrderNo = DpbsUtil.getTableNo(DpbsUtil.PREFIX_PUSH_ORDER_LOG);
        scanCertReq.setPushOrderNo(pushOrderNo);

        PushOrderLog pushOrderLog = new PushOrderLog();
        pushOrderLog.setPushOrderNo(pushOrderNo);

        ClientInfo clientInfo = new ClientInfo();
        PropertyUtils.copyProperties(clientInfo, scanCertReq);
        String clientNo = DpbsUtil.getTableNo(DpbsUtil.PREFIX_CLIENT_INFO);
        clientInfo.setClientNo(clientNo);
        clientInfo.setGenderCd(DpbsUtil.judgeManOrWoman(clientInfo.getCertNo()));
        clientInfo.setClientAge(DpbsUtil.judgeAgeByCertNo(clientInfo.getCertNo()));
        clientInfo.setReconUserNo(scanCertReq.getUserNo());
        pushOrderLog.setClientNo(clientNo);
        pushOrderLog.setCertNo(clientInfo.getCertNo());

        // according to the credit, judge the client is or not inTrading
        if (!clientTradingSupportService.inTrading(scanCertReq.getClientName(), scanCertReq.getCertNo(), jsonObj)) {
            return false;
        }

        // judge the idcard and idname is right
        CheckIDCardReq checkIDCardReq = new CheckIDCardReq();
        checkIDCardReq.setIdcardName(clientInfo.getClientName());
        checkIDCardReq.setIdcardNo(clientInfo.getCertNo());
        if (!icpAuthSupportService.checkPersonMsg(checkIDCardReq, jsonObj)) {
            return false;
        }

        // init the client info t
        int dealCnt = clientInfoMapper.initSingleClientInfo(clientInfo);
        log.info("初始化客户[{}]证件号[{}]客户编号[{}]结果记录:[{}]", clientInfo.getClientName(), clientInfo.getCertNo(), clientInfo.getClientNo(), dealCnt);

        dealCnt = pushOrderLogService.initPushOrder(pushOrderNo);
        if (DpbsCnst.NUMBER_1 != dealCnt) {
            jsonObj.put(DpbsCnst.RTN_MSG, "初始化推单记录失败");
            return false;
        }

        // update the push order log last
        pushOrderLog.setClientNo(clientNo);
        pushOrderLog.setUserNo(scanCertReq.getUserNo());
        pushOrderLog.setRtnCode(jsonObj.getString(DpbsCnst.RTN_CODE));
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setRtnMsg(jsonObj.getString(DpbsCnst.RTN_MSG));
        pushOrderLog.setPushStatus(DpbsStatusCnst.PUSH_SCAN);
        if (!pushOrderLogService.updatePushOrderLogByOrgStatus(pushOrderLog, DpbsStatusCnst.PUSH_INIT, jsonObj)) {
            return false;
        }
        return true;
    }

    public boolean uploadImg(MultipartFile[] fileList, String pushOrderNo, JSONObject jsonObj) {
        PushOrderLog pushOrderLog = new PushOrderLog();
        pushOrderLog.setPushOrderNo(pushOrderNo);
        if (!doUploadImg(fileList, pushOrderNo, jsonObj)) {
            return false;
        } else {
            pushOrderLog.setPushStatus(DpbsStatusCnst.PUSH_MOVIE);
        }

        pushOrderLog.setMovieNo(jsonObj.getString("contentId"));
        pushOrderLog.setRtnCode(jsonObj.getString(DpbsCnst.RTN_CODE));
        pushOrderLog.setRtnMsg(jsonObj.getString(DpbsCnst.RTN_MSG));

        if (!pushOrderLogService.updatePushOrderLogByOrgStatus(pushOrderLog, DpbsStatusCnst.PUSH_SCAN, jsonObj)) {
            return false;
        }

        return true;
    }

    private boolean doUploadImg(MultipartFile[] fileList, String pushOrderNo, JSONObject jsonObj) {
        List<File> localFileList = null;
        try {
            localFileList = moviePlatRefService.copyTempFileToServer(fileList);
        } catch (Exception e) {
            log.error("推单流水号[{}],转换文件异常:{}", pushOrderNo, e);
            jsonObj.put(DpbsCnst.RTN_MSG, DpbsCnst.SERVER_ERROR);
            return false;
        }

        try {
            JSONObject rtnObj = moviePlatRefService.uploadHandler(PUSH_ORDER_MOVIE_UPLOAD, pushOrderNo, localFileList);
            String rtnCode = rtnObj == null ? DpbsCnst.FAIL_RTN_CODE : rtnObj.getString(DpbsCnst.RTN_CODE);
            String rtnMsg = rtnObj == null ? DpbsCnst.SERVER_ERROR : rtnObj.getString(DpbsCnst.RTN_MSG);
            if (null == rtnObj || DpbsCnst.FAIL_RTN_CODE.equals(rtnObj.getString(DpbsCnst.RTN_CODE))) {
                jsonObj.put(DpbsCnst.RTN_MSG, rtnMsg);
                jsonObj.put(DpbsCnst.RTN_CODE, rtnCode);
                return false;
            }
            jsonObj.put("contentId", rtnObj.getString("contentId"));
            return true;
        } catch (Exception e) {
            log.error("推单流水号[{}],上传影象平台文件异常:{}", pushOrderNo, e);
            jsonObj.put(DpbsCnst.RTN_MSG, DpbsCnst.SERVER_ERROR);
            return false;
        } finally {
            moviePlatRefService.deleteTempFileFromServer(localFileList);
        }
    }

    public boolean infoEntry(InfoEntryReq infoEntryReq, JSONObject jsonObj) throws Exception {
        PushOrderLog pushOrderLog = new PushOrderLog();
        pushOrderLog.setPushOrderNo(infoEntryReq.getPushOrderNo());

        if (!pushOrderLogService.fullPushOrderLog(infoEntryReq, jsonObj, pushOrderLog)) {
            return false;
        }

        pushOrderLog.setPushStatus(DpbsStatusCnst.PUSH_ENTRY);
        if (!pushOrderLogService.updatePushOrderLogByOrgStatus(pushOrderLog, DpbsStatusCnst.PUSH_MOVIE, jsonObj)) {
            return false;
        }
        return true;
    }


    public boolean initCreditAuthPage(String pushOrderNo, InfoEntryResp infoEntryResp, JSONObject jsonObj) {
        QrCodeResp qrCodeResp = qrCodeSupportService.initQrCodeResp(pushOrderNo, jsonObj);

        if (null == qrCodeResp) {
            return false;
        }

        infoEntryResp.setPushOrderNo(pushOrderNo);
        BeanUtils.copyProperties(qrCodeResp, infoEntryResp);
        return true;
    }

    public boolean giveUpPushOrder(GiveUpPushOrderReq giveUpPushOrderReq, JSONObject jsonObj) {
        PushOrderLog pushOrderLog = new PushOrderLog();
        pushOrderLog.setPushOrderNo(giveUpPushOrderReq.getPushOrderNo());

        pushOrderLog.setPushStatus(DpbsStatusCnst.PUSH_FAIL);
        if (!pushOrderLogService.giveUpPushOrderLog(pushOrderLog, jsonObj)) {
            return false;
        }
        return true;
    }
}
