package com.dashuf.dpbs.sao.laapp.req.subscribe;

import com.fasterxml.jackson.annotation.JsonFormat;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

@Getter
@Setter
public class Taxes implements Serializable {
    private static final long serialVersionUID = -6488972882352783377L;

    @ApiModelProperty(value = "近一年缴税金额")
    private BigDecimal nearlyYearTaxesAmt;

    @ApiModelProperty(value = "借款人最早交税日期")
    @JsonFormat(pattern = "yyyy-MM-dd")
    @DateTimeFormat(pattern = "yyyy-MM-dd")
    private Date earliestTaxesDttm;

    @ApiModelProperty(value = "是否有未缴清税款 0： 否， 1： 是")
    private String outstandingTaxesInd;
}
