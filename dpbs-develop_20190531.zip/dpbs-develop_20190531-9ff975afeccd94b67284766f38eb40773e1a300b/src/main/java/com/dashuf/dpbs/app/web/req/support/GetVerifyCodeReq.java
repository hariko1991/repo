package com.dashuf.dpbs.app.web.req.support;

import java.io.Serializable;

import javax.validation.constraints.NotBlank;
import javax.validation.constraints.Pattern;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

@ApiModel(value = "获取验证码Req")
@Getter
@Setter
public class GetVerifyCodeReq implements Serializable {
    private static final long serialVersionUID = -5290251496172927734L;
    /**
     * 手机号码
     */
    @ApiModelProperty(value = "手机号码")
    @NotBlank(message = "请输入正确的手机号")
    @Pattern(regexp = "^[1][0-9]{10}$", message = "请输入正确的手机号")
    private String mobileNo;

    @ApiModelProperty(value = "模块编码")
    @NotBlank(message = "请输入正确的模块编码")
    private String moduleCode;
}
