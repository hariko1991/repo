package com.dashuf.dpbs.service;

import com.alibaba.fastjson.JSONObject;
import com.dashuf.dpbs.app.web.req.center.*;
import com.dashuf.dpbs.app.web.req.user.VerifyCertReq;
import com.dashuf.dpbs.app.web.resp.center.GetContactMsgResp;
import com.dashuf.dpbs.app.web.resp.center.GetPersonCenterResp;
import com.dashuf.dpbs.cnst.DpbsCnst;
import com.dashuf.dpbs.cnst.SysConfCnst;
import com.dashuf.dpbs.mapper.UserInfoMapper;
import com.dashuf.dpbs.model.SysConf;
import com.dashuf.dpbs.model.UserInfo;
import com.dashuf.dpbs.sao.icp.req.CheckIDCardReq;
import com.dashuf.dpbs.service.cpms.MarketManagerSupportService;
import com.dashuf.dpbs.service.support.ElecSignService;
import com.dashuf.dpbs.service.support.IcpAuthSupportService;
import com.dashuf.dpbs.service.support.VerifyCodeService;
import com.dashuf.dpbs.service.support.dto.ElecCreditAuthDto;
import com.dashuf.dpbs.service.ucss.UserAuthSupportService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.BeanUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PersonCenterSupportService {
    @Autowired
    private VerifyCodeService verifyCodeService;
    @Autowired
    private UserInfoMapper userInfoMapper;
    @Autowired
    private IcpAuthSupportService icpAuthSupportService;
    @Autowired
    private SysConfSupportService sysConfSupportService;
    @Autowired
    private ElecSignService elecSignService;
    @Autowired
    private MarketManagerSupportService marketManagerSupportService;

    public boolean modifyMobileNo(ModifyMobileNoReq modifyMobileNoReq, JSONObject jsonObj) {
        if (!verifyCodeService.checkVerifyCode(SysConfCnst.USER_MODIFY_MOBILE_NO, modifyMobileNoReq.getMobileNo(), modifyMobileNoReq.getVerifyCode(), jsonObj)) {
            return false;
        }

        UserInfo userInfo = new UserInfo();
        userInfo.setUserNo(modifyMobileNoReq.getUserNo());
        userInfo.setMobileNo(modifyMobileNoReq.getMobileNo());

        int dealCnt = userInfoMapper.updateMobileNoOfUser(userInfo, modifyMobileNoReq.getSrcMobileNo());

        if (DpbsCnst.NUMBER_1 != dealCnt) {
            jsonObj.put(DpbsCnst.RTN_MSG, "该号码已注册，如有需要可联系您的专属客户经理");
            return false;
        }
        return true;
    }

    public boolean verifyMobileNo(VerifyMobileNoReq verifyMobileNoReq, JSONObject jsonObj) {
        UserInfo userInfoParam = new UserInfo();
        userInfoParam.setUserNo(verifyMobileNoReq.getUserNo());
        userInfoParam.setMobileNo(verifyMobileNoReq.getMobileNo());

        UserInfo userInfo = userInfoMapper.selectQuiqueUserInfo(userInfoParam);

        if (null != userInfo) {
            jsonObj.put(DpbsCnst.RTN_MSG, "该号码已注册，如有需要可联系您的专属客户经理");
            return false;
        }

        return true;
    }

    private boolean signFileList(VerifyCertReq verifyCertReq, JSONObject jsonObj) {
        ElecCreditAuthDto elecCreditAuthDto = new ElecCreditAuthDto();
        elecCreditAuthDto.setCertNo(verifyCertReq.getCertNo());
        elecCreditAuthDto.setMobileNo(verifyCertReq.getMobileNo());
        elecCreditAuthDto.setCertName(verifyCertReq.getUserName());
        elecCreditAuthDto.setModuleCode("user_reg");
        elecCreditAuthDto.setModuleSubCode("reg_agreement");
        elecCreditAuthDto.setSave(true);

        if (!elecSignService.elecCreditAuth(elecCreditAuthDto, jsonObj)) {
            return false;
        }

        /*elecCreditAuthDto.setModuleCode("client_credit_auth");
        elecCreditAuthDto.setModuleSubCode("file3");
        if (!elecSignService.elecCreditAuth(elecCreditAuthDto, jsonObj)) {
            return false;
        }*/

        return true;
    }


    public boolean verifyCert(VerifyCertReq verifyCertReq, JSONObject jsonObj) {
        if (!verifyCodeService.checkVerifyCode(SysConfCnst.USER_CERT_AUTH, verifyCertReq.getMobileNo(), verifyCertReq.getVerifyCode(), jsonObj)) {
            return false;
        }

        if (!signFileList(verifyCertReq, jsonObj)) {
            return false;
        }

        CheckIDCardReq checkIDCardReq = new CheckIDCardReq();
        checkIDCardReq.setIdcardName(verifyCertReq.getUserName());
        checkIDCardReq.setIdcardNo(verifyCertReq.getCertNo());
        if (!icpAuthSupportService.checkPersonMsg(checkIDCardReq, jsonObj)) {
            return false;
        }

        UserInfo userInfoParam = new UserInfo();
        userInfoParam.setUserNo(verifyCertReq.getUserNo());
        userInfoParam.setUserName(verifyCertReq.getUserName());
        userInfoParam.setCertNo(verifyCertReq.getCertNo());
        userInfoParam.setSrcChannel(verifyCertReq.getSrcChannel());
        userInfoParam.setSrcChannelCode(verifyCertReq.getSrcChannelCode());
        userInfoParam.setIsVerify(DpbsCnst.VERIFIED);
        if (StringUtils.isNotEmpty(verifyCertReq.getSrcChannelCode())) {
            userInfoParam.setUserType("exclusive");
        } else {
            userInfoParam.setUserType("personal");
        }

        int dealCnt = userInfoMapper.updateUserInfo(userInfoParam);
        if (DpbsCnst.NUMBER_1 != dealCnt) {
            jsonObj.put(DpbsCnst.RTN_MSG, "用户实名认证失败");
            return false;
        }
        return true;
    }

    public GetPersonCenterResp getPersonCenter(GetPersonCenterReq getPersonCenterReq, JSONObject jsonObj) {
        UserInfo userInfoParam = new UserInfo();
        userInfoParam.setUserNo(getPersonCenterReq.getUserNo());

        UserInfo userInfo = userInfoMapper.selectQuiqueUserInfo(userInfoParam);
        if (null == userInfo) {
            return null;
        }

        GetPersonCenterResp getPersonCenterResp = new GetPersonCenterResp();
        BeanUtils.copyProperties(userInfo, getPersonCenterResp);
        return getPersonCenterResp;
    }

    public boolean bindClientManager(BindClientManagerReq bindClientManagerReq, JSONObject jsonObj) {
        UserInfo userInfoParam = new UserInfo();
        userInfoParam.setUserNo(bindClientManagerReq.getUserNo());
        userInfoParam.setSrcUmNo(bindClientManagerReq.getSrcUmNo().toUpperCase());
        userInfoParam.setSrcUmName(bindClientManagerReq.getSrcUmName());
        userInfoParam.setSrcUmMobileNo(bindClientManagerReq.getSrcUmMobileNo());
        userInfoParam.setSrcCompany(bindClientManagerReq.getSrcCompany());
        userInfoParam.setSrcCompanyCode(bindClientManagerReq.getSrcCompanyCode());
        userInfoParam.setSrcTeam(bindClientManagerReq.getTeamName());
        userInfoParam.setSrcTeamCode(bindClientManagerReq.getTeamCode());

        int dealCnt = userInfoMapper.updateUserInfo(userInfoParam);
        if (DpbsCnst.NUMBER_1 != dealCnt) {
            jsonObj.put(DpbsCnst.RTN_MSG, "用户绑定客户经理失败");
            return false;
        }
        return true;
    }

    public boolean unBindClientManager(UnBindClientManagerReq unBindClientManagerReq, JSONObject jsonObj) {
        UserInfo userInfoParam = new UserInfo();
        userInfoParam.setUserNo(unBindClientManagerReq.getUserNo());

        int dealCnt = userInfoMapper.unBindClientManager(userInfoParam);
        if (DpbsCnst.NUMBER_1 != dealCnt) {
            jsonObj.put(DpbsCnst.RTN_MSG, "用户解绑客户经理失败");
            return false;
        }
        return true;
    }

    public GetContactMsgResp getContactMsg(GetContactMsgReq getContactMsgReq, JSONObject jsonObj) {
        UserInfo userInfoParam = new UserInfo();
        userInfoParam.setUserNo(getContactMsgReq.getUserNo());

        GetContactMsgResp getContactMsgResp = new GetContactMsgResp();
        if (StringUtils.isNotEmpty(getContactMsgReq.getUserNo())) {
            UserInfo userInfo = userInfoMapper.selectQuiqueUserInfo(userInfoParam);

            if (null != userInfo) {
                BeanUtils.copyProperties(userInfo, getContactMsgResp);
            }
        }

        SysConf sysConfParam = new SysConf();
        sysConfParam.setModuleCode("person_center");
        sysConfParam.setModuleSubCode("contact_us");
        sysConfParam.setModuleKey("service_time");
        getContactMsgResp.setClientServicePhone(sysConfSupportService.selectValueFromCache(sysConfParam));
        sysConfParam.setModuleKey("client_service_phone");
        getContactMsgResp.setServiceTime(sysConfSupportService.selectValueFromCache(sysConfParam));
        return getContactMsgResp;
    }
}
