package com.dashuf.dpbs.sao.wx.req;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

@Getter
@Setter
public class GetDashuQrTicketReq implements Serializable {

    private String sceneStr;

    private String expireSeconds;

    private String replyInfo;
}
