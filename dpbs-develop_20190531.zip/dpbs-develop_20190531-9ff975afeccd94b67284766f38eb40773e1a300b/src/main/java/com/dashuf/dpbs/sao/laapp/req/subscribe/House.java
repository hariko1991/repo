package com.dashuf.dpbs.sao.laapp.req.subscribe;

import io.swagger.annotations.ApiModelProperty;
import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;
import java.math.BigDecimal;

@Getter
@Setter
public class House implements Serializable {
    @ApiModelProperty(value = "房产地址code")
    private String addressCode;

    @ApiModelProperty(value = "房产地址name")
    private String addressName;

    @ApiModelProperty(value = "房屋性质")
    private String estatesTypeCode;

    @ApiModelProperty(value = "房产价值（万元）")
    private BigDecimal totalPriceAmt;

}
