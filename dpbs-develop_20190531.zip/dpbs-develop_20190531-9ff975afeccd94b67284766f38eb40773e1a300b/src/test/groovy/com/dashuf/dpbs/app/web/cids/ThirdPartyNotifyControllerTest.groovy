package com.dashuf.dpbs.app.web.cids

import com.dashuf.dpbs.app.web.req.cids.NofityScoreDs020Req
import com.dashuf.dpbs.app.web.req.cids.NotifyCreditStatusReq
import com.dashuf.dpbs.service.blaze.ThirdPartyAccessSupportService
import spock.lang.Specification

/**
 *
 * Created with IDEA
 * author:Likangcheng
 * Date:2019/3/5
 * Time:14:35
 *
 * */
class ThirdPartyNotifyControllerTest extends Specification {


    ThirdPartyAccessSupportService thirdPartyAccessSupportService = Mock(ThirdPartyAccessSupportService)
    ThirdPartyNotifyController thirdPartyNotifyController = new ThirdPartyNotifyController(thirdPartyAccessSupportService: thirdPartyAccessSupportService)

    def "test notifyCreditStatus"() {
        given:
        NotifyCreditStatusReq notifyCreditStatusReq = new NotifyCreditStatusReq()

        when:
        thirdPartyNotifyController.notifyCreditStatus(notifyCreditStatusReq)
        then:
        1
    }

    def "test notifyCreditStatus case1"() {
        given:
        NotifyCreditStatusReq notifyCreditStatusReq = new NotifyCreditStatusReq()
        notifyCreditStatusReq.with {
            loanApplicationNum = "xxx"
        }
        when:
        thirdPartyNotifyController.notifyCreditStatus(notifyCreditStatusReq)
        then:
        1
    }

     def "test nofityScoreDs020"() {
         given:
         NofityScoreDs020Req nofityScoreDs020Req = new NofityScoreDs020Req()
         when:
         thirdPartyNotifyController.nofityScoreDs020(nofityScoreDs020Req)
         then:
         1
     }
}
