package com.dashuf.dpbs.service.support

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.mapper.SysConfMapper
import com.dashuf.dpbs.sao.sms.SendMessageSAO
import com.dashuf.dpbs.service.SysConfSupportService
import org.springframework.data.redis.connection.RedisConnection
import org.springframework.data.redis.connection.RedisConnectionFactory
import org.springframework.data.redis.core.RedisOperations
import org.springframework.data.redis.core.StringRedisTemplate
import org.springframework.data.redis.core.ValueOperations
import spock.lang.Specification

class VerifyCodeServiceTest extends Specification {
    ValueOperations valueOperations = Mock(ValueOperations.class)
    RedisOperations redisOperations = Mock(RedisOperations.class)
    RedisConnection redisConnection = Mock(RedisConnection.class)
    RedisConnectionFactory redisConnectionFactory = Mock(RedisConnectionFactory.class)

    SendMessageSAO sendMessageSAO = Mock(SendMessageSAO);
    StringRedisTemplate redisTemplate = Mock(StringRedisTemplate);
    SysConfSupportService sysConfSupportService = Mock(SysConfSupportService)
    VerifyCodeService verifyCodeService = new VerifyCodeService(
            sendMessageSAO: sendMessageSAO,
            redisTemplate: redisTemplate,
            sysConfSupportService: sysConfSupportService)


    def "sendVerifyCode case1: "() {
        when:
        verifyCodeService.sendVerifyCode("moduleCode", "phone", new JSONObject())
        then:
        1 * sysConfSupportService.selectValueFromCache(*_) >> "confVal"
        1 * sendMessageSAO.sendVerificationCode(*_) >> {
            JSONObject jsonObject = new JSONObject()
            jsonObject.put("code", "0000")
            return jsonObject
        }
        1 * redisTemplate.opsForValue() >> valueOperations
    }

    def "sendVerifyCode case2: "() {
        when:
        verifyCodeService.sendVerifyCode("moduleCode", "phone", new JSONObject())
        then:
        1 * sysConfSupportService.selectValueFromCache(*_) >> "confVal"
        1 * sendMessageSAO.sendVerificationCode(*_) >> {
            JSONObject jsonObject = new JSONObject()
            jsonObject.put("code", "2222")
            return jsonObject
        }
    }

    def "checkVerifyCode case1: "() {
        when:
        verifyCodeService.checkVerifyCode("moduleCode", "phone", "verifyCode", new JSONObject())
        then:
        1 * redisTemplate.opsForValue() >> valueOperations
        1 * valueOperations.get(*_) >> "val"
        1 * sendMessageSAO.checksumVerificationCode(*_) >> {
            JSONObject jsonObject = new JSONObject()
            jsonObject.put("code", "2222")
            return jsonObject
        }
    }

    def "checkVerifyCode case2: "() {
        when:
        verifyCodeService.checkVerifyCode("moduleCode", "phone", "verifyCode", new JSONObject())
        then:
        1 * redisTemplate.opsForValue() >> valueOperations
    }
}
