package com.dashuf.dpbs.app.web

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.app.web.req.support.QueryMovieReq
import com.dashuf.dpbs.service.support.MoviePlatRefService
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.mock.web.MockHttpSession
import org.springframework.web.multipart.MultipartFile
import spock.lang.Specification

class MoviePlatRefControllerTest extends Specification {
    MockHttpServletRequest request
    MockHttpServletResponse response
    MockHttpSession session

    def setup() {
        request = new MockHttpServletRequest()
        request.setCharacterEncoding("UTF-8")
        response = new MockHttpServletResponse()
        session = new MockHttpSession()
    }

    MoviePlatRefService moviePlatRefService = Mock(MoviePlatRefService)
    MoviePlatRefController moviePlatRefController = new MoviePlatRefController(moviePlatRefService: moviePlatRefService)

    def "uploadMoviePlat case1:上传影像信息"() {
        given:
        MultipartFile[] fileList = null
        String stepRefNo = null
        String stepCode = null
        when:
        moviePlatRefController.uploadMoviePlat(fileList, stepRefNo, stepCode)
        then:
        1
    }

    def "uploadMoviePlat case2:上传影像信息"() {
        given:
        MultipartFile[] fileList = new MultipartFile[2]
        String stepRefNo = null
        String stepCode = null
        when:
        moviePlatRefController.uploadMoviePlat(fileList, stepRefNo, stepCode)
        then:
        1 * moviePlatRefService.copyTempFileToServer(*_) >> null
    }

    def "uploadMoviePlat case3:上传影像信息"() {
        given:
        MultipartFile[] fileList = new MultipartFile[2]
        String stepRefNo = null
        String stepCode = null
        when:
        moviePlatRefController.uploadMoviePlat(fileList, stepRefNo, stepCode)
        then:
        1 * moviePlatRefService.copyTempFileToServer(*_) >> { throw new RuntimeException() }
    }

    def "uploadMoviePlat case4:上传影像信息"() {
        given:
        MultipartFile[] fileList = new MultipartFile[2]
        String stepRefNo = null
        String stepCode = null
        when:
        moviePlatRefController.uploadMoviePlat(fileList, stepRefNo, stepCode)
        then:
        1 * moviePlatRefService.copyTempFileToServer(*_) >> new ArrayList<File>()
    }

    def "uploadMoviePlat case5:上传影像信息"() {
        given:
        MultipartFile[] fileList = new MultipartFile[2]
        String stepRefNo = null
        String stepCode = null
        when:
        moviePlatRefController.uploadMoviePlat(fileList, stepRefNo, stepCode)
        then:
        1 * moviePlatRefService.copyTempFileToServer(*_) >> new ArrayList<File>()
        1 * moviePlatRefService.uploadHandler(*_) >> null
    }

    def "uploadMoviePlat case6:上传影像信息"() {
        given:
        MultipartFile[] fileList = new MultipartFile[2]
        String stepRefNo = null
        String stepCode = null
        when:
        moviePlatRefController.uploadMoviePlat(fileList, stepRefNo, stepCode)
        then:
        1 * moviePlatRefService.copyTempFileToServer(*_) >> new ArrayList<File>()
        1 * moviePlatRefService.uploadHandler(*_) >> new JSONObject()
    }

    def "uploadMoviePlat case7:上传影像信息"() {
        given:
        MultipartFile[] fileList = new MultipartFile[2]
        String stepRefNo = null
        String stepCode = null
        when:
        moviePlatRefController.uploadMoviePlat(fileList, stepRefNo, stepCode)
        then:
        1 * moviePlatRefService.copyTempFileToServer(*_) >> new ArrayList<File>()
        1 * moviePlatRefService.uploadHandler(*_) >> {
            throw new RuntimeException()
        }
    }


    def "queryMoviePlat case1:查询影像信息"() {
        given:
        QueryMovieReq queryMovieReq = new QueryMovieReq(stepCode: "test", stepRefNo: "test", contentId: "test")
        when:
        moviePlatRefController.queryMoviePlat(queryMovieReq)
        then:
        1 * moviePlatRefService.queryHandler(*_) >> null
    }

    def "queryMoviePlat case2:查询影像信息"() {
        given:
        QueryMovieReq queryMovieReq = new QueryMovieReq(stepCode: "test", stepRefNo: "test", contentId: "test")
        when:
        moviePlatRefController.queryMoviePlat(queryMovieReq)
        then:
        1 * moviePlatRefService.queryHandler(*_) >> new JSONObject()
    }

    def "queryMoviePlat case3:查询影像信息"() {
        given:
        QueryMovieReq queryMovieReq = new QueryMovieReq(stepCode: "test", stepRefNo: "test", contentId: "test")
        when:
        moviePlatRefController.queryMoviePlat(queryMovieReq)
        then:
        1 * moviePlatRefService.queryHandler(*_) >> {
            throw new RuntimeException()
        }
    }

}
