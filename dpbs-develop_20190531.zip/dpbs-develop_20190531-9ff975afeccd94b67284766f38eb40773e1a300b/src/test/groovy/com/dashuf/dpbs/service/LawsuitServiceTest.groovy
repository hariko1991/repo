package com.dashuf.dpbs.service

import com.alibaba.fastjson.JSONArray
import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.app.web.resp.lawsuit.LawsuitResultResp
import com.dashuf.dpbs.mapper.LawsuitQueryRecordMapper
import com.dashuf.dpbs.mapper.LawsuitRequestLogMapper
import com.dashuf.dpbs.mapper.PushOrderLogMapper
import com.dashuf.dpbs.model.LawsuitQueryRecord
import com.dashuf.dpbs.sao.huifa.LawxinDataSao
import com.dashuf.merlin.mybatis.page.Pagination
import spock.lang.Specification

/**
 *
 * Created with IDEA
 * author:Likangcheng
 * Date:2019/3/5
 * Time:9:45
 *
 * */
class LawsuitServiceTest extends Specification {


    LawsuitQueryRecordMapper lawsuitQueryRecordMapper = Mock(LawsuitQueryRecordMapper)
    LawsuitRequestLogMapper lawsuitRequestLogMapper = Mock(LawsuitRequestLogMapper)
    PushOrderLogMapper pushOrderLogMapper = Mock(PushOrderLogMapper)
    LawxinDataSao lawxinDataSao = Mock(LawxinDataSao)
    LawsuitService lawsuitService = new LawsuitService(
            lawsuitQueryRecordMapper: lawsuitQueryRecordMapper,
            lawsuitRequestLogMapper: lawsuitRequestLogMapper,
            pushOrderLogMapper: pushOrderLogMapper,
            lawxinDataSao: lawxinDataSao,
            idenCode: "dashu201609011804489",
            equalZero: 1,
            lessHund: 3,
            moreHund: 5
    )

    def "test getHistoryQueryRecord"() {

        when:
        lawsuitService.getHistoryQueryRecord("xx", new Pagination())
        then:
        1 * lawsuitQueryRecordMapper.selectByModelSelective(*_) >> new ArrayList<LawsuitQueryRecord>()
    }

    def "test getLeftCount"() {

        when:
        lawsuitService.getLeftCount("U20190123143320662707")
        then:
        1 * pushOrderLogMapper.getLoanSum(*_) >> new BigDecimal(1)
        1 * lawsuitRequestLogMapper.getCount(*_) >> 1
    }

    def "test getLocalResult"() {
        when:
        lawsuitService.getLocalResult(1)
        then:
        1 * lawsuitQueryRecordMapper.getLocalResult(*_) >> new LawsuitResultResp()
    }

    def "getLawsuit case1: "() {
        when:
        lawsuitService.getLawsuit("certNo", "name", "userNo")
        then:
        1 * lawxinDataSao.getLawxinData(*_) >> {
            JSONObject jsonObject = new JSONObject()
            JSONArray allmsglist = new JSONArray()


            JSONObject innerJsonObj = new JSONObject()
            JSONArray onemsglist = new JSONArray()
            JSONObject jsonObj = new JSONObject()
            jsonObj.put("propername", "被执行人姓名或名称")
            onemsglist.add(jsonObj)
            jsonObj = new JSONObject()
            jsonObj.put("propername", "证件号码")
            onemsglist.add(jsonObj)
            jsonObj = new JSONObject()
            jsonObj.put("propername", "执行法院")
            onemsglist.add(jsonObj)
            jsonObj = new JSONObject()
            jsonObj.put("propername", "执行案号")
            onemsglist.add(jsonObj)
            jsonObj = new JSONObject()
            jsonObj.put("propername", "执行内容")
            onemsglist.add(jsonObj)
            jsonObj = new JSONObject()
            jsonObj.put("propername", "立案时间")
            onemsglist.add(jsonObj)
            jsonObj = new JSONObject()
            jsonObj.put("propername", "执行状态")
            onemsglist.add(jsonObj)
            jsonObj = new JSONObject()
            jsonObj.put("propername", "异议备注")
            onemsglist.add(jsonObj)

            innerJsonObj.put("onemsglist", onemsglist)
            allmsglist.add(innerJsonObj)
            jsonObject.put("allmsglist", allmsglist)
            return jsonObject
        }
        1 * lawsuitRequestLogMapper.insertSelective(*_) >> 2
        1 * lawsuitQueryRecordMapper.selectOneByModelSelective(*_) >> new LawsuitQueryRecord()
    }
}
