package com.dashuf.dpbs.service.credit

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.model.ClientInfo
import com.dashuf.dpbs.model.InfoEntry
import com.dashuf.dpbs.model.PushOrderLog
import com.dashuf.dpbs.model.UserInfo
import com.dashuf.dpbs.sao.credit.CreditReportSAO
import com.dashuf.dpbs.sao.credit.resp.CreditReport25Resp
import com.dashuf.dpbs.sao.credit.resp.CreditUploadResp
import com.dashuf.dpbs.service.SysConfSupportService
import com.dashuf.dpbs.service.blaze.dto.DashufBlazeDto
import spock.lang.Specification

class CreditReportServiceTest extends Specification {
    CreditReportSAO creditReportSAO = Mock(CreditReportSAO)
    SysConfSupportService sysConfSupportService = Mock(SysConfSupportService)
    CreditReportService creditReportService = new CreditReportService(creditReportSAO: creditReportSAO,
            sysConfSupportService: sysConfSupportService)

    def "queryCreditReportWithin25Day case1: "() {
        when:
        creditReportService.queryCreditReportWithin25Day(new ClientInfo(), new JSONObject())
        then:
        1 * creditReportSAO.queryCreditReportWithin25Day(*_) >> {
            CreditReport25Resp creditReport25Resp = new CreditReport25Resp();
            List<CreditReport25Resp.CreditReport> list = new ArrayList<>()
            CreditReport25Resp.CreditReport creditReport = new CreditReport25Resp.CreditReport();
            creditReport.setReportNo("reportNo")
            list.add(creditReport)
            creditReport25Resp.setReportList(list)
            creditReport25Resp.setRetCode("SUC000")
            return creditReport25Resp;
        }
    }


    def "queryCreditReportWithin25Day case2: "() {
        when:
        creditReportService.queryCreditReportWithin25Day(new ClientInfo(), new JSONObject())
        then:
        1 * creditReportSAO.queryCreditReportWithin25Day(*_) >> {
            return null;
        }
    }

    def "submitCreditReportReq case1: "() {
        given:
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        InfoEntry infoEntry = new InfoEntry()
        ClientInfo clientInfo = new ClientInfo()
        UserInfo userInfo = new UserInfo()
        PushOrderLog pushOrderLog = new PushOrderLog()
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry)

        when:
        creditReportService.submitCreditReportReq(dashufBlazeDto, new JSONObject())
        then:
        1 * sysConfSupportService.selectValueFromCache(*_) >> "{'queryOrg':'002','originId':'002'}"
        1 * creditReportSAO.submitCreditReportReq(*_) >> null
    }

    def "submitCreditReportReq case2: "() {
        given:
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        InfoEntry infoEntry = new InfoEntry()
        ClientInfo clientInfo = new ClientInfo()
        UserInfo userInfo = new UserInfo()
        PushOrderLog pushOrderLog = new PushOrderLog()
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry)

        when:
        creditReportService.submitCreditReportReq(dashufBlazeDto, new JSONObject())
        then:
        1 * sysConfSupportService.selectValueFromCache(*_) >> "{'queryOrg':'002','originId':'002'}"
        1 * creditReportSAO.submitCreditReportReq(*_) >> {
            CreditUploadResp creditUploadResp = new CreditUploadResp()
            creditUploadResp.setRetCode("suc")
            return creditUploadResp
        }
    }

    def "submitCreditReportReq case3 "() {
        given:
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        InfoEntry infoEntry = new InfoEntry()
        ClientInfo clientInfo = new ClientInfo()
        UserInfo userInfo = new UserInfo()
        PushOrderLog pushOrderLog = new PushOrderLog()
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry)

        when:
        creditReportService.submitCreditReportReq(dashufBlazeDto, new JSONObject())
        then:
        1 * sysConfSupportService.selectValueFromCache(*_) >> "{'queryOrg':'002','originId':'002'}"
        1 * creditReportSAO.submitCreditReportReq(*_) >> {
            CreditUploadResp creditUploadResp = new CreditUploadResp()
            creditUploadResp.setRetCode("SUC000")
            return creditUploadResp
        }
    }

}
