package com.dashuf.dpbs.service

import com.dashuf.dpbs.mapper.SysConfMapper
import com.dashuf.dpbs.model.SysConf
import org.springframework.data.redis.connection.RedisConnection
import org.springframework.data.redis.connection.RedisConnectionFactory
import org.springframework.data.redis.core.RedisOperations
import org.springframework.data.redis.core.StringRedisTemplate
import org.springframework.data.redis.core.ValueOperations
import spock.lang.Specification

class SysConfSupportServiceTest extends Specification {
    ValueOperations valueOperations = Mock(ValueOperations.class)
    RedisOperations redisOperations = Mock(RedisOperations.class)
    RedisConnection redisConnection = Mock(RedisConnection.class)
    RedisConnectionFactory redisConnectionFactory = Mock(RedisConnectionFactory.class)

    SysConfMapper sysConfMapper = Mock(SysConfMapper);
    CacheInitService cacheInitService = Mock(CacheInitService);
    StringRedisTemplate redisTemplate = Mock(StringRedisTemplate);

    SysConfSupportService sysConfSupportService = new SysConfSupportService(
            sysConfMapper: sysConfMapper,
            cacheInitService: cacheInitService,
            redisTemplate: redisTemplate
    )

    def "selectValueFromDb case1: "() {
        when:
        sysConfSupportService.selectValueFromDb(new SysConf())
        then:
        1 * sysConfMapper.selectValue(*_) >> "confVal";
    }

    def "selectValueFromCache case1: "() {
        when:
        sysConfSupportService.selectValueFromCache(new SysConf())
        then:
        1 * cacheInitService.getRedisKey(*_) >> "redisKey"
        1 * redisTemplate.opsForValue() >> valueOperations
    }

    def "updateValueForDb case1: "() {
        when:
        sysConfSupportService.updateValueForDb(new SysConf())
        then:
        1 * sysConfMapper.updateValue(*_) >> 1
    }

    def "updateValueFromCache case1: "() {
        when:
        sysConfSupportService.updateValueFromCache(new SysConf())
        then:
        1 * cacheInitService.getRedisKey(*_) >> "redisKey"
        1 * redisTemplate.opsForValue() >> valueOperations
    }

    def "selectMockValFromCache case1: "() {
        when:
        sysConfSupportService.selectMockValFromCache()
        then:
        1 * cacheInitService.getRedisKey(*_) >> "redisKey"
        1 * redisTemplate.opsForValue() >> valueOperations
    }

    def "selectValueFromCache case2: "() {
        when:
        sysConfSupportService.selectValueFromCache(null, null, null)
        then:
        1 * cacheInitService.getRedisKey(*_) >> "redisKey"
        1 * redisTemplate.opsForValue() >> valueOperations
    }

    def "selectMockValFromCache case2: "() {
        when:
        sysConfSupportService.selectMockValFromCache("mockModuleCode")
        then:
        1 * cacheInitService.getRedisKey(*_) >> "redisKey"
        1 * redisTemplate.opsForValue() >> valueOperations
        1 * valueOperations.get(*_) >> "mockModuleCode"
    }

    def "selectMockValFromCache case3: "() {
        when:
        sysConfSupportService.selectMockValFromCache("mockModuleCode")
        then:
        1 * cacheInitService.getRedisKey(*_) >> "redisKey"
        1 * redisTemplate.opsForValue() >> valueOperations
        1 * valueOperations.get(*_) >> null
    }
}
