package com.dashuf.dpbs.service.support

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.sao.icp.IcpAuthSAO
import com.dashuf.dpbs.sao.icp.req.CheckIDCardReq
import spock.lang.Specification

class IcpAuthSupportServiceTest extends Specification {
    IcpAuthSAO icpAuthSAO = Mock(IcpAuthSAO)
    IcpAuthSupportService icpAuthSupportService = new IcpAuthSupportService(icpAuthSAO: icpAuthSAO)

    def "checkPersonMsg case1: "() {
        when:
        icpAuthSupportService.checkPersonMsg(new CheckIDCardReq(), new JSONObject())
        then:
        1 * icpAuthSAO.checkPersonMsg(*_) >> {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("code", "00")
            return jsonObject;
        }
    }

    def "checkPersonMsg case2: "() {
        when:
        icpAuthSupportService.checkPersonMsg(new CheckIDCardReq(), new JSONObject())
        then:
        1 * icpAuthSAO.checkPersonMsg(*_) >> {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("code", "00111")
            return jsonObject;
        }
    }
}
