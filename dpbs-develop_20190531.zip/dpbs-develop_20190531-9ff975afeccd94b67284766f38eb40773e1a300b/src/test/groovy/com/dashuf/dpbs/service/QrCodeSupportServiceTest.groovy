package com.dashuf.dpbs.service

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.mapper.ClientInfoMapper
import com.dashuf.dpbs.mapper.InfoEntryMapper
import com.dashuf.dpbs.mapper.QrCodeInfoMapper
import com.dashuf.dpbs.model.ClientInfo
import com.dashuf.dpbs.model.InfoEntry
import com.dashuf.dpbs.model.QrCodeInfo
import com.dashuf.dpbs.service.support.WxSupportService
import spock.lang.Specification

class QrCodeSupportServiceTest extends Specification {
    ClientInfoMapper clientInfoMapper = Mock(ClientInfoMapper)
    QrCodeInfoMapper qrCodeInfoMapper = Mock(QrCodeInfoMapper)
    WxSupportService wxSupportService = Mock(WxSupportService)
    InfoEntryMapper infoEntryMapper = Mock(InfoEntryMapper)
    QrCodeSupportService qrCodeSupportService = new QrCodeSupportService(clientInfoMapper: clientInfoMapper,
            qrCodeInfoMapper: qrCodeInfoMapper, wxSupportService: wxSupportService,
            infoEntryMapper: infoEntryMapper)

    def "initQrCodeResp case1: "() {
        when:
        qrCodeSupportService.initQrCodeResp(null, new JSONObject())
        then:
        1 * infoEntryMapper.selectOneByModelSelective(*_) >> new InfoEntry()
        1 * clientInfoMapper.selectByPushOrderNo(*_) >> new ClientInfo()
    }

    def "initQrCodeResp case2: "() {
        when:
        qrCodeSupportService.initQrCodeResp(null, new JSONObject())
        then:
        1 * infoEntryMapper.selectOneByModelSelective(*_) >> new InfoEntry()
        1 * clientInfoMapper.selectByPushOrderNo(*_) >> new ClientInfo()
        1 * wxSupportService.getQrCodeUrl(*_) >> "ticket"
        1 * qrCodeInfoMapper.initQrCodeInfo(*_) >> 1
    }

    def "analysisQrCode case1: "() {
        when:
        qrCodeSupportService.analysisQrCode(null, "qr_code", new JSONObject())
        then:
        1 * qrCodeInfoMapper.selectUniqueQrCodeInfo(*_) >> null
    }

    def "analysisQrCode case2: "() {
        when:
        qrCodeSupportService.analysisQrCode(null, "qr_code", new JSONObject())
        then:
        1 * qrCodeInfoMapper.selectUniqueQrCodeInfo(*_) >> new QrCodeInfo()
        1 * qrCodeInfoMapper.updateQrCodeInfoByOrgStatus(*_) >> 1
    }

    def "analysisQrCode case3: "() {
        when:
        qrCodeSupportService.analysisQrCode(null, "qr_code", new JSONObject())
        then:
        1 * qrCodeInfoMapper.selectUniqueQrCodeInfo(*_) >> new QrCodeInfo()
        1 * qrCodeInfoMapper.updateQrCodeInfoByOrgStatus(*_) >> 0
    }
}
