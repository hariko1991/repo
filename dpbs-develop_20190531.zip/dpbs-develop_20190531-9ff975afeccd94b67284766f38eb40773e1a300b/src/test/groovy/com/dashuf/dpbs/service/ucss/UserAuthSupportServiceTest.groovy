package com.dashuf.dpbs.service.ucss

import com.alibaba.fastjson.JSONArray
import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.model.UserInfo
import com.dashuf.dpbs.sao.ucss.UserAuthSAO
import com.dashuf.dpbs.sao.ucss.resp.GetDetailOfUserResp
import spock.lang.Specification

class UserAuthSupportServiceTest extends Specification {
    UserAuthSAO userAuthSAO = Mock(UserAuthSAO)
    UserAuthSupportService userAuthSupportService = new UserAuthSupportService(userAuthSAO: userAuthSAO)

    def "getCompanyListOfUser case1: "() {
        when:
        userAuthSupportService.getCompanyListOfUser(null, null, new JSONObject())
        then:
        1 * userAuthSAO.getCompanyListOfUser(*_) >> {
            return com.dashuf.merlin.web.base.views.ResponseVo.fail("fail");
        }
    }


    def "getCompanyListOfUser case2: "() {
        when:
        userAuthSupportService.getCompanyListOfUser(null, new UserInfo(), new JSONObject())
        then:
        1 * userAuthSAO.getCompanyListOfUser(*_) >> {
            JSONObject rtnObj = new JSONObject();
            JSONArray jsonArray = new JSONArray();
            JSONObject jsonObj = new JSONObject();
            jsonObj.put("organizationName", "organizationName");
            jsonObj.put("organizationId", "organizationId");

            JSONObject jsonInnerObj = new JSONObject();
            jsonInnerObj.put("organization", jsonObj);
            jsonArray.add(jsonInnerObj);
            rtnObj.put("list", jsonArray);
            return com.dashuf.merlin.web.base.views.ResponseVo.success(rtnObj);
        }
    }

    def "getCompanyListOfUser 2 case1: "() {
        when:
        userAuthSupportService.getCompanyListOfUser(null, new JSONObject())
        then:
        1 * userAuthSAO.getCompanyListOfUser(*_) >> {
            return com.dashuf.merlin.web.base.views.ResponseVo.fail("fail");
        }
    }


    def "getCompanyListOfUser 2 case2: "() {
        when:
        userAuthSupportService.getCompanyListOfUser(null, new JSONObject())
        then:
        1 * userAuthSAO.getCompanyListOfUser(*_) >> {
            JSONObject rtnObj = new JSONObject();
            JSONArray jsonArray = new JSONArray();
            JSONObject jsonObj = new JSONObject();
            jsonObj.put("organizationName", "organizationName");
            jsonObj.put("organizationId", "organizationId");

            JSONObject jsonInnerObj = new JSONObject();
            jsonInnerObj.put("organization", jsonObj);
            jsonArray.add(jsonInnerObj);
            rtnObj.put("list", jsonArray);
            return com.dashuf.merlin.web.base.views.ResponseVo.success(rtnObj);
        }
    }

    def "getCompanyList case1: "() {
        when:
        userAuthSupportService.getCompanyList(new JSONObject())
        then:
        1 * userAuthSAO.getCompanyOfUm(*_) >> {
            JSONObject rtnObj = new JSONObject();
            JSONArray jsonArray = new JSONArray();
            JSONObject jsonObj = new JSONObject();
            jsonObj.put("organizationName", "organizationName");
            jsonObj.put("organizationId", "organizationId");

            jsonArray.add(jsonObj);
            rtnObj.put("list", jsonArray);
            return com.dashuf.merlin.web.base.views.ResponseVo.success(rtnObj);
        }
    }

    def "getCompanyList case2: "() {
        when:
        userAuthSupportService.getCompanyList(new JSONObject())
        then:
        1 * userAuthSAO.getCompanyOfUm(*_) >> {
            return com.dashuf.merlin.web.base.views.ResponseVo.success(null);
        }
    }

    def "getCompanyList case3: "() {
        when:
        userAuthSupportService.getCompanyList(new JSONObject())
        then:
        1 * userAuthSAO.getCompanyOfUm(*_) >> {
            return com.dashuf.merlin.web.base.views.ResponseVo.fail("fail");
        }
    }

    def "getDetailOfUser case1: "() {
        when:
        userAuthSupportService.getDetailOfUser(null, null, new JSONObject())
        then:
        1 * userAuthSAO.getDetailOfUser(*_) >> {
            return com.dashuf.merlin.web.base.views.ResponseVo.fail("fail");
        }
    }

    def "getDetailOfUser case2: "() {
        when:
        userAuthSupportService.getDetailOfUser(null, new UserInfo(), new JSONObject())
        then:
        1 * userAuthSAO.getDetailOfUser(*_) >> {
            GetDetailOfUserResp resp = new GetDetailOfUserResp();
            return com.dashuf.merlin.web.base.views.ResponseVo.success(resp);
        }
    }
}