package com.dashuf.dpbs.app.web.msmp

import com.dashuf.dpbs.app.web.req.msmp.ClientOfUserPageReq
import com.dashuf.dpbs.app.web.req.msmp.GetUserDetailReq
import com.dashuf.dpbs.app.web.req.msmp.ModifyUserCompanyReq
import com.dashuf.dpbs.app.web.resp.msmp.ClientBean
import com.dashuf.dpbs.app.web.resp.msmp.MyUserDetailResp
import com.dashuf.dpbs.service.MsmpSupportService
import com.github.pagehelper.PageInfo
import spock.lang.Specification

/**
 *
 * Created with IDEA
 * author:Likangcheng
 * Date:2019/3/5
 * Time:14:54
 *
 * */
class MyUserControllerTest extends Specification {
    MsmpSupportService chipSupportService = Mock(MsmpSupportService)
    MyUserController myUserController = new MyUserController(chipSupportService: chipSupportService)

    def "test getDetail"() {
        given:
        GetUserDetailReq getUserRefReq = new GetUserDetailReq()
        getUserRefReq.with {
            userNo = "xxx"
        }
        when:
        myUserController.getDetail(getUserRefReq)
        then:
        1 * chipSupportService.getDetail(*_) >> new MyUserDetailResp()
    }

    def "test getDetail case1"() {
        given:
        GetUserDetailReq getUserRefReq = new GetUserDetailReq()
        getUserRefReq.with {
            userNo = "xxx"
        }
        when:
        myUserController.getDetail(getUserRefReq)
        then:
        1 * chipSupportService.getDetail(*_) >> null
    }

    def "test getDetail case3"() {
        given:
        GetUserDetailReq getUserRefReq = new GetUserDetailReq()
        getUserRefReq.with {
            userNo = "xxx"
        }
        when:
        myUserController.getDetail(getUserRefReq)
        then:
        1 * chipSupportService.getDetail(*_) >> {
            throw new RuntimeException()
        }
    }

    def "test modifyUserCompany"() {
        given:
        ModifyUserCompanyReq modifyUserCompanyReq = new ModifyUserCompanyReq()
        modifyUserCompanyReq.with {
            userNo = "xxx"
        }
        when:
        myUserController.modifyUserCompany(modifyUserCompanyReq)
        then:
        1 * chipSupportService.modifyUserCompany(*_) >> 1
    }

    def "test modifyUserCompany case1"() {
        given:
        ModifyUserCompanyReq modifyUserCompanyReq = new ModifyUserCompanyReq()
        modifyUserCompanyReq.with {
            userNo = "xxx"
        }
        when:
        myUserController.modifyUserCompany(modifyUserCompanyReq)
        then:
        1 * chipSupportService.modifyUserCompany(*_) >> { throw new RuntimeException() }
    }

    def "test getPendPage"() {
        given:
        ClientOfUserPageReq clientOfUserPageReq = new ClientOfUserPageReq()
        clientOfUserPageReq.with {
            userNo = "xx"
        }
        when:
        myUserController.getPendPage(clientOfUserPageReq)
        then:
        1 * chipSupportService.selectPendClientPage(*_) >> new PageInfo<ClientBean>()
    }

    def "test getPendPage case1"() {
        given:
        ClientOfUserPageReq clientOfUserPageReq = new ClientOfUserPageReq()
        clientOfUserPageReq.with {
            userNo = "xx"
        }
        when:
        myUserController.getPendPage(clientOfUserPageReq)
        then:
        1 * chipSupportService.selectPendClientPage(*_) >> {
            throw new RuntimeException()
        }
    }

    def "test getAlreadyPage"() {
        given:
        ClientOfUserPageReq clientOfUserPageReq = new ClientOfUserPageReq()
        clientOfUserPageReq.with {
            userNo = "xx"
        }
        when:
        myUserController.getAlreadyPage(clientOfUserPageReq)
        then:
        1 * chipSupportService.selectAlreadyClientPage(*_) >> new PageInfo<ClientBean>()
    }

    def "test getAlreadyPage case1"() {
        given:
        ClientOfUserPageReq clientOfUserPageReq = new ClientOfUserPageReq()
        clientOfUserPageReq.with {
            userNo = "xx"
        }
        when:
        myUserController.getAlreadyPage(clientOfUserPageReq)
        then:
        1 * chipSupportService.selectAlreadyClientPage(*_) >> { throw new RuntimeException() }
    }
}
