package com.dashuf.dpbs.service.cpms

import com.alibaba.fastjson.JSONArray
import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.sao.cpms.MarketManagerSAO
import com.dashuf.merlin.web.base.views.ResponseVo
import spock.lang.Specification

class MarketManagerSupportServiceTest extends Specification {
    MarketManagerSAO marketManagerSAO = Mock(MarketManagerSAO)
    MarketManagerSupportService marketManagerSupportService = new MarketManagerSupportService(marketManagerSAO: marketManagerSAO)

    def "getExclusiveChannel case1: "() {
        when:
        marketManagerSupportService.getExclusiveChannel("channelName", new JSONObject())
        then:
        1 * marketManagerSAO.getExclusiveChannel(*_) >> {
            JSONObject jsonObject = new JSONObject()

            JSONArray jsonArray = new JSONArray()
            JSONObject jsonObj = new JSONObject()
            jsonObj.put("channelName", "channelName")
            jsonObj.put("exclusiveChannelId", "exclusiveChannelId");
            jsonArray.add(jsonObj);
            jsonObject.put("list", jsonArray)
            return ResponseVo.success(jsonObject)
        }
    }

    def "getExclusiveChannel case2: "() {
        when:
        marketManagerSupportService.getExclusiveChannel("channelName", new JSONObject())
        then:
        1 * marketManagerSAO.getExclusiveChannel(*_) >> {
            JSONObject jsonObject = new JSONObject()

            JSONArray jsonArray = new JSONArray()
            JSONObject jsonObj = new JSONObject()
            jsonObj.put("channelName", "channelName")
            jsonObj.put("exclusiveChannelId", "exclusiveChannelId")
            jsonArray.add(jsonObj)
            jsonObject.put("list", jsonArray)
            return ResponseVo.fail("fail")
        }
    }



    def "test getExclusiveChannelAvailable case"() {
        when:
        marketManagerSupportService.getExclusiveChannelAvailable("channelName", new JSONObject())
        then:
        1 * marketManagerSAO.getExclusiveChannelAvailable(*_) >> {
            JSONObject jsonObject = new JSONObject()
            return ResponseVo.success(jsonObject)
        }
    }

    def "test getExclusiveChannelAvailable case0"() {
        when:
        marketManagerSupportService.getExclusiveChannelAvailable("channelName", new JSONObject())
        then:
        1 * marketManagerSAO.getExclusiveChannelAvailable(*_) >> {
            JSONObject jsonObject = new JSONObject()

            JSONArray jsonArray = new JSONArray()
            jsonObject.put("list", jsonArray)
            return ResponseVo.success(jsonObject)
        }
    }

    def "test getExclusiveChannelAvailable case1"() {
        when:
        marketManagerSupportService.getExclusiveChannelAvailable("channelName", new JSONObject())
        then:
        1 * marketManagerSAO.getExclusiveChannelAvailable(*_) >> {
            JSONObject jsonObject = new JSONObject()

            JSONArray jsonArray = new JSONArray()
            JSONObject jsonObj = new JSONObject()
            jsonObj.put("channelName", "channelName")
            jsonObj.put("exclusiveChannelId", "exclusiveChannelId")
            jsonArray.add(jsonObj)
            jsonObject.put("list", jsonArray)
            return ResponseVo.success(jsonObject)
        }
    }

    def "test getExclusiveChannelAvailable case2"() {
        when:
        marketManagerSupportService.getExclusiveChannelAvailable("channelName", new JSONObject())
        then:
        1 * marketManagerSAO.getExclusiveChannelAvailable(*_) >> {
            JSONObject jsonObject = new JSONObject()

            JSONArray jsonArray = new JSONArray()
            JSONObject jsonObj = new JSONObject()
            jsonObj.put("channelName", "channelName")
            jsonObj.put("exclusiveChannelId", "exclusiveChannelId")
            jsonArray.add(jsonObj)
            jsonObject.put("list", jsonArray)
            return ResponseVo.fail("fail")
        }
    }



    def "test getTeamListOfUm case1"() {
        given:
        def umNo = "CHENZHE"
        when:
        marketManagerSupportService.getTeamListOfUm(umNo, new JSONObject())
        then:
        1 * marketManagerSAO.getTeamListOfUmNo(*_) >> new ResponseVo<JSONObject>()
    }

    def "test getTeamListOfUm case2"() {
        given:
        def umNo = "CHENZHE"
        when:
        marketManagerSupportService.getTeamListOfUm(umNo, new JSONObject())
        then:
        1 * marketManagerSAO.getTeamListOfUmNo(*_) >> {

            JSONObject jsonObj = new JSONObject()
            jsonObj.put("userName", "陈哲")
            jsonObj.put("mobileTelephoneNum", "18627995255")

            JSONArray jsonArrayRole = new JSONArray()
            JSONObject jsonObj2 = new JSONObject()
            jsonObj2.put("userId", "CHENZHE")
            jsonObj2.put("marketTeamId", "100001")
            jsonObj2.put("marketTeamName", "武汉市场一部")
            jsonObj2.put("organizationId", "100700")
            jsonObj2.put("organizationName", "武汉分公司")
            jsonArrayRole.add(jsonObj2)

            jsonObj.put("memberRole", jsonArrayRole)

            JSONArray jsonArray = new JSONArray()
            jsonArray.add(jsonObj)

            JSONObject jsonObject1 = new JSONObject()
            jsonObject1.put("total", 0)
            jsonObject1.put("list", jsonArray)

            ResponseVo.success(jsonObject1)
        }
    }

    def "test getTeamListOfUm case3"() {
        given:
        def umNo = "CHENZHE"
        when:
        marketManagerSupportService.getTeamListOfUm(umNo, new JSONObject())
        then:
        1 * marketManagerSAO.getTeamListOfUmNo(*_) >> {
            JSONArray jsonArray = new JSONArray()

            JSONObject jsonObject1 = new JSONObject()
            jsonObject1.put("total", 0)
            jsonObject1.put("list", jsonArray)

            ResponseVo.success(jsonObject1)
        }
    }


    def "test getTeamListOfUm case4"() {
        given:
        def umNo = "CHENZHE"
        when:
        marketManagerSupportService.getTeamListOfUm(umNo, new JSONObject())
        then:
        1 * marketManagerSAO.getTeamListOfUmNo(*_) >> {

            ResponseVo.fail("500")
        }
    }


    def "test getAvailableUmList case1"() {
        given:
        def umNo = "CHENZHE"
        when:
        marketManagerSupportService.getAvailableUmList(umNo, new JSONObject())
        then:
        1 * marketManagerSAO.getTeamListAvailable(*_) >> new ResponseVo<JSONObject>()
    }

    def "test getAvailableUmList case2"() {
        given:
        def umNo = "CHENZHE"
        when:
        marketManagerSupportService.getAvailableUmList(umNo, new JSONObject())
        then:
        1 * marketManagerSAO.getTeamListAvailable(*_) >> {

            JSONObject jsonObject1 = new JSONObject()
            jsonObject1.put("userId", "CHENZHE")
            JSONArray jsonArray = new JSONArray()
            jsonArray.add(jsonObject1)

            JSONObject jsonObject = new JSONObject()
            jsonObject.put("list", jsonArray)

            ResponseVo.success(jsonObject)
        }
    }

    def "test getAvailableUmList case3"() {
        given:
        def umNo = "CHENZHE"
        when:
        marketManagerSupportService.getAvailableUmList(umNo, new JSONObject())
        then:
        1 * marketManagerSAO.getTeamListAvailable(*_) >> {
            JSONArray jsonArray = new JSONArray()
            JSONObject jsonObject = new JSONObject()
            jsonObject.put("list", jsonArray)
            ResponseVo.success(jsonObject)
        }
    }

    def "test getAvailableUmList case4"() {
        given:
        def umNo = "CHENZHE"
        when:
        marketManagerSupportService.getAvailableUmList(umNo, new JSONObject())
        then:
        1 * marketManagerSAO.getTeamListAvailable(*_) >> {
            ResponseVo.fail("433")
        }
    }



    def "test getOrganizationChannelsListAvailable case1"() {
        when:
        marketManagerSupportService.getOrganizationChannelsListAvailable("channelName", new JSONObject())
        then:
        1 * marketManagerSAO.getOrganizationChannelsListAvailable(*_) >> {
            JSONObject jsonObject = new JSONObject()

            JSONArray jsonArray = new JSONArray()
            JSONObject jsonObj = new JSONObject()
            jsonObj.put("channelName", "channelName")
            jsonObj.put("organizationChannelId", "organizationChannelId")
            jsonArray.add(jsonObj)
            jsonObject.put("list", jsonArray)
            return ResponseVo.success(jsonObject)
        }
    }


    def "test getOrganizationChannelsListAvailable case2"() {
        when:
        marketManagerSupportService.getOrganizationChannelsListAvailable("channelName", new JSONObject())
        then:
        1 * marketManagerSAO.getOrganizationChannelsListAvailable(*_) >> {
            return ResponseVo.fail("fail")
        }
    }

    def "test getOrganizationChannelsListAvailable case3"() {
        when:
        marketManagerSupportService.getOrganizationChannelsListAvailable("channelName", new JSONObject())
        then:
        1 * marketManagerSAO.getOrganizationChannelsListAvailable(*_) >> {
            JSONObject jsonObject = new JSONObject()
            JSONArray jsonArray = new JSONArray()
            jsonObject.put("list", jsonArray)
            return ResponseVo.success(jsonObject)
        }
    }

    def "test getOrganizationChannelsListAvailable case4"() {
        when:
        marketManagerSupportService.getOrganizationChannelsListAvailable("channelName", new JSONObject())
        then:
        1 * marketManagerSAO.getOrganizationChannelsListAvailable(*_) >> {
            JSONObject jsonObject = new JSONObject()
            jsonObject.put("list", null)
            return ResponseVo.success(jsonObject)
        }
    }





}
