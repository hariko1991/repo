package com.dashuf.dpbs.service.support

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.model.QrCodeInfo
import com.dashuf.dpbs.sao.wx.DswxApiSAO
import com.dashuf.dpbs.sao.wx.WxApiSao
import com.dashuf.dpbs.sao.wx.WxQrCodeSAO
import com.dashuf.dpbs.service.SysConfSupportService
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.redis.connection.RedisConnection
import org.springframework.data.redis.connection.RedisConnectionFactory
import org.springframework.data.redis.core.RedisOperations
import org.springframework.data.redis.core.StringRedisTemplate
import org.springframework.data.redis.core.ValueOperations
import org.springframework.data.redis.support.atomic.RedisAtomicInteger
import spock.lang.Specification

class WxSupportServiceTest extends Specification {
    WxApiSao wxApiSao = Mock(WxApiSao);
    WxQrCodeSAO wxQrCodeSAO = Mock(WxQrCodeSAO);

    ValueOperations valueOperations = Mock(ValueOperations.class)
    RedisOperations redisOperations = Mock(RedisOperations.class)
    RedisConnection redisConnection = Mock(RedisConnection.class)
    RedisConnectionFactory redisConnectionFactory = Mock(RedisConnectionFactory.class)

    DswxApiSAO dswxApiSAO = Mock(DswxApiSAO);
    SysConfSupportService sysConfSupportService = Mock(SysConfSupportService);
    RedisAtomicInteger redisDistributeLock = Mock(RedisAtomicInteger);
    StringRedisTemplate redisTemplateAccessToken = Mock(StringRedisTemplate);
    WxSupportService wxSupportService = new WxSupportService(wxApiSao: wxApiSao,
            wxQrCodeSAO: wxQrCodeSAO,
            appId: "appId",
            appSecret: "appSecret",
            qrAppId: "qrAppId",
            qrAppSecret: "qrAppSecret",
            redisDistributeLock: redisDistributeLock,
            redisTemplateAccessToken: redisTemplateAccessToken,
            dswxApiSAO: dswxApiSAO,
            sysConfSupportService: sysConfSupportService)

    def "getOpenId case1: "() {
        when:
        wxSupportService.getOpenId("userNo", "wxCode", new JSONObject())
        then:
        1 * wxApiSao.getOpenId(*_) >> {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("openid", "openid");
            return JSONObject.toJSONString(jsonObject);
        }
    }

    def "getOpenId case2: "() {
        when:
        wxSupportService.getOpenId("userNo", "wxCode", new JSONObject())
        then:
        1 * wxApiSao.getOpenId(*_) >> null
    }

    def "getOpenId case3: "() {
        when:
        wxSupportService.getOpenId("userNo", "wxCode", new JSONObject())
        then:
        1 * wxApiSao.getOpenId(*_) >> { throw new RuntimeException() }
    }

    def "authThirdPartyLogin case1: "() {
        when:
        wxSupportService.authThirdPartyLogin("thirdPartyType", "thirdPartyCode", new JSONObject())
        then:
        1 * wxApiSao.getOpenId(*_) >> {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("openid", "openid");
            return JSONObject.toJSONString(jsonObject);
        }
    }

    def "authThirdPartyLogin case2: "() {
        when:
        wxSupportService.authThirdPartyLogin("thirdPartyType", "thirdPartyCode", new JSONObject())
        then:
        1 * wxApiSao.getOpenId(*_) >> { throw new RuntimeException() }
    }

    def "authThirdPartyLogin case3: "() {
        when:
        wxSupportService.authThirdPartyLogin("thirdPartyType", "thirdPartyCode", new JSONObject())
        then:
        1 * wxApiSao.getOpenId(*_) >> null
    }

    def "getQrCodeUrl case1: "() {
        when:
        wxSupportService.getQrCodeUrl("pushOrderNo", new QrCodeInfo(), new JSONObject())
        then:
        1 * redisTemplateAccessToken.opsForValue(*_) >> valueOperations
        1 * redisDistributeLock.compareAndSet(*_) >> true
        1 * wxQrCodeSAO.getAccessToken(*_) >> {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("access_token", "access_token");
            return JSONObject.toJSONString(jsonObject);
        }
        1 * redisTemplateAccessToken.opsForValue(*_) >> valueOperations
        1 * wxQrCodeSAO.getQrTicket(*_) >> {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("ticket", "ticket");
            return JSONObject.toJSONString(jsonObject);
        }
    }


    def "getQrCodeUrl case2: "() {
        when:
        wxSupportService.getQrCodeUrl("pushOrderNo", new QrCodeInfo(), new JSONObject())
        then:
        1 * redisTemplateAccessToken.opsForValue(*_) >> valueOperations
        1 * redisDistributeLock.compareAndSet(*_) >> true
        1 * wxQrCodeSAO.getAccessToken(*_) >> null
    }

    def "getQrCodeUrl case3: "() {
        when:
        wxSupportService.getQrCodeUrl("pushOrderNo", new QrCodeInfo(), new JSONObject())
        then:
        1 * redisTemplateAccessToken.opsForValue(*_) >> valueOperations
        1 * redisDistributeLock.compareAndSet(*_) >> true
        1 * wxQrCodeSAO.getAccessToken(*_) >> {
            JSONObject jsonObject = new JSONObject();
            jsonObject.put("access_token", "access_token");
            return JSONObject.toJSONString(jsonObject);
        }
        1 * redisTemplateAccessToken.opsForValue(*_) >> valueOperations
        1 * wxQrCodeSAO.getQrTicket(*_) >> null
    }

    def "getQrCodeUrl case4: "() {
        when:
        wxSupportService.getQrCodeUrl(new QrCodeInfo(), new JSONObject())
        then:
        2 * sysConfSupportService.selectValueFromCache(*_) >> "val"
        1 * dswxApiSAO.getQrTicket(*_) >> "{'code':'0000','data':'http://mock/url'}";
    }

    def "getQrCodeUrl case5: "() {
        when:
        wxSupportService.getQrCodeUrl(new QrCodeInfo(), new JSONObject())
        then:
        2 * sysConfSupportService.selectValueFromCache(*_) >> "val"
        1 * dswxApiSAO.getQrTicket(*_) >> null
    }
}