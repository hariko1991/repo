package com.dashuf.dpbs.app.web

import com.dashuf.dpbs.app.web.req.user.DensityFreeLoginReq
import com.dashuf.dpbs.app.web.req.user.LoginCodeReq
import com.dashuf.dpbs.app.web.req.user.LoginPwdReq
import com.dashuf.dpbs.app.web.resp.user.LoginResp
import com.dashuf.dpbs.service.UserInfoSupportService
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.mock.web.MockHttpSession
import spock.lang.Specification

class UserLoginControllerTest extends Specification {

    MockHttpServletRequest request
    MockHttpServletResponse response
    MockHttpSession session

    def setup() {
        request = new MockHttpServletRequest()
        request.setCharacterEncoding("UTF-8")
        response = new MockHttpServletResponse()
        session = new MockHttpSession()
    }

    UserInfoSupportService userInfoSupportService = Mock(UserInfoSupportService)
    UserLoginController userLoginController = new UserLoginController(userInfoSupportService: userInfoSupportService)

    def "loginByPwd case1:密码方式登录"() {
        given:
        LoginPwdReq loginPwdReq = new LoginPwdReq()
        when:
        userLoginController.loginByPwd(request, response, loginPwdReq)
        then:
        1 * userInfoSupportService.loginByPwd(*_) >> null

    }

    def "loginByPwd case2:密码方式登录"() {
        given:
        LoginPwdReq loginPwdReq = new LoginPwdReq()
        when:
        userLoginController.loginByPwd(request, response, loginPwdReq)
        then:
        1 * userInfoSupportService.loginByPwd(*_) >> new LoginResp()
        1 * userInfoSupportService.initAccessTokenForUser(*_) >> null
    }

    def "loginByPwd case3:密码方式登录"() {
        given:
        LoginPwdReq loginPwdReq = new LoginPwdReq()
        when:
        userLoginController.loginByPwd(request, response, loginPwdReq)
        then:
        1 * userInfoSupportService.loginByPwd(*_) >> { throw new RuntimeException() }

    }

    def "loginByCode case1:验证码方式登录"() {
        given:
        LoginCodeReq loginCodeReq = new LoginCodeReq()
        when:
        userLoginController.loginByCode(request, response, loginCodeReq)
        then:
        1 * userInfoSupportService.loginByCode(*_) >> null
    }

    def "loginByCode case2:验证码方式登录"() {
        given:
        LoginCodeReq loginCodeReq = new LoginCodeReq()
        when:
        userLoginController.loginByCode(request, response, loginCodeReq)
        then:
        1 * userInfoSupportService.loginByCode(*_) >> new LoginResp()
        1 * userInfoSupportService.initAccessTokenForUser(*_) >> null
    }

    def "loginByCode case3:验证码方式登录"() {
        given:
        LoginCodeReq loginCodeReq = new LoginCodeReq()
        when:
        userLoginController.loginByCode(request, response, loginCodeReq)
        then:
        1 * userInfoSupportService.loginByCode(*_) >> { throw new RuntimeException() }
    }


    def "densityFreeLogin case1:免密码登录"() {
        given:
        DensityFreeLoginReq densityFreeLoginReq = new DensityFreeLoginReq()
        when:
        userLoginController.densityFreeLogin(request, response, densityFreeLoginReq)
        then:
        1 * userInfoSupportService.densityFreeLogin(*_) >> null
    }

    def "densityFreeLogin case2:免密码登录"() {
        given:
        DensityFreeLoginReq densityFreeLoginReq = new DensityFreeLoginReq()
        when:
        userLoginController.densityFreeLogin(request, response, densityFreeLoginReq)
        then:
        1 * userInfoSupportService.densityFreeLogin(*_) >> new LoginResp()
        1 * userInfoSupportService.initAccessTokenForUser(*_) >> null
    }

    def "densityFreeLogin case3:免密码登录"() {
        given:
        DensityFreeLoginReq densityFreeLoginReq = new DensityFreeLoginReq()
        when:
        userLoginController.densityFreeLogin(request, response, densityFreeLoginReq)
        then:
        1 * userInfoSupportService.densityFreeLogin(*_) >> { throw new RuntimeException() }
    }
}
