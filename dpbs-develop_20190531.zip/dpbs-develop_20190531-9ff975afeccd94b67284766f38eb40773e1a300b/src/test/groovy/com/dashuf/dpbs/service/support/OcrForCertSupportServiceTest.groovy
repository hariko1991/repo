package com.dashuf.dpbs.service.support

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.sao.ocr.OcrForCertSAO
import spock.lang.Specification

class OcrForCertSupportServiceTest extends Specification {
    OcrForCertSAO ocrForCertSAO = Mock(OcrForCertSAO)
    OcrForCertSupportService ocrForCertSupportService = new OcrForCertSupportService(ocrForCertSAO: ocrForCertSAO)

    def "ocrForCert case1: "() {
        when:
        ocrForCertSupportService.ocrForCert("pushOrderNo", null, new JSONObject())
        then:
        1 * ocrForCertSAO.ocrForCert(*_) >> {
            return com.dashuf.merlin.web.base.views.ResponseVo.fail("fail");
        }
    }

    def "ocrForCert case2: "() {
        when:
        ocrForCertSupportService.ocrForCert("pushOrderNo", null, new JSONObject())
        then:
        1 * ocrForCertSAO.ocrForCert(*_) >> {
            return com.dashuf.merlin.web.base.views.ResponseVo.fail("00", "success", "success");
        }
    }
}
