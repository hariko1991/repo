package com.dashuf.dpbs.app.web

import com.dashuf.dpbs.app.web.req.lawsuit.LawSuitReq
import com.dashuf.dpbs.app.web.resp.lawsuit.HistoryRecord
import com.dashuf.dpbs.app.web.resp.lawsuit.LawsuitResultResp
import com.dashuf.dpbs.model.LawsuitQueryRecord
import com.dashuf.dpbs.model.UserInfo
import com.dashuf.dpbs.service.LawsuitService
import com.dashuf.dpbs.service.UserInfoSupportService
import com.github.pagehelper.PageInfo
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.mock.web.MockHttpSession
import spock.lang.Specification

class LawsuitControllerTest extends Specification {
    MockHttpServletRequest request
    MockHttpServletResponse response
    MockHttpSession session

    def setup() {
        request = new MockHttpServletRequest()
        request.setCharacterEncoding("UTF-8")
        response = new MockHttpServletResponse()
        session = new MockHttpSession()
    }

    LawsuitService lawsuitService = Mock(LawsuitService)
    UserInfoSupportService userInfoSupportService = Mock(UserInfoSupportService)
    LawsuitController lawsuitController = new LawsuitController(lawsuitService: lawsuitService,
            userInfoSupportService: userInfoSupportService)

    def "getLawSuit case1:诉讼实时查询列表"() {
        given:
        LawSuitReq lawSuitReq = new LawSuitReq()
        lawSuitReq.setCertNo("certNo")
        lawSuitReq.setName("name")
        lawSuitReq.setUserNo("userNo")
        def count = 1
        when:
        lawsuitController.getLawSuit(lawSuitReq)
        then:
        1 * lawsuitService.getLeftCount(lawSuitReq.getUserNo()) >> count
        1 * lawsuitService.getLawsuit(*_) >> new LawsuitResultResp()
    }


    def "getCertification case1:查询是否实名认证"() {
        given:
        UserInfo userInfo = new UserInfo(certNo: "test", isVerify: "false")
        when:
        lawsuitController.getCertification("userNo")
        then:
        1 * userInfoSupportService.getUserInfo(*_) >> new UserInfo()
    }

    def "getCertification case2:查询是否实名认证"() {
        given:
        UserInfo userInfo = new UserInfo(isVerify: "false")
        when:
        lawsuitController.getCertification("userNo")
        then:
        1 * userInfoSupportService.getUserInfo(*_) >> new UserInfo()
    }


    def "getHistorySuitList case1:诉讼查询历史记录"() {
        given:
        String userNo = null
        UserInfo userInfo = new UserInfo(userNo: "userNo")
        when:
        lawsuitController.getHistorySuitList(userNo, null, "userNo")
        then:
        1 * lawsuitService.getHistoryQueryRecord(*_) >> {
            com.github.pagehelper.PageInfo<LawsuitQueryRecord> page = new PageInfo<>(new ArrayList<HistoryRecord>())
            return page;
        }
    }


    def "getLeftCount case1:诉讼剩余查询次数"() {
        given:
        String userNo = null
        UserInfo userInfo = new UserInfo(userNo: "userNo")
        when:
        lawsuitController.getLeftCount(userNo, "userNo")
        then:
        1 * lawsuitService.getLeftCount(*_) >> 1
    }

    def "getLocalResult case1:本地查询结果"() {
        given:
        Integer requestId = null
        when:
        lawsuitController.getLocalResult(requestId)
        then:
        1 * lawsuitService.getLocalResult(*_) >> new LawsuitResultResp()
    }
}
