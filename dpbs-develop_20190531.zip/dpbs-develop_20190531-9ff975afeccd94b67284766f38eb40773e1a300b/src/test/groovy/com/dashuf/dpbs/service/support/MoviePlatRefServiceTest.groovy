package com.dashuf.dpbs.service.support

import com.dashuf.dpbs.mapper.StepRefLogMapper
import com.ubtech.client.UBCMPClient
import com.ubtech.cmp.bean.ContentBean
import com.ubtech.cmp.bean.ContentDocBean
import com.ubtech.cmp.bean.FileBean
import com.ubtech.cmp.bean.SDKResultBean
import org.springframework.mock.web.MockMultipartFile
import org.springframework.web.multipart.MultipartFile
import spock.lang.Specification

class MoviePlatRefServiceTest extends Specification {
    UBCMPClient client = Mock(UBCMPClient)
    StepRefLogMapper stepRefLogMapper = Mock(StepRefLogMapper)
    MoviePlatRefService moviePlatRefService = new MoviePlatRefService(stepRefLogMapper: stepRefLogMapper,
            APPLICATION_UBECM_USER_NO: "222",
            APPLICATION_UBECM_USER_PASSWORD: "222",
            APPLICATION_UBECM_SERVER_IP: "22",
            APPLICATION_UBECM_SERVER_PORT: 222,
            APPLICATION_UBECM_SERVER_NAME: "222",
            APPLICATION_UBECM_SAVE_PATH: "222", client: client)

    def "copyTempFileToServer case1: "() {
        given:
        def name = "test.txt"
        def originalFilename = "test.txt"
        def contentType = "file"
        def content = "test".getBytes()
        def file = new MockMultipartFile(name, originalFilename, contentType, content)
        def fileList = new ArrayList<MockMultipartFile>()
        fileList.add(file)
        MultipartFile[] fileArr = fileList.toArray()
        when:
        moviePlatRefService.copyTempFileToServer(fileArr)
        then:
        1
    }

    def "deleteTempFileFromServer case1: "() {
        given:
        List<File> fileList = new ArrayList<>();
        File file = new File("file.txt");
        fileList.add(file)
        when:
        moviePlatRefService.deleteTempFileFromServer(fileList)
        then:
        1
    }

    def "uploadHandler case1: "() {
        given:
        def fileObj = new FileBean(fileCustomMap: new HashMap<String, String>(), FILE_ID: "111")
        def list = new ArrayList<FileBean>()
        list.add(fileObj)
        def contentBeans = new ArrayList<ContentBean>()
        def contentBean = new ContentBean()
        def contentDocBeans = new ArrayList<ContentDocBean>()
        def contentDocBean = new ContentDocBean()
        contentDocBean.setFiles(list)
        contentDocBeans.add(contentDocBean)
        contentBean.setDOC_BEANS(contentDocBeans)
        contentBeans.add(contentBean)
        def sdkBean = new SDKResultBean()
        sdkBean.setResultCode("SUCCESS")
        sdkBean.setContentBeans(contentBeans)

        def fileList = new ArrayList<File>()
        def file = new File("file.txt")
        fileList.add(file)

        when:
        moviePlatRefService.uploadHandler("loanStepCode", "applicationId", fileList)

        then:
        1 * client.upload(*_) >> sdkBean
        1 * stepRefLogMapper.insertSelective(*_) >> 1
    }

    def "queryHandler case1: "() {
        given:
        def sdkBean = new SDKResultBean()
        sdkBean.setResultCode("SUCCESS")

        when:
        moviePlatRefService.queryHandler("loanStepCode", "applicationId", "contentId")

        then:
        1 * client.queryContent(*_) >> sdkBean
        1 * stepRefLogMapper.insertSelective(*_) >> 1
    }

    def "queryHandler case2: "() {
        given:
        def fileBean = new FileBean()
        fileBean.setFileCustomMap(new HashMap<String, String>())
        def fileBeanList = new ArrayList<FileBean>()
        fileBeanList.add(fileBean)

        def docBean = new ContentDocBean()
        docBean.setFiles(fileBeanList)

        def docBeans = new ArrayList<ContentDocBean>()
        docBeans.add(docBean)

        def contentBean = new ContentBean()
        contentBean.setDOC_BEANS(docBeans)

        def contentBeanlist = new ArrayList<ContentBean>()
        contentBeanlist.add(contentBean)

        def sdkBean = new SDKResultBean()
        sdkBean.setResultCode("SUCCESS")
        sdkBean.setContentBeans(contentBeanlist)

        when:
        moviePlatRefService.queryHandler("loanStepCode", "applicationId", "contentId")

        then:
        1 * client.queryContent(*_) >> sdkBean
        1 * stepRefLogMapper.insertSelective(*_) >> 1
    }
}

