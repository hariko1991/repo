package com.dashuf.dpbs.service

import com.dashuf.dpbs.mapper.SysAreaInfoMapper
import com.dashuf.dpbs.mapper.SysConfMapper
import com.dashuf.dpbs.mapper.SysDictMapper
import com.dashuf.dpbs.model.SysAreaInfo
import com.dashuf.dpbs.model.SysConf
import com.dashuf.dpbs.model.SysDict
import org.springframework.beans.factory.annotation.Autowired
import org.springframework.data.redis.connection.RedisConnection
import org.springframework.data.redis.connection.RedisConnectionFactory
import org.springframework.data.redis.core.RedisOperations
import org.springframework.data.redis.core.StringRedisTemplate
import org.springframework.data.redis.core.ValueOperations
import spock.lang.Specification

class CacheInitServiceTest extends Specification {
    SysAreaInfoMapper sysAreaInfoMapper = Mock()
    SysDictMapper sysDictMapper = Mock(SysDictMapper)
    SysConfMapper sysConfMapper = Mock(SysConfMapper);
    ValueOperations valueOperations = Mock(ValueOperations.class)
    RedisOperations redisOperations = Mock(RedisOperations.class)
    RedisConnection redisConnection = Mock(RedisConnection.class)
    RedisConnectionFactory redisConnectionFactory = Mock(RedisConnectionFactory.class)

    StringRedisTemplate redisTemplate = Mock(StringRedisTemplate)

    CacheInitService cacheInitService = new CacheInitService(
            sysAreaInfoMapper: sysAreaInfoMapper,
            sysDictMapper: sysDictMapper,
            sysConfMapper: sysConfMapper,
            redisTemplate: redisTemplate)

    def "initCache case1: "() {
        when:
        cacheInitService.initCache()
        then:
        1 * sysAreaInfoMapper.selectByModelSelective(*_) >> {
            List<SysAreaInfo> sysAreaInfoList = new ArrayList<>();
            SysAreaInfo sysAreaInfo = new SysAreaInfo();
            sysAreaInfoList.add(sysAreaInfo);
            return sysAreaInfoList;
        }
        1 * sysDictMapper.selectByModelSelective(*_) >> {
            List<SysDict> sysAreaInfoList = new ArrayList<>();
            SysDict sysAreaInfo = new SysDict();
            sysAreaInfoList.add(sysAreaInfo);
            return sysAreaInfoList;
        }
        1 * sysConfMapper.selectSysConfList(*_) >> null
    }

    def "initSysAreaInfo case1: "() {
        when:
        cacheInitService.initSysAreaInfo()
        then:
        1 * sysAreaInfoMapper.selectByModelSelective(*_) >> {
            List<SysAreaInfo> sysAreaInfoList = new ArrayList<>();
            SysAreaInfo sysAreaInfo = new SysAreaInfo();
            sysAreaInfoList.add(sysAreaInfo);
            return sysAreaInfoList;
        }
    }

    def "initSysDictInfo case1: "() {
        when:
        cacheInitService.initSysDictInfo();
        then:
        1 * sysDictMapper.selectByModelSelective(*_) >> {
            List<SysDict> sysAreaInfoList = new ArrayList<>();
            SysDict sysAreaInfo = new SysDict();
            sysAreaInfoList.add(sysAreaInfo);
            return sysAreaInfoList;
        }
    }

    def "initSysConf case1: "() {
        when:
        cacheInitService.initSysConf();
        then:
        1 * sysConfMapper.selectSysConfList(*_) >> {
            List<SysConf> sysConfList = new ArrayList<>()
            SysConf sysConf = new SysConf()
            sysConf.setModuleCode("moduleCode")
            sysConf.setModuleSubCode("moduleSubCode")
            sysConf.setModuleKey("moduleKey")
            sysConf.setModuleVal("moduleVal")
            sysConfList.add(sysConf)
            return sysConfList
        }
        1 * redisTemplate.opsForValue() >> valueOperations
    }

    def "initSysConf case2: "() {
        when:
        cacheInitService.initSysConf();
        then:
        1 * sysConfMapper.selectSysConfList(*_) >> {
            List<SysConf> sysConfList = new ArrayList<>()
            SysConf sysConf = new SysConf()
            sysConf.setModuleCode("moduleCode")
            sysConf.setModuleSubCode("moduleSubCode")
            sysConf.setModuleKey("moduleKey")
            sysConf.setModuleVal("moduleVal")
            sysConfList.add(sysConf)
            sysConf = new SysConf()
            sysConf.setModuleCode("moduleCode")
            sysConf.setModuleSubCode("moduleSubCode1")
            sysConf.setModuleKey("moduleKey")
            sysConfList.add(sysConf)
            return sysConfList
        }
        1 * redisTemplate.opsForValue() >> valueOperations
    }

    def "updateSysConfFromRedis case1: "() {
        given:
        SysConf sysConf = new SysConf()
        sysConf.setModuleCode("moduleCode")
        sysConf.setModuleSubCode("moduleSubCode")
        sysConf.setModuleKey("moduleKey")
        sysConf.setModuleVal("moduleVal")
        when:
        cacheInitService.updateSysConfFromRedis(sysConf)
        then:
        1 * redisTemplate.opsForValue() >> valueOperations
    }
}
