package com.dashuf.dpbs.service

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.app.web.req.user.DensityFreeLoginReq
import com.dashuf.dpbs.app.web.req.user.ForgetPwdReq
import com.dashuf.dpbs.app.web.req.user.LoginCodeReq
import com.dashuf.dpbs.app.web.req.user.LoginPwdReq
import com.dashuf.dpbs.app.web.req.user.ModifyPwdReq
import com.dashuf.dpbs.app.web.req.user.RegReq
import com.dashuf.dpbs.mapper.UserInfoMapper
import com.dashuf.dpbs.model.UserInfo
import com.dashuf.dpbs.service.support.VerifyCodeService
import com.dashuf.dpbs.service.support.WxSupportService
import com.dashuf.dpbs.util.MD5Util
import org.springframework.data.redis.connection.RedisConnection
import org.springframework.data.redis.connection.RedisConnectionFactory
import org.springframework.data.redis.core.RedisOperations
import org.springframework.data.redis.core.StringRedisTemplate
import org.springframework.data.redis.core.ValueOperations
import spock.lang.Specification

class UserInfoSupportServiceTest extends Specification {

    ValueOperations valueOperations = Mock(ValueOperations.class)
    RedisOperations redisOperations = Mock(RedisOperations.class)
    RedisConnection redisConnection = Mock(RedisConnection.class)
    RedisConnectionFactory redisConnectionFactory = Mock(RedisConnectionFactory.class)

    StringRedisTemplate redisTemplate = Mock(StringRedisTemplate)
    UserInfoMapper userInfoMapper = Mock(UserInfoMapper)
    WxSupportService wxSupportService = Mock(WxSupportService)
    VerifyCodeService verifyCodeService = Mock(VerifyCodeService)

    UserInfoSupportService userInfoSupportService = new UserInfoSupportService(redisTemplate: redisTemplate, userInfoMapper: userInfoMapper, wxSupportService: wxSupportService, verifyCodeService: verifyCodeService)

    def "regUser case1: "() {
        given:
        RegReq regReq = new RegReq();
        regReq.setConfirmPwd("pwd");
        regReq.setUserPwd("pwds");
        when:
        userInfoSupportService.regUser(regReq, new JSONObject())
        then:
        1
    }

    def "regUser case2: "() {
        given:
        RegReq regReq = new RegReq();
        regReq.setConfirmPwd("pwd");
        regReq.setUserPwd("pwd");
        when:
        userInfoSupportService.regUser(regReq, new JSONObject())
        then:
        1 * verifyCodeService.checkVerifyCode(*_) >> false
    }

    def "regUser case3: "() {
        given:
        RegReq regReq = new RegReq();
        regReq.setConfirmPwd("pwd");
        regReq.setUserPwd("pwd");
        when:
        userInfoSupportService.regUser(regReq, new JSONObject())
        then:
        1 * verifyCodeService.checkVerifyCode(*_) >> true
        1 * wxSupportService.getOpenId(*_) >> "openId"
        1 * userInfoMapper.initUserInfoByReg(*_) >> 0
    }

    def "regUser case4: "() {
        given:
        RegReq regReq = new RegReq();
        regReq.setConfirmPwd("pwd");
        regReq.setUserPwd("pwd");
        when:
        userInfoSupportService.regUser(regReq, new JSONObject())
        then:
        1 * verifyCodeService.checkVerifyCode(*_) >> true
        1 * wxSupportService.getOpenId(*_) >> "openId"
        1 * userInfoMapper.initUserInfoByReg(*_) >> 1
    }

    def "loginByPwd case1: "() {
        given:
        LoginPwdReq loginPwdReq = new LoginPwdReq();
        loginPwdReq.setMobileNo("18765678789")
        loginPwdReq.setUserPwd("pwd")
        when:
        userInfoSupportService.loginByPwd(loginPwdReq, new JSONObject())

        then:
        1 * redisTemplate.opsForValue() >> valueOperations
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> {
            UserInfo userInfo = new UserInfo();
            userInfo.setUserPwd(MD5Util.EncoderByMd5(loginPwdReq.getUserPwd()));
            return userInfo;
        }
        1 * wxSupportService.getOpenId(*_) >> "openId"
        1 * userInfoMapper.updateUserInfo(*_) >> 1
    }

    def "loginByPwd case2: "() {
        given:
        LoginPwdReq loginPwdReq = new LoginPwdReq();
        loginPwdReq.setMobileNo("18765678789")
        loginPwdReq.setUserPwd("pwd")
        when:
        userInfoSupportService.loginByPwd(loginPwdReq, new JSONObject())

        then:
        1 * redisTemplate.opsForValue() >> valueOperations
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> {
            UserInfo userInfo = new UserInfo();
            userInfo.setUserPwd(MD5Util.EncoderByMd5(loginPwdReq.getUserPwd()));
            userInfo.setOpenId("open");
            return userInfo;
        }
        1 * wxSupportService.getOpenId(*_) >> "openId"
        1 * userInfoMapper.updateUserInfo(*_) >> 1
    }


    def "loginByPwd case3: "() {
        given:
        LoginPwdReq loginPwdReq = new LoginPwdReq();
        loginPwdReq.setMobileNo("18765678789")
        loginPwdReq.setUserPwd("pwd")
        when:
        userInfoSupportService.loginByPwd(loginPwdReq, new JSONObject())

        then:
        1 * redisTemplate.opsForValue() >> valueOperations
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> {
            UserInfo userInfo = new UserInfo();
            userInfo.setUserPwd("pwd");
            userInfo.setOpenId("open");
            return userInfo;
        }
        2 * redisTemplate.opsForValue() >> valueOperations
    }

    def "loginByCode case1: "() {
        given:
        LoginCodeReq loginCodeReq = new LoginCodeReq();
        loginCodeReq.setMobileNo("18765678789")
        loginCodeReq.setVerifyCode("2343434")
        when:
        userInfoSupportService.loginByCode(loginCodeReq, new JSONObject())

        then:
        1 * redisTemplate.opsForValue() >> valueOperations
        1 * verifyCodeService.checkVerifyCode(*_) >> false
    }

    def "loginByCode case2: "() {
        given:
        LoginCodeReq loginCodeReq = new LoginCodeReq();
        loginCodeReq.setMobileNo("18765678789")
        loginCodeReq.setVerifyCode("2343434")
        when:
        userInfoSupportService.loginByCode(loginCodeReq, new JSONObject())

        then:
        1 * redisTemplate.opsForValue() >> valueOperations
        1 * verifyCodeService.checkVerifyCode(*_) >> true
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> {
            UserInfo userInfo = new UserInfo();
            userInfo.setOpenId("open");
            return userInfo;
        }
        1 * wxSupportService.getOpenId(*_) >> "openId"
    }

    def "modifyPwd case1: "() {
        given:
        ModifyPwdReq modifyPwdReq = new ModifyPwdReq()
        modifyPwdReq.setUserPwd("pwd");
        modifyPwdReq.setConfirmPwd("pwd1");
        when:
        userInfoSupportService.modifyPwd(modifyPwdReq, new JSONObject())
        then:
        1
    }

    def "modifyPwd case2: "() {
        given:
        ModifyPwdReq modifyPwdReq = new ModifyPwdReq()
        modifyPwdReq.setUserPwd("pwd");
        modifyPwdReq.setConfirmPwd("pwd");
        when:
        userInfoSupportService.modifyPwd(modifyPwdReq, new JSONObject())
        then:
        1 * verifyCodeService.checkVerifyCode(*_) >> true
        1 * userInfoMapper.updateUserInfo(*_) >> 1
    }

    def "forgetPwd case1: "() {
        given:
        ForgetPwdReq forgetPwdReq = new ForgetPwdReq();
        forgetPwdReq.setUserPwd("pwd");
        forgetPwdReq.setConfirmPwd("pwd1");
        when:
        userInfoSupportService.forgetPwd(forgetPwdReq, new JSONObject())
        then:
        1
    }

    def "forgetPwd case2: "() {
        given:
        ForgetPwdReq forgetPwdReq = new ForgetPwdReq();
        forgetPwdReq.setUserPwd("pwd");
        forgetPwdReq.setConfirmPwd("pwd");
        when:
        userInfoSupportService.forgetPwd(forgetPwdReq, new JSONObject())
        then:
        1 * verifyCodeService.checkVerifyCode(*_) >> true
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> {
            UserInfo userInfo = new UserInfo();
            userInfo.setUserPwd(MD5Util.EncoderByMd5(forgetPwdReq.getUserPwd()));
            userInfo.setOpenId("open");
            return userInfo;
        }
        1 * userInfoMapper.updateUserInfo(*_) >> 1
    }

    def "densityFreeLogin case1: "() {
        given:
        DensityFreeLoginReq densityFreeLoginReq = new DensityFreeLoginReq();

        when:
        userInfoSupportService.densityFreeLogin(densityFreeLoginReq, new JSONObject())

        then:
        1 * wxSupportService.authThirdPartyLogin(*_) >> "code"
        1 * userInfoMapper.selectOneByModelSelective(*_) >> new UserInfo()
    }
}
