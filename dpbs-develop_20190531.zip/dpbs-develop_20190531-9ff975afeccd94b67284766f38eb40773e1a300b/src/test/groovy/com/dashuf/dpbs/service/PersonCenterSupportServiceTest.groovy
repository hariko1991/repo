package com.dashuf.dpbs.service

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.app.web.req.center.BindClientManagerReq
import com.dashuf.dpbs.app.web.req.center.GetContactMsgReq
import com.dashuf.dpbs.app.web.req.center.GetPersonCenterReq
import com.dashuf.dpbs.app.web.req.center.ModifyMobileNoReq
import com.dashuf.dpbs.app.web.req.center.UnBindClientManagerReq
import com.dashuf.dpbs.app.web.req.center.VerifyMobileNoReq
import com.dashuf.dpbs.app.web.req.user.VerifyCertReq
import com.dashuf.dpbs.mapper.UserInfoMapper
import com.dashuf.dpbs.model.UserInfo
import com.dashuf.dpbs.service.cpms.MarketManagerSupportService
import com.dashuf.dpbs.service.support.ElecSignService
import com.dashuf.dpbs.service.support.IcpAuthSupportService
import com.dashuf.dpbs.service.support.VerifyCodeService
import spock.lang.Specification

class PersonCenterSupportServiceTest extends Specification {
    VerifyCodeService verifyCodeService = Mock(VerifyCodeService);
    UserInfoMapper userInfoMapper = Mock(UserInfoMapper);
    IcpAuthSupportService icpAuthSupportService = Mock(IcpAuthSupportService);
    SysConfSupportService sysConfSupportService = Mock(SysConfSupportService);
    ElecSignService elecSignService = Mock(ElecSignService);
    MarketManagerSupportService marketManagerSupportService = Mock(MarketManagerSupportService)

    PersonCenterSupportService personCenterSupportService = new PersonCenterSupportService(verifyCodeService: verifyCodeService,
            userInfoMapper: userInfoMapper,
            icpAuthSupportService: icpAuthSupportService,
            sysConfSupportService: sysConfSupportService,
            elecSignService: elecSignService,
            marketManagerSupportService: marketManagerSupportService)

    def "modifyMobileNo case1: "() {
        given:
        ModifyMobileNoReq modifyMobileNoReq = new ModifyMobileNoReq()
        when:
        personCenterSupportService.modifyMobileNo(modifyMobileNoReq, new JSONObject())
        then:
        1 * verifyCodeService.checkVerifyCode(*_) >> true
        1 * userInfoMapper.updateMobileNoOfUser(*_) >> 1
    }

    def "modifyMobileNo case2: "() {
        given:
        ModifyMobileNoReq modifyMobileNoReq = new ModifyMobileNoReq()
        when:
        personCenterSupportService.modifyMobileNo(modifyMobileNoReq, new JSONObject())
        then:
        1 * verifyCodeService.checkVerifyCode(*_) >> true
        1 * userInfoMapper.updateMobileNoOfUser(*_) >> 0
    }

    def "verifyMobileNo case1: "() {
        when:
        personCenterSupportService.verifyMobileNo(new VerifyMobileNoReq(), new JSONObject());
        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> null
    }

    def "verifyMobileNo case2: "() {
        when:
        personCenterSupportService.verifyMobileNo(new VerifyMobileNoReq(), new JSONObject());
        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> new UserInfo()
    }

    def "verifyCert case1: "() {
        given:
        VerifyCertReq verifyCertReq = new VerifyCertReq();
        when:
        personCenterSupportService.verifyCert(verifyCertReq, new JSONObject())
        then:
        1 * verifyCodeService.checkVerifyCode(*_) >> true
        1 * elecSignService.elecCreditAuth(*_) >> true
        1 * icpAuthSupportService.checkPersonMsg(*_) >> true
        1 * userInfoMapper.updateUserInfo(*_) >> 1
    }

    def "verifyCert case2: "() {
        given:
        VerifyCertReq verifyCertReq = new VerifyCertReq();
        when:
        personCenterSupportService.verifyCert(verifyCertReq, new JSONObject())
        then:
        1 * verifyCodeService.checkVerifyCode(*_) >> true
        1 * elecSignService.elecCreditAuth(*_) >> true
        1 * icpAuthSupportService.checkPersonMsg(*_) >> true
        1 * userInfoMapper.updateUserInfo(*_) >> 0
    }

    def "getPersonCenter case1: "() {
        given:
        GetPersonCenterReq getPersonCenterReq = new GetPersonCenterReq();
        when:
        personCenterSupportService.getPersonCenter(new GetPersonCenterReq(), new JSONObject())
        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> null
    }

    def "getPersonCenter case2: "() {
        when:
        personCenterSupportService.getPersonCenter(new GetPersonCenterReq(), new JSONObject())
        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> new UserInfo()
    }

    def "bindClientManager case1: "() {
        when:
        personCenterSupportService.bindClientManager(new BindClientManagerReq(srcUmNo: "test"), new JSONObject())
        then:
        //1 * marketManagerSupportService.getDetailOfUmNo(*_) >> true
        1 * userInfoMapper.updateUserInfo(*_) >> 1
    }

    def "bindClientManager case2: "() {
        when:
        personCenterSupportService.bindClientManager(new BindClientManagerReq(srcUmNo: "test"), new JSONObject())
        then:
        // 1 * marketManagerSupportService.getDetailOfUmNo(*_) >> true
        1 * userInfoMapper.updateUserInfo(*_) >> 0
    }

    def "unBindClientManager case1: "() {
        when:
        personCenterSupportService.unBindClientManager(new UnBindClientManagerReq(), new JSONObject())
        then:
        1 * userInfoMapper.unBindClientManager(*_) >> 1
    }

    def "unBindClientManager case2: "() {
        when:
        personCenterSupportService.unBindClientManager(new UnBindClientManagerReq(), new JSONObject())
        then:
        1 * userInfoMapper.unBindClientManager(*_) >> 0
    }

    def "getContactMsg case1: "() {
        when:
        personCenterSupportService.getContactMsg(new GetContactMsgReq(userNo: "userNo"), new JSONObject())
        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> new UserInfo()
        2 * sysConfSupportService.selectValueFromCache(*_) >> "confVal"
    }

    def "getContactMsg case2: "() {
        when:
        personCenterSupportService.getContactMsg(new GetContactMsgReq(userNo: "userNo"), new JSONObject())
        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> null
    }
}
