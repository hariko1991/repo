package com.dashuf.dpbs.app.web

import com.dashuf.dpbs.app.web.req.QrOfLoanAppReq
import com.dashuf.dpbs.app.web.req.center.VerifyMobileNoReq
import com.dashuf.dpbs.app.web.req.support.GatherFormIdReq
import com.dashuf.dpbs.app.web.req.support.GetCompanyOfUmReq
import com.dashuf.dpbs.app.web.req.support.GetExclusiveChannelReq
import com.dashuf.dpbs.app.web.resp.support.FindUMReq
import com.dashuf.dpbs.app.web.resp.support.GetCompanyOfUmResp
import com.dashuf.dpbs.app.web.resp.support.GetCompanyResp
import com.dashuf.dpbs.app.web.resp.support.GetExclusiveChannelResp
import com.dashuf.dpbs.app.web.resp.support.GetOcrOfCertResp
import com.dashuf.dpbs.app.web.resp.support.GetTeamOfUmResp
import com.dashuf.dpbs.model.UserInfo
import com.dashuf.dpbs.service.SupportRefService
import com.dashuf.dpbs.service.cpms.MarketManagerSupportService
import com.dashuf.dpbs.service.laapp.ApkPackageSupportService
import com.dashuf.dpbs.service.support.OcrForCertSupportService
import com.dashuf.dpbs.service.ucss.UserAuthSupportService
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.mock.web.MockHttpSession
import org.springframework.web.multipart.MultipartFile
import spock.lang.Specification

class SupportRefControllerTest extends Specification {
    MockHttpServletRequest request
    MockHttpServletResponse response
    MockHttpSession session

    def setup() {
        request = new MockHttpServletRequest()
        request.setCharacterEncoding("UTF-8")
        response = new MockHttpServletResponse()
        session = new MockHttpSession()
    }

    MarketManagerSupportService marketManagerSupportService = Mock(MarketManagerSupportService)
    ApkPackageSupportService apkPackageSupportService = Mock(ApkPackageSupportService)
    UserAuthSupportService userAuthSupportService = Mock(UserAuthSupportService)
    SupportRefService supportRefService = Mock(SupportRefService)
    OcrForCertSupportService ocrForCertSupportService = Mock(OcrForCertSupportService)
    SupportRefController supportRefController = new SupportRefController(marketManagerSupportService: marketManagerSupportService,
            apkPackageSupportService: apkPackageSupportService, userAuthSupportService: userAuthSupportService, supportRefService: supportRefService,
            ocrForCertSupportService: ocrForCertSupportService)

    def "getLoanApp case1:获取贷款APP"() {
        given:
        QrOfLoanAppReq qrOfLoanAppReq = new QrOfLoanAppReq()
        when:
        supportRefController.getLoanApp(qrOfLoanAppReq)
        then:
        1 * apkPackageSupportService.getLoanAppQr(*_) >> null
    }

    def "getLoanApp case2:获取贷款APP"() {
        given:
        QrOfLoanAppReq qrOfLoanAppReq = new QrOfLoanAppReq()
        when:
        supportRefController.getLoanApp(qrOfLoanAppReq)
        then:
        1 * apkPackageSupportService.getLoanAppQr(*_) >> "test"
    }

    def "getLoanApp case3:获取贷款APP"() {
        given:
        QrOfLoanAppReq qrOfLoanAppReq = new QrOfLoanAppReq()
        when:
        supportRefController.getLoanApp(qrOfLoanAppReq)
        then:
        1 * apkPackageSupportService.getLoanAppQr(*_) >> { throw new RuntimeException() }
    }


    def "initDataDict case1:初始化数据字典"() {
        given:
        when:
        supportRefController.initDataDict()
        then:
        1
    }

    def "getExclusiveChannel case1:用户所属公司查询"() {
        given:
        GetExclusiveChannelReq getExclusiveChannelReq = new GetExclusiveChannelReq()
        when:
        supportRefController.getExclusiveChannel(getExclusiveChannelReq)
        then:
        1 * marketManagerSupportService.getExclusiveChannel(*_) >> null
    }

    def "getExclusiveChannel case2:用户所属公司查询"() {
        given:
        GetExclusiveChannelReq getExclusiveChannelReq = new GetExclusiveChannelReq()
        when:
        supportRefController.getExclusiveChannel(getExclusiveChannelReq)
        then:
        1 * marketManagerSupportService.getExclusiveChannel(*_) >> new ArrayList<GetExclusiveChannelResp.ExclusiveChannel>()
    }

    def "getExclusiveChannel case3:用户所属公司查询"() {
        given:
        GetExclusiveChannelReq getExclusiveChannelReq = new GetExclusiveChannelReq()
        when:
        supportRefController.getExclusiveChannel(getExclusiveChannelReq)
        then:
        1 * marketManagerSupportService.getExclusiveChannel(*_) >> { throw new RuntimeException() }
    }


    def "gatherFormIdForPushMsg case1:收集微信小程序formid"() {
        given:
        List<String> list = new ArrayList<>()
        list.add("test")
        GatherFormIdReq gatherFormIdReq = new GatherFormIdReq(formIdList: list)
        UserInfo userInfo = new UserInfo()
        when:
        supportRefController.gatherFormIdForPushMsg(gatherFormIdReq, "userNo")
        then:
        1 * supportRefService.gatherFormIdForPushMsg(*_) >> false
    }

    def "gatherFormIdForPushMsg case2:收集微信小程序formid"() {
        given:
        GatherFormIdReq gatherFormIdReq = new GatherFormIdReq()
        UserInfo userInfo = new UserInfo()
        when:
        supportRefController.gatherFormIdForPushMsg(gatherFormIdReq, "userNo")
        then:
        1
    }

    def "gatherFormIdForPushMsg case3:收集微信小程序formid"() {
        given:
        List<String> list = new ArrayList<>()
        list.add("test")
        GatherFormIdReq gatherFormIdReq = new GatherFormIdReq(formIdList: list)
        UserInfo userInfo = new UserInfo()
        when:
        supportRefController.gatherFormIdForPushMsg(gatherFormIdReq, "userNo")
        then:
        1 * supportRefService.gatherFormIdForPushMsg(*_) >> true
    }

    def "gatherFormIdForPushMsg case4:收集微信小程序formid"() {
        given:
        List<String> list = new ArrayList<>()
        list.add("test")
        GatherFormIdReq gatherFormIdReq = new GatherFormIdReq(formIdList: list)
        UserInfo userInfo = new UserInfo()
        when:
        supportRefController.gatherFormIdForPushMsg(gatherFormIdReq, "userNo")
        then:
        1 * supportRefService.gatherFormIdForPushMsg(*_) >> { throw new RuntimeException() }
    }

    def "getCompanyOfUm case1:获取客户经理所属分公司"() {
        given:
        GetCompanyOfUmReq getCompanyOfUmReq = new GetCompanyOfUmReq()
        when:
        supportRefController.getCompanyOfUm(getCompanyOfUmReq)
        then:
        1 * userAuthSupportService.getCompanyListOfUser(*_) >> null
    }

    def "getCompanyOfUm case2:获取客户经理所属分公司"() {
        given:
        GetCompanyOfUmReq getCompanyOfUmReq = new GetCompanyOfUmReq()
        when:
        supportRefController.getCompanyOfUm(getCompanyOfUmReq)
        then:
        1 * userAuthSupportService.getCompanyListOfUser(*_) >> new GetCompanyOfUmResp()
    }

    def "getCompanyOfUm case3:获取客户经理所属分公司"() {
        given:
        GetCompanyOfUmReq getCompanyOfUmReq = new GetCompanyOfUmReq()
        when:
        supportRefController.getCompanyOfUm(getCompanyOfUmReq)
        then:
        1 * userAuthSupportService.getCompanyListOfUser(*_) >> { throw new RuntimeException() }
    }


    def "getCompany case1:获取所属分公司"() {
        given:
        when:
        supportRefController.getCompany()
        then:
        1 * userAuthSupportService.getCompanyList(*_) >> null
    }

    def "getCompany case2:获取所属分公司"() {
        given:
        when:
        supportRefController.getCompany()
        then:
        1 * userAuthSupportService.getCompanyList(*_) >> new GetCompanyResp()
    }

    def "getCompany case3:获取所属分公司"() {
        given:
        when:
        supportRefController.getCompany()
        then:
        1 * userAuthSupportService.getCompanyList(*_) >> { throw new RuntimeException() }
    }


    def "ocrForCert case1:身份证ocr识别"() {
        given:
        String pushOrderNo = null
        MultipartFile file = null
        when:
        supportRefController.ocrForCert(pushOrderNo, file)
        then:
        1 * ocrForCertSupportService.ocrForCert(*_) >> null
    }

    def "ocrForCert case2:身份证ocr识别"() {
        given:
        String pushOrderNo = null
        MultipartFile file = null
        when:
        supportRefController.ocrForCert(pushOrderNo, file)
        then:
        1 * ocrForCertSupportService.ocrForCert(*_) >> new GetOcrOfCertResp()
    }

    def "ocrForCert case3:身份证ocr识别"() {
        given:
        String pushOrderNo = null
        MultipartFile file = null
        when:
        supportRefController.ocrForCert(pushOrderNo, file)
        then:
        1 * ocrForCertSupportService.ocrForCert(*_) >> { throw new RuntimeException() }
    }

    def "verifyMobileNo case1:校验手机号码"() {
        given:
        VerifyMobileNoReq verifyMobileNoReq = new VerifyMobileNoReq()
        when:
        supportRefController.verifyMobileNo(verifyMobileNoReq)
        then:
        1 * supportRefService.verifyMobileNo(*_) >> false

    }

    def "verifyMobileNo case2:校验手机号码"() {
        given:
        VerifyMobileNoReq verifyMobileNoReq = new VerifyMobileNoReq()
        when:
        supportRefController.verifyMobileNo(verifyMobileNoReq)
        then:
        1 * supportRefService.verifyMobileNo(*_) >> true

    }

    def "verifyMobileNo case3:校验手机号码"() {
        given:
        VerifyMobileNoReq verifyMobileNoReq = new VerifyMobileNoReq()
        when:
        supportRefController.verifyMobileNo(verifyMobileNoReq)
        then:
        1 * supportRefService.verifyMobileNo(*_) >> { throw new RuntimeException() }
    }

    def "getExclusiveChannelAvailable case1:可用专属渠道"() {

        given:
        GetExclusiveChannelReq getExclusiveChannelReq = new GetExclusiveChannelReq()
        getExclusiveChannelReq.with {
            channelName = ""
        }
        when:
        supportRefController.getExclusiveChannelAvailable(getExclusiveChannelReq)
        then:
        1 * marketManagerSupportService.getExclusiveChannelAvailable(*_) >> null
    }

    def "getExclusiveChannelAvailable case2:可用专属渠道"() {
        given:
        GetExclusiveChannelReq getExclusiveChannelReq = new GetExclusiveChannelReq()
        getExclusiveChannelReq.with {
            channelName = ""
        }
        when:
        supportRefController.getExclusiveChannelAvailable(getExclusiveChannelReq)
        then:
        1 * marketManagerSupportService.getExclusiveChannelAvailable(*_) >> {
            List<GetExclusiveChannelResp.ExclusiveChannel> getExclusiveChannelList = new ArrayList<>()
            GetExclusiveChannelResp.ExclusiveChannel exclusiveChannel = new GetExclusiveChannelResp.ExclusiveChannel()
            getExclusiveChannelList.add(exclusiveChannel)
            return getExclusiveChannelList
        }
    }

    def "getExclusiveChannelAvailable case3:可用专属渠道"() {
        given:
        GetExclusiveChannelReq getExclusiveChannelReq = new GetExclusiveChannelReq()
        getExclusiveChannelReq.with {
            channelName = ""
        }
        when:
        supportRefController.getExclusiveChannelAvailable(getExclusiveChannelReq)
        then:
        1 * marketManagerSupportService.getExclusiveChannelAvailable(*_) >> {
            throw new RuntimeException()
        }
    }
}
