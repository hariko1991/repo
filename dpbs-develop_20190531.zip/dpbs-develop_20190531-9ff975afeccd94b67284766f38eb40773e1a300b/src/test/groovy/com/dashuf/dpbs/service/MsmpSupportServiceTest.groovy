package com.dashuf.dpbs.service

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.app.web.req.msmp.GetUserDetailReq
import com.dashuf.dpbs.app.web.resp.msmp.ClientBean
import com.dashuf.dpbs.app.web.resp.msmp.UserBean
import com.dashuf.dpbs.mapper.MsmpSupportMapper
import spock.lang.Specification

class MsmpSupportServiceTest extends Specification {
    MsmpSupportMapper msmpSupportMapper = Mock(MsmpSupportMapper)
    MsmpSupportService msmpSupportService = new MsmpSupportService(msmpSupportMapper: msmpSupportMapper)

    def "selectClientPage case1: "() {
        when:
        msmpSupportService.selectClientPage(1, 1, null, null)
        then:
        1 * msmpSupportMapper.getClientList(*_) >> new ArrayList<ClientBean>()
    }

    def "selectUserPage case1: "() {
        when:
        msmpSupportService.selectUserPage(1, 1, null, null)
        then:
        1 * msmpSupportMapper.getUserList(*_) >> new ArrayList<UserBean>()
    }

    def "selectPendClientPage case1: "() {
        when:
        msmpSupportService.selectPendClientPage(1, 1, null, null)
        then:
        1 * msmpSupportMapper.getPendClientList(*_) >> new ArrayList<ClientBean>()
    }

    def "selectAlreadyClientPage case1: "() {
        when:
        msmpSupportService.selectAlreadyClientPage(1, 1, null, null)
        then:
        1 * msmpSupportMapper.getAlreadyClientList(*_) >> new ArrayList<ClientBean>()
    }

    def "modifyUserCompany case1: "() {
        when:
        msmpSupportService.modifyUserCompany(null, null, null)
        then:
        1 * msmpSupportMapper.modifyUserCompany(*_) >> 1
    }

    def "getDetail case1: "() {
        given:
        GetUserDetailReq getUserRefReq = new GetUserDetailReq()
        when:
        msmpSupportService.getDetail(getUserRefReq, new JSONObject())
        then:
        1 * msmpSupportMapper.getDetailOfUser(*_) >> null
    }

    def "getDetail case2: "() {
        given:
        GetUserDetailReq getUserRefReq = new GetUserDetailReq()
        when:
        msmpSupportService.getDetail(getUserRefReq, new JSONObject())
        then:
        1 * msmpSupportMapper.getDetailOfUser(*_) >> new UserBean()
        1 * msmpSupportMapper.statUserReconForm(*_) >> {
            Map<String, String> rtnMap = new HashMap<String, String>();
            rtnMap.put("total_cnt", "22");
            return rtnMap;
        }

    }

}
