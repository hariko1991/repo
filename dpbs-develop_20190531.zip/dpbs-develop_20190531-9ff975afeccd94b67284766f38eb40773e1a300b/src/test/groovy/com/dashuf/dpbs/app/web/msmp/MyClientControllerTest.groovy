package com.dashuf.dpbs.app.web.msmp

import com.dashuf.dpbs.app.web.req.msmp.ClientPageReq
import com.dashuf.dpbs.app.web.resp.msmp.ClientBean
import com.dashuf.dpbs.service.MsmpSupportService
import com.github.pagehelper.PageInfo
import spock.lang.Specification

/**
 *
 * Created with IDEA
 * author:Likangcheng
 * Date:2019/3/5
 * Time:14:52
 *
 * */
class MyClientControllerTest extends Specification {

    MsmpSupportService chipSupportService = Mock(MsmpSupportService)
    MyClientController myClientController = new MyClientController(chipSupportService: chipSupportService)

    def "test getPage"() {
        given:
        ClientPageReq clientPageReq = new ClientPageReq()
        when:
        myClientController.getPage(clientPageReq)
        then:
        1 * chipSupportService.selectClientPage(*_) >> new PageInfo<ClientBean>()
    }
}
