package com.dashuf.dpbs.app.web

import com.dashuf.dpbs.app.web.req.support.GetVerifyCodeReq
import com.dashuf.dpbs.service.support.VerifyCodeService
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.mock.web.MockHttpSession
import spock.lang.Specification

class VerifyCodeControllerTest extends Specification{
    MockHttpServletRequest request
    MockHttpServletResponse response
    MockHttpSession session

    def setup() {
        request = new MockHttpServletRequest()
        request.setCharacterEncoding("UTF-8")
        response = new MockHttpServletResponse()
        session = new MockHttpSession()
    }
    VerifyCodeService verifyCodeService  = Mock(VerifyCodeService)
    VerifyCodeController verifyCodeController = new VerifyCodeController(verifyCodeService: verifyCodeService)

    def "getVerifyCode case1:发送验证码"(){
        given:
        GetVerifyCodeReq getVerifyCodeReq = new GetVerifyCodeReq()
        when:
        verifyCodeController.getVerifyCode(getVerifyCodeReq)
        then:
        1*verifyCodeService.sendVerifyCode(*_)>>false
    }

    def "getVerifyCode case2:发送验证码"(){
        given:
        GetVerifyCodeReq getVerifyCodeReq = new GetVerifyCodeReq()
        when:
        verifyCodeController.getVerifyCode(getVerifyCodeReq)
        then:
        1*verifyCodeService.sendVerifyCode(*_)>>true
    }

    def "getVerifyCode case3:发送验证码"(){
        given:
        GetVerifyCodeReq getVerifyCodeReq = new GetVerifyCodeReq()
        when:
        verifyCodeController.getVerifyCode(getVerifyCodeReq)
        then:
        1*verifyCodeService.sendVerifyCode(*_)>>{ throw new RuntimeException() }
    }
}
