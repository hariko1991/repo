package com.dashuf.dpbs.service.blaze

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.app.web.req.credit.SubmitAuthH5Req
import com.dashuf.dpbs.model.ClientInfo
import com.dashuf.dpbs.model.CreditSupplyInfo
import com.dashuf.dpbs.model.HouseInfo
import com.dashuf.dpbs.model.InfoEntry
import com.dashuf.dpbs.model.InsuranceInfo
import com.dashuf.dpbs.model.PushOrderLog
import com.dashuf.dpbs.model.UserInfo
import com.dashuf.dpbs.sao.defi.DefiBlazeSAO
import com.dashuf.dpbs.sao.defi.resp.ApplyRunEngineResp
import com.dashuf.dpbs.sao.defi.resp.apply.Decision
import com.dashuf.dpbs.service.CreditAuthSupportService
import com.dashuf.dpbs.service.PushOrderLogService
import com.dashuf.dpbs.service.SysConfSupportService
import com.dashuf.dpbs.service.blaze.dto.DashufBlazeDto
import com.dashuf.dpbs.service.credit.CreditReportService
import com.dashuf.dpbs.service.support.ZldSignSupportService
import org.springframework.beans.factory.annotation.Autowired
import spock.lang.Specification

class DashufBlazeSupportServiceTest extends Specification {
    DefiBlazeSAO defiBlazeSAO = Mock(DefiBlazeSAO)
    PushOrderLogService pushOrderLogService = Mock(PushOrderLogService)
    SysConfSupportService sysConfSupportService = Mock(SysConfSupportService)
    CreditAuthSupportService creditAuthSupportService = Mock(CreditAuthSupportService)
    CreditReportService creditReportService = Mock(CreditReportService);
    ZldSignSupportService zldSignSupportService = Mock(ZldSignSupportService)

    DashufBlazeSupportService dashufBlazeSupportService = new DashufBlazeSupportService(
            defiBlazeSAO: defiBlazeSAO,
            pushOrderLogService: pushOrderLogService,
            sysConfSupportService: sysConfSupportService,
            creditAuthSupportService: creditAuthSupportService,
            creditReportService: creditReportService,
            zldSignSupportService: zldSignSupportService);

    def "gatherBlazeInfo case1: "() {
        when:
        dashufBlazeSupportService.gatherBlazeInfo("pushOrderNo", new JSONObject())
        then:
        1 * pushOrderLogService.selectOneByModelSelective(*_) >> null
    }

    def "gatherBlazeInfo case2: "() {
        when:
        dashufBlazeSupportService.gatherBlazeInfo("pushOrderNo", new JSONObject())
        then:
        1 * pushOrderLogService.selectOneByModelSelective(*_) >> new PushOrderLog()
        1 * pushOrderLogService.gatherBlazeInfo(*_) >> new DashufBlazeDto()
    }

    def "initScreenDs010 case1: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.initScreenDs010(submitAuthH5Req, new PushOrderLog(), dashufBlazeDto, new JSONObject())
        then:
        1 * defiBlazeSAO.applyRunEngine(*_) >> new ApplyRunEngineResp();
    }

    def "initScreenDs010 case2: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.initScreenDs010(submitAuthH5Req, new PushOrderLog(), dashufBlazeDto, new JSONObject())
        then:
        1 * defiBlazeSAO.applyRunEngine(*_) >> {
            ApplyRunEngineResp applyRunEngineResp = new ApplyRunEngineResp();
            applyRunEngineResp.setRetCode("SUC000")
            Decision decision = new Decision();
            decision.setFinalResult("P");
            decision.setMaxCalCreditAmt(new BigDecimal("10000"))
            applyRunEngineResp.setDecision(decision)
            return applyRunEngineResp;
        }
    }

    def "initScreenDs010 case3: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.initScreenDs010(submitAuthH5Req, new PushOrderLog(), dashufBlazeDto, new JSONObject())
        then:
        1 * defiBlazeSAO.applyRunEngine(*_) >> {
            ApplyRunEngineResp applyRunEngineResp = new ApplyRunEngineResp();
            applyRunEngineResp.setRetCode("SUC00220")
            Decision decision = new Decision();
            decision.setFinalResult("P");
            decision.setMaxCalCreditAmt(new BigDecimal("10000"))
            applyRunEngineResp.setDecision(decision)
            return applyRunEngineResp;
        }
    }

    def "initScreenDs010 case4: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.initScreenDs010(submitAuthH5Req, new PushOrderLog(), dashufBlazeDto, new JSONObject())
        then:
        1 * defiBlazeSAO.applyRunEngine(*_) >> {
            ApplyRunEngineResp applyRunEngineResp = new ApplyRunEngineResp();
            applyRunEngineResp.setRetCode("SUC000")
            Decision decision = new Decision();
            decision.setFinalResult("P");
            decision.setMaxCalCreditAmt(new BigDecimal("10000"))
            applyRunEngineResp.setDecision(decision)
            return applyRunEngineResp;
        }
        1 * creditAuthSupportService.submitCreditAuth(*_) >> false
    }

    def "initScreenDs010 case5: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.initScreenDs010(submitAuthH5Req, new PushOrderLog(), dashufBlazeDto, new JSONObject())
        then:
        1 * defiBlazeSAO.applyRunEngine(*_) >> {
            ApplyRunEngineResp applyRunEngineResp = new ApplyRunEngineResp();
            applyRunEngineResp.setRetCode("SUC000")
            Decision decision = new Decision();
            decision.setFinalResult("P");
            decision.setMaxCalCreditAmt(new BigDecimal("10000"))
            applyRunEngineResp.setDecision(decision)
            return applyRunEngineResp;
        }
        1 * creditAuthSupportService.submitCreditAuth(*_) >> true
        1 * creditReportService.submitCreditReportReq(*_) >> "false"
    }

    def "initScreenDs010 case6: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.initScreenDs010(submitAuthH5Req, new PushOrderLog(), dashufBlazeDto, new JSONObject())
        then:
        1 * defiBlazeSAO.applyRunEngine(*_) >> {
            ApplyRunEngineResp applyRunEngineResp = new ApplyRunEngineResp();
            applyRunEngineResp.setRetCode("SUC000")
            Decision decision = new Decision();
            decision.setFinalResult("P");
            decision.setMaxCalCreditAmt(new BigDecimal("10000"))
            applyRunEngineResp.setDecision(decision)
            return applyRunEngineResp;
        }
        1 * creditAuthSupportService.submitCreditAuth(*_) >> true
        1 * creditReportService.submitCreditReportReq(*_) >> "true"
    }

    def "initScreenDs010 case7: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.initScreenDs010(submitAuthH5Req, new PushOrderLog(), dashufBlazeDto, new JSONObject())
        then:
        1 * defiBlazeSAO.applyRunEngine(*_) >> {
            ApplyRunEngineResp applyRunEngineResp = new ApplyRunEngineResp();
            applyRunEngineResp.setRetCode("SUC000")
            Decision decision = new Decision();
            decision.setFinalResult("P");
            decision.setMaxCalCreditAmt(new BigDecimal("10000"))
            applyRunEngineResp.setDecision(decision)
            return applyRunEngineResp;
        }
        1 * creditAuthSupportService.submitCreditAuth(*_) >> true
        1 * creditReportService.submitCreditReportReq(*_) >> "true"
        1 * creditAuthSupportService.signFileList(*_) >> {
            JSONObject jsonObject = new JSONObject()
            jsonObject.put("ok", "ook")
            return jsonObject
        }
    }

    def "initScreenDs010 case8: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.initScreenDs010(new PushOrderLog(), dashufBlazeDto, new JSONObject())
        then:
        1 * defiBlazeSAO.applyRunEngine(*_) >> {
            ApplyRunEngineResp applyRunEngineResp = new ApplyRunEngineResp();
            applyRunEngineResp.setRetCode("SUC000")
            Decision decision = new Decision();
            decision.setFinalResult("P");
            decision.setMaxCalCreditAmt(new BigDecimal("10000"))
            applyRunEngineResp.setDecision(decision)
            return applyRunEngineResp;
        }
        1 * creditAuthSupportService.signFileList(*_) >> {
            JSONObject jsonObject = new JSONObject()
            jsonObject.put("ok", "ook")
            return jsonObject
        }
        1 * zldSignSupportService.uploadFileToZldSftp(*_) >> true
    }

    def "initScreenDs010 case9: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.initScreenDs010(new PushOrderLog(), dashufBlazeDto, new JSONObject())
        then:
        1 * defiBlazeSAO.applyRunEngine(*_) >> {
            ApplyRunEngineResp applyRunEngineResp = new ApplyRunEngineResp();
            applyRunEngineResp.setRetCode("SUC0000")
            Decision decision = new Decision();
            decision.setFinalResult("P");
            decision.setMaxCalCreditAmt(new BigDecimal("10000"))
            applyRunEngineResp.setDecision(decision)
            return applyRunEngineResp;
        }
    }

    def "initScreenDs010 case10: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.initScreenDs010(new PushOrderLog(), dashufBlazeDto, new JSONObject())
        then:
        1 * defiBlazeSAO.applyRunEngine(*_) >> {
            ApplyRunEngineResp applyRunEngineResp = new ApplyRunEngineResp();
            applyRunEngineResp.setRetCode("SUC000")
            Decision decision = new Decision();
            decision.setFinalResult("P");
            decision.setMaxCalCreditAmt(new BigDecimal("10000"))
            applyRunEngineResp.setDecision(decision)
            return applyRunEngineResp;
        }
        1 * creditAuthSupportService.signFileList(*_) >> null
    }

    def "submitCredit case1: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.submitCredit(submitAuthH5Req, dashufBlazeDto, new JSONObject())
        then:
        1 * creditAuthSupportService.submitCreditAuth(*_) >> true
        1 * creditReportService.submitCreditReportReq(*_) >> "true"
        1 * pushOrderLogService.updatePushOrderLogByOrgStatus(*_) >> true
    }

    def "submitCredit case2: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.submitCredit(submitAuthH5Req, dashufBlazeDto, new JSONObject())
        then:
        1 * creditAuthSupportService.submitCreditAuth(*_) >> true
        1 * creditReportService.submitCreditReportReq(*_) >> null
    }

    def "submitCredit case3: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.submitCredit(submitAuthH5Req, dashufBlazeDto, new JSONObject())
        then:
        1 * creditAuthSupportService.submitCreditAuth(*_) >> false
    }

    def "submitCredit case4: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.submitCredit(submitAuthH5Req, dashufBlazeDto, new JSONObject())
        then:
        1 * creditAuthSupportService.submitCreditAuth(*_) >> true
        1 * creditReportService.submitCreditReportReq(*_) >> "true"
        1 * pushOrderLogService.updatePushOrderLogByOrgStatus(*_) >> false
    }

    def "giveScoreDs020 case1: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.giveScoreDs020(new PushOrderLog(), dashufBlazeDto, new JSONObject())
        then:
        1 * creditReportService.queryCreditReportWithin25Day(*_) >> "reportNO"
        1 * defiBlazeSAO.applyRunEngine(*_) >> new ApplyRunEngineResp()
    }

    def "giveScoreDs020 case2: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.giveScoreDs020(new PushOrderLog(), dashufBlazeDto, new JSONObject())
        then:
        1 * creditReportService.queryCreditReportWithin25Day(*_) >> "reportNO"
        1 * defiBlazeSAO.applyRunEngine(*_) >> {
            ApplyRunEngineResp applyRunEngineResp = new ApplyRunEngineResp();
            applyRunEngineResp.setRetCode("SUC000")
            return applyRunEngineResp;
        }
    }

    def "giveScoreDs020 case3: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.giveScoreDs020(new PushOrderLog(), dashufBlazeDto, new JSONObject())
        then:
        1 * creditReportService.queryCreditReportWithin25Day(*_) >> "reportNO"
        1 * defiBlazeSAO.applyRunEngine(*_) >> {
            ApplyRunEngineResp applyRunEngineResp = new ApplyRunEngineResp();
            applyRunEngineResp.setRetCode("SUC000000")
            return applyRunEngineResp;
        }
    }

    def "giveScoreDs020 case4: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        pushOrderLog.setCreatedDate(new Date())
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        infoEntry.setExpectLoanPeriod("12")
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.giveScoreDs020(new PushOrderLog(), dashufBlazeDto, new JSONObject())
        then:
        1 * creditReportService.queryCreditReportWithin25Day(*_) >> "reportNO"
        1 * defiBlazeSAO.applyRunEngine(*_) >> {
            ApplyRunEngineResp applyRunEngineResp = new ApplyRunEngineResp();
            applyRunEngineResp.setRetCode("SUC000")
            Decision decision = new Decision();
            decision.setFinalResult("P");
            decision.setMaxCalCreditAmt(new BigDecimal("10000"))
            applyRunEngineResp.setDecision(decision)
            return applyRunEngineResp;
        }
        2 * sysConfSupportService.selectValueFromCache(*_) >> "1"
    }

    def "giveScoreDs020 case5: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        infoEntry.setExpectLoanPeriod("12")
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.giveScoreDs020(new PushOrderLog(), dashufBlazeDto, new JSONObject())
        then:
        1 * creditReportService.queryCreditReportWithin25Day(*_) >> null
    }

    def "giveScoreDs020 case6: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
        PushOrderLog pushOrderLog = new PushOrderLog()
        pushOrderLog.setPushStartTime(new Date());
        ClientInfo clientInfo = new ClientInfo()
        InfoEntry infoEntry = new InfoEntry();
        pushOrderLog.setIfCreditSupply("true");
        List<CreditSupplyInfo> creditSupplyInfoList = new ArrayList<>();
        CreditSupplyInfo creditSupplyInfo = new CreditSupplyInfo();
        creditSupplyInfo.setMonthlyAmt(new BigDecimal("100"))
        creditSupplyInfoList.add(creditSupplyInfo);
        dashufBlazeDto.setCreditSupplyInfoList(creditSupplyInfoList)

        pushOrderLog.setIfInsurance("true");
        List<InsuranceInfo> insuranceList = new ArrayList<>();
        InsuranceInfo insuranceInfo = new InsuranceInfo()
        insuranceInfo.setPremiumAnnualAmt(new BigDecimal("100"))
        insuranceInfo.setEffectiveDate(new Date())
        insuranceList.add(insuranceInfo)
        dashufBlazeDto.setInsuranceList(insuranceList)

        List<HouseInfo> houseInfoList = new ArrayList<>()
        HouseInfo houseInfo = new HouseInfo()
        houseInfo.setTotalPriceAmt(new BigDecimal("1000"))
        houseInfoList.add(houseInfo)
        dashufBlazeDto.setHouseInfoList(houseInfoList)
        pushOrderLog.setIfHouse("true")

        infoEntry.setExpectLoanPeriod("12")
        UserInfo userInfo = new UserInfo()
        dashufBlazeDto.setUserInfo(userInfo)
        dashufBlazeDto.setInfoEntry(infoEntry);
        dashufBlazeDto.setClientInfo(clientInfo)
        dashufBlazeDto.setPushOrderLog(pushOrderLog)
        when:
        dashufBlazeSupportService.giveScoreDs020(new PushOrderLog(), dashufBlazeDto, new JSONObject())
        then:
        1 * creditReportService.queryCreditReportWithin25Day(*_) >> "reportNO"
        1 * defiBlazeSAO.applyRunEngine(*_) >> {
            ApplyRunEngineResp applyRunEngineResp = new ApplyRunEngineResp();
            applyRunEngineResp.setRetCode("SUC000")
            Decision decision = new Decision();
            decision.setFinalResult("P");
            decision.setMaxCalCreditAmt(new BigDecimal("10000"))
            applyRunEngineResp.setDecision(decision)
            return applyRunEngineResp;
        }
        2 * sysConfSupportService.selectValueFromCache(*_) >> "1"
    }
}
