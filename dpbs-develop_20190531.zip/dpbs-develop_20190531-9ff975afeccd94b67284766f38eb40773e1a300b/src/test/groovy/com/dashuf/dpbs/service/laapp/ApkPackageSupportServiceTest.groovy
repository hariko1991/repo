package com.dashuf.dpbs.service.laapp

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.app.web.req.QrOfLoanAppReq
import com.dashuf.dpbs.sao.laapp.ApkPackageSAO
import com.dashuf.dpbs.sao.laapp.resp.ApkPackageResp
import com.dashuf.dpbs.service.SysConfSupportService
import com.dashuf.merlin.web.base.views.ResponseVo
import spock.lang.Specification

class ApkPackageSupportServiceTest extends Specification {
    ApkPackageSAO apkPackageSAO = Mock(ApkPackageSAO);
    SysConfSupportService sysConfSupportService = Mock(SysConfSupportService);

    ApkPackageSupportService apkPackageSupportService = new ApkPackageSupportService(
            apkPackageSAO: apkPackageSAO,
            sysConfSupportService: sysConfSupportService)

    def "getLoanAppQr case1: "() {
        given:
        QrOfLoanAppReq qrOfLoanAppReq = new QrOfLoanAppReq();
        qrOfLoanAppReq.setDeviceType("andorid")

        when:
        apkPackageSupportService.getLoanAppQr(qrOfLoanAppReq, new JSONObject())
        then:
        1 * apkPackageSAO.getNewestApk(*_) >> {
            List<ApkPackageResp> list = new ArrayList<>();
            ApkPackageResp apkPackageResp = new ApkPackageResp();
            list.add(apkPackageResp)

            return ResponseVo.success(list);
        }
    }

    def "getLoanAppQr case2: "() {
        given:
        QrOfLoanAppReq qrOfLoanAppReq = new QrOfLoanAppReq();
        qrOfLoanAppReq.setDeviceType("andorid")

        when:
        apkPackageSupportService.getLoanAppQr(qrOfLoanAppReq, new JSONObject())
        then:
        1 * apkPackageSAO.getNewestApk(*_) >> {
            return ResponseVo.fail("fail");
        }
    }

    def "getLoanAppQr case3: "() {
        given:
        QrOfLoanAppReq qrOfLoanAppReq = new QrOfLoanAppReq();
        qrOfLoanAppReq.setDeviceType("other")

        when:
        apkPackageSupportService.getLoanAppQr(qrOfLoanAppReq, new JSONObject())
        then:
        1
    }

    def "getLoanAppQr case4: "() {
        given:
        QrOfLoanAppReq qrOfLoanAppReq = new QrOfLoanAppReq();
        qrOfLoanAppReq.setDeviceType("iphone")

        when:
        apkPackageSupportService.getLoanAppQr(qrOfLoanAppReq, new JSONObject())
        then:
        1 * sysConfSupportService.selectValueFromCache(*_) >> "confVal"
    }
}
