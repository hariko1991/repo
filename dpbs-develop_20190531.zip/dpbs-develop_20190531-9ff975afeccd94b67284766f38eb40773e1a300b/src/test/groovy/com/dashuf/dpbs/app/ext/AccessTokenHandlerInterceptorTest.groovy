package com.dashuf.dpbs.app.ext

import com.dashuf.dpbs.app.web.UserLoginController
import com.dashuf.dpbs.app.web.req.user.LoginPwdReq
import com.dashuf.dpbs.cnst.DpbsHeadCnst
import com.dashuf.dpbs.service.UserInfoService
import com.dashuf.dpbs.util.TokenUtil
import io.jsonwebtoken.Claims
import io.jsonwebtoken.Jwts
import org.springframework.data.redis.connection.RedisConnection
import org.springframework.data.redis.connection.RedisConnectionFactory
import org.springframework.data.redis.core.DefaultValueOperations
import org.springframework.data.redis.core.RedisOperations
import org.springframework.data.redis.core.StringRedisTemplate
import org.springframework.data.redis.core.ValueOperations
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.mock.web.MockHttpSession
import org.springframework.web.method.HandlerMethod
import org.springframework.web.servlet.ModelAndView
import spock.lang.Specification

import javax.servlet.http.HttpServletRequest
import java.lang.reflect.Method

class AccessTokenHandlerInterceptorTest extends Specification {

    ValueOperations valueOperations = Mock(ValueOperations.class)
    RedisOperations redisOperations = Mock(RedisOperations.class)
    RedisConnection redisConnection = Mock(RedisConnection.class)

    RedisConnectionFactory redisConnectionFactory = Mock(RedisConnectionFactory.class)

    MockHttpServletRequest request;
    MockHttpServletResponse response;
    MockHttpSession session;

    def setup() {
        request = new MockHttpServletRequest();
        request.setCharacterEncoding("UTF-8");
        response = new MockHttpServletResponse();
        session = new MockHttpSession();
    }

    TokenUtil tokenUtils = Mock(TokenUtil);
    StringRedisTemplate redisTemplate = Mock(StringRedisTemplate);

    AccessTokenHandlerInterceptor accessTokenHandlerInterceptor =
            new AccessTokenHandlerInterceptor(tokenUtils: tokenUtils, redisTemplate: redisTemplate)

    def "preHandle case2: "() {
        given:
        Object obj = new Object();
        Method method = obj.getClass().getMethod("toString");
        HandlerMethod handlerMethod = new HandlerMethod(obj, method);
        request.setRequestURI("/dpbs/test")

        when:
        accessTokenHandlerInterceptor.preHandle(request, response, handlerMethod)
        then:
        1
    }

    def "preHandle case3: "() {
        given:
        Object obj = new Object();
        Method method = obj.getClass().getMethod("toString");
        HandlerMethod handlerMethod = new HandlerMethod(obj, method);
        request.setRequestURI("/dpbs/test")
        request.addHeader(DpbsHeadCnst.X_HEAD_ACCESS_TOKEN, "accessToken");
        request.setAttribute(DpbsHeadCnst.X_HEAD_USER_NO, "userNo")
        when:
        accessTokenHandlerInterceptor.preHandle(request, response, handlerMethod)
        then:
        1 * tokenUtils.parseJWT(*_) >> {
            Claims claims = Jwts.claims();
            claims.setExpiration(new Date(System.currentTimeMillis() + 1000l));
            claims.setIssuer("user");
            claims.put("id", "id");
            return claims;
        }
    }

    def "preHandle case4: "() {
        given:
        Object obj = new Object();
        Method method = obj.getClass().getMethod("toString");
        HandlerMethod handlerMethod = new HandlerMethod(obj, method);
        request.setRequestURI("/dpbs/test")
        request.addHeader(DpbsHeadCnst.X_HEAD_ACCESS_TOKEN, "accessToken");
        request.setAttribute(DpbsHeadCnst.X_HEAD_USER_NO, "userNo")
        when:
        accessTokenHandlerInterceptor.preHandle(request, response, handlerMethod)
        then:
        1 * tokenUtils.parseJWT(*_) >> {
            Claims claims = Jwts.claims();
            claims.setExpiration(new Date(System.currentTimeMillis() + 1000l));
            claims.setIssuer("user");
            claims.put("id", "id");
            return claims;
        }
        1 * redisTemplate.opsForValue(*_) >> valueOperations
        1 * valueOperations.get(*_) >> "accessToken1"
    }

    def "postHandle case1: "() {
        given:
        Object obj = new Object();
        Method method = obj.getClass().getMethod("toString");
        HandlerMethod handlerMethod = new HandlerMethod(obj, method);

        request.setRequestURI("/dpbs/test")
        response.setHeader(DpbsHeadCnst.X_HEAD_ACCESS_TOKEN, "accessToken");
        request.setAttribute(DpbsHeadCnst.X_HEAD_USER_NO, "userNo")
        when:
        accessTokenHandlerInterceptor.postHandle(request, response, handlerMethod, null)
        then:
        1 * redisTemplate.opsForValue(*_) >> valueOperations
    }

}
