package com.dashuf.dpbs.service.blaze

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.mapper.ThirdPartyAccessMapper
import com.dashuf.dpbs.model.ClientInfo
import com.dashuf.dpbs.model.CreditSupplyInfo
import com.dashuf.dpbs.model.HouseInfo
import com.dashuf.dpbs.model.InfoEntry
import com.dashuf.dpbs.model.InsuranceInfo
import com.dashuf.dpbs.model.PushOrderLog
import com.dashuf.dpbs.model.UserInfo
import com.dashuf.dpbs.sao.laapp.AppBlazeSAO
import com.dashuf.dpbs.sao.laapp.req.subscribe.Insurance
import com.dashuf.dpbs.sao.laapp.resp.PushClientResp
import com.dashuf.dpbs.service.PushOrderLogService
import com.dashuf.dpbs.service.blaze.dto.DashufBlazeDto
import com.dashuf.merlin.web.base.views.ResponseVo
import spock.lang.Specification

class ThirdPartyAccessSupportServiceTest extends Specification {
    PushOrderLogService pushOrderLogService = Mock(PushOrderLogService);
    AppBlazeSAO appBlazeSAO = Mock(AppBlazeSAO);
    ThirdPartyAccessMapper thirdPartyAccessMapper = Mock(ThirdPartyAccessMapper);
    DashufBlazeSupportService dashufBlazeSupportService = Mock(DashufBlazeSupportService);

    ThirdPartyAccessSupportService thirdPartyAccessSupportService = new ThirdPartyAccessSupportService(
            pushOrderLogService: pushOrderLogService,
            appBlazeSAO: appBlazeSAO,
            thirdPartyAccessMapper: thirdPartyAccessMapper,
            dashufBlazeSupportService: dashufBlazeSupportService
    )

    def "queryNeedGetDs020List case1: "() {
        when:
        thirdPartyAccessSupportService.queryNeedGetDs020List()
        then:
        1 * thirdPartyAccessMapper.queryDs020GetScore(*_) >> null
    }

    def "pushClient case1: "() {
        when:
        thirdPartyAccessSupportService.pushClient("pushOrderNo", new JSONObject())
        then:
        1 * dashufBlazeSupportService.gatherBlazeInfo(*_) >> {
            DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
            PushOrderLog pushOrderLog = new PushOrderLog()
            ClientInfo clientInfo = new ClientInfo()
            UserInfo userInfo = new UserInfo()

            List<InsuranceInfo> insuranceInfoList = new ArrayList<>()
            InsuranceInfo insuranceInfo = new InsuranceInfo()
            insuranceInfo.setEffectiveDate(new Date())
            insuranceInfoList.add(insuranceInfo)
            pushOrderLog.setIfInsurance("true")
            dashufBlazeDto.setInsuranceList(insuranceInfoList)

            List<HouseInfo> houseInfoList = new ArrayList<>()
            HouseInfo houseInfo = new HouseInfo()
            houseInfoList.add(houseInfo)
            pushOrderLog.setIfHouse("true")
            dashufBlazeDto.setHouseInfoList(houseInfoList)

            List<CreditSupplyInfo> creditSupplyInfoList = new ArrayList<>()
            CreditSupplyInfo creditSupplyInfo = new CreditSupplyInfo()
            creditSupplyInfoList.add(creditSupplyInfo)
            pushOrderLog.setIfCreditSupply("true")
            dashufBlazeDto.setCreditSupplyInfoList(creditSupplyInfoList)

            InfoEntry infoEntry = new InfoEntry()

            dashufBlazeDto.setInfoEntry(infoEntry)
            dashufBlazeDto.setUserInfo(userInfo)
            dashufBlazeDto.setClientInfo(clientInfo)
            dashufBlazeDto.setPushOrderLog(pushOrderLog)
            return dashufBlazeDto;
        }
        1 * appBlazeSAO.pushClient(*_) >> {
            return ResponseVo.fail("fail")
        }
    }

    def "pushClient case2: "() {
        when:
        thirdPartyAccessSupportService.pushClient("pushOrderNo", new JSONObject())
        then:
        1 * dashufBlazeSupportService.gatherBlazeInfo(*_) >> {
            DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
            PushOrderLog pushOrderLog = new PushOrderLog()
            ClientInfo clientInfo = new ClientInfo()
            UserInfo userInfo = new UserInfo()

            List<InsuranceInfo> insuranceInfoList = new ArrayList<>()
            InsuranceInfo insuranceInfo = new InsuranceInfo()
            insuranceInfo.setEffectiveDate(new Date())
            insuranceInfoList.add(insuranceInfo)
            pushOrderLog.setIfInsurance("true")
            dashufBlazeDto.setInsuranceList(insuranceInfoList)

            List<HouseInfo> houseInfoList = new ArrayList<>()
            HouseInfo houseInfo = new HouseInfo()
            houseInfoList.add(houseInfo)
            pushOrderLog.setIfHouse("true")
            dashufBlazeDto.setHouseInfoList(houseInfoList)

            List<CreditSupplyInfo> creditSupplyInfoList = new ArrayList<>()
            CreditSupplyInfo creditSupplyInfo = new CreditSupplyInfo()
            creditSupplyInfoList.add(creditSupplyInfo)
            pushOrderLog.setIfCreditSupply("true")
            dashufBlazeDto.setCreditSupplyInfoList(creditSupplyInfoList)

            InfoEntry infoEntry = new InfoEntry()

            dashufBlazeDto.setInfoEntry(infoEntry)
            dashufBlazeDto.setUserInfo(userInfo)
            dashufBlazeDto.setClientInfo(clientInfo)
            dashufBlazeDto.setPushOrderLog(pushOrderLog)
            return dashufBlazeDto;
        }
        1 * appBlazeSAO.pushClient(*_) >> {
            PushClientResp pushClientResp = new PushClientResp();
            return ResponseVo.success(pushClientResp)
        }
        1 * pushOrderLogService.updatePushOrderLogByOrgStatus(*_) >> true
    }

    def "queryScoreDs020 case1: "() {

        when:
        thirdPartyAccessSupportService.queryScoreDs020(new PushOrderLog(), new JSONObject())
        then:
        1 * dashufBlazeSupportService.gatherBlazeInfo(*_) >> new DashufBlazeDto();
        1 * dashufBlazeSupportService.giveScoreDs020(*_) >> true

    }

    def "initScreenDs010 case1: "() {

        when:
        thirdPartyAccessSupportService.initScreenDs010(new PushOrderLog(), new JSONObject())
        then:
        1 * dashufBlazeSupportService.gatherBlazeInfo(*_) >> new DashufBlazeDto();
        1 * dashufBlazeSupportService.initScreenDs010(*_) >> true

    }
}
