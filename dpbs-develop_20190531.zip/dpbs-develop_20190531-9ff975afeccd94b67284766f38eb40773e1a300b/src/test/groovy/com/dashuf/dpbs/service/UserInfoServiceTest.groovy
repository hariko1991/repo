package com.dashuf.dpbs.service

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.mapper.UserInfoMapper
import com.dashuf.dpbs.model.UserInfo
import spock.lang.Specification

class UserInfoServiceTest extends Specification {
    UserInfoMapper userInfoMapper = Mock(UserInfoMapper)
    UserInfoService userInfoService = new UserInfoService(userInfoMapper: userInfoMapper)

    def "getUserInfo case1: "() {
        given:

        when:
        userInfoService.getUserInfo("userNo", new JSONObject())

        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> null
    }

    def "getUserInfo case2: "() {
        given:

        when:
        userInfoService.getUserInfo("userNo", new JSONObject())

        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> new UserInfo()
    }
}
