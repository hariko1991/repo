package com.dashuf.dpbs.app.web

import com.dashuf.dpbs.app.web.req.push.FinishPushOrderReq
import com.dashuf.dpbs.app.web.req.push.GetScoreReq
import com.dashuf.dpbs.app.web.req.push.GiveUpPushOrderReq
import com.dashuf.dpbs.app.web.req.push.InfoEntryReq
import com.dashuf.dpbs.app.web.req.push.InitPushOrderReq
import com.dashuf.dpbs.app.web.req.push.ScanCertReq
import com.dashuf.dpbs.app.web.resp.push.GetScoreResp
import com.dashuf.dpbs.model.UserInfo
import com.dashuf.dpbs.service.PushOrderSupportService
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.mock.web.MockHttpSession
import org.springframework.web.multipart.MultipartFile
import spock.lang.Specification

class PushOrderControllerTest extends Specification {
    MockHttpServletRequest request
    MockHttpServletResponse response
    MockHttpSession session

    def setup() {
        request = new MockHttpServletRequest()
        request.setCharacterEncoding("UTF-8")
        response = new MockHttpServletResponse()
        session = new MockHttpSession()
    }

    PushOrderSupportService pushOrderSupportService = Mock(PushOrderSupportService)
    PushOrderController pushOrderController = new PushOrderController(pushOrderSupportService: pushOrderSupportService)

    def "initPushOrder case1:立即推单"() {
        given:
        InitPushOrderReq initPushOrderReq = new InitPushOrderReq()
        when:
        pushOrderController.initPushOrder(initPushOrderReq, "userNo")
        then:
        1 * pushOrderSupportService.initPushOrder(*_) >> false
    }

    def "initPushOrder case2:立即推单"() {
        given:
        InitPushOrderReq initPushOrderReq = new InitPushOrderReq()
        when:
        pushOrderController.initPushOrder(initPushOrderReq, "userNo")
        then:
        1 * pushOrderSupportService.initPushOrder(*_) >> true
    }

    def "initPushOrder case3:立即推单"() {
        given:
        InitPushOrderReq initPushOrderReq = new InitPushOrderReq()
        when:
        pushOrderController.initPushOrder(initPushOrderReq, "userNo")
        then:
        1 * pushOrderSupportService.initPushOrder(*_) >> { throw new RuntimeException() }
    }


    def "scanCert case1:扫描身份证"() {
        given:
        ScanCertReq scanCertReq = new ScanCertReq()
        UserInfo userInfo = new UserInfo()
        when:
        pushOrderController.scanCert(scanCertReq, "userNo")
        then:
        1 * pushOrderSupportService.scanCert(*_) >> false
    }

    def "scanCert case2:扫描身份证"() {
        given:
        ScanCertReq scanCertReq = new ScanCertReq()
        UserInfo userInfo = new UserInfo()
        when:
        pushOrderController.scanCert(scanCertReq, "userNo")
        then:
        1 * pushOrderSupportService.scanCert(*_) >> true
    }

    def "scanCert case3:扫描身份证"() {
        given:
        ScanCertReq scanCertReq = new ScanCertReq()
        UserInfo userInfo = new UserInfo()
        when:
        pushOrderController.scanCert(scanCertReq, "userNo")
        then:
        1 * pushOrderSupportService.scanCert(*_) >> { throw new RuntimeException() }
    }


    def "uploadImg case1:上传手持证件照片"() {
        given:
        MultipartFile[] fileList = new MultipartFile[0]
        String pushOrderNo = null
        when:
        pushOrderController.uploadImg(fileList, pushOrderNo)
        then:
        1
    }


    def "uploadImg case2:上传手持证件照片"() {
        given:
        MultipartFile[] fileList = new MultipartFile[2]
        String pushOrderNo = null
        when:
        pushOrderController.uploadImg(fileList, pushOrderNo)
        then:
        1 * pushOrderSupportService.uploadImg(*_) >> false
    }

    def "uploadImg case3:上传手持证件照片"() {
        given:
        MultipartFile[] fileList = new MultipartFile[2]
        String pushOrderNo = null
        when:
        pushOrderController.uploadImg(fileList, pushOrderNo)
        then:
        1 * pushOrderSupportService.uploadImg(*_) >> true
    }

    def "uploadImg case4:上传手持证件照片"() {
        given:
        MultipartFile[] fileList = new MultipartFile[2]
        String pushOrderNo = null
        when:
        pushOrderController.uploadImg(fileList, pushOrderNo)
        then:
        1 * pushOrderSupportService.uploadImg(*_) >> { throw new RuntimeException() }
    }

    def "infoEntry case1:信息录入"() {
        given:
        InfoEntryReq infoEntryReq = new InfoEntryReq()
        when:
        pushOrderController.infoEntry(infoEntryReq)
        then:
        1 * pushOrderSupportService.infoEntry(*_) >> false
    }

    def "infoEntry case2:信息录入"() {
        given:
        InfoEntryReq infoEntryReq = new InfoEntryReq()
        when:
        pushOrderController.infoEntry(infoEntryReq)
        then:
        1 * pushOrderSupportService.infoEntry(*_) >> true
        1 * pushOrderSupportService.initCreditAuthPage(*_) >> false
    }

    def "infoEntry case3:信息录入"() {
        given:
        InfoEntryReq infoEntryReq = new InfoEntryReq()
        when:
        pushOrderController.infoEntry(infoEntryReq)
        then:
        1 * pushOrderSupportService.infoEntry(*_) >> true
        1 * pushOrderSupportService.initCreditAuthPage(*_) >> true
    }

    def "infoEntry case4:信息录入"() {
        given:
        InfoEntryReq infoEntryReq = new InfoEntryReq()
        when:
        pushOrderController.infoEntry(infoEntryReq)
        then:
        1 * pushOrderSupportService.infoEntry(*_) >> { throw new RuntimeException() }
    }


    def "finishPushOrder case1:完成推单并提交"() {
        given:
        FinishPushOrderReq finishPushOrderReq = new FinishPushOrderReq()
        when:
        pushOrderController.finishPushOrder(finishPushOrderReq)
        then:
        1
    }

    def "getScore case1:获取评分结果"() {
        given:
        GetScoreReq getScoreReq = new GetScoreReq()
        when:
        pushOrderController.getScore(getScoreReq)
        then:
        1 * pushOrderSupportService.getScore(*_) >> null
    }

    def "getScore case2:获取评分结果"() {
        given:
        GetScoreReq getScoreReq = new GetScoreReq()
        when:
        pushOrderController.getScore(getScoreReq)
        then:
        1 * pushOrderSupportService.getScore(*_) >> new GetScoreResp()
    }

    def "getScore case3:获取评分结果"() {
        given:
        GetScoreReq getScoreReq = new GetScoreReq()
        when:
        pushOrderController.getScore(getScoreReq)
        then:
        1 * pushOrderSupportService.getScore(*_) >> { throw new RuntimeException() }
    }


    def "giveUpPushOrder case1:放弃推单"() {
        given:
        GiveUpPushOrderReq giveUpPushOrderReq = new GiveUpPushOrderReq()
        when:
        pushOrderController.giveUpPushOrder(giveUpPushOrderReq)
        then:
        1 * pushOrderSupportService.giveUpPushOrder(*_) >> false
    }

    def "giveUpPushOrder case2:放弃推单"() {
        given:
        GiveUpPushOrderReq giveUpPushOrderReq = new GiveUpPushOrderReq()
        when:
        pushOrderController.giveUpPushOrder(giveUpPushOrderReq)
        then:
        1 * pushOrderSupportService.giveUpPushOrder(*_) >> true
    }

    def "giveUpPushOrder case3:放弃推单"() {
        given:
        GiveUpPushOrderReq giveUpPushOrderReq = new GiveUpPushOrderReq()
        when:
        pushOrderController.giveUpPushOrder(giveUpPushOrderReq)
        then:
        1 * pushOrderSupportService.giveUpPushOrder(*_) >> { throw new RuntimeException() }
    }
}
