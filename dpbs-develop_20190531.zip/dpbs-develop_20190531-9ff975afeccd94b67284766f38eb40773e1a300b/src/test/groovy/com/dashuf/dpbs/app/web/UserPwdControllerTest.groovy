package com.dashuf.dpbs.app.web

import com.dashuf.dpbs.app.web.req.user.ForgetPwdReq
import com.dashuf.dpbs.app.web.req.user.ModifyPwdReq
import com.dashuf.dpbs.app.web.resp.user.LoginResp
import com.dashuf.dpbs.model.UserInfo
import com.dashuf.dpbs.service.UserInfoSupportService
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.mock.web.MockHttpSession
import spock.lang.Specification

class UserPwdControllerTest extends Specification {

    MockHttpServletRequest request
    MockHttpServletResponse response
    MockHttpSession session

    def setup() {
        request = new MockHttpServletRequest()
        request.setCharacterEncoding("UTF-8")
        response = new MockHttpServletResponse()
        session = new MockHttpSession()
    }

    UserInfoSupportService userInfoSupportService = Mock(UserInfoSupportService)
    UserPwdController userPwdController = new UserPwdController(userInfoSupportService: userInfoSupportService)

    def "forgetPwd case1:忘记密码"() {
        given:
        ForgetPwdReq forgetPwdReq = new ForgetPwdReq()
        when:
        userPwdController.forgetPwd(request, response, forgetPwdReq)
        then:
        1 * userInfoSupportService.forgetPwd(*_) >> null
    }

    def "forgetPwd case2:忘记密码"() {
        given:
        ForgetPwdReq forgetPwdReq = new ForgetPwdReq()
        when:
        userPwdController.forgetPwd(request, response, forgetPwdReq)
        then:
        1 * userInfoSupportService.forgetPwd(*_) >> new LoginResp()
        1 * userInfoSupportService.initAccessTokenForUser(*_) >> null
    }

    def "forgetPwd case3:忘记密码"() {
        given:
        ForgetPwdReq forgetPwdReq = new ForgetPwdReq()
        when:
        userPwdController.forgetPwd(request, response, forgetPwdReq)
        then:
        1 * userInfoSupportService.forgetPwd(*_) >> { throw new RuntimeException() }
    }

    def "modifyPwd case1:修改密码"() {
        given:
        ModifyPwdReq modifyPwdReq = new ModifyPwdReq()
        UserInfo userInfo = new UserInfo()
        when:
        userPwdController.modifyPwd(modifyPwdReq, "userNo")
        then:
        1 * userInfoSupportService.modifyPwd(*_) >> null
    }

    def "modifyPwd case2:修改密码"() {
        given:
        ModifyPwdReq modifyPwdReq = new ModifyPwdReq()
        UserInfo userInfo = new UserInfo()
        when:
        userPwdController.modifyPwd(modifyPwdReq, "userNo")
        then:
        1 * userInfoSupportService.modifyPwd(*_) >> new LoginResp()
    }

    def "modifyPwd case3:修改密码"() {
        given:
        ModifyPwdReq modifyPwdReq = new ModifyPwdReq()
        UserInfo userInfo = new UserInfo()
        when:
        userPwdController.modifyPwd(modifyPwdReq, "userNo")
        then:
        1 * userInfoSupportService.modifyPwd(*_) >> { throw new RuntimeException() }
    }
}
