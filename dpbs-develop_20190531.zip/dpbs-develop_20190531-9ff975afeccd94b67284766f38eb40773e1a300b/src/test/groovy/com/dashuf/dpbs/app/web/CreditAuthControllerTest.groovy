package com.dashuf.dpbs.app.web

import com.dashuf.dpbs.app.web.req.credit.AnalysisQrCodeReq
import com.dashuf.dpbs.app.web.req.credit.CreditAuthH5Req
import com.dashuf.dpbs.app.web.req.credit.PushClientReq
import com.dashuf.dpbs.app.web.req.credit.RefreshQrCodeReq
import com.dashuf.dpbs.app.web.req.credit.SkipCreditAuthReq
import com.dashuf.dpbs.app.web.req.credit.SubmitAuthH5Req
import com.dashuf.dpbs.app.web.req.push.FinishPushOrderReq
import com.dashuf.dpbs.app.web.resp.credit.AnalysisQrCodeResp
import com.dashuf.dpbs.model.InfoEntry
import com.dashuf.dpbs.model.PushOrderLog
import com.dashuf.dpbs.sao.defi.resp.ApplyRunEngineResp
import com.dashuf.dpbs.service.CreditAuthSupportService
import com.dashuf.dpbs.service.blaze.DashufBlazeSupportService
import com.dashuf.dpbs.service.blaze.ThirdPartyAccessSupportService
import com.dashuf.dpbs.service.blaze.dto.DashufBlazeDto
import com.dashuf.dpbs.service.support.VerifyCodeService
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.mock.web.MockHttpSession
import spock.lang.Specification

class CreditAuthControllerTest extends Specification {
    MockHttpServletRequest request;
    MockHttpServletResponse response;
    MockHttpSession session;

    def setup() {
        request = new MockHttpServletRequest();
        request.setCharacterEncoding("UTF-8");
        response = new MockHttpServletResponse();
        session = new MockHttpSession();
    }

    CreditAuthSupportService creditAuthSupportService = Mock(CreditAuthSupportService)
    VerifyCodeService verifyCodeService = Mock(VerifyCodeService)
    DashufBlazeSupportService dashufBlazeSupportService = Mock(DashufBlazeSupportService)
    ThirdPartyAccessSupportService thirdPartyAccessSupportService = Mock(ThirdPartyAccessSupportService)
    CreditAuthController creditAuthController = new CreditAuthController(creditAuthSupportService: creditAuthSupportService,
            verifyCodeService: verifyCodeService,
            dashufBlazeSupportService: dashufBlazeSupportService,
            thirdPartyAccessSupportService: thirdPartyAccessSupportService)


    def "getCreditAuthH5 case1:获取银联h5认证页面"() {
        given:
        CreditAuthH5Req creditAuthH5Req = new CreditAuthH5Req("pushOrderNo": "RL010222222", "clientName": null, "certNo": null, "mobileNo": null, "verifyCode": null);
        when:
        creditAuthController.getCreditAuthH5(creditAuthH5Req)
        then:
        1 * verifyCodeService.checkVerifyCode(*_) >> false

    }

    def "getCreditAuthH5 case2:获取银联h5认证页面"() {
        given:
        CreditAuthH5Req creditAuthH5Req = new CreditAuthH5Req("pushOrderNo": "RL010222222", "clientName": null, "certNo": null, "mobileNo": null, "verifyCode": null);
        when:
        creditAuthController.getCreditAuthH5(creditAuthH5Req)
        then:
        1 * verifyCodeService.checkVerifyCode(*_) >> true
        1 * creditAuthSupportService.getCreditAuthH5(*_) >> null

    }

    def "getCreditAuthH5 case3:获取银联h5认证页面"() {
        given:
        CreditAuthH5Req creditAuthH5Req = new CreditAuthH5Req("pushOrderNo": "RL010222222", "clientName": null, "certNo": null, "mobileNo": null, "verifyCode": null);
        when:
        creditAuthController.getCreditAuthH5(creditAuthH5Req)
        then:
        1 * verifyCodeService.checkVerifyCode(*_) >> true
        1 * creditAuthSupportService.getCreditAuthH5(*_) >> "mock"

    }

    def "getCreditAuthH5 case4:获取银联h5认证页面"() {
        given:
        CreditAuthH5Req creditAuthH5Req = new CreditAuthH5Req("pushOrderNo": "RL010222222", "clientName": null, "certNo": null, "mobileNo": null, "verifyCode": null);
        when:
        creditAuthController.getCreditAuthH5(creditAuthH5Req)
        then:
        1 * verifyCodeService.checkVerifyCode(*_) >> { throw new RuntimeException() }

    }


    def "submitCreditAuth case1:提交征信授权码"() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req()
        when:
        creditAuthController.submitCreditAuth(submitAuthH5Req)
        then:
        1 * creditAuthSupportService.validSubmitCreditAuth(*_) >> null
    }

    def "submitCreditAuth case2:提交征信授权码"() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req()
        when:
        creditAuthController.submitCreditAuth(submitAuthH5Req)
        then:
        1 * creditAuthSupportService.validSubmitCreditAuth(*_) >> {
            DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
            PushOrderLog pushOrderLog = new PushOrderLog();
            pushOrderLog.setPushStatus("entry");
            dashufBlazeDto.setPushOrderLog(pushOrderLog)
            return dashufBlazeDto
        }
        1 * dashufBlazeSupportService.submitCredit(*_) >> true
    }

    def "submitCreditAuth case3:提交征信授权码"() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req()
        when:
        creditAuthController.submitCreditAuth(submitAuthH5Req)
        then:
        1 * creditAuthSupportService.validSubmitCreditAuth(*_) >> {
            DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
            PushOrderLog pushOrderLog = new PushOrderLog();
            pushOrderLog.setPushStatus("entry");
            dashufBlazeDto.setPushOrderLog(pushOrderLog)
            return dashufBlazeDto
        }
        1 * dashufBlazeSupportService.submitCredit(*_) >> false
    }

    def "submitCreditAuth case4:提交征信授权码"() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req()
        when:
        creditAuthController.submitCreditAuth(submitAuthH5Req)
        then:
        1 * creditAuthSupportService.validSubmitCreditAuth(*_) >> {
            DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
            PushOrderLog pushOrderLog = new PushOrderLog();
            pushOrderLog.setPushStatus("entrys");
            dashufBlazeDto.setPushOrderLog(pushOrderLog)
            return dashufBlazeDto
        }
    }

    def "submitCreditAuth case5:提交征信授权码"() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req()
        when:
        creditAuthController.submitCreditAuth(submitAuthH5Req)
        then:
        1 * creditAuthSupportService.validSubmitCreditAuth(*_) >> {
            DashufBlazeDto dashufBlazeDto = new DashufBlazeDto();
            PushOrderLog pushOrderLog = new PushOrderLog();
            pushOrderLog.setPushStatus("entry");
            dashufBlazeDto.setPushOrderLog(pushOrderLog)
            return dashufBlazeDto
        }
        1 * dashufBlazeSupportService.submitCredit(*_) >> { throw new RuntimeException() }
    }


    def "analysisQrCode case1:解析二维码内容"() {
        given:
        AnalysisQrCodeReq analysisQrCodeReq = new AnalysisQrCodeReq()
        when:
        creditAuthController.analysisQrCode(analysisQrCodeReq)
        then:
        1 * creditAuthSupportService.analysisQrCode(*_) >> null
    }

    def "analysisQrCode case2:解析二维码内容"() {
        given:
        AnalysisQrCodeReq analysisQrCodeReq = new AnalysisQrCodeReq()
        when:
        creditAuthController.analysisQrCode(analysisQrCodeReq)
        then:
        1 * creditAuthSupportService.analysisQrCode(*_) >> new AnalysisQrCodeResp()
    }

    def "analysisQrCode case3:解析二维码内容"() {
        given:
        AnalysisQrCodeReq analysisQrCodeReq = new AnalysisQrCodeReq()
        when:
        creditAuthController.analysisQrCode(analysisQrCodeReq)
        then:
        1 * creditAuthSupportService.analysisQrCode(*_) >> { throw new RuntimeException() }
    }


    def "skipCreditAuth case1:跳过银联h5认证页面"() {
        given:
        SkipCreditAuthReq skipCreditAuthReq = new SkipCreditAuthReq()
        when:
        creditAuthController.skipCreditAuth(skipCreditAuthReq)
        then:
        1
    }

    def "skipCreditAuth case2:跳过银联h5认证页面"() {
        given:
        SkipCreditAuthReq skipCreditAuthReq = new SkipCreditAuthReq()
        when:
        creditAuthController.skipCreditAuth(skipCreditAuthReq)
        then:
        1
    }


    def "refreshQrCode case1:刷新征信授权二维码"() {
        given:
        RefreshQrCodeReq refreshQrCodeReq = new RefreshQrCodeReq()
        when:
        creditAuthController.refreshQrCode(refreshQrCodeReq)
        then:
        1 * creditAuthSupportService.initCreditAuthPage(*_) >> false
    }

    def "refreshQrCode case2:刷新征信授权二维码"() {
        given:
        RefreshQrCodeReq refreshQrCodeReq = new RefreshQrCodeReq()
        when:
        creditAuthController.refreshQrCode(refreshQrCodeReq)
        then:
        1 * creditAuthSupportService.initCreditAuthPage(*_) >> true
    }

    def "refreshQrCode case3:刷新征信授权二维码"() {
        given:
        RefreshQrCodeReq refreshQrCodeReq = new RefreshQrCodeReq()
        when:
        creditAuthController.refreshQrCode(refreshQrCodeReq)
        then:
        1 * creditAuthSupportService.initCreditAuthPage(*_) >> { throw new RuntimeException() }
    }


    def "pushClient case1:调用二代APP推送客户"() {
        given:
        PushClientReq pushClientReq = new PushClientReq()
        when:
        creditAuthController.pushClient(pushClientReq)
        then:
        1 * thirdPartyAccessSupportService.pushClient(*_) >> false
    }


    def "pushClient case2:调用二代APP推送客户"() {
        given:
        PushClientReq pushClientReq = new PushClientReq()
        when:
        creditAuthController.pushClient(pushClientReq)
        then:
        1 * thirdPartyAccessSupportService.pushClient(*_) >> true
    }

    def "pushClient case3:调用二代APP推送客户"() {
        given:
        PushClientReq pushClientReq = new PushClientReq()
        when:
        creditAuthController.pushClient(pushClientReq)
        then:
        1 * thirdPartyAccessSupportService.pushClient(*_) >> { throw new RuntimeException() }
    }

    def "ds020OfBlaze case1: "() {
        when:
        creditAuthController.ds020OfBlaze(new FinishPushOrderReq())
        then:
        1 * thirdPartyAccessSupportService.queryScoreDs020(*_) >> false
    }

    def "ds020OfBlaze case2: "() {
        when:
        creditAuthController.ds020OfBlaze(new FinishPushOrderReq())
        then:
        1 * thirdPartyAccessSupportService.queryScoreDs020(*_) >> true
    }

    def "ds020OfBlaze case3: "() {
        when:
        creditAuthController.ds020OfBlaze(new FinishPushOrderReq())
        then:
        1 * thirdPartyAccessSupportService.queryScoreDs020(*_) >> { throw new RuntimeException() }
    }
}
