package com.dashuf.dpbs.app.web

import com.dashuf.dpbs.app.web.resp.business.BusinessProcessDetailResp
import com.dashuf.dpbs.app.web.resp.business.BusinessProcessResp
import com.dashuf.dpbs.model.UserInfo
import com.dashuf.dpbs.service.BusinessProcessService
import com.dashuf.merlin.mybatis.page.Pagination
import com.github.pagehelper.PageInfo
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.mock.web.MockHttpSession
import spock.lang.Specification

class BusinessProcessControllerTest extends Specification {
    MockHttpServletRequest request;
    MockHttpServletResponse response;
    MockHttpSession session;

    def setup() {
        request = new MockHttpServletRequest();
        request.setCharacterEncoding("UTF-8");
        response = new MockHttpServletResponse();
        session = new MockHttpSession();
    }

    //BusinessProcessResp businessProcessResp = new BusinessProcessResp(pushOrderNo: "RL1002020125687566",clientName: "赵帅强",pushStartTime:"2019-02-13",pushEndTime:"2019-02-14");
    BusinessProcessService businessProcessService = Mock(BusinessProcessService);
    BusinessProcessController businessProcessController = new BusinessProcessController(businessProcessService: businessProcessService);

    def "getBusinessProcess case1:业务进度查询概览"() {
        given:
        Integer processStatus = null;
        String userNo = null;
        Pagination pagination = null;
        UserInfo userInfo = new UserInfo(userNo: "userNo")
        when:
        businessProcessController.getBusinessProcess(processStatus, userNo, "userNo", pagination);
        then:
        1 * businessProcessService.getBusinessProcess(*_) >> null;
    }

    def "getBusinessProcess case2:业务进度查询概览"() {
        given:
        Integer processStatus = null;
        String userNo = null;
        Pagination pagination = null;
        UserInfo userInfo = new UserInfo(userNo: "userNo")
        when:
        businessProcessController.getBusinessProcess(processStatus, userNo, "userNo", pagination);
        then:
        1 * businessProcessService.getBusinessProcess(*_) >> new PageInfo<>(new ArrayList<BusinessProcessResp>())
    }


    def "getBusinessProcess case1:订单状态详情"() {
        given:
        String pushOrderNo = null;
        when:
        businessProcessController.getProcessDetail(pushOrderNo);
        then:
        1 * businessProcessService.getBusinessDetail(*_) >> null;
    }

    def "getBusinessProcess case2:订单状态详情"() {
        given:
        String pushOrderNo = null;
        when:
        businessProcessController.getProcessDetail(pushOrderNo);
        then:
        1 * businessProcessService.getBusinessDetail(*_) >> new BusinessProcessDetailResp()
    }
}
