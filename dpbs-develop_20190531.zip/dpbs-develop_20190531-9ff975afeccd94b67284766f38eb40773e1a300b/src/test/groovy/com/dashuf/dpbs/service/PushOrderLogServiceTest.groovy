package com.dashuf.dpbs.service

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.app.web.req.push.InfoEntryOfCreditSupply
import com.dashuf.dpbs.app.web.req.push.InfoEntryOfHouse
import com.dashuf.dpbs.app.web.req.push.InfoEntryOfInsurance
import com.dashuf.dpbs.app.web.req.push.InfoEntryReq
import com.dashuf.dpbs.mapper.ClientInfoMapper
import com.dashuf.dpbs.mapper.CreditSupplyInfoMapper
import com.dashuf.dpbs.mapper.HouseInfoMapper
import com.dashuf.dpbs.mapper.InfoEntryMapper
import com.dashuf.dpbs.mapper.InsuranceInfoMapper
import com.dashuf.dpbs.mapper.PushOrderLogMapper
import com.dashuf.dpbs.mapper.UserInfoMapper
import com.dashuf.dpbs.model.ClientInfo
import com.dashuf.dpbs.model.CreditSupplyInfo
import com.dashuf.dpbs.model.HouseInfo
import com.dashuf.dpbs.model.InsuranceInfo
import com.dashuf.dpbs.model.PushOrderLog
import com.dashuf.dpbs.model.UserInfo
import io.swagger.annotations.ApiModelProperty
import spock.lang.Specification

class PushOrderLogServiceTest extends Specification {
    PushOrderLogMapper pushOrderLogMapper = Mock(PushOrderLogMapper);
    InfoEntryMapper infoEntryMapper = Mock(InfoEntryMapper);
    HouseInfoMapper houseInfoMapper = Mock(HouseInfoMapper);
    CreditSupplyInfoMapper creditSupplyInfoMapper = Mock(CreditSupplyInfoMapper);
    InsuranceInfoMapper insuranceInfoMapper = Mock(InsuranceInfoMapper);
    ClientInfoMapper clientInfoMapper = Mock(ClientInfoMapper);
    UserInfoMapper userInfoMapper = Mock(UserInfoMapper);

    PushOrderLogService pushOrderLogService = new PushOrderLogService(pushOrderLogMapper: pushOrderLogMapper,
            infoEntryMapper: infoEntryMapper,
            houseInfoMapper: houseInfoMapper,
            creditSupplyInfoMapper: creditSupplyInfoMapper,
            insuranceInfoMapper: insuranceInfoMapper,
            clientInfoMapper: clientInfoMapper,
            userInfoMapper: userInfoMapper)

    def "queryPushOrderLog case1: "() {
        when:
        pushOrderLogService.queryPushOrderLog(new PushOrderLog())
        then:
        1 * pushOrderLogMapper.queryPushOrderLog(*_) >> new PushOrderLog()
    }

    def "selectOneByModelSelective case1: "() {
        when:
        pushOrderLogService.selectOneByModelSelective(new PushOrderLog(), true)
        then:
        1 * pushOrderLogMapper.selectOneByModelSelective(*_) >> new PushOrderLog()
    }

    def "updatePushOrderLogByOrgStatus case1: "() {
        when:
        pushOrderLogService.updatePushOrderLogByOrgStatus(new PushOrderLog(), "orgStatus", new JSONObject())
        then:
        1 * pushOrderLogMapper.updatePushOrderLogByOrgStatus(*_) >> 1
    }

    def "updatePushOrderLogByOrgStatus case2: "() {
        when:
        pushOrderLogService.updatePushOrderLogByOrgStatus(new PushOrderLog(), "orgStatus", new JSONObject())
        then:
        1 * pushOrderLogMapper.updatePushOrderLogByOrgStatus(*_) >> 0
    }

    def "initPushOrder case1: "() {
        when:
        pushOrderLogService.initPushOrder(null);

        then:
        1 * pushOrderLogMapper.initPushOrder(*_) >> 1
    }

    def "fullPushOrderLog case1: "() {
        given:
        InfoEntryReq infoEntryReq = new InfoEntryReq();
        infoEntryReq.setIfHouse("true");
        List<InfoEntryOfHouse> houseList = new ArrayList<>();
        InfoEntryOfHouse house = new InfoEntryOfHouse();
        houseList.add(house);
        infoEntryReq.setHouseList(houseList);

        infoEntryReq.setIfCreditSupply("true");
        List<InfoEntryOfCreditSupply> creditSupplyList = new ArrayList<>();
        InfoEntryOfCreditSupply creditSupply = new InfoEntryOfCreditSupply();
        creditSupplyList.add(creditSupply)
        infoEntryReq.setCreditSupplyList(creditSupplyList)

        infoEntryReq.setIfInsurance("true");
        List<InfoEntryOfInsurance> insuranceList = new ArrayList<>();
        InfoEntryOfInsurance insurance = new InfoEntryOfInsurance()
        insuranceList.add(insurance)
        infoEntryReq.setInsuranceList(insuranceList)

        PushOrderLog pushOrderLog = new PushOrderLog();
        when:
        pushOrderLogService.fullPushOrderLog(infoEntryReq, new JSONObject(), pushOrderLog)
        then:
        1 * infoEntryMapper.insertSelective(*_) >> 1
        1 * houseInfoMapper.insertBatchSelective(*_) >> 2
        1 * creditSupplyInfoMapper.insertBatchSelective(*_) >> 2
        1 * insuranceInfoMapper.insertBatchSelective(*_) >> 2
    }

    def "updatePushOrderLog case1"() {
        when:
        pushOrderLogService.updatePushOrderLog(new PushOrderLog(), new JSONObject())
        then:
        1 * pushOrderLogMapper.updatePushOrderLog(*_) >> 1
    }

    def "updatePushOrderLog case2"() {
        when:
        pushOrderLogService.updatePushOrderLog(new PushOrderLog(), new JSONObject())
        then:
        1 * pushOrderLogMapper.updatePushOrderLog(*_) >> 0
    }

    def "gatherBlazeInfo case1: "() {
        given:
        PushOrderLog pushOrderLog = new PushOrderLog();
        pushOrderLog.setIfInsurance("true");
        pushOrderLog.setIfCreditSupply("true");
        pushOrderLog.setIfHouse("true");
        when:
        pushOrderLogService.gatherBlazeInfo(pushOrderLog, new JSONObject())
        then:
        1 * clientInfoMapper.selectOneByModelSelective(*_) >> new ClientInfo()
        1 * userInfoMapper.selectOneByModelSelective(*_) >> new UserInfo()
        1 * houseInfoMapper.selectByModelSelective(*_) >> new ArrayList<HouseInfo>()
        1 * creditSupplyInfoMapper.selectByModelSelective(*_) >> new ArrayList<CreditSupplyInfo>()
        1 * insuranceInfoMapper.selectByModelSelective(*_) >> new ArrayList<InsuranceInfo>()
    }
}
