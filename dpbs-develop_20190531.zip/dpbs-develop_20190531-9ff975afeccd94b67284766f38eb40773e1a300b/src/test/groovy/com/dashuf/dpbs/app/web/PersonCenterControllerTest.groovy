package com.dashuf.dpbs.app.web

import com.dashuf.dpbs.app.web.req.center.BindClientManagerReq
import com.dashuf.dpbs.app.web.req.center.GetContactMsgReq
import com.dashuf.dpbs.app.web.req.center.GetPersonCenterReq
import com.dashuf.dpbs.app.web.req.center.ModifyMobileNoReq
import com.dashuf.dpbs.app.web.req.center.UnBindClientManagerReq
import com.dashuf.dpbs.app.web.req.center.VerifyMobileNoReq
import com.dashuf.dpbs.app.web.req.user.VerifyCertReq
import com.dashuf.dpbs.app.web.resp.center.GetContactMsgResp
import com.dashuf.dpbs.app.web.resp.center.GetPersonCenterResp
import com.dashuf.dpbs.model.UserInfo
import com.dashuf.dpbs.service.PersonCenterSupportService
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.mock.web.MockHttpSession
import spock.lang.Specification

class PersonCenterControllerTest extends Specification {

    MockHttpServletRequest request
    MockHttpServletResponse response
    MockHttpSession session

    def setup() {
        request = new MockHttpServletRequest()
        request.setCharacterEncoding("UTF-8")
        response = new MockHttpServletResponse()
        session = new MockHttpSession()
    }

    PersonCenterSupportService personCenterSupportService = Mock(PersonCenterSupportService)
    PersonCenterController personCenterController = new PersonCenterController(personCenterSupportService: personCenterSupportService)


    def "modifyMobileNo case1:修改手机号码"() {
        given:
        ModifyMobileNoReq modifyMobileNoReq = new ModifyMobileNoReq()
        UserInfo userInfo = new UserInfo(userNo: "test", mobileNo: "test")
        when:
        personCenterController.modifyMobileNo(modifyMobileNoReq, "userNo")
        then:
        1 * personCenterSupportService.modifyMobileNo(*_) >> false
    }

    def "modifyMobileNo case2:修改手机号码"() {
        given:
        ModifyMobileNoReq modifyMobileNoReq = new ModifyMobileNoReq()
        UserInfo userInfo = new UserInfo(userNo: "test", mobileNo: "test")
        when:
        personCenterController.modifyMobileNo(modifyMobileNoReq, "userNo")
        then:
        1 * personCenterSupportService.modifyMobileNo(*_) >> true
    }

    def "modifyMobileNo case3:修改手机号码"() {
        given:
        ModifyMobileNoReq modifyMobileNoReq = new ModifyMobileNoReq()
        UserInfo userInfo = new UserInfo(userNo: "test", mobileNo: "test")
        when:
        personCenterController.modifyMobileNo(modifyMobileNoReq, "userNo")
        then:
        1 * personCenterSupportService.modifyMobileNo(*_) >> { throw new RuntimeException() }
    }

    def "verifyCert case1:实名认证"() {
        given:
        VerifyCertReq verifyCertReq = new VerifyCertReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.verifyCert(verifyCertReq, "userNo")
        then:
        1 * personCenterSupportService.verifyCert(*_) >> false
    }

    def "verifyCert case2:实名认证"() {
        given:
        VerifyCertReq verifyCertReq = new VerifyCertReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.verifyCert(verifyCertReq, "userNo")
        then:
        1 * personCenterSupportService.verifyCert(*_) >> true
    }

    def "verifyCert case3:实名认证"() {
        given:
        VerifyCertReq verifyCertReq = new VerifyCertReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.verifyCert(verifyCertReq, "userNo")
        then:
        1 * personCenterSupportService.verifyCert(*_) >> { throw new RuntimeException() }
    }


    def "bindClientManager case1:绑定客户经理"() {
        given:
        BindClientManagerReq bindClientManagerReq = new BindClientManagerReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.bindClientManager(bindClientManagerReq, "userNo")
        then:
        1 * personCenterSupportService.bindClientManager(*_) >> false
    }

    def "bindClientManager case2:绑定客户经理"() {
        given:
        BindClientManagerReq bindClientManagerReq = new BindClientManagerReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.bindClientManager(bindClientManagerReq, "userNo")
        then:
        1 * personCenterSupportService.bindClientManager(*_) >> true
    }

    def "bindClientManager case3:绑定客户经理"() {
        given:
        BindClientManagerReq bindClientManagerReq = new BindClientManagerReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.bindClientManager(bindClientManagerReq, "userNo")
        then:
        1 * personCenterSupportService.bindClientManager(*_) >> { throw new RuntimeException() }
    }


    def "unBindClientManager case1:解绑客户经理"() {
        given:
        UnBindClientManagerReq unBindClientManagerReq = new UnBindClientManagerReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.unBindClientManager(unBindClientManagerReq, "userNo")
        then:
        1 * personCenterSupportService.unBindClientManager(*_) >> false
    }

    def "unBindClientManager case2:解绑客户经理"() {
        given:
        UnBindClientManagerReq unBindClientManagerReq = new UnBindClientManagerReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.unBindClientManager(unBindClientManagerReq, "userNo")
        then:
        1 * personCenterSupportService.unBindClientManager(*_) >> true
    }

    def "unBindClientManager case3:解绑客户经理"() {
        given:
        UnBindClientManagerReq unBindClientManagerReq = new UnBindClientManagerReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.unBindClientManager(unBindClientManagerReq, "userNo")
        then:
        1 * personCenterSupportService.unBindClientManager(*_) >> { throw new RuntimeException() }
    }


    def "getPersonCenter case1:获取个人中心"() {
        given:
        GetPersonCenterReq getPersonCenterReq = new GetPersonCenterReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.getPersonCenter(getPersonCenterReq, "userNo")
        then:
        1 * personCenterSupportService.getPersonCenter(*_) >> null
    }

    def "getPersonCenter case2:获取个人中心"() {
        given:
        GetPersonCenterReq getPersonCenterReq = new GetPersonCenterReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.getPersonCenter(getPersonCenterReq, "userNo")
        then:
        1 * personCenterSupportService.getPersonCenter(*_) >> new GetPersonCenterResp()
    }

    def "getPersonCenter case3:获取个人中心"() {
        given:
        GetPersonCenterReq getPersonCenterReq = new GetPersonCenterReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.getPersonCenter(getPersonCenterReq, "userNo")
        then:
        1 * personCenterSupportService.getPersonCenter(*_) >> { throw new RuntimeException() }
    }


    def "verifyMobileNo case1:校验手机号码"() {
        given:
        VerifyMobileNoReq verifyMobileNoReq = new VerifyMobileNoReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.verifyMobileNo(verifyMobileNoReq, "userNo")
        then:
        1 * personCenterSupportService.verifyMobileNo(*_) >> false
    }

    def "verifyMobileNo case2:校验手机号码"() {
        given:
        VerifyMobileNoReq verifyMobileNoReq = new VerifyMobileNoReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.verifyMobileNo(verifyMobileNoReq, "userNo")
        then:
        1 * personCenterSupportService.verifyMobileNo(*_) >> true
    }

    def "verifyMobileNo case3:校验手机号码"() {
        given:
        VerifyMobileNoReq verifyMobileNoReq = new VerifyMobileNoReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.verifyMobileNo(verifyMobileNoReq, "userNo")
        then:
        1 * personCenterSupportService.verifyMobileNo(*_) >> { throw new RuntimeException() }
    }


    def "getContactMsg case1:联系我们"() {
        given:
        GetContactMsgReq getContactMsgReq = new GetContactMsgReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.getContactMsg(getContactMsgReq, "userNo")
        then:
        1 * personCenterSupportService.getContactMsg(*_) >> null
    }

    def "getContactMsg case2:联系我们"() {
        given:
        GetContactMsgReq getContactMsgReq = new GetContactMsgReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.getContactMsg(getContactMsgReq, "userNo")
        then:
        1 * personCenterSupportService.getContactMsg(*_) >> new GetContactMsgResp()
    }

    def "getContactMsg case3:联系我们"() {
        given:
        GetContactMsgReq getContactMsgReq = new GetContactMsgReq()
        UserInfo userInfo = new UserInfo()
        when:
        personCenterController.getContactMsg(getContactMsgReq, "userNo")
        then:
        1 * personCenterSupportService.getContactMsg(*_) >> { throw new RuntimeException() }
    }


    def "getContactMsgNoLogin case1:联系我们"() {
        given:
        GetContactMsgReq getContactMsgReq = new GetContactMsgReq()
        when:
        personCenterController.getContactMsg(getContactMsgReq)
        then:
        1 * personCenterSupportService.getContactMsg(*_) >> null
    }

    def "getContactMsgNoLogin case2:联系我们"() {
        given:
        GetContactMsgReq getContactMsgReq = new GetContactMsgReq()
        when:
        personCenterController.getContactMsg(getContactMsgReq)
        then:
        1 * personCenterSupportService.getContactMsg(*_) >> new GetContactMsgResp()
    }

    def "getContactMsgNoLogin case3:联系我们"() {
        given:
        GetContactMsgReq getContactMsgReq = new GetContactMsgReq()
        when:
        personCenterController.getContactMsg(getContactMsgReq)
        then:
        1 * personCenterSupportService.getContactMsg(*_) >> { throw new RuntimeException() }
    }


}
