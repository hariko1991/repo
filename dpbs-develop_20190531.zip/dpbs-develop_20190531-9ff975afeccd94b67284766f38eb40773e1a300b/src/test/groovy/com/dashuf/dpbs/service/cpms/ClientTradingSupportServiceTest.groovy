package com.dashuf.dpbs.service.cpms

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.sao.cpms.ClientTradingSAO
import com.dashuf.merlin.web.base.views.ResponseVo
import spock.lang.Specification

class ClientTradingSupportServiceTest extends Specification {

    ClientTradingSAO clientTradingSAO = Mock(ClientTradingSAO)
    ClientTradingSupportService clientTradingSupportService = new ClientTradingSupportService(clientTradingSAO: clientTradingSAO)

    def "inTrading case1: "() {
        when:
        clientTradingSupportService.inTrading("clientName", "certNo", new JSONObject())
        then:
        1 * clientTradingSAO.inTrading(*_) >> {
            return ResponseVo.fail("fail");
        }
    }

    def "inTrading case2: "() {
        when:
        clientTradingSupportService.inTrading("clientName", "certNo", new JSONObject())
        then:
        1 * clientTradingSAO.inTrading(*_) >> {
            return ResponseVo.success("success")
        }
    }

    def "inTrading case3: "() {
        when:
        clientTradingSupportService.inTrading("clientName", "certNo", new JSONObject())
        then:
        1 * clientTradingSAO.inTrading(*_) >> {
            return ResponseVo.success("1")
        }
    }
}
