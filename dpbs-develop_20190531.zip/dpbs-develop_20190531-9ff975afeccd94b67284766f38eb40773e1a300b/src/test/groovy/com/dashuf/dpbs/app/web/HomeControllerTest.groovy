package com.dashuf.dpbs.app.web

import com.dashuf.dpbs.app.web.req.home.GetUmInfoReq
import com.dashuf.dpbs.app.web.resp.home.NoticeResp
import com.dashuf.dpbs.app.web.resp.home.PosterResp
import com.dashuf.dpbs.model.UserInfo
import com.dashuf.dpbs.service.NoticeInfoService
import com.dashuf.dpbs.service.PosterInfoService
import com.dashuf.dpbs.service.UserInfoService
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.mock.web.MockHttpSession
import spock.lang.Specification

class HomeControllerTest extends Specification {
    MockHttpServletRequest request
    MockHttpServletResponse response
    MockHttpSession session

    def setup() {
        request = new MockHttpServletRequest()
        request.setCharacterEncoding("UTF-8")
        response = new MockHttpServletResponse()
        session = new MockHttpSession()
    }

    NoticeInfoService noticeInfoService = Mock(NoticeInfoService)
    PosterInfoService posterInfoService = Mock(PosterInfoService)
    UserInfoService userInfoService = Mock(UserInfoService)
    HomeController homeController = new HomeController(noticeInfoService: noticeInfoService,
            posterInfoService: posterInfoService, userInfoService: userInfoService)

    def "getNotice case1:公告查询"() {
        given:
        when:
        homeController.getNotice()
        then:
        1 * noticeInfoService.getNoticeList() >> new ArrayList<NoticeResp>()
    }

    def "getNotice case2:公告查询"() {
        given:
        when:
        homeController.getNotice()
        then:
        1 * noticeInfoService.getNoticeList() >> { throw new RuntimeException() }
    }


    def "getUmInfo case1:获取客户经理信息"() {
        given:
        GetUmInfoReq getUmInfoReq = new GetUmInfoReq()
        UserInfo userInfo = new UserInfo()
        when:
        homeController.getUmInfo(getUmInfoReq, "userNo")
        then:
        1 * userInfoService.getUserInfo(*_) >> null
    }

    def "getUmInfo case2:获取客户经理信息"() {
        given:
        GetUmInfoReq getUmInfoReq = new GetUmInfoReq()
        UserInfo userInfo = new UserInfo()
        when:
        homeController.getUmInfo(getUmInfoReq, "userNo")
        then:
        1 * userInfoService.getUserInfo(*_) >> new UserInfo()
    }

    def "getUmInfo case3:获取客户经理信息"() {
        given:
        GetUmInfoReq getUmInfoReq = new GetUmInfoReq()
        UserInfo userInfo = new UserInfo()
        when:
        homeController.getUmInfo(getUmInfoReq, "userNo")
        then:
        1 * userInfoService.getUserInfo(*_) >> { throw new RuntimeException() }
    }


    def "getPoster case1:海报查询"() {
        given:
        when:
        homeController.getPoster()
        then:
        1 * posterInfoService.getPosterList() >> new ArrayList<PosterResp>()
    }

    def "getPoster case2:海报查询"() {
        given:
        when:
        homeController.getPoster()
        then:
        1 * posterInfoService.getPosterList() >> { throw new RuntimeException() }
    }
}
