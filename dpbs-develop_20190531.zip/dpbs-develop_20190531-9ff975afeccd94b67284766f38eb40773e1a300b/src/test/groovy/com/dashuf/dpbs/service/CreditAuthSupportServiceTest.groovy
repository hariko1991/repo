package com.dashuf.dpbs.service

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.app.web.req.credit.AnalysisQrCodeReq
import com.dashuf.dpbs.app.web.req.credit.CreditAuthH5Req
import com.dashuf.dpbs.app.web.req.credit.SubmitAuthH5Req
import com.dashuf.dpbs.app.web.resp.QrCodeResp
import com.dashuf.dpbs.app.web.resp.credit.AnalysisQrCodeResp
import com.dashuf.dpbs.app.web.resp.credit.RefreshQrCodeResp
import com.dashuf.dpbs.mapper.SysConfMapper
import com.dashuf.dpbs.sao.defi.resp.ApplyRunEngineResp
import com.dashuf.dpbs.sao.defi.resp.apply.Decision
import com.dashuf.dpbs.sao.defi.resp.apply.Product
import com.dashuf.dpbs.sao.dsfg.CreditAuthSAO
import com.dashuf.dpbs.service.blaze.DashufBlazeSupportService
import com.dashuf.dpbs.service.blaze.dto.DashufBlazeDto
import com.dashuf.dpbs.service.support.ElecSignService
import com.dashuf.dpbs.service.support.dto.ElecCreditAuthDto
import com.dashuf.merlin.web.base.views.ResponseVo
import spock.lang.Specification

class CreditAuthSupportServiceTest extends Specification {

    CreditAuthSAO creditAuthSAO = Mock(CreditAuthSAO);
    QrCodeSupportService qrCodeSupportService = Mock(QrCodeSupportService);
    ElecSignService elecSignService = Mock(ElecSignService);
    SysConfSupportService sysConfSupportService = Mock(SysConfSupportService);
    DashufBlazeSupportService dashufBlazeSupportService = Mock(DashufBlazeSupportService);

    CreditAuthSupportService creditAuthSupportService = new CreditAuthSupportService(
            creditAuthSAO: creditAuthSAO,
            qrCodeSupportService: qrCodeSupportService,
            elecSignService: elecSignService,
            sysConfSupportService: sysConfSupportService,
            dashufBlazeSupportService: dashufBlazeSupportService
    )

    def "getCreditAuthH5 case1: "() {
        when:
        creditAuthSupportService.getCreditAuthH5(new CreditAuthH5Req(), new JSONObject())
        then:
        1 * sysConfSupportService.selectValueFromCache(*_) >> "confVal"
        1 * creditAuthSAO.sendCreditAuth(*_) >> "creditAuthResp"
    }

    def "getCreditAuthH5 case2: "() {
        when:
        creditAuthSupportService.getCreditAuthH5(new CreditAuthH5Req(), new JSONObject())
        then:
        1 * sysConfSupportService.selectValueFromCache(*_) >> "confVal"
        1 * creditAuthSAO.sendCreditAuth(*_) >> null
    }

    def "getCreditAuthH5 case3: "() {
        when:
        creditAuthSupportService.getCreditAuthH5(new CreditAuthH5Req(), new JSONObject())
        then:
        1 * sysConfSupportService.selectValueFromCache(*_) >> null
    }

    def "submitCreditAuth case1: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        ApplyRunEngineResp applyRunEngineResp = new ApplyRunEngineResp();
        Decision decision = new Decision()
        decision.setProductSelected(new ArrayList<Product>())
        applyRunEngineResp.setDecision(decision)
        when:
        creditAuthSupportService.submitCreditAuth(submitAuthH5Req, new JSONObject())
        then:
        1 * creditAuthSAO.queryCreditAuthResult(*_) >> { return ResponseVo.success("success"); }
    }

    def "submitCreditAuth case2: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        ApplyRunEngineResp applyRunEngineResp = new ApplyRunEngineResp();
        Decision decision = new Decision()
        decision.setProductSelected(new ArrayList<Product>())
        applyRunEngineResp.setDecision(decision)
        when:
        creditAuthSupportService.submitCreditAuth(submitAuthH5Req, new JSONObject())
        then:
        1 * creditAuthSAO.queryCreditAuthResult(*_) >> {
            ResponseVo resp = ResponseVo.success("success");
            resp.code = "0000";
            return resp
        }
    }

    def "submitCreditAuth case3: "() {
        given:
        SubmitAuthH5Req submitAuthH5Req = new SubmitAuthH5Req();
        ApplyRunEngineResp applyRunEngineResp = new ApplyRunEngineResp();
        Decision decision = new Decision()
        decision.setProductSelected(new ArrayList<Product>())
        applyRunEngineResp.setDecision(decision)
        when:
        creditAuthSupportService.submitCreditAuth(submitAuthH5Req, new JSONObject())
        then:
        1 * creditAuthSAO.queryCreditAuthResult(*_) >> { throw new RuntimeException() }
    }

    def "validSubmitCreditAuth case1: "() {
        when:
        creditAuthSupportService.validSubmitCreditAuth(new SubmitAuthH5Req(), new JSONObject())
        then:
        1 * dashufBlazeSupportService.gatherBlazeInfo(*_) >> new DashufBlazeDto()
    }

    def "analysisQrCode case1: "() {
        when:
        creditAuthSupportService.analysisQrCode(new AnalysisQrCodeReq(), new JSONObject())
        then:
        1 * qrCodeSupportService.analysisQrCode(*_) >> new AnalysisQrCodeResp()
    }

    def "initCreditAuthPage case1: "() {
        given:
        RefreshQrCodeResp refreshQrCodeResp = new RefreshQrCodeResp()
        when:
        creditAuthSupportService.initCreditAuthPage("pushOrderNo", refreshQrCodeResp, new JSONObject())
        then:
        1 * qrCodeSupportService.initQrCodeResp(*_) >> new QrCodeResp()
    }

    def "initCreditAuthPage case2: "() {
        given:
        RefreshQrCodeResp refreshQrCodeResp = new RefreshQrCodeResp()
        when:
        creditAuthSupportService.initCreditAuthPage("pushOrderNo", refreshQrCodeResp, new JSONObject())
        then:
        1 * qrCodeSupportService.initQrCodeResp(*_) >> null
    }

    def "signFileList case1: "() {
        given:
        JSONObject jsonObj = new JSONObject();
        jsonObj.put("authCode", "authCode")
        when:
        creditAuthSupportService.signFileList(new ElecCreditAuthDto(), new JSONObject());
        then:
        3 * elecSignService.elecCreditAuth(*_) >> true
    }

    def "signFileList case2: "() {
        given:
        JSONObject jsonObj = new JSONObject();
        jsonObj.put("authCode", "authCode")
        when:
        creditAuthSupportService.signFileList(new ElecCreditAuthDto(), new JSONObject());
        then:
        1 * elecSignService.elecCreditAuth(*_) >> false
    }
}
