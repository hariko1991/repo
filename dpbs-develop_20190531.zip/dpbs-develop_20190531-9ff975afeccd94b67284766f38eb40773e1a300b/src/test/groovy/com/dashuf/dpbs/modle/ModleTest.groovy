package com.dashuf.dpbs.modle

import com.dashuf.dpbs.model.ChangeLog
import com.dashuf.dpbs.model.ClientInfo
import com.dashuf.dpbs.model.CreditSupplyInfo
import com.dashuf.dpbs.model.HouseInfo
import com.dashuf.dpbs.model.InfoEntry
import com.dashuf.dpbs.model.InsuranceInfo
import com.dashuf.dpbs.model.LawsuitInfo
import com.dashuf.dpbs.model.LawsuitQueryRecord
import com.dashuf.dpbs.model.LawsuitRequestLog
import com.dashuf.dpbs.model.LoanStatusMap
import com.dashuf.dpbs.model.NoticeInfo
import com.dashuf.dpbs.model.PageRedirect
import com.dashuf.dpbs.model.PosterInfo
import com.dashuf.dpbs.model.PushLoan
import com.dashuf.dpbs.model.PushLoanProduct
import com.dashuf.dpbs.model.PushMsg
import com.dashuf.dpbs.model.PushMsgForm
import com.dashuf.dpbs.model.PushMsgLog
import com.dashuf.dpbs.model.PushOrderLog
import com.dashuf.dpbs.model.QrCodeInfo
import com.dashuf.dpbs.model.StepRefLog
import com.dashuf.dpbs.model.SysAreaInfo
import com.dashuf.dpbs.model.SysConf
import com.dashuf.dpbs.model.SysDict
import com.dashuf.dpbs.model.UserInfo
import spock.lang.Specification

import java.lang.reflect.Method
import java.lang.reflect.Modifier

class ModleTest extends Specification {

    def "initScreenDs010 case4: "() {
        given:
        ChangeLog changeLog = new ChangeLog()
        ClientInfo clientInfo = new ClientInfo()
        CreditSupplyInfo creditSupplyInfo = new CreditSupplyInfo()
        HouseInfo houseInfo = new HouseInfo()
        InfoEntry infoEntry = new InfoEntry()
        InsuranceInfo insuranceInfo = new InsuranceInfo()
        LawsuitInfo lawsuitInfo = new LawsuitInfo()
        LawsuitQueryRecord lawsuitQueryRecord = new LawsuitQueryRecord()
        LawsuitRequestLog lawsuitRequestLog = new LawsuitRequestLog()
        LoanStatusMap loanStatusMap = new LoanStatusMap()
        NoticeInfo noticeInfo = new NoticeInfo()
        PageRedirect pageRedirect = new PageRedirect()
        PosterInfo posterInfo = new PosterInfo();
        PushLoan pushLoanInfo = new PushLoan()
        PushLoanProduct pushLoanProduct = new PushLoanProduct()
        PushMsg pushMsg = new PushMsg()
        PushMsgForm pushMsgForm = new PushMsgForm()
        PushMsgLog pushMsgLog = new PushMsgLog()
        PushOrderLog pushOrderLog = new PushOrderLog()
        QrCodeInfo qrCodeInfo = new QrCodeInfo()
        StepRefLog stepRefLog = new StepRefLog()
        SysAreaInfo sysAreaInfo = new SysAreaInfo()
        SysConf sysConf = new SysConf()
        SysDict sysDict = new SysDict()
        UserInfo userInfo = new UserInfo()

        def objArray = [changeLog, clientInfo, creditSupplyInfo,
                        houseInfo, infoEntry, insuranceInfo,
                        lawsuitInfo, lawsuitQueryRecord, lawsuitRequestLog,
                        loanStatusMap, noticeInfo, pageRedirect,
                        posterInfo, pushLoanInfo, pushLoanProduct,
                        pushMsg, pushMsgForm, pushMsgLog,
                        pushOrderLog, qrCodeInfo, stepRefLog,
                        sysAreaInfo, sysConf, sysDict,
                        userInfo];

        for (int i = 0; i < objArray.size(); i++) {
            for (Method method : objArray[i].getClass().getMethods()) {
                if (method.getName().contains("set")) {

                    Class clazz = method.getParameterTypes()[0];
                    if (!Modifier.isAbstract(clazz.getModifiers()) && !clazz.isInterface()) {
                        try {
                            method.invoke(objArray[i], method.getParameterTypes()[0].newInstance())
                        } catch (Exception e1) {
                        }
                    }
                }

                if (method.getName().contains("get")) {
                    try {
                        method.invoke(objArray[i], null)
                    } catch (Exception e1) {
                    }
                }
            }
        }
        when:
        1
        then:
        1
    }
}
