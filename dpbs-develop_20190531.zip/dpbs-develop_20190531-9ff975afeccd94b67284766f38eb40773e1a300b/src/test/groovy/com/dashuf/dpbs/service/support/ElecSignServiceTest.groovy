package com.dashuf.dpbs.service.support

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.cnst.SysConfCnst
import com.dashuf.dpbs.mapper.SysConfMapper
import com.dashuf.dpbs.sao.support.ElecSignPlatSAO
import com.dashuf.dpbs.sao.support.PdfTempPlatSAO
import com.dashuf.dpbs.sao.support.resp.GetFileTemplateResp
import com.dashuf.dpbs.sao.support.resp.GetPersonSignResp
import com.dashuf.dpbs.service.SysConfSupportService
import com.dashuf.dpbs.service.support.dto.ElecCreditAuthDto
import spock.lang.Specification

class ElecSignServiceTest extends Specification {
    PdfTempPlatSAO pdfTempPlatSAO = Mock(PdfTempPlatSAO);
    ElecSignPlatSAO elecSignPlatSAO = Mock(ElecSignPlatSAO);
    SysConfSupportService sysConfSupportService = Mock(SysConfSupportService)

    ElecSignService elecSignService = new ElecSignService(
            pdfTempPlatSAO: pdfTempPlatSAO,
            elecSignPlatSAO: elecSignPlatSAO,
            sysConfSupportService: sysConfSupportService)

    def "elecCreditAuth case1: "() {
        given:
        ElecCreditAuthDto elecCreditAuthDto = new ElecCreditAuthDto()
        when:
        elecSignService.elecCreditAuth(elecCreditAuthDto, new JSONObject())
        then:
        2 * sysConfSupportService.selectValueFromCache(*_) >> "confVal"
        1 * pdfTempPlatSAO.getFileTemplate(*_) >> {
            GetFileTemplateResp getFileTemplateResp = new GetFileTemplateResp();
            return com.dashuf.merlin.web.base.views.ResponseVo.success(getFileTemplateResp);
        }
    }

    def "elecCreditAuth case2: "() {
        given:
        ElecCreditAuthDto elecCreditAuthDto = new ElecCreditAuthDto()
        when:
        elecSignService.elecCreditAuth(elecCreditAuthDto, new JSONObject())
        then:
        2 * sysConfSupportService.selectValueFromCache(*_) >> "confVal"
        1 * pdfTempPlatSAO.getFileTemplate(*_) >> {
            GetFileTemplateResp getFileTemplateResp = new GetFileTemplateResp();
            return com.dashuf.merlin.web.base.views.ResponseVo.success(getFileTemplateResp);
        }
    }

    def "elecCreditAuth case3: "() {
        given:
        ElecCreditAuthDto elecCreditAuthDto = new ElecCreditAuthDto()
        when:
        elecSignService.elecCreditAuth(elecCreditAuthDto, new JSONObject())
        then:
        1 * sysConfSupportService.selectValueFromCache(*_) >> null
        1 * sysConfSupportService.selectValueFromCache(*_) >> "confVal"
        1 * pdfTempPlatSAO.getFileTemplate(*_) >> {
            return com.dashuf.merlin.web.base.views.ResponseVo.fail("fail");
        }
    }

    def "elecCreditAuth case4: "() {
        given:
        ElecCreditAuthDto elecCreditAuthDto = new ElecCreditAuthDto()
        when:
        elecSignService.elecCreditAuth(elecCreditAuthDto, new JSONObject())
        then:
        1 * sysConfSupportService.selectValueFromCache(*_) >> null
        1 * sysConfSupportService.selectValueFromCache(*_) >> "confVal"
        1 * pdfTempPlatSAO.getFileTemplate(*_) >> {
            GetFileTemplateResp getFileTemplateResp = new GetFileTemplateResp();
            return com.dashuf.merlin.web.base.views.ResponseVo.success(getFileTemplateResp);
        }
    }

    def "elecCreditAuth case5: "() {
        given:
        ElecCreditAuthDto elecCreditAuthDto = new ElecCreditAuthDto()
        elecCreditAuthDto.setSave(true)
        when:
        elecSignService.elecCreditAuth(elecCreditAuthDto, new JSONObject())
        then:
        1 * sysConfSupportService.selectValueFromCache(*_) >> null
        2 * sysConfSupportService.selectValueFromCache(*_) >> "confVal"
        1 * pdfTempPlatSAO.getFileTemplate(*_) >> {
            GetFileTemplateResp getFileTemplateResp = new GetFileTemplateResp();
            getFileTemplateResp.setFileId("fileId");
            return com.dashuf.merlin.web.base.views.ResponseVo.fail("0000", getFileTemplateResp, "success");
        }
        1 * sysConfSupportService.updateValueForDb(*_) >> 1
        1 * elecSignPlatSAO.personSign(*_) >> {
            GetPersonSignResp getPersonSignResp = new GetPersonSignResp();
            return com.dashuf.merlin.web.base.views.ResponseVo.success(getPersonSignResp);
        }
    }

    def "elecCreditAuth case6: "() {
        given:
        ElecCreditAuthDto elecCreditAuthDto = new ElecCreditAuthDto()
        elecCreditAuthDto.setSave(true)
        when:
        elecSignService.elecCreditAuth(elecCreditAuthDto, new JSONObject())
        then:
        1 * sysConfSupportService.selectValueFromCache(*_) >> null
        2 * sysConfSupportService.selectValueFromCache(*_) >> "confVal"
        1 * pdfTempPlatSAO.getFileTemplate(*_) >> {
            GetFileTemplateResp getFileTemplateResp = new GetFileTemplateResp();
            getFileTemplateResp.setFileId("fileId");
            return com.dashuf.merlin.web.base.views.ResponseVo.fail("0000", getFileTemplateResp, "success");
        }
        1 * sysConfSupportService.updateValueForDb(*_) >> 0
        1 * elecSignPlatSAO.personSign(*_) >> {
            GetPersonSignResp getPersonSignResp = new GetPersonSignResp();
            return com.dashuf.merlin.web.base.views.ResponseVo.fail("00", "{'fileId':'fileId'}", "00");
        }
    }
}
