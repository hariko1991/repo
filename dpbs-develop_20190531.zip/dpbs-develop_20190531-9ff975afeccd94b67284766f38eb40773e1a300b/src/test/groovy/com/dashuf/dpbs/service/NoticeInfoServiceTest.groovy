package com.dashuf.dpbs.service

import com.dashuf.dpbs.mapper.NoticeInfoMapper
import com.dashuf.dpbs.model.NoticeInfo
import spock.lang.Specification

/**
 *
 * Created with IDEA
 * author:Likangcheng
 * Date:2019/2/27
 * Time:11:03
 *
 * */
class NoticeInfoServiceTest extends Specification {

    NoticeInfoMapper noticeInfoMapper = Mock(NoticeInfoMapper)
    NoticeInfoService noticeInfoService = new NoticeInfoService(noticeInfoMapper: noticeInfoMapper)

    def "test getNoticeList"() {
        when:
        noticeInfoService.getNoticeList()
        then:
        1 * noticeInfoMapper.selectByModelSelective(*_) >> {
            List<NoticeInfo> list = new ArrayList<>()
            NoticeInfo noticeInfo = new NoticeInfo()
            noticeInfo.setStartDate(new Date())
            noticeInfo.setEndDate(new Date())
            list.add(noticeInfo)
            return list
        }
    }
}
