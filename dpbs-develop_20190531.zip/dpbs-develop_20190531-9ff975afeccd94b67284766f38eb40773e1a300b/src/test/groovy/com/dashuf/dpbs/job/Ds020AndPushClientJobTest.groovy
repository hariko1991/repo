package com.dashuf.dpbs.job

import com.dangdang.ddframe.job.api.ShardingContext
import com.dashuf.dpbs.cnst.DpbsStatusCnst
import com.dashuf.dpbs.model.PushOrderLog
import com.dashuf.dpbs.service.blaze.ThirdPartyAccessSupportService
import spock.lang.Specification

class Ds020AndPushClientJobTest extends Specification {
    ThirdPartyAccessSupportService thirdPartyAccessSupportService = Mock(ThirdPartyAccessSupportService)
    ShardingContext shardingContext = GroovyMock(ShardingContext.class)
    Ds020AndPushClientJob ds020AndPushClientJob = new Ds020AndPushClientJob(thirdPartyAccessSupportService: thirdPartyAccessSupportService);


    def "execute case1: "() {

        when:
        ds020AndPushClientJob.execute(shardingContext)
        then:
        1 * thirdPartyAccessSupportService.queryNeedGetDs020List(*_) >> {
            List<PushOrderLog> pushOrderLogList = new ArrayList<>()
            PushOrderLog pushOrderLog = new PushOrderLog()
            pushOrderLog.setPushStatus(DpbsStatusCnst.PUSH_CREDIT)
            pushOrderLogList.add(pushOrderLog)
            pushOrderLog = new PushOrderLog()
            pushOrderLog.setPushStatus(DpbsStatusCnst.PUSH_EVAL_ING)
            pushOrderLogList.add(pushOrderLog)
            pushOrderLog = new PushOrderLog()
            pushOrderLog.setPushStatus(DpbsStatusCnst.PUSH_EVAL_SUCCESS)
            pushOrderLogList.add(pushOrderLog)
            return pushOrderLogList
        }
        1 * thirdPartyAccessSupportService.lockPushOrderLog(*_) >> true
        1 * thirdPartyAccessSupportService.initScreenDs010(*_) >> true
        1 * thirdPartyAccessSupportService.lockPushOrderLog(*_) >> true
        1 * thirdPartyAccessSupportService.queryScoreDs020(*_) >> true
        1 * thirdPartyAccessSupportService.lockPushOrderLog(*_) >> true
        1 * thirdPartyAccessSupportService.pushClient(*_) >> true
    }

    def "execute case2: "() {
        when:
        ds020AndPushClientJob.execute(shardingContext)
        then:
        1 * thirdPartyAccessSupportService.queryNeedGetDs020List(*_) >> {
            List<PushOrderLog> pushOrderLogList = new ArrayList<>()
            return pushOrderLogList
        }
    }

    def "execute case3: "() {
        when:
        ds020AndPushClientJob.execute(shardingContext)
        then:
        1 * thirdPartyAccessSupportService.queryNeedGetDs020List(*_) >> {
            List<PushOrderLog> pushOrderLogList = new ArrayList<>()
            PushOrderLog pushOrderLog = new PushOrderLog()
            pushOrderLog.setPushStatus(DpbsStatusCnst.PUSH_CREDIT)
            pushOrderLogList.add(pushOrderLog)
            return pushOrderLogList
        }
        1 * thirdPartyAccessSupportService.lockPushOrderLog(*_) >> true
        1 * thirdPartyAccessSupportService.initScreenDs010(*_) >> { throw new RuntimeException() }
    }

    def "execute case4: "() {
        when:
        ds020AndPushClientJob.execute(shardingContext)
        then:
        1 * thirdPartyAccessSupportService.queryNeedGetDs020List(*_) >> {
            List<PushOrderLog> pushOrderLogList = new ArrayList<>()
            PushOrderLog pushOrderLog = new PushOrderLog()
            pushOrderLog.setPushStatus(DpbsStatusCnst.PUSH_CREDIT)
            pushOrderLogList.add(pushOrderLog)
            return pushOrderLogList
        }
        1 * thirdPartyAccessSupportService.lockPushOrderLog(*_) >> false
    }

}

