package com.dashuf.dpbs.service

import com.dashuf.dpbs.app.web.resp.business.BusinessProcessResp
import com.dashuf.dpbs.app.web.resp.business.ClientBaseInfoResp
import com.dashuf.dpbs.mapper.ClientInfoMapper
import com.dashuf.dpbs.mapper.PushLoanProductMapper
import com.dashuf.dpbs.mapper.PushOrderLogMapper
import com.dashuf.dpbs.model.PushLoanProduct
import com.dashuf.dpbs.model.PushOrderLog
import com.dashuf.merlin.mybatis.page.Pagination
import spock.lang.Specification

/**
 *
 * Created with IDEA
 * author:Likangcheng
 * Date:2019/2/27
 * Time:10:22
 *
 * */
class BusinessProcessServiceTest extends Specification {

    PushOrderLogMapper pushOrderLogMapper = Mock(PushOrderLogMapper)
    ClientInfoMapper clientInfoMapper = Mock(ClientInfoMapper)
    PushLoanProductMapper pushLoanProductMapper = Mock(PushLoanProductMapper)
    BusinessProcessService businessProcessService = new BusinessProcessService(
            pushOrderLogMapper: pushOrderLogMapper,
            clientInfoMapper: clientInfoMapper,
            pushLoanProductMapper: pushLoanProductMapper
    )

    def "test getBusinessProcess"() {

        when:
        businessProcessService.getBusinessProcess(1, "sss", new Pagination(1, 2))
        then:
        1 * pushOrderLogMapper.getBusinessProcess(*_) >> {
            List<BusinessProcessResp> list = new ArrayList<>()
            BusinessProcessResp businessProcessResp = new BusinessProcessResp()
            list.add(businessProcessResp)
            return list
        }
    }

    def "test getBusinessDetail case1"() {
        when:
        businessProcessService.getBusinessDetail("xxx")
        then:
        1 * pushOrderLogMapper.selectOneByModelSelective(*_) >> null
    }

    def "test getBusinessDetail case2"() {
        when:
        businessProcessService.getBusinessDetail("xxx")
        then:
        1 * pushOrderLogMapper.selectOneByModelSelective(*_) >> new PushOrderLog()
        1 * clientInfoMapper.getClientBaseInfo(*_) >> null
    }

    def "test getBusinessDetail case3"() {
        when:
        businessProcessService.getBusinessDetail("xxx")
        then:
        1 * pushOrderLogMapper.selectOneByModelSelective(*_) >> new PushOrderLog(pushStatus: "init")
        1 * clientInfoMapper.getClientBaseInfo(*_) >> new ClientBaseInfoResp()
    }

    def "test getBusinessDetail case4"() {
        when:
        businessProcessService.getBusinessDetail("xxx")
        then:
        1 * pushOrderLogMapper.selectOneByModelSelective(*_) >> new PushOrderLog(pushStatus: "credit")
        1 * clientInfoMapper.getClientBaseInfo(*_) >> new ClientBaseInfoResp()
    }

    def "test getBusinessDetail case5"() {
        when:
        businessProcessService.getBusinessDetail("xxx")
        then:
        1 * pushOrderLogMapper.selectOneByModelSelective(*_) >> new PushOrderLog(pushStatus: "eval_ing")
        1 * clientInfoMapper.getClientBaseInfo(*_) >> new ClientBaseInfoResp()
    }

    def "test getBusinessDetail case6"() {
        when:
        businessProcessService.getBusinessDetail("xxx")
        then:
        1 * pushOrderLogMapper.selectOneByModelSelective(*_) >> new PushOrderLog(pushStatus: "eval_fail")
        1 * clientInfoMapper.getClientBaseInfo(*_) >> new ClientBaseInfoResp()
    }

    def "test getBusinessDetail case7"() {
        when:
        businessProcessService.getBusinessDetail("xxx")
        then:
        1 * pushOrderLogMapper.selectOneByModelSelective(*_) >> new PushOrderLog(pushStatus: "fail")
        1 * clientInfoMapper.getClientBaseInfo(*_) >> new ClientBaseInfoResp()
    }

    def "test getBusinessDetail case8"() {
        when:
        businessProcessService.getBusinessDetail("xxx")
        then:
        1 * pushOrderLogMapper.selectOneByModelSelective(*_) >> new PushOrderLog(pushStatus: "eval_success")
        1 * clientInfoMapper.getClientBaseInfo(*_) >> new ClientBaseInfoResp()
    }

    def "test getBusinessDetail case9"() {
        when:
        businessProcessService.getBusinessDetail("xxx")
        then:
        1 * pushOrderLogMapper.selectOneByModelSelective(*_) >> new PushOrderLog(pushStatus: "approval_veto")
        1 * clientInfoMapper.getClientBaseInfo(*_) >> new ClientBaseInfoResp()
        1 * pushLoanProductMapper.selectByModelSelective(*_) >> {
            List<PushLoanProduct> list = new ArrayList<>()
            PushLoanProduct product = new PushLoanProduct()
            PushLoanProduct product2 = new PushLoanProduct()
            list.add(product)
            list.add(product2)
            return list
        }
    }

    def "test getBusinessDetail case10"() {
        when:
        businessProcessService.getBusinessDetail("xxx")
        then:
        1 * pushOrderLogMapper.selectOneByModelSelective(*_) >> new PushOrderLog(pushStatus: "approval_veto")
        1 * clientInfoMapper.getClientBaseInfo(*_) >> new ClientBaseInfoResp()
        1 * pushLoanProductMapper.selectByModelSelective(*_) >> null
    }


    def "test getBusinessDetail case11"() {
        when:
        businessProcessService.getBusinessDetail("xxx")
        then:
        1 * pushOrderLogMapper.selectOneByModelSelective(*_) >> new PushOrderLog(pushStatus: "loan_success")
        1 * clientInfoMapper.getClientBaseInfo(*_) >> new ClientBaseInfoResp()
        1 * pushLoanProductMapper.selectByModelSelective(*_) >> {
            List<PushLoanProduct> list = new ArrayList<>()
            PushLoanProduct product = new PushLoanProduct()
            PushLoanProduct product2 = new PushLoanProduct()
            list.add(product)
            list.add(product2)
            return list
        }
    }

}
