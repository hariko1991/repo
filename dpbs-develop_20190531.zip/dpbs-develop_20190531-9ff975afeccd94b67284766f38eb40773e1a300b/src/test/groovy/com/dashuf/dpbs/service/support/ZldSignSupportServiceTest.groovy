package com.dashuf.dpbs.service.support

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.sao.dsfg.CreditAuthSAO
import com.dashuf.dpbs.sao.dsfg.UploadCreditFileResp
import com.dashuf.dpbs.service.SysConfSupportService
import com.dashuf.dpbs.service.support.dto.ElecCreditAuthDto
import com.dashuf.merlin.ftb.service.FtbService
import com.dashuf.merlin.web.base.views.ResponseVo
import spock.lang.Specification

class ZldSignSupportServiceTest extends Specification {

    SftpSupportService sftpSupportService = Mock(SftpSupportService);
    SysConfSupportService sysConfSupportService = Mock(SysConfSupportService);
    FtbService ftbService = Mock(FtbService);
    CreditAuthSAO creditAuthSAO = Mock(CreditAuthSAO);

    ZldSignSupportService zldSignSupportService = new ZldSignSupportService(sftpSupportService: sftpSupportService,
            sysConfSupportService: sysConfSupportService,
            ftbService: ftbService,
            creditAuthSAO: creditAuthSAO)

    def "uploadFileToZldSftp case1: "() {
        given:
        ElecCreditAuthDto elecCreditAuthDto = new ElecCreditAuthDto()
        elecCreditAuthDto.setCertName("certName")
        JSONObject signJsonObj = new JSONObject()
        signJsonObj.put("file1", "ok")
        signJsonObj.put("file2", "ok")
        signJsonObj.put("file3", "ok")
        when:
        zldSignSupportService.uploadFileToZldSftp(elecCreditAuthDto, signJsonObj, new JSONObject())
        then:
        1 * sysConfSupportService.selectMockValFromCache(*_) >> false
        1 * sysConfSupportService.selectValueFromCache(*_) >> '{\"host\":\"\",\"port\":\"22\",\"user\":\"\",\"secret\":\"\",\"remote\":\"\",\"timeout\":\"6000\",\"local\":\"\"}'
        2 * ftbService.downloadFile(*_) >> new File("test")
        1 * sftpSupportService.localFileListToSftp(*_) >> true
        1 * creditAuthSAO.uploadCreditFile(*_) >> {
            UploadCreditFileResp uploadCreditFileResp = new UploadCreditFileResp();
            uploadCreditFileResp.setResult("0000")

            return ResponseVo.fail("SUC000", uploadCreditFileResp, "")
        }

    }

    def "uploadFileToZldSftp case2: "() {
        given:
        ElecCreditAuthDto elecCreditAuthDto = new ElecCreditAuthDto()
        elecCreditAuthDto.setCertName("certName")
        JSONObject signJsonObj = new JSONObject()
        signJsonObj.put("file1", "ok")
        signJsonObj.put("file2", "ok")
        signJsonObj.put("file3", "ok")
        when:
        zldSignSupportService.uploadFileToZldSftp(elecCreditAuthDto, signJsonObj, new JSONObject())
        then:
        1 * sysConfSupportService.selectMockValFromCache(*_) >> false
        1 * sysConfSupportService.selectValueFromCache(*_) >> '{\"host\":\"\",\"port\":\"22\",\"user\":\"\",\"secret\":\"\",\"remote\":\"\",\"timeout\":\"6000\",\"local\":\"\"}'
        2 * ftbService.downloadFile(*_) >> new File("test")
        1 * sftpSupportService.localFileListToSftp(*_) >> true
        1 * creditAuthSAO.uploadCreditFile(*_) >> {
            throw new RuntimeException()
        }
    }

    def "uploadFileToZldSftp case3: "() {
        given:
        ElecCreditAuthDto elecCreditAuthDto = new ElecCreditAuthDto()
        elecCreditAuthDto.setCertName("certName")
        JSONObject signJsonObj = new JSONObject()
        signJsonObj.put("file1", "ok")
        signJsonObj.put("file2", "ok")
        signJsonObj.put("file3", "ok")
        when:
        zldSignSupportService.uploadFileToZldSftp(elecCreditAuthDto, signJsonObj, new JSONObject())
        then:
        1 * sysConfSupportService.selectMockValFromCache(*_) >> false
        1 * sysConfSupportService.selectValueFromCache(*_) >> '{\"host\":\"\",\"port\":\"22\",\"user\":\"\",\"secret\":\"\",\"remote\":\"\",\"timeout\":\"6000\",\"local\":\"\"}'
        2 * ftbService.downloadFile(*_) >> new File("test")
        1 * sftpSupportService.localFileListToSftp(*_) >> true
        1 * creditAuthSAO.uploadCreditFile(*_) >> {
            UploadCreditFileResp uploadCreditFileResp = new UploadCreditFileResp();
            uploadCreditFileResp.setResult("111")

            return ResponseVo.fail("SUC000", uploadCreditFileResp, "")
        }
    }

    def "uploadFileToZldSftp case4: "() {
        given:
        ElecCreditAuthDto elecCreditAuthDto = new ElecCreditAuthDto()
        elecCreditAuthDto.setCertName("certName")
        JSONObject signJsonObj = new JSONObject()
        signJsonObj.put("file1", "ok")
        signJsonObj.put("file2", "ok")
        signJsonObj.put("file3", "ok")
        when:
        zldSignSupportService.uploadFileToZldSftp(elecCreditAuthDto, signJsonObj, new JSONObject())
        then:
        1 * sysConfSupportService.selectMockValFromCache(*_) >> false
        1 * sysConfSupportService.selectValueFromCache(*_) >> '{\"host\":\"\",\"port\":\"22\",\"user\":\"\",\"secret\":\"\",\"remote\":\"\",\"timeout\":\"6000\",\"local\":\"\"}'
        2 * ftbService.downloadFile(*_) >> new File("test")
        1 * sftpSupportService.localFileListToSftp(*_) >> true
        1 * creditAuthSAO.uploadCreditFile(*_) >> {
            UploadCreditFileResp uploadCreditFileResp = new UploadCreditFileResp();
            uploadCreditFileResp.setResult("111")

            return ResponseVo.fail("SUC1000", uploadCreditFileResp, "")
        }
    }


    def "uploadFileToZldSftp case5: "() {
        given:
        ElecCreditAuthDto elecCreditAuthDto = new ElecCreditAuthDto()
        elecCreditAuthDto.setCertName("certName")
        JSONObject signJsonObj = new JSONObject()
        signJsonObj.put("file1", "ok")
        signJsonObj.put("file2", "ok")
        signJsonObj.put("file3", "ok")
        when:
        zldSignSupportService.uploadFileToZldSftp(elecCreditAuthDto, signJsonObj, new JSONObject())
        then:
        1 * sysConfSupportService.selectMockValFromCache(*_) >> false
        1 * sysConfSupportService.selectValueFromCache(*_) >> '{\"host\":\"\",\"port\":\"22\",\"user\":\"\",\"secret\":\"\",\"remote\":\"\",\"timeout\":\"6000\",\"local\":\"\"}'
        2 * ftbService.downloadFile(*_) >> new File("test")
        1 * sftpSupportService.localFileListToSftp(*_) >> false
    }

    def "uploadFileToZldSftp case6: "() {
        given:
        ElecCreditAuthDto elecCreditAuthDto = new ElecCreditAuthDto()
        elecCreditAuthDto.setCertName("certName")
        JSONObject signJsonObj = new JSONObject()
        signJsonObj.put("file1", "ok")
        signJsonObj.put("file2", "ok")
        signJsonObj.put("file3", "ok")
        when:
        zldSignSupportService.uploadFileToZldSftp(elecCreditAuthDto, signJsonObj, new JSONObject())
        then:
        1 * sysConfSupportService.selectMockValFromCache(*_) >> true
    }
}
