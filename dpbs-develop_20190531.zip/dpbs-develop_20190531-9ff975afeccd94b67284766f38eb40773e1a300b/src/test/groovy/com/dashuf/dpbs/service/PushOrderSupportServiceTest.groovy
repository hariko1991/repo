package com.dashuf.dpbs.service

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.app.web.req.push.GiveUpPushOrderReq
import com.dashuf.dpbs.app.web.req.push.InfoEntryReq
import com.dashuf.dpbs.app.web.req.push.InitPushOrderReq
import com.dashuf.dpbs.app.web.req.push.ScanCertReq
import com.dashuf.dpbs.app.web.resp.QrCodeResp
import com.dashuf.dpbs.app.web.resp.push.InfoEntryResp
import com.dashuf.dpbs.cnst.DpbsCnst
import com.dashuf.dpbs.mapper.ClientInfoMapper
import com.dashuf.dpbs.mapper.UserInfoMapper
import com.dashuf.dpbs.model.ClientInfo
import com.dashuf.dpbs.model.PushOrderLog
import com.dashuf.dpbs.model.UserInfo
import com.dashuf.dpbs.service.cpms.ClientTradingSupportService
import com.dashuf.dpbs.service.laapp.AppBlazeService
import com.dashuf.dpbs.service.support.IcpAuthSupportService
import com.dashuf.dpbs.service.support.MoviePlatRefService
import org.springframework.web.multipart.MultipartFile
import spock.lang.Specification

class PushOrderSupportServiceTest extends Specification {
    MoviePlatRefService moviePlatRefService = Mock(MoviePlatRefService)
    PushOrderLogService pushOrderLogService = Mock(PushOrderLogService)
    ClientTradingSupportService clientTradingSupportService = Mock(ClientTradingSupportService)
    ClientInfoMapper clientInfoMapper = Mock(ClientInfoMapper)
    UserInfoMapper userInfoMapper = Mock(UserInfoMapper)
    IcpAuthSupportService icpAuthSupportService = Mock(IcpAuthSupportService)
    QrCodeSupportService qrCodeSupportService = Mock(QrCodeSupportService)
    AppBlazeService appBlazeService = Mock(AppBlazeService)

    PushOrderSupportService pushOrderSupportService = new PushOrderSupportService(moviePlatRefService: moviePlatRefService,
            pushOrderLogService: pushOrderLogService,
            clientTradingSupportService: clientTradingSupportService,
            clientInfoMapper: clientInfoMapper,
            userInfoMapper: userInfoMapper,
            icpAuthSupportService: icpAuthSupportService,
            qrCodeSupportService: qrCodeSupportService,
            appBlazeService: appBlazeService)

    def "getScore case1: "() {
        when:
        pushOrderSupportService.getScore(null, new JSONObject())
        then:
        1 * pushOrderLogService.selectOneByModelSelective(*_) >> null
    }

    def "getScore case2: "() {
        when:
        pushOrderSupportService.getScore(null, new JSONObject())
        then:
        1 * pushOrderLogService.selectOneByModelSelective(*_) >> new PushOrderLog()
        1 * clientInfoMapper.selectOneByModelSelective(*_) >> new ClientInfo()
    }

    def "initPushOrder case1: "() {
        given:
        InitPushOrderReq initPushOrderReq = new InitPushOrderReq();
        when:
        pushOrderSupportService.initPushOrder("userNo", new JSONObject())
        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> {
            UserInfo userInfo = new UserInfo();
            return userInfo;
        }
    }

    def "initPushOrder case2: "() {
        given:
        InitPushOrderReq initPushOrderReq = new InitPushOrderReq();
        when:
        pushOrderSupportService.initPushOrder("userNo", new JSONObject())
        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> {
            UserInfo userInfo = new UserInfo();
            userInfo.setSrcUmNo("liuqiang1");
            return userInfo;
        }
    }

    def "initPushOrder case3: "() {
        given:
        InitPushOrderReq initPushOrderReq = new InitPushOrderReq();
        when:
        pushOrderSupportService.initPushOrder("userNo", new JSONObject())
        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> {
            UserInfo userInfo = new UserInfo();
            userInfo.setSrcUmNo("liuqiang1");
            userInfo.setCertNo("certNo");
            userInfo.setUserName("userName");
            return userInfo;
        }
    }

    def "scanCert case1: "() {
        given:
        ScanCertReq scanCertReq = new ScanCertReq();
        when:
        pushOrderSupportService.scanCert(scanCertReq, new JSONObject())
        then:
        1 * appBlazeService.queyClientIsAllownPush(*_) >> false
    }

    def "scanCert case2: "() {
        given:
        ScanCertReq scanCertReq = new ScanCertReq();
        scanCertReq.setCertNo("410322199101081834");
        when:
        pushOrderSupportService.scanCert(scanCertReq, new JSONObject())
        then:
        1 * appBlazeService.queyClientIsAllownPush(*_) >> true
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> {
            UserInfo userInfo = new UserInfo();
            userInfo.setSrcUmNo("liuqiang1");
            return userInfo;
        }
        1 * pushOrderLogService.initPushOrder(*_) >> 1
        1 * clientTradingSupportService.inTrading(*_) >> true
        1 * icpAuthSupportService.checkPersonMsg(*_) >> true
        1 * clientInfoMapper.initSingleClientInfo(*_) >> 1
        1 * pushOrderLogService.updatePushOrderLogByOrgStatus(*_) >> true
    }

    def "scanCert case3: "() {
        given:
        ScanCertReq scanCertReq = new ScanCertReq();
        when:
        pushOrderSupportService.scanCert(scanCertReq, new JSONObject())
        then:
        1 * appBlazeService.queyClientIsAllownPush(*_) >> true
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> {
            UserInfo userInfo = new UserInfo();
            return userInfo;
        }
    }

    def "uploadImg case1: "() {
        given:
        MultipartFile[] fileList = new MultipartFile[2];
        when:
        pushOrderSupportService.uploadImg(fileList, null, new JSONObject())
        then:
        1 * moviePlatRefService.copyTempFileToServer(*_) >> { throw new RuntimeException() }
    }

    def "uploadImg case2: "() {
        given:
        MultipartFile[] fileList = new MultipartFile[2];
        when:
        pushOrderSupportService.uploadImg(fileList, null, new JSONObject())
        then:
        1 * moviePlatRefService.copyTempFileToServer(*_) >> new ArrayList<File>()
        1 * moviePlatRefService.uploadHandler(*_) >> {
            JSONObject jsonObj = new JSONObject();
            jsonObj.put(DpbsCnst.RTN_CODE, DpbsCnst.FAIL_RTN_CODE);
            return jsonObj;
        }
    }

    def "uploadImg case3: "() {
        given:
        MultipartFile[] fileList = new MultipartFile[2];
        when:
        pushOrderSupportService.uploadImg(fileList, null, new JSONObject())
        then:
        1 * moviePlatRefService.copyTempFileToServer(*_) >> new ArrayList<File>()
        1 * moviePlatRefService.uploadHandler(*_) >> {
            JSONObject jsonObj = new JSONObject();
            jsonObj.put(DpbsCnst.RTN_CODE, "200");
            return jsonObj;
        }
    }

    def "uploadImg case4: "() {
        given:
        MultipartFile[] fileList = new MultipartFile[2];
        when:
        pushOrderSupportService.uploadImg(fileList, null, new JSONObject())
        then:
        1 * moviePlatRefService.copyTempFileToServer(*_) >> new ArrayList<File>()
        1 * moviePlatRefService.uploadHandler(*_) >> { throw new RuntimeException() }
    }

    def "uploadImg case5: "() {
        given:
        MultipartFile[] fileList = new MultipartFile[2];
        when:
        pushOrderSupportService.uploadImg(fileList, null, new JSONObject())
        then:
        1 * moviePlatRefService.copyTempFileToServer(*_) >> new ArrayList<File>()
        1 * moviePlatRefService.uploadHandler(*_) >> {
            JSONObject jsonObj = new JSONObject();
            jsonObj.put(DpbsCnst.RTN_CODE, "200");
            return jsonObj;
        }
        1 * pushOrderLogService.updatePushOrderLogByOrgStatus(*_) >> true
    }


    def "infoEntry case1: "() {
        given:
        InfoEntryReq infoEntryReq = new InfoEntryReq();
        when:
        pushOrderSupportService.infoEntry(infoEntryReq, new JSONObject())
        then:
        1 * pushOrderLogService.fullPushOrderLog(*_) >> true
        1 * pushOrderLogService.updatePushOrderLogByOrgStatus(*_) >> true
    }

    def "initCreditAuthPage case1: "() {
        when:
        pushOrderSupportService.initCreditAuthPage(null, new InfoEntryResp(), new JSONObject())
        then:
        1 * qrCodeSupportService.initQrCodeResp(*_) >> new QrCodeResp()
    }

    def "giveUpPushOrder case1: "() {
        given:
        GiveUpPushOrderReq giveUpPushOrderReq = new GiveUpPushOrderReq();
        when:
        pushOrderSupportService.giveUpPushOrder(giveUpPushOrderReq, new JSONObject())
        then:
        1 * pushOrderLogService.giveUpPushOrderLog(*_) >> true
    }
}
