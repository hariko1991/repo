package com.dashuf.dpbs.service

import com.dashuf.dpbs.mapper.PosterInfoMapper
import com.dashuf.dpbs.model.PosterInfo
import spock.lang.Specification

/**
 *
 * Created with IDEA
 * author:Likangcheng
 * Date:2019/2/27
 * Time:10:49
 *
 * */
class PosterInfoServiceTest extends Specification {

    PosterInfoMapper posterInfoMapper = Mock(PosterInfoMapper)
    PosterInfoService posterInfoService = new PosterInfoService(posterInfoMapper: posterInfoMapper)

    def "test getPosterList"() {

        when:
        posterInfoService.getPosterList()
        then:
        1 * posterInfoMapper.selectByModelSelective(*_) >> {
            List<PosterInfo> list = new ArrayList<>()
            PosterInfo posterInfo = new PosterInfo()
            list.add(posterInfo)
            return list
        }
    }
}
