package com.dashuf.dpbs.app.web

import com.dashuf.dpbs.app.web.req.user.RegReq
import com.dashuf.dpbs.app.web.resp.user.LoginResp
import com.dashuf.dpbs.service.UserInfoSupportService
import org.springframework.mock.web.MockHttpServletRequest
import org.springframework.mock.web.MockHttpServletResponse
import org.springframework.mock.web.MockHttpSession
import spock.lang.Specification

class UserRegControllerTest extends Specification {

    MockHttpServletRequest request
    MockHttpServletResponse response
    MockHttpSession session

    def setup() {
        request = new MockHttpServletRequest()
        request.setCharacterEncoding("UTF-8")
        response = new MockHttpServletResponse()
        session = new MockHttpSession()
    }

    UserInfoSupportService userInfoSupportService = Mock(UserInfoSupportService)
    UserRegController userRegController = new UserRegController(userInfoSupportService: userInfoSupportService)

    def "regUser case1:用户注册"() {
        given:
        RegReq regReq = new RegReq()
        when:
        userRegController.regUser(request, response, regReq)
        then:
        1 * userInfoSupportService.regUser(*_) >> null
    }

    def "regUser case2:用户注册"() {
        given:
        RegReq regReq = new RegReq()
        when:
        userRegController.regUser(request, response, regReq)
        then:
        1 * userInfoSupportService.regUser(*_) >> new LoginResp()
        1 * userInfoSupportService.initAccessTokenForUser(*_) >> null
    }

    def "regUser case3:用户注册"() {
        given:
        RegReq regReq = new RegReq()
        when:
        userRegController.regUser(request, response, regReq)
        then:
        1 * userInfoSupportService.regUser(*_) >> { throw new RuntimeException() }
    }
}
