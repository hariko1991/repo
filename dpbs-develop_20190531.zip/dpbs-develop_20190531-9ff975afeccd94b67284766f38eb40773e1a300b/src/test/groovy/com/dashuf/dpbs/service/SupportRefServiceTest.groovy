package com.dashuf.dpbs.service

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.app.web.req.QrOfLoanAppReq
import com.dashuf.dpbs.app.web.req.center.VerifyMobileNoReq
import com.dashuf.dpbs.app.web.req.support.GatherFormIdReq
import com.dashuf.dpbs.mapper.PushMsgFormMapper
import com.dashuf.dpbs.mapper.UserInfoMapper
import com.dashuf.dpbs.model.PushMsgForm
import com.dashuf.dpbs.model.UserInfo
import spock.lang.Specification

class SupportRefServiceTest extends Specification {

    PushMsgFormMapper pushMsgFormMapper = Mock(PushMsgFormMapper)
    UserInfoMapper userInfoMapper = Mock(UserInfoMapper)
    SupportRefService supportRefService = new SupportRefService(pushMsgFormMapper: pushMsgFormMapper, userInfoMapper: userInfoMapper)

    def "gatherFormIdForPushMsg case1: "() {
        given:
        GatherFormIdReq gatherFormIdReq = new GatherFormIdReq();
        when:
        supportRefService.gatherFormIdForPushMsg(gatherFormIdReq, new JSONObject())
        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> new UserInfo()
        1 * pushMsgFormMapper.selectOneByModelSelective(*_) >> null
    }

    def "gatherFormIdForPushMsg case2: "() {
        given:
        GatherFormIdReq gatherFormIdReq = new GatherFormIdReq();
        List<String> formIdList = new ArrayList<>();
        formIdList.add("2222")
        gatherFormIdReq.setFormIdList(formIdList)
        when:
        supportRefService.gatherFormIdForPushMsg(gatherFormIdReq, new JSONObject())
        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> new UserInfo()
        1 * pushMsgFormMapper.selectOneByModelSelective(*_) >> {
            PushMsgForm pushMsgForm = new PushMsgForm();
            pushMsgForm.setPushIndex(1)
            pushMsgForm.setFormIdOne("xxxx,xxxx")
            pushMsgForm.setUseIndex(2)
            pushMsgForm.setOpenId("XXXXX")
            return pushMsgForm
        }
        1 * pushMsgFormMapper.updatePushMsgForm(*_) >> 1
    }




    def "gatherFormIdForPushMsg case3: "() {
        given:
        GatherFormIdReq gatherFormIdReq = new GatherFormIdReq();
        List<String> formIdList = new ArrayList<>();
        formIdList.add("2222")
        gatherFormIdReq.setFormIdList(formIdList)
        when:
        supportRefService.gatherFormIdForPushMsg(gatherFormIdReq, new JSONObject())
        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> new UserInfo()
        1 * pushMsgFormMapper.selectOneByModelSelective(*_) >> {
            PushMsgForm pushMsgForm = new PushMsgForm();
            pushMsgForm.setPushIndex(1)
            pushMsgForm.setFormIdOne("xxxx,xxxx")
            pushMsgForm.setUseIndex(6)
            pushMsgForm.setPushIndex(5)
            pushMsgForm.setOpenId("XXXXX")
            return pushMsgForm
        }
    }

    def "gatherFormIdForPushMsg case4: "() {
        given:
        GatherFormIdReq gatherFormIdReq = new GatherFormIdReq();
        List<String> formIdList = new ArrayList<>();
        formIdList.add("2222")
        gatherFormIdReq.setFormIdList(formIdList)
        when:
        supportRefService.gatherFormIdForPushMsg(gatherFormIdReq, new JSONObject())
        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> new UserInfo()
        1 * pushMsgFormMapper.selectOneByModelSelective(*_) >> {
            PushMsgForm pushMsgForm = new PushMsgForm();
            pushMsgForm.setPushIndex(1)
            pushMsgForm.setFormIdOne("xxxx,xxxx")
            pushMsgForm.setUseIndex(6)
            pushMsgForm.setOpenId("XXXXX")
            return pushMsgForm
        }
        1 * pushMsgFormMapper.updatePushMsgForm(*_) >> 1
    }


    def "verifyMobileNo case1: "() {
        given:
        VerifyMobileNoReq verifyMobileNoReq = new VerifyMobileNoReq()
        verifyMobileNoReq.setVerifyType("common_verify")
        when:
        supportRefService.verifyMobileNo(verifyMobileNoReq, new JSONObject())
        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> null
    }

    def "verifyMobileNo case2: "() {
        given:
        VerifyMobileNoReq verifyMobileNoReq = new VerifyMobileNoReq()
        verifyMobileNoReq.setVerifyType(verifyType)
        when:
        supportRefService.verifyMobileNo(verifyMobileNoReq, new JSONObject())
        then:
        1 * userInfoMapper.selectQuiqueUserInfo(*_) >> new UserInfo()
        where:
        verifyType         | temp
        "user_reg"         | 1
        "modify_mobile_no" | 1
    }


}
