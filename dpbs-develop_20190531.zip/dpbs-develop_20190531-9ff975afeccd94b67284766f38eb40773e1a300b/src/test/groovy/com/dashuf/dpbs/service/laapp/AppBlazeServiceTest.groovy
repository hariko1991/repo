package com.dashuf.dpbs.service.laapp

import com.alibaba.fastjson.JSONObject
import com.dashuf.dpbs.sao.laapp.AppBlazeSAO
import com.dashuf.dpbs.sao.laapp.req.AllowPushClientReq
import com.dashuf.dpbs.sao.laapp.resp.AllowPushClientResp
import com.dashuf.merlin.web.base.views.ResponseVo
import spock.lang.Specification

class AppBlazeServiceTest extends Specification {
    AppBlazeSAO appBlazeSAO = Mock(AppBlazeSAO);
    AppBlazeService appBlazeService = new AppBlazeService(appBlazeSAO: appBlazeSAO);

    def "queyClientIsAllownPush case1: "() {
        given:
        AllowPushClientReq allowPushClientReq = new AllowPushClientReq();
        when:
        appBlazeService.queyClientIsAllownPush(allowPushClientReq, new JSONObject());
        then:
        1 * appBlazeSAO.queyClientIsAllownPush(*_) >> { return new ResponseVo<>(new AllowPushClientResp()) }
    }

    def "queyClientIsAllownPush case2: "() {
        given:
        AllowPushClientReq allowPushClientReq = new AllowPushClientReq();
        when:
        appBlazeService.queyClientIsAllownPush(allowPushClientReq, new JSONObject());
        then:
        1 * appBlazeSAO.queyClientIsAllownPush(*_) >> { return ResponseVo.fail("500") }
    }

    def "queyClientIsAllownPush case3: "() {
        given:
        AllowPushClientReq allowPushClientReq = new AllowPushClientReq();
        when:
        appBlazeService.queyClientIsAllownPush(allowPushClientReq, new JSONObject());
        then:
        1 * appBlazeSAO.queyClientIsAllownPush(*_) >> {
            return new ResponseVo<>(new AllowPushClientResp(prodectedInd: true))
        }
    }

}
