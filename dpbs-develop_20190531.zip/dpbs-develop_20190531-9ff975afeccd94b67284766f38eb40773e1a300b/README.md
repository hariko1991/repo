WX.sCorpID: ww55950ae43cfe44e7
#WX.secret: 3MZtLvZU4l1_cbktSGeKekk-ysPNdk1btMpAd5rqmd8
WX.secret: rXT7QCIjfvNQIuBpWXrGELFqHBXKqYYMg4s-_EYQaT8

##微信小程序
wx19a839ac5fa38950 
528fc517b139043f02c6d30dc319987b


##微信公众号参数 sit
weixin.appid=wx5b55de1bbb85ff1d
weixin.appSecurity=20c9d147b9ff59aa7c90c7846a47cf59



####https://www.jianshu.com/p/14eb0180f7cf



大数伙伴小程序
heyuan@dashuf.com
dashu8888


PM-REQUESTREDIRECT:url="http://10.21.0.23:8250"
DE-FrontInterface:url="http://10.21.0.23:8215"
