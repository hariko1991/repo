/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.mock.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349 
 * 
 * CreateDate: 2016年12月14日
 */
public class SleepUtils {
	private static Logger logger = LoggerFactory.getLogger(SleepUtils.class);

	
	public static void sleep(Boolean bool, Long sleep) {
		logger.info("交易过程中休息[{}],[{}]", bool, sleep);
		if(bool){
			try {
				Thread.sleep(sleep);
			} catch (InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
