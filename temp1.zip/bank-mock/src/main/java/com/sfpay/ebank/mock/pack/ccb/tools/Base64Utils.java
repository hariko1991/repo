/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.mock.pack.ccb.tools;

import com.sfpay.framework.common.util.StringUtils;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349 
 * 
 * CreateDate: 2016年10月13日
 */
@SuppressWarnings("restriction")
public class Base64Utils {
	public static String base64Encode(byte[] bstr) {
		return new sun.misc.BASE64Encoder().encode(bstr);
	}

	public static byte[] base64Decode(String str) throws Exception {
		sun.misc.BASE64Decoder decoder = new sun.misc.BASE64Decoder();

		return decoder.decodeBuffer(str);
	}

	public static byte[] addArrayAll(byte[] array1, byte[] array2) {
		if (null == array1) {
			return clone(array2);
		}
		if (null == array2) {
			return clone(array1);
		}
		byte[] joinedArray = new byte[array1.length + array2.length];
		System.arraycopy(array1, 0, joinedArray, 0, array1.length);
		System.arraycopy(array2, 0, joinedArray, array1.length, array2.length);
		return joinedArray;
	}

	private static byte[] clone(byte[] array) {
		if (array == null) {
			return null;
		}
		return (byte[]) array.clone();
	}
	
	/***
     * 为字符串填充到指定宽度，
     * padLeft("1",'0',5)返回00001
     * @param sourceStr 字符串
     * @param isLeft true:左补padChar，反之右补
     * @param padChar   字数不够，在左边填充的字符
     * @param length    指定长度
     * @return
     */
    public static String padLeftOrRight(String sourceStr, boolean isLeft, char padChar, int length) {
        if (StringUtils.isNullOrEmpty(sourceStr) || sourceStr.length() >= length) {
            return sourceStr;
        }
        else {
            StringBuffer sbRet = new StringBuffer();
            StringBuffer sb = new StringBuffer();
            int padLength = length - sourceStr.length();
            for (int i = 0; i < padLength; i++) {
                sb.append(padChar);
            }
            //---将源字符串追加在填充字符之后
            if (isLeft) {
                sbRet = sb.append(sourceStr);
            }
            else {
                sbRet = new StringBuffer().append(sourceStr).append(sb);
            }
            return sbRet.toString();
        }
    }
}
