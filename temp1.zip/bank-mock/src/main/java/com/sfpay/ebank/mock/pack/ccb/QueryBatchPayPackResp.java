package com.sfpay.ebank.mock.pack.ccb;

import java.io.File;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;

import com.sfpay.ebank.mock.util.MockStatus;
import com.sfpay.ebank.mock.util.SFTPUtils;
import com.sfpay.framework.config.properties.Property;

public class QueryBatchPayPackResp extends CCBBasePackResp {
	
	private static final String INST_GRP = "Transaction/Transaction_Body/response/INST_GRP";
	private static final String RESPONSE = "Transaction/Transaction_Body/response";
	private static final String TOTAL_REC = "Transaction/Transaction_Header/TOTAL_REC";

	String local_dir;

	@Override
	public Document readRespMockXml() throws Exception {
		String filePath = this.getRespDirPath() + "queryBatchPayResp.xml";
		return this.readXmlFile(filePath);
	}

	@Override
	@SuppressWarnings("unchecked")
	public void changeRespDetail(Document req, Document resp) throws Exception {
		this.changeRespHeadAndDetail(req, resp);
		String fileName = req.selectSingleNode(ITTPARTY_JRNL_NO).getText()+".txt";
		if(downloadFile(fileName)){
			LineIterator lineIterator = null;
			int recNum = 1;
			File file = new File(local_dir+fileName);
			try {
				lineIterator = FileUtils.lineIterator(file, "GBK");
				Node respNodeTemplet = null;
				
				List<Node> respList = resp.selectNodes(INST_GRP);

				for (Node node : respList) {
					if (respNodeTemplet == null) {
						respNodeTemplet = (Node) node.clone();
					}
					node.getParent().remove(node);
				}
				Element root = (Element) resp.selectObject(RESPONSE);
				while (lineIterator.hasNext()) {
					recNum++;
					String line = lineIterator.nextLine();
					String[] args = line.split("\\|");
					String accountNo = args[0];
					String accountName = args[1];
					String amt = args[2];
					String reqbankSn = args[3];
					String bankName = args[5];
					Node respNode = (Node) respNodeTemplet.clone();
					respNode.selectSingleNode("TrdPCt_ID_Fst_ID").setText(reqbankSn);
					respNode.selectSingleNode("TrdPCt_AccNo").setText(accountNo);
					respNode.selectSingleNode("Acc_AccNm").setText(accountName);
					respNode.selectSingleNode("Srp_Txnamt").setText(amt);
					respNode.selectSingleNode("SRP_Act_TxnAmt").setText(amt);
					respNode.selectSingleNode("IwBk_BkNm").setText(bankName);
					respNode.selectSingleNode("SCSP_Txn_StCd").setText(mockRtnStatus());
					respNode.selectSingleNode("Err_Cd").setText(mockRtnStatus());
					respNode.selectSingleNode("Err_Rsn").setText(createBankHeadRetMsg());
					
					root.add(respNode);
					if (!lineIterator.hasNext()) {
						break;
					}
					resp.selectSingleNode(TOTAL_REC).setText(String.valueOf(recNum));
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		
		}
		
	}

	/**
	 * 检查文件是否存在,存在则下载文件
	 * 方法说明：<br>
	 * 
	 * @param fileName
	 * @return
	 * @throws Exception
	 */
	protected boolean downloadFile(String fileName) throws Exception {
		String mock_sftp_ip = Property.getProperty("abc_mock_sftp_ip");
		int mock_sftp_port = Integer.parseInt(Property
				.getProperty("abc_mock_sftp_port"));
		String mock_sftp_user = Property.getProperty("abc_mock_sftp_user");
		String mock_sftp_pass = Property.getProperty("abc_mock_sftp_pass");
		String mock_sftp_dir = Property.getProperty("ccb_mock_sftp_dir");
		local_dir = Property.getProperty("ccb_mock_local_dir");
		SFTPUtils sftp = new SFTPUtils(mock_sftp_ip, mock_sftp_port,
				mock_sftp_user, mock_sftp_pass, 0);
		if (sftp.exists(mock_sftp_dir + fileName)) {
			sftp.download(mock_sftp_dir, fileName, local_dir + fileName);
			return true;
		} else {
			return false;
		}
	}
	
	public String mockRtnStatus() {
		String status = "";
		int cmd = MockStatus.getTransStatus();
		switch (cmd) {
		case MockStatus.STATUS_WAITING:
			status = "02";
			break;
		case MockStatus.STATUS_FAILURE:
			status = "04";
			break;
		default:
			status = "03";
		}
		return status;
	}
	
	
}
