/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.mock.pack.icbc;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.ebank.mock.util.SleepUtils;
import com.sfpay.ebank.mock.util.TimeFormat;
import com.sfpay.framework.common.util.StringUtils;
import com.sfpay.framework.config.properties.Property;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author sfhq1581
 * 
 *         CreateDate: 2016年11月11日
 */
public class SocketServer implements Runnable {
	private static final Logger LOGGER = LoggerFactory.getLogger(SocketServer.class);
	private Socket socket;
	private Map<String, String> transCode;

	public SocketServer(Socket socket, Map<String, String> transCode) {
		this.socket = socket;
		this.transCode = transCode;
	}

	public void run() {
		SleepUtils.sleep(Boolean.valueOf(Property.getProperty("bool")), Long.valueOf(Property.getProperty("sleep")));

		try {
			LOGGER.info("=====================================");
			int contentLength = 0;
			String resp_data = null;
			
			String rData = null;
			InputStream is = socket.getInputStream();
			byte[] buffer = new byte[102400];
			
			while(is.read(buffer) >= 0){
				String bufferStr = new String(buffer);
				LOGGER.info(bufferStr);
				/*if (bufferStr.indexOf("Content-Length") != -1) {
					contentLength = Integer.parseInt(bufferStr.substring(bufferStr.indexOf("Content-Length") + 16));
					LOGGER.info("解析socket流中报文长度" + contentLength);
				}*/
				
				if(bufferStr.contains("ersion")){
					rData = "V" + bufferStr;
					LOGGER.info("收到前置报文:{}", rData);
					break;
				}
			}
			
			
			/*BufferedReader br = new BufferedReader(new InputStreamReader(socket.getInputStream(), "GBK"));
			String line = br.readLine();
			
			while (line != null) {
				LOGGER.info(line);
				line = br.readLine();
				if ("".equals(line)) {
					break;
				} else if (line.indexOf("Content-Length") != -1) {
					contentLength = Integer.parseInt(line.substring(line.indexOf("Content-Length") + 16));
				}
			}*/
			
			
			
			/*while (line != null) {
				if (line.indexOf("Content-Length") != -1) {
					contentLength = Integer.parseInt(line.substring(line.indexOf("Content-Length") + 16));
				}
				
				LOGGER.info(line);
				
				if("".equals(line)){
					break;
				}
				line = br.readLine();
			}
			
			char[] buf = new char[contentLength];
			br.read(buf, 0, 20);
			rData = new String(buf);
			LOGGER.info("收到前置报文:{}", rData);*/

			if (rData.length() == 0) {
				resp_data = ("error:接收报文不符合工行规则");
			} else {
				// 继续读取普通post（没有附件）提交的数据
				
				
			/*	char[] buf = null;
				String rData = null;
				if (contentLength != 0) {
					buf = new char[contentLength];
					br.read(buf, 1, contentLength);
					rData = new String(buf);
					LOGGER.info("收到前置报文:{}", rData);
				}*/

				// rData = new String(buf);

				Map<String, String> map = new HashMap<String, String>();
				String transCodeStr = "";
				if (!(rData.indexOf("error") >= 0)) {
					String[] arg = rData.split("&");
					for (String str : arg) {
						String[] dt = str.split("=");
						map.put(dt[0], dt[1]);
					}
					transCodeStr = map.get("TransCode");
					LOGGER.info("交易编码TransCode:{}", transCodeStr);
					rData = map.get("reqData").replaceAll("%2F", "/").replaceAll("%2B", "+").replaceAll("%3D", "=");
					if (transCodeStr.equals("PAYENT") || transCodeStr.equals("PAYPER")) {
						rData = TimeFormat.getFromBase64(rData);
						rData = rData.substring(10, Integer.valueOf(rData.substring(0, 10)) + 10);
					} else {
						rData = TimeFormat.getFromBase64(rData);
					}
				}

				LOGGER.info("收到的拆包数据:{}", rData);
				if (transCode.containsKey(transCodeStr)) {
					ICBCBasePackResp icbcpack = (ICBCBasePackResp) Class.forName(transCode.get(transCodeStr))
							.newInstance();
					resp_data = icbcpack.createRespStr(rData);
				} else {
					resp_data = "";
				}
				if (StringUtils.isNullOrEmpty(resp_data)) {
					resp_data = ("error:工行挡板错误，请联系胜军");
				}
			}
			LOGGER.info("返回给前置报文,Base64之前：{}", resp_data);
			resp_data = TimeFormat.getBase64(resp_data);
			writeXmlToResp(resp_data);
			is.close();
			//br.close();
		} catch (Exception e) {
			LOGGER.error("工行前置异常", e);
		} finally {
			// 操作结束，关闭socket
			try {
				socket.close();
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * 方法说明：<br>
	 * 
	 * @param respBody
	 * @throws IOException
	 */
	private void writeXmlToResp(String respBody) throws IOException {
		String response = "";
		response += "HTTP/1.1 200 OK\n";
		response += "Content-Length: " + respBody.getBytes().length + "\n";
		response += "\n";
		LOGGER.info("返回response数据,：{}", response);
		LOGGER.info("返回body数据,：{}", respBody);
		OutputStream out = socket.getOutputStream();
		out.write(response.getBytes());
		out.write(respBody.getBytes());
		out.flush();
	}

}
