/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.mock.pack.abc;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.LineIterator;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.ebank.mock.util.MD5Util;
import com.sfpay.ebank.mock.util.MockStatus;
import com.sfpay.ebank.mock.util.StringFormat;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author 89003318
 * 
 *         CreateDate: 2016年12月21日
 */
public class QueryPackResp extends ABCBasePackResp {
	private static final Logger LOGGER = LoggerFactory.getLogger(QueryPackResp.class);

	@Override
	protected String handleReqDate(String req) throws Exception {
		// String transCode = req.substring(4, 8);
		String rtnBankSn = req.substring(8, 28);
		File file = new File(local_dir, rtnBankSn + ".txt");
		String fileName = FileUtils.readFileToString(file, "GBK");
		if (StringUtils.isEmpty(fileName)) {
			return "文件不存在，请联系开发";
		}
		String rcv = fileName.substring(0, fileName.lastIndexOf(".")) + ".RCV";
//		String rtnMsg = new String("挡板返回".getBytes("GBK"), "ISO_8859_1");
		String respData = new StringBuilder().append(StringFormat.formatSpace(rcv, 30, "GBK"))
				.append(StringFormat.format0Right(0, 10))
				.append(StringFormat.format0Right(0, 10))
				.append(StringFormat.format0Right(0, 18))
				.append(StringFormat.format0Right(0, 10))
				.append(StringFormat.format0Right(0, 18))
				.append(StringFormat.formatSpace("", 8, "GBK"))
				.append(StringFormat.formatSpace("", 6, "GBK"))
				.append(mockRtnFlg())
				.append(StringFormat.formatSpace("挡板返回",100, "GBK"))
				.append(StringFormat.formatSpace("",1, "GBK"))
				.toString();
		int length = StringFormat.countLength(respData,"GBK");
		String lengthStr = String.format("%04d", length); // 转成4位的字符串
		if("0000".equals(mockRtnFlg())){
			readAndWrite(fileName,rcv);
		}
		
		return lengthStr + respData;
	}

	private void readAndWrite(String src,String rcv) {
		LineIterator lineIterator = null;
		File file = new File(local_dir,src);
		File rcvFile = new File(local_dir,rcv);
		List<String> lineList = new ArrayList<String>();
		try {
			lineIterator = FileUtils.lineIterator(file, "GBK");
			String head = lineIterator.nextLine()+"0000000000|000000000000000000|000000000000000000|";
			lineList.add(head);
			while (lineIterator.hasNext()) {
				String line = lineIterator.nextLine();
				if (!lineIterator.hasNext()) {
					break;
				}
				String[] args = line.split("\\|");
				String respLine = new StringBuilder()
				.append(args[0]).append("|")
				.append(args[1]).append("|")
				.append(args[1]).append("|")
				.append(args[2]).append("|")
				.append("0").append("|")
				.append("0000").append("|")
				.append("挡板返回").append("|")
				.toString();
				lineList.add(respLine);
			}
			for(String line:lineList){
				FileUtils.write(rcvFile, line + "\n","GBK", true);
			}
			String temp = rcv.substring(0, rcv.lastIndexOf(".")) + ".txt";
			File fileTemp = new File(local_dir, temp);
			FileUtils.copyFile(rcvFile, fileTemp);
			FileUtils.write(fileTemp, md5key,"GBK", true);
			String respMd5 = MD5Util.getMD5(fileTemp).toUpperCase();
			LOGGER.info("验证md5[{}]",respMd5);
			FileUtils.write(rcvFile, respMd5,"GBK", true);
			FileUtils.deleteQuietly(fileTemp);// 删除临时文件
			checkFileExists(rcv,false);
		} catch (Exception e) {
			LOGGER.info("处理文件[{}]异常", src,e);
		} finally {
			LineIterator.closeQuietly(lineIterator);
			LOGGER.info("[文件交易内容]删除本地文件:[{}]是否成功:[{}]", file.toString(), FileUtils.deleteQuietly(rcvFile));
		}
	}

	public String mockRtnFlg() {
		String status = "";
		int abc = MockStatus.getTransStatus();
		switch (abc) {
		case MockStatus.STATUS_WAITING:
			status = "ECDB";
			break;
		case MockStatus.STATUS_FAILURE:
			status = "FFFF";
			break;
		default:
			status = "0000";
		}
		return status;
	}
}
