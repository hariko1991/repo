package com.sfpay.ebank.mock.web;

import java.io.IOException;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.ebank.mock.pack.szfs.SZFSBasePackResp;
import com.sfpay.ebank.mock.util.CertConfig;
import com.sfpay.ebank.mock.util.SleepUtils;
import com.sfpay.framework.config.properties.Property;

import szfs.tws.adapter.security.CertUtils;

/**
 * Note: 结算中心Servlet Desc: 用于处理异步模式结算中心回调的请求 Author: 725826 沈红富 Create Time:
 * 2014-12-16 下午3:19:59
 */

public class SZFSServer extends HttpServlet {

	private static Logger logger = LoggerFactory.getLogger(SZFSServer.class);

	private static final long serialVersionUID = 1L;

	private static Map<String, String> transCode = new HashMap<String, String>();

	@Override
	public void init() throws ServletException {
		super.init();
		String packageName = "com.sfpay.ebank.mock.pack.szfs.";
		transCode.put("SINGLEPAY", packageName + "TransSinglePackResp");
		transCode.put("BATCHPAY", packageName + "TransBatchPackResp");
		transCode.put("BIZTRANSQUERY", packageName + "QueryPackResp");
	}

	public SZFSServer() {

	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		resp.getWriter().append(this.getServletName()).append(" at: ").append(req.getContextPath());
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		processBiz(req, resp);
	}

	/**
	 * 处理请求，GET和POST的处理逻辑完全一致
	 * 
	 * @param req
	 * @param resp
	 * @throws ServletException
	 * @throws IOException
	 */
	@SuppressWarnings("rawtypes")
	private void processBiz(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		Enumeration nameList = req.getParameterNames();
		while (nameList.hasMoreElements()) {
			String name = (String) nameList.nextElement();
			logger.info("请求参数信息:" + name + ">>>>>" + req.getParameter(name));
		}
		req.setCharacterEncoding("UTF-8");
		
		SleepUtils.sleep(Boolean.valueOf(Property.getProperty("bool")), Long.valueOf(Property.getProperty("sleep")));
		
		String respMesg = null;
		// 接收对方的 回调各种参数
		String msgtype = req.getParameter("msgtype");
		String ziptype = req.getParameter("ziptype");
		String signature = req.getParameter("signature");
		String msgbody = req.getParameter("msgbody");
		// 先进行参数合法性检查，略
		// 检查msgtype、version、...等等和报文标准文档是否匹配得上
		if (null == msgtype || msgtype.equals("")) {
			logger.error("请求报文msgtype为空！");
			return;
		}

		// 进行验签+解密
		// 公钥文件路径
		String crtPath = CertConfig.getCertPath("szfs", Property.getProperty("szfs.crt"));
		String pfxPath = CertConfig.getCertPath("szfs", Property.getProperty("szfs.pfx"));
		String pfxPwd = Property.getProperty("szfs.pfx.pwd");

		logger.info("crtPath>>>>>{}\npfxPath>>>>>{}\npfxPwd>>>>>{}\n", new String[] { crtPath, pfxPath, pfxPwd });
		String req_xml = null;
		try {
			req_xml = CertUtils.decodePaReq(crtPath, pfxPath, pfxPwd, msgbody, signature, ziptype);
			logger.info("解密后的报文："+req_xml);
			if (transCode.containsKey(msgtype)) {
					SZFSBasePackResp packResp = (SZFSBasePackResp) Class.forName(transCode.get(msgtype)).newInstance();
					respMesg = packResp.createRespStr(req_xml);
			} else {
				logger.info("未识别的交易的报文");
			}
		} catch (Exception e) {
			logger.error("生成返回报文错误");
			logger.error("生成返回报文错误",e);;
		}
		resp.setContentType("text/xml;charset=UTF-8");
		logger.info("Server返回给对方的报文：\n" + respMesg);
		resp.getWriter().print(respMesg);
		// 如果业务处理没成功，或是该server故障无回应上面的<Result>的xml片断回结算中心，直连接口系统会认真该次回调失败，隔一段时间尝试重发，超过最大重发次数则不再继续重发
		logger.info("=====================================\n\n\n");
	}


}
