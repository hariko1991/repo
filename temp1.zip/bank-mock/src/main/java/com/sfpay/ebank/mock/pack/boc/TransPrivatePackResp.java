package com.sfpay.ebank.mock.pack.boc;

import org.dom4j.Document;
/**
 * 
 * 类说明：<br>
 * 中行对私交易
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author sfhq1581 
 * 
 * CreateDate: 2016年11月9日
 */
public class TransPrivatePackResp extends BOCBasePackResp {
	/**
	 *银行返回流水
	 */
	private static final String  OBSSID_RS = "/bocb2e/trans/trn-b2e0078-rs/b2e0078-rs/obssid";
	private static final String  INSID_RS = "/bocb2e/trans/trn-b2e0078-rs/b2e0078-rs/insid";
	/**
	 *批次reqBankSn
	 */
	private static final String  INSID_RE = "/bocb2e/trans/trn-b2e0078-rq/b2e0078-rq/insid";

	@Override
	public Document readRespMockXml() throws Exception {
		String filePath = this.getRespDirPath() + "transPrivate.xml";
		return this.readXmlFile(filePath);
	}

	@Override
	public void changeRespDetail(Document req, Document resp) throws Exception {
		String insid = req.selectSingleNode(INSID_RE).getText();
		resp.selectSingleNode(OBSSID_RS).setText("BOC" + insid);
		resp.selectSingleNode(INSID_RS).setText(insid);
	}

	@Override
	public void beforeSendResp(Document req, Document resp) throws Exception {
		String reqnbr = resp.selectSingleNode(INSID_RS).getText();
		String path = this.getReqDirPath();
		String fileName = path + reqnbr + ".xml";
		writeXmlFile(fileName, req.asXML(), "UTF-8");
	}

}
