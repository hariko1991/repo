/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.mock.pack.abc;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.RandomStringUtils;

import com.sfpay.ebank.mock.util.StringFormat;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author 89003318
 * 
 *         CreateDate: 2016年12月20日
 */
public class TransPackResp extends ABCBasePackResp {

	@Override
	protected String handleReqDate(String req) throws Exception {
		String busCode = req.substring(8, 13).trim();
		String pro = req.substring(13, 18).trim();
		String payFlag = req.substring(18, 20).trim();
		String date = req.substring(20, 28).trim();
		String time = req.substring(28, 34).trim();
		String seq = req.substring(34, 38).trim();
		// String size = req.substring(38, 48);
		// String totalNum = req.substring(48, 58);
		// String totalAmt = req.substring(58, 76);
		String rtnBankSn = RandomStringUtils.randomNumeric(20);

		// 文件名称
		String fileName = new StringBuilder().append(busCode).append("_").append(pro).append("_").append(payFlag)
				.append("_").append(date.substring(2)).append("_").append(seq).toString();

		String src = fileName + ".SRC";
		if (checkFileExists(src, true)) {
			String msg = new StringBuilder().append("0011").append(rtnBankSn).append(date).append(time)
					.append(StringFormat.formatSpace(src, 30, "GBK")).append("0000")
					.append(StringFormat.formatSpace("交易成功", 30, "GBK")).toString();
			File file = new File(local_dir, rtnBankSn + ".txt");
			FileUtils.writeStringToFile(file, src, "GBK");
			return msg;
		} else {
			return src + "在sftp不存在";
		}
	}

}
