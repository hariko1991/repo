package com.sfpay.ebank.mock.web;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sfpay.ebank.mock.util.MockStatus;

@Controller
public class ConfigController {
	private static Logger LOGGER = LoggerFactory.getLogger(ConfigController.class);

	@RequestMapping("/status")
	public String statusPage() {
		return "status";
	}

	@RequestMapping("/setStatus")
	public String setStatus(String status) {
		MockStatus.setTransStatus(status);
		LOGGER.info("当前状态" + ":" + status + ":" + MockStatus.getTransStatus());
		return "status";
	}

}
