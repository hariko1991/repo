/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.mock.pack.ccb.tools;



import java.security.Key;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.SecretKeySpec;




/**
 * 类说明：<br>
 * ：3des加密
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author sfhq813 梁承鸿
 * 
 *CreateDate: 2016-10-8
 */
public class Des3 {
	
	private static final String Algorithm = "DESede";
	private static final String DES = "DES";

	/**
	 * 方法说明：3des加密<br>
	 * 
	 * @param data
	 * @param desKey
	 * @throws Exception
	 */
	public static byte[] encryptMode(String data, byte[] desKey) throws Exception {
		Cipher c1 = Cipher.getInstance(Algorithm);
		SecretKey sk = new SecretKeySpec(desKey, Algorithm);
		c1.init(Cipher.ENCRYPT_MODE, sk);
		return c1.doFinal(data.getBytes("UTF-8"));
	}

	/**
	 * 方法说明：3des解密<br>
	 * 
	 * @param encContent
	 * @param desKey
	 * @throws Exception
	 * 
	 */
	public static byte[] decryptMode(byte[] encContent, byte[] desKey) throws Exception {
		Cipher c1 = Cipher.getInstance(Algorithm);
		SecretKey sk = new SecretKeySpec(desKey, Algorithm);
		c1.init(Cipher.DECRYPT_MODE, sk);
		return c1.doFinal(encContent);
	}

	/**
	 * 将 16 进制字符串转换成 16进制数字数组
	 *
	 * @param DEShexString DES 的明文
	 * @return byte[]
	 */
	public static byte[] asc2bin(String hexString) {
		byte[] hexbyte = hexString.getBytes();
		byte[] bitmap = new byte[hexbyte.length / 2];
		for (int i = 0; i < bitmap.length; i++) {
			hexbyte[i * 2] -= hexbyte[i * 2] > '9' ? 7 : 0;
			hexbyte[i * 2 + 1] -= hexbyte[i * 2 + 1] > '9' ? 7 : 0;
			bitmap[i] = (byte) ((hexbyte[i * 2] << 4 & 0xf0) | (hexbyte[i * 2 + 1] & 0x0f));
		}
		return bitmap;
	}

	
	/**
	 * DES算法，加密
	 * 
	 * @param data
	 *            待加密字符串
	 * @param key
	 *            加密私钥，长度不能够小于8位
	 * @return 加密后的字节数组，一般结合Base64编码使用
	 * @throws Exception
	 *             异常
	 */
	public static byte[] desEncode(byte[] data, byte[] key) throws Exception {
		DESKeySpec dks = new DESKeySpec(key);
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(DES);
		// key的长度不能够小于8位字节
		Key secretKey = keyFactory.generateSecret(dks);
		Cipher cipher = Cipher.getInstance(DES);
		cipher.init(Cipher.ENCRYPT_MODE, secretKey);
		return cipher.doFinal(data);
	}

	/**
	 * DES算法，解密
	 * 
	 * @param data
	 *            待解密字符串
	 * @param key
	 *            解密私钥，长度不能够小于8位
	 * @return 解密后的字节数组
	 * @throws Exception
	 *             异常
	 */
	public static byte[] desDecode(byte[] data, byte[] key) throws Exception {
		DESKeySpec dks = new DESKeySpec(key);
		SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(DES);
		// key的长度不能够小于8位字节
		Key secretKey = keyFactory.generateSecret(dks);
		Cipher cipher = Cipher.getInstance(DES);
		cipher.init(Cipher.DECRYPT_MODE, secretKey);
		return cipher.doFinal(data);
	}

}