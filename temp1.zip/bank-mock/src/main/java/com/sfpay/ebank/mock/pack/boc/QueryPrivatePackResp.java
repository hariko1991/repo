/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.mock.pack.boc;

import java.io.File;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;

import com.sfpay.ebank.mock.util.MockStatus;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author sfhq1581
 * 
 *         CreateDate: 2016年11月9日
 */
public class QueryPrivatePackResp extends BOCBasePackResp {

	private static final String DETAILRS = "/bocb2e/trans/trn-b2e0079-rs/b2e0079-rs";

	private static final String INSID_RQ = "/bocb2e/trans/trn-b2e0079-rq/b2e0079-rq/insid";

	private static final String DETAIL = "/bocb2e/trans/trn-b2e0078-rq/b2e0078-rq/detail";

	private static final String DETAILRS_PARENT = "/bocb2e/trans/trn-b2e0079-rs";

	@Override
	public Document readRespMockXml() throws Exception {
		String path = super.getRespDirPath() + "queryPrivate.xml";
		return super.readXmlFile(path);
	}

	@SuppressWarnings("unchecked")
	@Override
	public void changeRespDetail(Document req, Document resp) throws Exception {
		List<Node> respList = resp.selectNodes(DETAILRS);
		Node respDetailTemplet = null;
		for (Node node : respList) {
			if (respDetailTemplet == null) {
				respDetailTemplet = (Node) node.clone();
			}
			node.getParent().remove(node);
		}
		Element root = (Element) resp.selectObject(DETAILRS_PARENT);
		String reqDir = this.getReqDirPath();
		String reqnbr = req.selectSingleNode(INSID_RQ).getText();
		String filepath = reqDir + reqnbr + ".xml";
		Document orgReq = this.readXmlFile(filepath);
		List<Node> reqDetailList = orgReq.selectNodes(DETAIL);
		for (Node reqDetail : reqDetailList) {
			Node respDetail = (Node) respDetailTemplet.clone();// 响应模板
			String toactn = reqDetail.selectSingleNode("toactn").getText();
			respDetail.selectSingleNode("toactn").setText(toactn);
			String toname = reqDetail.selectSingleNode("toname").getText();
			respDetail.selectSingleNode("toname").setText(toname);
			String pydamt = reqDetail.selectSingleNode("pydamt").getText();
			respDetail.selectSingleNode("pydamt").setText(pydamt);
			respDetail.selectSingleNode("status/rspcod").setText(this.createBankRetCode());
			respDetail.selectSingleNode("status/rspmsg").setText("挡板返回");
			String reqBanksn = reqDetail.selectSingleNode("toidet").getText();
			respDetail.selectSingleNode("toidet").setText(reqBanksn);
			root.add(respDetail);
		}
		if (MockStatus.getTransStatus() != MockStatus.STATUS_WAITING) {
			new File(filepath).delete();
		}
	}

	public String createBankRetCode() {
		String status = "";
		int cmd = MockStatus.getTransStatus();
		switch (cmd) {
		case MockStatus.STATUS_WAITING:
			status = "B054";
			break;
		case MockStatus.STATUS_FAILURE:
			status = "FFFF";
			break;
		default:
			status = "B001";
		}
		return status;
	}
}
