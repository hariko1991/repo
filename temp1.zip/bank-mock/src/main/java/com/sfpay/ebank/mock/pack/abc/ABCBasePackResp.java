package com.sfpay.ebank.mock.pack.abc;

import com.sfpay.ebank.mock.util.SFTPUtils;
import com.sfpay.framework.config.properties.Property;


/**
 * 类说明：<br>
 * 招行挡板公共类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 * CreateDate: 2015年10月31日
 */
public abstract class ABCBasePackResp{
	
	protected static String abc_mock_sftp_ip;
	protected static int abc_mock_sftp_port;
	protected static String abc_mock_sftp_user;
	protected static String abc_mock_sftp_pass;
	protected static String abc_mock_sftp_dir;
	protected static String local_dir;
	protected static String md5key;
	
	

	protected abstract String handleReqDate(String req)throws Exception;
	
	public final String process(String data)throws Exception{
		initArg();
		return handleReqDate(data);
	}
	
	private void initArg(){
		abc_mock_sftp_ip = Property.getProperty("abc_mock_sftp_ip");
		abc_mock_sftp_port = Integer.parseInt(Property.getProperty("abc_mock_sftp_port"));
		abc_mock_sftp_user = Property.getProperty("abc_mock_sftp_user");
		abc_mock_sftp_pass = Property.getProperty("abc_mock_sftp_pass");
		abc_mock_sftp_dir = Property.getProperty("abc_mock_sftp_dir");
		local_dir = Property.getProperty("dir.message")+"/abc/resp/";
		md5key = Property.getProperty("md5key");
	}
	
	/**
	 * 检查文件是否存在
	 * 方法说明：<br>
	 * 
	 * @param fileName
	 * @return
	 * @throws Exception
	 */
	protected boolean checkFileExists(String fileName,boolean flag) throws Exception {
		SFTPUtils sftp = new SFTPUtils(abc_mock_sftp_ip, abc_mock_sftp_port, abc_mock_sftp_user, abc_mock_sftp_pass, 0);
		if(flag){
			if (sftp.exists(abc_mock_sftp_dir + fileName)) {
				sftp.download(abc_mock_sftp_dir, fileName, local_dir+fileName);
				return true;
			}else{
				return false;
			}
		}else{
			sftp.upload(abc_mock_sftp_dir, local_dir + fileName);
			return true;
		}
	}

}
