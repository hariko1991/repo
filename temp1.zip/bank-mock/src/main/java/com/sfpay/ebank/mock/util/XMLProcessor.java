package com.sfpay.ebank.mock.util;


import java.io.CharArrayReader;
import java.io.File;
import java.io.FileWriter;
import java.util.List;

import org.jdom.Attribute;
import org.jdom.Document;
import org.jdom.Element;
import org.jdom.input.SAXBuilder;
import org.jdom.output.Format;
import org.jdom.output.XMLOutputter;
import org.jdom.xpath.XPath;
/**
 * XML文档处理器
 * @author 725826 沈红富
 *
 */
public class XMLProcessor {
	private Document doc;

	private Element root;

	private File xmlFile;
	
	public XMLProcessor(File xmlFile) throws Exception {
		this.xmlFile = xmlFile;
		SAXBuilder builder = new SAXBuilder();
		doc = builder.build(xmlFile);
		root = doc.getRootElement();
	}

	public XMLProcessor(String xmlString) throws Exception {
		// 除掉字符串中不合法字符
		xmlString = xmlString.replaceAll("[\r\n,\r,\n]", "");

		CharArrayReader reader = new CharArrayReader(xmlString.toCharArray());
		SAXBuilder builder = new SAXBuilder();
		doc = builder.build(reader);
		root = doc.getRootElement();
	}

	/**
	 * 
	 * 方法说明：<br>
	 * 
	 * @param xPathString
	 * @param value
	 * @throws Exception
	 */
	public void setNodeText(String xPathString, String value) throws Exception {
		setNodeText(xPathString, value, false, "");
	}

	public void setNodeText(String xPathString, String value, boolean required, String requiredName)
			throws Exception {

//		if (required && B2EUtil.stringIsEmpty(value))
//			throw new Exception(requiredName + "不能为空。");

		Element element = (Element) XPath.selectSingleNode(root, xPathString);

		if (element == null)
			throw new Exception("无法设置结点值:" + xPathString + ",无此结点");

		element.setText(value == null ? "" : value);
	}

	public String getNodeText(String xPathString) throws Exception {
		Element element = (Element) XPath.selectSingleNode(root, xPathString);

		if (element == null)
			throw new Exception("无此结点:" + xPathString);

		return element.getText().trim();
	}

	public Element getRoot() {
		return root;
	}

	public void save(String filePath) throws Exception {
		File outFile = null;
		if (filePath != null) {
			outFile = new File(filePath);			
		} else
			outFile = this.xmlFile;

		FileWriter writer = new FileWriter(outFile);

		XMLOutputter out = null;
		try {
			out = new XMLOutputter();
			out.output(doc, writer);
		} finally {
			writer.close();
		}
	}

	@SuppressWarnings("unchecked")
	public List<Element> getNodes(String xPathString) throws Exception {
		return XPath.selectNodes(root, xPathString);
	}

	public Element getFirstNode(String xPathString) throws Exception {
		return (Element) XPath.selectSingleNode(root, xPathString);
	}

	public void save() throws Exception {
		this.save(null);
	}

	public void setNodeProp(String xPathString, String propName, String value) throws Exception {
		Element element = (Element) XPath.selectSingleNode(root, xPathString);
		if (element == null)
			throw new Exception("无此结点：" + xPathString);

		this.setNodeProp(element, propName, value);
	}

	public void setNodeProp(Element element, String propName, String value) throws Exception {
		Attribute attr = element.getAttribute(propName);
		if (attr == null)
			throw new Exception("无" + propName + "属性");

		element.setAttribute(propName, value);
	}

	public String getNodeProp(String xPathString, String propName) throws Exception {
		Element element = (Element) XPath.selectSingleNode(root, xPathString);
		if (element == null)
			throw new Exception("无此结点：" + xPathString);

		return this.getNodeProp(element, propName);
	}

	public String getNodeProp(Element element, String propName) throws Exception {
		Attribute attr = element.getAttribute(propName);

		if (attr == null)
			throw new Exception("无此属性：" + propName);

		return element.getAttributeValue(propName);
	}

	/*public String getDocText() {
		return getDocText(true,"");
	}
	
	public String getDocText(String encode){
		return getDocText(true,encode);
	}
	
	public String getDocText(boolean needDeclaration){
		return getDocText(needDeclaration,"");
	}

	public String getDocText(boolean needDeclaration,String encode) {
		XMLOutputter out = new XMLOutputter();
		String returnString = "";

		Format format = out.getFormat();
		

		if (needDeclaration) {
//			if ("9002".equals(Configuration.getBankID())||"9010".equals(Configuration.getBankID())){
//				format.setEncoding("GB2312");
//			}else if("9021".equals(Configuration.getBankID())){
//				format.setEncoding("UTF-8");
//			}else{
			if(B2EUtil.stringIsEmpty(encode)){
				format.setEncoding("GBK");
			}else{
				format.setEncoding(encode);
			}
//			}
			
			format.setIndent("");
			format.setLineSeparator("");
			format.setExpandEmptyElements(true);
			
			out.setFormat(format);

			returnString = out.outputString(doc);
		} else {
			returnString = out.outputString(doc);

			if (returnString.startsWith("<?xml")) {
				int pos = returnString.indexOf("?>");

				// pos + 4 是因为去掉"?>" 、回车、换行
				returnString = returnString.substring(pos + 4);
			}
		}

		return returnString;
	}*/

	public String getChildTextByKeyNode(String keyNodeXPath, String keyName, String keyValue,
			String childName) {
		String xPath = keyNodeXPath + "[child::" + keyName + "=\"" + keyValue + "\"]";
		String result = null;
		
		try {
			Element element = (Element) XPath.selectSingleNode(root, xPath);
			result = element.getChildText(childName);
		} catch (Exception e) {
			result = null;
		}

		return result;
	}
	
	public String toString() {
		String xmlFileData = new XMLOutputter().outputString(doc);
		return xmlFileData;
	}
	
	public String toString(String charSet) {
		Format format=Format.getPrettyFormat();
		format.setEncoding(charSet);
		String xmlFileData = new XMLOutputter().outputString(doc);
		return xmlFileData;
	}
	
}
