package com.sfpay.ebank.mock.util;

public class BankConstrans {
	/**
	 *工行-指令包序列号(批次请求流水号)
	 */
	public final static String ICBC_PUB_FSEQNO = "/CMS/eb/pub/fSeqno";
	/**
	 *工行-平台交易流水号
	 */
	public final static String ICBC_PUB_SERIALNO = "/CMS/eb/pub/SerialNo";
	/**
	 *工行-待查指令包序列号（批次请求流水号）
	 */
	public final static String ICBC_IN_QRYFSEQNO = "/CMS/eb/in/QryfSeqno";
	
	/**
	 *工行-输入记录数
	 */
	public final static String ICBC_IN_RD = "/CMS/eb/in/rd";
	/**
	 *工行-转出记录数
	 */
	public final static String ICBC_OUT = "/CMS/eb/out";
	/**
	 *工行-转出记录数
	 */
	public final static String ICBC_OUT_RD = "/CMS/eb/out/rd";
	/**
	 *招行-流程实例号
	 */
	public final static String ICBC_REQNBR = "REQNBR";
	
}
