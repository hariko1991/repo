/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.mock.pack.ccb;


import java.util.Date;

import org.dom4j.Document;

import com.sfpay.framework.common.util.DateUtils;



/**
 * 类说明：<br>
 * 单笔付款查询
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author sfhq813 梁承鸿
 * 
 * CreateDate: 2016-11-8
 */
public class QuerySinglePayPackResp extends CCBBasePackResp{
	
	private static final String TXN_DT = "Transaction/Transaction_Body/response/LIST1/Txn_Dt";
	private static final String TXN_TM = "Transaction/Transaction_Body/response/LIST1/Txn_Tm";
	private static final String RESP_CSTPTY_TXNSRLNO = "Transaction/Transaction_Body/response/LIST1/CstPty_TxnSrlNo";
	private static final String RESP_CSTPTY_PY_JRNL_NO = "Transaction/Transaction_Body/response/LIST1/CstPty_Py_Jrnl_No";
	private static final String CSTPTY_PY_JRNL_NO = "Transaction/Transaction_Body/request/CstPty_Py_Jrnl_No";
	private static final String PYR_ACCNM = "Transaction/Transaction_Body/request/Pyr_AccNm";
	private static final String RESP_PYR_ACCNM = "Transaction/Transaction_Body/response/LIST1/Pyr_AccNm";
	private static final String PYR_CST_ACCNO = "Transaction/Transaction_Body/request/Pyr_Cst_AccNo";
	private static final String RESP_PYR_CST_ACCNO = "Transaction/Transaction_Body/response/LIST1/Pyr_Cst_AccNo";
	private static final String HST_TXN_DT = "Transaction/Transaction_Body/response/LIST1/Hst_Txn_Dt";
	private static final String CST_DLV_DT = "Transaction/Transaction_Body/response/LIST1/Cst_Dlv_Dt";


	
	

	

	@Override
	public Document readRespMockXml() throws Exception {
		String filePath = this.getRespDirPath() + "querySinglePayResp.xml";
		return this.readXmlFile(filePath);
	}

	@Override
	public void changeRespDetail(Document req, Document resp) throws Exception {
		String curDate = DateUtils.formatDate(new Date(), "yyyyMMdd");
		this.changeRespHeadAndDetail(req, resp);
		if("1".equals(resp.selectSingleNode(RESP_RVL_RCRD_NUM).getText())){
			resp.selectSingleNode(TXN_DT).setText(curDate);
			resp.selectSingleNode(TXN_TM).setText(DateUtils.formatDate(new Date(), "HHmmss"));
			resp.selectSingleNode(RESP_CSTPTY_TXNSRLNO).setText(req.selectSingleNode(CSTPTY_PY_JRNL_NO).getText());
			resp.selectSingleNode(RESP_CSTPTY_PY_JRNL_NO).setText(req.selectSingleNode(CSTPTY_PY_JRNL_NO).getText());
			resp.selectSingleNode(RESP_PYR_ACCNM).setText(req.selectSingleNode(PYR_ACCNM).getText());
			resp.selectSingleNode(RESP_PYR_CST_ACCNO).setText(req.selectSingleNode(PYR_CST_ACCNO).getText());
			resp.selectSingleNode(HST_TXN_DT).setText(curDate);
			resp.selectSingleNode(CST_DLV_DT).setText(curDate);
		}
	}
	
}
