/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.mock.web;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.ebank.mock.pack.abc.ABCBasePackResp;
import com.sfpay.ebank.mock.util.SleepUtils;
import com.sfpay.framework.config.properties.Property;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author 89003318
 * 
 *         CreateDate: 2016年12月20日
 */
public class ABCServer extends HttpServlet {

	private static final long serialVersionUID = -8150899979077468049L;

	private static final Logger LOGGER = LoggerFactory.getLogger(ABCServer.class);
	private static Map<String, String> transCode = new HashMap<String, String>();
	private ServerSocket serverSocket;

	@Override
	public void init() throws ServletException {
		String packageName = "com.sfpay.ebank.mock.pack.abc.";
		transCode.put("PL01", packageName + "TransPackResp");// 交易
		transCode.put("PL02", packageName + "QueryPackResp");// 查询
		new Thread() {
			public void run() {
				startup();
			}
		}.start();
	}

	private void startup() {
		Socket socket = null;
		try {
			LOGGER.info("ABC构造ServerSocket实例，指定端口监听客户端,端口:[{}]",30001);
			serverSocket = new ServerSocket(30001);
			while (true) {
				try {
					// 建立跟客户端的连接
					socket = serverSocket.accept();
					SleepUtils.sleep(Boolean.valueOf(Property.getProperty("bool")),
							Long.valueOf(Property.getProperty("sleep")));
					// 接受客户端的响应
					InputStream is = socket.getInputStream();
					byte[] b = new byte[1024];
					is.read(b);
					String req = new String(b);
					LOGGER.info("ABC收到原始报文:[{}]", req);
					String tc = req.substring(4, 8);
					LOGGER.info("ABC收到transCode:[{}]", tc);
					String resp_data = null;
					for (Entry<String, String> e : transCode.entrySet()) {
						if (tc.equals(e.getKey())) {
							try {
								ABCBasePackResp abc = (ABCBasePackResp) Class.forName(e.getValue()).newInstance();
								resp_data = abc.process(req);
							} catch (Exception e1) {
								LOGGER.info("农行响应报文异常", e1);
							}
							break;
						}
					}
					if (StringUtils.isEmpty(resp_data)) {
						resp_data = "挡板有问题，请联系开发";
					}
					OutputStream os = socket.getOutputStream();
					os.write(resp_data.getBytes("GBK"));
					LOGGER.info("ABC返回报文:[{}]", new String(resp_data.getBytes("GBK")));
				} catch (Exception e) {
					LOGGER.error("socket异常", e);
				} finally {
					socket.close();
				}
			}
		} catch (IOException e) {
			LOGGER.error("serverSocket异常", e);
		} finally {
			// 操作结束，关闭socket
			try {
				serverSocket.close();
			} catch (IOException e) {
				LOGGER.error("serverSocket关闭异常", e);
			}
		}
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doGet(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		super.doPost(req, resp);
	}

	@Override
	public void destroy() {
		super.destroy();
		try {
			if(null!=serverSocket){
				serverSocket.close();
			}
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

}
