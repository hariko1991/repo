package com.sfpay.ebank.mock.pack.cmb;

import java.io.File;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;

import com.sfpay.ebank.mock.util.MockStatus;

public class QueryPrivatePackResp extends CMBBasePackResp {
	/**
	 * 流程实例号结点路径（银行返回流水）
	 */
	private static final String REQNBR = "/CMBSDKPGK/SDKATDQYX/REQNBR";

	private static final String SDKATDRQX = "/CMBSDKPGK/SDKATDRQX";

	@Override
	public Document readRespMockXml() throws Exception {
		String filePath = this.getRespDirPath() + "queryPrivate.xml";
		return this.readXmlFile(filePath);
	}

	@Override
	@SuppressWarnings("unchecked")
	public void changeRespDetail(Document req, Document resp) throws Exception {
		List<Node> respList = resp.selectNodes("/CMBSDKPGK/NTQATDQYZ");
		Node respDetailTemplet = null;
		for (Node node : respList) {
			if (respDetailTemplet == null) {
				respDetailTemplet = (Node) node.clone();
			}
			node.getParent().remove(node);
		}
		Element root = resp.getRootElement();
		String reqDir = this.getReqDirPath();
		String reqnbr = req.selectSingleNode(REQNBR).getText();
		String filepath = reqDir + reqnbr + ".xml";
		Document orgReq = this.readXmlFile(filepath);
		List<Node> reqDetailList = orgReq.selectNodes(SDKATDRQX);
		for (Node reqDetail : reqDetailList) {
			Node respDetail = (Node) respDetailTemplet.clone();
			String accnam = reqDetail.selectSingleNode("ACCNBR").getText();
			respDetail.selectSingleNode("ACCNBR").setText(accnam);
			String cltnam = reqDetail.selectSingleNode("CLTNAM").getText();
			respDetail.selectSingleNode("CLTNAM").setText(cltnam);
			String trsamt = reqDetail.selectSingleNode("TRSAMT").getText();
			respDetail.selectSingleNode("TRSAMT").setText(trsamt);
			respDetail.selectSingleNode("STSCOD").setText(this.createBankRetCode());
			
			String trsdsp = reqDetail.selectSingleNode("TRSDSP").getText();
			respDetail.selectSingleNode("TRSDSP").setText(trsdsp);
			root.add(respDetail);
		}
		if (MockStatus.getTransStatus() != MockStatus.STATUS_WAITING) {
			new File(filepath).delete();
		}
	}

	/**
	 * 方法说明：<br>
	 * 模拟工行银行返回状态
	 * 
	 * @param cmd
	 *            指定银行返回状态<br>
	 *            0:成功, 1：失败, 2:进行中
	 * 
	 * @return
	 */
	public String createBankRetCode() {
		String status = "";
		int cmd = MockStatus.getTransStatus();
		switch (cmd) {
		case MockStatus.STATUS_WAITING:
			status = "I";
			break;
		case MockStatus.STATUS_FAILURE:
			status = "F";
			break;
		default:
			status = "S";
		}
		return status;
	}

}
