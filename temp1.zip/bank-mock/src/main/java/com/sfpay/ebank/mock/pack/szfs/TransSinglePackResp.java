package com.sfpay.ebank.mock.pack.szfs;

import org.dom4j.Document;

public class TransSinglePackResp extends SZFSBasePackResp {
	@Override
	public void afterReceiveReq(Document req) throws Exception {
		String outid = req.getRootElement().element("outid").getText();
		String path = this.getReqDirPath();
		String fileName = path + outid + ".xml";
		writeXmlFile(fileName, req.asXML(), "UTF-8");
	};

	@Override
	public Document readRespMockXml() throws Exception {
		String filePath = this.getRespDirPath()+"singlePay.xml";
		return this.readXmlFile(filePath);
	}

	@Override
	public void changeRespDetail(Document req, Document resp) throws Exception {
		String outid = req.getRootElement().element("outid").getText();
		resp.getRootElement().element("outid").setText(outid);
		resp.getRootElement().element("status").setText("04");//处理中
	}
	
	

}
