package com.sfpay.ebank.mock.pack.cmb;

import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;

import com.sfpay.framework.common.util.Md5Utils;

public class TransPublicPackResp extends CMBBasePackResp {
	/**
	 *请求明细节点
	 */
	private static final String  REQ_DETAIL = "/CMBSDKPGK/DCOPDPAYX";
	
	/**
	 *流程实例号
	 */
	private static final String REQNBR = "REQNBR";
	/**
	 *响应明细节点
	 */
	private static final String  RESP_DETAIL = "/CMBSDKPGK/NTQPAYRQZ";
	/**
	 *业务参考号结点（银行流水号）
	 */
	private static final String  YURREF = "YURREF";
	
	

	@Override
	public Document readRespMockXml() throws Exception {
		String filePath = this.getRespDirPath() + "transPublic.xml";
		return this.readXmlFile(filePath);
	}

	@Override
	@SuppressWarnings("unchecked")
	public void changeRespDetail(Document req, Document resp) throws Exception {
		List<Node> outRdList = resp.selectNodes(RESP_DETAIL);
		Node detailTemplet = null;
		for (Node out : outRdList) {
			if(detailTemplet==null){
				detailTemplet=(Node) out.clone();
			}
			out.getParent().remove(out);
		}
		List<Node> reqList =   req.selectNodes(REQ_DETAIL);
		Element root = resp.getRootElement();
		Set<String> reqnbrSet = new TreeSet<String>();
		for(Node node : reqList){
			String yurref = node.selectSingleNode(YURREF).getText();
			String reqnbr = "CMB" + yurref;
			reqnbrSet.add(reqnbr);
			Node respDetail = (Node) detailTemplet.clone();
			respDetail.selectSingleNode(YURREF).setText(yurref);
			respDetail.selectSingleNode(REQNBR).setText(reqnbr);
			root.add(respDetail);
		}
		String path = this.getReqDirPath();
		String reqnbrStr =  reqnbrSet.toString();
		String reqnbr = Md5Utils.encryptMD5(reqnbrStr);
		String fileName = path + reqnbr + ".xml";
		writeXmlFile(fileName, req.asXML(), "GBK");
	}

	@Override
	public void beforeSendResp(Document req, Document resp) throws Exception {	

	}

}
