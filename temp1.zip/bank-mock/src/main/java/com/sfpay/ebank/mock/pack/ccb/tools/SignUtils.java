/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.mock.pack.ccb.tools;

import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;

/**
 * 类说明：<br>
 * 签名和校验签名
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349 
 * 
 * CreateDate: 2016年10月13日
 */
public final class SignUtils {
	/**
	 * 签名算法SHA1withRSA
	 */
	public final static String SIGN_ALGORITHM_SHA1WITHRSA = "SHA1withRSA";
	/**
	 * 签名算法MD5withRSA
	 */
	public final static String SIGN_ALGORITHM_MD5WITHRSA = "MD5withRSA";
	
	/**
	 * 方法说明：<br>
	 * 
	 * @param keyPath  私钥路径
	 * @param keyPwd   私钥密码
	 * @param signAlg  签名算法
	 * @param textByte 原始报文字节
	 * @return byte[]
	 * @throws Exception
	 */
	public static byte[] sign(String keyPath, String keyPwd, String signAlg, byte[] textByte) throws Exception {

		PrivateKey priKey = CertUtils.getPrivateKey(keyPath, keyPwd);

		return doSign(priKey, textByte, signAlg);
	}
	
	/**
	 * 方法说明：<br>
	 * 
	 * @param cerPath  公钥路径
	 * @param signAlg  签名算法
	 * @param textByte 原始报文字节
	 * @param signByte 签名字节
	 * @return boolean 校验结果
	 * @throws Exception
	 */
	public static boolean verify(String cerPath, String signAlg, byte[] textByte, byte[] signByte) throws Exception {

		PublicKey pubKey = CertUtils.getPublicKey(cerPath);

		return doVerify(pubKey, textByte, signByte, signAlg);
	}
	
	
    /**
     * 方法说明：<br>
     * 
     * @param priKey 私钥路径
     * @param textByte 原始报文字节
     * @param algorithm 签名算法
     * @return byte[]
     * @throws Exception
     */
	public static byte[] doSign(PrivateKey priKey, byte[] textByte, String algorithm) throws Exception {
		Signature sig = Signature.getInstance(algorithm);
		sig.initSign(priKey);
		sig.update(textByte);
		return sig.sign();
	}
	
	/**
	 * 方法说明：<br>
	 * 
	 * @param pubKey 公钥路径
	 * @param textByte 原始串字节
	 * @param signaByte 签名字节串
	 * @param algorithm 签名算法
	 * @return boolean  是否签名校验正确
	 * @throws Exception
	 */
	public static boolean doVerify(PublicKey pubKey, byte[] textByte, byte[] signaByte, String algorithm)
			throws Exception {
		Signature sig = Signature.getInstance(algorithm);
		sig.initVerify(pubKey);
		sig.update(textByte);
		return sig.verify(signaByte);
	}
	
}