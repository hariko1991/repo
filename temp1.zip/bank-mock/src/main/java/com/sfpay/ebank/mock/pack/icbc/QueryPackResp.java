package com.sfpay.ebank.mock.pack.icbc;

import java.io.File;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;

import com.sfpay.ebank.mock.util.BankConstrans;
import com.sfpay.ebank.mock.util.MockStatus;

/**
 * 类说明：<br>
 * 工行挡板交易查询公共类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 * CreateDate: 2015年10月31日
 */
public abstract class QueryPackResp extends ICBCBasePackResp{
	@SuppressWarnings("unchecked")
	@Override
	public void changeRespDetail(Document req, Document resp) throws Exception {
		this.changeRespHead(req, resp);
		String fSeqno = req.selectSingleNode(BankConstrans.ICBC_IN_QRYFSEQNO).getStringValue();
		resp.selectSingleNode("/CMS/eb/out/QryfSeqno").setText(fSeqno);
		resp.selectSingleNode("/CMS/eb/out/QrySerialNo").setText("CMM" + fSeqno);		
		List<Node> outRdList = resp.selectNodes(BankConstrans.ICBC_OUT_RD);
		Node rdTemplet = null;
		for (Node out : outRdList) {
			if(rdTemplet==null){
				rdTemplet=(Node) out.clone();
			}
			out.getParent().remove(out);
		}
		Element out = (Element) resp.selectSingleNode(BankConstrans.ICBC_OUT);
		String reqDir = this.getReqDirPath();
		Document orgReq = this.readXmlFile(reqDir + fSeqno + ".xml");
		List<Node> inRdList = orgReq.selectNodes(BankConstrans.ICBC_IN_RD);
		for (Node inRd : inRdList) {
			Node outRd = (Node) rdTemplet.clone();//out.addElement("rd");
			String iSeqno = inRd.selectSingleNode("iSeqno").getText();
			outRd.selectSingleNode("QryiSeqno").setText(iSeqno);
			outRd.selectSingleNode("Result").setText(createBankRetCode());
			outRd.selectSingleNode("instrRetCode").setText(iSeqno);
			outRd.selectSingleNode("instrRetMsg").setText(iSeqno);
			out.add(outRd);
		}
	}
	
	@Override
	public void beforeSendResp(Document req, Document resp) {
		if (MockStatus.getTransStatus() != MockStatus.STATUS_WAITING) {
			String fSeqno = req.selectSingleNode(BankConstrans.ICBC_IN_QRYFSEQNO).getStringValue();
			String reqDir = this.getReqDirPath();
			File reqFile = new File(reqDir + fSeqno + ".xml");
			reqFile.delete();
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 模拟工行银行返回状态
	 * 
	 * @param cmd
	 *            指定银行返回状态<br>
	 *            0:成功, 1：失败, 2:进行中
	 * 
	 * @return
	 */
	public String createBankRetCode() {
		String status = "";
		int cmd = MockStatus.getTransStatus();
		switch (cmd) {
		case MockStatus.STATUS_WAITING:
			status = "0";
			break;
		case MockStatus.STATUS_FAILURE:
			status = "6";
			break;
		default:
			status = "7";
		}
		return status;
	}
}
