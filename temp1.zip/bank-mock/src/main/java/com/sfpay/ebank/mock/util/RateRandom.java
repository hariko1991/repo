package com.sfpay.ebank.mock.util;


/** 
 * @ClassName: RateRandom 
 * @Description: JAVA 返回随机数，并根据概率、比率返回 
 * @since: TODO
 * @author 725826 沈红富   2014-12-22
 * @date 2014-12-22 上午10:49:45  
 */ 
public class RateRandom {
	/**
	 * 概率为%5
	 */
	public static double rate5 = 0.05;
	/**
	 *  概率为%90
	 */
	public static double rate90 = 0.90;
	/**
	 * 2出现的概率为%10
	 */
	public static double rate10 = 0.1;
//	/**
//	 * 3出现的概率为%0.5
//	 */
//	public static double rate3 = 0.02;
//	/**
//	 * 4出现的概率为%0.5
//	 */
//	public static double rate4 = 0.01;
//	/**
//	 * 7出现的概率为%0.5
//	 */
//	public static double rate5 = 0.01;

	/**
	 * Math.random()产生一个double型的随机数，判断一下 例如0出现的概率为%50，则介于0到0.50中间的返回0
	 * 
	 * @return int
	 * 
	 */
	public int PercentageRandomSevenSuccess() {
		double randomNumber;
		randomNumber = Math.random();
		if (randomNumber >= 0 && randomNumber <= rate5) {
			return 0;
		} else if (randomNumber >= rate5 / 100 && randomNumber <= rate5 + rate90) {
			return 7;
		} 
//		else if (randomNumber >= rate0 + rate1
//				&& randomNumber <= rate0 + rate1 + rate2) {
//			return 2;
//		} else if (randomNumber >= rate0 + rate1 + rate2
//				&& randomNumber <= rate0 + rate1 + rate2 + rate3) {
//			return 3;
//		} else if (randomNumber >= rate0 + rate1 + rate2 + rate3
//				&& randomNumber <= rate0 + rate1 + rate2 + rate3 + rate4) {
//			return 4;
//		} else if (randomNumber >= rate0 + rate1 + rate2 + rate3 + rate4
//				&& randomNumber <= rate0 + rate1 + rate2 + rate3 + rate4
//						+ rate5) {
//			return 5;
//		}
		 
		return -1;
	}

	/**
	 * Math.random()产生一个double型的随机数，判断一下 例如0出现的概率为%50，则介于0到0.50中间的返回0
	 * 
	 * @return int
	 * 
	 */
	public int PercentageRandomZeroSuccess() {
		double randomNumber;
		randomNumber = Math.random();
		if (randomNumber >= 0 && randomNumber <= rate5) {
			return 1;
		} else if (randomNumber >= rate5 / 100 && randomNumber <= rate5 + rate90) {
			return 0;
		} 
		return -1;
	}
	/**
	 * // * 测试主程序 // * @param agrs //
	 */
	// public static void main(String[] agrs)
	// {
	// int i = 0;
	// Random a = new Random();
	// for (i = 0; i <= 100; i++)//打印100个测试概率的准确性
	// {
	// System.out.println(a.PercentageRandom());
	// }
	// }
}
