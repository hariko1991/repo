package com.sfpay.ebank.mock.pack.icbc;

import org.dom4j.Document;

public class QPayentPackResp extends QueryPackResp {
	@Override
	public Document readRespMockXml() throws Exception {
		String filePath = this.getRespDirPath() + "qpayent.xml";
		return this.readXmlFile(filePath);
	}



}
