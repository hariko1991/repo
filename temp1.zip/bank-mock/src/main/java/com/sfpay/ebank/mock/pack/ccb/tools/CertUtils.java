/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.mock.pack.ccb.tools;

import java.io.FileInputStream;
import java.io.InputStream;
import java.security.KeyFactory;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.cert.Certificate;
import java.security.cert.CertificateFactory;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Enumeration;


/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349 
 * 
 * CreateDate: 2016年10月13日
 */
public final class CertUtils {
	public static final String RSA = "RSA";
	public static final String AES = "AES";
	
	/**
	 * 方法说明：<br>
	 * 获取公钥
	 * 
	 * @param certPath
	 * @return PublicKey
	 * @throws Exception
	 */
	public static PublicKey getPublicKey(String certPath) throws Exception {
		return getCert(certPath).getPublicKey();
	}

	/**
	 * 方法说明：<br>
	 * 获取私钥
	 * 
	 * @param certPath
	 * @return
	 * @throws Exception
	 */
	public static Certificate getCert(String certPath) throws Exception {
		InputStream streamCert = new FileInputStream(certPath);
		CertificateFactory factory = CertificateFactory.getInstance("X.509");
		Certificate cert = factory.generateCertificate(streamCert);

		return cert;
	}

	public static PrivateKey getPrivateKey(String keyPath, String passwd) throws Exception {
		String keySuffix = keyPath.substring(keyPath.lastIndexOf(".") + 1);

		String keyType = "JKS";
		if ((keySuffix == null) || (keySuffix.trim().equals(""))) {
			keyType = "JKS";
		} else {
			keySuffix = keySuffix.trim().toUpperCase();
		}
		if (keySuffix.equals("P12")) {
			keyType = "PKCS12";
		} else if (keySuffix.equals("PFX")) {
			keyType = "PKCS12";
		} else if (keySuffix.equals("JCK")) {
			keyType = "JCEKS";
		} else {
			keyType = "JKS";
		}
		PrivateKey fk = getPrivateKey(keyPath, passwd, keyType);
		return fk;
	}

	@SuppressWarnings("rawtypes")
	public static PrivateKey getPrivateKey(String keyPath, String passwd, String keyType) throws Exception {
		PrivateKey key = null;
		KeyStore ks = KeyStore.getInstance(keyType);
		char[] cPasswd = passwd.toCharArray();
		FileInputStream fis = null;
		try {
			fis = new FileInputStream(keyPath);
			ks.load(fis, cPasswd);
			fis.close();
		} finally {
			if (fis != null) {
				fis.close();
				fis = null;
			}
		}
		Object aliasenum = ks.aliases();
		String keyAlias = null;
		while (((Enumeration) aliasenum).hasMoreElements()) {
			keyAlias = (String) ((Enumeration) aliasenum).nextElement();
			key = (PrivateKey) ks.getKey(keyAlias, cPasswd);
			if (key != null) {
				break;
			}
		}
		return key;
	}
	
	/**
	 * 方法说明：<br>
	 * 由指定串获取publickey
	 * 
	 * <pre>
	 * KEY_PUBLIC = "MFwwDQYJKoZIhvcNAQEBBQADSwAwSAJBAIv38xXk06As11OCWq0IPQoQAmz20ZiE8T5KeaMTUbhzUkGNTAQygApua71R/INeEDNsyyQS4PT6EaWTjJop2rcCAwEAAQ==";
	 * </pre>
	 * 
	 * @param pubKey
	 * @param alg
	 * @return PublicKey
	 * @throws Exception
	 */
	public static PublicKey getPubKey(String pubKey, String alg) throws Exception {
		X509EncodedKeySpec keySpec = new X509EncodedKeySpec(Base64Utils.base64Decode(pubKey));
		PublicKey publicKey = KeyFactory.getInstance(alg).generatePublic(keySpec);

		return publicKey;
	}
	
	/**
	 * 方法说明：<br>
	 * 
	 * <pre>
	 * KEY_PRIVATE = "MIIBVAIBADANBgkqhkiG9w0BAQEFAASCAT4wggE6AgEAAkEAi/fzFeTToCzXU4JarQg9ChACbPbRmITxPkp5oxNRuHNSQY1MBDKACm5rvVH8g14QM2zLJBLg9PoRpZOMminatwIDAQABAkBqDAR7FBJbC15hgSQecV194D9WO3L18dOt9FNQgPSroGVYIvIizp1/wIHpMTN6uHwSoaZQcOqV33gxLF6fKbwxAiEAv390Q3X2cBjeScxhNbqPiOspE9rYD3eWSajN6Q7ud7UCIQC7HTUZelHMCpv4xPzg6e1QZkWhBfuqkhg9aOeAnIW0OwIgLW5Tat3FhXqg4ek29sQ34UfJCwjUUXcRlJATqcL9GDECIQChqe+JzrxDbVsrCY9vB83JLEO2hwPUcJtO24dBAHsopwIgEV547YcgZ+pyI1dnQhiLJiiFif+h1aBzaIH5mrkshtw=";
	 * </pre>
	 * 
	 * @param key
	 * @return PrivateKey
	 * @throws Exception
	 */
	public static PrivateKey getPriKey(String priKey, String alg) throws Exception {
		PKCS8EncodedKeySpec keySpec = new PKCS8EncodedKeySpec(Base64Utils.base64Decode(priKey));
		PrivateKey privateKey = KeyFactory.getInstance(alg).generatePrivate(keySpec);
		return privateKey;
	}
	
}
