/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.mock.pack.ccb.tools;

import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Security;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;

import org.bouncycastle.util.encoders.Base64;

/**
 * 类说明：<br>
 * 建行公共服务类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349 
 * 
 * CreateDate: 2016年10月24日
 */
public final class CCBUtil {
	private static final String RSA = "RSA";
	private static final String BC = "BC";
	static {
		Security.addProvider(new org.bouncycastle.jce.provider.BouncyCastleProvider());
	}
	/**
	 * 方法说明：<br>
	 * 获取指定私钥
	 * 
	 * @param priKeyStr
	 * @return PrivateKey
	 * @throws Exception
	 */
	public static PrivateKey getPriKey(String priKeyStr) throws Exception {
		PKCS8EncodedKeySpec priPKCS8 = new PKCS8EncodedKeySpec(Base64.decode(priKeyStr));

		KeyFactory keyFactory = KeyFactory.getInstance(RSA, BC);
		return keyFactory.generatePrivate(priPKCS8);
	}
	
	/**
	 * 方法说明：<br>
	 * 获取公钥
	 * 
	 * @param pubKeyByte
	 * @return PublicKey
	 * @throws Exception
	 */
	public static PublicKey getPubKey(byte[] pubKeyByte) throws Exception {
		X509EncodedKeySpec pubX509 = new X509EncodedKeySpec(pubKeyByte);
		KeyFactory keyFactory = KeyFactory.getInstance(RSA, BC);
		return keyFactory.generatePublic(pubX509);
	}
	
	

}
