package com.sfpay.ebank.mock.web;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.ebank.mock.pack.cmb.CMBBasePackResp;
import com.sfpay.ebank.mock.util.SleepUtils;
import com.sfpay.framework.common.util.StringUtils;
import com.sfpay.framework.config.properties.Property;

/**
 * Servlet implementation class CMBservice
 */
public class CMBServer extends HttpServlet {
	private static Logger logger = LoggerFactory.getLogger(CMBServer.class);
	private static final long serialVersionUID = 1L;
	private static Map<String, String> transCode = new HashMap<String, String>();

	@Override
	public void init() throws ServletException {
		super.init();
		String packageName = "com.sfpay.ebank.mock.pack.cmb.";
		transCode.put("SDKPAYRQX", packageName + "TransPublicPackResp");// 3.6
		transCode.put("NTSTLINFX", packageName + "QueryPublicPackResp");// 3.9
		transCode.put("SDKATSRQX", packageName + "TransPrivatePackResp");// 4.2
		transCode.put("SDKATDQYX", packageName + "QueryPrivatePackResp");// 4.4
	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CMBServer() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append(this.getServletName()).append(" at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		BufferedReader reader = null;
		String rData = null;
		
		SleepUtils.sleep(Boolean.valueOf(Property.getProperty("bool")), Long.valueOf(Property.getProperty("sleep")));
		
		try {
			reader = new BufferedReader(new InputStreamReader(request.getInputStream(), "GBK"));

			StringBuffer receiveData = new StringBuffer();
			// 分段收取
			String line = null;
			while ((line = reader.readLine()) != null) {
				receiveData.append(line);
			}
			rData = receiveData.toString();
			logger.info("收到的原始数据：" + rData);
		} catch (Exception e) {
			logger.info("数据接收错误。" + e.getMessage());
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (Exception e) {
					logger.info("关闭接收流错误。" + e.getMessage());
				}
			}
		}
		String resp_data = null;

		for (Entry<String, String> e : transCode.entrySet()) {
			// conn.setRequestProperty(e.getKey(), e.getValue());
			int idx = rData.indexOf(e.getKey());
			if (idx >= 0) {
				try {
					CMBBasePackResp cmb = (CMBBasePackResp) Class.forName(e.getValue()).newInstance();
					resp_data = cmb.createRespStr(rData);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
				break;
			}
		}

		if (StringUtils.isNullOrEmpty(resp_data)) {
			resp_data = failXml();
		}

		response.setCharacterEncoding("GBK");
		PrintWriter pw = response.getWriter();
		pw.write(resp_data);
		pw.flush();
		logger.info("返回的报文："+resp_data);
		logger.info("=====================================\n\n\n");
		pw.close();

	}

	private String failXml() {
		String str = "<?xml version=\"1.0\" encoding=\"GBK\"?>" + "<CMBSDKPGK>" + "<INFO>" + "<DATTYP>2</DATTYP>"
				+ "<ERRMSG>招行挡板有误，请联系开发</ERRMSG>" + "<RETCOD>-9</RETCOD>" + "</INFO>" + "</CMBSDKPGK>";
		logger.info("招行返回报文：" + str);
		return str;
	}
}
