package com.sfpay.ebank.mock.util;

import java.io.UnsupportedEncodingException;
import java.text.SimpleDateFormat;
import java.util.Date;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

/**
 * @ClassName: TimeFormat
 * @Description: 根据指定的格式将当前时间返回字符串
 * @since: TODO
 * @author 725826 沈红富 2014-12-22
 * @date 2014-12-22 上午10:50:05
 */
@SuppressWarnings("restriction")
public class TimeFormat {

	static SimpleDateFormat miliSecondComma = new SimpleDateFormat(
			"yyyyMMdd HH:mm:ss:SSS");
	static SimpleDateFormat timeSecond = new SimpleDateFormat("yyyyMMddHHmmss");
	static SimpleDateFormat miliSecondStraith = new SimpleDateFormat(
			"HHmmssSSSSSS");
	static SimpleDateFormat miliSecond = new SimpleDateFormat(
			"MMddHHmmssSSS");
	// static SimpleDateFormat timeHISDTL = new
	// SimpleDateFormat("yyyy-MM-dd-HH:mm:ss.SSSSSS");

	// 2014-05-27-15.26.44.920571
	static SimpleDateFormat timeHISDTL = new SimpleDateFormat(
			"yyyy-MM-dd-HH:mm:ss.SSSSSS");
	static long TweentyMinute = 25 * 60 * 1000;

	public static String getSequenceAccountNumber() {
		Date d = new Date();
		String str = miliSecond.format(d);
		String haomiao = String.valueOf(System.nanoTime());
		str = str + haomiao.substring(haomiao.length() - 6, haomiao.length());
		return str;
	}

	public static String getCurrentTimeMillis(long t1) {

		return miliSecondComma.format(new Date(t1));
	}

	public static String getCurrentTimeSecond() {

		return timeSecond.format(new Date(System.currentTimeMillis()));
	}

	public static String getHISDTLtime() {

		return timeHISDTL.format(new Date(System.currentTimeMillis()));
	}

	public static String getHISDTLtime(long t1) {

		return timeHISDTL.format(new Date(t1));
	}

	public static String getCurrentTimeSecond(long t1) {

		return timeSecond.format(new Date(t1));
	}

	// 加密
	public static String getBase64(String str) {
		byte[] b = null;
		String s = null;
		try {
			b = str.getBytes("GBK");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		if (b != null) {
			s = new BASE64Encoder().encode(b);
		}
		return s;
	}

	// 解密
	public static String getFromBase64(String s) {
		byte[] b = null;
		String result = null;
		if (s != null) {
			BASE64Decoder decoder = new BASE64Decoder();
			try {
				b = decoder.decodeBuffer(s);
				result = new String(b, "GBK");
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}
}
