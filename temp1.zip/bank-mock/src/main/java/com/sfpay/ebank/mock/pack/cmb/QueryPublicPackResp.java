package com.sfpay.ebank.mock.pack.cmb;

import java.io.File;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;

import com.sfpay.ebank.mock.util.MockStatus;
import com.sfpay.framework.common.util.Md5Utils;

public class QueryPublicPackResp extends CMBBasePackResp {
	/**
	 * 请求明细节点
	 */
	private static final String ORG_REQ_DETAIL = "/CMBSDKPGK/DCOPDPAYX";

	/**
	 * 流程实例号
	 */
	private static final String REQNBR = "REQNBR";
	/**
	 * 响应明细节点
	 */
	private static final String RESP_DETAIL = "/CMBSDKPGK/NTQPAYQYZ";
	/**
	 * 业务参考号结点（银行流水号）
	 */
	private static final String YURREF = "YURREF";

	@Override
	public Document readRespMockXml() throws Exception {
		String filePath = this.getRespDirPath() + "queryPublic.xml";
		return this.readXmlFile(filePath);
	}

	@Override
	@SuppressWarnings("unchecked")
	public void changeRespDetail(Document req, Document resp) throws Exception {
		List<Node> respList = resp.selectNodes(RESP_DETAIL);
		Node respNodeTemplet = null;
		for (Node node : respList) {
			if (respNodeTemplet == null) {
				respNodeTemplet = (Node) node.clone();
			}
			node.getParent().remove(node);
		}
		Set<String> reqnbrSet = new TreeSet<String>();
		List<Node> reqList = req.selectNodes("/CMBSDKPGK/NTSTLINFX");
		for (Node note : reqList) {
			reqnbrSet.add(note.selectSingleNode(REQNBR).getText());
		}
		String reqnbr = Md5Utils.encryptMD5(reqnbrSet.toString());
		String reqDir = this.getReqDirPath();
		String filepath = reqDir + reqnbr + ".xml";
		Document orgReq = this.readXmlFile(filepath);
		List<Node> orgList = orgReq.selectNodes(ORG_REQ_DETAIL);
		Element root = resp.getRootElement();
		for (Node reqNode : orgList) {
			Node respNode = (Node) respNodeTemplet.clone();
			String yurref = reqNode.selectSingleNode(YURREF).getText();
			respNode.selectSingleNode(YURREF).setText(yurref);
			respNode.selectSingleNode("REQSTS").setText(this.createBankRetCode());
			respNode.selectSingleNode("RTNFLG").setText(this.mockRtnFlg());
			root.add(respNode);
		}
		if (MockStatus.getTransStatus() != MockStatus.STATUS_WAITING) {
			new File(filepath).delete();
		}
	}

	/**
	 * 方法说明：<br>
	 * 模拟工行银行返回状态
	 * 
	 * @param cmd
	 *            指定银行返回状态<br>
	 *            0:成功, 1：失败, 2:进行中
	 * 
	 * @return
	 */
	public String createBankRetCode() {
		String status = "";
		int cmd = MockStatus.getTransStatus();
		switch (cmd) {
		case MockStatus.STATUS_WAITING:
			status = "BNK";
			break;
		default:
			status = "FIN";
		}
		return status;
	}

	/**
	 * 方法说明：<br>
	 * 模拟工行银行返回状态
	 * 
	 * @param cmd
	 *            指定银行返回状态<br>
	 *            0:成功, 1：失败, 2:进行中
	 * 
	 * @return
	 */
	public String mockRtnFlg() {
		String status = "";
		int cmd = MockStatus.getTransStatus();
		switch (cmd) {
		case MockStatus.STATUS_WAITING:
			status = "";
			break;
		case MockStatus.STATUS_FAILURE:
			status = "F";
			break;
		default:
			status = "S";
		}
		return status;
	}

}
