/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.mock.util;

import org.apache.commons.lang3.StringUtils;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author sfhq1581 
 * 
 * CreateDate: 2016年9月26日
 */
public class StringFormat {
	
	
	
	
	/** 
     * 格式化输出 字符串  
     * [*]左对齐,右补空格 
     *  
     * @param str 
     * @param length : 输出长度 
     * @return 
     * @throws UnsupportedEncodingCnstException 
     */  
    public static String formatSpace(String str, int length,String encode) throws Exception {
    	String param = "";
    	if(StringUtils.isNotEmpty(str)){
    		param = str;
    	}
    	//参数转为ISO_8859_1编码，中文占2个字节
		byte[] buff = param.getBytes(encode);  
		String tmp = new String(buff,"ISO_8859_1");
		//判断参数超长
    	if(tmp.length() > length){
    		StringBuilder sb = new StringBuilder();
    		sb.append("参数值[").append(str).append("]超过标准长度[").append(length).append("]!");
    		throw new Exception(sb.toString());
    	}
    	
        String format = "%-" + (length < 1 ? 1 : length) + "s";
        String formatedStr = String.format(format, tmp);
        //从ISO_8859_1转回GBK
        return new String(formatedStr.getBytes("ISO_8859_1"),encode);
    }
    
    /** 
     * 格式化输出 整数  
     * [*]右对齐,左补0 
     *  
     * @param num 
     * @param length : 输出长度 
     * @return 
     * @throws Exception 
     */  
    public static String format0Right(long num, int length) throws Exception {
		//判断参数超长
    	if(String.valueOf(num).length() > length){
    		StringBuilder sb = new StringBuilder();
    		sb.append("参数值[").append(num).append("]超过标准长度[").append(length).append("]!");
    		throw new Exception(sb.toString());
    	}
    	
        String format = "%0" + (length < 1 ? 1 : length) + "d";
        return String.format(format, num);
    }
  
    /** 
     * 格式化输出 浮点数 
     * [*]右对齐,左补0 
     *  
     * @param d 
     * @param minLength : 最小输出长度 
     * @param precision : 小数点后保留位数 
     * @return 
     */  
    public static String format0Right(double d, int minLength, int precision) {  
        String format = "%0" + (minLength < 1 ? 1 : minLength) + "."  
                + (precision < 0 ? 0 : precision) + "f";  
        return String.format(format, d);  
    }  
    
	/**
	 * 
	 * 方法说明：<br>
	 * 去除左边为0
	 * @param str
	 * @return
	 */
    public static String clear0Left(String str){
    	if(StringUtils.isEmpty(str)){
    		return null;
    	}
    	char[] cs = str.toCharArray();
    	int i = 0;
    	for(char c:cs){
    		if("0".equals(String.valueOf(c))){
    			i++;
    			continue;
    		}
    		break;
    	}
    	return str.substring(i);
    }
    
	
    /** 
     * 先转为ISO_8859_1编码格式，再字符串计算长度
     *  
     * @param str 
     * @return 
     */  
	public static int countLength(String str,String encode) throws Exception{
		byte[] buff = str.getBytes(encode);  
		String encodedStr = new String(buff,"ISO_8859_1");
		return encodedStr.length();
	}
}
