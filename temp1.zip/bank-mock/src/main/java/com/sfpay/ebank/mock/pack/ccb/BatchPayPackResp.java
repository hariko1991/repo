/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.mock.pack.ccb;


import org.dom4j.Document;



/**
 * 类说明：<br>
 * 批量付款
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author sfhq813 梁承鸿
 * 
 * CreateDate: 2016-11-8
 */
public class BatchPayPackResp extends CCBBasePackResp{
	
	private static final String BTCH_ID = "Transaction/Transaction_Body/response/Btch_ID";

	
	@Override
	public Document readRespMockXml() throws Exception {
		String filePath = this.getRespDirPath() + "batchPayResp.xml";
		return this.readXmlFile(filePath);
	}

	@Override
	public void changeRespDetail(Document req, Document resp) throws Exception {
		this.changeRespHeadAndDetail(req, resp);
		resp.selectSingleNode(BTCH_ID).setText(req.selectSingleNode(ITTPARTY_JRNL_NO).getText());
	}
	
}
