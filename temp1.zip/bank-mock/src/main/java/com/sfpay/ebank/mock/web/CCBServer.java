package com.sfpay.ebank.mock.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.ebank.mock.pack.ccb.CCBBasePackResp;
import com.sfpay.ebank.mock.pack.ccb.tools.Base64Utils;
import com.sfpay.ebank.mock.pack.ccb.tools.CCBUtil;
import com.sfpay.ebank.mock.pack.ccb.tools.Des3;
import com.sfpay.ebank.mock.pack.ccb.tools.SignUtils;
import com.sfpay.framework.common.util.StringUtils;

/**
 * Servlet implementation class CCBServer
 */
public class CCBServer extends HttpServlet {
	private static final long serialVersionUID = -3169775951665948516L;
	private static Logger logger = LoggerFactory.getLogger(CCBServer.class);
	private static Map<String, String> transCode = new HashMap<String, String>();
	private static final int XML_DEF_LEN = 10;// 报文默认长度10位
	private static final char XML_PADDING = '0';// 填充值
	private static final String DES_KEY = "73zm1ms9EJF677adVBCoKe985tZrPRCR";
	private static final String PRI_KEY = "MIICeQIBADANBgkqhkiG9w0BAQEFAASCAmMwggJfAgEAAoGBAJZDMiXJUeS7oKeIVmrw7vAIPACq5m2VDCFnp1M+YR9cbmYthJt0WSD9GM24vfmETJfF+WtoaL6qyySLOag1ZRUK+N/Rgig2sEF9Y3quyJ8o4pKkTOaDTcZ42aE+kK4nLcAOU+ZcEFt8nxvhXleMOcRqZiZkXiYWNuZe+3NJFDOrAgMBAAECgYEAlVFe8ue0xoyg3/p+jbSwa7xzC+LIKtry+/sJ7pHNZ6GtX0IaRXR/4WVBEaVkux/6ENQ9v7s4Y0hLqBvmBr5Qm+vHP4RGgQHlkNCwE5kG7ybbhLwFcwb84BNk1VF5cfNB9vzQxIUebCIUFfsdp9ODrVlSpD1VQaQvV7eQoyDxWBkCQQDENABxMKo7A/0vGiaHKgXKAkKfdHUL2CzQA17tjlHRdCu2SwwJQSzSxKxU7BglFewMA3n9cjXvRtjtcrJTPRlFAkEAxA7Z2ey05G1fnuLWUn7nTjThMmJe2yS8xfETqMuI441dHJSla/2rCwo/P7NmDwfindaN4fL1cwAvcTXhNwtQLwJBAKzDzY/d9ke5H3wWXs6uJiLXEqst9NLVK8CO90vfAhSZYtRGCPctOLbvD4BH1IrzXsLFXOnbY7qqe+G6GWRKbLECQQCOir2Y06Aw89QxkHqCQAGruoaAO0T7zxnwT/YbIt/DkWPBA9HBUgypWiniBmyNQQ5h8zv0qtAJbHkRtjqn6nHBAkEAgYkQ+o2ZVTnY6WzeuFq2UkToFRg1wKUxGqDJm402jRvsEHth02c4Gk/389GSPRXpOiKXFTqrwxuzRjZCPOhNmQ==";
	private static final String CHANL_CUST_NO_KEY = "chanl_cust_no";
	private static final String CHANL_CUST_NO_VAL = "SZ44030110533173002";
	private static final String XML = "xml";
	private static final String SIGNATURE ="signature";
	private static final String ENCODING_UTF_8= "UTF-8";
	

	@Override
	public void init() throws ServletException {
		super.init();
		String packageName = "com.sfpay.ebank.mock.pack.ccb.";
		transCode.put("P1CMSET35", packageName + "SinglePayPackResp");
		transCode.put("P1CMSET36", packageName + "QuerySinglePayPackResp");
		transCode.put("P1OPME001", packageName + "SignPackResp");
		transCode.put("P1CMSTP20", packageName + "BatchPayPackResp");
		transCode.put("P1CMSTP22", packageName + "QueryBatchPayPackResp");

	}

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public CCBServer() {
		super();
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append(this.getServletName()).append(" at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
 throws ServletException, IOException {
//		Enumeration nameList = request.getParameterNames();
//		while (nameList.hasMoreElements()) {
//			String name = (String) nameList.nextElement();
//			logger.info("请求参数信息:" + name + ">>>>>" + request.getParameter(name));
//		}
		request.setCharacterEncoding(ENCODING_UTF_8);
		// 接收对方的 回调各种参数
		String chanlCustNo = request.getParameter(CHANL_CUST_NO_KEY);
		String reqXml = request.getParameter(XML);
		String signature = request.getParameter(SIGNATURE);
		String fileName = request.getParameter("filename");
		if (!StringUtils.isNullOrEmpty(fileName)) {//批量付款申请
			try {
				// 解密
				byte[] reqByte = Des3.decryptMode(
						Base64Utils.base64Decode(fileName),
						Base64Utils.base64Decode(DES_KEY));
				String respData =  "SUCCESS" + "|"+new String(reqByte, ENCODING_UTF_8);
				buildRespInfo(response, respData);
				return;
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	
//		SleepUtils.sleep(Boolean.valueOf(Property.getProperty("bool")), Long.valueOf(Property.getProperty("sleep")));
		
		// 先进行参数合法性检查
		if (!chanlCustNo.equals(CHANL_CUST_NO_VAL)) {
			logger.error("请求电子合约编号错误");
			return;
		} else if (StringUtils.isNullOrEmpty(signature)) {
			logger.error("请求签名为空");
			return;
		} else if (StringUtils.isNullOrEmpty(reqXml)&& StringUtils.isNullOrEmpty(fileName)) {
			logger.error("请求报文reqXml为空");
			return;
		}
		String reqXmlStr = null;
		try {
			byte[] reqXmlByte = Des3.decryptMode(Base64Utils.base64Decode(reqXml),
					Base64Utils.base64Decode(DES_KEY));
			// 解密
			reqXmlStr = new String(reqXmlByte,ENCODING_UTF_8);
			logger.info("解密后请求报文：" + reqXmlStr);
			String resp_data = null;
			for (Entry<String, String> e : transCode.entrySet()) {
				int idx = reqXmlStr.indexOf(e.getKey());
				if (idx >= 0) {
					CCBBasePackResp ccb = (CCBBasePackResp) Class.forName(
							e.getValue()).newInstance();
					resp_data = ccb.createRespStr(reqXmlStr);
					buildRespInfo(response, resp_data);
					break;
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	/**
	 * 方法说明：<br>
	 * 
	 * @param response
	 * @param respData
	 * @throws Exception
	 */
	private void buildRespInfo(HttpServletResponse response, String respData)
			throws Exception {
		logger.info("加密前响应报文：" + respData);
		// 签名
		byte[] sign = SignUtils.doSign(CCBUtil.getPriKey(PRI_KEY),
				respData.getBytes(ENCODING_UTF_8),
				SignUtils.SIGN_ALGORITHM_MD5WITHRSA);
		String dataPre = Base64Utils.padLeftOrRight(sign.length + "",
				true, XML_PADDING, XML_DEF_LEN);
		// 加密
		byte[] encodeData = Des3.encryptMode(respData,
				Base64Utils.base64Decode(DES_KEY));
		byte[] byte_3 = new byte[10 + sign.length + encodeData.length];
		System.arraycopy(dataPre.getBytes(), 0, byte_3, 0,
				dataPre.getBytes().length);
		System.arraycopy(sign, 0, byte_3, dataPre.getBytes().length,
				sign.length);
		System.arraycopy(encodeData, 0, byte_3, dataPre.getBytes().length
				+ sign.length, encodeData.length);
		response.setCharacterEncoding(ENCODING_UTF_8);
		response.getOutputStream().write(byte_3);
	}
	
}
