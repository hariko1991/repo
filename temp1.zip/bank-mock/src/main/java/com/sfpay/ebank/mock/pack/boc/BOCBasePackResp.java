package com.sfpay.ebank.mock.pack.boc;

import com.sfpay.ebank.mock.pack.XmlPackResp;

/**
 * 类说明：<br>
 * 招行挡板公共类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 * CreateDate: 2015年10月31日
 */
public abstract class BOCBasePackResp extends XmlPackResp{

	@Override
	public String initBankCode() {
		return "boc";
	}


}
