package com.sfpay.ebank.mock.pack.icbc;

import org.dom4j.Document;

import com.sfpay.ebank.mock.util.BankConstrans;

/**
 * 类说明：<br>
 * 工行档板交易请求公共类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 * CreateDate: 2015年10月31日
 */
public abstract class TransPackResp extends ICBCBasePackResp{
	@Override
	public void afterReceiveReq(Document req) throws Exception {
		String fSeqno = req.selectSingleNode(BankConstrans.ICBC_PUB_FSEQNO).getStringValue();
		String path = this.getReqDirPath();
		String fileName = path + fSeqno + ".xml";
		writeXmlFile(fileName, req.asXML(), "GBK");
	}
	
	@Override
	public void changeRespDetail(Document req, Document resp) throws Exception {
		this.changeRespHead(req, resp);
	}
}
