package com.sfpay.ebank.mock.util;

import java.io.InputStream;
import java.util.Properties;

public class MockStatus {
	
	
	private static final String FILENAME = "properties/status.properties" ;
	
	/**
	 *交易成功CMD
	 */
	public static final int STATUS_SUCCESS = 0;
	/**
	 *交易失败CMD
	 */
	public static final int STATUS_FAILURE = 1;
	/**
	 *交易进行中CMD
	 */
	public static final int STATUS_WAITING = 2;
	
	private static Integer curStatus = Integer.valueOf(-1);
	
	public static int  getTransStatus(){
		if(curStatus==null){
			synchronized (curStatus) {
			 	curStatus = initStatus();
			}
		}
		switch(curStatus){
		case STATUS_SUCCESS:
		case STATUS_FAILURE:
			return curStatus;		
		default :
			return STATUS_WAITING;
		}
	}
	
	public static void setTransStatus(String status){
		int res;
		if("SUCCESS".equals(status)){
			res= 	STATUS_SUCCESS;
		}else if("FAILURE".equals(status)){
			res= 	STATUS_FAILURE;
		}else {
			res= 	STATUS_WAITING;
		}
		synchronized (curStatus) {
		 	curStatus = res;
		}	
	}
	
	private static int initStatus(){
		int res = STATUS_SUCCESS;
		try {
			InputStream in = CertConfig.class.getClassLoader().getResourceAsStream(FILENAME);
			Properties prop = new Properties();
			prop.load(in);
			String cmdStatus = prop.getProperty("CMD_STATUS");
			if("SUCCESS".equals(cmdStatus)){
				res= 	STATUS_SUCCESS;
			}else if("FAILURE".equals(cmdStatus)){
				res= 	STATUS_FAILURE;
			}else {
				res= 	STATUS_WAITING;
			}
		} catch (Exception e) {
		}
		return res;
	}
	
	
	
}
