package com.sfpay.ebank.mock.pack.icbc;

import org.dom4j.Document;

public class PayperPackResp extends TransPackResp {

	
	@Override
	public Document readRespMockXml() throws Exception{	
		String filePath = this.getRespDirPath()+"payper.xml";
		return this.readXmlFile(filePath);
	}



}
