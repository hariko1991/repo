package com.sfpay.ebank.mock.web;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.net.ssl.KeyManagerFactory;
import javax.net.ssl.SSLContext;
import javax.net.ssl.SSLServerSocket;
import javax.net.ssl.SSLServerSocketFactory;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.ebank.mock.pack.icbc.SocketServer;
import com.sfpay.framework.config.properties.Property;

public class ICBCServer extends HttpServlet {
	private static final Logger LOGGER = LoggerFactory.getLogger(ICBCServer.class);
	private static final long serialVersionUID = 1L;
	private static Map<String, String> transCode = new HashMap<String, String>();
	private static ExecutorService executor = Executors.newCachedThreadPool();
	private SSLServerSocket server;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public ICBCServer() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	public void init() throws ServletException {
		String packageName = "com.sfpay.ebank.mock.pack.icbc.";
		transCode.put("PAYENT", packageName + "PayentPackResp");
		transCode.put("PAYPER", packageName + "PayperPackResp");
		transCode.put("QPAYPER", packageName + "QPayperPackResp");
		transCode.put("QPAYENT", packageName + "QPayentPackResp");
		new Thread() {
			public void run() {
				startup();
			}
		}.start();
	}

	public void startup() {
		LOGGER.info("=================Socket begin=================");
		// key store相关信息
		try {
			String path = Property.getProperty("dir.cert");
			String keyName = path + "sfkeystore";
			char[] keyPwd = "12345678".toCharArray();
			// 访问Java密钥库，JKS是keytool创建的Java密钥库，保存密钥。 KeyStore.getDefaultType()
			KeyStore keyStore = KeyStore.getInstance("JKS");
			// 装载当前目录下的key store. 可用jdk中的keytool工具生成keystore
			InputStream in = new FileInputStream(keyName);
			keyStore.load(in, keyPwd);
			in.close();
			// 初始化key manager factory 创建用于管理JKS密钥库的X.509密钥管理器。 "SunX509"
			KeyManagerFactory kmf = KeyManagerFactory.getInstance(KeyManagerFactory.getDefaultAlgorithm());
			kmf.init(keyStore, keyPwd);
			// 初始化ssl context
			X509TrustManager x509m = new X509TrustManager() {
				@Override
				public X509Certificate[] getAcceptedIssuers() {
					return null;
				}

				@Override
				public void checkServerTrusted(X509Certificate[] chain, String authType) throws CertificateException {
				}

				@Override
				public void checkClientTrusted(X509Certificate[] chain, String authType) throws CertificateException {
				}
			};
			SSLContext context = SSLContext.getInstance("SSLv3");
			context.init(kmf.getKeyManagers(), new TrustManager[] { x509m }, new java.security.SecureRandom());
			LOGGER.info("=================证书完成=================");
			// 监听和接收客户端连接
			SSLServerSocketFactory factory = context.getServerSocketFactory();
			server = (SSLServerSocket) factory.createServerSocket(30000);
			LOGGER.info("ICBC,Socket监听端口:{}", server.getLocalPort());
			while (true) {
				executor.execute(new SocketServer(server.accept(), transCode));
			}
		} catch (Exception e) {
			LOGGER.error("解析证书异常", e);
		}
		LOGGER.info("=================Socket end=================");
	}

	@Override
	public void destroy() {
		if (null != server) {
			try {
				server.close();
			} catch (IOException e) {
				LOGGER.error("关闭SSLServerSocket异常", e);
			}
		}
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.getWriter().append(this.getServletName()).append(" at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {

	}
}