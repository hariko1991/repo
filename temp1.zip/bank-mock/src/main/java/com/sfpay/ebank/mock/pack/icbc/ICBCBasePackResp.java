package com.sfpay.ebank.mock.pack.icbc;

import org.dom4j.Document;
import org.dom4j.Node;

import com.sfpay.ebank.mock.pack.XmlPackResp;
import com.sfpay.ebank.mock.util.BankConstrans;

/**
 * 类说明：<br>
 * 工行挡板公共类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 * CreateDate: 2015年10月31日
 */
public abstract class ICBCBasePackResp extends XmlPackResp{

	@Override
	public String initBankCode() {
		return "icbc";
	}

	/**
	 * 方法说明：<br>
	 * 修改返回报文头
	 * 
	 * @param req
	 * @param resp
	 */
	public void changeRespHead(Document req, Document resp) {
		String fSeqno = req.selectSingleNode(BankConstrans.ICBC_PUB_FSEQNO).getStringValue();
		resp.selectSingleNode(BankConstrans.ICBC_PUB_FSEQNO).setText(fSeqno);
		Node node = resp.selectSingleNode(BankConstrans.ICBC_PUB_SERIALNO);
		if (node != null) {
			resp.selectSingleNode(BankConstrans.ICBC_PUB_SERIALNO).setText("CMN" + fSeqno);
		}
	}





}
