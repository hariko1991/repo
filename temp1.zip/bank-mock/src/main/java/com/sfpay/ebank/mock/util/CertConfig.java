/*	 
 * =================================================================
 * 版权所有 2014-2015 深圳市泰海网络科技服务有限公司，并保留所有权利
 * ----------------------------------------------------------------- 
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * ================================================================= 
 * @Title: CertConfig.java 
 * @Package com.sfpay.tech.util 
 * @Description: 读取证书的相应配置 
 * @author 725826 沈红富   2014-12-19
 * @date 2014-12-19 下午4:54:20 
 * @version V1.0  
 */
package com.sfpay.ebank.mock.util;

import java.io.File;

import com.sfpay.framework.config.properties.Property;

/**
 * @ClassName: CertConfig
 * @Description: TODO
 * @since: TODO
 * @author 725826 沈红富 2014-12-19
 * @date 2014-12-19 下午4:54:20
 */
public class CertConfig {

	public static String getCertDir() {
		return Property.getProperty("dir.cert");
	}

	public static String getCertPath(String bankCode, String filename) {
		return getCertDir() + File.separator + bankCode + File.separator + filename;
	}

}