package com.sfpay.ebank.mock.pack.ccb;


import java.util.Date;
import java.util.List;

import org.dom4j.Document;
import org.dom4j.Node;

import com.sfpay.ebank.mock.pack.XmlPackResp;
import com.sfpay.ebank.mock.util.MockStatus;
import com.sfpay.framework.common.util.DateUtils;

/**
 * 
 * 类说明：<br>
 * 建行挡板公共类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author sfhq813 梁承鸿
 * 
 * CreateDate: 2016-11-8
 */
public abstract class CCBBasePackResp extends XmlPackResp{

	private static final String  SYS_TX_CODE = "Transaction/Transaction_Header/SYS_TX_CODE";
	protected static final String  ITTPARTY_JRNL_NO = "Transaction/Transaction_Header/IttParty_Jrnl_No";
	private static final String  SYS_RESP_DESC = "Transaction/Transaction_Header/SYS_RESP_DESC";
	protected static final String  SYS_RESP_CODE = "Transaction/Transaction_Header/SYS_RESP_CODE";
	protected static final String  SYS_RECV_TIME = "Transaction/Transaction_Header/SYS_RECV_TIME";
	protected static final String  SYS_RESP_TIME = "Transaction/Transaction_Header/SYS_RESP_TIME";
	private static final String  RESPONSE_STATUS = "Transaction/Transaction_Header/tran_response/status";
	private static final String  RESP_BODY = "Transaction/Transaction_Body/response";
	private static final String  CSHMGT_TXN_RSLT_CD = "Transaction/Transaction_Body/response/CshMgt_Txn_Rslt_Cd";
	private static final String  HST_TXN_DT = "Transaction/Transaction_Body/response/Hst_Txn_Dt";
	private static final String  CSHMGT_TXNSRLNO = "Transaction/Transaction_Body/response/CshMgt_TxnSrlNo";
	private static final String  RESP_BODY_List = "Transaction/Transaction_Body/response/LIST1";
	protected static final String  RESP_RVL_RCRD_NUM = "Transaction/Transaction_Body/response/Rvl_Rcrd_Num";
	protected static final String  RESP_TOTAL_REC = "Transaction/Transaction_Body/response/TOTAL_REC";
	protected static final String  RESP_CURR_TOTAL_REC = "Transaction/Transaction_Body/response/CURR_TOTAL_REC";

	private static final String  SYS_TX_CODE_36 = "P1CMSET36";
	private static final String  SYS_TX_CODE_35 = "P1CMSET35";
	private static final String  SYS_TX_CODE_20 = "P1CMSTP20";
	private static final String  SYS_TX_CODE_22 = "P1CMSTP22";



	

	@Override
	public String initBankCode() {
		return "ccb";
	}

	/**
	 * 方法说明：<br>
	 * 修改返回报文头和内容
	 * 
	 * @param req
	 * @param resp
	 */
	public void changeRespHeadAndDetail(Document req, Document resp) {
		String sysTxCode = resp.selectSingleNode(SYS_TX_CODE).getText();
		String IttPartyJrnlNo = req.selectSingleNode(ITTPARTY_JRNL_NO).getText();
		String curTime = DateUtils.formatDate(new Date(), "yyyyMMddHHmmssSSS");
		resp.selectSingleNode(ITTPARTY_JRNL_NO).setText(IttPartyJrnlNo);
		resp.selectSingleNode(SYS_RECV_TIME).setText(curTime);
		resp.selectSingleNode(SYS_RESP_TIME).setText(curTime);
		resp.selectSingleNode(SYS_RESP_DESC).setText(createBankHeadRetMsg());
		resp.selectSingleNode(RESPONSE_STATUS).setText(createResponseStatus());
		if(SYS_TX_CODE_36.equals(sysTxCode)){
			resp.selectSingleNode(SYS_RESP_CODE).setText(changeBankHeadRetCode(resp));
		}else if(SYS_TX_CODE_35.equals(sysTxCode)){
			resp.selectSingleNode(SYS_RESP_CODE).setText(createBankHeadRetCode(resp));
		}else if(SYS_TX_CODE_20.equals(sysTxCode) || SYS_TX_CODE_22.equals(sysTxCode)){
			resp.selectSingleNode(SYS_RESP_DESC).setText("");
			resp.selectSingleNode(RESPONSE_STATUS).setText("COMPLETE");
		}
		

	}
	
	/**
	 * 方法说明：<br>
	 * 模拟建行返回状态
	 * 
	 * @param cmd
	 *            指定银行返回状态码<br>
	 *            000000000000:成功, 其他：失败
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public String createBankHeadRetCode(Document resp) {
		String retCode = "";
		List<Node> nodedList = resp.selectNodes(RESP_BODY);
		int cmd = MockStatus.getTransStatus();
		switch (cmd) {
		case MockStatus.STATUS_WAITING:
			retCode = "000000000000";
			resp.selectSingleNode(CSHMGT_TXN_RSLT_CD).setText("3");
			resp.selectSingleNode(HST_TXN_DT).setText(DateUtils.formatDate(new Date(), "yyyyMMdd"));
			resp.selectSingleNode(CSHMGT_TXNSRLNO).setText("CN000s61"+DateUtils.formatDate(new Date(), "yyyyMMddHHmmssSSSSSS"));
			break;
		case MockStatus.STATUS_FAILURE:
			for (Node out : nodedList) {
				out.getParent().remove(out);
			}
			retCode = "XDCA058121G1";
			break;
		default:	   
			retCode = "000000000000";
			resp.selectSingleNode(CSHMGT_TXN_RSLT_CD).setText("1");
			resp.selectSingleNode(HST_TXN_DT).setText(DateUtils.formatDate(new Date(), "yyyyMMdd"));
			resp.selectSingleNode(CSHMGT_TXNSRLNO).setText("CN000s61"+DateUtils.formatDate(new Date(), "yyyyMMddHHmmssSSSSSS"));
		}
		return retCode;
	}
	
	
	/**
	 * 方法说明：<br>
	 * 模拟建行返回状态
	 * 
	 * @param cmd
	 *            指定银行返回状态码<br>
	 *            000000000000:成功, 其他：失败
	 * 
	 * @return
	 */
	@SuppressWarnings("unchecked")
	public String changeBankHeadRetCode(Document resp) {
		String retCode = "000000000000";
		List<Node> nodedList = resp.selectNodes(RESP_BODY_List);
		resp.selectSingleNode(RESP_RVL_RCRD_NUM).setText("0");
		resp.selectSingleNode(RESP_TOTAL_REC).setText("0");
		resp.selectSingleNode(RESP_CURR_TOTAL_REC).setText("0");

		int cmd = MockStatus.getTransStatus();
		switch (cmd) {
		case MockStatus.STATUS_WAITING:
			for (Node out : nodedList) {
				out.getParent().remove(out);
			}
			break;
		case MockStatus.STATUS_FAILURE:
			for (Node out : nodedList) {
				out.getParent().remove(out);
			}
			break;
		default:
			resp.selectSingleNode(RESP_RVL_RCRD_NUM).setText("1");
			resp.selectSingleNode(RESP_TOTAL_REC).setText("1");
			resp.selectSingleNode(RESP_CURR_TOTAL_REC).setText("1");
		}
		return retCode;
	}
	/**
	 * 方法说明：<br>
	 * 模拟建行返回描述
	 * 
	 * @param cmd
	 *            指定银行返回状态<br>
	 *            1:成功, 2：失败, 3:受理中
	 * 
	 * @return
	 */
	public String createBankHeadRetMsg() {
		String rtnMsg = "";
		int cmd = MockStatus.getTransStatus();
		switch (cmd) {
		case MockStatus.STATUS_WAITING:
			rtnMsg = "已受理";
			break;
		case MockStatus.STATUS_FAILURE:
			rtnMsg = "失败";
			break;
		default:
			rtnMsg = "成功";
		}
		return rtnMsg;
	}
	/**
	 * 方法说明：<br>
	 * 模拟建行返回状态
	 * 
	 * @param cmd
	 *            指定银行返回状态<br>
	 *            1:成功, 2：失败, 3:受理中
	 * 
	 * @return
	 */
	public String createResponseStatus() {
		String status = "";
		int cmd = MockStatus.getTransStatus();
		switch (cmd) {
		case MockStatus.STATUS_WAITING:
			status = "COMPLETE";
			break;
		case MockStatus.STATUS_FAILURE:
			status = "FAIL";
			break;
		default:
			status = "COMPLETE";
		}
		return status;
	}
}
