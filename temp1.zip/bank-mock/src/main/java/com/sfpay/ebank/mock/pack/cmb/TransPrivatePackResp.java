package com.sfpay.ebank.mock.pack.cmb;

import org.dom4j.Document;

public class TransPrivatePackResp extends CMBBasePackResp {
	/**
	 *流程实例号结点路径（银行返回流水）
	 */
	private static final String  REQNBR = "/CMBSDKPGK/NTREQNBRY/REQNBR";
	/**
	 *业务参才号结点路径（批次号）
	 */
	private static final String  YURREF = "/CMBSDKPGK/SDKATSRQX/YURREF";

	@Override
	public Document readRespMockXml() throws Exception {
		String filePath = this.getRespDirPath() + "transPrivate.xml";
		return this.readXmlFile(filePath);
	}

	@Override
	public void changeRespDetail(Document req, Document resp) throws Exception {
		String yurref = req.selectSingleNode(YURREF).getText();
		resp.selectSingleNode(REQNBR).setText("CMB" + yurref);
	}

	@Override
	public void beforeSendResp(Document req, Document resp) throws Exception {
		String reqnbr = resp.selectSingleNode(REQNBR).getText();
		String path = this.getReqDirPath();
		String fileName = path + reqnbr + ".xml";
		writeXmlFile(fileName, req.asXML(), "GBK");
	}

}
