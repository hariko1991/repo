package com.sfpay.ebank.mock.pack.szfs;

import java.io.File;
import java.util.Iterator;

import org.dom4j.Document;
import org.dom4j.Element;

import com.sfpay.ebank.mock.util.MockStatus;

public class QueryPackResp extends SZFSBasePackResp {
	boolean singleFlag;

	@Override
	public void afterReceiveReq(Document req) throws Exception {
		String msgType = req.getRootElement().element("omsgtype").getText();
		if ("SINGLEPAY".equals(msgType)) {
			singleFlag = true;
		} else {
			singleFlag = false;
		}
	}

	@Override
	public Document readRespMockXml() throws Exception {
		if (singleFlag) {
			String filePath = this.getRespDirPath() + "querySinglePay.xml";
			return this.readXmlFile(filePath);
		} else {
			String filePath = this.getRespDirPath() + "queryBatchPay.xml";
			return this.readXmlFile(filePath);
		}
	}

	@SuppressWarnings("rawtypes")
	@Override
	public void changeRespDetail(Document req, Document resp) throws Exception {
		String oseqid = req.getRootElement().elementText("oseqid");
		resp.getRootElement().element("oseqid").setText(oseqid);
		if (singleFlag) {
			resp.getRootElement().element("status").setText(createBankRetCode());
		} else {
			Element respDetails = resp.getRootElement().element("details");
			Iterator respIt = respDetails.elementIterator("detail");
			Element respTemplet = null;
			while (respIt.hasNext()) {
				Element element = (Element) respIt.next();
				if (respTemplet == null) {
					respTemplet = (Element) element.clone();
				}
				element.getParent().remove(element);
			}
			String reqDir = this.getReqDirPath();
			Document orgReq = this.readXmlFile(reqDir + oseqid + ".xml");
			Element orgDetails = orgReq.getRootElement().element("details");
			Iterator reqIt = orgDetails.elementIterator("detail");
			while (reqIt.hasNext()) {
				Element reqDetail = (Element) reqIt.next();
				Element detail = (Element) respTemplet.clone();
				detail.element("outid").setText(reqDetail.elementText("outid"));
				detail.element("dtstatus").setText(createBankRetCode());
				respDetails.add(detail);
			}
		}
	}
	
	@Override
	public void beforeSendResp(Document req, Document resp) throws Exception {
		if (MockStatus.getTransStatus() != MockStatus.STATUS_WAITING) {
			String oseqid = req.getRootElement().elementText("oseqid");
			String reqDir = this.getReqDirPath();
			File reqFile = new File(reqDir + oseqid + ".xml");
			reqFile.delete();
		}
	}

	/**
	 * 方法说明：<br>
	 * 模拟工行银行返回状态
	 * 
	 * @param cmd
	 *            指定银行返回状态<br>
	 *            0:成功, 1：失败, 2:进行中
	 * 
	 * @return
	 */
	public String createBankRetCode() {
		String status = "";
		int cmd = MockStatus.getTransStatus();
		switch (cmd) {
		case MockStatus.STATUS_WAITING:
			status = "04";
			break;
		case MockStatus.STATUS_FAILURE:
			status = "01";
			break;
		default:
			status = "00";
		}
		return status;
	}
}
