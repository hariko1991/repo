/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.mock.web;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.ebank.mock.pack.boc.BOCBasePackResp;
import com.sfpay.ebank.mock.util.SleepUtils;
import com.sfpay.framework.common.util.StringUtils;
import com.sfpay.framework.config.properties.Property;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author sfhq1581
 * 
 *         CreateDate: 2016年11月9日
 */
public class BOCServer extends HttpServlet {

	private static final long serialVersionUID = 8403082964204291451L;

	private static final Logger LOGGER = LoggerFactory.getLogger(BOCServer.class);
	private static Map<String, String> transCode = new HashMap<String, String>();

	@Override
	public void init() throws ServletException {
		super.init();
		String packageName = "com.sfpay.ebank.mock.pack.boc.";
		transCode.put("b2e0009", packageName + "TransPublicPackResp");// 对公交易
		transCode.put("b2e0007", packageName + "QueryPublicPackResp");// 对公查询
		transCode.put("b2e0078", packageName + "TransPrivatePackResp");// 对私交易
		transCode.put("b2e0079", packageName + "QueryPrivatePackResp");// 对私查询
		transCode.put("b2e0001", packageName + "SignResp");// 签到
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		super.doGet(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException,
			IOException {
		BufferedReader reader = null;
		String rData = null;
		
		SleepUtils.sleep(Boolean.valueOf(Property.getProperty("bool")), Long.valueOf(Property.getProperty("sleep")));
		
		try {
			reader = new BufferedReader(new InputStreamReader(request.getInputStream(), "UTF-8"));
			StringBuffer receiveData = new StringBuffer();
			// 分段收取
			String line = null;
			while ((line = reader.readLine()) != null) {
				receiveData.append(line);
			}
			rData = receiveData.toString();
			LOGGER.info("收到的原始数据：" + rData);
		} catch (Exception e) {
			LOGGER.info("数据接收错误。", e);
		} finally {
			if (reader != null) {
				try {
					reader.close();
				} catch (Exception e) {
					LOGGER.info("关闭接收流错误。" + e.getMessage());
				}
			}
		}
		String resp_data = null;
		for (Entry<String, String> e : transCode.entrySet()) {
			int idx = rData.indexOf(e.getKey());
			if (idx >= 0) {
				try {
					 BOCBasePackResp cmb = (BOCBasePackResp)
					 Class.forName(e.getValue()).newInstance();
					 resp_data = cmb.createRespStr(rData);
				} catch (Exception e1) {
					LOGGER.info("处理响应报文异常", e);
				}
				break;
			}
		}
		if (StringUtils.isNullOrEmpty(resp_data)) {
			resp_data = failXml();
		}
		response.setCharacterEncoding("UTF-8");
		PrintWriter pw = response.getWriter();
		pw.write(resp_data);
		pw.flush();
		LOGGER.info("返回的报文：" + resp_data);
		LOGGER.info("=====================================\n\n\n");
		pw.close();

	}

	private String failXml() {
		String str = "<?xml version=\"1.0\" encoding=\"UTF-8\"?>+" + "<bocb2e>+" + " <head>+" + "  <cusopr></cusopr>+"
				+ "  <trncod>b2eerror</trncod>+" + "  <custid></custid>+" + "</head>+" + "<trans>+"
				+ "  <trn-b2eerror-rs>+" + "    <status>+" + "      <rspcod>1012</rspcod>+"
				+ "      <rspmsg>中行挡板有误，请检查模板文件是否存在</rspmsg>+" + "    </status>+" + "  </trn-b2eerror-rs>+" + "</trans>+"
				+ "</bocb2e>";
		LOGGER.info("中行返回报文：" + str);
		return str;
	}

	@Override
	public void destroy() {
		// TODO Auto-generated method stub
		super.destroy();
	}

}
