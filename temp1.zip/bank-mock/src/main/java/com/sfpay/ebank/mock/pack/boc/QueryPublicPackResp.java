package com.sfpay.ebank.mock.pack.boc;

import java.io.File;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.Node;

import com.sfpay.ebank.mock.util.MockStatus;
import com.sfpay.framework.common.util.Md5Utils;

public class QueryPublicPackResp extends BOCBasePackResp {
	/**
	 * 响应明细节点
	 */
	private static final String RESP_DETAIL = "/bocb2e/trans/trn-b2e0007-rs/b2e0007-rs";
	private static final String RESP_DETAIL_PARENT = "/bocb2e/trans/trn-b2e0007-rs";

	private static final String REQ_DETAIL_TRANS = "/bocb2e/trans/trn-b2e0009-rq/b2e0009-rq";
	
	private static final String REQ_DETAIL_QUERY = "/bocb2e/trans/trn-b2e0007-rq/b2e0007-rq";
	/**
	 */
	private static final String INSID = "insid";
	private static final String OBSSID = "obssid";

	@Override
	public Document readRespMockXml() throws Exception {
		String filePath = this.getRespDirPath() + "queryPublic.xml";
		return this.readXmlFile(filePath);
	}

	@Override
	@SuppressWarnings("unchecked")
	public void changeRespDetail(Document req, Document resp) throws Exception {
		List<Node> respList = resp.selectNodes(RESP_DETAIL);
		Node respNodeTemplet = null;
		for (Node node : respList) {
			if (respNodeTemplet == null) {
				respNodeTemplet = (Node) node.clone();
			}
			node.getParent().remove(node);
		}
		Set<String> reqnbrSet = new TreeSet<String>();
		List<Node> reqList = req.selectNodes(REQ_DETAIL_QUERY);
		for (Node note : reqList) {
			reqnbrSet.add(note.selectSingleNode(INSID).getText());
		}
		String reqnbr = Md5Utils.encryptMD5(reqnbrSet.toString());
		String reqDir = this.getReqDirPath();
		String filepath = reqDir + reqnbr + ".xml";
		Document orgReq = this.readXmlFile(filepath);
		List<Node> orgList = orgReq.selectNodes(REQ_DETAIL_TRANS);
		Element root = (Element) resp.selectObject(RESP_DETAIL_PARENT);
		for (Node reqNode : orgList) {
			Node respNode = (Node) respNodeTemplet.clone();
			String insid = reqNode.selectSingleNode(INSID).getText();
			respNode.selectSingleNode(INSID).setText(insid);
			respNode.selectSingleNode(OBSSID).setText("BOC" + insid);
			respNode.selectSingleNode("status/rspcod").setText(this.mockRtnFlg());
			respNode.selectSingleNode("status/rspmsg").setText("挡板返回");
			root.add(respNode);
		}
		if (MockStatus.getTransStatus() != MockStatus.STATUS_WAITING) {
			new File(filepath).delete();
		}
	}

	public String mockRtnFlg() {
		String status = "";
		int cmd = MockStatus.getTransStatus();
		switch (cmd) {
		case MockStatus.STATUS_WAITING:
			status = "B054";
			break;
		case MockStatus.STATUS_FAILURE:
			status = "FFFF";
			break;
		default:
			status = "B001";
		}
		return status;
	}

}
