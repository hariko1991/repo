package com.sfpay.ebank.mock.pack.szfs;

import org.dom4j.Document;

public class TransBatchPackResp extends SZFSBasePackResp {
	@Override
	public void afterReceiveReq(Document req) throws Exception {
		String outid = req.getRootElement().element("batno").getText();
		String path = this.getReqDirPath();
		String fileName = path + outid + ".xml";
		writeXmlFile(fileName, req.asXML(), "UTF-8");
	}

	@Override
	public Document readRespMockXml() throws Exception {
		String filePath = this.getRespDirPath()+"batchPay.xml";
		return this.readXmlFile(filePath);
	}

	@Override
	public void changeRespDetail(Document req, Document resp) throws Exception {
	}

}
