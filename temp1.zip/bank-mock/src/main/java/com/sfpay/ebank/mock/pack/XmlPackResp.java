package com.sfpay.ebank.mock.pack;

import java.io.File;

import org.apache.commons.io.FileUtils;
import org.dom4j.Document;
import org.dom4j.DocumentHelper;
import org.dom4j.io.SAXReader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.ebank.mock.util.MockStatus;
import com.sfpay.framework.config.properties.Property;

/**
 * 类说明：<br>
 * XML报文挡板
 * 
 * <p>
 * 挡板处理流程：<br>
 * 1、初始化通道代码<br>
 * 2、解析请求报文<br>
 * 3、接收请求后处理 <br>
 * 4、读取响应报文模板文件<br>
 * 5、修改返回报文头<br>
 * 6、修改返回报文交易明细<br>
 * 7、发送响应前处理<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2015年10月31日
 */
public abstract class XmlPackResp {
	private static final Logger LOGGER = LoggerFactory.getLogger(XmlPackResp.class);
	/**
	 * 通道名称
	 */
	private String bankCode = "";

	public String createRespStr(String reqStr) {
		String respStr = null;
		try {
			bankCode = initBankCode();
			Document req = DocumentHelper.parseText(reqStr);
			afterReceiveReq(req);
			Document resp = readRespMockXml();
			changeRespDetail(req, resp);
			beforeSendResp(req, resp);
			respStr = resp.asXML();
		} catch (Exception e) {
			LOGGER.error("解析xml异常",e);
			respStr = "";
		}
		return respStr;
	}

	/**
	 * 方法说明：<br>
	 * 接收请求后处理
	 * 
	 * @param req
	 * @throws Exception
	 */
	public void afterReceiveReq(Document req) throws Exception {
	}

	/**
	 * 方法说明：<br>
	 * 发送响应前处理
	 * 
	 * @param req
	 * @param resp
	 * @throws Exception
	 */
	public void beforeSendResp(Document req, Document resp) throws Exception {
	}

	/**
	 * 方法说明：<br>
	 * 初始化通道名称
	 * 
	 * @param bankCode
	 * @return
	 */
	public abstract String initBankCode();

	/**
	 * 方法说明：<br>
	 * 读取响应报文模板文件（xml）
	 * 
	 * @return
	 * @throws Exception
	 */
	public abstract Document readRespMockXml() throws Exception;

	/**
	 * 方法说明：<br>
	 * 修改返回报文交易明细
	 * 
	 * @param req
	 * @param resp
	 */
	public abstract void changeRespDetail(Document req, Document resp) throws Exception;

	/**
	 * 方法说明：<br>
	 * 获取请求报文路径
	 * 
	 * @return
	 */
	public String getReqDirPath() {
		String msgDir = Property.getProperty("dir.message");
		StringBuffer sb = new StringBuffer(msgDir);
		sb.append(File.separator).append(bankCode).append(File.separator).append("req").append(File.separator);
		File file = new File(sb.toString());
		if (!file.exists()) {
			file.mkdirs();
		}
		return sb.toString();
	}

	/**
	 * 方法说明：<br>
	 * 获取响应报文路径
	 * 
	 * @return
	 */
	public String getRespDirPath() {
		String msgDir = Property.getProperty("dir.message");
		StringBuffer sb = new StringBuffer(msgDir);
		sb.append(File.separator).append(bankCode).append(File.separator).append("resp").append(File.separator);
		File file = new File(sb.toString());
		if (!file.exists()) {
			file.mkdirs();
		}
		return sb.toString();
	}

	/**
	 * 方法说明：<br>
	 * 读取XML文件
	 * 
	 * @param filePath
	 * @return
	 * @throws Exception
	 */
	public Document readXmlFile(String filePath) throws Exception {
		SAXReader reader = new SAXReader();
		Document document = reader.read(filePath);
		return document;
	}

	public void writeXmlFile(String filePath, String content, String encode) throws Exception {
		try {
			FileUtils.writeStringToFile(new File(filePath), content, encode);
			// FileOutputStream fos = new FileOutputStream(filePath);
			// fos.write(content.getBytes(encode));
			// fos.close();
		} catch (Exception e) {
			LOGGER.error("写入文件异常",e);
		}
	}

	/**
	 * 方法说明：<br>
	 * 模拟交易状态
	 * 
	 * @return
	 */
	public int mockTransStatus() {
		return MockStatus.getTransStatus();
	}

	/**
	 * 方法说明：<br>
	 * 生成银行返回码
	 */
	public String createBankRetCode() {
		return "";
	}

}
