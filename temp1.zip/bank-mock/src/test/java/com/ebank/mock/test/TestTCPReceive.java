/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.ebank.mock.test;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author sfhq1581
 * 
 *         CreateDate: 2016年11月8日
 */
public class TestTCPReceive {
	public static void main(String[] args) {
		Socket socket = null;
		try {
			// 对服务端发起连接请求
			socket = new Socket("127.0.0.1", 30001);
			// 给服务端发送响应信息
			OutputStream os = socket.getOutputStream();
			os.write("yes,I have received you messagefdgdfgfdsgdfgsdfg!".getBytes());
			// 接受服务端消息并打印
			InputStream is = socket.getInputStream();
			byte b[] = new byte[1024];
			is.read(b);
			System.out.println(new String(b,"GBK"));
			os.close();
		} catch (IOException e) {
			e.printStackTrace();
		} finally {
			try {
				socket.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	}
}
