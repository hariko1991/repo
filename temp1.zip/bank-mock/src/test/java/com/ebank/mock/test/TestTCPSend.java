/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.ebank.mock.test;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author sfhq1581 
 * 
 * CreateDate: 2016年11月8日
 */
public class TestTCPSend {
	public static void main(String[] args) { 
	      ServerSocket serverSocket=null; 
	      Socket socket=null; 
	      String msg="hello client,I am server.."; 
	      try { 
	          
	         //构造ServerSocket实例，指定端口监听客户端的连接请求 
	         serverSocket=new ServerSocket(30000); 
	         //建立跟客户端的连接 
	         socket=serverSocket.accept(); 
	          
	         //向客户端发送消息 
	         OutputStream os=socket.getOutputStream(); 
	         os.write(msg.getBytes()); 
	         InputStream is=socket.getInputStream(); 
	          
	         //接受客户端的响应 
	         byte[] b=new byte[1024]; 
	         is.read(b); 
	         System.out.println(new String(b)); 
	          
	      } catch (IOException e) { 
	         e.printStackTrace(); 
	      } finally { 
	         //操作结束，关闭socket  
	          try { 
	            serverSocket.close(); 
	            socket.close(); 
	          } catch (IOException e) { 
	            e.printStackTrace(); 
	          } 
	      }  
	  } 
}
