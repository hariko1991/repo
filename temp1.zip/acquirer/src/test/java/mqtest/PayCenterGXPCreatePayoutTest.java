/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package mqtest;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.domain.paycenter.PayoutReqInfo;
import com.sfpay.acquirer.enums.SystemSource;
import com.sfpay.acquirer.service.IPayoutCenterService;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author sfhq269 向鹏
 * 
 * CreateDate: 2014-9-15
 */
public class PayCenterGXPCreatePayoutTest  extends SpringTestCase {
	
	@Resource
	private IPayoutCenterService payoutCenterService; 
//			IPayoutCenterService
	@Test
	public void payoutCenterServiceTest(){
		List<PayoutReqInfo> list=new ArrayList<PayoutReqInfo>();
		try{
			PayoutReqInfo info=new PayoutReqInfo();
			info.setCmdType("SDLR");
			info.setTradeNo("sf"+new Date().getTime());
			list.add(info);
			payoutCenterService.payCenterGXPCreatePayout(list);	
		}catch(Exception e){
			e.printStackTrace();
		}
		
		}

}
