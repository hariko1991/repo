/**
 * 
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.dao.DataAccessException;

import com.sfpay.acquirer.domain.ThirdCoverBank;
import com.sfpay.acquirer.domain.ThirdCoverBankQueryParam;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.ThirdBankCode;
import com.sfpay.acquirer.enums.ThirdCoverBankStatus;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 类说明：
 * 
 * 
 * <p/>
 * 详细描述：
 * 
 * 
 * @author 312932 何国兴
 * 
 * CreateDate: 2012-6-1
 */
public class ThirdCoverBankDaoTest extends SpringTestCase {

	@Resource
	private IThirdCoverBankDao dao;

	@Test
	public void testCountThirdCoverBankPage() {
		ThirdCoverBankQueryParam param = new ThirdCoverBankQueryParam();
		param.setChannelCode(ChannelCode.B2C);
		try { 
			long count = dao.countThirdCoverBankPage(param);
			logger.debug("{}", count);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}

	@Test
	public void testQueryThirdCoverBankPage() {
		ThirdCoverBankQueryParam param = new ThirdCoverBankQueryParam();
		param.setChannelCode(ChannelCode.B2C);
		try { 
			List<ThirdCoverBank> list = dao.queryThirdCoverBankPage(param, 1, 2);
			logger.debug("{}", null == list ? "null" : list.toString());
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}

	@Test
	public void testUpdateStatus() {
		try { 
			dao.updateStatus(1, ThirdCoverBankStatus.ENABLED, "test");
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}

	@Test
	public void testQueryThirdCoverBankList() {
		try { 
			List<ThirdCoverBank> list = dao.queryThirdCoverBankList(ChannelCode.B2C, ThirdBankCode.YEEPAY);
			logger.debug("{}", null == list ? "null" : list.toString());
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}

}
