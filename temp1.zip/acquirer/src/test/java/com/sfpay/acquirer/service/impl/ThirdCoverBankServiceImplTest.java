/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.dao.IThirdCoverBankDao;
import com.sfpay.acquirer.domain.ThirdCoverBank;
import com.sfpay.acquirer.domain.ThirdCoverBankQueryParam;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.ThirdBankCode;
import com.sfpay.acquirer.enums.ThirdCoverBankStatus;
import com.sfpay.acquirer.service.IThirdCoverBankService;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 
 * 类说明：
 *  
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-5-28
 */
public class ThirdCoverBankServiceImplTest extends ClassTransactionalTestCase {
	
	private static Logger logger = LoggerFactory.getLogger(ThirdCoverBankServiceImplTest.class);
	
	@Resource
	private IThirdCoverBankService service;
	
	@Test
	public void testQueryThirdCoverBankPage(){
		ThirdCoverBankQueryParam param = new ThirdCoverBankQueryParam();		
		param.setChannelCode(ChannelCode.B2C);
		MockCurrentResult.setMockValue(IThirdCoverBankDao.class, "countThirdCoverBankPage",10l);
		try {
		
			IPage<ThirdCoverBank> page = service.queryThirdCoverBankPage(param, 1, 10);
			logger.debug("page is: {}", page == null ? "" : page.toString());
			
			
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testUpdateStatus(){		
		try {
			
			service.updateStatus(1L,null,"test");	
		} catch (Exception e) {
			logger.error("", e);
		}
		
	try {
			
			service.updateStatus(1L,ThirdCoverBankStatus.ENABLED,"test");	
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testQueryThirdCoverBankList(){		
		try {
			List<ThirdCoverBank> list = service.queryThirdCoverBankList(ChannelCode.B2C, ThirdBankCode.YEEPAY);
			logger.debug("list is:"+ list == null ? "" : list.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			service.queryThirdCoverBankList(null, ThirdBankCode.YEEPAY);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
		try {
			 service.queryThirdCoverBankList(ChannelCode.B2C, null);
		} catch (Exception e) {
			logger.error("", e);
		}
		
	}
	@Test
	public void testUpdateThirdCoverBankById(){
		ThirdCoverBank  param=new ThirdCoverBank(); 
		param.setChannelCode(ChannelCode.B2C);
		param.setBankCode(ThirdBankCode.YEEPAY);
		param.setCoverBankCode("ALIPAY");
		try {
			service.updateThirdCoverBankById(param);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			service.updateThirdCoverBankById(null);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		param.setChannelCode(null);
		try {
			service.updateThirdCoverBankById(param);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		param.setChannelCode(ChannelCode.B2C);
		param.setBankCode(null);
		try {
			service.updateThirdCoverBankById(param);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		param.setBankCode(ThirdBankCode.YEEPAY);
		param.setCoverBankCode(null);
		try {
			service.updateThirdCoverBankById(param);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	public void testQueryThirdCoverBankById(){
		
		try {
			service.queryThirdCoverBankById(10l);
		} catch (Exception e) {
			logger.error("", e);
		}
		
	}
}
