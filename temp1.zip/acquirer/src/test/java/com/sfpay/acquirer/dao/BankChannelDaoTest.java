/**
 * 
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

import com.sfpay.acquirer.domain.BankChannel;
import com.sfpay.acquirer.domain.BankChannelQueryParam;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 类说明：
 *  
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-5-28
 */
public class BankChannelDaoTest extends SpringTestCase {
	
	private static Logger logger = LoggerFactory.getLogger(BankChannelDaoTest.class);
	
	@Resource
	private IBankChannelDao dao;
	
	@Test
	public void testQueryBankChannelPageCount(){
		BankChannelQueryParam param = new BankChannelQueryParam();
		param.setChannelCode(ChannelCode.B2C);
		try { 
			long count = dao.queryBankChannelPageCount(param);
			logger.debug("count is:"+count);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testQueryBankChannelPageList(){
		BankChannelQueryParam param = new BankChannelQueryParam();
		param.setChannelCode(ChannelCode.B2C);
		try { 
			List<BankChannel> list = dao.queryBankChannelPageList(param, 1, 2);
			logger.debug("list is:"+list);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testQueryBankChannelList(){
		try { 
			List<BankChannel> list = dao.queryBankChannelList(ChannelCode.B2C, true);
			logger.debug("list is:"+list);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testQueryBankChannel(){
		try { 
			BankChannel bankChannel = dao.queryBankChannel(ChannelCode.B2C,BankCode.PAB);
			logger.debug("bankChannel is:"+bankChannel);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
}
