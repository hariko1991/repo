/**
 * =================================================================
 * 版权所有 2011-2012 深圳市泰海网络科技服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.dao.DataAccessException;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.domain.CollectInfo;
import com.sfpay.acquirer.domain.ReverseInfo;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.CardType;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.CollectStatus;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.acquirer.enums.SystemSource;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 312932 何国兴
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2012-11-19
 */
public class CollectInfoDaoTest extends SpringTestCase {

	@Resource
	private ICollectInfoDao dao;
	
	@Test
	public void testFindByCollectNo() {
		CollectInfo ci = null;
		try {
			ci = dao.findByCollectNo("1302020000001064");
			logger.debug("{}", null == ci ? "null" : ci.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testFindByBizNo() {
		CollectInfo ci = null;
		try {
			ci = dao.findByBizNo("39091388902909028147");
			logger.debug("{}", null == ci ? "null" : ci.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testFindByPayNo() {
		try {
			CollectInfo ci = dao.findByPayNo("89091381809601292102", SystemSource.PORTAL);
			logger.debug("{}", ci.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testCreateCollectInfo() {
		CollectInfo ci = new CollectInfo();
		ci.setBankCode(BankCode.UPOP);
		ci.setChannelCode(ChannelCode.QPAY);
		ci.setOrderType(OrderType.EXPENSE);
		ci.setFundWay(FundWay.IN);
		ci.setTradeNo("11111111");
		ci.setPayNo("2222222");
		ci.setBusinessSn("3333333333");
		ci.setAmt(1L);
		ci.setCcy(CurrencyType.RMB);
		ci.setStatus(CollectStatus.SUCCESS);
		ci.setEndTime(new Date());
		ci.setClientIp("10.0.0.0");
		ci.setOldCollectNo("444444444");
		ci.setAppendBusType(null);
		
		//查询收款方信息
		ci.setPayeeMemberNo(null);
		ci.setPayeeOrgCode("aaaaaaa");
		ci.setPayeeBranchCode("ddddddd");
		ci.setPayeeBranchName("cccccccc");
		ci.setPayeeAcctCode("ggggggg");
		ci.setPayeeAcctName("wwwwwwwww");
		ci.setPayeeAcctProvince("tttttttt");
		ci.setPayeeAcctCity("yyyyyyy");
		ci.setFrontUrl("http://127.0.0.1/acq/{0}/callback");
		ci.setResultUrl("http://127.0.0.1/acq/{0}/notify");
		
//		ci.setPayerCardType(CardType.CREDIT);
//		ci.setFee(1L);
		
		try {
			dao.createCollectInfo(ci);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testUpdateByCollectNo() {
		CollectInfo ci = new CollectInfo();
		ci.setBankCode(BankCode.ICBC);
		ci.setChannelCode(ChannelCode.B2C);
		ci.setReqBankSn("111");
		ci.setFee(0L);
		ci.setPayerOrgCode("1515");
		ci.setPayerOrgName("1515Name");
		ci.setPayerBranchCode("1212");
		ci.setPayerBranchName("2323");
		ci.setPayerAcctCode("2525");
		ci.setPayerAcctName("2626");
		ci.setPayerAcctProvince("7575");
		ci.setPayerAcctProvinceN("9898");
		ci.setPayerAcctCity("7878");
		ci.setPayerAcctCityN("5656");
		ci.setStatus(CollectStatus.RECEIVED);
		ci.setRtnBankSn("4141");
		ci.setRtnBankMsg("7474");
		ci.setRtnPayCode("5656");
		ci.setBatchCode("B1234567");
		ci.setRemark("test");
		
		ci.setCollectNo("000000");
		try {
			dao.updateByCollectNo(ci);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testCreateQPayUser() {
		try {
			dao.createQPayUser("15899763696", Arrays.asList(new String[]{"4432,1234"}));
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testUpdateByReverse() {
		ReverseInfo reverse = new ReverseInfo();
		reverse.setCollectNo("13020500000011050");
		reverse.setReverseType(OrderType.CANCEL);
		try {
			dao.updateByReverse(reverse);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testUpdateForBankCall() {
		CollectInfo ci = new CollectInfo();
		ci.setBankCode(BankCode.ABC);
		ci.setChannelCode(ChannelCode.B2C);
		ci.setReqBankSn("00001");
		ci.setFee(0L);
		ci.setPayerOrgCode("0000");
		ci.setPayerOrgName("AAAAA");
		ci.setPayerBranchCode("1111");
		ci.setPayerBranchName("大幅度");
		ci.setPayerAcctCode("0755");
		ci.setPayerAcctName("幅度");
		ci.setPayerAcctProvince("GD");
		ci.setPayerAcctProvinceN("广东");
		ci.setPayerAcctCity("SZ");
		ci.setPayerAcctCityN("深圳");
		ci.setRtnBankSn("444");
		ci.setRtnBankMsg("OK");
		ci.setRtnPayCode("888");
		ci.setBatchCode("B222");
		ci.setRemark("test");
		ci.setRtnBankCode("8889");
		ci.setStatus(CollectStatus.SUCCESS);
		ci.setCollectNo("1308210000003052");
		
		try {
			dao.updateForBankCall(ci);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testUpdateRemark() {
		try { 
			dao.updateRemark("00000000", "test");
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testCountRecon() {
		try { 
			dao.countRecon("2013-08-05");
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testQueryRecon() {
		try { 
			dao.queryRecon("2013-08-05", 1, 10);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testCloseCollectInfo() {
		
		try { 
			dao.closeCollectInfo(new Date(), CollectStatus.FAILURE);//TODO 此SQL优化?
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testQueryCloseCollectInfo() {
		 List<CollectInfo> list = null;
		try {
			list = dao.queryCloseCollectInfo(new Date());//TODO 此SQL优化(同closeCollectInfo)?
			for(CollectInfo ci : list){
				logger.debug("ci : {}", ci.toString());
			}
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testQueryCollectInfoForCheck() {
		Date date = DateUtil.getDateFormatStr("20120202", DateUtil.DATA_FORMAT_PATTERN_2);
		CollectInfo ci = null;
		try {
			ci = dao.queryCollectInfoForCheck("39091388902909028147", date);
			logger.debug("{}", null == ci ? "null" : ci.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testUpdateForResupplyByNo() {
		try {
			dao.updateForResupplyByNo("0000001", "Msg", "B001", "P0010");
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testUpdateTradeCardType() {
		
		try { 
			dao.updateFee(CardType.CREDIT, 1L, "00000002");
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
}