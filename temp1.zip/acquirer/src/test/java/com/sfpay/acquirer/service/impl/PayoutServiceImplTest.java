/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.PayoutEditor;
import com.sfpay.acquirer.domain.PayoutForCheckTotalBatchQueryParam;
import com.sfpay.acquirer.domain.PayoutQueryParam;
import com.sfpay.acquirer.domain.PayoutQueryRlt;
import com.sfpay.acquirer.domain.TotalBatchInfo;
import com.sfpay.acquirer.enums.AcctType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.acquirer.enums.RemitMethod;
import com.sfpay.acquirer.enums.SystemSource;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.acquirer.service.IPayoutQueryService;
import com.sfpay.acquirer.service.IPayoutService;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 类说明：<br>
 * 付款测试类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2012-10-26
 */
public class PayoutServiceImplTest extends SpringTestCase {

	@Resource
	private IPayoutService service;
	
	@Resource
	private IPayoutQueryService payoutQueryService; 

	/**
	 * 方法说明：<br>
	 * 1、招行录入
	 */
	@Test
	public void createPayoutCMB() {
		try {
			List<PayoutEditor> payoutEditorList = new ArrayList<PayoutEditor>();

			/************************** 招行 ***************************/
			PayoutEditor editor = new PayoutEditor();
			editor.setAmt(2);
			editor.setCreateDate(new Date());
			editor.setMsgFlag(YNFlag.N);
			editor.setPayeeAcctAddr("地址1");
			editor.setPayeeAcctCity("");
			editor.setPayeeAcctName("唐曾");
			editor.setPayeeAcctNo("6225885710000027");
			editor.setPayeeAcctProvince("");
			editor.setPayeeAcctType(AcctType.COMPANY);
			editor.setPayeeBranchCode("");
			editor.setPayeeEmail("test@163.com");
			editor.setPayeeMobile("1311111111");
			editor.setPayeeOrgCode(BankCode.CMB);
			editor.setRemark("备注1");
			editor.setRemitMethod(RemitMethod.COMMON);
			editor.setSaveColtCompFlag(YNFlag.N);
			editor.setSummary("我人有的和主产不为这国中是上一地在要工工经以发了民同");
			editor.setUseDesc("代发");
			editor.setPayeeBranchName("招商银行股份有限公司杭州凤起支行");
			editor.setPayeeAcctProvinceName("浙江省");
			editor.setPayeeAcctCityName("杭州市");
			editor.setExpectPayDate(new Date());
			editor.setSystemSource(SystemSource.COD);
			editor.setTradeOutNo(CUID.generate(20));

			payoutEditorList.add(editor);

			PayoutEditor editor1 = new PayoutEditor();
			editor1.setAmt(1);
			editor1.setCreateDate(new Date());
			editor1.setMsgFlag(YNFlag.Y);
			editor1.setPayeeAcctAddr("地址2");
			editor1.setPayeeAcctCity("");
			editor1.setPayeeAcctName("土豆");
			editor1.setPayeeAcctNo("6225885750000028");
			editor1.setPayeeAcctProvince("");
			editor1.setPayeeAcctType(AcctType.PERSON);
			editor1.setPayeeBranchCode("");
			editor1.setPayeeEmail("test@163.com");
			editor1.setPayeeMobile("1311111111");
			editor1.setPayeeOrgCode(BankCode.CMB);
			editor1.setRemark("备注2");
			editor1.setRemitMethod(RemitMethod.COMMON);
			editor1.setSaveColtCompFlag(YNFlag.N);
			editor1.setSummary("摘要2");
			editor1.setUseDesc("代发");
			editor1.setPayeeBranchName("招商银行股份有限公司杭州分行");
			editor1.setPayeeAcctProvinceName("浙江省");
			editor1.setPayeeAcctCityName("杭州市");
			editor1.setTradeOutNo("tradeOutNo123456789");
			editor1.setSystemSource(SystemSource.COD);
			editor1.setTradeOutNo(CUID.generate(20));

			payoutEditorList.add(editor1);

			List<PayoutEditor> payoutEditorResp = service.createPayout(payoutEditorList);
			for (PayoutEditor resp : payoutEditorResp) {
				logger.debug("payoutNo: {}", resp.getPayoutNo());
			}
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 1、付款中心测试用
	 * 
	 */
	@Test
	public void createPayoutCenter() {
		try {
		 for(int i=0;i<10;i++){
			List<PayoutEditor> payoutEditorList = new ArrayList<PayoutEditor>();

			/********************** 工行 ***************************/
			PayoutEditor editor = new PayoutEditor();
			editor.setAmt(1700-i);
			
			editor.setCreateDate(new Date());
			editor.setMsgFlag(YNFlag.Y);
			editor.setPayeeAcctAddr("深圳");
			editor.setPayeeAcctCity("440300");
			editor.setPayeeAcctName("韶圳蜕劳睡张劳笙苹坎营焚");
			editor.setPayeeAcctNo("4000020919200077141");
			editor.setPayeeAcctProvince("440000");
			editor.setPayeeAcctType(AcctType.PERSON);
			editor.setPayeeBranchCode("102584000002");
			editor.setPayeeEmail("testicbc@163.com");
			editor.setPayeeMobile("13222222222");
			editor.setPayeeOrgCode(BankCode.ICBC);
			editor.setRemark("工行1");
			editor.setRemitMethod(RemitMethod.COMMON);
			editor.setSaveColtCompFlag(YNFlag.Y);
			editor.setSummary("工行1");
			editor.setUseDesc("工资");

			editor.setPayeeBranchName("中国工商银行深圳市分行");
			editor.setPayeeAcctProvinceName("广东省");
			editor.setPayeeAcctCityName("深圳市");
			editor.setExpectPayDate(new Date());
			editor.setSystemSource(SystemSource.GXP);
			editor.setTradeOutNo("7551751156N9999995"+i);			
			payoutEditorList.add(editor);		
			
			List<PayoutEditor> payoutEditorResp = service.createPayout(payoutEditorList);
			for (PayoutEditor resp : payoutEditorResp) {
				System.out.println("返回状态："+resp.getStatus().getText());
				System.out.println("返回备注："+resp.getRemark());
			}
		 }
		} catch (Exception ex) {
			logger.error("", ex);
		}
		
	}
	
	

	/**
	 * 方法说明：<br>
	 * 1、工行录入
	 * 
	 */
	@Test
	public void createPayoutICBC() {
		try {
			List<PayoutEditor> payoutEditorList = new ArrayList<PayoutEditor>();

			/********************** 工行 ***************************/
			PayoutEditor editor = new PayoutEditor();
			editor.setAmt(1000);
			
			editor.setCreateDate(new Date());
			editor.setMsgFlag(YNFlag.Y);
			editor.setPayeeAcctAddr("深圳");
			editor.setPayeeAcctCity("440300");
			editor.setPayeeAcctName("韶圳蜕劳睡张劳笙苹坎营焚");
			editor.setPayeeAcctNo("4000020919200077141");
			editor.setPayeeAcctProvince("440000");
			editor.setPayeeAcctType(AcctType.PERSON);
			editor.setPayeeBranchCode("102584000002");
			editor.setPayeeEmail("testicbc@163.com");
			editor.setPayeeMobile("13222222222");
			editor.setPayeeOrgCode(BankCode.ICBC);
			editor.setRemark("工行1");
			editor.setRemitMethod(RemitMethod.COMMON);
			editor.setSaveColtCompFlag(YNFlag.Y);
			editor.setSummary("工行1");
			editor.setUseDesc("工资");

			editor.setPayeeBranchName("中国工商银行深圳市分行");
			editor.setPayeeAcctProvinceName("广东省");
			editor.setPayeeAcctCityName("深圳市");
			editor.setExpectPayDate(new Date());
			editor.setSystemSource(SystemSource.COD);
			editor.setTradeOutNo("7551751156N99999980");
			

			payoutEditorList.add(editor);
		
			
			List<PayoutEditor> payoutEditorResp = service.createPayout(payoutEditorList);
			for (PayoutEditor resp : payoutEditorResp) {
				logger.debug(resp.getPayoutNo());
			}
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}

	/**
	 * 方法说明：<br>
	 * 2、生成批次
	 */
	@Test
	public void createBatch() {
		String rule = "ICBC_1001";
		String operator = "654895";
		String[] payoutNo = new String[]{"1309120000001121", "1309120000001122"};
		try {
			BatchInfo bi = service.createBatch(rule, operator, Arrays.asList(payoutNo));
			logger.debug("{}", null == bi ? "null" : bi.getBatchCode());
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 2、生成批次
	 */
	@Test
	public void createBatch1() {
		String rule = "ICBC_1001";
		String operator = "654895";
		String[] payoutNo = new String[]{ "1309120000001122"};
		try {
			BatchInfo bi = service.createBatch(rule, operator, Arrays.asList(payoutNo));
			logger.debug("{}", null == bi ? "null" : bi.getBatchCode());
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}

	/**
	 * 方法说明：<br>
	 * 3、第一次复核
	 * 
	 */
	@Test
	public void testAuditFirst() {
		try {
			// createOperator/firOperator/secOperator
			service.checkPayout("2013090601291516", "123456", null, BatchStatus.FIR_CHECK_PASS);
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}

	/**
	 * 方法说明：<br>
	 * 3、第二次复核
	 * 
	 */
	@Test
	public void testAuditSecond() {
		try {
			// createOperator/firOperator/secOperator
			service.checkPayout("2013090601291516", "741258", "dd", BatchStatus.SEC_CHECK_PASS);
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}

	@Test
	public void testICBC() {
		for (int i = 0; i < 100; i++) {
			List<String> payoutNoList = new ArrayList<String>();
			try {
				List<PayoutEditor> payoutEditorList = new ArrayList<PayoutEditor>();
               for(int k=0;k<1;k++){
				/********************** 工行 ***************************/
				PayoutEditor editor = new PayoutEditor();
				editor.setAmt(1);
				editor.setCreateDate(new Date());
				editor.setMsgFlag(YNFlag.Y);
				editor.setPayeeAcctAddr("深圳");
				editor.setPayeeAcctCity("440300");
				editor.setPayeeAcctName("缉圳拂千港目千蛇酰佣死嗣1");
				editor.setPayeeAcctNo("4000020919200077141");
				editor.setPayeeAcctProvince("440000");
				editor.setPayeeAcctType(AcctType.PERSON);
				editor.setPayeeBranchCode("102584000002");
				editor.setPayeeEmail("testicbc@163.com");
				editor.setPayeeMobile("13222222222");
				editor.setPayeeOrgCode(BankCode.ICBC);
				editor.setRemark("工行1");
				editor.setRemitMethod(RemitMethod.COMMON);
				editor.setSaveColtCompFlag(YNFlag.N);
				editor.setSummary("工行1");
				editor.setUseDesc("工资");

				editor.setPayeeBranchName("中国工商银行深圳市分行");
				editor.setPayeeAcctProvinceName("广东省");
				editor.setPayeeAcctCityName("深圳市");
				editor.setExpectPayDate(new Date());
				editor.setSystemSource(SystemSource.COD);
				editor.setTradeOutNo(CUID.generateId4B2E(20));

				payoutEditorList.add(editor);

               }

				List<PayoutEditor> payoutEditorResp = service.createPayout(payoutEditorList);
				for (PayoutEditor resp : payoutEditorResp) {
					logger.debug(resp.getPayoutNo());
					payoutNoList.add(resp.getPayoutNo());
				}
			} catch (Exception ex) {
				logger.error("", ex);
			}

			// 生成批次
			BatchInfo bi = null;
			try {
				bi = service.createBatch("ICBC_1001", "654895", payoutNoList);
				logger.debug("批次号: {}", bi.getBatchCode());
			} catch (Exception ex) {
				logger.error("", ex);
			}

			/**
			 * 方法说明：<br>
			 * 3、第一次复核
			 * 
			 */
			try {
				// createOperator/firOperator/secOperator
				service.checkPayout(bi.getBatchCode(), "123456", "第一通过", BatchStatus.FIR_CHECK_PASS);
			} catch (Exception ex) {
				logger.error("", ex);
			}

			/**
			 * 方法说明：<br>
			 * 3、第二次复核
			 * 
			 */
			try {
				// createOperator/firOperator/secOperator
				service.checkPayout(bi.getBatchCode(), "741258", "第二拒绝", BatchStatus.SEC_CHECK_PASS);
			} catch (Exception ex) {
				logger.error("", ex);
			}
		}
	}

	@Test
	public void testCMB() {
		List<String> payoutNoList = new ArrayList<String>();
		try {
			List<PayoutEditor> payoutEditorList = new ArrayList<PayoutEditor>();

			/************************** 招行 ***************************/
			PayoutEditor editor = new PayoutEditor();
			editor.setAmt(2);
			editor.setCreateDate(new Date());
			editor.setMsgFlag(YNFlag.N);
			editor.setPayeeAcctAddr("地址1");
			editor.setPayeeAcctCity("");
			editor.setPayeeAcctName("唐曾");
			editor.setPayeeAcctNo("6225885710000027");
			editor.setPayeeAcctProvince("");
			editor.setPayeeAcctType(AcctType.COMPANY);
			editor.setPayeeBranchCode("");
			editor.setPayeeEmail("test@163.com");
			editor.setPayeeMobile("1311111111");
			editor.setPayeeOrgCode(BankCode.CMB);
			editor.setRemark("备注1");
			editor.setRemitMethod(RemitMethod.COMMON);
			editor.setSaveColtCompFlag(YNFlag.N);
			editor.setSummary("摘要1");
			editor.setUseDesc("代发");
			editor.setPayeeBranchName("招商银行股份有限公司杭州凤起支行");
			editor.setPayeeAcctProvinceName("浙江省");
			editor.setPayeeAcctCityName("杭州市");
			editor.setExpectPayDate(new Date());
			editor.setSystemSource(SystemSource.COD);
			editor.setTradeOutNo(CUID.generateId4B2E(20));

			payoutEditorList.add(editor);

			PayoutEditor editor1 = new PayoutEditor();
			editor1.setAmt(1);
			editor1.setCreateDate(new Date());
			editor1.setMsgFlag(YNFlag.Y);
			editor1.setPayeeAcctAddr("地址2");
			editor1.setPayeeAcctCity("");
			editor1.setPayeeAcctName("土豆");
			editor1.setPayeeAcctNo("6225885750000028");
			editor1.setPayeeAcctProvince("");
			editor1.setPayeeAcctType(AcctType.PERSON);
			editor1.setPayeeBranchCode("");
			editor1.setPayeeEmail("test@163.com");
			editor1.setPayeeMobile("1311111111");
			editor1.setPayeeOrgCode(BankCode.CMB);
			editor1.setRemark("备注2");
			editor1.setRemitMethod(RemitMethod.COMMON);
			editor1.setSaveColtCompFlag(YNFlag.N);
			editor1.setSummary("摘要2");
			editor1.setUseDesc("代发");
			editor1.setPayeeBranchName("招商银行股份有限公司杭州分行");
			editor1.setPayeeAcctProvinceName("浙江省");
			editor1.setPayeeAcctCityName("杭州市");
			editor1.setTradeOutNo(CUID.generateId4B2E(20));
			editor1.setSystemSource(SystemSource.COD);
			payoutEditorList.add(editor1);

			List<PayoutEditor> payoutEditorResp = service.createPayout(payoutEditorList);
			for (PayoutEditor resp : payoutEditorResp) {
				logger.debug("payoutNo: {}", resp.getPayoutNo());
				payoutNoList.add(resp.getPayoutNo());
			}
		} catch (Exception ex) {
			logger.error("", ex);
		}

		// 生成批次
		BatchInfo bi = null;
		try {
			bi = service.createBatch("CMB_1001", "654895", payoutNoList);
			logger.debug("批次号: {}", bi.getBatchCode());
		} catch (Exception ex) {
			logger.error("", ex);
		}

		/**
		 * 方法说明：<br>
		 * 3、第一次复核
		 */
		try {
			// createOperator/firOperator/secOperator
			service.checkPayout(bi.getBatchCode(), "123456", "dd", BatchStatus.FIR_CHECK_REFUSE);
		} catch (Exception ex) {
			logger.error("", ex);
		}

		/**
		 * 方法说明：<br>
		 * 3、第二次复核
		 */
		try {
			// createOperator/firOperator/secOperator
			service.checkPayout(bi.getBatchCode(), "741258", "dd", BatchStatus.SEC_CHECK_PASS);
		} catch (Exception ex) {
			logger.error("", ex);
		}

	}
	
	/**
	 * 方法说明：<br>
	 *测试批量生成批次信息
	 */
	@Test
	public void testCreateBatchPayout() {
		try {
			List<String> payoutNoList = new ArrayList<String>();
			payoutNoList.add("1309040000001021");
			payoutNoList.add("1309040000001022");
			payoutNoList.add("1309050000001023");
			service.createBatchPayout("ICBC_1000", "xp", payoutNoList);
		} catch (Exception e) {
			logger.info("", e);
		}

	}

	@Test
	public void testqueryForCheckTotalBatch() {
		try {
			PayoutForCheckTotalBatchQueryParam param = new PayoutForCheckTotalBatchQueryParam();
			param.setBatchCode("2013090500001007");
			IPage<TotalBatchInfo> pages = payoutQueryService.queryForCheckTotalBatch(param, 1, 1);
			Object[] objs = pages.getData().toArray();
			TotalBatchInfo tbatch = (TotalBatchInfo) objs[0];
			logger.info("取到批次号：" + tbatch.getTotalBatchCode());
			logger.info("总记录条数：" + tbatch.getTotalBatchCnt());
			logger.info("总金额:" + tbatch.getTotalBatchAmt());
		} catch (Exception e) {
			logger.info("", e);
		}
	}

	@Test
	public void testQueryPageByTotalBatch() {
		try {
			PayoutQueryParam param = new PayoutQueryParam();
			param.setTotalBatchCode("2013090500001007");
			IPage<PayoutQueryRlt> dtls = payoutQueryService.queryPageByTotalBatch(param, 1, 20);
			Object[] objs = dtls.getData().toArray();

			logger.info("取到{}条明细记录!", dtls.getSize());
			for (Object obj : objs) {
				PayoutQueryRlt info = (PayoutQueryRlt) obj;
				logger.info(info.getBatchCode());
			}
		} catch (Exception e) {
			logger.info("", e);
		}
	}

	@Test
	public void testCheckPayOutByTotalBatch() {
		try {
			service.batchCheckPayout("2013090500001007", "xp1", "", BatchStatus.SEC_CHECK_PASS);
		} catch (Exception e) {
			logger.info("", e);
		}
	}
	
	
}
