package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.dao.IPayBusinessDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.OfflineConfirm;
import com.sfpay.acquirer.domain.PayoutExchange;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutOfflineQueryParam;
import com.sfpay.acquirer.domain.PayoutQueryRlt;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.OfflineType;
import com.sfpay.acquirer.service.IPayoutExchangeService;
import com.sfpay.acquirer.service.IPayoutOfflineService;
import com.sfpay.acquirer.service.SendPayoutResp;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 
 * 类说明：<br>
 * 人工操作测试类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-9-7
 */
public class PayoutOfflineServiceImplTest extends ClassTransactionalTestCase{
	
	@Resource
	private IPayoutOfflineService service;

	/**
	 * 方法说明：
	 * 分页查询未人工操作的付款明细信息
	 * @param param 参数
	 * @param pageNo 当前页
	 * @param pageSize 每页显示数
	 * @return
	 * @throws ServiceException
	 */
	@Test
	public void queryPayoutOfflinePage() throws ServiceException{
		PayoutOfflineQueryParam param = new PayoutOfflineQueryParam();
		
		try{
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "countOfflinePayoutPage",11111l);
			service.queryPayoutOfflinePage(param, 0, 11111);
		}catch(Exception ex){
			logger.error("",ex);
		}
	}


	/**
	* 线下确认（线下付款确认、失败确认）
	* @param ls   人工操作对象集合
	* 
	*/
	@Test
	public void doConfirmOffline() throws ServiceException{
		List<OfflineConfirm> ls = new ArrayList<OfflineConfirm>();
		OfflineConfirm con = new OfflineConfirm();
		
		try{
			service.doConfirmOffline(null);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			ls = new ArrayList<OfflineConfirm>();
			con = new OfflineConfirm();
			con.setPayoutNo("1309070000001050");
			con.setOfflineOper("456");
			ls.add(con);
			
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_SUCCESS);
			con.setPayoutNo("1309070000001049");
			ls.add(con);
			
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_SUCCESS);
			con.setPayoutNo("1309070000001049");
			con.setOfflineOper("456");
			ls.add(con);
			
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_FAILURE);
			con.setPayoutNo("1309070000001049");
			con.setOfflineOper("456");
			ls.add(con);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updateOfflineInfo", new Exception(""));
			service.doConfirmOffline(ls);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			ls = new ArrayList<OfflineConfirm>();
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_SUCCESS);
			con.setPayoutNo("1309070000001049");
			con.setOfflineOper("456");
			ls.add(con);
			
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_FAILURE);
			con.setPayoutNo("1309070000001049");
			con.setOfflineOper("456");
			ls.add(con);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updateOfflineInfo", 1111l);
			service.doConfirmOffline(ls);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			ls = new ArrayList<OfflineConfirm>();
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_SUCCESS);
			con.setPayoutNo("1309070000001049");
			con.setOfflineOper("456");
			ls.add(con);
			
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_FAILURE);
			con.setPayoutNo("1309070000001049");
			con.setOfflineOper("456");
			ls.add(con);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updateOfflineInfo", 0l);
			service.doConfirmOffline(ls);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		
		try{
			ls = new ArrayList<OfflineConfirm>();
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_SUCCESS);
			con.setPayoutNo("1309070000001049");
			con.setOfflineOper("456");
			ls.add(con);
			
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_FAILURE);
			con.setPayoutNo("1309070000001049");
			con.setOfflineOper("456");
			ls.add(con);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updateOfflineInfo", 1111l);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "queryByPayoutNos", new Exception(""));
			service.doConfirmOffline(ls);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			ls = new ArrayList<OfflineConfirm>();
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_SUCCESS);
			con.setPayoutNo("1309070000001049");
			con.setOfflineOper("456");
			ls.add(con);
			
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_FAILURE);
			con.setPayoutNo("1309070000001049");
			con.setOfflineOper("456");
			ls.add(con);
			List<PayoutInfo> payoutInfos = new ArrayList<PayoutInfo>();
			PayoutInfo payoutInfo = new PayoutInfo();
			payoutInfos.add(payoutInfo);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updateOfflineInfo", 1111l);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "queryByPayoutNos", payoutInfos); 
			MockCurrentResult.setMockValue(SendPayoutResp.class, "sendBounceResp", new Exception(""));
			service.doConfirmOffline(ls);
		}catch(Exception ex){
			logger.error("",ex);
		}
	
	}

	/**
	 * 执行退票
	 * @param payoutNos  付款编号集合
	 * 
	 */
	@Test
	public void doBouncePayout() throws ServiceException{
		List<OfflineConfirm> ls = new ArrayList<OfflineConfirm>();
		OfflineConfirm con = new OfflineConfirm();
		
		try{
			service.doBouncePayout(null);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_BOUNCE);
			con.setOfflineOper("123");
			con.setOfflineRemark("111111111111111");
			ls.add(con);
			
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_BOUNCE);
			con.setPayoutNo("1309060000001032");
			con.setOfflineRemark("111111111111111");
			ls.add(con);
			service.doBouncePayout(ls);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_BOUNCE);
			con.setPayoutNo("1309100000001071");
			con.setOfflineRemark("111111111111111");
			con.setOfflineOper("123");
			ls.add(con);
			
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_BOUNCE);
			con.setPayoutNo("1309060000001032");
			con.setOfflineRemark("111111111111111");
			con.setOfflineOper("123456");
			ls.add(con); 
			MockCurrentResult.setMockValue(IPayoutExchangeService.class, "queryExchange", null);
			service.doBouncePayout(ls);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_BOUNCE);
			con.setPayoutNo("1309100000001071");
			con.setOfflineRemark("111111111111111");
			con.setOfflineOper("123");
			ls.add(con);
			
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_BOUNCE);
			con.setPayoutNo("1309060000001032");
			con.setOfflineRemark("111111111111111");
			con.setOfflineOper("123456");
			ls.add(con);
			List<PayoutExchange> ecList = new ArrayList<PayoutExchange>();
			PayoutExchange payoutExchange = new PayoutExchange();
			ecList.add(payoutExchange);
			payoutExchange = new PayoutExchange();
			ecList.add(payoutExchange);
			MockCurrentResult.setMockValue(IPayoutExchangeService.class, "queryExchange", ecList);
			MockCurrentResult.setMockValue(IPayoutInfoDao .class, "updateOfflineInfo", new Exception(""));
			service.doBouncePayout(ls);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_BOUNCE);
			con.setPayoutNo("1309100000001071");
			con.setOfflineRemark("111111111111111");
			con.setOfflineOper("123");
			ls.add(con);
			
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_BOUNCE);
			con.setPayoutNo("1309060000001032");
			con.setOfflineRemark("111111111111111");
			con.setOfflineOper("123456");
			ls.add(con);
			List<PayoutExchange> ecList = new ArrayList<PayoutExchange>();
			PayoutExchange payoutExchange = new PayoutExchange();
			ecList.add(payoutExchange);
			payoutExchange = new PayoutExchange();
			ecList.add(payoutExchange);
			MockCurrentResult.setMockValue(IPayoutExchangeService.class, "queryExchange", ecList);
			MockCurrentResult.setMockValue(IPayoutInfoDao .class, "updateOfflineInfo", 0);
			service.doBouncePayout(ls);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_BOUNCE);
			con.setPayoutNo("1309100000001071");
			con.setOfflineRemark("111111111111111");
			con.setOfflineOper("123");
			ls.add(con);
			
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_BOUNCE);
			con.setPayoutNo("1309060000001032");
			con.setOfflineRemark("111111111111111");
			con.setOfflineOper("123456");
			ls.add(con);
			List<PayoutExchange> ecList = new ArrayList<PayoutExchange>();
			PayoutExchange payoutExchange = new PayoutExchange();
			ecList.add(payoutExchange);
			payoutExchange = new PayoutExchange();
			ecList.add(payoutExchange);
			MockCurrentResult.setMockValue(IPayoutExchangeService.class, "queryExchange", ecList);
			MockCurrentResult.setMockValue(IPayoutInfoDao .class, "updateOfflineInfo", 11);
			service.doBouncePayout(ls);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_BOUNCE);
			con.setPayoutNo("1309100000001071");
			con.setOfflineRemark("111111111111111");
			con.setOfflineOper("123");
			ls.add(con);
			
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_BOUNCE);
			con.setPayoutNo("1309060000001032");
			con.setOfflineRemark("111111111111111");
			con.setOfflineOper("123456");
			ls.add(con);
			List<PayoutExchange> ecList = new ArrayList<PayoutExchange>();
			PayoutExchange payoutExchange = new PayoutExchange();
			ecList.add(payoutExchange);
			payoutExchange = new PayoutExchange();
			ecList.add(payoutExchange);
			MockCurrentResult.setMockValue(IPayoutExchangeService.class, "queryExchange", ecList);
			MockCurrentResult.setMockValue(IPayoutInfoDao .class, "updateOfflineInfo", 11);
			MockCurrentResult.setMockValue(IPayoutInfoDao .class, "queryByPayoutNos", new Exception(""));
			service.doBouncePayout(ls);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_BOUNCE);
			con.setPayoutNo("1309100000001071");
			con.setOfflineRemark("111111111111111");
			con.setOfflineOper("123");
			ls.add(con);
			
			con = new OfflineConfirm();
			con.setOfflineType(OfflineType.OFFLINE_BOUNCE);
			con.setPayoutNo("1309060000001032");
			con.setOfflineRemark("111111111111111");
			con.setOfflineOper("123456");
			ls.add(con);
			List<PayoutExchange> ecList = new ArrayList<PayoutExchange>();
			PayoutExchange payoutExchange = new PayoutExchange();
			ecList.add(payoutExchange);
			payoutExchange = new PayoutExchange();
			ecList.add(payoutExchange);
			MockCurrentResult.setMockValue(IPayoutExchangeService.class, "queryExchange", ecList);
			MockCurrentResult.setMockValue(IPayoutInfoDao .class, "updateOfflineInfo", 11);
			MockCurrentResult.setMockValue(IPayoutInfoDao .class, "queryByPayoutNos", null);
			MockCurrentResult.setMockValue(SendPayoutResp  .class, "sendBounceResp", new Exception(""));
			service.doBouncePayout(ls);
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
}
