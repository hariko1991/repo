package com.sfpay.acquirer.task;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.framework.web.test.SpringTestCase;

public class SZFSReconBounceTaskTest extends SpringTestCase  {

	@Resource
	private SZFSReconBounceTask task;

	@Test
	public void testExecute(){
		try {
			task.execute();
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
}
