package com.sfpay.acquirer.dao;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.domain.EnumTypeInfoDTO;
import com.sfpay.framework.web.test.SpringTestCase;

public class EnumTypeInfoDAOTest extends SpringTestCase {
	private static Logger logger = LoggerFactory.getLogger(EnumTypeInfoDAOTest.class);
	@Resource
	private IEnumTypeInfoDao enumTypeInfoDao;
	@Test
	public void queryByTypeTest(){
		List<EnumTypeInfoDTO> list = enumTypeInfoDao.queryByType("useDesc");
		logger.debug("{}", list);
	}
}
