/**
 * 
 */
package com.sfpay.acquirer.dao;

import javax.annotation.Resource;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

import com.sfpay.acquirer.domain.paycenter.ApproveListInfo;
import com.sfpay.acquirer.domain.paycenter.ApproveListParam;
import com.sfpay.framework.web.test.SpringTestCase;


public class PayApproveDaoTest extends SpringTestCase {
	
	@SuppressWarnings("unused")
	private static Logger logger = LoggerFactory.getLogger(PayApproveDaoTest.class);
	
	@Resource
	private IApproveListDao dao;
	
	
	
	@Test
	public void testQueryApproveListPageCount(){
		ApproveListParam param = new ApproveListParam();
		param.setUsername("000000");
		param.setAcctSetNo("ALL");
		try { 
			dao.queryApproveListPageCount(param);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testqueryApproveListByPage(){
		ApproveListParam param = new ApproveListParam();
		param.setUsername("000000");
		param.setAcctSetNo("ALL");
		try { 
			dao.queryApproveListByPage(param, 0, 11);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testQueryApproveListById(){
		try { 
			dao.queryApproveListById(1l);		dao.queryApproveListById(1l);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testDelApproveList(){
		try { 
			dao.delApproveList(1l);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	
	@Test
	public void testUpdateApproveListById(){
		ApproveListInfo approveList = new ApproveListInfo();
		approveList.setUsername("002771");
		approveList.setAcctSetNo("ALL");
		approveList.setRemark("我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我我");
		try { 
			dao.updateApproveListById(approveList);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testAddApproveListInfo(){
		ApproveListInfo approveList = new ApproveListInfo();
		approveList.setAcctSetFlag("1");
		approveList.setUsername("605236");
		approveList.setRealName("王八");
		approveList.setAcctSetNo("a333");
		try { 
			dao.addApproveList(approveList);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testQueryApproveListByAcctSetNo(){
		ApproveListInfo approveList = new ApproveListInfo();
		approveList.setAcctSetFlag("1");
		approveList.setUsername("1");
		approveList.setAcctSetNo("ALL");
		try { 
			dao.queryApproveListByAcctSetNo(approveList);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	
	@Test
	public void testQueryApproveListByAcctSetFlag(){
		ApproveListInfo approveList = new ApproveListInfo();
		approveList.setAcctSetFlag("1");
		approveList.setUsername("000000");
		approveList.setAcctSetNo("ALL");
		try { 
			//dao.queryApproveListByAcctSetFlag(approveList);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testUpdateApproveListDelete(){
		ApproveListInfo approveList = new ApproveListInfo();
		approveList.setAcctSetFlag("1");
		approveList.setUsername("1");
		approveList.setAcctSetNo("ALL");
		try { 
			dao.updateApproveListDelete(approveList);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testQueryApproveListByAcctSetNoAgain(){
		ApproveListInfo approveList = new ApproveListInfo();
		approveList.setAcctSetFlag("1");
		approveList.setUsername("1");
		approveList.setAcctSetNo("ALL");
		try { 
			dao.queryApproveListByAcctSetNoAgain(approveList);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testUpdateApproveListDeleteById(){
		try { 
			dao.updateApproveListDeleteById(1L);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testUpdateApproveListDeleteByUsername(){
		ApproveListInfo approveList = new ApproveListInfo();
		approveList.setUsername("000000");
		try { 
			dao.updateApproveListDeleteByUsername(approveList);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testQueryApproveListByAcctSetNoThird(){
		ApproveListInfo approveList = new ApproveListInfo();
		approveList.setAcctSetFlag("1");
		approveList.setUsername("1");
		approveList.setAcctSetNo("ALL");
		try { 
			dao.queryApproveListByAcctSetNoThird(approveList);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testCheckAcctSetNo(){
		ApproveListInfo approveList = new ApproveListInfo();
		approveList.setAcctSetFlag("1");
		approveList.setUsername("1");
		approveList.setAcctSetNo("ALL");
		try { 
			dao.checkAcctSetNo(approveList);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testQueryApproveListInfoByAll(){
		ApproveListInfo param = new ApproveListInfo();
		param.setUsername("000000");
		param.setAcctSetNo("ALL");
		try { 
			dao.queryApproveListInfoByAll(param);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	
}
