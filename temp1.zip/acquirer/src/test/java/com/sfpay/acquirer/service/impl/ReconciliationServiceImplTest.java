/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.ICollectInfoDao;
import com.sfpay.acquirer.service.IReconciliationService;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;
import com.sfpay.pubcenter.domain.BaseParam;
import com.sfpay.pubcenter.service.IConfigruationCenter;

/**
 * 
 * 类说明：
 *  
 * 
 * <p>
 * 详细描述：
 *   
 * 
 * @author 271762
 * @author 329202 符瑜鑫(Ricky Fu)
 *   
 * CreateDate: 2012-4-20
 */
public class ReconciliationServiceImplTest extends ClassTransactionalTestCase  {

	@Resource
	private IReconciliationService service;
	
	@Test
	public void testCreateFiles(){
		MockCurrentResult.setMockValue(ICollectInfoDao.class, "countRecon",10l);
		Map<String, BaseParam> paramMap =new HashMap<String ,BaseParam>();
		BaseParam param1=new BaseParam();
		param1.setParamValue("/test/acq");
		BaseParam param2=new BaseParam();
		param2.setParamValue("192.168.7.90");
		BaseParam param3=new BaseParam();
		param3.setParamValue("8080");
		BaseParam param4=new BaseParam();
		param4.setParamValue("admin");
		BaseParam param5=new BaseParam();
		param5.setParamValue("123456");
		BaseParam param6=new BaseParam();
		param6.setParamValue("/test/acq");
		BaseParam param7=new BaseParam();
		param7.setParamValue("52458");
		BaseParam param8=new BaseParam();
		param8.setParamValue("568784");
		paramMap.put("acqLocalPath1",param1);
		paramMap.put("fileSysIp",param2);
		paramMap.put("fileSysPort",param3);
		paramMap.put("fileSysUser",param4);
		paramMap.put("fileSysPass",param5);
		paramMap.put("acqRemotePath",param6);
		paramMap.put("fileSize",param7);
		paramMap.put("fetchSize	",param8);
		MockCurrentResult.setMockValue(IConfigruationCenter.class, "findParamBySystemName",paramMap);
		try {
			service.createFiles("2013-08-27");
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	
	@Test
	public void testCreateFiles1(){
		service.createFiles();
		
	}
}
