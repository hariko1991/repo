/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.dao.ICollectInfoDao;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.CollectInfo;
import com.sfpay.acquirer.domain.InCollectInfo;
import com.sfpay.acquirer.domain.PaymentParam;
import com.sfpay.acquirer.domain.PaymentReq;
import com.sfpay.acquirer.domain.PaymentResp;
import com.sfpay.acquirer.domain.PaymentResult;
import com.sfpay.acquirer.domain.SFPayBank;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.CardType;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.CollectStatus;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.acquirer.enums.SystemSource;
import com.sfpay.acquirer.gate.IPayment;
import com.sfpay.acquirer.service.ICollectInfoService;
import com.sfpay.acquirer.service.ISFPayBankService;
import com.sfpay.coreplatform.order.service.IBankPayService;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 类说明：收单信息测试类
 *  
 * <p>
 * 详细描述：
 *   
 * @author 271762
 * @author 329202 符瑜鑫(Ricky Fu)
 *   
 * CreateDate: 2012-3-16
 */
public class CollectInfoServiceImplTest extends ClassTransactionalTestCase {
	@Resource
	private ICollectInfoService service;
	
	@Test
	public void testCreateInCollect(){
		long curMill = System.currentTimeMillis();
		PaymentParam result = null;
		InCollectInfo in = new InCollectInfo();
		in.setBankCode(BankCode.ICBC);
		in.setChannelCode(ChannelCode.B2C);
		in.setOrderType(OrderType.RECHARGE);
		in.setTradeNo("T"+curMill);
		in.setPayNo("P"+curMill);
		in.setBusinessSn("B"+curMill);
		in.setPayerMemberNo(20147979991953L);
		in.setResultUrl("http://localhost:8080/acquirer/{0}/test/bankResp");
		in.setAmt(100L);
		in.setCcy(CurrencyType.RMB);
		in.setCardType(CardType.CREDIT);
		PaymentReq retObj=new PaymentReq ();
		retObj.setCollectNo("123213213213");
		retObj.setSerieNo("1233546789");
		retObj.setAction("HelloAction");
		MockCurrentResult.setMockValue(IPayment.class, "send",retObj);
		try {
			result = service.createInCollect(in);
			logger.info( null == result ? "" : result.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testCreatePaymentByB2C() {
		long curMill = System.currentTimeMillis();
		InCollectInfo in = new InCollectInfo();
		
		try {
			PaymentReq retObj=new PaymentReq ();
			retObj.setCollectNo("123213213213");
			retObj.setSerieNo("1233546789");
			retObj.setAction("HelloAction");
			MockCurrentResult.setMockValue(IPayment.class, "send",retObj);
			service.createPaymentByB2C(null);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			in = new InCollectInfo();
			in.setSystemSource(SystemSource.SYPAY);
			PaymentReq retObj=new PaymentReq ();
			retObj.setCollectNo("123213213213");
			retObj.setSerieNo("1233546789");
			retObj.setAction("HelloAction");
			MockCurrentResult.setMockValue(IPayment.class, "send",retObj);
			service.createPaymentByB2C(in);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			in = new InCollectInfo();
			PaymentReq retObj=new PaymentReq ();
			in.setSystemSource(SystemSource.FBS);
			in.setBankCode(BankCode.ABC);
			retObj.setCollectNo("123213213213");
			retObj.setSerieNo("1233546789");
			retObj.setAction("HelloAction");
			MockCurrentResult.setMockValue(IPayment.class, "send",retObj);
			service.createPaymentByB2C(in);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			in = new InCollectInfo();
			PaymentReq retObj=new PaymentReq ();
			in.setSystemSource(SystemSource.FBS);
			in.setBankCode(BankCode.YEEPAY);
			retObj.setCollectNo("123213213213");
			retObj.setSerieNo("1233546789");
			retObj.setAction("HelloAction");
			MockCurrentResult.setMockValue(IPayment.class, "send",retObj);
			service.createPaymentByB2C(in);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			in = new InCollectInfo();
			in.setSystemSource(SystemSource.SYPAY);
			in.setOriBankCode("ABC");
			PaymentReq retObj=new PaymentReq ();
			retObj.setCollectNo("123213213213");
			retObj.setSerieNo("1233546789");
			retObj.setAction("HelloAction");
			MockCurrentResult.setMockValue(IPayment.class, "send",retObj);
			service.createPaymentByB2C(in);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			in = new InCollectInfo();
			in.setSystemSource(SystemSource.SYPAY);
			in.setOriBankCode("ABC");
			in.setChannelCode(ChannelCode.B2C);
			PaymentReq retObj=new PaymentReq ();
			retObj.setCollectNo("123213213213");
			retObj.setSerieNo("1233546789");
			retObj.setAction("HelloAction");
			MockCurrentResult.setMockValue(IPayment.class, "send",retObj);
			service.createPaymentByB2C(in);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			in = new InCollectInfo();
			in.setSystemSource(SystemSource.SYPAY);
			in.setOriBankCode("ABC");
			in.setChannelCode(ChannelCode.B2C);
			in.setOrderType(OrderType.CANCEL);
			PaymentReq retObj=new PaymentReq ();
			retObj.setCollectNo("123213213213");
			retObj.setSerieNo("1233546789");
			retObj.setAction("HelloAction");
			MockCurrentResult.setMockValue(IPayment.class, "send",retObj);
			service.createPaymentByB2C(in);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			in = new InCollectInfo();
			in.setSystemSource(SystemSource.SYPAY);
			in.setOriBankCode("ABC");
			in.setChannelCode(ChannelCode.B2C);
			in.setOrderType(OrderType.CANCEL);
			in.setTradeNo("111111111");
			PaymentReq retObj=new PaymentReq ();
			retObj.setCollectNo("123213213213");
			retObj.setSerieNo("1233546789");
			retObj.setAction("HelloAction");
			MockCurrentResult.setMockValue(IPayment.class, "send",retObj);
			service.createPaymentByB2C(in);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			in = new InCollectInfo();
			in.setSystemSource(SystemSource.SYPAY);
			in.setOriBankCode("ABC");
			in.setChannelCode(ChannelCode.B2C);
			in.setOrderType(OrderType.CANCEL);
			in.setTradeNo("111111111");
			in.setPayNo("11111");
			PaymentReq retObj=new PaymentReq ();
			retObj.setCollectNo("123213213213");
			retObj.setSerieNo("1233546789");
			retObj.setAction("HelloAction");
			MockCurrentResult.setMockValue(IPayment.class, "send",retObj);
			service.createPaymentByB2C(in);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			in = new InCollectInfo();
			in.setSystemSource(SystemSource.SYPAY);
			in.setOriBankCode("ABC");
			in.setChannelCode(ChannelCode.B2C);
			in.setOrderType(OrderType.CANCEL);
			in.setTradeNo("111111111");
			in.setPayNo("11111");
			in.setBusinessSn("11111111");
			PaymentReq retObj=new PaymentReq ();
			retObj.setCollectNo("123213213213");
			retObj.setSerieNo("1233546789");
			retObj.setAction("HelloAction");
			MockCurrentResult.setMockValue(IPayment.class, "send",retObj);
			service.createPaymentByB2C(in);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			in = new InCollectInfo();
			in.setBankCode(BankCode.ICBC);
			in.setChannelCode(ChannelCode.B2C);
			in.setOrderType(OrderType.RECHARGE);
			in.setTradeNo("T"+curMill);
			in.setPayNo("P"+curMill);
			in.setBusinessSn("B"+curMill);
			in.setPayerMemberNo(20147979991953L);
			in.setResultUrl("http://localhost:8080/acquirer/{0}/test/bankResp");
			in.setAmt(100L);
			in.setCcy(CurrencyType.RMB);
			in.setCardType(CardType.CREDIT);
			PaymentReq retObj=new PaymentReq ();
			retObj.setCollectNo("123213213213");
			retObj.setSerieNo("1233546789");
			retObj.setAction("HelloAction");
			MockCurrentResult.setMockValue(IPayment.class, "send",retObj);
			service.createPaymentByB2C(in);
			
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			in = new InCollectInfo();
			in.setSystemSource(SystemSource.SYPAY);
			in.setBankCode(BankCode.ICBC);
			in.setChannelCode(ChannelCode.B2C);
			in.setOrderType(OrderType.RECHARGE);
			in.setTradeNo("T"+curMill);
			in.setPayNo("P"+curMill);
			in.setBusinessSn("B"+curMill);
			in.setPayerMemberNo(20147979991953L);
			in.setResultUrl("http://localhost:8080/acquirer/{0}/test/bankResp");
			in.setAmt(100L);
			in.setCcy(CurrencyType.RMB);
			in.setCardType(CardType.CREDIT);
			PaymentReq retObj=new PaymentReq ();
			retObj.setCollectNo("123213213213");
			retObj.setSerieNo("1233546789");
			retObj.setAction("HelloAction");
			MockCurrentResult.setMockValue(ISFPayBankService.class, "findSFPayBank",new Exception(""));
			MockCurrentResult.setMockValue(IPayment.class, "send",retObj);
			service.createPaymentByB2C(in);
			
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			in = new InCollectInfo();
			in.setSystemSource(SystemSource.SYPAY);
			in.setBankCode(BankCode.ICBC);
			in.setChannelCode(ChannelCode.B2C);
			in.setOrderType(OrderType.RECHARGE);
			in.setTradeNo("T"+curMill);
			in.setPayNo("P"+curMill);
			in.setBusinessSn("B"+curMill);
			in.setPayerMemberNo(20147979991953L);
			in.setResultUrl("http://localhost:8080/acquirer/{0}/test/bankResp");
			in.setAmt(100L);
			in.setCcy(CurrencyType.RMB);
			in.setCardType(CardType.CREDIT);
			PaymentReq retObj=new PaymentReq ();
			retObj.setCollectNo("123213213213");
			retObj.setSerieNo("1233546789");
			retObj.setAction("HelloAction");
			MockCurrentResult.setMockValue(ISFPayBankService.class, "findSFPayBank",null);
			MockCurrentResult.setMockValue(IPayment.class, "send",retObj);
			service.createPaymentByB2C(in);
			
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			in = new InCollectInfo();
			in.setSystemSource(SystemSource.SYPAY);
			in.setBankCode(BankCode.ICBC);
			in.setChannelCode(ChannelCode.B2C);
			in.setOrderType(OrderType.RECHARGE);
			in.setTradeNo("T"+curMill);
			in.setPayNo("P"+curMill);
			in.setBusinessSn("B"+curMill);
			in.setPayerMemberNo(20147979991953L);
			in.setResultUrl("http://localhost:8080/acquirer/{0}/test/bankResp");
			in.setAmt(100L);
			in.setCcy(CurrencyType.RMB);
			in.setCardType(CardType.CREDIT);
			PaymentReq retObj=new PaymentReq ();
			retObj.setCollectNo("123213213213");
			retObj.setSerieNo("1233546789");
			retObj.setAction("HelloAction");
			SFPayBank  sFPayBank  = new SFPayBank();
			sFPayBank.setBankCode(BankCode.ABC);
			sFPayBank.setCoverBankCode("aa");
			MockCurrentResult.setMockValue(ISFPayBankService.class, "findSFPayBank",sFPayBank);
			MockCurrentResult.setMockValue(IPayment.class, "send",retObj);
			service.createPaymentByB2C(in);
			
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testUpdateBankResp() {
		String collectNo = "1310080000001165";
//		Map<String, String[]> param = new HashMap<String, String[]>();
//		param.put("Msg", new String[]{"07551000882012042612242637900000003430"});
//		param.put("Amount", new String[]{"0.01"});
//		param.put("BillNo", new String[]{"7545153185"});
//		param.put("Succeed", new String[]{"Y"});
//		param.put("CoNo", new String[]{"100088"});
//		param.put("MerchantPara", new String[]{"7545153185"});
//		param.put("Signature", new String[]{"117|45|100|46|251|129|103|137|238|71|106|226|46|147|33|64|177|242|117|200|194|178|205|51|112|40|64|3|198|203|76|37|169|92|22|118|181|145|197|242|167|65|76|167|167|36|224|41|1|0|68|155|138|244|178|242|226|217|47|30|175|245|10|84|"});
//		param.put("Date", new String[]{"20120426"});
		
		Map<String, String[]> param = new HashMap<String, String[]>();
		param.put("p1_merid", new String[]{"10011838280"});
		param.put("r0_cmd", new String[]{"buy"});
		param.put("r1_code", new String[]{"1"});
		param.put("r2_trxid", new String[]{"913425128352411i"});
		param.put("r3_amt", new String[]{"300.0"});
		param.put("r4_cur", new String[]{"rmb"});
		param.put("r5_pid", new String[]{""});
		param.put("r6_order", new String[]{"2013120111545861693242965"});
		param.put("r7_uid", new String[]{""});
		param.put("r8_mp", new String[]{""});
		param.put("r9_btype", new String[]{"1"});
		param.put("ru_trxtime", new String[]{"20131201084914"});
		param.put("ro_bankorderid", new String[]{"2298684062131201"});
		param.put("rb_bankid", new String[]{"ccb-net"});
		param.put("rp_paydate", new String[]{"20131201084857"});
		param.put("rq_cardno", new String[]{""});
		param.put("rq_sourcefee", new String[]{"0.0"});
		param.put("rq_targetfee", new String[]{"1.2"});
		param.put("hmac", new String[]{"f2b1688247c6bd3bfcf70ac42a14217e"});
		try {
			PaymentResp resp = service.updateBankResp(collectNo, param);
			logger.info("回传参数: "+ resp.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
		//mock
		
		CollectInfo info=new CollectInfo();
		info.setStatus(CollectStatus.RECEIVED);
		info.setBankCode(BankCode.YEEPAY);
		info.setChannelCode(ChannelCode.B2C);
		MockCurrentResult.setMockValue(ICollectInfoDao.class, "findByCollectNo",info);
		
		PaymentResult rs = new PaymentResult();
		rs.setIgnore(false);
		rs.setRtnBankMsg("hello");
		MockCurrentResult.setMockValue(IPayment.class, "receive",rs);
		try {
			PaymentResp resp = service.updateBankResp(collectNo, param);
			logger.info("回传参数: "+ resp.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
		//mock
		info.setStatus(CollectStatus.INIT);
		MockCurrentResult.setMockValue(ICollectInfoDao.class, "oupdateByReverse",1);
		try {
			PaymentResp resp  = service.updateBankResp(collectNo, param);
			logger.info("回传参数: "+ resp.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testFindAccountByPayNo() {


		try {
			AccountInfo acct = service.findAccountByPayNo("", SystemSource.PORTAL);
			logger.info( acct.toString());
		} catch (Exception e) {
			logger.error("", e);
		}

		try {
			AccountInfo acct = service.findAccountByPayNo("89091381809601292102", null);
			logger.info( acct.toString());
		} catch (Exception e) {
			logger.error("", e);
		}

		CollectInfo  ci=new CollectInfo ();
		try {
			ci.setPayeeOrgCode("111");
			ci.setPayeeOrgName("111");
			ci.setPayeeBranchCode("111");
			ci.setPayeeBranchName("111");
			ci.setPayeeAcctCode("2222");
			ci.setPayeeAcctName("3333");
			ci.setPayeeAcctProvince("4444");
			ci.setPayeeAcctProvinceN("4444");
			ci.setPayeeAcctCity("3333");
			ci.setPayeeAcctCityN("3333");
			MockCurrentResult.setMockValue(ICollectInfoDao.class, "findByPayNo",ci);
			AccountInfo acct = service.findAccountByPayNo("89091381809601292102", SystemSource.PORTAL);
			logger.info( acct.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			ci=new CollectInfo ();
			MockCurrentResult.setMockValue(ICollectInfoDao.class, "findByPayNo",null);
			AccountInfo acct = service.findAccountByPayNo("89091381809601292102", SystemSource.PORTAL);
			logger.info( acct.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			ci=new CollectInfo ();
			MockCurrentResult.setMockValue(ICollectInfoDao.class, "findByPayNo", new Exception(""));
			AccountInfo acct = service.findAccountByPayNo("89091381809601292102", SystemSource.PORTAL);
			logger.info( acct.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testCloseCollectInfo() {
		CollectInfo ci=new CollectInfo();
		 List<CollectInfo> list =new ArrayList<CollectInfo>();
		 list.add(ci);
		MockCurrentResult.setMockValue(ICollectInfoDao.class, "queryCloseCollectInfo",list);
		try {
			List<CollectInfo> ls = service.closeCollectInfo(1);
			logger.info( null == ls ? "0" : ls.size());
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testQueryCollectInfoForCheck() {
		try {
			CollectInfo ci = service.queryCollectInfoForCheck(null, DateUtil.getDateFormatStr("2012-12-5", "yyyy-MM-dd"));
			logger.info( null == ci ? "null" : ci.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			CollectInfo ci = service.queryCollectInfoForCheck("99091281912905057167", null);
			logger.info( null == ci ? "null" : ci.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
		MockCurrentResult.setMockValue(ICollectInfoDao.class, "queryCollectInfoForCheck",new Exception("rest exception"));
		try {
			CollectInfo ci = service.queryCollectInfoForCheck("99091281912905057167", DateUtil.getDateFormatStr("2012-12-5", "yyyy-MM-dd"));
			logger.info( null == ci ? "null" : ci.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testFindByPayNo(){
		try{
			MockCurrentResult.setMockValue(ICollectInfoDao.class, "findByPayNo",10l);
			service.findByPayNo(SystemSource.PORTAL, null);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
		
		try{
			MockCurrentResult.setMockValue(ICollectInfoDao.class, "findByPayNo",10l);
			service.findByPayNo(null, "89091381809601292102");
		}catch(Exception e){
			logger.info(e.getMessage());
		}
		
		try{
			MockCurrentResult.setMockValue(ICollectInfoDao.class, "findByPayNo",10l);
			service.findByPayNo(SystemSource.PORTAL, "89091381809601292102");
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}
	
	@Test
	public void testResupplyByHand(){
		String bussinessSn = "12345678";
		Date tradeDate = new Date();
		String rtnBankMsg = "1234";
		String rtnBankCode = "123";
		
		try{
			service.resupplyByHand(null, tradeDate , rtnBankMsg, rtnBankCode);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
		
		try{
			service.resupplyByHand(bussinessSn, null , rtnBankMsg, rtnBankCode);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
		
		try{
			CollectInfo collectInfo = new CollectInfo();
			collectInfo.setCollectNo("11111");
			collectInfo.setPayNo("2222");
			MockCurrentResult.setMockValue(ICollectInfoDao.class, "queryCollectInfoForCheck",null);
			service.resupplyByHand(bussinessSn, tradeDate , rtnBankMsg, rtnBankCode);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
		
		try{
			CollectInfo collectInfo = new CollectInfo();
			collectInfo.setCollectNo("11111");
			collectInfo.setPayNo("2222");
			MockCurrentResult.setMockValue(ICollectInfoDao.class, "queryCollectInfoForCheck",new Exception(""));
			service.resupplyByHand(bussinessSn, tradeDate , rtnBankMsg, rtnBankCode);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
		
		try{
			CollectInfo collectInfo = new CollectInfo();
			collectInfo.setCollectNo("11111");
			collectInfo.setPayNo("2222");
			MockCurrentResult.setMockValue(ICollectInfoDao.class, "queryCollectInfoForCheck",collectInfo);
			MockCurrentResult.setMockValue(ICollectInfoDao.class, "updateForResupplyByNo",11);
			service.resupplyByHand(bussinessSn, tradeDate , rtnBankMsg, rtnBankCode);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
		
		try{
			CollectInfo collectInfo = new CollectInfo();
			collectInfo.setCollectNo("11111");
			MockCurrentResult.setMockValue(ICollectInfoDao.class, "queryCollectInfoForCheck",collectInfo);
			MockCurrentResult.setMockValue(ICollectInfoDao.class, "updateForResupplyByNo",new Exception(""));
			service.resupplyByHand(bussinessSn, tradeDate , rtnBankMsg, rtnBankCode);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
		
		try{
			CollectInfo collectInfo = new CollectInfo();
			collectInfo.setCollectNo("11111");
			collectInfo.setPayNo("2222");
			MockCurrentResult.setMockValue(ICollectInfoDao.class, "queryCollectInfoForCheck",collectInfo);
			MockCurrentResult.setMockValue(ICollectInfoDao.class, "updateForResupplyByNo",11);
			service.resupplyByHand(bussinessSn, tradeDate , rtnBankMsg, rtnBankCode);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
		
		try{
			CollectInfo collectInfo = new CollectInfo();
			collectInfo.setCollectNo("11111");
			collectInfo.setPayNo("2222");
			MockCurrentResult.setMockValue(ICollectInfoDao.class, "queryCollectInfoForCheck",collectInfo);
			MockCurrentResult.setMockValue(ICollectInfoDao.class, "updateForResupplyByNo",1);
			MockCurrentResult.setMockValue(IBankPayService.class, "netBankPayNotifyByAcq",new Exception(""));
			service.resupplyByHand(bussinessSn, tradeDate , rtnBankMsg, rtnBankCode);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}
	
}
