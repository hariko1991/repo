/**
 * =================================================================
 * 版权所有 2011-2013 深圳市泰海网络科技服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.Date;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IDeductionInfoDao;
import com.sfpay.acquirer.dao.IDeductionLogDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.DeductionQueryParam;
import com.sfpay.acquirer.domain.DeductionQueryRlt;
import com.sfpay.acquirer.domain.NeedDeductionInfo;
import com.sfpay.acquirer.domain.NeedDeductionInfoQueryParam;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutQueryRlt;
import com.sfpay.acquirer.domain.PayoutRlt;
import com.sfpay.acquirer.enums.FreezeFlag;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.service.IDeductionService;
import com.sfpay.acquirer.service.SendPayoutResp;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 类说明：<br>
 * 抵扣业务测试类
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 *  
 * @author 400928 向鹏
 * 
 * CreateDate: 2013-9-10
 */
public class DeductionDerviceImplTest  extends ClassTransactionalTestCase{
	
	@Resource
	IDeductionService deductionService;
	
	
	@Test
	public void testQueryNeedDeduction(){
		try{
			DeductionQueryParam param=new DeductionQueryParam();
			IPage<PayoutQueryRlt> results=deductionService.queryNeedDeduction(param, 1, 10);
		    Object[] objs=results.getData().toArray();
		    for(Object obj:objs){
		    	PayoutQueryRlt rtl=(PayoutQueryRlt)obj;
		    	logger.info(rtl.getPayoutNo());
		    }
		}catch(Exception e){
			logger.info("",e);
		}
	}
	
	@Test
	public void testQueryDeductionInfo(){
		try{
			PayoutRlt rtl=deductionService.queryDeductionInfo("1309100000001068");
		    logger.info("对方账号："+rtl.getPayeeAcctNo());
		    logger.info("对方户名："+rtl.getPayeeAcctName());
		    logger.info("外部单号:"+rtl.getTradeOutNo());
		    logger.info("备注一:"+rtl.getOutDescFir());
		    logger.info("应付金额:"+rtl.getShouldAmt());
			
		}catch(Exception e){
			logger.info("",e);
		}
	}
	
	@Test
	public void testDoDeduction(){
		try{
			deductionService.doDeduction("xp","因账户原因抵扣10分", "1309100000001068",2L,FreezeFlag.N);
			
		}catch(Exception e){
			logger.info("",e);
		}
		
		
		try{
			deductionService.doDeduction("","因账户原因抵扣10分", "1309100000001068",2L,FreezeFlag.N);
			
		}catch(Exception e){
			logger.info("",e);
		}
		
		try{
			deductionService.doDeduction("xp","", "1309100000001068",2L,FreezeFlag.N);
			
		}catch(Exception e){
			logger.info("",e);
		}
		
		try{
			deductionService.doDeduction("xp","因账户原因抵扣10分", "",2L,FreezeFlag.N);
			
		}catch(Exception e){
			logger.info("",e);
		}
		
		try{
			deductionService.doDeduction("xp","因账户原因抵扣10分", "1309100000001068",null,FreezeFlag.N);
			
		}catch(Exception e){
			logger.info("",e);
		}
		
		try{
			deductionService.doDeduction("xp","因账户原因抵扣10分", "1309100000001068",2L,null);
			
		}catch(Exception e){
			logger.info("",e);
		}
		PayoutInfo  payoutRtl= new PayoutInfo();
		payoutRtl.setStatus(PayoutStatus.INIT);
		payoutRtl.setFreezeFlag(FreezeFlag.N);
		payoutRtl.setShouldAmt(100L);
		
		PayoutInfo  payoutRtl2= new PayoutInfo();
		payoutRtl2.setStatus(PayoutStatus.BATCH);
		
		PayoutInfo  payoutRtl3= new PayoutInfo();
		payoutRtl3.setStatus(PayoutStatus.INIT);
		payoutRtl3.setFreezeFlag(FreezeFlag.Y);
		
		PayoutInfo  payoutRtl4= new PayoutInfo();
		payoutRtl4.setStatus(PayoutStatus.INIT);
		payoutRtl4.setFreezeFlag(FreezeFlag.N);
		payoutRtl4.setShouldAmt(2L);
		MockCurrentResult.setMockValue(IPayoutInfoDao.class, "findByPayoutNo",payoutRtl);
		MockCurrentResult.setMockValue(IDeductionLogDao.class, "save", null);
		try{
			deductionService.doDeduction("xp","因账户原因抵扣10分", "1309100000001068",2L,FreezeFlag.N);
			
		}catch(Exception e){
			logger.info("",e);
		}
		MockCurrentResult.setMockValue(IPayoutInfoDao.class, "findByPayoutNo",payoutRtl2);
		try{
			deductionService.doDeduction("xp","因账户原因抵扣10分", "1309100000001068",2L,FreezeFlag.N);
			
		}catch(Exception e){
			logger.info("",e);
		}
		MockCurrentResult.setMockValue(IPayoutInfoDao.class, "findByPayoutNo",payoutRtl3);
		try{
			deductionService.doDeduction("xp","因账户原因抵扣10分", "1309100000001068",2L,FreezeFlag.N);
			
		}catch(Exception e){
			logger.info("",e);
		}
		
		MockCurrentResult.setMockValue(IPayoutInfoDao.class, "findByPayoutNo",payoutRtl4);
		MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updateDeductionInfo",1);
		MockCurrentResult.setMockValue(SendPayoutResp.class, "sendResp",null);
		try{
			deductionService.doDeduction("xp","因账户原因抵扣10分", "1309100000001068",2L,FreezeFlag.N);
			
		}catch(Exception e){
			logger.info("",e);
		}
	}
	
	@Test
	public void testQueryDeductionInfos(){
		MockCurrentResult.setMockValue(IDeductionLogDao.class, "countDeductionInfos",10L);
		try{
			DeductionQueryParam param=new DeductionQueryParam();
			param.setPayeeAcctName("户");
			IPage<DeductionQueryRlt>  results=deductionService.queryDeductionInfos(param, 1, 2);
			Object[] objs=results.getData().toArray();
		    for(Object obj:objs){
		    	PayoutQueryRlt rtl=(PayoutQueryRlt)obj;
		    	logger.info(rtl.getPayoutNo());
		    }
			
		}catch(Exception e){
			logger.info("",e);
		}
	}
	@Test
	public void testDoAddDeductInfo(){
		NeedDeductionInfo  info=new NeedDeductionInfo();
		info.setCustAccNo("1309100000001068");
		info.setCustName("zhangsan");
		info.setDisputeAmt(10L);
		info.setOperatorId("13213");
		info.setRecDay(new Date());
		try{
			deductionService.doAddDeductInfo(info);
		}catch(Exception e){
			logger.info("",e);
		}
		info.setCustAccNo("");
		try{
			deductionService.doAddDeductInfo(info);
		}catch(Exception e){
			logger.info("",e);
		}
		
		
		info.setCustAccNo("1309100000001068");
		info.setCustName("");
		try{
			deductionService.doAddDeductInfo(info);
		}catch(Exception e){
			logger.info("",e);
		}
		
		info.setCustName("zhangsan");
		info.setDisputeAmt(null);
		try{
			deductionService.doAddDeductInfo(info);
		}catch(Exception e){
			logger.info("",e);
		}
		
		info.setDisputeAmt(10L);
		info.setOperatorId("");
		try{
			deductionService.doAddDeductInfo(info);
		}catch(Exception e){
			logger.info("",e);
		}
		
		info.setOperatorId("13213");
		info.setRecDay(null);
		try{
			deductionService.doAddDeductInfo(info);
		}catch(Exception e){
			logger.info("",e);
		}
	}
	@Test
	public void testQueryNeedDeductionInfos(){
		NeedDeductionInfoQueryParam  param=new NeedDeductionInfoQueryParam ();
		MockCurrentResult.setMockValue(IDeductionInfoDao.class, "countNeedDeductionInfos",10L);
		try{
			deductionService.queryNeedDeductionInfos(param,1,10);
		}catch(Exception e){
			logger.info("",e);
		}
		
	}

}
