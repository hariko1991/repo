/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.dao.DataAccessException;

import com.sfpay.acquirer.domain.BatchTotal;
import com.sfpay.acquirer.domain.PayoutForCreateBatchQueryParam;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutQueryParam;
import com.sfpay.acquirer.enums.AcctType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.PayoutDateQueryType;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-8-15
 */
public class PayoutInfoDaoTest extends SpringTestCase {
	
	@Resource
	private IPayoutInfoDao dao;
	
	
	@Test
	public void testQueryByRule(){
	  try{
		PayoutForCreateBatchQueryParam param=new PayoutForCreateBatchQueryParam();
		param.setRuleCode("ICBC_1001");
		param.setAgentFlag(YNFlag.Y);
		List<PayoutInfo> infos=dao.queryByRule(param, PayoutStatus.INIT, AcctType.PERSON, 0, 10,"off");
		System.out.println(infos.size());
	  }catch(Exception e){
		  e.printStackTrace();
	  }
	}
	
	
	
	@Test
	public void testQueryPayoutPage() {
		PayoutQueryParam param = new PayoutQueryParam();
		param.setAccountNo("4000023019200803711");
		param.setBankCode(BankCode.ICBC);
		param.setBankTxSn("0001");
		param.setBatchCode("2013081600001190");
		param.setBeginDate(new Date());
		param.setEndDate(new Date());
		param.setPayoutStatus(PayoutStatus.INIT);
		param.setDateQueryType(PayoutDateQueryType.BY_TRANS);
		try {
			dao.queryPayoutPage(param, 0, 10);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testTotalAmtAndNum() {
		try { 
			BatchTotal total = dao.totalAmtAndNum("2013091000001001");
			logger.debug("{}", total);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testFindPayout(){
		PayoutInfo info = dao.findBankRtn("1606120000279608");
		logger.debug("============================{},{}",info.getRtnBankCode(),info.getRtnBankMsg());
	}
}
