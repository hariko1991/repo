/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.dao.DataAccessException;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.domain.PayoutEditor;
import com.sfpay.acquirer.domain.paycenter.MerInfo;
import com.sfpay.acquirer.domain.paycenter.MerInfoParam;
import com.sfpay.acquirer.domain.paycenter.PaymentTranInfoParam;
import com.sfpay.acquirer.domain.paycenter.PayoutReqInfo;
import com.sfpay.acquirer.domain.paycenter.PayoutReqInfoView;
import com.sfpay.acquirer.enums.AcctType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.PayCenterPayStatus;
import com.sfpay.acquirer.enums.PayoutType;
import com.sfpay.acquirer.enums.RemitMethod;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 400928 向鹏
 * 
 * CreateDate: 2014-3-25
 */
public class PayBusinessDaoTest extends SpringTestCase{
	
	@Resource
	private IPayBusinessDao payBusinessDao;
	
	@Resource
	private IMerInfoDao merInfoDao;
	
	@Test
	public void testApprovePayInfoByFir(){
		try { 
			payBusinessDao.approvePayInfoByFir("test","test",1020L,PayCenterPayStatus.FIR_APPROVE_PASS);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
		System.out.println("END ...........");
	}
	
	@Test
	public void testUpdateStatus(){
		try{
		payBusinessDao.updateStatus(1116L,PayCenterPayStatus.FAILURE,"",new Date());
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	@Test
	public void testQueryPayoutReqInfoById(){
		try{
			  PayoutReqInfoView view=payBusinessDao.queryPayoutReqInfoById(1400L);
			  PayoutEditor pe=convert2PayoutEditor(view);
			  System.out.println(pe.getAgentFlag().name());
			
			}catch(Exception e){
				e.printStackTrace();
			}
		
	}
	
	private PayoutEditor convert2PayoutEditor(PayoutReqInfo item) {
		PayoutEditor pe = new PayoutEditor();
		pe.setTradeOutNo(item.getMerNo()+"N"+item.getTradeNo());
		pe.setTradeOutBussinessNo(item.getPayBusinessNo());
		pe.setPayeeOrgCode(item.getBankNo());
		pe.setPayeeBranchCode(item.getBranchNo());
		pe.setPayeeBranchName(item.getBranchName());		
		pe.setPayeeAcctNo(item.getAcctNo());
		pe.setPayeeAcctName(item.getAcctName());
		pe.setPayeeAcctType(item.getAcctType());
		pe.setPayeeAcctProvinceName(item.getProvinceName());
		pe.setPayeeAcctCityName(item.getCityName());
		pe.setPayeeMobile(item.getMobile());
		pe.setMsgFlag(item.getMsgFlag());		
		pe.setAmt(item.getAmt());
		pe.setRemitMethod(item.getRemitType());
		pe.setUseDesc(item.getUseDesc());
		pe.setSummary(item.getSummary());
		pe.setExpectPayDate(DateUtil.getDateFormatStr(item.getExpectPayDate(),"yyyyMMdd"));
		pe.setSaveColtCompFlag(YNFlag.N);
		pe.setSystemSource(item.getSystemSource());
		pe.setAgentFlag(item.getAgentFlag());
		pe.setAgentName(item.getAgentName());
		pe.setAgentAcctNo(item.getAgentAcctNo());
		return pe;
	}
	
	@Test
	public void testQueryPayInfoByBusinessNo(){
		try{
			//String desc="test";
			StringBuffer bXml=new StringBuffer();
			PayoutReqInfo temInfo=payBusinessDao.queryPayInfoByBusinessNo("1403260000001117");
			//若在付款业务表中能查到相应的付款记录表示该笔付款是付款中心数据则需要通过另外方式实现
			if(null!=temInfo){				
				//更新付款中心付款业务表状态			
				temInfo=payBusinessDao.queryPayoutReqInfoById(temInfo.getId());
				String merNo=temInfo.getMerNo();
				MerInfoParam param=new MerInfoParam();
				param.setMerNo(merNo);
				MerInfo merInfo=merInfoDao.queryMerInfo(param);
				bXml
				.append("<item tradeNo=\"").append(temInfo.getTradeNo())//外部交易订单编号
					.append("\">")//付款编号
					.append("<tradeExt1>").append(temInfo.getTradeExt1()).append("</tradeExt1>")
					.append("<tradeExt2>").append(temInfo.getTradeExt2()).append("</tradeExt2>")
					.append("<payBusinessNo>").append(temInfo.getPayBusinessNo()).append("</payBusinessNo>")
					.append("<payReqTime>").append(temInfo.getPayReqTime()).append("</payReqTime>")
					.append("<payEndTime>").append(temInfo.getPayEndTime()).append("</payEndTime>")
					.append("<status>").append(temInfo.getStatus().name()).append("</status>")
					.append("<bankRetCode>").append(toBlank(temInfo.getBankRetCode())).append("</bankRetCode>")
					.append("<bankRetMsg>").append(toBlank(temInfo.getBankRetMsg())).append("</bankRetMsg>")
					.append("<merNo>").append(temInfo.getMerNo()).append("</merNo>")
					.append("<url>").append(merInfo.getNotifyUrl()).append("</url>")
					.append("<merKey>").append(merInfo.getMerKey()).append("</merKey>")
				.append("</item>");
				System.out.println(bXml.toString());
				return;	
			}
			
			}catch(Exception e){
				e.printStackTrace();
			}
		
	}
	
	private String toBlank(Object ori) {
		return null == ori ? "" : ori+"";
	}
	
	@Test
	public  void queryPaymentTranListByPage(){
		List<String> list=new ArrayList<String>();
		list.add("INPUTED");
		list.add("FIR_APPROVE_REFUSE");
		PaymentTranInfoParam param=new PaymentTranInfoParam();
		param.setMaxAmt((long) 50000);
		param.setMinAmt(  (long) 1000 );
		param.setStatusList(list);
		try { 
			payBusinessDao.queryPaymentTranListByPage(param, 0, 10);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testAddPayCenterPayInfo(){
		PayoutReqInfo param = new PayoutReqInfo();
		param.setMerNo("0001");
		param.setBankNo(BankCode.CMB);
		param.setAcctType(AcctType.ALL);
		param.setAgentFlag(YNFlag.Y);
		param.setMsgFlag(YNFlag.Y);
		param.setCcy(CurrencyType.AUD);
		param.setAmt(100l);
		param.setRemitType(RemitMethod.COMMON);
		param.setPayType(PayoutType.B2E);
		param.setUseDesc("usedesc");
		param.setSummary("summarty");
		param.setStatus(PayCenterPayStatus.FAILURE);
		param.setTradeNo(" trade no ");
		param.setTradeExt1(" trade ext 1 ");
		param.setTradeExt2(" trade ext 2 ");
		param.setAcctNo(" acct no ");
		param.setAcctName(" acct name ");
		param.setBranchNo(" branch no ");
		param.setBranchName(" branch name ");
		param.setProvinceName(" province name ");
		param.setCityName(" city name ");
		param.setMobile(" mobile mobile ");
		param.setCertNo(" certno certno ");
		param.setAcctSetNo(" acct set no ");
		param.setAgentName(" agent name ");
		param.setAgentAcctNo(" agent acct no ");
		payBusinessDao.addPayCenterPayInfo(param);
	}

}
