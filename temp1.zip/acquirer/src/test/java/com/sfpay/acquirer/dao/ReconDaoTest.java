/**
 * 
 */
package com.sfpay.acquirer.dao;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.dao.DataAccessException;

import com.sfpay.acquirer.domain.BankChannel;
import com.sfpay.acquirer.domain.ReconChangeQueryParam;
import com.sfpay.acquirer.domain.ReconChangeQueryRlt;
import com.sfpay.acquirer.domain.ReconChangeUpdateInfo;
import com.sfpay.acquirer.domain.ReconCollectRlt;
import com.sfpay.acquirer.domain.ReconDetailQueryParam;
import com.sfpay.acquirer.domain.ReconDetailQueryRlt;
import com.sfpay.acquirer.domain.ReconExpClearQueryParam;
import com.sfpay.acquirer.domain.ReconExpClearQueryRlt;
import com.sfpay.acquirer.domain.ReconExpDetailQueryParam;
import com.sfpay.acquirer.domain.ReconExpDetailQueryRlt;
import com.sfpay.acquirer.domain.ReconOutTmp;
import com.sfpay.acquirer.domain.ReconReportQueryParam;
import com.sfpay.acquirer.domain.ReconReportQueryRlt;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.CardType;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.acquirer.enums.ReconChangeStatus;
import com.sfpay.acquirer.enums.ReconChangeType;
import com.sfpay.acquirer.enums.ReconOutStatus;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 类说明： 对账测试
 * 
 * <p/>
 * 详细描述：
 * 
 * 
 * @author 312932 何国兴
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2012-5-10
 */
public class ReconDaoTest extends SpringTestCase {
	@Resource
	private IReconDao dao;

	@Test
	public void testAddTradeOrderList() {
		ReconOutTmp out = new ReconOutTmp();
		out.setAmt(123L);
		out.setBankCode(BankCode.ABC);
		out.setChannelCode(ChannelCode.B2C);
		out.setOutSeqNo("123124");
		out.setOutStatus(ReconOutStatus.SUCCESS);
		out.setOutTradeDate(new Date());
		out.setOutCardType(CardType.DEBIT);
		out.setOutOrderType(OrderType.CANCEL);
		List<ReconOutTmp> reconOutTmpList = new ArrayList<ReconOutTmp>();
		reconOutTmpList.add(out);
		reconOutTmpList.add(out);
		reconOutTmpList.add(out);
		try { 
			dao.addTradeOrderList(reconOutTmpList);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}

	@Test
	public void testSelectTradeCardType() {
		try { 
			dao.selectFee(BankCode.CMB, ChannelCode.B2C, "20130826");
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}

	@Test
	public void testReconChange() {
		ReconChangeUpdateInfo rcu = new ReconChangeUpdateInfo();
		rcu.setReconId(2L);
		rcu.setStatus(ReconChangeStatus.FAILURE.name());
		rcu.setFailReason("超时");
		rcu.setChangeType(ReconChangeType.RESUPPLY);
		rcu.setRemark("测试");
		try { 
			dao.updateReconChange(rcu);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}

	@Test
	public void testQueryReconCollectRltById() {
		
		try { 
			ReconCollectRlt rlt = dao.queryReconCollectRltById(10520);
			logger.debug("rlt:" + rlt);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}

	@Test
	public void testSaveRecon() {
		try { 
			dao.saveRecon(BankCode.UPOP, ChannelCode.B2C, new Date());
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}

	/**************** 测试查询 ***************/
	@Test
	public void testQueryReconPageList() {
		try { 
			List<ReconCollectRlt> list = dao.queryReconPageList(BankCode.UPOP,
					ChannelCode.QPAY, FundWay.IN, 1, 2);
			for (ReconCollectRlt rlt : list) {
				logger.debug("rlt :" + rlt.toString());
			}
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}

	@Test
	public void testQueryReconDetail() {
		try { 
			ReconDetailQueryParam param = new ReconDetailQueryParam();

			List<ReconDetailQueryRlt> list = dao.queryReconDetail(param, 1, 2);
			for (ReconDetailQueryRlt rlt : list) {
				logger.debug("rlt : " + rlt.toString());
			}
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}

	@Test
	public void testQueryReconExp() {
		try { 
			List<ReconExpDetailQueryRlt> list = dao.queryReconExp(
					new ReconExpDetailQueryParam(), 1, 2);
			for (ReconExpDetailQueryRlt rlt : list) {
				logger.debug("rlt : " + rlt.toString());
			}
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}

	@Test
	public void testQueryReconExpClear() {
		try { 
			List<ReconExpClearQueryRlt> list = dao.queryReconExpClear(
					new ReconExpClearQueryParam(), 1, 2);
			for (ReconExpClearQueryRlt rlt : list) {
				logger.debug("rlt : " + rlt);
			}
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}

	@Test
	public void testQueryReconReport() {
		try { 
			List<ReconReportQueryRlt> list = dao.queryReconReport(
					new ReconReportQueryParam(), 1, 2);
			for (ReconReportQueryRlt rlt : list) {
				logger.debug("rlt : " + rlt.toString());
			}
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}

	@Test
	public void testQueryReconChangeList() {
		try { 
			List<ReconChangeQueryRlt> list = dao.queryReconChangeList(
					new ReconChangeQueryParam(), 1, 2);
			for (ReconChangeQueryRlt rlt : list) {
				logger.debug("rlt : " + rlt.toString());
			}
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
}
