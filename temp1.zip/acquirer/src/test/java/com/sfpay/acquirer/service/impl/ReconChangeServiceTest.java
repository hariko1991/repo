/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.domain.ReconChangeRedoReq;
import com.sfpay.acquirer.domain.ReconChangeReq;
import com.sfpay.acquirer.domain.ReconChangeResupplyReq;
import com.sfpay.acquirer.enums.ReSupplyFlag;
import com.sfpay.acquirer.service.IReconChangeService;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 类说明：
 * 调账测试 
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-8-19
 */
public class ReconChangeServiceTest extends SpringTestCase {
	
	@Resource
	private IReconChangeService service;
	
	@Test
	public void testDoNoOper(){
	}
	
	@Test
	public void testDoResupply(){
		ReconChangeResupplyReq req = new ReconChangeResupplyReq();
		req.setReconRltId(10520L);
		req.setOperatorNo("329202");
		req.setOrgId(181L);
		req.setRemark("test");
		req.setRequestIp("10.79.6.55");
		req.setFlag(ReSupplyFlag.BYCARD);
		req.setCardNo("5669992240526911");
		req.setBusinessSn("49091381809603291196");
		try {
			service.doResupply(req);			
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testDoReverse(){
		ReconChangeReq req = new ReconChangeReq();
		req.setReconRltId(10520L);
		req.setOperatorNo("329202");
		req.setOrgId(181L);
		req.setRemark("test");
		req.setRequestIp("10.79.6.55");
		try {
			service.doReverse(req);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testDoRedo(){
		ReconChangeRedoReq req = new ReconChangeRedoReq();
		req.setReconRltId(10520L);
		req.setOperatorNo("329202");
		req.setOrgId(181L);
		req.setRemark("test");
		req.setRequestIp("10.79.6.55");
		try {
			service.doRedo(req);		
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
}
