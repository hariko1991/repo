/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import java.util.Date;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IReconLogDao;
import com.sfpay.acquirer.dao.IUnkownCollectDao;
import com.sfpay.acquirer.domain.ReconLog;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.service.IReconLogService;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 类说明：
 * 对账日志 
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-9-5
 */
public class ReconLogServiceTest extends ClassTransactionalTestCase {
	
	@Resource
	private IReconLogService service;
	
	@Test
	public void testTotalReconCollectRlt() {
		try {
			service.totalReconCollectRlt(BankCode.CMB, ChannelCode.B2C);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testTotalReconCollectRltCount() {
		try {
			service.totalReconCollectRltCount("2013-08-26", BankCode.CMB, ChannelCode.B2C);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testDoResupply(){
		try {
			Date createTime = null;
			int pageNo=1;
			int pageSize=10;
			MockCurrentResult.setMockValue(IReconLogDao.class, "findReconLogPage",111);
			service.findReconLogPage(createTime, pageNo, pageSize);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			Date createTime = null;
			int pageNo=0;
			int pageSize=0;
			MockCurrentResult.setMockValue(IReconLogDao.class, "findReconLogPage",111);
			service.findReconLogPage(createTime, pageNo, pageSize);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testInsertReconLog(){
		try {
			MockCurrentResult.setMockValue(IReconLogDao.class, "insertReconLog",null);
			service.insertReconLog("1", "111111111111111111111");
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
}
