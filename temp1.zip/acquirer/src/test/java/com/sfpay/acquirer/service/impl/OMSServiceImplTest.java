/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IOftenColInfoDao;
import com.sfpay.acquirer.service.IOMSService;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;
import com.sfpay.framework.web.test.SpringTestCase;
import com.sfpay.pubcenter.domain.District;
import com.sfpay.pubcenter.service.IConfigruationCenter;

/**
 * 
 * 类说明：
 * 配置中心提供的接口 测试类 
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-6-6
 */
public class OMSServiceImplTest extends ClassTransactionalTestCase {
	
	@Resource
	private IOMSService omsService;
	
	@Test
	public void testGetDistrictName(){
		try {
			District district = null;
			MockCurrentResult.setMockValue(IConfigruationCenter.class, "findDistrictByCode",district);
			String name = omsService.getDistrictName("HZ");
			logger.debug("name is:"+name);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
}
