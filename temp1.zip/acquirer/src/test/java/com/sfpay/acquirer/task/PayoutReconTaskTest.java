package com.sfpay.acquirer.task;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.service.IPayoutReconService;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 
 * 
 * 类说明：<br>
 * 银企对账测试类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-8-15
 */
public class PayoutReconTaskTest extends ClassTransactionalTestCase{

	@Resource
	private PayoutReconTask task;
	
	@Test
	public void test(){
		MockCurrentResult.setMockValue(IPayoutReconService .class, "doRecon", null);
		try{
			task.execute();
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
}
