/**
 * 
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

import com.sfpay.acquirer.domain.BankChannelArg;
import com.sfpay.acquirer.domain.BankChannelArgQueryParam;
import com.sfpay.acquirer.domain.BankChannelArgUpdateParam;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 类说明：
 *  
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-5-28
 */
public class BankChannelArgDaoTest extends SpringTestCase {
	
	private static Logger logger = LoggerFactory.getLogger(BankChannelArgDaoTest.class);
	
	@Resource
	private IBankChannelArgDao dao;
	
	@Test
	public void testQueryBankChannelArgPageCount(){
		BankChannelArgQueryParam param = new BankChannelArgQueryParam();
		param.setChannelCode(ChannelCode.B2C);
		try { 
			long count = dao.queryBankChannelArgPageCount(param);
			logger.debug("count is:"+count);
			} catch(DataAccessException e) {  
			    System.out.println("test:" + e.getMessage());  
			} 
	}
	
	@Test
	public void testQueryBankChannelArgPageList(){
		BankChannelArgQueryParam param = new BankChannelArgQueryParam();
		param.setChannelCode(ChannelCode.B2C);
		try { 
				List<BankChannelArg> list = dao.queryBankChannelArgPageList(param, 1, 10);
				logger.debug("list is:"+list);
			} catch(DataAccessException e) {  
			    System.out.println("test:" + e.getMessage());  
			} 
	}
	
	@Test
	public void testUpdateBankChannelArgById(){
		BankChannelArgUpdateParam param = new BankChannelArgUpdateParam();
		param.setId(100000L);
		param.setRemark("test");
		try { 
			dao.updateBankChannelArgById(param);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testQueryBankChannelArgById(){		
		try { 
			BankChannelArg arg = dao.queryBankChannelArgById(1);
			logger.debug("arg is:"+arg);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
}
