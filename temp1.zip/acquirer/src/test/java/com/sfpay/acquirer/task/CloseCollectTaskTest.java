/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.task;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.domain.CollectInfo;
import com.sfpay.acquirer.service.ICollectInfoService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 <a href="mailto:fuyuxin@sf-express.com">符瑜鑫(Ricky Fu)</a>
 * 
 * CreateDate: 2012-8-20
 */
public class CloseCollectTaskTest extends ClassTransactionalTestCase {

	private static Logger logger = LoggerFactory.getLogger(CloseCollectTaskTest.class);

	@Resource
	private CloseCollectTask task;

	@Test
	public void testExecute(){
		MockCurrentResult.setMockValue(ICollectInfoService.class, "closeCollectInfo", new ServiceException("构建异常"));
		try {
			task.execute();
		} catch (Exception e) {
			logger.error("", e);
		}
		List<CollectInfo> colList=new ArrayList<CollectInfo>();
		CollectInfo info=new CollectInfo();
		colList.add(info);
		MockCurrentResult.setMockValue(ICollectInfoService.class, "closeCollectInfo", colList);
		try {
			task.execute();
		} catch (Exception e) {
			logger.error("", e);
		}
	}
}
