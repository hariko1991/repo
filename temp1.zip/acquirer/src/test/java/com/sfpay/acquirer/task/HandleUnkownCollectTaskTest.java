/**
 * 
 */
package com.sfpay.acquirer.task;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 类说明：
 *  
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-8-10
 */
public class HandleUnkownCollectTaskTest extends SpringTestCase {
	
	@Resource
	private HandleUnkownCollectTask task;
	
	@Test
	public void testDoAddUnkownCollect(){
		try {
			task.doAddUnkownCollect();
		} catch (Exception e) {
			logger.error("", e);
		}
	}
}
