package com.sfpay.acquirer.service.impl;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IApproveListDao;
import com.sfpay.acquirer.dao.IMerInfoDao;
import com.sfpay.acquirer.dao.IOftenColInfoDao;
import com.sfpay.acquirer.dao.IParamInfoDao;
import com.sfpay.acquirer.dao.IPayBusinessDao;
import com.sfpay.acquirer.dao.IPayoutWhiteListDao;
import com.sfpay.acquirer.domain.paycenter.ApproveListInfo;
import com.sfpay.acquirer.domain.paycenter.ApproveListParam;
import com.sfpay.acquirer.domain.paycenter.MerInfo;
import com.sfpay.acquirer.domain.paycenter.MerInfoParam;
import com.sfpay.acquirer.domain.paycenter.PaymentTranInfoParam;
import com.sfpay.acquirer.domain.paycenter.PayoutReqInfo;
import com.sfpay.acquirer.domain.paycenter.PayoutReqInfoParam;
import com.sfpay.acquirer.domain.paycenter.PayoutReqInfoView;
import com.sfpay.acquirer.domain.paycenter.WhiteListInfo;
import com.sfpay.acquirer.domain.paycenter.WhiteListParam;
import com.sfpay.acquirer.enums.AcctType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.CollectStatus;
import com.sfpay.acquirer.enums.PayCenterPayStatus;
import com.sfpay.acquirer.enums.PayoutType;
import com.sfpay.acquirer.enums.RemitMethod;
import com.sfpay.acquirer.enums.SystemSource;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.acquirer.service.IPayoutCenterService;
import com.sfpay.acquirer.service.IPayoutService;
import com.sfpay.acquirer.service.SendPayoutResp;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;
import com.sfpay.organ.domain.OrgAccount;
import com.sfpay.organ.service.IOrgAccountService;

/**
 * 付款中心测试类
 */
public class PayoutCenterServiceImplTest extends ClassTransactionalTestCase{
	@Resource
	private IPayoutCenterService payoutCenterService;
	@Resource
	private IApproveListDao approveListDao;
	@Test
	public void testQueryPaymentTranListByPage(){
		PaymentTranInfoParam param=new PaymentTranInfoParam();
		Calendar cal=Calendar.getInstance();
		cal.add(Calendar.MONTH, -111);    //得到前111个月
		Date date = cal.getTime();
		param.setBeginTxDate(date);//开始日期
		param.setEndTxDate(new Date());//结束日期
		try {
			payoutCenterService.queryPaymentTranListByPage(param, 1, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			payoutCenterService.queryPaymentTranListByPage(param, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			PaymentTranInfoParam param1=new PaymentTranInfoParam();
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "countPaymentTran",10l);
			payoutCenterService.queryPaymentTranListByPage(param1, 0, 1111);

		} catch (Exception e) {
			logger.error("", e);
		}

	}



	@Test
	public void testValidationAcctSetNo(){
		ApproveListInfo param = new ApproveListInfo();
		OrgAccount orgAccount = new OrgAccount();
		try {
			param = new ApproveListInfo();
			param.setAcctSetNo("6008");
			
			MockCurrentResult.setMockValue(IOrgAccountService.class, "queryOrgAccount",orgAccount);
			payoutCenterService.validationAcctSetNo(param);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			param = new ApproveListInfo();
			param.setAcctSetNo("6008");
			orgAccount = new OrgAccount();
			MockCurrentResult.setMockValue(IOrgAccountService.class, "queryOrgAccount",orgAccount);
			payoutCenterService.validationAcctSetNo(param);
			logger.info(orgAccount);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			param = new ApproveListInfo();
			param.setAcctSetNo("123456789");
			orgAccount = null;
			MockCurrentResult.setMockValue(IOrgAccountService.class, "queryOrgAccount",orgAccount);
			String str = payoutCenterService.validationAcctSetNo(param);

			logger.info(str);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testCheckAcctSetNo(){
		ApproveListInfo	param = new ApproveListInfo();
		try {
			param = new ApproveListInfo();
			param.setUsername("000857");
			param.setModifyFlag("0");
			param.setAcctSetNo("6007");
			payoutCenterService.checkAcctSetNo(param);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			param.setUsername("000857");
			param.setModifyFlag("1");
			param.setAcctSetNo("6007");
			payoutCenterService.checkAcctSetNo(param);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testBatchApproveList(){
		List<ApproveListInfo> params = new ArrayList<ApproveListInfo>();
		ApproveListInfo param = new ApproveListInfo();
		String str = "";
		try {
			param.setUsername("001974");
			param.setAcctSetNo("6007");
			params.add(param);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListDeleteByUsername",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "addApproveList",null);
			str = payoutCenterService.batchApproveList(params);
			logger.info(str);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			param.setUsername("001974");
			param.setAcctSetNo("ALL");
			params.add(param);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListDeleteByUsername",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "addApproveList",null);
			str = payoutCenterService.batchApproveList(params);
			logger.info(str);
		} catch (Exception e) {
			logger.error("", e);
		}	
		try {
			param.setUsername("001974");
			param.setAcctSetNo("6007");
			params.add(param);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListDeleteByUsername",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "addApproveList",null);
			str = payoutCenterService.batchApproveList(params);
			logger.info(str);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			param.setUsername("001974");
			param.setAcctSetNo("6007");
			params.add(param);
			 List<ApproveListInfo> approveLists = null;
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListDeleteByUsername",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "addApproveList",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "queryApproveListByAcctSetNoThird",approveLists);
			str = payoutCenterService.batchApproveList(params);
			logger.info(str);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testSaveApproveList(){
		ApproveListInfo param = new ApproveListInfo();
		Map<String,String> map = new HashMap<String,String>();
		try {
			param = new ApproveListInfo();
			param.setAcctSetNo("123456123456");
			param.setAcctSetFlag("0");
			OrgAccount orgAccount = null;
			MockCurrentResult.setMockValue(IOrgAccountService.class, "queryOrgAccount",orgAccount);
			MockCurrentResult.setMockValue(IApproveListDao.class, "addApproveList",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListDeleteByUsername",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListById",null);
			payoutCenterService.saveApproveList(param);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			param = new ApproveListInfo();
			param.setModifyFlag("0");
			param.setAcctSetFlag("1");
			param.setUsername("001974");
			param.setAcctSetNo("6007");
			OrgAccount orgAccount = new OrgAccount();
			orgAccount.setId(11l);
			MockCurrentResult.setMockValue(IOrgAccountService.class, "queryOrgAccount",orgAccount);
			MockCurrentResult.setMockValue(IApproveListDao.class, "addApproveList",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListDeleteByUsername",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListById",null);
			payoutCenterService.saveApproveList(param);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			param = new ApproveListInfo();
			param.setModifyFlag("0");
			param.setAcctSetFlag("1");
			param.setUsername("001956");
			param.setAcctSetNo("6009");	
			approveListDao.updateApproveListDeleteByUsername(param);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			param = new ApproveListInfo();
			param.setModifyFlag("0");
			param.setAcctSetFlag("1");
			param.setUsername("001956");
			param.setAcctSetNo("6009");	
			OrgAccount orgAccount = new OrgAccount();
			orgAccount.setId(11l);
			MockCurrentResult.setMockValue(IOrgAccountService.class, "queryOrgAccount",orgAccount);
			MockCurrentResult.setMockValue(IApproveListDao.class, "addApproveList",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListDeleteByUsername",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListById",null);	
			payoutCenterService.saveApproveList(param);

		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			param = new ApproveListInfo();
			param.setModifyFlag("0");
			param.setAcctSetFlag("0");
			param.setUsername("001956");
			param.setAcctSetNo("ALL");	
			OrgAccount orgAccount = new OrgAccount();
			orgAccount.setId(11l);
			MockCurrentResult.setMockValue(IOrgAccountService.class, "queryOrgAccount",orgAccount);
			MockCurrentResult.setMockValue(IApproveListDao.class, "addApproveList",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListDeleteByUsername",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListById",null);	
			payoutCenterService.saveApproveList(param);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			param = new ApproveListInfo();
			param.setId(11111111l);
			param.setModifyFlag("1");
			param.setAcctSetFlag("1");
			param.setUsername("001956");
			param.setAcctSetNo("6009");	
			OrgAccount orgAccount = new OrgAccount();
			orgAccount.setId(11l);
			MockCurrentResult.setMockValue(IOrgAccountService.class, "queryOrgAccount",orgAccount);
			MockCurrentResult.setMockValue(IApproveListDao.class, "addApproveList",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListDeleteByUsername",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListById",null);	
			payoutCenterService.saveApproveList(param);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			param = new ApproveListInfo();
			param.setId(11111111l);
			param.setModifyFlag("1");
			param.setUsername("001956");
			param.setAcctSetFlag("0");
			param.setAcctSetNo("ALL");	
			OrgAccount orgAccount = new OrgAccount();
			orgAccount.setId(11l);
			MockCurrentResult.setMockValue(IOrgAccountService.class, "queryOrgAccount",orgAccount);
			MockCurrentResult.setMockValue(IApproveListDao.class, "addApproveList",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListDeleteByUsername",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListById",null);	
			payoutCenterService.saveApproveList(param);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			param = new ApproveListInfo();
			param.setId(11111111l);
			param.setModifyFlag("1");
			param.setAcctSetFlag("1");
			param.setUsername("001956");
			param.setAcctSetNo("6009");	
			OrgAccount orgAccount = new OrgAccount();
			orgAccount.setId(11l);
			MockCurrentResult.setMockValue(IOrgAccountService.class, "queryOrgAccount",orgAccount);
			MockCurrentResult.setMockValue(IApproveListDao.class, "addApproveList",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListDeleteByUsername",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListById",null);		
			payoutCenterService.saveApproveList(param);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			param = new ApproveListInfo();
			param.setModifyFlag("1");
			param.setId(11111111l);
			param.setAcctSetFlag("1");
			param.setUsername("001956");
			param.setAcctSetNo("6008");	
			OrgAccount orgAccount = new OrgAccount();
			orgAccount.setId(11l);
			MockCurrentResult.setMockValue(IOrgAccountService.class, "queryOrgAccount",orgAccount);
			MockCurrentResult.setMockValue(IApproveListDao.class, "addApproveList",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListDeleteByUsername",null);
			MockCurrentResult.setMockValue(IApproveListDao.class, "updateApproveListById",null);
			payoutCenterService.saveApproveList(param);
		} catch (Exception e) {
			logger.error("", e);
		}
	}




	@Test
	public void testDelApproveList(){
		try {
			payoutCenterService.delApproveList(1l);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testFindApproveListByPage(){
		try {
			ApproveListParam param = new ApproveListParam();
			payoutCenterService.findApproveListByPage(param, 0, 0);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testQueryPayoutReqInfo(){
		try {
			payoutCenterService.queryPayoutReqInfo(null, "1000000000030378");
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			payoutCenterService.queryPayoutReqInfo("0001", null);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			payoutCenterService.queryPayoutReqInfo("0001", "1000000000030378");
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testCheckPayOutInfo(){
		String ids = "1320";
		String checkDesc = "checkDesc";
		PayCenterPayStatus status = PayCenterPayStatus.FAILURE;
		String checkOper = "000000";
		try {
			payoutCenterService.checkPayOutInfo(null, null, null, null);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			payoutCenterService.checkPayOutInfo(ids, null, null, null);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			payoutCenterService.checkPayOutInfo(ids, checkDesc, null, null);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			payoutCenterService.checkPayOutInfo(ids, checkDesc, status, null);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			payoutCenterService.checkPayOutInfo(ids, checkDesc, status, checkOper);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			status = PayCenterPayStatus.FIR_APPROVE_PASS;
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "approvePayInfoByFir",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "updateCheckPayStatus",null);
			payoutCenterService.checkPayOutInfo(ids, checkDesc, status, checkOper);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			status = PayCenterPayStatus.FIR_APPROVE_REFUSE;
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "approvePayInfoByFir",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "updateCheckPayStatus",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "queryPayoutReqInfoById",null);
			payoutCenterService.checkPayOutInfo(ids, checkDesc, status, checkOper);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			status = PayCenterPayStatus.FIR_APPROVE_REFUSE;
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "approvePayInfoByFir",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "updateCheckPayStatus",null);
			 PayoutReqInfo info=new  PayoutReqInfo();
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "queryPayoutReqInfoById",info);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "countCheckOperator",10l);
			payoutCenterService.checkPayOutInfo(ids, checkDesc, status, checkOper);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			status = PayCenterPayStatus.FIR_APPROVE_REFUSE;
			 PayoutReqInfo info=new  PayoutReqInfo();
			 info.setStatus(PayCenterPayStatus.WAITING);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "queryPayoutReqInfoById",info);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "countCheckOperator",-10l);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "approvePayInfoByFir",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "updateCheckPayStatus",null);
			payoutCenterService.checkPayOutInfo(ids, checkDesc, status, checkOper);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			status = PayCenterPayStatus.FIR_APPROVE_REFUSE;
			 PayoutReqInfo info=new  PayoutReqInfo();
			 info.setStatus(PayCenterPayStatus.INPUTED);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "queryPayoutReqInfoById",info);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "countCheckOperator",-10l);
			 PayoutReqInfo info1=new  PayoutReqInfo();
			 info1.setStatus(PayCenterPayStatus.FIR_APPROVE_REFUSE);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "queryPayoutReqInfoById",info1);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "approvePayInfoByFir",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "updateCheckPayStatus",null);
			payoutCenterService.checkPayOutInfo(ids, checkDesc, status, checkOper);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {

			status = PayCenterPayStatus.SEC_APPROVE_REFUSE;
			PayoutReqInfoView info=new  PayoutReqInfoView();
			 info.setStatus(PayCenterPayStatus.FIR_APPROVE_PASS);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "queryPayoutReqInfoById",info);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "countCheckOperator",-10l);
			PayoutReqInfoView info1=new  PayoutReqInfoView();
			 info1.setStatus(PayCenterPayStatus.SEC_APPROVE_REFUSE);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "queryPayoutReqInfoById",info1);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "approvePayInfoBySec",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "updateCheckPayStatus",null);
			payoutCenterService.checkPayOutInfo(ids, checkDesc, status, checkOper);

		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {

			status = PayCenterPayStatus.SEC_APPROVE_REFUSE;
			PayoutReqInfoView info=new  PayoutReqInfoView();
			 info.setStatus(PayCenterPayStatus.FIR_APPROVE_PASS);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "countCheckOperator",-10l);
			PayoutReqInfoView info1=new  PayoutReqInfoView();
			 info1.setStatus(PayCenterPayStatus.WAITING);
			 info1.setPayType(PayoutType.B2E);
			 PayoutReqInfoView info2=new  PayoutReqInfoView();
			 info2.setStatus(PayCenterPayStatus.FIR_APPROVE_REFUSE);
			 info2.setPayType(PayoutType.B2E);
			MockCurrentResult.setMockMultiValue(IPayBusinessDao.class, "queryPayoutReqInfoById",info,info2,info1);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "approvePayInfoBySec",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "updateCheckPayStatus",null);
			MockCurrentResult.setMockValue(IPayoutService.class, "createPayout",null);
			MockCurrentResult.setMockValue(SendPayoutResp.class, "doPayCenterResp",null);
			payoutCenterService.checkPayOutInfo(ids, checkDesc, status, checkOper);

		} catch (Exception e) {
			logger.error("", e);
		}

	}
	@Test
	public void testqueryPayoutReqInfoByID(){
		try {
			payoutCenterService.queryPayoutReqInfoByID(null);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			payoutCenterService.queryPayoutReqInfoByID(1L);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testQueryPayoutReqInfoByPage(){
			PayoutReqInfoParam param = new PayoutReqInfoParam();
			param.setUserId("000857");
			
			try{
				payoutCenterService.queryPayoutReqInfoByPage(param, 0, 0);
			}catch (Exception e) {
				logger.error("", e);
			}
			try{
				payoutCenterService.queryPayoutReqInfoByPage(param,1, 1111);
			}catch (Exception e) {
				logger.error("", e);
			}
			
			try{
				MockCurrentResult.setMockValue(IParamInfoDao.class, "getParameter", new Exception());
				payoutCenterService.queryPayoutReqInfoByPage(param, 1, 1111);
			}catch (Exception e) {
				logger.error("", e);
			}
			try{
				 List<PayoutReqInfoView> list=new  ArrayList<PayoutReqInfoView>();
				 PayoutReqInfoView info=new PayoutReqInfoView();
				 info.setAmt(100l);
				 list.add(info);
				MockCurrentResult.setMockValue(IParamInfoDao.class, "getParameter", "10");
				MockCurrentResult.setMockValue(IPayBusinessDao.class, "queryPayoutReqInfoByPage", list);
				MockCurrentResult.setMockValue(IPayBusinessDao.class, "countDuplicate", 0l);
				payoutCenterService.queryPayoutReqInfoByPage(param, 1, 1111);
			}catch (Exception e) {
				logger.error("", e);
			}
			
			try{
				 List<PayoutReqInfoView> list=new  ArrayList<PayoutReqInfoView>();
				 PayoutReqInfoView info=new PayoutReqInfoView();
				 info.setAmt(100l);
				 list.add(info);
				MockCurrentResult.setMockValue(IParamInfoDao.class, "getParameter", "10");
				MockCurrentResult.setMockValue(IPayBusinessDao.class, "queryPayoutReqInfoByPage", list);
				MockCurrentResult.setMockValue(IPayBusinessDao.class, "countDuplicate", 10l);
				payoutCenterService.queryPayoutReqInfoByPage(param, 1, 1111);
			}catch (Exception e) {
				logger.error("", e);
			}
	}

	@Test
	public void testFindWhiteListByPage(){
		try {
			WhiteListParam param = new WhiteListParam();
			payoutCenterService.findWhiteListByPage(param, 0, 0);

			payoutCenterService.findWhiteListByPage(param, 1, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
	}


	@Test
	public void testDelMerInfo(){
		try {
			payoutCenterService.delMerInfo(1l);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testDelWhiteList(){
		try {
			payoutCenterService.delWhiteList(1l);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testSaveWhiteList(){
		WhiteListInfo wli = new WhiteListInfo();
		try {
			payoutCenterService.saveWhiteList(wli);
		} catch (Exception e) {
			logger.error("", e);
		}	
		try {
			wli.setCertNo("432522198606047051");
			payoutCenterService.saveWhiteList(wli);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {	
			wli.setUserName("章松");
			payoutCenterService.saveWhiteList(wli);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			wli.setAccountNo("1233123216");
			payoutCenterService.saveWhiteList(wli);
		}catch (Exception e) {
			logger.error("", e);
		}
		try {
			wli.setCreateId("000000");
			payoutCenterService.saveWhiteList(wli);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			MockCurrentResult.setMockValue(IPayoutWhiteListDao.class, "countWhiteListByReel",-1l);
			wli = new WhiteListInfo();
			wli.setCertNo("432522198606047051");
			wli.setUserName("章松");
			wli.setAccountNo("1233123216");
			wli.setCreateId("000000");

			wli.setId(0l);
			wli.setUserId("000000");
			payoutCenterService.saveWhiteList(wli);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			MockCurrentResult.setMockValue(IPayoutWhiteListDao.class, "countWhiteListByReel",10l);
			MockCurrentResult.setMockValue(IPayoutWhiteListDao.class, "addWhiteList",null);
			wli = new WhiteListInfo();
			wli.setCertNo("432522198606047051");
			wli.setUserName("章松");
			wli.setAccountNo("1233123216");
			wli.setCreateId("000000");

			wli.setId(0l);
			wli.setUserId("000000");
			payoutCenterService.saveWhiteList(wli);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			MockCurrentResult.setMockValue(IPayoutWhiteListDao.class, "countWhiteListByReel",-1l);
			wli = new WhiteListInfo();
			wli.setCertNo("432522198606047051");
			wli.setUserName("章松");
			wli.setAccountNo("1233123216");
			wli.setCreateId("000000");

			wli.setId(10l);
			wli.setUserId("000000");
			payoutCenterService.saveWhiteList(wli);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
		try {
			MockCurrentResult.setMockValue(IPayoutWhiteListDao.class, "countWhiteListByReel",10l);
			MockCurrentResult.setMockValue(IPayoutWhiteListDao.class, "queryWhiteListInfoById",null);
			wli = new WhiteListInfo();
			wli.setCertNo("432522198606047051");
			wli.setUserName("章松");
			wli.setAccountNo("1233123216");
			wli.setCreateId("000000");

			wli.setId(10l);
			wli.setUserId("000000");
			payoutCenterService.saveWhiteList(wli);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			WhiteListInfo info=new WhiteListInfo ();
			info.setCertNo("432522198606047051");
			MockCurrentResult.setMockValue(IPayoutWhiteListDao.class, "countWhiteListByReel",-10l);
			MockCurrentResult.setMockValue(IPayoutWhiteListDao.class, "queryWhiteListInfoById",info);
			wli = new WhiteListInfo();
			wli.setCertNo("432522198606047051");
			wli.setUserName("章松");
			wli.setAccountNo("1233123216");
			wli.setCreateId("000000");

			wli.setId(10l);
			wli.setUserId("000000");
			payoutCenterService.saveWhiteList(wli);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			WhiteListInfo info=new WhiteListInfo ();
			info.setCertNo("432522198606047561");
			MockCurrentResult.setMockValue(IPayoutWhiteListDao.class, "countWhiteListByReel",-10l);
			MockCurrentResult.setMockValue(IPayoutWhiteListDao.class, "queryWhiteListInfoById",info);
			wli = new WhiteListInfo();
			wli.setCertNo("432522198606047051");
			wli.setUserName("章松");
			wli.setAccountNo("1233123216");
			wli.setCreateId("000000");

			wli.setId(10l);
			wli.setUserId("000000");
			payoutCenterService.saveWhiteList(wli);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testSaveMerInfo(){
		MerInfo mi = new MerInfo();
		try {
			payoutCenterService.saveMerInfo(mi);

		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			mi.setMerNo("0002");
			payoutCenterService.saveMerInfo(mi);

		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			mi.setSysName(SystemSource.COD);
			payoutCenterService.saveMerInfo(mi);

		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			mi.setMerKey("87654321");
			payoutCenterService.saveMerInfo(mi);

		} catch (Exception e) {
			logger.error("", e);
		}
		try {

			mi = new MerInfo();
			mi.setId(0l);
			mi.setMerNo("0001");
			mi.setSysName(SystemSource.COD);
			mi.setMerKey("87654321");
			mi.setCreateId("000000");
			MockCurrentResult.setMockValue(IMerInfoDao.class, "saveMerInfo",null);
			payoutCenterService.saveMerInfo(mi);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			mi = new MerInfo();
			mi.setId(0l);
			mi.setMerNo("0002");
			mi.setSysName(SystemSource.COD);
			mi.setMerKey("87654321");
			mi.setCreateId("000000");
			MockCurrentResult.setMockValue(IMerInfoDao.class, "saveMerInfo",null);
			payoutCenterService.saveMerInfo(mi);

			mi = new MerInfo();
			mi.setId(0l);
			mi.setMerNo("0002");
			mi.setSysName(SystemSource.COD);
			mi.setMerKey("87654321");
			mi.setCreateId("000000");
			MockCurrentResult.setMockValue(IMerInfoDao.class, "saveMerInfo",null);
			payoutCenterService.saveMerInfo(mi);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			mi = new MerInfo();
			mi.setId(1020);
			mi.setMerNo("0001");
			mi.setSysName(SystemSource.GXP);
			mi.setMerKey("12345678");
			mi.setCreateId("system");
			mi.setApproveFlag(YNFlag.Y);
			MockCurrentResult.setMockValue(IMerInfoDao.class, "saveMerInfo",null);
			payoutCenterService.saveMerInfo(mi);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			mi = new MerInfo();
			mi.setId(1020);
			mi.setMerNo("0001");
			mi.setSysName(SystemSource.GXP);
			mi.setMerKey("12345678");
			mi.setCreateId("system");
			mi.setApproveFlag(YNFlag.Y);
			MockCurrentResult.setMockValue(IMerInfoDao.class, "saveMerInfo",null);
			MockCurrentResult.setMockValue(IMerInfoDao.class, "updateMerInfo",null);
			payoutCenterService.saveMerInfo(mi);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			mi = new MerInfo();
			mi.setId(1020);
			mi.setMerNo("0002");
			mi.setSysName(SystemSource.GXP);
			mi.setMerKey("12345678");
			mi.setCreateId("system");
			mi.setApproveFlag(YNFlag.Y);
			MockCurrentResult.setMockValue(IMerInfoDao.class, "saveMerInfo",null);
			MockCurrentResult.setMockValue(IMerInfoDao.class, "updateMerInfo",null);
			payoutCenterService.saveMerInfo(mi);
		} catch (Exception e) {
			logger.error("", e);
		}
	}





	@Test
	public void testQueryMerInfoByNo(){
		try {
			payoutCenterService.queryMerInfoByNo(null);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			payoutCenterService.queryMerInfoByNo("0001");
		} catch (Exception e) {
			logger.error("", e);
		}
	}


	@Test
	public void testFindMerInfoByPage(){
		MerInfoParam param = new MerInfoParam();
		try {
			payoutCenterService.findMerInfoByPage(param, 0, 0);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			payoutCenterService.findMerInfoByPage(param, 0, 11111);
		} catch (Exception e) {
			logger.error("", e);
		}
	}





	@Test
	public void testPayCenterCreatePayout(){
		List<PayoutReqInfo> payoutReqList = new ArrayList<PayoutReqInfo>();
		PayoutReqInfo payoutReqInfo = new PayoutReqInfo();
		
		try {
			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAcctNo("6225881206395443");
			payoutReqInfo.setAmt(11l);
			payoutReqInfo.setBankNo(BankCode.CMB);
			payoutReqInfo.setBranchName("招商银行");
			payoutReqInfo.setAcctName("韩丽");
			payoutReqInfo.setAcctType(AcctType.PERSON);
			payoutReqInfo.setProvinceName("安徽");
			payoutReqInfo.setCityName("合肥");
			payoutReqInfo.setUseDesc("测试");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAgentName("1111111111");
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setMobile("13587678987");
			payoutReqInfo.setRemitType(RemitMethod.FAST);
			payoutReqInfo.setSummary("测试");
			payoutReqList.add(payoutReqInfo);
			MerInfo merInfo = new MerInfo();
			merInfo.setApproveFlag(YNFlag.N);
			MockCurrentResult.setMockValue(IMerInfoDao.class, "queryMerInfo",merInfo);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "addPayCenterPayInfo",null);
			payoutCenterService.payCenterCreatePayout(payoutReqList);
		} catch (Exception e) {
			logger.error("", e);
		}	
		
		try {
			payoutReqList = new ArrayList<PayoutReqInfo>();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAmt(0l);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setMobile("13587678987");
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAcctNo("6225881206395443");
			payoutReqInfo.setAmt(11l);
			payoutReqInfo.setBankNo(BankCode.CMB);
			payoutReqInfo.setBranchName("招商银行");
			payoutReqInfo.setAcctName("韩丽");
			payoutReqInfo.setAcctType(AcctType.PERSON);
			payoutReqInfo.setProvinceName("安徽");
			payoutReqInfo.setCityName("合肥");
			payoutReqInfo.setUseDesc("测试");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAgentName("1111111111");
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setMobile("13587678987");
			payoutReqInfo.setRemitType(RemitMethod.FAST);
			payoutReqInfo.setSummary("测试");
			payoutReqList.add(payoutReqInfo);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "addPayCenterPayInfo",null);
			payoutCenterService.payCenterCreatePayout(payoutReqList);
		} catch (Exception e) {
			logger.error("", e);
		}	

		try {
			payoutReqList = new ArrayList<PayoutReqInfo>();
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "addPayCenterPayInfo",null);
			payoutCenterService.payCenterCreatePayout(payoutReqList);
		} catch (Exception e) {
			logger.error("", e);
		}	

		try {
			payoutReqList = new ArrayList<PayoutReqInfo>();
			payoutReqInfo = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAmt(0l);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setMobile("13587678987");
			payoutReqInfo.setAmt(0l);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAcctNo("6225881206395443");
			payoutReqInfo.setMerNo("0001");
			payoutReqInfo.setAmt(11l);
			payoutReqInfo.setBankNo(BankCode.CMB);
			payoutReqInfo.setBranchName("招商银行");
			payoutReqInfo.setAcctName("韩丽");
			payoutReqInfo.setAcctType(AcctType.PERSON);
			payoutReqInfo.setProvinceName("安徽");
			payoutReqInfo.setCityName("合肥");
			payoutReqInfo.setUseDesc("测试");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAgentName("1111111111");
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setMobile("13587678987");
			payoutReqInfo.setRemitType(RemitMethod.FAST);
			payoutReqInfo.setSummary("测试");
			payoutReqList.add(payoutReqInfo);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "addPayCenterPayInfo",null);
			payoutCenterService.payCenterCreatePayout(payoutReqList);
		} catch (Exception e) {
			logger.error("", e);
		}

		try {
			payoutReqList = new ArrayList<PayoutReqInfo>();
			payoutReqInfo = new PayoutReqInfo();
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setMobile("13587678987");
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAcctNo("6225881206395443");
			payoutReqInfo.setMerNo("0001");
			payoutReqInfo.setAmt(11l);
			payoutReqInfo.setBankNo(BankCode.CMB);
			payoutReqInfo.setBranchName("招商银行");
			payoutReqInfo.setAcctName("韩丽");
			payoutReqInfo.setAcctType(AcctType.PERSON);
			payoutReqInfo.setProvinceName("安徽");
			payoutReqInfo.setCityName("合肥");
			payoutReqInfo.setUseDesc("测试");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAgentName("1111111111");
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setMobile("13587678987");
			payoutReqInfo.setRemitType(RemitMethod.FAST);
			payoutReqInfo.setSummary("测试");
			payoutReqList.add(payoutReqInfo);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "addPayCenterPayInfo",null);
			payoutCenterService.payCenterCreatePayout(payoutReqList);
		} catch (Exception e) {
			logger.error("", e);
		}

		try {
			payoutReqList = new ArrayList<PayoutReqInfo>();
			payoutReqInfo = new PayoutReqInfo();
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAmt(0l);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setAmt(0l);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setMobile("13587678987");
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAcctNo("6225881206395443");
			payoutReqInfo.setMerNo("0001");
			payoutReqInfo.setAmt(11l);
			payoutReqInfo.setBankNo(BankCode.CMB);
			payoutReqInfo.setBranchName("招商银行");
			payoutReqInfo.setAcctName("韩丽");
			payoutReqInfo.setAcctType(AcctType.PERSON);
			payoutReqInfo.setProvinceName("安徽");
			payoutReqInfo.setCityName("合肥");
			payoutReqInfo.setUseDesc("测试");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAgentName("1111111111");
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setMobile("13587678987");
			payoutReqInfo.setRemitType(RemitMethod.FAST);
			payoutReqInfo.setSummary("测试");
			payoutReqList.add(payoutReqInfo);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "addPayCenterPayInfo",null);
			payoutCenterService.payCenterCreatePayout(payoutReqList);
		} catch (Exception e) {
			logger.error("", e);
		}

	}

	@Test
	public void testPayCenterGXPCreatePayout(){
		List<PayoutReqInfo> payoutReqList = new ArrayList<PayoutReqInfo>();
		PayoutReqInfo payoutReqInfo = new PayoutReqInfo();
		
		try {
			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAcctNo("6225881206395443");
			payoutReqInfo.setAmt(11l);
			payoutReqInfo.setBankNo(BankCode.CMB);
			payoutReqInfo.setBranchName("招商银行");
			payoutReqInfo.setAcctName("韩丽");
			payoutReqInfo.setAcctType(AcctType.PERSON);
			payoutReqInfo.setProvinceName("安徽");
			payoutReqInfo.setCityName("合肥");
			payoutReqInfo.setUseDesc("测试");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAgentName("1111111111");
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setMobile("13587678987");
			payoutReqInfo.setRemitType(RemitMethod.FAST);
			payoutReqInfo.setSummary("测试");
			payoutReqInfo.setAcctSetNo("C101");
			payoutReqList.add(payoutReqInfo);
			MerInfo merInfo = new MerInfo();
			merInfo.setApproveFlag(YNFlag.N);
			MockCurrentResult.setMockValue(IMerInfoDao.class, "queryMerInfo",merInfo);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "addPayCenterPayInfo",null);
			OrgAccount acct1=new OrgAccount();
			MockCurrentResult.setMockMultiValue(IOrgAccountService.class, "queryOrgAccount",null,acct1);
			payoutCenterService.payCenterGXPCreatePayout(payoutReqList);
		} catch (Exception e) {
			logger.error("", e);
		}	
		
		
		try {
			payoutReqList = new ArrayList<PayoutReqInfo>();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqList.add(payoutReqInfo);
			payoutReqInfo.setAmt(0l);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "saveOrUpdateEcsOften",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "addPayCenterPayInfo",null);
			payoutCenterService.payCenterGXPCreatePayout(payoutReqList);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAmt(0l);
			payoutReqList.add(payoutReqInfo);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "saveOrUpdateEcsOften",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "addPayCenterPayInfo",null);
			payoutCenterService.payCenterGXPCreatePayout(payoutReqList);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqList.add(payoutReqInfo);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "saveOrUpdateEcsOften",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "addPayCenterPayInfo",null);
			payoutCenterService.payCenterGXPCreatePayout(payoutReqList);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setMobile("13587678987");
			payoutReqList.add(payoutReqInfo);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "saveOrUpdateEcsOften",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "addPayCenterPayInfo",null);
			payoutCenterService.payCenterGXPCreatePayout(payoutReqList);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setAcctNo("6225881206395443");
			payoutReqInfo.setAmt(11l);
			payoutReqInfo.setBankNo(BankCode.CMB);
			payoutReqInfo.setBranchName("招商银行");
			payoutReqInfo.setAcctName("韩丽");
			payoutReqInfo.setAcctType(AcctType.PERSON);
			payoutReqInfo.setProvinceName("安徽");
			payoutReqInfo.setCityName("合肥");
			payoutReqInfo.setUseDesc("测试");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAgentName("1111111111");
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setMobile("13587678987");
			payoutReqInfo.setRemitType(RemitMethod.FAST);
			payoutReqInfo.setSummary("测试");
			payoutReqList.add(payoutReqInfo);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "saveOrUpdateEcsOften",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "addPayCenterPayInfo",null);
			payoutCenterService.payCenterGXPCreatePayout(payoutReqList);
		} catch (Exception e) {
			logger.error("", e);
		}

		try {
			payoutReqList = new ArrayList<PayoutReqInfo>();
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "saveOrUpdateEcsOften",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "addPayCenterPayInfo",null);
			payoutCenterService.payCenterGXPCreatePayout(payoutReqList);
		} catch (Exception e) {
			logger.error("", e);
		}

		try {
			payoutReqList = new ArrayList<PayoutReqInfo>();
			payoutReqInfo = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAmt(0l);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAmt(0l);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setMobile("13587678987");
			payoutReqInfo.setAmt(0l);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAcctNo("6225881206395443");
			payoutReqInfo.setMerNo("0001");
			payoutReqInfo.setAmt(11l);
			payoutReqInfo.setBankNo(BankCode.CMB);
			payoutReqInfo.setBranchName("招商银行");
			payoutReqInfo.setAcctName("韩丽");
			payoutReqInfo.setAcctType(AcctType.PERSON);
			payoutReqInfo.setProvinceName("安徽");
			payoutReqInfo.setCityName("合肥");
			payoutReqInfo.setUseDesc("测试");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAgentName("1111111111");
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setMobile("13587678987");
			payoutReqInfo.setRemitType(RemitMethod.FAST);
			payoutReqInfo.setSummary("测试");
			payoutReqList.add(payoutReqInfo);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "saveOrUpdateEcsOften",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "addPayCenterPayInfo",null);
			payoutCenterService.payCenterGXPCreatePayout(payoutReqList);
		} catch (Exception e) {
			logger.error("", e);
		}


		try {
			payoutReqList = new ArrayList<PayoutReqInfo>();
			payoutReqInfo = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAmt(0l);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAmt(0l);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setMobile("13587678987");
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAcctNo("6225881206395443");
			payoutReqInfo.setMerNo("0001");
			payoutReqInfo.setAmt(11l);
			payoutReqInfo.setBankNo(BankCode.CMB);
			payoutReqInfo.setBranchName("招商银行");
			payoutReqInfo.setAcctName("韩丽");
			payoutReqInfo.setAcctType(AcctType.PERSON);
			payoutReqInfo.setProvinceName("安徽");
			payoutReqInfo.setCityName("合肥");
			payoutReqInfo.setUseDesc("测试");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAgentName("1111111111");
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setMobile("13587678987");
			payoutReqInfo.setRemitType(RemitMethod.FAST);
			payoutReqInfo.setSummary("测试");
			payoutReqList.add(payoutReqInfo);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "saveOrUpdateEcsOften",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "addPayCenterPayInfo",null);
			payoutCenterService.payCenterGXPCreatePayout(payoutReqList);
		} catch (Exception e) {
			logger.error("", e);
		}


		try {
			payoutReqList = new ArrayList<PayoutReqInfo>();
			payoutReqInfo = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAmt(0l);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAmt(0l);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setAmt(0l);
			payoutReqInfo.setMobile("13587678987");
			payoutReqList.add(payoutReqInfo);

			payoutReqInfo  = new PayoutReqInfo();
			payoutReqInfo.setTradeNo("1000000000030378");
			payoutReqInfo.setAcctNo("6225881206395443");
			payoutReqInfo.setMerNo("0001");
			payoutReqInfo.setAmt(11l);
			payoutReqInfo.setBankNo(BankCode.CMB);
			payoutReqInfo.setBranchName("招商银行");
			payoutReqInfo.setAcctName("韩丽");
			payoutReqInfo.setAcctType(AcctType.PERSON);
			payoutReqInfo.setProvinceName("安徽");
			payoutReqInfo.setCityName("合肥");
			payoutReqInfo.setUseDesc("测试");
			payoutReqInfo.setAgentFlag(YNFlag.Y);
			payoutReqInfo.setAgentName("1111111111");
			payoutReqInfo.setMsgFlag(YNFlag.Y);
			payoutReqInfo.setMobile("13587678987");
			payoutReqInfo.setRemitType(RemitMethod.FAST);
			payoutReqInfo.setSummary("测试");
			payoutReqList.add(payoutReqInfo);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "saveOrUpdateEcsOften",null);
			MockCurrentResult.setMockValue(IPayBusinessDao.class, "addPayCenterPayInfo",null);
			payoutCenterService.payCenterGXPCreatePayout(payoutReqList);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void  testCountPaymentTran(){
		try{
			PaymentTranInfoParam param = new PaymentTranInfoParam();
			MockCurrentResult.setMockValue(IPayBusinessDao .class, "countPaymentTran",111l);
			payoutCenterService.countPaymentTran(param);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testConverToOftenCol(){
		PayoutCenterServiceImpl payoutCenterServiceImpl = new PayoutCenterServiceImpl();
		
		try {
			PayoutReqInfo payoutReqInfo = new PayoutReqInfo();
			payoutReqInfo.setAcctName("111");
			payoutReqInfo.setAcctNo("222");
			payoutReqInfo.setAcctType(AcctType.ALL);
			payoutReqInfo.setBankNo(BankCode.ABC);
			payoutReqInfo.setMobile("111");
			payoutReqInfo.setBranchNo("111");
			payoutReqInfo.setSummary("111");
			payoutReqInfo.setBranchName("11");
			payoutReqInfo.setProvinceName("111");
			payoutReqInfo.setCityName("11");
 			Method converToOftenCol = PayoutCenterServiceImpl.class.getDeclaredMethod("converToOftenCol", PayoutReqInfo.class);
 			converToOftenCol.setAccessible(true);
 			converToOftenCol.invoke(payoutCenterServiceImpl, new Object[]{payoutReqInfo});
		} catch (Exception e) {
			logger.error("", e);
		}
	}

}
