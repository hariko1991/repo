/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import javax.annotation.Resource;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.dao.IAcctBizDao;
import com.sfpay.acquirer.domain.AcctBizDetail;
import com.sfpay.acquirer.domain.AcctBizQueryParam;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.acquirer.service.IAcctBizService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 
 * 类说明：
 *  
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-5-28
 */
public class AcctBizServiceImplTest extends ClassTransactionalTestCase {

	private static Logger logger = LoggerFactory.getLogger(AcctBizServiceImplTest.class);

	@Resource
	private IAcctBizService service;

	@Test
	public void testQueryBankChannelPage(){
		MockCurrentResult.setMockValue(IAcctBizDao.class, "queryAcctBizPageCount",10);
		try {
			AcctBizQueryParam param = new AcctBizQueryParam();
			param.setChannelCode(ChannelCode.B2C);
			IPage<AcctBizDetail> page = service.queryAcctBizPage(param, 0, 10);
			logger.debug("page is:"+page == null ? "" : page.toString());
		} catch (ServiceException e) {
			logger.error("", e);
		}

	}

	@Test
	public void testSaveAcctBiz(){
			AcctBizDetail param = new AcctBizDetail();
			param.setChannelCode(ChannelCode.B2C);
			param.setBankCode(BankCode.ABC);
			param.setOrderType(OrderType.EXPENSE);
			param.setFundWay(FundWay.IN);
			param.setAccountNo("1111");
			MockCurrentResult.setMockValue(IAcctBizDao.class, "queryBankChannelCount",10);
			MockCurrentResult.setMockValue(IAcctBizDao.class, "addAcctBiz","");
			
			try {
				param.setChannelCode(null);
				service.saveAcctBiz(param);
			}catch (ServiceException e) {
				logger.error("", e);
			}
			
			
			try {
				param.setChannelCode(ChannelCode.B2C);
				param.setBankCode(null);
				service.saveAcctBiz(param);
			}catch (ServiceException e) {
				logger.error("", e);
			}
			
			try {
				param.setBankCode(BankCode.ABC);
				param.setOrderType(null);
				service.saveAcctBiz(param);
			}catch (ServiceException e) {
				logger.error("", e);
			}
			
			try {
				param.setOrderType(OrderType.EXPENSE);
				param.setFundWay(null);
				service.saveAcctBiz(param);
			}catch (ServiceException e) {
				logger.error("", e);
			}
			
			try {
				param.setFundWay(FundWay.IN);
				param.setAccountNo(null);
				service.saveAcctBiz(param);
			}catch (ServiceException e) {
				logger.error("", e);
			}
			
			try {
				param.setFundWay(FundWay.IN);
				param.setAccountNo("1111");
				service.saveAcctBiz(param);
			}catch (ServiceException e) {
				logger.error("", e);
			}
			
			
			try {
				param.setFundWay(FundWay.IN);
				param.setAccountNo("1111");
				MockCurrentResult.setMockValue(IAcctBizDao.class, "queryBankChannelCount",0);
				service.saveAcctBiz(param);
			}catch (ServiceException e) {
				logger.error("", e);
			}
	}
	
	@Test
	public void testDeleteAcctBiz(){
		try {
			service.deleteAcctBiz(0l);
		}catch (ServiceException e) {
			logger.error("", e);
		}
	}


}
