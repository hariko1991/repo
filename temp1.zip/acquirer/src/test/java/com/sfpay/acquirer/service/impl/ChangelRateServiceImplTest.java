package com.sfpay.acquirer.service.impl;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IChannelRateInfoDao;
import com.sfpay.acquirer.domain.ChannelRateInfoQueryParam;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.ChargeType;
import com.sfpay.acquirer.service.IChangelRateService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class ChangelRateServiceImplTest extends ClassTransactionalTestCase {
	@Resource
	private IChangelRateService service;
	@Test
	public void testQueryChannelRateInfoPage(){
		ChannelRateInfoQueryParam  param=new ChannelRateInfoQueryParam ();
		MockCurrentResult.setMockValue(IChannelRateInfoDao.class, "queryChannelRateInfoPageCount",10l);
		try{
			service.queryChannelRateInfoPage(param, 0,10);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
		
	}
	
	@Test
	public void testQueryChannelRateInfo (){
		
		MockCurrentResult.setMockValue(IChannelRateInfoDao.class, "queryChannelRateInfo",null);
		try{
			service.queryChannelRateInfo(100l, BankCode.ABC,ChannelCode .B2C,ChargeType .BY_RATE);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
	}
	@Test
	public void testAddChannelRateInfo(){
		MockCurrentResult.setMockValue(IChannelRateInfoDao.class, "addChannelRateInfo",null);
		ChannelRateInfoQueryParam  param=new ChannelRateInfoQueryParam ();
		try{
			service.addChannelRateInfo(param);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
	}
	
	@Test
	public void testUpdateChannelRateInfo(){
		ChannelRateInfoQueryParam  param=new ChannelRateInfoQueryParam ();
		try{
			service.updateChannelRateInfo(param);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
	}
}
