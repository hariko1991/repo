/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IAccountInfoDao;
import com.sfpay.acquirer.domain.AccountBalance;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.gate.b2e.service.IBankService;
import com.sfpay.acquirer.gate.b2e.service.IQuery;
import com.sfpay.acquirer.service.IAccountBalanceService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 
 * 类说明：<br>
 * 查询余额测试
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2012-10-25
 */
public class AccountBalanceServiceImplTest extends ClassTransactionalTestCase{

	@Resource
	private IAccountBalanceService service;

	@Test
	public void testCMBQueryAccountBalance(){

		//配置信息为null mock
		BankCode bankCode =BankCode.ICBC;
		String accountNo = "571905400810812";
		AccountInfo accountInfo = new AccountInfo();
		

		//账户信息为null查询mock
		try{
			accountInfo = new AccountInfo();
			accountInfo.setBankCode(BankCode.ICBC);
			accountInfo.setAccountNo("1111111");
			accountInfo.setAccountName("2222222");
			accountInfo.setCityName("22222");
			accountInfo.setCcy(CurrencyType.AUD);
			accountInfo.setOpeningBankName("aaaaaaa");
			accountInfo.setProvinceName("22222");
			accountInfo.setOpeningBankNo("222");
			bankCode = BankCode.CMB;
			accountNo = "571905400810812";
			MockCurrentResult.setMockValue(IAccountInfoDao.class, "queryAccountInfoByAccountNo",accountInfo);
			MockCurrentResult.setMockValue(IBankService.class, "service","<?xml  version=\"1.0\" encoding=\"GBK\" ?><CMS><eb><pub><TransCode>QACCBAL</TransCode><CIS>400090001229524</CIS><BankCode>102</BankCode><ID>test.d.4000</ID><TranDate>20130712</TranDate><TranTime>075659515000</TranTime><fSeqno>20130712100000062590</fSeqno><RetCode>0</RetCode><RetMsg></RetMsg></pub><out><rd><iSeqno>1</iSeqno><AccNo>4000023029200124946</AccNo><CurrType>001</CurrType><CashExf>0</CashExf><AcctProperty>004</AcctProperty><AccBalance>9999080062090</AccBalance><Balance>9999080062098</Balance><UsableBalance>9999080062098</UsableBalance><FrzAmt>0</FrzAmt><QueryTime>20130825155700000013</QueryTime><iRetCode>0</iRetCode><iRetMsg></iRetMsg><RepReserved3></RepReserved3><RepReserved4></RepReserved4></rd></out></eb></CMS>");
			service.queryAccountBalance(bankCode, accountNo);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
		try{
			service.queryAccountBalance(null, "571905400810812");
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}

		try{
			service.queryAccountBalance(BankCode.ICBC, "");
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}


		//账户信息为null查询mock
		try{
			accountInfo = new AccountInfo();
			bankCode = BankCode.CMB;
			accountNo = "571905400810812";
			MockCurrentResult.setMockValue(IAccountInfoDao.class, "queryAccountInfoByAccountNo",accountInfo);
			service.queryAccountBalance(bankCode, accountNo);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}

		//账户信息为null查询mock
		try{
			bankCode = BankCode.CMB;
			accountNo = "571905400810812";
			MockCurrentResult.setMockValue(IAccountInfoDao.class, "queryAccountInfoByAccountNo",null);
			service.queryAccountBalance(bankCode, accountNo);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}



		try{
			//查询余额mocke
			AccountBalance bal=new AccountBalance();
			bal.setAccountNo("123");
			bal.setRetainAmt("10000");
			MockCurrentResult.setMockValue(IQuery.class, "queryAccountBalance",bal);
			service.queryAccountBalance(bankCode, accountNo);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
	}

}
