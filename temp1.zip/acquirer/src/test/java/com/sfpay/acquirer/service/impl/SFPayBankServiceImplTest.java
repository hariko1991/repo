package com.sfpay.acquirer.service.impl;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.ISFPayBankDao;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.service.ISFPayBankService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class SFPayBankServiceImplTest extends ClassTransactionalTestCase {
	@Resource
	private ISFPayBankService service;
	@Test
	public void testFindSFPayBank(){
		try{
			service.findSFPayBank( ChannelCode.B2C,"");
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
		try{
			service.findSFPayBank( null,"123");
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		MockCurrentResult.setMockValue(ISFPayBankDao.class, "findBank",new Exception ("exception test"));
		
		try{
			service.findSFPayBank( ChannelCode.B2C,"123");
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
	}
	@Test
	public void testQuerySFPayBank(){
		MockCurrentResult.setMockValue(ISFPayBankDao.class, "queryBank",new Exception ("exception test"));
		
		try{
			service.querySFPayBank( ChannelCode.B2C);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
	}

}
