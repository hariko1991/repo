/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.dao.ICollectInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.dao.IReconDao;
import com.sfpay.acquirer.domain.PayoutQueryRlt;
import com.sfpay.acquirer.domain.ReconChangeQueryParam;
import com.sfpay.acquirer.domain.ReconChangeQueryRlt;
import com.sfpay.acquirer.domain.ReconCollectRlt;
import com.sfpay.acquirer.domain.ReconDetailQueryParam;
import com.sfpay.acquirer.domain.ReconDetailQueryRlt;
import com.sfpay.acquirer.domain.ReconExpClearQueryParam;
import com.sfpay.acquirer.domain.ReconExpClearQueryRlt;
import com.sfpay.acquirer.domain.ReconExpDetailQueryParam;
import com.sfpay.acquirer.domain.ReconExpDetailQueryRlt;
import com.sfpay.acquirer.domain.ReconReportQueryParam;
import com.sfpay.acquirer.domain.ReconReportQueryRlt;
import com.sfpay.acquirer.domain.paycenter.EcsRecon;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.ReconResult;
import com.sfpay.acquirer.service.IReconService;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 <a href="mailto:fuyuxin@sf-express.com">符瑜鑫(Ricky Fu)</a>
 * 
 * CreateDate: 2012-5-13
 */
public class ReconServiceImplTest extends ClassTransactionalTestCase {
	
	@Resource
	private IReconDao reconDao;
	
	@Resource
	private IReconService service;
	
	/**
	 * 方法说明：<br>
	 * 测试对账
	 *
	 */
	@Test
	public void testAnalyseRecon(){
		try {
			String relaPath = "/QPAY/UPOP/00215800_103130149005947_out.tar.gz";
			this.service.analyseRecon(BankCode.UPOP, ChannelCode.QPAY, new Date(), relaPath);
		} catch (Exception e) {
			logger.error("", e);
		}
		
	}
	

//	@Test
//	public void testProcedure() {
//		Calendar cal = Calendar.getInstance();
//		cal.set(Calendar.YEAR, 2012);
//		cal.set(Calendar.MONTH, 3);
//		cal.set(Calendar.DATE, 23);
//		reconDao.saveRecon(BankCode.PAB, ChannelCode.B2C, cal.getTime());
//	}
//	
//	@Test
//	public void testFindReconDetail() {
//		ReconDetailQueryParam param = new ReconDetailQueryParam();
//		Calendar cal = Calendar.getInstance();
//		cal.set(Calendar.YEAR, 2012);
//		cal.set(Calendar.MONTH, 7);
//		cal.set(Calendar.DATE, 1);
//		param.setBeginDate(cal.getTime());
//		
//		cal.set(Calendar.MONTH, 7);
//		cal.set(Calendar.DATE, 17);
//		param.setEndDate(cal.getTime());
//		
//		param.setBank(BankCode.CMB);

	@Test
	public void testProcedure() {
		try {
			Calendar cal = Calendar.getInstance();
			cal.set(Calendar.YEAR, 2012);
			cal.set(Calendar.MONTH, 3);
			cal.set(Calendar.DATE, 23);
			MockCurrentResult.setMockValue(IReconDao .class, "saveRecon",null);
			reconDao.saveRecon(BankCode.PAB, ChannelCode.B2C, cal.getTime());
		} catch (Exception e) {
			logger.error("", e);
		}
		
	}
	
	@Test
	public void testExecuteRecon(){
		try {
			service.executeRecon(BankCode.CMB, ChannelCode.B2C, new Date());
		} catch (Exception e) {
			logger.error("", e);
		}
		
	}
	
	@Test
	public void testFindReconByPage(){
		try {
			service.findReconByPage(null, ChannelCode.B2C, FundWay.IN, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			service.findReconByPage(BankCode.CMB, null, FundWay.IN, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			service.findReconByPage(BankCode.CMB, ChannelCode.B2C, FundWay.IN, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			MockCurrentResult.setMockValue(IReconDao .class, "queryReconCount",11111l);
			service.findReconByPage(BankCode.CMB, ChannelCode.B2C, FundWay.IN, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testFindReconDetail() {
		ReconDetailQueryParam param = new ReconDetailQueryParam();
		
		try {
			service.findReconDetailByPage(null, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			service.findReconDetailByPage(param, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			Calendar cal=Calendar.getInstance();
			cal.add(Calendar.MONTH, -111);    //得到前111个月
			Date date = cal.getTime();
			param.setBeginDate(new Date());
			param.setEndDate(date);//结束日期
			MockCurrentResult.setMockValue(IReconDao .class, "queryReconDetailCount",11111l);
			service.findReconDetailByPage(param, 0, 111111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			Calendar cal=Calendar.getInstance();
			cal.add(Calendar.MONTH, -111);    //得到前111个月
			Date date = cal.getTime();
			param.setBeginDate(date);
			param.setEndDate(new Date());//结束日期
			MockCurrentResult.setMockValue(IReconDao .class, "queryReconDetailCount",11111l);
			service.findReconDetailByPage(param, 0, 111111);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testFindReconExpDetail() {
		ReconExpDetailQueryParam param = new ReconExpDetailQueryParam();
		
		try {
			service.findReconExpByPage(null, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			service.findReconExpByPage(param, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			Calendar cal=Calendar.getInstance();
			cal.add(Calendar.MONTH, -111);    //得到前111个月
			Date date = cal.getTime();
			param.setBeginDate(new Date());
			param.setEndDate(date);//结束日期
			MockCurrentResult.setMockValue(IReconDao .class, "queryReconExpCount",11111l);
			service.findReconExpByPage(param, 0, 111111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			Calendar cal=Calendar.getInstance();
			cal.add(Calendar.MONTH, -111);    //得到前111个月
			Date date = cal.getTime();
			param.setBeginDate(date);
			param.setEndDate(new Date());//结束日期
			MockCurrentResult.setMockValue(IReconDao .class, "queryReconExpCount",11111l);
			service.findReconExpByPage(param, 0, 111111);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	
	@Test
	public void testFindReconExpClear() {
		ReconExpClearQueryParam param = new ReconExpClearQueryParam();
		
		try {
			service.findReconExpClearByPage(null, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			service.findReconExpClearByPage(param, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			Calendar cal=Calendar.getInstance();
			cal.add(Calendar.MONTH, -111);    //得到前111个月
			Date date = cal.getTime();
			param.setBeginDate(new Date());
			param.setEndDate(date);//结束日期
			MockCurrentResult.setMockValue(IReconDao .class, "queryReconExpCount",11111l);
			service.findReconExpClearByPage(param, 0, 2022222);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			Calendar cal=Calendar.getInstance();
			cal.add(Calendar.MONTH, -111);    //得到前111个月
			Date date = cal.getTime();
			param.setBeginDate(date);
			param.setEndDate(new Date());//结束日期
			MockCurrentResult.setMockValue(IReconDao .class, "queryReconExpCount",11111l);
			service.findReconExpClearByPage(param, 0, 2022222);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testFindReconReport() {
		ReconReportQueryParam param = new ReconReportQueryParam();
		
		try {
			service.findReconReportByPage(null, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			service.findReconReportByPage(param, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
		try {
			Calendar cal=Calendar.getInstance();
			cal.add(Calendar.MONTH, -111);    //得到前111个月
			Date date = cal.getTime();
			param.setBeginDate(new Date());
			param.setEndDate(date);//结束日期
			MockCurrentResult.setMockValue(IReconDao .class, "queryReconReportCount",11111l);
			service.findReconReportByPage(param, 0, 21111111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			Calendar cal=Calendar.getInstance();
			cal.add(Calendar.MONTH, -111);    //得到前111个月
			Date date = cal.getTime();
			param.setBeginDate(date);
			param.setEndDate(new Date());//结束日期
			MockCurrentResult.setMockValue(IReconDao .class, "queryReconReportCount",11111l);
			service.findReconReportByPage(param, 0, 21111111);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testFindReconExpClearByPage(){
		ReconExpClearQueryParam param = new ReconExpClearQueryParam();
		try {
			service.findReconExpClearByPage(null, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			service.findReconExpClearByPage(param, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			Calendar cal=Calendar.getInstance();
			cal.add(Calendar.MONTH, -111);    //得到前111个月
			Date date = cal.getTime();
			param.setBeginDate(new Date());
			param.setEndDate(date);//结束日期
			MockCurrentResult.setMockValue(IReconDao .class, "queryReconExpClearCount",11111l);
			service.findReconExpClearByPage(param, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			Calendar cal=Calendar.getInstance();
			cal.add(Calendar.MONTH, -111);    //得到前111个月
			Date date = cal.getTime();
			param.setBeginDate(date);
			param.setEndDate(new Date());//结束日期
			MockCurrentResult.setMockValue(IReconDao .class, "queryReconExpClearCount",11111l);
			service.findReconExpClearByPage(param, 0, 1111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
	}

	@Test
	public void testFindReconChangeByPage() {
		ReconChangeQueryParam param = new ReconChangeQueryParam();
		
		try {		
			service.findReconChangeByPage(null, 0, 11111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {		
			service.findReconChangeByPage(param, 0, 11111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			param.setBeginDate(new Date());
			service.findReconChangeByPage(param, 0, 11111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			param.setBeginDate(new Date());
			param.setEndDate(new Date());
			service.findReconChangeByPage(param, 0, 11111);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
		try {	
			param.setBank(BankCode.CMB);
			MockCurrentResult.setMockValue(IReconDao .class, "queryReconChangeCount",11111l);
			service.findReconChangeByPage(param, 0, 11111);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testDoClearReconExp(){
		try {
			service.doClearReconExp(null, null);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			List<Long> list = new ArrayList<Long>();
			list.add(1l);
			service.doClearReconExp(list, "1111");
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	

	@Test
	public void testUpdateFee(){
		Date date = DateUtil.getDateFormatStr("20120202", DateUtil.DATA_FORMAT_PATTERN_2);
		MockCurrentResult.setMockValue(ICollectInfoDao.class, "updateFee", null);
		
		try {
			service.updateFee(null, ChannelCode.QPAY, date);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			MockCurrentResult.setMockValue(IReconDao.class, "selectFee", null);
			service.updateFee(BankCode.UPOP, null, date);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			MockCurrentResult.setMockValue(IReconDao.class, "selectFee", null);
			service.updateFee(BankCode.UPOP, ChannelCode.QPAY, null);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			List<ReconCollectRlt> list = new ArrayList<ReconCollectRlt>();
			ReconCollectRlt rcr = new ReconCollectRlt();
			rcr.setOutFee(1l);
			list.add(rcr);
			MockCurrentResult.setMockValue(IReconDao.class, "selectFee", list);
			service.updateFee(BankCode.UPOP, ChannelCode.QPAY, date);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			MockCurrentResult.setMockValue(IReconDao.class, "selectFee", null);
			service.updateFee(BankCode.UPOP, ChannelCode.QPAY, date);
		} catch (Exception e) {
			logger.error("", e);
		}
		
	}
	
	@Test
	public void testQueryECSReconListExport(){
		EcsRecon param = new EcsRecon();
		service.queryECSReconListExport(param); 
	}
	
	@Test
	public void testFindEcsReconListByPage(){
		try{
			EcsRecon param = new EcsRecon();
			MockCurrentResult.setMockValue(IReconDao .class, "queryEcsReconCount",11111l);
			service.findEcsReconListByPage(param, 0, 11111);
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
}
