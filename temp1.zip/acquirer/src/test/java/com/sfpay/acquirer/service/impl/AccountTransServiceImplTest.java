/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IAccountInfoDao;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.AccountTransInfo;
import com.sfpay.acquirer.domain.HisAcctTxQueryParam;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.DrCrFlag;
import com.sfpay.acquirer.gate.b2e.service.IQuery;
import com.sfpay.acquirer.service.IAccountTransService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 
 * 类说明：<br>
 * 查询账户交易测试
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2012-10-25
 */
public class AccountTransServiceImplTest extends ClassTransactionalTestCase{

	@Resource
	public IAccountTransService service;
	
	/**
	 * 方法说明：<br>
	 * 当天
	 *
	 */
	@Test
	public void testqueryCurAccountTransList(){
//			BankCode bankCode = BankCode.CMB;
//			String accountNo = "571905400810812";//CMB=6225885710000027/571905400810812
			
			BankCode bankCode = BankCode.ICBC;
			String accountNo = "4000023029200124946";//ICBC=4000023029200124946
			AccountInfo accountInfo=new AccountInfo();
			accountInfo.setCcy(CurrencyType.RMB);
			accountInfo.setAcctUseDesc("yiliao");
			MockCurrentResult.setMockValue(IAccountInfoDao.class, "queryAccountInfoByAccountNo",accountInfo);
			
			List<AccountTransInfo> accountlist=new ArrayList<AccountTransInfo>();
			AccountTransInfo acctInfo=new AccountTransInfo();
			acctInfo.setAccountNo("564879");
			accountlist.add(acctInfo);
			MockCurrentResult.setMockValue(IQuery.class, "queryCurAccountTransList",accountlist);
			
			List<AccountTransInfo> list = this.service.queryCurAccountTransList(bankCode, accountNo);
			for(Iterator<AccountTransInfo> it = list.iterator();it.hasNext();){
				logger.debug(it.next().toString());
			}
			try {
				 list = this.service.queryCurAccountTransList(null, accountNo);
			}catch (ServiceException e) {
				logger.error("", e);
			}
			
			try {
				 list = this.service.queryCurAccountTransList(BankCode.ICBC, null);
			}catch (ServiceException e) {
				logger.error("", e);
			}
	}
	
	/**
	 * 方法说明：<br>
	 * 历史
	 *
	 */
	@Test
	public void testqueryHisAccountTransList(){
			HisAcctTxQueryParam param = new HisAcctTxQueryParam();
//			param.setBankCode(BankCode.CMB);
//			param.setAccountNo("571905400810812");//CMB=6225885710000027/571905400810812
			
			param.setBankCode(BankCode.ICBC);
			param.setAccountNo("4000023029200124946");//ICBC=4000023029200124946
			
			Calendar cal=Calendar.getInstance();
			cal.add(Calendar.DATE,-100);
			Date newDate = cal.getTime();
			
			param.setBeginTxDate(newDate);
			param.setEndTxDate(new Date());
			param.setDrFlag(DrCrFlag.DR);
			List<AccountTransInfo> list1=new ArrayList<AccountTransInfo>();
			list1.add(new AccountTransInfo());
			MockCurrentResult.setMockValue(IQuery.class, "queryHisAccountTransList",list1);
			List<AccountTransInfo> list = this.service.queryHisAccountTransList(param);
	
			
			
			try {
				this.service.queryHisAccountTransList(null);
			}catch (ServiceException e) {
				logger.error("", e);
			}
			
			try {
				param.setBankCode(null);
				this.service.queryHisAccountTransList(param);
			}catch (ServiceException e) {
				logger.error("", e);
			}
			
			try {
				param.setBankCode(BankCode.ICBC);
				param.setAccountNo(null);
				this.service.queryHisAccountTransList(param);
			}catch (ServiceException e) {
				logger.error("", e);
			}
			
			try {
				param.setAccountNo("4000023029200124946");
				param.setBeginTxDate(null);
				this.service.queryHisAccountTransList(param);
			}catch (ServiceException e) {
				logger.error("", e);
			}
			
			try {
				param.setBeginTxDate(newDate);
				param.setEndTxDate(null);
				this.service.queryHisAccountTransList(param);
			}catch (Exception e) {
				logger.error("", e);
			}
	}
}
