/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IOftenColInfoDao;
import com.sfpay.acquirer.dao.IPayUseDao;
import com.sfpay.acquirer.domain.PayUse;
import com.sfpay.acquirer.domain.PayUseQueryParam;
import com.sfpay.acquirer.service.IPayUseService;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 类说明：<br>
 * 付款用途　service测试类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2012-9-28
 */
public class PayUseServiceImplTest extends ClassTransactionalTestCase {
	
	@Resource
	private IPayUseService service;
	
	/**
	 * 方法说明：<br>
	 * 分页查询
	 *
	 */
	@Test
	public void testQueryPayUsePage(){
		PayUseQueryParam param = new PayUseQueryParam();

		try {
			MockCurrentResult.setMockValue(IPayUseDao .class, "countUsePage",10l);
			IPage<PayUse> page = service.queryPayUsePage(param,0,111);
			logger.debug("page is:"+page == null ? "" : page.toString());

		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 添加
	 *
	 */
	@Test
	public void testSavePayUse(){
		try{
			PayUse payUse = new PayUse();
			payUse.setUseDesc("");
			payUse.setId(0L);
			payUse.setRemark("备注7");
			payUse.setShowIndex(7L);
			MockCurrentResult.setMockValue(IPayUseDao .class, "addPayUse",null);
			service.savePayUse(payUse);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			PayUse payUse = new PayUse();
			payUse.setUseDesc("备注9");
			payUse.setId(0L);
			payUse.setRemark("备注7");
			payUse.setShowIndex(7L);
			MockCurrentResult.setMockValue(IPayUseDao .class, "addPayUse",null);
			service.savePayUse(payUse);
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 删除
	 *
	 */
	@Test
	public void testDeletePayUse(){
		try{
			long id = 1062L;		
			MockCurrentResult.setMockValue(IPayUseDao .class, "deletePayUse",null);
			service.deletePayUse(id);
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 查询所有
	 *
	 */
	@Test
	public void testQueryPayUse(){
		try{
			List<PayUse> list = service.queryPayUse();
			for(Iterator<PayUse> it = list.iterator(); it.hasNext();){
				PayUse  payUse = it.next();
				logger.debug(payUse.getId()+","+payUse.getUseDesc()+","+payUse.getRemark()+","+payUse.getShowIndex());
			}
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 根据ID修改
	 *
	 */
	@Test
	public void testUpdatePayUseById(){
		try{
			MockCurrentResult.setMockValue(IPayUseDao .class, "updatePayUseById",null);
			service.updatePayUseById(null, "备注90", "备注90", 1L);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			MockCurrentResult.setMockValue(IPayUseDao .class, "updatePayUseById",null);
			service.updatePayUseById(1063L, null, "备注90", 1L);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			MockCurrentResult.setMockValue(IPayUseDao .class, "updatePayUseById",null);
			service.updatePayUseById(1063L, "备注90", "备注90", 1L);
		}catch(Exception ex){
			logger.error("",ex);
		}
	}

	/**
	 * 方法说明：<br>
	 * 根据ID查询
	 *
	 */
	@Test
	public void testQueryPayUseById(){
		try{
			PayUse payUse = service.queryPayUseById(-1l);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			PayUse payUse = service.queryPayUseById(1063L);
		}catch(Exception ex){
			logger.error("",ex);
		}

		try{
			List<PayUse> list = new ArrayList<PayUse>();
			PayUse payUse1 = new PayUse();
			list.add(payUse1);
			MockCurrentResult.setMockValue(IPayUseDao .class, "queryUse",list);
			PayUse payUse = service.queryPayUseById(1063L);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			List<PayUse> list = null;
			MockCurrentResult.setMockValue(IPayUseDao .class, "queryUse",list);
			PayUse payUse = service.queryPayUseById(1063L);
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
}
