package com.sfpay.acquirer.service.impl;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.service.IGenerateInfoService;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * CreateDate: 2013-8-27
 */
public class GenerateInfoServiceTest extends SpringTestCase {

	@Resource
	private IGenerateInfoService service;

	@Test
	public void testGenerateId() {
		try {
			logger.debug(Property.getProperty("B2E_CHECK_BANK"));
			logger.debug(service.getGenerateId4B2E(21));
		} catch (Exception e) {
			logger.error("", e);
		}
	}
}
