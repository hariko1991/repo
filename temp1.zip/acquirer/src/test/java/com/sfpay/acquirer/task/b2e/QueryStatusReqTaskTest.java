package com.sfpay.acquirer.task.b2e;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.task.b2e.CMBQueryStatusReqTask;
import com.sfpay.acquirer.task.b2e.ICBCQueryStatusReqTask;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-5-7
 */
public class QueryStatusReqTaskTest extends SpringTestCase {

	@Resource
	private ICBCQueryStatusReqTask icbcTask;
	
	@Resource
	private CMBQueryStatusReqTask cmbTask;
	
	@Test
	public void testICBCExecute(){
		try{
			icbcTask.execute();
		}catch(Exception ex){
			logger.error("", ex);
		}
	}
	
	@Test
	public void testCMBExecute(){
		try{
			cmbTask.execute();
		}catch(Exception ex){
			logger.error("", ex);
		}
	}
}
