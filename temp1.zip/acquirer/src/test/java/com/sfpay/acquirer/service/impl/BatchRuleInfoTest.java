package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IBatchRuleInfoDao;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.enums.AcctType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.BatchRuleStatus;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.service.IBatchRuleInfoService;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-8-26
 */
public class BatchRuleInfoTest extends ClassTransactionalTestCase {

	@Resource
	private IBatchRuleInfoService batchRuleInfoService;

	@Test
	public void queryBatchRuleInfoPageTest() {
		BatchRuleInfo param = new BatchRuleInfo();
		try {
			batchRuleInfoService.queryBatchRuleInfoPage(param, 1, 10);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void addBatchRuleInfoTest() {
		BatchRuleInfo batchRuleInfo = new BatchRuleInfo();
		batchRuleInfo.setRuleName("招行");
		batchRuleInfo.setBankGroup("CMB");
		batchRuleInfo.setStatus(BatchRuleStatus.ENABLE);
		batchRuleInfo.setChannelCode(ChannelCode.B2E);
		batchRuleInfo.setBankCode(BankCode.CMB);
		batchRuleInfo.setBatchMaxSize(100L);
		batchRuleInfo.setOppAcctType(AcctType.ALL);//PERSON,COMPANY
		batchRuleInfo.setAccountNo("571905400810812");
		try {
			batchRuleInfoService.addBatchRuleInfo(batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			batchRuleInfoService.addBatchRuleInfo(null);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		batchRuleInfo.setAccountNo(null);
		try {
			batchRuleInfoService.addBatchRuleInfo(batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		batchRuleInfo.setAccountNo("571905400810812");
		batchRuleInfo.setBankCode(null);
		try {
			batchRuleInfoService.addBatchRuleInfo(batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		batchRuleInfo.setBankCode(BankCode.CMB);
		batchRuleInfo.setBatchMaxSize(0L);
		try {
			batchRuleInfoService.addBatchRuleInfo(batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		batchRuleInfo.setBatchMaxSize(100L);
		MockCurrentResult.setMockValue(IBatchRuleInfoDao.class, "addBatchRuleInfo",new Exception ("处理异常"));
		try {
			batchRuleInfoService.addBatchRuleInfo(batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void updateBatchRuleInfoByIdTest() {
		BatchRuleInfo batchRuleInfo = new BatchRuleInfo();
		batchRuleInfo.setId(1023l);
		batchRuleInfo.setRuleCode("ICBC_0002");
		batchRuleInfo.setRuleName("工行－对公");
		batchRuleInfo.setBankGroup("ICBC");
		batchRuleInfo.setStatus(BatchRuleStatus.ENABLE);
		batchRuleInfo.setChannelCode(ChannelCode.B2E);
		batchRuleInfo.setBankCode(BankCode.ICBC);
		batchRuleInfo.setBatchMaxSize(10l);
		batchRuleInfo.setOppAcctType(AcctType.ALL);
		batchRuleInfo.setAccountNo("4000023029200124946");
		try {
			batchRuleInfoService.updateBatchRuleInfoById(batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			batchRuleInfoService.updateBatchRuleInfoById(null);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		batchRuleInfo.setId(-5l);
		try {
			batchRuleInfoService.updateBatchRuleInfoById(batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		batchRuleInfo.setId(1023l);
		batchRuleInfo.setRuleName("");
		try {
			batchRuleInfoService.updateBatchRuleInfoById(batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		batchRuleInfo.setRuleName("工行－对公");
		batchRuleInfo.setAccountNo("");
		try {
			batchRuleInfoService.updateBatchRuleInfoById(batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		batchRuleInfo.setAccountNo("4000023029200124946");
		batchRuleInfo.setBankCode(null);
		try {
			batchRuleInfoService.updateBatchRuleInfoById(batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		batchRuleInfo.setBankCode(BankCode.ICBC);
		MockCurrentResult.setMockValue(IBatchRuleInfoDao.class, "updateBatchRuleInfoById",new Exception ("处理异常"));
		try {
			batchRuleInfoService.updateBatchRuleInfoById(batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void isEnableTest() {
		try {
			batchRuleInfoService.isEnAble(1015L, BatchRuleStatus.DISABLE);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			batchRuleInfoService.isEnAble(-10L, BatchRuleStatus.DISABLE);
		} catch (Exception e) {
			logger.error("", e);
		}
		MockCurrentResult.setMockValue(IBatchRuleInfoDao.class, "isEnAble",new Exception ("处理异常"));
		try {
			batchRuleInfoService.isEnAble(1015L, BatchRuleStatus.DISABLE);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void deleteBatchRuleInfo() {
		List<Long> list = new ArrayList<Long>();
		list.add(1000000L);
		try {
			batchRuleInfoService.deleteBatchRuleInfo(list);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			batchRuleInfoService.deleteBatchRuleInfo(null);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		MockCurrentResult.setMockValue(IBatchRuleInfoDao.class, "deleteBatchRuleInfo",new Exception ("处理异常"));
		try {
			batchRuleInfoService.deleteBatchRuleInfo(list);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void listAllBatchRuleInfoTest() {
		try {
			batchRuleInfoService.listAllBatchRuleInfo();
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testQueryBatchRuleInfoByCode() {
		try {
			batchRuleInfoService.queryBatchRuleInfoByCode("200001");
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			batchRuleInfoService.queryBatchRuleInfoByCode("");
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testQueryBatchRuleInfoById() {
		try {
			batchRuleInfoService.queryBatchRuleInfoById(100L);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			batchRuleInfoService.queryBatchRuleInfoById(-1L);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

}
