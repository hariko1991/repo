/**
 * 
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

import com.sfpay.acquirer.domain.AcctBizDetail;
import com.sfpay.acquirer.domain.AcctBizQueryParam;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 类说明：
 *  
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-5-28
 */
public class AcctBizDaoTest extends SpringTestCase {
	
	private static Logger logger = LoggerFactory.getLogger(AcctBizDaoTest.class);
	
	@Resource
	private IAcctBizDao dao;
	
	@Test
	public void testQueryAcctBizPageCount() {
		AcctBizQueryParam param = new AcctBizQueryParam();
		param.setChannelCode(ChannelCode.B2C);
		try { 
			long count = dao.queryAcctBizPageCount(param);
			logger.debug("count is:"+count);
			} catch(DataAccessException e) {  
			    System.out.println("test:" + e.getMessage());  
		} 
	}
	
	@Test
	public void testQueryAcctBizPageList() {
		AcctBizQueryParam param = new AcctBizQueryParam();
		param.setChannelCode(ChannelCode.B2C);
		List<AcctBizDetail> list=null;
		try { 
		list = dao.queryAcctBizPageList(param, 1, 10);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		} 
	}
	
	@Test
	public void testQueryBankChannelCount() {
		AcctBizDetail param = new AcctBizDetail();
		param.setBankCode(BankCode.ICBC);
		param.setChannelCode(ChannelCode.B2C);
		param.setOrderType(OrderType.RECHARGE);
		param.setFundWay(FundWay.IN);
		try { 
				long i = dao.queryBankChannelCount(param);
				logger.debug("count is:"+i);
			} catch(DataAccessException e) {  
			    System.out.println("test:" + e.getMessage());  
			} 
	}
	
	@Test
	public void testAddAcctBiz(){
		/*AcctBizDetail detail = new AcctBizDetail();
		detail.setAccountNo("123123");
		detail.setChannelCode(ChannelCode.QPAY);
		detail.setFundWay(FundWay.IN);
		detail.setOrderType(OrderType.RECHARGE);
		dao.addAcctBiz(detail);*/
	}
	
	@Test
	public void testDeleteAcctBiz(){
		try { 
			dao.deleteAcctBiz(5000L);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		} 
	}
}
