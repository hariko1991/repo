package com.sfpay.acquirer.service.impl;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.domain.CollectInfo;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.acquirer.service.IQPayBankInterfaceService;
import com.sfpay.framework.web.test.SpringTestCase;

public class QPayBankInterfaceServiceTest  extends SpringTestCase {
	@Resource
	private IQPayBankInterfaceService service;
	@Test
	public void testDoQPayPaymentPrepare(){
		CollectInfo info=new CollectInfo();
		info.setOrderType(OrderType.PAYOUT);
		try{
			service.doQPayPaymentPrepare(info);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}
	@Test
	public void testDoQPayPaymentPost(){
		CollectInfo info=new CollectInfo();
		info.setBankCode(BankCode.ABC);
		info.setChannelCode(ChannelCode.B2C);
		try{
			service.doQPayPaymentPost(info,"<name>12321</name>");
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}
}
