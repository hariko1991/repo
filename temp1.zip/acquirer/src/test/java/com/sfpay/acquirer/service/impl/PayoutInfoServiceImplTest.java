package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IOftenColInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.enums.AcctType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.acquirer.service.IPayoutInfoService;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;
import com.sfpay.framework.web.test.SpringTestCase;

public class PayoutInfoServiceImplTest extends ClassTransactionalTestCase{

	@Resource
	private IPayoutInfoService service;
	
	@Test
	public void testdeletePayOutInfo(){
		try{
			List<Long> ids = null;
			service.deletePayOutInfo(ids);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		
		try{
			List<Long> ids = new ArrayList<Long>();
			ids.add(1147L);
			service.deletePayOutInfo(ids);
		}catch(Exception ex){
			logger.error("",ex);
		}

		try{
			List<Long> ids = new ArrayList<Long>();
			ids.add(1147L);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "softDeleteByIds",new Exception(""));
			service.deletePayOutInfo(ids);
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
	
	@Test
	public void testupdatePayOutInfo(){
		try{
			PayoutInfo payoutInfo = null;
			service.updatePayOutInfo(payoutInfo);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			PayoutInfo payoutInfo = new PayoutInfo();
			payoutInfo.setId(4091L);
			payoutInfo.setSummary("我人有的和主产不为这国中是上一地在要工工经以发了民同");
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updatePayoutById",new Exception(""));
			MockCurrentResult.setMockValue(IOftenColInfoDao .class, "saveOrUpdateOften",new Exception(""));
			service.updatePayOutInfo(payoutInfo);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			PayoutInfo payoutInfo = new PayoutInfo();
			payoutInfo.setId(4091L);
			payoutInfo.setSummary("我人有的和主产不为这国中是上一地在要工工经以发了民同");
			MockCurrentResult.setMockValue(IOftenColInfoDao .class, "saveOrUpdateOften",new Exception(""));
			service.updatePayOutInfo(payoutInfo);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			PayoutInfo payoutInfo = new PayoutInfo();
			payoutInfo.setId(4091L);
			payoutInfo.setPayeeAcctName("11");
			payoutInfo.setPayeeAcctNo("11");
			payoutInfo.setPayeeAcctType(AcctType.COMPANY);
			payoutInfo.setPayeeOrgCode(BankCode.CMB);
			payoutInfo.setPayeeMobile("1");
			payoutInfo.setPayeeAcctAddr("1");
			payoutInfo.setPayeeAcctCity("1");
			payoutInfo.setPayeeBranchCode("1");
			payoutInfo.setPayeeAcctProvince("1");
			payoutInfo.setRemark("11");
			payoutInfo.setPayeeBranchName("123");
			payoutInfo.setPayeeAcctProvinceName("111");
			payoutInfo.setPayeeAcctCityName("12345");
			
			payoutInfo.setSaveColtCompFlag(YNFlag.Y);
			payoutInfo.setSummary("我人有的和主产不为这国中是上一地在要工工经以发了民同");
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updatePayoutById", 0);
			MockCurrentResult.setMockValue(IOftenColInfoDao .class, "saveOrUpdateOften",null);
			service.updatePayOutInfo(payoutInfo);
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
	
	@Test 
	public void testCreateBatch(){
		
		List<String> lists=new ArrayList<String>();
		lists.add("0");
		lists.add("1");
		lists.add("2");
		lists.add("3");
		lists.add("4");
		lists.add("5");
		lists.add("6");
		lists.add("7");
		lists.add("8");
		long paySize=lists.size();
		
		long maxSize=9;
		
		long blockSize=paySize/maxSize;
		
		long loopSize=paySize%maxSize==0?blockSize:blockSize+1;
		
		for(int i=0;i<loopSize;i++){
			List<String> tem=lists.subList(Integer.parseInt(String.valueOf(i*maxSize)),Integer.parseInt(String.valueOf((i+1)*maxSize>lists.size()?lists.size():(i+1)*maxSize)));
		}
		
	}
}
