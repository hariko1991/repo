/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.domain.BankChannel;
import com.sfpay.acquirer.domain.BankChannelQueryParam;
import com.sfpay.acquirer.domain.BankChannelUpdateParam;
import com.sfpay.acquirer.enums.BankChannelStatus;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.service.IBankChannelService;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 类说明：
 *  
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-5-28
 */
public class BankChannelServiceImplTest extends SpringTestCase {

	@Resource
	private IBankChannelService service;

	@Test
	public void testQueryBankChannelPage(){
		try {
			int pageNo = 1;
			int limit = 10;
			BankChannelQueryParam param = new BankChannelQueryParam();
			IPage<BankChannel> page = service.queryBankChannelPage(param, pageNo, limit);
			logger.debug("total: {}", page.getTotalRecord());
		} catch (Exception e) {
			logger.error("", e);
		}

	}

	@Test
	public void testUpdateStatus(){
		try {
			service.updateStatus(ChannelCode.B2C, BankCode.YEEPAY, BankChannelStatus.ENABLED);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
		try {
			service.updateStatus(null, BankCode.YEEPAY, BankChannelStatus.ENABLED);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
		try {
			service.updateStatus(ChannelCode.B2C,null, BankChannelStatus.ENABLED);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
		try {
			service.updateStatus(ChannelCode.B2C,BankCode.YEEPAY, null);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testUpdateBankChannel(){
		try {
			BankChannelUpdateParam param = new BankChannelUpdateParam();
			param.setBankCode(BankCode.YEEPAY);
			param.setBankName("易宝支付");

			param.setChannelCode(ChannelCode.B2C);
			param.setChannelName("网银");

			param.setShowIndex(1L);
			service.updateBankChannel(param);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
		
		try {
			BankChannelUpdateParam param = new BankChannelUpdateParam();
			param.setBankCode(BankCode.YEEPAY);
			param.setBankName("");

			param.setChannelCode(ChannelCode.B2C);
			param.setChannelName("网银");

			param.setShowIndex(1L);
			service.updateBankChannel(param);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
		
		try {
			BankChannelUpdateParam param = new BankChannelUpdateParam();
			param.setBankCode(BankCode.YEEPAY);
			param.setBankName("易宝支付");

			param.setChannelCode(null);
			param.setChannelName("网银");

			param.setShowIndex(1L);
			service.updateBankChannel(param);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
	}
	
	@Test
	public void testQueryBankChannelList(){
		try {
			List<BankChannel> list = service.queryBankChannelList(ChannelCode.B2C);
			logger.debug("list is:"+list.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			List<BankChannel> list = service.queryBankChannelList(null);
			logger.debug("list is:"+list.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			List<BankChannel> list = service.queryBankChannelAllList(null);
			logger.debug("list is:"+list.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	

	@Test
	public void testQueryBankChannelAllList(){
		try {
			List<BankChannel> list = service.queryBankChannelAllList(ChannelCode.B2C);
			logger.debug("list is:"+list.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			List<BankChannel> list = service.queryBankChannelAllList(null);
			logger.debug("list is:"+list.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	

	@Test
	public void testQueryBankChannel(){
		try {
			BankChannel bankChannel = service.queryBankChannel(ChannelCode.B2C,BankCode.ICBC);
			logger.debug("bankChannel is:"+bankChannel.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			BankChannel bankChannel = service.queryBankChannel(null,BankCode.ICBC);
			logger.debug("bankChannel is:"+bankChannel.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			BankChannel bankChannel = service.queryBankChannel(ChannelCode.B2C,null);
			logger.debug("bankChannel is:"+bankChannel.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testQueryAllBankList(){
		try {
			List<BankChannel> list = service.queryAllBankList(ChannelCode.B2C,true);
			logger.debug("list is:"+list.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			List<BankChannel> list = service.queryAllBankList(null,true);
			logger.debug("list is:"+list.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testQueryAllBankList4Test(){
		try {
			List<BankChannel> list = service.queryAllBankList4Test(ChannelCode.B2C, "127.0.0.1", true);
			logger.debug("list size: {}", list.size());
		} catch (Exception e) {
			logger.error("", e);
		}
	}

}
