/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.Date;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.service.IReconGatewayFileService;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-7-22
 */
public class ReconGatewayFileServiceTest extends SpringTestCase {

	@Resource
	private IReconGatewayFileService service;
	
	@Test
	public void testCreateFile(){
		try{
			service.doGateReconFile(new Date(), false);
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
}
