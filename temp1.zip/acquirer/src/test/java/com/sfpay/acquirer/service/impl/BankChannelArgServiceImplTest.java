/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import java.util.Map;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.common.AcquirerHelper;
import com.sfpay.acquirer.domain.BankChannelArg;
import com.sfpay.acquirer.domain.BankChannelArgQueryParam;
import com.sfpay.acquirer.domain.BankChannelArgUpdateParam;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.service.IBankChannelArgService;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 类说明：
 *  
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-5-28
 */
public class BankChannelArgServiceImplTest extends SpringTestCase {

	@Resource
	private IBankChannelArgService service;

	@Test
	public void testQueryBankChannelArgPage(){
		try {
			BankChannelArgQueryParam param = new BankChannelArgQueryParam();
			param.setBankCode(BankCode.PAB);
			param.setChannelCode(ChannelCode.B2C);
			IPage<BankChannelArg> page = service.queryBankChannelArgPage(param, 1, 10);
			logger.debug("page is:"+ page == null ? "" : page.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
		try {
			BankChannelArgQueryParam param = new BankChannelArgQueryParam();
			param.setBankCode(BankCode.PAB);
			param.setChannelCode(ChannelCode.B2C);
			IPage<BankChannelArg> page = service.queryBankChannelArgPage(param, 0, 10);
			logger.debug("page is:"+ page == null ? "" : page.toString());
		} catch (Exception e) {
			logger.error("", e);
		}

	}

	@Test
	public void testUpdateBankChannelArgById(){
		try {
			BankChannelArgUpdateParam param = new BankChannelArgUpdateParam();
			param.setId(100000L);
			param.setArgName("ff");
			param.setArgValue("14");
			param.setRemark("remark");
			service.updateBankChannelArgById(param);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			BankChannelArgUpdateParam param = new BankChannelArgUpdateParam();
			param.setId(-1L);
			param.setArgName("ff");
			param.setArgValue("14");
			param.setRemark("remark");
			service.updateBankChannelArgById(param);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testCacheLoad() {
		try {
			//		System.setProperty("test_prop_path", "D:/work/acquirer/config/constant.properties");

			logger.debug(AcquirerHelper.getProperties(BankCode.ICBC, ChannelCode.B2C).get("keyPath"));

			//		BankChannelArgUpdateParam param = new BankChannelArgUpdateParam();
			//		param.setId(1000L);
			//		param.setRemark("remark");
			//		service.updateBankChannelArgById(param);
			//		logger.debug(AcquirerHelper.getProperties(BankCode.ICBC, ChannelCode.B2C).get("keyPath"));
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testGetBankChannelArgs(){	
		try {
			Map<String, String> args = service.getBankChannelArgs(BankCode.ALIPAY, ChannelCode.B2C);
			logger.debug("args size is:"+ args == null ? "" : String.valueOf(args.size()));
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testQueryBankChannelArgById(){		
		try {
			BankChannelArg arg = service.queryBankChannelArgById(1);	
			logger.debug("arg is:"+ arg == null ? "" : arg.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testGetBankChannelArgs1(){		
		try {
			Map<String, BankProperty> args= service.getBankChannelArgs();	
			logger.debug("args size is:"+ args == null ? "" : String.valueOf(args.size()));
		} catch (Exception e) {
			logger.error("", e);
		}
	}
}
