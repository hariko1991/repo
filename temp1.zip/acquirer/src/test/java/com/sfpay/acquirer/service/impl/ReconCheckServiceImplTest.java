package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IReconBankFileCreateDao;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.ReconBankFileCreate;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.service.IReconCheckService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class ReconCheckServiceImplTest extends ClassTransactionalTestCase {
	
	@Resource
	private IReconCheckService  service;
	
	
	@Test
	public void testSaveBankFile(){
		ReconBankFileCreate  info=new ReconBankFileCreate ();
		
		try{
			info=new ReconBankFileCreate();
			service.saveBankFile(info);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
		try{
			info=new ReconBankFileCreate();
			info.setChannelCode(ChannelCode.B2C);
			service.saveBankFile(info);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
		try{
			info=new ReconBankFileCreate();
			info.setChannelCode(ChannelCode.B2C);
			info.setBankCode(BankCode.ABC);
			service.saveBankFile(info);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
		try{
			info=new ReconBankFileCreate();
			info.setChannelCode(ChannelCode.B2C);
			info.setBankCode(BankCode.ABC);
			info.setTradeDate(new Date());
			service.saveBankFile(info);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
		try{
			info=new ReconBankFileCreate();
			info.setChannelCode(ChannelCode.B2C);
			info.setBankCode(BankCode.ABC);
			info.setTradeDate(new Date());
			info.setFileGetDate(new Date());
			service.saveBankFile(info);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
		try{
			info=new ReconBankFileCreate();
			info.setChannelCode(ChannelCode.B2C);
			info.setBankCode(BankCode.ABC);
			info.setTradeDate(new Date());
			info.setFileGetDate(new Date());
			info.setFileGetFlag("2");
			MockCurrentResult.setMockValue(IReconBankFileCreateDao.class, "query", null);
			service.saveBankFile(info);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
		try{
			info=new ReconBankFileCreate();
			info.setChannelCode(ChannelCode.B2C);
			info.setBankCode(BankCode.CMB);
			info.setTradeDate(new Date());
			info.setFileGetDate(new Date());
			info.setFileGetFlag("Y");
			List<ReconBankFileCreate> list=new ArrayList<ReconBankFileCreate>();
			ReconBankFileCreate fileInfo=new ReconBankFileCreate();
			list.add(fileInfo);
			MockCurrentResult.setMockValue(IReconBankFileCreateDao.class, "query",list);
			MockCurrentResult.setMockValue(IReconBankFileCreateDao.class, "update",null);
			MockCurrentResult.setMockValue(IReconBankFileCreateDao.class, "save",null);
			service.saveBankFile(info);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
		try{
			info=new ReconBankFileCreate();
			MockCurrentResult.setMockValue(IReconBankFileCreateDao.class, "query",null);
			service.saveBankFile(info);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
	}
	@Test
	public void testIsRecon(){
		try{
			service.isRecon(null,ChannelCode.B2C,new Date());
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
		try{
			service.isRecon(BankCode.CMB,null,new Date());
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
		try{
			service.isRecon(BankCode.CMB,ChannelCode.B2C,null);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
		List<ReconBankFileCreate> list=new ArrayList<ReconBankFileCreate>();
		ReconBankFileCreate fileInfo=new ReconBankFileCreate();
		fileInfo.setFileGetFlag("N");
		list.add(fileInfo);
		MockCurrentResult.setMockValue(IReconBankFileCreateDao.class, "query",list);
		try{
			service.isRecon(BankCode.CMB,ChannelCode.B2C,new Date());
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		fileInfo.setFileGetFlag("Y");
		try{
			service.isRecon(BankCode.CMB,ChannelCode.B2C,new Date());
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
		MockCurrentResult.setMockValue(IReconBankFileCreateDao.class, "query",null);
		try{
			service.isRecon(BankCode.CMB,ChannelCode.B2C,new Date());
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
	}
	
	@Test
	public void testCheckReconTime(){
		BankProperty bankProperty = new BankProperty();
		
		try{
			bankProperty = new BankProperty();
			service.checkReconTime(bankProperty);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
		try{
			bankProperty = new BankProperty();
			bankProperty.put("ReconTime", "6:12|8:11");
			service.checkReconTime(bankProperty);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
		
		try{
			bankProperty = new BankProperty();
			bankProperty.put("ReconTime", "10:12|8:11");
			service.checkReconTime(bankProperty);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
	}
	
}
