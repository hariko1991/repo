/**
 * 
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.dao.DataAccessException;

import com.sfpay.acquirer.domain.UnkownCollect;
import com.sfpay.acquirer.domain.UnkownCollectParam;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.CollectStatus;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 类说明： 未知收单信息测试
 * 
 * <p/>
 * 详细描述：
 * 
 * 
 * @author 312932 何国兴
 * 
 * CreateDate: 2012-5-10
 */
public class UnkownCollectDaoTest extends SpringTestCase {

	@Resource
	private IUnkownCollectDao dao;

	@Test
	public void testAddUnkownCollectFromCollectInfo() {
		try { 
			dao.addUnkownCollectFromCollectInfo();
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}

	@Test
	public void testQueryUnkownCollectList() {
		
		try { 
			List<UnkownCollect> list = dao.queryUnkownCollectList(ChannelCode.B2C, BankCode.PAB, OrderType.RECHARGE, FundWay.IN);
			logger.debug(list == null ? "" : list.toString());
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}

	@Test
	public void testUpdateUnkownCollect() {
		UnkownCollectParam param = new UnkownCollectParam();
		param.setCollectNo("1308210000003072");
		param.setRtnBankCode("");
		param.setRtnBankMsg("");
		param.setRtnPayCode("");
		param.setStatus(CollectStatus.INIT);
		try { 
			dao.updateUnkownCollect(param);
			logger.debug("{}", param.getProRtnCode());
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
}
