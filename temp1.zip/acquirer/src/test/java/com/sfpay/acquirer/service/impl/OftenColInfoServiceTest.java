package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IChannelRateInfoDao;
import com.sfpay.acquirer.dao.IOftenColInfoDao;
import com.sfpay.acquirer.domain.OftenColInfo;
import com.sfpay.acquirer.domain.OftenColInfoQueryParam;
import com.sfpay.acquirer.enums.AcctType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.service.IOftenColInfoService;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;
import com.sfpay.framework.web.test.SpringTestCase;
import com.sfpay.organ.service.IOrgAccountService;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu) CreateDate: 2013-8-27
 */
public class OftenColInfoServiceTest extends ClassTransactionalTestCase {

	@Resource
	private IOftenColInfoService oftenColInfoService;
	
	@Test
	public void testlistAllOftenColInfo(){
		oftenColInfoService.listAllOftenColInfo();
	}
	
	@Test
	public void testQueryEcsOftenColInfoPage(){
		OftenColInfoQueryParam param = new OftenColInfoQueryParam();
		try {
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "queryEcsOftenColInfoPageCount",10l);
			IPage<OftenColInfo> page = oftenColInfoService.queryEcsOftenColInfoPage(param, 1, 2);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "queryEcsOftenColInfoPageCount",10l);
			IPage<OftenColInfo> page = oftenColInfoService.queryEcsOftenColInfoPage(param, 0, 2);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testQueryOftenColInfoPage() {
		OftenColInfoQueryParam param = new OftenColInfoQueryParam();
		try {
			IPage<OftenColInfo> page = oftenColInfoService.queryOftenColInfoPage(param, 1, 2);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			IPage<OftenColInfo> page = oftenColInfoService.queryOftenColInfoPage(param, 0, 2);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testAddOftenColInfo() {
		OftenColInfo oftenColInfo = new OftenColInfo();
		
		try {
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "addOftenColInfo",null);
			oftenColInfoService.addOftenColInfo(null);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			oftenColInfo = new OftenColInfo();
			oftenColInfo.setId(0l);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "addOftenColInfo",null);
			oftenColInfoService.addOftenColInfo(oftenColInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			oftenColInfo = new OftenColInfo();
			oftenColInfo.setId(3333333l);
			oftenColInfo.setBankCode(BankCode.CMB);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "addOftenColInfo",null);
			oftenColInfoService.addOftenColInfo(oftenColInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			oftenColInfo = new OftenColInfo();
			oftenColInfo.setId(3333333l);
			oftenColInfo.setBankCode(BankCode.CMB);
			oftenColInfo.setAccountNo("221111111122211");
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "addOftenColInfo",null);
			oftenColInfoService.addOftenColInfo(oftenColInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			oftenColInfo = new OftenColInfo();
			oftenColInfo.setId(3333333l);
			oftenColInfo.setBankCode(BankCode.CMB);
			oftenColInfo.setAccountNo("221111111122211");
			oftenColInfo.setAccountName("测试单位5");
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "addOftenColInfo",null);
			oftenColInfoService.addOftenColInfo(oftenColInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			oftenColInfo = new OftenColInfo();
			oftenColInfo.setId(3333333l);
			oftenColInfo.setBankCode(BankCode.CMB);
			oftenColInfo.setAccountNo("221111111122211");
			oftenColInfo.setAccountName("测试单位5");
			oftenColInfo.setAcctType(AcctType.COMPANY);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "addOftenColInfo",null);
			oftenColInfoService.addOftenColInfo(oftenColInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
		try {
			oftenColInfo = new OftenColInfo();
			oftenColInfo.setId(3333333l);
			oftenColInfo.setBankCode(BankCode.CMB);
			oftenColInfo.setAccountNo("4000021419200211527A");
			oftenColInfo.setAccountName("测试单位5");
			oftenColInfo.setAcctType(AcctType.COMPANY);
			OftenColInfo dbCol = null;
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "queryOftenColInfoByAcctNo",dbCol);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "addOftenColInfo",null);
			oftenColInfoService.addOftenColInfo(oftenColInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			oftenColInfo = new OftenColInfo();
			oftenColInfo.setColCompName("333收款公司5");
			oftenColInfo.setAccountNo("221111111122211");
			oftenColInfo.setAccountName("测试单位5");
			oftenColInfo.setBankCode(BankCode.CMB);
			oftenColInfo.setAcctType(AcctType.COMPANY);
			oftenColInfo.setCcy(CurrencyType.RMB);
			oftenColInfo.setObNo("12345678");
			oftenColInfo.setObProvince("110000");
			oftenColInfo.setObCity("110111");
			oftenColInfo.setObAddr("987654");
			oftenColInfo.setCompManager("负责人3");
			oftenColInfo.setManagerMobile("13111111111");
			oftenColInfo.setRemark("备注3");
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "addOftenColInfo",null);
			oftenColInfoService.addOftenColInfo(oftenColInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			oftenColInfo = new OftenColInfo();
			oftenColInfo.setColCompName("333收款公司5");
			oftenColInfo.setAccountNo("221111111122211");
			oftenColInfo.setAccountName("测试单位5");
			oftenColInfo.setBankCode(BankCode.CMB);
			oftenColInfo.setAcctType(AcctType.COMPANY);
			oftenColInfo.setCcy(CurrencyType.RMB);
			oftenColInfo.setObNo("12345678");
			oftenColInfo.setObProvince("110000");
			oftenColInfo.setObCity("110111");
			oftenColInfo.setObAddr("987654");
			oftenColInfo.setCompManager("负责人3");
			oftenColInfo.setManagerMobile("13111111111");
			oftenColInfo.setRemark("备注3");
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "addOftenColInfo",new Exception(""));
			oftenColInfoService.addOftenColInfo(oftenColInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testUpdateOftenColInfoById() {
		OftenColInfo oftenColInfo = new OftenColInfo();
		
		try {
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "updateOftenColInfoById",null);
			oftenColInfoService.updateOftenColInfoById(null);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			oftenColInfo = new OftenColInfo();
			oftenColInfo.setId(0l);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "updateOftenColInfoById",null);
			oftenColInfoService.updateOftenColInfoById(oftenColInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			oftenColInfo = new OftenColInfo();
			oftenColInfo.setId(11l);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "updateOftenColInfoById",null);
			oftenColInfoService.updateOftenColInfoById(oftenColInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			oftenColInfo = new OftenColInfo();
			oftenColInfo.setId(1023L);
			oftenColInfo.setBankCode(BankCode.CMB);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "updateOftenColInfoById",null);
			oftenColInfoService.updateOftenColInfoById(oftenColInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			oftenColInfo = new OftenColInfo();
			oftenColInfo.setId(1023L);
			oftenColInfo.setBankCode(BankCode.CMB);
			oftenColInfo.setAccountNo("221111111122211");
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "updateOftenColInfoById",null);
			oftenColInfoService.updateOftenColInfoById(oftenColInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			oftenColInfo = new OftenColInfo();
			oftenColInfo.setId(1023L);
			oftenColInfo.setBankCode(BankCode.CMB);
			oftenColInfo.setAccountNo("221111111122211");
			oftenColInfo.setAccountName("测试单位5");
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "updateOftenColInfoById",null);
			oftenColInfoService.updateOftenColInfoById(oftenColInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			oftenColInfo = new OftenColInfo();
			oftenColInfo.setId(1023L);
			oftenColInfo.setBankCode(BankCode.CMB);
			oftenColInfo.setAccountNo("221111111122211");
			oftenColInfo.setAccountName("测试单位5");
			oftenColInfo.setAcctType(AcctType.COMPANY);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "updateOftenColInfoById",null);
			oftenColInfoService.updateOftenColInfoById(oftenColInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
		try {
			oftenColInfo = new OftenColInfo();
			oftenColInfo.setId(1023L);
			oftenColInfo.setBankCode(BankCode.CMB);
			oftenColInfo.setAccountNo("4000021419200211527A");
			oftenColInfo.setAccountName("测试单位5");
			oftenColInfo.setAcctType(AcctType.COMPANY);
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "updateOftenColInfoById",null);
			oftenColInfoService.updateOftenColInfoById(oftenColInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
		try {
			oftenColInfo = new OftenColInfo();
			oftenColInfo.setId(1023L);
			oftenColInfo.setColCompName("收款公司6");
			oftenColInfo.setAccountNo("221111118787");
			oftenColInfo.setAccountName("测试单位6");
			oftenColInfo.setBankCode(BankCode.CMB);
			oftenColInfo.setAcctType(AcctType.COMPANY);
			oftenColInfo.setCcy(CurrencyType.RMB);
			oftenColInfo.setObNo("36987");
			oftenColInfo.setObProvince("999");
			oftenColInfo.setObCity("888");
			oftenColInfo.setObAddr("987654");
			oftenColInfo.setCompManager("负责人5");
			oftenColInfo.setManagerMobile("132222222222");
			oftenColInfo.setRemark("备注5");
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "updateOftenColInfoById",null);
			oftenColInfoService.updateOftenColInfoById(oftenColInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void deleteOftenColInfo() {
		List<Long> list = new ArrayList<Long>();
		list.add(1033L);
		try {
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "deleteOftenColInfo",null);
			oftenColInfoService.deleteOftenColInfo(list);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			MockCurrentResult.setMockValue(IOftenColInfoDao.class, "deleteOftenColInfo",null);
			oftenColInfoService.deleteOftenColInfo(null);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void queryOftenColInfoByAcctNoTest() {
		String accountNo = "111111";
		try {
			OftenColInfo col = oftenColInfoService.queryOftenColInfoByAcctNo(accountNo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			OftenColInfo col = oftenColInfoService.queryOftenColInfoByAcctNo(null);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void queryOftenColInfoIdTest() {
		try {
			OftenColInfo col = oftenColInfoService.queryOftenColInfoById(0l);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			OftenColInfo col = oftenColInfoService.queryOftenColInfoById(1);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

}
