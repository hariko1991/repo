/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.ICheckReconInfoDao;
import com.sfpay.acquirer.dao.IReconBankFileCreateDao;
import com.sfpay.acquirer.domain.ReconCollectRlt;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.service.ICheckReconInfoService;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-8-26
 */
public class CheckReconInfoServiceImpleTest extends ClassTransactionalTestCase {
	
	@Resource
	private ICheckReconInfoService service;
	
	@Test
	public void testFindReconLose() {
		try {
			MockCurrentResult.setMockValue(ICheckReconInfoDao.class, "findReconLose",null);
			service.findReconLose(BankCode.YEEPAY, ChannelCode.B2C, "2013-08-05");
		} catch (Exception e) {
			logger.error("",e);
		}
		
	}
	
	@Test
	public void testUpdateReconCollectRltState() {
		try {
			MockCurrentResult.setMockValue(ICheckReconInfoDao.class, "updateReconCollectRltState",null);
			service.updateReconCollectRltState(1L);
		} catch (Exception e) {
			logger.error("",e);
		}
		
	}
	
	@Test
	public void testUpdateCollectInfoState() {
		try {
			MockCurrentResult.setMockValue(ICheckReconInfoDao.class, "updateCollectInfoState",null);
			service.updateCollectInfoState("",BankCode.YEEPAY, ChannelCode.B2C, FundWay.IN);
		} catch (Exception e) {
			logger.error("",e);
		}
	}
	
	@Test
	public void testupdateReconCollectRltFromCollectInfo() {
		try {
			MockCurrentResult.setMockValue(ICheckReconInfoDao.class, "updateReconCollectRltFromCollectInfo",null);
			service.updateReconCollectRltFromCollectInfo(100L,BankCode.YEEPAY, ChannelCode.B2C, FundWay.IN,"h");
		} catch (Exception e) {
			logger.error("",e);
		}
	
	}

}
