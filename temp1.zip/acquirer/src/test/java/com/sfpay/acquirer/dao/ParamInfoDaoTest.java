/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.dao.DataAccessException;

import com.sfpay.acquirer.domain.ParamInfo;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-9-9
 */
public class ParamInfoDaoTest extends SpringTestCase {
	@Resource
	private IParamInfoDao dao;
	
	@Test
	public void testFindByKeys() {
		try { 
			List<ParamInfo> ls = dao.findByKeys(Arrays.asList(new String[]{"URL_BOUNCE_COD", "URL_BOUNCE_PAS"}));
			logger.debug("{}", ls);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
}
