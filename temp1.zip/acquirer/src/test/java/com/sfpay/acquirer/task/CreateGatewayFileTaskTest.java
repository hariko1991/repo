/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.task;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.service.IReconGatewayFileService;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-7-24
 */
public class CreateGatewayFileTaskTest extends ClassTransactionalTestCase{

	@Resource
	private CreateGatewayFileTask task;
	
	@Test
	public void test(){
		MockCurrentResult.setMockValue(IReconGatewayFileService.class, "doGateReconFile", null);
		try {
			task.execute();
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
}
