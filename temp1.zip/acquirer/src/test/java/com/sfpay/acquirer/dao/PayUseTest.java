/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.domain.PayUse;
import com.sfpay.acquirer.domain.PayUseQueryParam;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 类说明：<br>
 * 付款用途　dao测试类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * CreateDate: 2012-9-28
 */
public class PayUseTest extends SpringTestCase {

	@Resource
	private IPayUseDao dao;

	/**
	 * 方法说明：<br>
	 * 添加
	 */
	@Test
	public void testAddPayUse() {
		try {
			PayUse payUse = new PayUse();
			payUse.setId(1);
			payUse.setUseDesc("测试5");
			payUse.setShowIndex(5L);
			payUse.setRemark("备注5");
			dao.addPayUse(payUse);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	/**
	 * 方法说明：<br>
	 * 删除
	 */
	@Test
	public void testDeletePayUse() {
		try {
			long id = 1020l;
			List<Long> ids = new ArrayList<Long>();
			ids.add(id);
			dao.deletePayUse(id);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	/**
	 * 方法说明：<br>
	 * 分页查询
	 */
	@Test
	public void testQueryUsePage() {
		PayUseQueryParam param = new PayUseQueryParam();
		param.setShowIndex(2L);
		try {
			List<PayUse> list = dao.queryUsePage(param, 1, 3);
			for (Iterator<PayUse> it = list.iterator(); it.hasNext();) {
				logger.debug("{}", it.next().toString());
			}
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	/**
	 * 方法说明：<br>
	 * 查询分页总数
	 */
	@Test
	public void testCountUsePage() {
		PayUseQueryParam param = new PayUseQueryParam();
		param.setShowIndex(2L);
		try {
			long count = dao.countUsePage(param);
			logger.debug("{}", count);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	/**
	 * 方法说明：<br>
	 * 查询所有
	 * 
	 */
	@Test
	public void testQueryUseAll() {
		try {
			List<PayUse> list = dao.queryUseAll();
			for (Iterator<PayUse> it = list.iterator(); it.hasNext();) {
				logger.debug("{}", it.next().toString());
			}
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	/**
	 * 方法说明：<br>
	 * 查询某用途记录数
	 * 
	 */
	@Test
	public void testQueryUseCount() {
		try {
			long count = dao.queryUseCount("测试", null);
			logger.debug("{}", count);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	/**
	 * 方法说明：<br>
	 * 测试条件查询
	 * 
	 */
	@Test
	public void testQueryUse() {
		try {
			PayUse param = new PayUse();
			param.setId(10);
			// param.setRemark("备");
			// param.setUseDesc("1");

			List<PayUse> list = dao.queryUse(param);
			for (Iterator<PayUse> it = list.iterator(); it.hasNext();) {
				logger.debug("{}", it.next().toString());
			}
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	/**
	 * 方法说明：<br>
	 * 根据ID查询　
	 * 
	 */
	@Test
	public void testQueryUseById() {
		try {
			PayUse payUse = dao.queryUseById(1021L);
			logger.debug("{}", payUse);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	/**
	 * 方法说明：<br>
	 * 测试根据ID修改
	 * 
	 */
	@Test
	public void testUpdatePayUseById() {
		try {
			long id = 1021;
			String useDesc = "测试111";
			String remark = "备注111";
			long showIndex = 1;
			dao.updatePayUseById(id, useDesc, remark, showIndex);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	/**
	 * 方法说明：<br>
	 * 测试修改
	 * 
	 */
	@Test
	public void testUpdatePayUse() {
		try {
			PayUse payUse = new PayUse();
			payUse.setId(1021L);
			payUse.setRemark("备注1");
			payUse.setShowIndex(null);
			payUse.setUseDesc("测试1111");

			dao.updatePayUse(payUse);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
}
