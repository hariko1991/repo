/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.common.AcquirerHelper;
import com.sfpay.acquirer.dao.IAccountInfoDao;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.AccountInfoQueryParam;
import com.sfpay.acquirer.domain.AccountInfoUpdateParam;
import com.sfpay.acquirer.enums.AccountInfoStatus;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.acquirer.service.IAccountInfoService;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 <a href="mailto:fuyuxin@sf-express.com">符瑜鑫(Ricky Fu)</a>
 * 
 * CreateDate: 2012-5-29
 */
public class AccountInfoServiceImplTest extends ClassTransactionalTestCase {

	@Resource
	private IAccountInfoService service;

	@Test
	public void testQueryAccountInfoPage() {
		try {
			AccountInfoQueryParam param = new AccountInfoQueryParam();
			//		param.setAccountNo("571905400810812");
			//	param.setBankCode(BankCode.PAB);
			param.setChannelCode(ChannelCode.B2E);
			IPage<AccountInfo> page = service.queryAccountInfoPage(param, 1, 10);
			logger.debug("page is:"+page == null ? "" : page.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testQueryAccountInfo() {
		try {
			service.queryAccountInfo(null);
		} catch (Exception e) {
			logger.error("", e);
		}
		service.queryAccountInfo(5L);
	}

	@Test
	public void testAddAccountInfo() {
			AccountInfoUpdateParam param = new AccountInfoUpdateParam();
			param.setBankCode(BankCode.BOC);
			param.setAccountNo("123456789123456");
			param.setAccountName("TEST");
			param.setStoreCode("123456789012345678901234567890");
			MockCurrentResult.setMockValue(IAccountInfoDao.class, "addAccountInfo","");
			service.addAccountInfo(param);
			try {
				service.addAccountInfo(null);
			}catch (Exception e) {
				logger.error("", e);
			}
			param.setBankCode(null);
			param.setAccountNo(null);
			param.setStoreCode(null);
			try {
				service.addAccountInfo(param);
			}catch (Exception e) {
				logger.error("", e);
			}
			param.setBankCode(BankCode.BOC);
			param.setAccountNo(null);
			param.setStoreCode(null);
			
			try {
				service.addAccountInfo(param);
			}catch (Exception e) {
				logger.error("", e);
			}
			param.setBankCode(BankCode.BOC);
			param.setAccountNo("123456789123456");
			param.setStoreCode(null);
			try {
				service.addAccountInfo(param);
			}catch (Exception e) {
				logger.error("", e);
			}
	}

	@Test
	public void testUpdateAccountInfo() {
			MockCurrentResult.setMockValue(IAccountInfoDao.class, "updateAccountInfo","");
			AccountInfoUpdateParam param = new AccountInfoUpdateParam();
			param.setAccountNo("571905400810812");
			service.updateAccountInfo(param);
			try {
				service.updateAccountInfo(null);
			}catch (Exception e) {
				logger.error("", e);
			}
			
			try {
				param.setAccountNo(null);
				service.updateAccountInfo(param);
			}catch (Exception e) {
				logger.error("", e);
			}
	}

	@Test
	public void testUpdateAccountInfoById() {
			AccountInfoUpdateParam param = new AccountInfoUpdateParam();
			param.setBankCode(BankCode.BOCM);
			param.setAccountNo("571905400810812");
			param.setAccountName("stdf");
			param.setId(99L);
			param.setProvinceName("test");
			param.setStoreCode("ddddd");
			param.setStoreNameEN("RRRRRRRRR");
			MockCurrentResult.setMockValue(IAccountInfoDao.class, "updateAccountInfoById","");
			service.updateAccountInfoById(param);
			
			
			try {
				service.updateAccountInfoById(null);
			}catch (Exception e) {
				logger.error("", e);
			}
			
			try {
				param.setAccountNo(null);
				service.updateAccountInfoById(param);
			}catch (Exception e) {
				logger.error("", e);
			}
			
			try {
				param.setBankCode(null);
				param.setAccountNo("571905400810812");
				service.updateAccountInfoById(param);
			}catch (Exception e) {
				logger.error("", e);
			}
			
			
			try {
				param.setId(0L);
				param.setBankCode(BankCode.BOCM);
				service.updateAccountInfoById(param);
			}catch (Exception e) {
				logger.error("", e);
			}
			
			try {
				param.setAccountName(null);
				param.setId(55L);
				service.updateAccountInfoById(param);
			}catch (Exception e) {
				logger.error("", e);
			}
			
			try {
				param.setStoreCode(null);
				param.setAccountName("stdf");
				service.updateAccountInfoById(param);
			}catch (Exception e) {
				logger.error("", e);
			}
	}

	@Test
	public void testUpdateStatus() {
			MockCurrentResult.setMockValue(IAccountInfoDao.class, "updateStatus","");
			service.updateStatus("571905400810812", AccountInfoStatus.ENABLED, "");
			
			try {
				service.updateStatus(null, AccountInfoStatus.ENABLED, "");
			}catch (Exception e) {
				logger.error("", e);
			}
			try {
				service.updateStatus("571905400810812", null, "");
			}catch (Exception e) {
				logger.error("", e);
			}
	}

	@Test
	public void testCacheLoad() {
		try {
			System.setProperty("test_acct_path", "D:/work/acquirer/config/account.json");

			logger.debug(AcquirerHelper.getAccount(BankCode.BOC, ChannelCode.B2C, OrderType.RECHARGE, FundWay.IN).getAccountNo());
			logger.debug(AcquirerHelper.getAccount(BankCode.CMB, ChannelCode.B2E, OrderType.PAYPAL, FundWay.OUT).getAccountNo());

			service.updateStatus("571905400810812", AccountInfoStatus.ENABLED, "");
			logger.debug(AcquirerHelper.getAccount(BankCode.CMB, ChannelCode.B2E, OrderType.PAYPAL, FundWay.OUT).getAccountNo());
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	@Test
	public void testQueryAccountInfoList() {
		try {
			List<AccountInfo> list = service.queryAccountInfoList(ChannelCode.B2E,BankCode.PAB);
			logger.debug(list == null ? "" : list.toString());
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
		try {
			 service.queryAccountInfoList(null,BankCode.PAB);
		}catch (Exception e) {
			logger.error("", e);
		}
		try {
			 service.queryAccountInfoList(ChannelCode.B2E,null);
		}catch (Exception e) {
			logger.error("", e);
		}
	}

}
