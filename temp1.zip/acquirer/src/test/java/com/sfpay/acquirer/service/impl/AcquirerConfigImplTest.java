package com.sfpay.acquirer.service.impl;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.acquirer.service.IAcquirerConfig;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class AcquirerConfigImplTest extends ClassTransactionalTestCase{
	@Resource
	private IAcquirerConfig service;

	@Test
	public void testLoadProperty(){
		try{
			service.loadProperty(BankCode.ABC, ChannelCode.B2C);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}
	
	@Test
	public void testLoadProperty1(){
		try{
			service.loadProperty();
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}
	
	@Test
	public void testLoadAccount(){
		try{
			service.loadAccount(BankCode.ABC, ChannelCode.B2C, OrderType.CANCEL, FundWay.IN);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}

}
