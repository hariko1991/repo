package com.sfpay.acquirer.service.impl;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.domain.DataTrans;
import com.sfpay.acquirer.service.IDataTransService;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class DataTransServiceImplTest extends ClassTransactionalTestCase{
	@Resource
	IDataTransService service;
	
	@Test
	public void testAddDataTrans(){
		service.addDataTrans(null);
	}
	
	@Test
	public void testUpdateDataTrans(){
		service.updateDataTrans(null);
	}
}
