/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IAffiliateBankDao;
import com.sfpay.acquirer.domain.AffiliateBank;
import com.sfpay.acquirer.domain.AffiliateBankParam;
import com.sfpay.acquirer.service.IAffiliateBankService;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 类说明：<br>
 * 银行联行号
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * CreateDate: 2012-10-23
 */
public class AffiliateBankServiceImplTest extends SpringTestCase {

	@Resource
	private IAffiliateBankService service;

	@Resource
	private IAffiliateBankDao dao;

	@Test
	public void testQueryBank() {
		try {
			List<AffiliateBank> list = service.queryBank();
			for (Iterator<AffiliateBank> it = list.iterator(); it.hasNext();) {
				AffiliateBank info = it.next();
				logger.debug("{}", info.toString());
			}
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}

	@Test
	public void testQueryAffiliate() {
		String affiliateNo = "ICBC";
		String countryCode = "440300";
		String affiliateName = "工商";
		String provinceCode = "440000";
		try {
			List<AffiliateBank> list = service.queryAffiliate(affiliateNo, countryCode, affiliateName, provinceCode);
			for (Iterator<AffiliateBank> it = list.iterator(); it.hasNext();) {
				AffiliateBank info = it.next();
				logger.debug("{}", info.toString());
			}
		} catch (Exception ex) {
			logger.error("", ex);
		}
		try {
			service.queryAffiliate("", countryCode, affiliateName, provinceCode);
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}

	@Test
	public void testQueryAffiliatePage() {
		AffiliateBankParam param = new AffiliateBankParam();
		String countryCode = "440300";
		String provinceCode = "440000";
		param.setAffiliateName("平安");
		param.setCountryCode("350100");
		param.setAffiliateNo("PAB");
		param.setCountryCode(countryCode);
		param.setProvinceCode(provinceCode);
		try {
			IPage<AffiliateBank> page = service.queryAffiliatePage(param, 1, 10);
			logger.debug("page is:" + page);
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}

	@Test
	public void testGetBankByAffiliateNo() {
		String affiliateNo = "308584001258";
		try {
			AffiliateBank abank = service.getBankByAffiliateNo(affiliateNo);
			logger.debug("abank is:" + abank);
		} catch (Exception ex) {
			logger.error("", ex);
		}
		try {
			service.getBankByAffiliateNo("");
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}

	@Test
	public void testQueryByAffiliateNo() {
		try {
			String affiliateNo = "308584001258";
			List<AffiliateBank> list = dao.queryByAffiliateNo(affiliateNo);
			for (Iterator<AffiliateBank> it = list.iterator(); it.hasNext();) {
				AffiliateBank info = it.next();
				logger.debug("{}", info == null ? "" : info.toString());
			}
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}
}
