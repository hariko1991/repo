package com.sfpay.acquirer.gate.b2e.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.enums.AcctType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.acquirer.gate.b2e.service.IBankService;
import com.sfpay.acquirer.gate.b2e.service.IQueryPayout;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class QueryPayoutTest extends ClassTransactionalTestCase{

	@Resource
	private IQueryPayout service;


	@Test
	public void testDoReq(){
		QueryPayout queryPayout = new QueryPayout();
		List<PayoutInfo> payoutInfos = new ArrayList<PayoutInfo>();
		PayoutInfo payoutInfo = new PayoutInfo();
		BatchInfo batchInfo = new BatchInfo();
		BankProperty bankProperty = new BankProperty();
		BatchRuleInfo batchRuleInfo = new BatchRuleInfo();

		try{
			bankProperty = new BankProperty();
			payoutInfos = new ArrayList<PayoutInfo>();
			payoutInfo = new PayoutInfo();
			payoutInfo.setAgentFlag(YNFlag.Y);
			payoutInfos.add(payoutInfo);
			queryPayout.doReq(batchInfo, payoutInfos, bankProperty, BankCode.ABC, batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try{
			bankProperty = new BankProperty();
			payoutInfos = new ArrayList<PayoutInfo>();
			payoutInfo = new PayoutInfo();
			batchRuleInfo = new BatchRuleInfo();
			batchRuleInfo.setOppAcctType(AcctType.PERSON);
			batchInfo = new BatchInfo();
			payoutInfo.setAgentFlag(YNFlag.N);
			payoutInfos.add(payoutInfo);
			queryPayout.doReq(batchInfo, payoutInfos, bankProperty, BankCode.ABC, batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try{
			bankProperty = new BankProperty();
			payoutInfos = new ArrayList<PayoutInfo>();
			payoutInfo = new PayoutInfo();
			batchRuleInfo = new BatchRuleInfo();
			batchRuleInfo.setOppAcctType(AcctType.COMPANY);
			batchInfo = new BatchInfo();
			payoutInfo.setAgentFlag(YNFlag.N);
			payoutInfos.add(payoutInfo);
			queryPayout.doReq(batchInfo, payoutInfos, bankProperty, BankCode.ABC, batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try{
			bankProperty = new BankProperty();
			payoutInfos = new ArrayList<PayoutInfo>();
			payoutInfo = new PayoutInfo();
			batchRuleInfo = new BatchRuleInfo();
			batchRuleInfo.setOppAcctType(null);
			batchInfo = new BatchInfo();
			payoutInfo.setAgentFlag(YNFlag.N);
			payoutInfos.add(payoutInfo);
			queryPayout.doReq(batchInfo, payoutInfos, bankProperty, BankCode.ABC, batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
	}
	
	@Test
	public void testDoResp(){
		BeanBase respBean = new BeanBase(BankCode.ABC, TradeCodeB2E.ACCOUNT_CHANGE_NOTIFY);
		QueryPayout queryPayout = new QueryPayout();
		
		try{
			respBean = new BeanBase(BankCode.ABC, TradeCodeB2E.BATCH_AGENT_TRANSFER);
			queryPayout.doResp(respBean);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try{
			respBean = new BeanBase(BankCode.ABC, TradeCodeB2E.BATCH_PAYOFF);
			queryPayout.doResp(respBean);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try{
			respBean = new BeanBase(BankCode.ABC, TradeCodeB2E.BATCH_TRANSFER);
			queryPayout.doResp(respBean);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try{
			respBean = new BeanBase(BankCode.ABC, null);
			queryPayout.doResp(respBean);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testDoQuery(){
		QueryPayout queryPayout = new QueryPayout();
		List<PayoutInfo> payoutInfos = new ArrayList<PayoutInfo>();
		PayoutInfo payoutInfo = new PayoutInfo();
		BatchInfo batchInfo = new BatchInfo();
		BankProperty bankProperty = new BankProperty();
		BatchRuleInfo batchRuleInfo = new BatchRuleInfo();

		try{
			batchInfo = new BatchInfo();
			batchInfo.setReqBankSn("2222");
			bankProperty = new BankProperty();
			payoutInfos = new ArrayList<PayoutInfo>();
			payoutInfo = new PayoutInfo();
			payoutInfo.setAgentFlag(YNFlag.Y);
			payoutInfos.add(payoutInfo);
			payoutInfo.setPayerAcctNo("111");
			payoutInfo.setPayerAcctName("222");
			payoutInfo.setPayerAcctProvinceName("333");
			payoutInfo.setPayerAcctCityName("####");
			payoutInfo.setPayerBranchName("$$$");
			batchRuleInfo = new BatchRuleInfo();
			batchRuleInfo.setOppAcctType(null);
			MockCurrentResult.setMockValue(IBankService .class, "service", "1111111111");
			queryPayout.doQuery(batchInfo, payoutInfos, bankProperty, BankCode.ABC, batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try{
			batchInfo = new BatchInfo();
			batchInfo.setReqBankSn("2222");
			bankProperty = new BankProperty();
			payoutInfos = new ArrayList<PayoutInfo>();
			payoutInfo = new PayoutInfo();
			batchRuleInfo = new BatchRuleInfo();
			batchRuleInfo.setOppAcctType(AcctType.PERSON);
			batchInfo = new BatchInfo();
			payoutInfo.setAgentFlag(YNFlag.N);
			payoutInfo.setPayerAcctNo("111");
			payoutInfo.setPayerAcctName("222");
			payoutInfo.setPayerAcctProvinceName("333");
			payoutInfo.setPayerAcctCityName("####");
			payoutInfo.setPayerBranchName("$$$");
			payoutInfos.add(payoutInfo);
			MockCurrentResult.setMockValue(IBankService .class, "service", "1111111111");
			queryPayout.doQuery(batchInfo, payoutInfos, bankProperty, BankCode.ABC, batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try{
			batchInfo = new BatchInfo();
			batchInfo.setReqBankSn("2222");
			bankProperty = new BankProperty();
			payoutInfos = new ArrayList<PayoutInfo>();
			payoutInfo = new PayoutInfo();
			batchRuleInfo = new BatchRuleInfo();
			batchRuleInfo.setOppAcctType(AcctType.COMPANY);
			batchInfo = new BatchInfo();
			payoutInfo.setAgentFlag(YNFlag.N);
			payoutInfo.setPayerAcctNo("111");
			payoutInfo.setPayerAcctName("222");
			payoutInfo.setPayerAcctProvinceName("333");
			payoutInfo.setPayerAcctCityName("####");
			payoutInfo.setPayerBranchName("$$$");
			payoutInfos.add(payoutInfo);
			MockCurrentResult.setMockValue(IBankService .class, "service", "1111111111");
			queryPayout.doQuery(batchInfo, payoutInfos, bankProperty, BankCode.ABC, batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try{
			batchInfo = new BatchInfo();
			batchInfo.setReqBankSn("2222");
			bankProperty = new BankProperty();
			payoutInfos = new ArrayList<PayoutInfo>();
			payoutInfo = new PayoutInfo();
			batchRuleInfo = new BatchRuleInfo();
			batchRuleInfo.setOppAcctType(null);
			batchInfo = new BatchInfo();
			payoutInfo.setAgentFlag(YNFlag.N);
			payoutInfo.setPayerAcctNo("111");
			payoutInfo.setPayerAcctName("222");
			payoutInfo.setPayerAcctProvinceName("333");
			payoutInfo.setPayerAcctCityName("####");
			payoutInfo.setPayerBranchName("$$$");
			payoutInfos.add(payoutInfo);
			MockCurrentResult.setMockValue(IBankService .class, "service", "1111111111");
			queryPayout.doQuery(batchInfo, payoutInfos, bankProperty, BankCode.ABC, batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try{
			batchInfo = new BatchInfo();
			batchInfo.setReqBankSn("2222");
			bankProperty = new BankProperty();
			payoutInfos = new ArrayList<PayoutInfo>();
			payoutInfo = new PayoutInfo();
			batchRuleInfo = new BatchRuleInfo();
			batchRuleInfo.setOppAcctType(AcctType.ALL);
			batchInfo = new BatchInfo();
			payoutInfo.setAgentFlag(YNFlag.N);
			payoutInfo.setPayerAcctNo("111");
			payoutInfo.setPayerAcctName("222");
			payoutInfo.setPayerAcctProvinceName("333");
			payoutInfo.setPayerAcctCityName("####");
			payoutInfo.setPayerBranchName("$$$");
			payoutInfos.add(payoutInfo);
			MockCurrentResult.setMockValue(IBankService .class, "service", "1111111111");
			queryPayout.doQuery(batchInfo, payoutInfos, bankProperty, BankCode.ABC, batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testBeanUtil(){
	}
	
	
	
}
