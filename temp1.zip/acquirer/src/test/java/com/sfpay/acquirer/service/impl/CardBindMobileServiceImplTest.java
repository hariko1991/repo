/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.util.Assert;

import com.sfpay.acquirer.service.ICardBindMobileService;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 类说明：
 *  
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-5-22
 */
public class CardBindMobileServiceImplTest extends SpringTestCase {
	@Resource
	private ICardBindMobileService service;

	@Test
	public void testGetMobileByCard() throws Exception{
		try {
			String cardNo="60584";
			String mobile = service.getMobileByCard(cardNo);
			Assert.isNull(mobile);
		} catch (Exception e) {
			logger.error("",e);
		}
		
		try {
			String mobile = service.getMobileByCard(null);
			Assert.isNull(mobile);
		} catch (Exception e) {
			logger.error("",e);
		}
	}

	@Test
	public void testAddCard() throws Exception{
		try {
			String cardNo="60584";
			String mobile="1342865231";
			service.addCard(cardNo,mobile,"");
		} catch (Exception e) {
			logger.error("",e);
		}
		
		try {
			String mobile="1342865231";
			service.addCard(null,mobile,"");
		} catch (Exception e) {
			logger.error("",e);
		}
		
		try {
			String cardNo="60584";
			service.addCard(cardNo,null,"");
		} catch (Exception e) {
			logger.error("",e);
		}
	}

	@Test
	public void testUpdateDisabledStatus() throws Exception{
		try {
			String cardNo="60584";		
			service.updateDisabledStatus(cardNo);
		} catch (Exception e) {
			logger.error("",e);
		}
		
		try {
			service.updateDisabledStatus(null);
		} catch (Exception e) {
			logger.error("",e);
		}
	}
}
