/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-8-28
 */
public class RtnPayCodeDaoTest extends SpringTestCase {
	
	@Resource
	private IRtnPayCodeDao dao;
	
	@Test
	public void testFindRtnPayCode() {
		try {
			dao.findRtnPayCode(ChannelCode.B2C, BankCode.CMB, "");
		} catch (Exception e) {
			logger.error("", e);
		}
	}

}
