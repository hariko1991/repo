package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.domain.PayoutExchange;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.ExchangeType;
import com.sfpay.acquirer.service.IPayoutExchangeService;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 
 * 类说明：<br>
 * 银企交互信息　测试类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-8-15
 */
public class PayoutExchangeServiceTest extends SpringTestCase {

	@Resource
	private IPayoutExchangeService service;
	
	@Test
	public void testCreateExchange(){
		try{
			PayoutInfo info = new PayoutInfo();
			info.setPayoutNo("test123456");
			info.setAmt(1L);
			info.setCcy(CurrencyType.RMB);
			PayoutExchange ec = this.service.createExchange(info, ExchangeType.SEND_AFTER);
			logger.debug("{}",ec);
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
	
	@Test
	public void testCreateExchangeList(){
		try{
			List<PayoutInfo> list = new ArrayList<PayoutInfo>();
			for(int i =0;i<3;i++){
				PayoutInfo info = new PayoutInfo();
				info.setPayoutNo("test1"+i);
				info.setAmt(1L);
				info.setCcy(CurrencyType.RMB);
				list.add(info);
			}
			
			List<PayoutExchange> respList =  this.service.createExchangeList(list, ExchangeType.SEND_AFTER);
			for(PayoutExchange ec : respList){
				logger.debug("{}",ec);
			}
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
	
	@Test
	public void testUpdateOrderResp(){
		try{
			String tradeNo = "111";
			String exchangeNo = "1308160000001004";
			String returnCode = "1000";
			String returnMsg = "1000";
			this.service.updateOrderResp(tradeNo, exchangeNo, returnCode, returnMsg, ExchangeType.SEND_AFTER);
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
}
