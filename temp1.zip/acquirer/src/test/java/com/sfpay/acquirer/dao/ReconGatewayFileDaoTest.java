/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import org.junit.Test;

import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 *         CreateDate: 2013-7-22
 */
public class ReconGatewayFileDaoTest extends SpringTestCase {

//	@Resource
//	private IReconGatewayFileDao dao;
//
//	@Test
//	public void test() {
//		try {
//			Date date = new Date();
//			date.setDate(25);
//			date.setYear(2013 - 1900);
//			date.setMonth(5 - 1);
//
//			List<HashMap> list = null;
//			logger.debug("{}", list.size());
//			HashMap hashMap = new HashMap();
//			for (int i = 0; i < list.size(); i++) {
//				hashMap = (HashMap) list.get(i);
//				String[] s = new String[3];
//				s[0] = hashMap.get("BANKCODE").toString();
//				logger.debug("dddd{}", s[0]);
//			}
//		} catch (Exception e) {
//		}
//	}
	
	@Test
	public void test(){
		System.out.println("test");
	}
}
