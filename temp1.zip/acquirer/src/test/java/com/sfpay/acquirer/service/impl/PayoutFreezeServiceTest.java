package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IBatchInfoDao;
import com.sfpay.acquirer.dao.IOftenColInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.dao.ITotalBatchInfoDao;
import com.sfpay.acquirer.domain.FreezeQueryParam;
import com.sfpay.acquirer.domain.OftenColInfo;
import com.sfpay.acquirer.domain.OftenColInfoQueryParam;
import com.sfpay.acquirer.domain.PayoutFreezeParam;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutQueryRlt;
import com.sfpay.acquirer.enums.FreezeFlag;
import com.sfpay.acquirer.service.IPayoutFreezeService;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 
 * 类说明：<br>
 * 冻结/解冻 测试类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-11-12
 */
public class PayoutFreezeServiceTest extends ClassTransactionalTestCase {

	@Resource
	private IPayoutFreezeService service;
	
	@Test
	public void testQueryFreezePage() {
		FreezeQueryParam param = new FreezeQueryParam();
		try {
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "countFreezeInfos",120l);
			IPage<PayoutQueryRlt> page = service.queryFreezePage(param, 0, 111);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testDoFreeze() {
		List<PayoutFreezeParam> param = new ArrayList<PayoutFreezeParam>();
		PayoutFreezeParam req  = new PayoutFreezeParam();
		int cnt = 0;
		
		try{
			param = null;
			service.doFreeze(param);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			param = new ArrayList<PayoutFreezeParam>();
			req  = null;
			param.add(req);
			service.doFreeze(param);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			param = new ArrayList<PayoutFreezeParam>();
			req  = new PayoutFreezeParam();
			param.add(req);
			service.doFreeze(param);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			param = new ArrayList<PayoutFreezeParam>();
			req  = new PayoutFreezeParam();
			req.setPayoutNo("1311120000047092");
			param.add(req);
			service.doFreeze(param);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			param = new ArrayList<PayoutFreezeParam>();
			req  = new PayoutFreezeParam();
			req.setPayoutNo("1311120000047092");
			req.setFreezeFlag(FreezeFlag.Y);
			param.add(req);
			service.doFreeze(param);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			param = new ArrayList<PayoutFreezeParam>();
			req  = new PayoutFreezeParam();
			req.setPayoutNo("1311120000047092");
			req.setFreezeFlag(FreezeFlag.Y);
			req.setOperator("111");
			param.add(req);
			cnt = 111;
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updateFreeze",cnt);
			service.doFreeze(param);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			param = new ArrayList<PayoutFreezeParam>();
			req  = new PayoutFreezeParam();
			req.setFreezeFlag(FreezeFlag.N);
			req.setPayoutNo("1311120000047092");
			req.setOperator("111");
			param.add(req);
			cnt = 111;
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updateFreeze",cnt);
			service.doFreeze(param);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			param = new ArrayList<PayoutFreezeParam>();
			req  = new PayoutFreezeParam();
			req.setFreezeFlag(FreezeFlag.N);
			req.setPayoutNo("1311120000047092");
			req.setOperator("111");
			param.add(req);
			List<PayoutInfo> pis = new ArrayList<PayoutInfo>();
			PayoutInfo pi = new PayoutInfo();
			pis.add(pi);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "findByStatus",pis);
			service.doFreeze(param);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			param = new ArrayList<PayoutFreezeParam>();
			req  = new PayoutFreezeParam();
			req.setFreezeFlag(FreezeFlag.Y);
			req.setPayoutNo("1311120000047092");
			req.setOperator("111");
			param.add(req);
			List<PayoutInfo> pis = new ArrayList<PayoutInfo>();
			PayoutInfo pi = new PayoutInfo();
			pis.add(pi);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "findByStatus",pis);
			service.doFreeze(param);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			param = new ArrayList<PayoutFreezeParam>();
			req  = new PayoutFreezeParam();
			req.setFreezeFlag(FreezeFlag.Y);
			req.setPayoutNo("1311120000047092");
			req.setOperator("111");
			param.add(req);
			List<PayoutInfo> pis = new ArrayList<PayoutInfo>();
			PayoutInfo pi = new PayoutInfo();
			pi.setBatchCode("11111");
			pis.add(pi);
			pi = new PayoutInfo();
			pi.setTotalBatchCode("2222");
			pis.add(pi);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "findByStatus",pis);
			cnt = 111;
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updateFreeze",cnt);
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "updateFreeze",cnt);
			MockCurrentResult.setMockValue(ITotalBatchInfoDao.class, "updateFreeze",cnt);
			
			service.doFreeze(param);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			param = new ArrayList<PayoutFreezeParam>();
			req  = new PayoutFreezeParam();
			req.setFreezeFlag(FreezeFlag.Y);
			req.setPayoutNo("1311120000047092");
			req.setOperator("111");
			param.add(req);
			List<PayoutInfo> pis = new ArrayList<PayoutInfo>();
			PayoutInfo pi = new PayoutInfo();
			pi.setBatchCode("11111");
			pis.add(pi);
			pi = new PayoutInfo();
			pi.setTotalBatchCode("2222");
			pis.add(pi);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "findByStatus",pis);
			cnt = 111;
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updateFreeze",new Exception(""));
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "updateFreeze", new Exception(""));
			MockCurrentResult.setMockValue(ITotalBatchInfoDao.class, "updateFreeze",new Exception(""));
			
			service.doFreeze(param);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			param = new ArrayList<PayoutFreezeParam>();
			req  = new PayoutFreezeParam();
			req.setFreezeFlag(FreezeFlag.Y);
			req.setPayoutNo("1311120000047092");
			req.setOperator("111");
			param.add(req);
			List<PayoutInfo> pis = new ArrayList<PayoutInfo>();
			PayoutInfo pi = new PayoutInfo();
			pi.setBatchCode("11111");
			pis.add(pi);
			pi = new PayoutInfo();
			pi.setTotalBatchCode("2222");
			pis.add(pi);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "findByStatus",pis);
			cnt = 111;
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updateFreeze",cnt);
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "updateFreeze", new Exception(""));
			MockCurrentResult.setMockValue(ITotalBatchInfoDao.class, "updateFreeze",new Exception(""));
			
			service.doFreeze(param);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			param = new ArrayList<PayoutFreezeParam>();
			req  = new PayoutFreezeParam();
			req.setFreezeFlag(FreezeFlag.Y);
			req.setPayoutNo("1311120000047092");
			req.setOperator("111");
			param.add(req);
			List<PayoutInfo> pis = new ArrayList<PayoutInfo>();
			PayoutInfo pi = new PayoutInfo();
			pi.setBatchCode("11111");
			pis.add(pi);
			pi = new PayoutInfo();
			pi.setTotalBatchCode("2222");
			pis.add(pi);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "findByStatus",pis);
			cnt = 111;
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updateFreeze",cnt);
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "updateFreeze", null);
			MockCurrentResult.setMockValue(ITotalBatchInfoDao.class, "updateFreeze",new Exception(""));
			
			service.doFreeze(param);
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
}
