/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.Date;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.dao.DataAccessException;

import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.domain.DataTrans;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.CommonTradeType;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 类说明：
 * 
 * 
 * <p>
 * 详细描述：
 * 
 * 
 * @author 321302
 * CreateDate: 2012-3-20
 */
public class DataTransDaoTest extends SpringTestCase {
	@Resource
	private IDataTransDao dao;

	@Test
	public void testSaveOrUpdateDataTrans() throws Exception {
		try { 
			for (int i = 0; i < 1000; i++) {
				DataTrans iData = new DataTrans();
				iData.setBeginTime(new Date());
				iData.setSerieNo(CUID.generate(20));
				iData.setBankCode(BankCode.ICBC);
				iData.setChannelCode(ChannelCode.B2E);
				iData.setDataTransType(CommonTradeType.QUERY);
				StringBuffer requestMsg = new StringBuffer("");
				requestMsg.append("first test msg.....");
				iData.setRequestMsg(requestMsg.toString());

				dao.addDataTrans(iData);
			}
		} catch(Exception e) {  
			System.out.println("test:" + e.getMessage());  
		}
	}

	@Test
	public void testSaveDataTrans() throws Exception {
		try { 
			for (int i = 0; i < 1000; i++) {
				DataTrans iData = new DataTrans();
				iData.setBeginTime(new Date());
				iData.setSerieNo(CUID.generate(20));
				iData.setBankCode(BankCode.ICBC);
				iData.setChannelCode(ChannelCode.B2E);
				iData.setDataTransType(CommonTradeType.QUERY);
				StringBuffer requestMsg = new StringBuffer("");
				requestMsg.append("first test msg.....");
				iData.setRequestMsg(requestMsg.toString());
				dao.addDataTrans(iData);
			}
		} catch(Exception e) {  
			System.out.println("test:" + e.getMessage());  
		}
	}
}
