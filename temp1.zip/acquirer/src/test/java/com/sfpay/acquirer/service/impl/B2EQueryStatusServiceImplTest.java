package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IAccountInfoDao;
import com.sfpay.acquirer.dao.IBatchInfoDao;
import com.sfpay.acquirer.dao.IBatchRuleInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.enums.AcctType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.acquirer.service.IB2EQueryStatusService;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class B2EQueryStatusServiceImplTest extends ClassTransactionalTestCase {
	@Resource
	private IB2EQueryStatusService service;
	@Test
	public void testProQueryReq(){
		BatchInfo batchInfo=new BatchInfo();
		List<BatchInfo> batchInfoList=new ArrayList<BatchInfo>();
		PayoutInfo payoutInfo=new PayoutInfo();
		List<PayoutInfo> payoutInfoList=new ArrayList<PayoutInfo>();
		AccountInfo acctInfo=new AccountInfo();
		BatchRuleInfo rule=new BatchRuleInfo();
		
		try{
			batchInfo = new BatchInfo();
			batchInfoList = new ArrayList<BatchInfo>();
			batchInfo.setReqBankSn("0001");
			batchInfoList.add(batchInfo);
			rule=new BatchRuleInfo();
			rule.setAccountNo("1111");
			rule.setOppAcctType(AcctType.COMPANY);
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "queryBatchByStatus",batchInfoList);
			MockCurrentResult.setMockValue(IBatchRuleInfoDao.class, "queryBatchRuleInfoByCode",rule);
			MockCurrentResult.setMockValue(IAccountInfoDao.class, "queryAccountInfoByAccountNo",acctInfo);
			
			payoutInfo = new PayoutInfo();
			payoutInfoList = new ArrayList<PayoutInfo>();
			
			payoutInfo.setAgentFlag(YNFlag.Y);
			payoutInfo.setAgentAcctNo("1232133213");
			payoutInfoList.add(payoutInfo);
			
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "queryByStatus",payoutInfoList);
			payoutInfo=new PayoutInfo();
			service.proQueryReq(BankCode.CMB);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
		
		MockCurrentResult.setMockValue(IBatchInfoDao.class, "queryBatchByStatus",null);
		try{
			service.proQueryReq(BankCode.CMB);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
		
		try{
			batchInfo = new BatchInfo();
			batchInfoList = new ArrayList<BatchInfo>();
			batchInfo.setReqBankSn("0001");
			batchInfoList.add(batchInfo);
			rule=new BatchRuleInfo();
			rule.setAccountNo("1111");
			rule.setOppAcctType(AcctType.PERSON);
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "queryBatchByStatus",batchInfoList);
			MockCurrentResult.setMockValue(IBatchRuleInfoDao.class, "queryBatchRuleInfoByCode",rule);
			MockCurrentResult.setMockValue(IAccountInfoDao.class, "queryAccountInfoByAccountNo",acctInfo);
			
			payoutInfo = new PayoutInfo();
			payoutInfoList = new ArrayList<PayoutInfo>();
			
			payoutInfo.setAgentFlag(YNFlag.Y);
			payoutInfo.setAgentAcctNo("1232133213");
			payoutInfoList.add(payoutInfo);
			
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "queryByStatus",payoutInfoList);
			payoutInfo=new PayoutInfo();
			service.proQueryReq(BankCode.CMB);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
		
		try{
			batchInfo = new BatchInfo();
			batchInfoList = new ArrayList<BatchInfo>();
			batchInfo.setReqBankSn("0001");
			batchInfoList.add(batchInfo);
			rule=new BatchRuleInfo();
			rule.setAccountNo("1111");
			rule.setOppAcctType(null);
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "queryBatchByStatus",batchInfoList);
			MockCurrentResult.setMockValue(IBatchRuleInfoDao.class, "queryBatchRuleInfoByCode",rule);
			MockCurrentResult.setMockValue(IAccountInfoDao.class, "queryAccountInfoByAccountNo",acctInfo);
			
			payoutInfo = new PayoutInfo();
			payoutInfoList = new ArrayList<PayoutInfo>();
			
			payoutInfo.setAgentFlag(YNFlag.Y);
			payoutInfo.setAgentAcctNo("1232133213");
			payoutInfoList.add(payoutInfo);
			
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "queryByStatus",payoutInfoList);
			payoutInfo=new PayoutInfo();
			service.proQueryReq(BankCode.CMB);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
		
		try{
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "queryBatchByStatus",null);
			service.proQueryReq(BankCode.CMB);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
		
		
		try{
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "queryBatchByStatus",batchInfoList);
			MockCurrentResult.setMockValue(IBatchRuleInfoDao.class, "queryBatchRuleInfoByCode",null);
			service.proQueryReq(BankCode.CMB);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
		
		
		try{
			MockCurrentResult.setMockValue(IBatchRuleInfoDao.class, "queryBatchRuleInfoByCode",rule);
			MockCurrentResult.setMockValue(IAccountInfoDao.class, "queryAccountInfoByAccountNo",null);
			service.proQueryReq(BankCode.CMB);
		}catch(Exception e){
			logger.info(e.getMessage());
		}
	}
}
