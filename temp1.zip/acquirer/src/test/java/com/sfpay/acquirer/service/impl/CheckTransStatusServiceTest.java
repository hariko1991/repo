package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutRespResult;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.acquirer.enums.CmdStatus;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.service.ICheckTransStatusService;
import com.sfpay.acquirer.service.SendPayoutResp;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class CheckTransStatusServiceTest extends ClassTransactionalTestCase {
	
	@Resource
	private ICheckTransStatusService service;
	
	
	@Test
	public void testQueryBatch(){
		
		try {
			service.queryBatch(BankCode.ABC,BatchStatus .RECEIVED);
			
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
		try {
			service.queryBatch(null,BatchStatus .RECEIVED);
			
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			service.queryBatch(BankCode.ABC,null);
			
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	
	@Test
	public void testDoBatchCheck(){
		
		PayoutInfo info=new PayoutInfo();
		info.setStatus(PayoutStatus.RECEIVED);
		List<PayoutInfo> listInfo=new ArrayList<PayoutInfo>();
		listInfo.add(info);
		MockCurrentResult.setMockValue(IPayoutInfoDao .class, "queryPayoutByBatchCode",listInfo);
		try {
			service.doBatchCheck("2013052400001204");
			
		} catch (Exception e) {
			logger.error("", e);
		}
		
		
		info.setStatus(PayoutStatus.FAILURE);
		List<PayoutInfo> listInfo1=new ArrayList<PayoutInfo>();
		listInfo1.add(info);
		MockCurrentResult.setMockValue(IPayoutInfoDao .class, "queryPayoutByBatchCode",listInfo1);
		MockCurrentResult.setMockValue(IPayoutInfoDao .class, "updateFinishStatus",new Exception ("test exception"));
		try {
			service.doBatchCheck("2013052400001204");
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testDoBatch(){
		BatchInfo  batchInfo=new BatchInfo ();
		try {
			service.doBatch(BankCode.ABC,batchInfo);
			
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			service.doBatch(null,batchInfo);
			
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			service.doBatch(BankCode.ABC,null);
			
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testDoPayoutResp(){
		PayoutRespResult ret=new PayoutRespResult ();
		try {
			service.doPayoutResp(null,ret);
			
		} catch (Exception e) {
			logger.error("", e);
		}
		
		BatchInfo  batchInfo=new BatchInfo ();
		try {
			service.doPayoutResp(batchInfo,null);
			
		} catch (Exception e) {
			logger.error("", e);
		}
		ret.setCmdStatus(CmdStatus.FAILURE);
		try {
			service.doPayoutResp(batchInfo,ret);
			
		} catch (Exception e) {
			logger.error("", e);
		}
		MockCurrentResult.setMockValue(SendPayoutResp.class, "doSendOrderResp",null);
		 ret.setCmdStatus(CmdStatus.SUCCESS);
		 ret.setStatus(BatchStatus.REJECT);
	     List<PayoutInfo>  batchNotify =null;
	     ret.setPayoutDetail(batchNotify);
		try {
			service.doPayoutResp(batchInfo,ret);
			
		} catch (Exception e) {
			logger.error("", e);
		}
		
		ret.setStatus(BatchStatus.DONE);
		try {
			service.doPayoutResp(batchInfo,ret);
			
		} catch (Exception e) {
			logger.error("", e);
		}
		
		ret.setStatus(BatchStatus.DONE);
		 batchNotify =new ArrayList<PayoutInfo>();
		 batchNotify.add(new PayoutInfo());
		try {
			service.doPayoutResp(batchInfo,ret);
			
		} catch (Exception e) {
			logger.error("", e);
		}
	}
}
