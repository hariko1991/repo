/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.rb.IBankBounceFileDao;
import com.sfpay.acquirer.domain.rb.szfs.BankBounceFile;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author sfhq814 
 * 
 * CreateDate: 2016年4月5日
 */
public class BankBounceFileDaoTest extends SpringTestCase{
	@Resource
	private IBankBounceFileDao bankBounceFileDao;
	@Test
	public void test(){
		List<BankBounceFile> list = new ArrayList<BankBounceFile>();
		BankBounceFile file = new BankBounceFile();
		file.setReqBankSn("201512311155640779378");
		file.setRetcode("1");
		file.setRemark("110");
		list.add(file);
		BankBounceFile file1 = new BankBounceFile();
		file.setReqBankSn("201512311155640779379");
		file.setRetcode("1");
		file.setRemark("110");
		list.add(file1);
		try {
			int cnt = bankBounceFileDao.updatePayoutInfoForBounce(list);
			System.out.println(cnt);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
