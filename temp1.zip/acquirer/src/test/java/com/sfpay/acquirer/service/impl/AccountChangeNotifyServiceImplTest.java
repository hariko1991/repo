package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IAcctNotifyConfig;
import com.sfpay.acquirer.dao.IAcctNotifyInfoDao;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.gate.b2e.domain.AccountNotifyInfo;
import com.sfpay.acquirer.gate.b2e.domain.AccountNotifySubInfo;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.MailInfo;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.acquirer.service.IAccountChangeNotifyService;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class AccountChangeNotifyServiceImplTest  extends ClassTransactionalTestCase {
	@Resource
	private IAccountChangeNotifyService service;
	@Test
	public void testAcctChangeNotify(){
		BeanBase bean=new BeanBase(BankCode.ICBC,TradeCodeB2E.QUERY_CUR_BAL);
		bean.setBusDetailBeanBase(null);
		service.acctChangeNotify(bean);
		
		AccountNotifyInfo info=new AccountNotifyInfo();
		bean.setBusDetailBeanBase(info);
		info.setNotifyInfos(null);
		service.acctChangeNotify(bean);
		
		List<AccountNotifySubInfo> notifyInfos=new ArrayList<AccountNotifySubInfo>();
		AccountNotifySubInfo subInfo=new AccountNotifySubInfo();
		subInfo.setCdSign("1");
		subInfo.setAccNo("571905400810812");
		AccountNotifySubInfo subInfo1=new AccountNotifySubInfo();
		subInfo1.setCdSign("0");
		subInfo1.setAccNo("571905400810814");
		AccountNotifySubInfo subInfo2=new AccountNotifySubInfo();
		subInfo2.setCdSign("2");
		subInfo2.setAccNo("571905400810813");
		notifyInfos.add(subInfo);
		notifyInfos.add(subInfo1);
		notifyInfos.add(subInfo2);
		info.setNotifyInfos(notifyInfos);
		bean.setBusDetailBeanBase(info);
		
		MockCurrentResult.setMockValue(IAcctNotifyInfoDao.class, "addNotifyInfos","");
		MailInfo mailInfo=new MailInfo();
		MockCurrentResult.setMockValue(IAcctNotifyConfig.class, "getMailInfoByAccountNo",mailInfo);
		service.acctChangeNotify(bean);
	}
}
