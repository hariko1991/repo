/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IMerInfoDao;
import com.sfpay.acquirer.dao.IUnkownCollectDao;
import com.sfpay.acquirer.domain.UnkownCollect;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.CollectStatus;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.acquirer.service.IUnkownCollectService;
import com.sfpay.coreplatform.order.service.IBankPayService;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 
 * 类说明：
 *  
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-5-28
 */
public class UnkownCollectServiceImplTest extends ClassTransactionalTestCase {

	@Resource
	private IUnkownCollectService service;

	@Test
	public void testUpdateUnkownCollect(){	
		String collectNo="1208280000001220";
		String payNo = "";
		String rtnBankCode="03";
		String rtnBankMsg="订单已支付（支付成功）";
		String rtnPayCode="0000";
		CollectStatus status = CollectStatus.SUCCESS;
		try {
			MockCurrentResult.setMockValue(IUnkownCollectDao.class, "updateUnkownCollect",null);
			service.updateUnkownCollect(null, payNo, rtnBankCode, rtnBankMsg, rtnPayCode, status);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			MockCurrentResult.setMockValue(IUnkownCollectDao.class, "updateUnkownCollect",null);
			service.updateUnkownCollect(collectNo, payNo, rtnBankCode, rtnBankMsg, rtnPayCode, status);		
		} catch (Exception e) {
			logger.error("", e);
		}

		try {
			MockCurrentResult.setMockValue(IUnkownCollectDao.class, "updateUnkownCollect","0000");
			service.updateUnkownCollect(collectNo, payNo, rtnBankCode, rtnBankMsg, rtnPayCode, status);		
		} catch (Exception e) {
			logger.error("", e);
		}

		try {
			MockCurrentResult.setMockValue(IUnkownCollectDao.class, "updateUnkownCollect","0000");
			service.updateUnkownCollect(collectNo, payNo, rtnBankCode, rtnBankMsg, rtnPayCode, CollectStatus.FAILURE);		
		} catch (Exception e) {
			logger.error("", e);
		}

		try {
			MockCurrentResult.setMockValue(IUnkownCollectDao.class, "updateUnkownCollect","0000");
			service.updateUnkownCollect(collectNo, payNo, rtnBankCode, rtnBankMsg, rtnPayCode, CollectStatus.INIT);		
		} catch (Exception e) {
			logger.error("", e);
		}

		try {
			MockCurrentResult.setMockValue(IUnkownCollectDao.class, "updateUnkownCollect","0000");
			MockCurrentResult.setMockValue(IBankPayService.class, "netBankPayNotifyByAcq",null);
			service.updateUnkownCollect(collectNo, payNo, rtnBankCode, rtnBankMsg, rtnPayCode, CollectStatus.SUCCESS);		
		} catch (Exception e) {
			logger.error("", e);
		}

	}

	@Test
	public void testQueryUnkownCollectList(){
		List<UnkownCollect> list = new ArrayList<UnkownCollect>();
		try {
			list = service.queryUnkownCollectList(null, BankCode.UPOP, OrderType.CANCEL, FundWay.IN);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			list = service.queryUnkownCollectList(ChannelCode.B2C, null, OrderType.CANCEL, FundWay.IN);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			list = service.queryUnkownCollectList(ChannelCode.B2C, BankCode.UPOP, OrderType.CANCEL, null);
		} catch (Exception e) {
			logger.error("", e);
		}
		try {
			list = service.queryUnkownCollectList(ChannelCode.B2C, BankCode.UPOP, OrderType.CANCEL, FundWay.IN);
			if(null != list && 0 != list.size())
				for(UnkownCollect uc:list){
					System.out.println(uc.getCollectNo());
				}
		} catch (Exception e) {
			logger.error("", e);
		}
	}


	@SuppressWarnings("rawtypes")
	@Test
	public void testDoOrderHandle(){
		UnkownCollectServiceImpl unkownCollectServiceImpl = new UnkownCollectServiceImpl();
		MockCurrentResult.setMockValue(IBankPayService.class, "netBankPayNotifyByAcq",null);
		
		try {
			Class[] argsClass = new Class[2];
			argsClass[0] = String.class;
			argsClass[1] = CollectStatus.class;
 			Method doOrderHandle = UnkownCollectServiceImpl.class.getDeclaredMethod("doOrderHandle", argsClass);
 			doOrderHandle.setAccessible(true);
 			doOrderHandle.invoke(unkownCollectServiceImpl, new Object[]{"11111", CollectStatus.SUCCESS});
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			Class[] argsClass = new Class[2];
			argsClass[0] = String.class;
			argsClass[1] = CollectStatus.class;
 			Method doOrderHandle = UnkownCollectServiceImpl.class.getDeclaredMethod("doOrderHandle", argsClass);
 			doOrderHandle.setAccessible(true);
 			doOrderHandle.invoke(unkownCollectServiceImpl, new Object[]{"11111", CollectStatus.FAILURE});
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			Class[] argsClass = new Class[2];
			argsClass[0] = String.class;
			argsClass[1] = CollectStatus.class;
 			Method doOrderHandle = UnkownCollectServiceImpl.class.getDeclaredMethod("doOrderHandle", argsClass);
 			doOrderHandle.setAccessible(true);
 			doOrderHandle.invoke(unkownCollectServiceImpl, new Object[]{"11111", null});
		} catch (Exception e) {
			logger.error("", e);
		}
	}
}
