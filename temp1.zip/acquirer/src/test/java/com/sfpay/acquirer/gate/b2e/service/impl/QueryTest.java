package com.sfpay.acquirer.gate.b2e.service.impl;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IAccountInfoDao;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.HisAcctTxQueryParam;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.gate.b2e.service.IBankService;
import com.sfpay.acquirer.gate.b2e.service.IQuery;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class QueryTest extends ClassTransactionalTestCase{

	@Resource
	private IQuery service;

	@Test
	public void testQueryAccountBalance(){
		BankProperty bankProperty = new BankProperty();
		AccountInfo accountInfo = new AccountInfo();

		try{
			bankProperty = new BankProperty();
			accountInfo = new AccountInfo();
			accountInfo.setBankCode(BankCode.ABC);
			accountInfo.setAccountNo("22222");
			accountInfo.setAccountName("33333");
			accountInfo.setCityName("3333");
			accountInfo.setCcy(CurrencyType.AUD);
			accountInfo.setOpeningBankName("3333");
			accountInfo.setProvinceName("111");
			accountInfo.setOpeningBankNo("3333");
			MockCurrentResult.setMockValue(IBankService .class, "service", "11111ssss11111");
			service.queryAccountBalance(bankProperty, accountInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testQueryCurAccountTransList(){
		BankProperty bankProperty = new BankProperty();
		AccountInfo accountInfo = new AccountInfo();

		try{
			bankProperty = new BankProperty();
			accountInfo = new AccountInfo();
			accountInfo.setBankCode(BankCode.ABC);
			accountInfo.setAccountNo("22222");
			accountInfo.setAccountName("33333");
			accountInfo.setCityName("3333");
			accountInfo.setCcy(CurrencyType.AUD);
			accountInfo.setOpeningBankName("3333");
			accountInfo.setProvinceName("111");
			accountInfo.setOpeningBankNo("3333");
			MockCurrentResult.setMockValue(IBankService .class, "service", "11111ssss11111");
			service.queryCurAccountTransList(bankProperty, accountInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
	
	@Test
	public void testQueryHisAccountTransList(){
		BankProperty bankProperty = new BankProperty();
		HisAcctTxQueryParam  param = new HisAcctTxQueryParam ();
		AccountInfo accountInfo = new AccountInfo();

		try{
			bankProperty = new BankProperty();
			param = new HisAcctTxQueryParam();
			accountInfo.setBankCode(BankCode.ABC);
			accountInfo.setAccountNo("22222");
			accountInfo.setAccountName("33333");
			accountInfo.setCityName("3333");
			accountInfo.setCcy(CurrencyType.AUD);
			accountInfo.setOpeningBankName("3333");
			accountInfo.setProvinceName("111");
			accountInfo.setOpeningBankNo("3333");
			MockCurrentResult.setMockValue(IAccountInfoDao .class, "queryAccountInfoByAccountNo", accountInfo);
			MockCurrentResult.setMockValue(IBankService .class, "service", "11111ssss11111");
			service.queryHisAccountTransList(bankProperty, param);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
}
