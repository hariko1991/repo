package com.sfpay.acquirer.service.impl;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IRtnPayCodeDao;
import com.sfpay.acquirer.domain.RtnChannelCodeInfo;
import com.sfpay.acquirer.service.IRtnPayCodeService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class RtnPayCodeServiceImplTest extends ClassTransactionalTestCase {
	
	@Resource
	private IRtnPayCodeService  service;
	@Test
	public void testFindRtnPayCodeByBankCode(){
		
	 MockCurrentResult.setMockValue(IRtnPayCodeDao .class, "findRtnPayCode",new Exception("test exception"));
	 RtnChannelCodeInfo  param=new RtnChannelCodeInfo ();
		try{
			 service. findRtnPayCodeByBankCode(param);
		}catch(ServiceException e){
			logger.info(e.getMessage());
		}
	}
}
