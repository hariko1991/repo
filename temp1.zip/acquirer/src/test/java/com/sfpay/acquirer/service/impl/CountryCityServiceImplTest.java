/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import junit.framework.Assert;

import org.junit.Test;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.dao.ICountryCityDao;
import com.sfpay.acquirer.domain.CountryCity;
import com.sfpay.acquirer.service.ICountryCityService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 
 * 测试用例功能要单一明了，一目了然。
 * 
 * 添加2个测试用例例子方便大家参考。
 *  
 * 
 * </p>
 * 
 * @author 720735 廖业勤
 * @author 361424 詹锡宁
 * 
 *         CreateDate: 2012-10-23
 */
public class CountryCityServiceImplTest extends ClassTransactionalTestCase {

	@Resource
	private ICountryCityService countryCityService;

	@Test
	public void givenOneCountryShouldReturnOneItemSuccessfully() {

		List<CountryCity> countryCityList = new ArrayList<CountryCity>(1);
		CountryCity item = new CountryCity();
		item.setCountryCode("CX001");
		countryCityList.add(item);

		MockCurrentResult.setMockValue(ICountryCityDao.class, "queryProvince",
				countryCityList);
		List<CountryCity> resultList = countryCityService.queryProvince();
		Assert.assertEquals(countryCityList.size(), resultList.size());
		Assert.assertEquals(countryCityList.get(0).getCountryCode(), resultList
				.get(0).getCountryCode());
	}

	@Test
	public void givenEmptyCountryShouldThrowException() {
		try {
			countryCityService.queryByParentCode(null);
			Assert.fail();
		} catch (ServiceException e) {
			Assert.assertEquals(InfoCode.PARAM_INVALID, e.getCode());
		}
	}

	@Test
	public void queryByParentId() {
		try {
			String countryCode = "140900";
			List<CountryCity> list = countryCityService
					.queryByParentCode(countryCode);
			for (Iterator<CountryCity> it = list.iterator(); it.hasNext();) {
				CountryCity city = it.next();
				logger.debug(city.getCountryCode() + "," + city.getId() + ","
						+ city.getParentId() + "," + city.getCountryNameC()
						+ "," + city.getGrade() + "," + city.getShowIndex());
			}
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}

	@Resource
	private ICountryCityDao dao;

	@Test
	public void testqueryByCode() {
		try {
			String countryCode = "140900";
			List<CountryCity> list = this.dao.queryByCode(countryCode);
			for (Iterator<CountryCity> it = list.iterator(); it.hasNext();) {
				CountryCity city = it.next();
				if (null != city)
					logger.debug(city.getCountryCode() + "," + city.getId()
							+ "," + city.getParentId() + ","
							+ city.getCountryNameC() + "," + city.getGrade()
							+ "," + city.getShowIndex());
			}
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}

	@Test
	public void queryParentByCode() {
		try {
			String countryCode = "140900";
			CountryCity city = this.dao.queryParentByCode(countryCode);
			// logger.debug("", city == null ? "" : city.toString());
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}
	
	@Test
	public void testQueryProvinceByName(){
		try {
			countryCityService.queryProvinceByName(null);
		} catch (Exception ex) {
			logger.error("", ex);
		}
		
		try {
			countryCityService.queryProvinceByName("11");
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}
}
