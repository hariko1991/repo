/**
 * 
 */
package com.sfpay.acquirer.dao;

import java.util.Date;

import javax.annotation.Resource;

import org.apache.commons.dbcp.BasicDataSource;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;

import com.sfpay.acquirer.domain.paycenter.EcsRecon;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework.web.test.SpringTestCase;
import com.sfpay.task.util.SpringContextHolder;


public class EcsReconDaoTest extends SpringTestCase {
	
	@SuppressWarnings("unused")
	private static Logger logger = LoggerFactory.getLogger(EcsReconDaoTest.class);
	
	
	@Resource 
	private IReconDao dao;
	
	@Test
	public void testQueryECSReconListExport(){
		EcsRecon param = new EcsRecon();
		try { 
			dao.queryECSReconListExport(param);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	@Test
	public void testQueryECSReconList(){
		EcsRecon param = new EcsRecon();
		param.setAcquireAmt(129023l);
		param.setBankBeginDate(new Date());
		param.setBankEndDate(new Date());
		try { 
			dao.queryECSReconList(param, 0, 1);
		} catch(DataAccessException e) {  
		    System.out.println("test:" + e.getMessage());  
		}
	}
	
	
	@Test
	public void testDataSource(){
		BasicDataSource dataSource2 = (BasicDataSource) SpringContextHolder.getBean("dataSource");
        System.out.println(dataSource2.getUsername());

	}
	
	@Test
	public void testFileExcel1(){
		System.out.println(Property.getProperty("B2E_CHECK_BANK"));
		System.out.println(Property.getProperty("filesize"));
	}
	
	
	
	
}
