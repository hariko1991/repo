/**
 * =================================================================
 * 版权所有 2011-2013 深圳市泰海网络科技服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.annotation.Resource;
import org.junit.Test;
import com.caucho.hessian.client.HessianProxyFactory;
import com.sfpay.acquirer.dao.IBatchInfoDao;
import com.sfpay.acquirer.dao.IParamInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.dao.IReconBankFileCreateDao;
import com.sfpay.acquirer.domain.BankCmdResult;
import com.sfpay.acquirer.domain.BatchCmdStatusParam;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.CmdBean;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutQueryRlt;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.service.IB2EPayoutService;
import com.sfpay.acquirer.service.ICheckTransStatusService;
import com.sfpay.acquirer.service.IExceptionCmdProcessService;
import com.sfpay.acquirer.service.SendPayoutResp;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author 400928 向鹏
 * 
 * CreateDate: 2013-5-22
 */
public class ExceptionCmdProcessServiceImplTest extends ClassTransactionalTestCase {

	@Resource
	private IExceptionCmdProcessService exceptionCmdProcessService;

	@Resource
	private IBatchInfoDao batchInfoDao;

	@Resource
	private IParamInfoDao paramDao;
	

	// 调整异常指令状态
	@Test
	public void testUpdateExceptionCmdStatus() throws Exception {
		BatchCmdStatusParam status = new BatchCmdStatusParam();
		List<CmdBean> list = new ArrayList<CmdBean>();
		CmdBean bean = new CmdBean();
		
		try {
			status = new BatchCmdStatusParam();
			status.setReqBankSn("11111111111");
			MockCurrentResult.setMockValue(IBatchInfoDao .class, "queryByReqBankSn", null);
			exceptionCmdProcessService.updateExceptionCmdStatus(status);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			status = new BatchCmdStatusParam();
			list = new ArrayList<CmdBean>();
			bean = new CmdBean();
			bean.setReqBankSn("20130910100000027648");
			bean.setOldPayOutStatus(PayoutStatus.SEC_CHECK_PASS);
			bean.setRemark("向鹏进行调整测试");
			bean.setStatus(PayoutStatus.SUCCESS);
			list.add(bean);
			status.setReqBankSn("11111111111");
			BatchInfo batchInfo = new BatchInfo();
			batchInfo.setBatchCode("111");
			status.setDtsCmds(list);
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "queryByReqBankSn", batchInfo);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updateExceptionProcess", 1);
			exceptionCmdProcessService.updateExceptionCmdStatus(status);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			status = new BatchCmdStatusParam();
			list = new ArrayList<CmdBean>();
			bean = new CmdBean();
			bean.setReqBankSn("20130910100000027648");
			bean.setOldPayOutStatus(PayoutStatus.SEC_CHECK_PASS);
			bean.setRemark("向鹏进行调整测试");
			bean.setStatus(PayoutStatus.SUCCESS);
			list.add(bean);
			status.setReqBankSn("11111111111");
			BatchInfo batchInfo = new BatchInfo();
			batchInfo.setBatchCode("111");
			status.setDtsCmds(list);
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "queryByReqBankSn", batchInfo);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updateExceptionProcess", 1);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "queryPayoutInfo", new PayoutInfo());
			MockCurrentResult.setMockValue(SendPayoutResp.class, "sendOrderResp", new Exception(""));
			exceptionCmdProcessService.updateExceptionCmdStatus(status);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			status = new BatchCmdStatusParam();
			list = new ArrayList<CmdBean>();
			bean = new CmdBean();
			bean.setReqBankSn("20130910100000027648");
			bean.setOldPayOutStatus(PayoutStatus.SEC_CHECK_PASS);
			bean.setRemark("向鹏进行调整测试");
			bean.setStatus(PayoutStatus.SUCCESS);
			list.add(bean);
			status.setReqBankSn("11111111111");
			BatchInfo batchInfo = new BatchInfo();
			batchInfo.setBatchCode("111");
			status.setDtsCmds(list);
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "queryByReqBankSn", batchInfo);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "updateExceptionProcess", 2);
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "queryPayoutInfo", new PayoutInfo());
			exceptionCmdProcessService.updateExceptionCmdStatus(status);
		} catch (Exception e) {
			logger.error("", e);
		}
		
	}
	
	// 重发异常指令
	@Test
	public void testRePayOut() throws Exception {
		BatchInfo batchInfo = new BatchInfo();
		BatchInfo _batchInfo = new BatchInfo();
		
		try {
			batchInfo = new BatchInfo();
			batchInfo.setBatchCode("2013062600001080");
			batchInfo.setRemark("向鹏进行了重发!");
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "queryByBatchCode", null);
			exceptionCmdProcessService.rePayOut(batchInfo, BankCode.ICBC);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			batchInfo = new BatchInfo();
			batchInfo.setBatchCode("2013062600001080");
			batchInfo.setRemark("向鹏进行了重发!");
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "queryByBatchCode", _batchInfo);
			exceptionCmdProcessService.rePayOut(batchInfo, BankCode.ICBC);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			batchInfo = new BatchInfo();
			batchInfo.setBatchCode("2013062600001080");
			batchInfo.setRemark("向鹏进行了重发!");
			_batchInfo = new BatchInfo();
			_batchInfo.setRtnBankCode("111");
			_batchInfo.setRtnBankMsg("111");
			_batchInfo.setReqBankSn("111");
			_batchInfo.setStatus(BatchStatus.DONE);
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "queryByBatchCode", _batchInfo);
			MockCurrentResult.setMockValue(IB2EPayoutService .class, "doPayoutReq", null);
			exceptionCmdProcessService.rePayOut(batchInfo, BankCode.ICBC);
		} catch (Exception e) {
			logger.error("", e);
		}

	}
	

	// 查询转帐结果状态测试
	@Test
	public void testQueryCmdStatus() throws Exception {
		BatchCmdStatusParam batchInfo = new BatchCmdStatusParam();
		BatchInfo _batchInfo = new BatchInfo();
		
		try {
			batchInfo = new BatchCmdStatusParam();
			batchInfo.setReqBankSn("20130626100000045021");
			batchInfo.setBankCode(BankCode.ICBC);
			batchInfo.setRemark("11111");
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "queryByReqBankSn", null);
			exceptionCmdProcessService.queryCmdStatus(batchInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			batchInfo = new BatchCmdStatusParam();
			batchInfo.setReqBankSn("20130626100000045021");
			batchInfo.setBankCode(BankCode.ICBC);
			batchInfo.setRemark("11111");
			_batchInfo = new BatchInfo(); 
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "queryByReqBankSn", _batchInfo);
			exceptionCmdProcessService.queryCmdStatus(batchInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try {
			batchInfo = new BatchCmdStatusParam();
			batchInfo.setReqBankSn("20130626100000045021");
			batchInfo.setBankCode(BankCode.ICBC);
			batchInfo.setRemark("11111");
			_batchInfo = new BatchInfo(); 
			_batchInfo.setRemark("11111");
			List<PayoutInfo> payoutInfoDetail = new ArrayList<PayoutInfo>();
			PayoutInfo pi = new PayoutInfo();
			payoutInfoDetail.add(pi);
			MockCurrentResult.setMockValue(IBatchInfoDao.class, "queryByReqBankSn", _batchInfo);
			MockCurrentResult.setMockValue(ICheckTransStatusService .class, "doBatch", payoutInfoDetail);
			MockCurrentResult.setMockValue(SendPayoutResp  .class, "sendOrderResp", new   Exception(""));
			exceptionCmdProcessService.queryCmdStatus(batchInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
	}



	@Test
	public void testHessian() throws Exception {
		try {
			HessianProxyFactory proxyFactory = new HessianProxyFactory();
			IExceptionCmdProcessService service = (IExceptionCmdProcessService) proxyFactory.create(IExceptionCmdProcessService.class, "http://10.79.6.59:9080/acquirer/hessian/exceptionCmdProcessService");
			ArrayList<BatchStatus> status = new ArrayList<BatchStatus>();
			status.add(BatchStatus.UNKOWN);
			status.add(BatchStatus.SEC_CHECK_PASS);
			status.add(BatchStatus.RECEIVED);
			List<BatchInfo> list = service.queryBatchInfoByExceptionStatus(status, null, null, null, null);
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	/**
	 * 根据状态集合获取异常批次记录集合 方法说明：<br>
	 * 
	 */
	// 传入日期为空测试获取批次信息
	@Test
	public void getExceptionBatchInfoByAllDateNullTest() {
		//
		try {
			List<BatchInfo> infos = getExceptionBatch(null, null, null, null);
			if (infos.size() == 0) {
				return;
			}
			BatchInfo info = infos.get(0);

			logger.debug("生成批次时间：" + info.getCreateBatchDate());
			logger.debug("批次号：" + info.getBatchCode());
			logger.debug("规则名称：" + info.getRuleName());
			logger.debug("付款方银行:" + info.getPayerOrgCode()); // 暂无需要加
			logger.debug("付款方帐号：" + info.getPayerAcctNo());
			logger.debug("付款方户名：" + info.getPayerAcctName());
			logger.debug("总笔数：" + info.getTotalCnt());
			logger.debug("总金额：" + info.getTotalAmt());
			logger.debug("状态：" + info.getStatus());
			logger.debug("第一次复核人：" + info.getFirCheckOperator());
			logger.debug("第一次复核时间：" + info.getFirCheckDate());
			logger.debug("第一次复核信息：" + info.getFirCheckDesc());
			logger.debug("第二次复核人：" + info.getSecCheckOperator());
			logger.debug("第二次复核时间：" + info.getSecCheckDate());
			logger.debug("第二次复核信息：" + info.getSecCheckDesc());
			logger.debug("交易流水号:" + info.getReqBankSn());
			logger.debug("银行返回码：" + info.getRtnBankCode());
			logger.debug("银行返回信息:" + info.getRtnBankMsg());
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	// 只传结束日期测试获取批次信息
	@Test
	public void getExceptionBatchInfoByStartDateNullTest() throws Exception {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			Date endDate = sdf.parse("20130521");
			getExceptionBatch(null, endDate, null, null);
		} catch (Exception e) {
			logger.error("", e);
		}
		
	}

	// 只传批次号获取
	@Test
	public void getExceptionBatchInfoByBatchCodeTest() throws Exception {
		try {
			getExceptionBatch(null, null, BankCode.ICBC, "2013052400001210");
		} catch (Exception e) {
			logger.error("", e);
		}
	}

	// 只传开始日期测试获取批次信息
	@Test
	public void getExceptionBatchInfoByEndDateNullTest() throws Exception {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			Date startDate = sdf.parse("20130522");
			getExceptionBatch(startDate, null, null, null);
		} catch (Exception e) {
			logger.error("", e);
		}
		
	}

	// 开始日期与结束日期全传测试获取批次信息
	@Test
	public void getExceptionBatchInfoTest() throws Exception {
		try {
			SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
			Date startDate = sdf.parse("20130322");
			Date endDate = sdf.parse("20130523");
			getExceptionBatch(startDate, endDate, null, null);
		} catch (Exception e) {
			logger.error("", e);
		}
		
	}

	// 根据批次号获取付款信息明细
	@Test
	public void getExceptionDtlByBatchInfoTest() throws Exception {
		try {
			List<PayoutQueryRlt> list = this.exceptionCmdProcessService.queryExceptionPayoutInfoByBatchCode("2013060300001306");
			logger.debug("共取到" + list == null ? "0" : String.valueOf(list.size()) + "付款明细记录！");
			for (PayoutQueryRlt info : list) {

				logger.debug("录入日期：" + info.getCreateDate());
				logger.debug("交易日期：" + info.getTransDate());
				logger.debug("交易状态：" + info.getPayoutStatus());
				logger.debug("交易金额：" + info.getAmt());
				logger.debug("交易币种：" + info.getCcy());
				logger.debug("付款银行：" + info.getPayerBankCode());
				logger.debug("付款帐号：" + info.getPayerAcctNo());
				logger.debug("付款户名：" + info.getPayerAcctName());
				logger.debug("收款银行：" + info.getPayeeBankCode());
				logger.debug("收款帐号：" + info.getPayeeAcctNo());
				logger.debug("收款户名：" + info.getPayeeAcctName());
				logger.debug("收款方帐户类型：" + info.getPayeeAcctType());
				logger.debug("收款方开户行名：" + info.getPayeeBranchName());
				logger.debug("收款方省份：" + info.getPayeeAcctProvinceName());
				logger.debug("收款方城市：" + info.getPayeeAcctCityName());
				logger.debug("汇款方式：" + info.getRemitMethod());
				logger.debug("用途：" + info.getUseDesc());
				logger.debug("搞要：" + info.getSummary());
				logger.debug("银行返回码：" + info.getRtnBankCode());
				logger.debug("银行返回信息：" + info.getRtnBankMsg());
				logger.debug("是否短信通知：" + info.getMsgFlag());
				logger.debug("批次号：" + info.getBatchCode());
				logger.debug("业务流水号：" + info.getBusinessSn());
				logger.debug("付款流水号：" + info.getPayoutNo());
				logger.debug("银行交易流水号：" + info.getBankTxSn());
				logger.debug("第一次复核人：" + info.getFirCheckOperator());
				logger.debug("第一次复核时间：" + info.getFirCheckDate());
				logger.debug("第一次复核信息：" + info.getFirCheckDesc());
				logger.debug("第二次复核人：" + info.getSecCheckOpertor());
				logger.debug("第二次复核时间：" + info.getSecCheckDate());
				logger.debug("第二次复核信息：" + info.getSecCheckDesc());
				logger.debug("系统来源：" + info.getSystemSource());
				logger.debug("付款业务类型:" + info.getPayoutBusType());
				logger.debug("外部交易单号:" + info.getTradeOutNo());

			}
		} catch (Exception e) {
			logger.error("", e);
		}

	
		

	}

	

	// 查询转帐结果状态测试
	@Test
	public void queryCmdStatusTest() throws Exception {
		try {
			BatchCmdStatusParam batchInfo = new BatchCmdStatusParam();
			batchInfo.setReqBankSn("20130626100000045021");
			batchInfo.setBankCode(BankCode.ICBC);
			this.exceptionCmdProcessService.queryCmdStatus(batchInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
	}

	@Test
	public void getParamInfo() {
		try {
			logger.debug("测试：" + paramDao.getParameter("B2E_EXP_RECEIVED_LIMIT"));
		} catch (Exception e) {
			logger.error("", e);
		}

	}

	/**
	 * 异常批次查询
	 */
	private List<BatchInfo> getExceptionBatch(Date startDate, Date endDate, BankCode bankCode, String batchCode) {
		ArrayList<BatchStatus> status = new ArrayList<BatchStatus>();
		status.add(BatchStatus.UNKOWN);
		status.add(BatchStatus.SEC_CHECK_PASS);
		status.add(BatchStatus.RECEIVED);
		List<BatchInfo> list = exceptionCmdProcessService.queryBatchInfoByExceptionStatus(status, startDate, endDate, bankCode, batchCode);
		logger.debug("测试取到批次+" + list == null ? "0" : String.valueOf(list.size()) + "条异常批次指令!");
		if (list.size() > 0) {
			logger.debug("第一条批次号:" + list.get(0).getBatchCode());
		}
		return list;
	}

}
