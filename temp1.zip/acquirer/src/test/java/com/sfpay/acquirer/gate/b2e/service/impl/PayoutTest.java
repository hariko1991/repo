package com.sfpay.acquirer.gate.b2e.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.enums.AcctType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.acquirer.gate.b2e.service.IPayout;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;

public class PayoutTest extends ClassTransactionalTestCase{

	@Resource
	private IPayout service;


	@Test
	public void testDoReq(){
		Payout payout = new Payout();
		List<PayoutInfo> payoutInfos = new ArrayList<PayoutInfo>();
		PayoutInfo payoutInfo = new PayoutInfo();
		BatchInfo batchInfo = new BatchInfo();
		BankProperty bankProperty = new BankProperty();
		BatchRuleInfo batchRuleInfo = new BatchRuleInfo();

		try{
			bankProperty = new BankProperty();
			payoutInfos = new ArrayList<PayoutInfo>();
			payoutInfo = new PayoutInfo();
			payoutInfo.setAgentFlag(YNFlag.Y);
			payoutInfos.add(payoutInfo);
			payout.doReq(batchInfo, payoutInfos, bankProperty, BankCode.ABC, batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try{
			bankProperty = new BankProperty();
			payoutInfos = new ArrayList<PayoutInfo>();
			payoutInfo = new PayoutInfo();
			batchRuleInfo = new BatchRuleInfo();
			batchRuleInfo.setOppAcctType(AcctType.PERSON);
			batchInfo = new BatchInfo();
			payoutInfo.setAgentFlag(YNFlag.N);
			payoutInfos.add(payoutInfo);
			payout.doReq(batchInfo, payoutInfos, bankProperty, BankCode.ABC, batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try{
			bankProperty = new BankProperty();
			payoutInfos = new ArrayList<PayoutInfo>();
			payoutInfo = new PayoutInfo();
			batchRuleInfo = new BatchRuleInfo();
			batchRuleInfo.setOppAcctType(AcctType.COMPANY);
			batchInfo = new BatchInfo();
			payoutInfo.setAgentFlag(YNFlag.N);
			payoutInfos.add(payoutInfo);
			payout.doReq(batchInfo, payoutInfos, bankProperty, BankCode.ABC, batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try{
			bankProperty = new BankProperty();
			payoutInfos = new ArrayList<PayoutInfo>();
			payoutInfo = new PayoutInfo();
			batchRuleInfo = new BatchRuleInfo();
			batchRuleInfo.setOppAcctType(null);
			batchInfo = new BatchInfo();
			payoutInfo.setAgentFlag(YNFlag.N);
			payoutInfos.add(payoutInfo);
			payout.doReq(batchInfo, payoutInfos, bankProperty, BankCode.ABC, batchRuleInfo);
		} catch (Exception e) {
			logger.error("", e);
		}
		
	}
	
	@Test
	public void testDoResp(){
		BeanBase respBean = new BeanBase(BankCode.ABC, TradeCodeB2E.ACCOUNT_CHANGE_NOTIFY);
		Payout payout = new Payout();
		
		try{
			respBean = new BeanBase(BankCode.ABC, TradeCodeB2E.BATCH_AGENT_TRANSFER);
			payout.doResp(respBean);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try{
			respBean = new BeanBase(BankCode.ABC, TradeCodeB2E.BATCH_PAYOFF);
			payout.doResp(respBean);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try{
			respBean = new BeanBase(BankCode.ABC, TradeCodeB2E.BATCH_TRANSFER);
			payout.doResp(respBean);
		} catch (Exception e) {
			logger.error("", e);
		}
		
		try{
			respBean = new BeanBase(BankCode.ABC, null);
			payout.doResp(respBean);
		} catch (Exception e) {
			logger.error("", e);
		}
	}
}
