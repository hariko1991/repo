package com.sfpay.acquirer.service.impl;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.service.IChannelFieldMappingService;
import com.sfpay.framework.web.test.SpringTestCase;

public class ChannelFieldMappingServiceTest extends SpringTestCase {
	private static Logger logger = LoggerFactory.getLogger(ChannelFieldMappingServiceTest.class);
	@Resource
	IChannelFieldMappingService service;

	@Test
	public void queryMappingByChannelTest() {
		Map<String, Map<String,String>> map = service.queryMappingByChannel("ICBC_1001");
		logger.info("{}",map);
	}
	@Test
	public void execFieldMappingTest() {
		Map<String, Map<String,String>> map = service.queryMappingByChannel("ICBC_1001");
		logger.info("\n=============mapping==========\n{}",map);
		PayoutInfo payout = new PayoutInfo();
		payout.setUseType("GOODS");
		payout.setUseDesc("123");
		service.execFieldMapping(payout, map);
		logger.info("\n=============payout==========\n{}",payout);
	}
	
	
}
