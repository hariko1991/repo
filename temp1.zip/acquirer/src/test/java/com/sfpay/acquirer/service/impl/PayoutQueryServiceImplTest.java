/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.Date;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.acquirer.dao.IBatchRuleInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.dao.IReconDao;
import com.sfpay.acquirer.dao.ITotalBatchInfoDao;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.domain.PayoutForCheckBatchQueryParam;
import com.sfpay.acquirer.domain.PayoutForCheckTotalBatchQueryParam;
import com.sfpay.acquirer.domain.PayoutForCreateBatchQueryParam;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutQueryParam;
import com.sfpay.acquirer.domain.PayoutQueryRlt;
import com.sfpay.acquirer.domain.PayoutRlt;
import com.sfpay.acquirer.domain.PayoutRlt4Ext;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.PayoutBatchQueryType;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.enums.SystemSource;
import com.sfpay.acquirer.service.IPayoutQueryService;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.test.mock.MockCurrentResult;
import com.sfpay.framework.test.testcase.ClassTransactionalTestCase;
import com.sfpay.framework.web.test.SpringTestCase;

/**
 * 类说明：<br>
 * 付款 查询类service 测试
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * CreateDate: 2012-10-25
 */
public class PayoutQueryServiceImplTest extends ClassTransactionalTestCase{

	@Resource
	private IPayoutQueryService service;
	@Resource
	private IPayoutInfoDao dao;
	/**
	 * 方法说明：<br>
	 * 测试添加
	 *
	 */
	@Test
	public void testAdd(){
		try{
			PayoutInfo payoutInfo = new PayoutInfo();
			MockCurrentResult.setMockValue(IPayoutInfoDao.class, "addPayoutInfo",null);
			dao.addPayoutInfo(payoutInfo);
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 测试分页查询
	 *
	 */
	@Test
	public void testPage(){
		PayoutQueryParam param = new PayoutQueryParam();
		MockCurrentResult.setMockValue(IPayoutInfoDao .class, "countPayoutPage",11111l);
		
		try{
			service.queryPayoutPage(null, 0, 11111);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			service.queryPayoutPage(param, 0, 11111);
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 批次前查询
	 *
	 */
	@Test
	public void testQueryPayoutForCreateBatch(){
		PayoutForCreateBatchQueryParam param = new PayoutForCreateBatchQueryParam();
		MockCurrentResult.setMockValue(IPayoutInfoDao .class, "countQueryByRule",11111l);
		
		try{
			service.queryPayoutForCreateBatch(null, 0, 1111);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			param.setQueryType(PayoutBatchQueryType.BY_RULE);
			service.queryPayoutForCreateBatch(param, 0, 1111);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			param.setQueryType(PayoutBatchQueryType.BY_RULE);
			param.setRuleCode("111"); 
			MockCurrentResult.setMockValue(IBatchRuleInfoDao .class, "queryBatchRuleInfoByCode", null);
			service.queryPayoutForCreateBatch(param, 0, 1111);
		}catch(Exception ex){
			logger.error("",ex);
		}
		
		try{
			param.setQueryType(PayoutBatchQueryType.BY_RULE);
			param.setRuleCode("111"); 
			MockCurrentResult.setMockValue(IBatchRuleInfoDao .class, "queryBatchRuleInfoByCode", new BatchRuleInfo());
			service.queryPayoutForCreateBatch(param, 0, 1111);
		}catch(Exception ex){
			logger.error("",ex);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 复核查询
	 */
	@Test
	public void testQueryPayoutForCheckBatch(){
		PayoutForCheckBatchQueryParam param = new PayoutForCheckBatchQueryParam();
		
		try {
			MockCurrentResult.setMockValue(IPayoutInfoDao .class, "countPayoutForCheckBatch",11111l);
			service.queryPayoutForCheckBatch(null, 0, 111111);
		} catch (Exception ex) {
			logger.error("", ex);
		}
		
		try {
			MockCurrentResult.setMockValue(IPayoutInfoDao .class, "countPayoutForCheckBatch",11111l);
			service.queryPayoutForCheckBatch(param, 0, 111111);
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}
	
	@Test
	public void testqueryPayout(){
		String payoutNo = "1311290000047416";
		PayoutRlt rlt = new PayoutRlt();
		
		try {
			service.queryPayout(null);
		} catch (Exception ex) {
			logger.error("", ex);
		}
		
		try {
			service.queryPayout(payoutNo);
		} catch (Exception ex) {
			logger.error("", ex);
		}
		
		try {
			MockCurrentResult.setMockValue(IPayoutInfoDao .class, "queryPayoutByPayoutNo",null);
			service.queryPayout(payoutNo);
		} catch (Exception ex) {
			logger.error("", ex);
		}
		
		try {
			MockCurrentResult.setMockValue(IPayoutInfoDao .class, "queryPayoutByPayoutNo",rlt);
			service.queryPayout(payoutNo);
		} catch (Exception ex) {
			logger.error("", ex);
		}
		
		try {
			rlt.setPayoutStatus(PayoutStatus.FAILURE);
			MockCurrentResult.setMockValue(IPayoutInfoDao .class, "queryPayoutByPayoutNo",rlt);
			service.queryPayout(payoutNo);
		} catch (Exception ex) {
			logger.error("", ex);
		}
		
		try {
			rlt.setPayoutStatus(PayoutStatus.SUCCESS);
			MockCurrentResult.setMockValue(IPayoutInfoDao .class, "queryPayoutByPayoutNo",rlt);
			service.queryPayout(payoutNo);
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}
	
	
	@Test
	public void testQueryPayout() {
		String payoutNo = "1312200000001057";		
		String tradeNo = "0201459092N131223072818";
		String businessNo = "0201459092N20131109N20131109N020AK";
		
		try {
			service.queryPayout(null, payoutNo, tradeNo, businessNo);
		} catch (Exception ex) {
			logger.error("", ex);
		}
		
		try {
			service.queryPayout(SystemSource.COD, payoutNo, tradeNo, businessNo);
		} catch (Exception ex) {
			logger.error("", ex);
		}
		
		try {
			MockCurrentResult.setMockValue(IPayoutInfoDao .class, "queryPayoutByExt",null);
			service.queryPayout(SystemSource.COD, payoutNo, tradeNo, businessNo);
		} catch (Exception ex) {
			logger.error("", ex);
		}
		
		try {
			MockCurrentResult.setMockValue(IPayoutInfoDao .class, "queryPayoutByExt",new Exception(""));
			service.queryPayout(SystemSource.COD, payoutNo, tradeNo, businessNo);
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}
	
	@Test
	public void testqueryPayoutInfobyID(){
		try {
			service.queryPayoutInfobyID(null);
		} catch (Exception ex) {
			logger.error("", ex);
		}
		
		try {
			service.queryPayoutInfobyID(1033L);
		} catch (Exception ex) {
			logger.error("", ex);
		}
		
		try {
			MockCurrentResult.setMockValue(IPayoutInfoDao .class, "queryById",11111l);
			service.queryPayoutInfobyID(1033L);
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}
	
	@Test
	public void testQueryForCheckTotalBatch(){
		PayoutForCheckTotalBatchQueryParam param = new PayoutForCheckTotalBatchQueryParam();
		try {
			service.queryForCheckTotalBatch(null, 0, 11111);
		} catch (Exception ex) {
			logger.error("", ex);
		}
		
		try {
			MockCurrentResult.setMockValue(ITotalBatchInfoDao.class, "queryPayoutForCheckTotalBatchCount",11111l);
			service.queryForCheckTotalBatch(param, 0, 11111);
		} catch (Exception ex) {
			logger.error("", ex);
		}
	}
}
