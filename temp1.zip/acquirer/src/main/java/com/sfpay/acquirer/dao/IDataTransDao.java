/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import com.sfpay.acquirer.domain.DataTrans;

/**
 * 类说明：数据交互信息
 * 
 * <p>
 * 详细描述：<br>
 * @author 321302 程俊杰
 *   
 * CreateDate: 2012-3-16
 */
public interface IDataTransDao {
	
	/**
	 * 方法说明：插入或修改数据交互信息
	 *
	 * @param iData 插入或修改的数据交互信息记录
	 */
	//public void saveOrUpdate(DataTrans iData);
	
	/**
	 * 方法说明：插入数据交互信息
	 * @param iData 插入的数据交互信息记录
	 */
	public void addDataTrans(DataTrans iData);
	
	/**
	 * 方法说明：修改数据交互信息
	 * @param iData 修改的数据交互信息记录
	 */
	public int updateDataTrans(DataTrans iData);
}
