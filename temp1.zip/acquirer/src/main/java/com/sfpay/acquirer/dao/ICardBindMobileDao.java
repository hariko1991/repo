/**
 * 
 */
package com.sfpay.acquirer.dao;

import com.sfpay.acquirer.domain.CardBindMobile;

/**
 * 
 * 类说明：
 * 卡号绑定手机号dao层 
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-5-22
 */
public interface ICardBindMobileDao {
	
	/**
	 * 
	 *
	 * 方法说明：
	 * 根据卡号查询手机号
	 * @param cardNo 卡号
	 * @return
	 */
	public String getMobileByCard(String cardNo);
	
	/**
	 * 
	 *
	 * 方法说明：
	 * 添加
	 * @param card
	 */
	public void addCard(CardBindMobile card);
	
	/**
	 * 
	 *
	 * 方法说明：
	 * 修改状态为停用
	 * @param cardNo
	 */
	public void updateDisabledStatus(String cardNo);

}
