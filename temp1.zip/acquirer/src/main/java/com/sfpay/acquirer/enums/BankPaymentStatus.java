package com.sfpay.acquirer.enums;

public enum BankPaymentStatus
{

}
