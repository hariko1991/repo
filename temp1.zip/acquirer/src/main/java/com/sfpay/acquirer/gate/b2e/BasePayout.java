package com.sfpay.acquirer.gate.b2e;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.enums.AcctType;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 
 * 类说明：<br>
 * PAYOUT 基类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * TODO 改名为BasePayoutService (interface)
 * CreateDate: 2013-4-27
 */
public abstract class BasePayout {
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	protected final boolean isDebug = logger.isDebugEnabled();

	/**
	 * 方法说明：<br>
	 * 获取账号类型
	 *
	 * @param bi
	 * @param pis
	 * @return
	 */
	public AcctType getAcctType(BatchRuleInfo rule) throws ServiceException {
		if(AcctType.ALL == rule.getOppAcctType()) {
			logger.info("支持所有账户类型, 默认使用:{}", AcctType.COMPANY);
			return AcctType.COMPANY;
		}
		return rule.getOppAcctType();
	}
	
}
