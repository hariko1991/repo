/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.common;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.framework.config.properties.Property;

/**
 * 
 * 类说明：
 * 对账文件辅助类 
 * 
 * <p/>
 * 详细描述：
 *   
 * 注:与<tt>acquirer-web</tt>工程的com.sfpay.acquirer.common.helper.ReconHelper相同
 * 
 * @author 312932 何国兴
 * @author 329202 <a href="mailto:fuyuxin@sf-express.com">符瑜鑫(Ricky Fu)</a>
 *   
 * CreateDate: 2012-5-9
 */
public final class ReconHelper {
	
	private static final Logger logger = LoggerFactory.getLogger(ReconHelper.class);
	
	private static final boolean isDebug = logger.isDebugEnabled();
	
	/**
	 * 对账文件根目录
	 */
	private static final String ROOT = Property.getProperty("ROOT_RECON");
	
	private ReconHelper() {}
	
	/**
	 * 方法说明：
	 * 创建对账文件
	 * 
	 * @param tradeDate 日期
	 * @param channel 渠道编码{@link ChannelCode}
	 * @param bank 银行编码{@link BankCode}
	 * @param buf 文件字节
	 * @return 返回相对于根目录的对账文件路径
	 * @throws IOException
	 */
	public static String saveFile(Date tradeDate, BankCode bank, ChannelCode channel, byte[] buf) throws IOException {
		String fullPath = buildFile(tradeDate, bank, channel, true);
		
		if(isDebug) {
			logger.debug("对账文件保存路径: {}", fullPath);
		}

		FileOutputStream fos = null;
		try {
			fos = new FileOutputStream(fullPath);// 建立文件
			fos.write(buf);
		} finally {
			try {
				if(null != fos){ fos.close(); }
			} catch (Exception e) {
				logger.error("#buildReconFile: close stream exception: ", e);
			}
		}

		return fullPath;
	}
	
	/**
	 * 方法说明：<br>
	 * 生成({@code isNew==true})并返回对账文件路径全路径.
	 *
	 * @param tradeDate 交易日期
	 * @param bank 银行编码{@link BankCode}
	 * @param channel 渠道编码{@link ChannelCode}
	 * @param isNew 是否新建.true:新建;false:原有
	 * @return 
	 * @throws IOException
	 */
	public static String buildFile(Date tradeDate, BankCode bank, ChannelCode channel, boolean isNew) throws IOException {
		return buildFile(tradeDate, channel, bank.name().toLowerCase()+".recon", isNew);
	}
	
	/**
	 * 方法说明：<br>
	 * 根据文件名[生成({@code isNew==true})并]返回对账文件路径全路径.
	 *
	 * @param tradeDate 交易日期
	 * @param bank 银行编码{@link BankCode}
	 * @param channel 渠道编码{@link ChannelCode}
	 * @param isNew 是否新建.true:新建;false:原有
	 * @return 
	 * @throws IOException
	 */
	public static String buildFile(Date tradeDate, ChannelCode channel, String fileName, boolean isNew) throws IOException {
		StringBuffer path = new StringBuffer(50)
			.append(ROOT).append(ROOT.charAt(ROOT.length()-1) == '/' ? "" : "/")
			.append(new SimpleDateFormat("yyyyMMdd").format(tradeDate)).append("/")
			.append(channel.name().toLowerCase()).append("/");
		File dir = new File(path.toString());
		if (!dir.isDirectory()) {
			try{
			    	dir.mkdirs();
				} catch (SecurityException e) {
					throw new IOException("[ It doesn't own the create directory rights. ]",e);
				}
		}
		String filePath = path.append(fileName).toString();// 文件名
		if(isDebug) {
			logger.debug("对账文件保存路径: {}", filePath);
		}
		File file = new File(filePath);
		if(isNew) {
			if (file.exists()) {
				try{
				 file.delete();//TODO 删除还是用时间点备份?
				}catch (SecurityException e) {
					throw new IOException("[ It doesn't own the create directory rights. ]", e);
				}
			}
			try{
				file.createNewFile();
			}catch (SecurityException e) {
				throw new IOException("[ It doesn't own the create directory rights. ]", e);
			}
		} else {
			if (!file.exists()) {
				throw new IOException("["+filePath+"] not found.");
			}
		}
		return filePath;
	}
	
	/**
	 * 方法说明：<br>
	 * 获取对账文件相对路径.排除根目录.
	 * 注: 在分布式中,根目录的映射路径可能不同,传递到其它子系统时需要调用此方法.
	 *
	 * @param fullPath 对账文件全路径
	 * @return
	 */
	public static String getPathWithoutRoot(String fullPath) {
		return fullPath.substring(ROOT.length());
	}
	
	/**
	 * 方法说明：<br>
	 * 获取对账文件全路径
	 *
	 * @param relaPath 对账文件相对路径
	 * @return
	 */
	public static String getPathWithRoot(String relaPath) {
		return new StringBuffer(50).append(ROOT).append(relaPath).toString();
	}
	
}
