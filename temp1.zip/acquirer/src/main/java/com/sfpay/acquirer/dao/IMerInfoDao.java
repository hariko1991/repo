/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import com.sfpay.acquirer.domain.paycenter.MerInfo;
import com.sfpay.acquirer.domain.paycenter.MerInfoParam;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 400928 向鹏
 * 
 * CreateDate: 2014-2-26
 */
public interface IMerInfoDao {
	/**
	 * 
	 * 方法说明：<br>
	 * 追加商户信息
	 * @param info
	 */
	public void addMerInfo(@Param("info")MerInfo info);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 追加商户信息
	 * @param info
	 */
	public void delMerInfo(@Param("id")Long id);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 查询符个条件的商户信息
	 * @param param
	 */
	public MerInfo queryMerInfo(@Param("param")MerInfoParam param);	
	
	 /**
	  * 
	  * 方法说明：<br>
	  * 分页查询白名单信息
	  * @param param
	  * @param start
	  * @param end
	  */
	 public List<MerInfo> queryMerInfoByPage(@Param("param")MerInfoParam param,@Param("start")int start,@Param("end")int end);
	 
	 /**
	  * 
	  * 方法说明：<br>
	  * 统计符合条件的白名单记录笔数模糊匹配
	  * @param param
	  * @return
	  */
	 public Long countMerInfo(@Param("param")MerInfoParam param);
	 
	 /**
	  * 
	  * 方法说明：<br>
	  * 更新商户信息
	  * @param param
	  */
	 public void updateMerInfo(@Param("param")MerInfo param);
	 
	 /**
	  * 
	  * 方法说明：<br>
	  * 根据商户ID查询商户信息
	  * @param id
	  * @return
	  */
	 public MerInfo queryMerInfoById(@Param("id")Long id);
}
