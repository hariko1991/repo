package com.sfpay.acquirer.service.impl;


import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IBatchInfoDao;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.service.IAutoPayoutService;
import com.sfpay.acquirer.service.IB2EPayoutService;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
/**
 * 自动出款
 * @author sfhq814
 *add 2015-9-22
 */
@HessianExporter
@Service("autoPayoutService")
public class AutoPayoutServiceImpl implements IAutoPayoutService{
	private static Logger logger = LoggerFactory.getLogger(PayoutServiceImpl.class);
	@Resource
	private IBatchInfoDao batchInfoDao;
	@Resource
	private IB2EPayoutService payout;
	/**
	 * 接受付款中心发来的批次信息进行出款
	 */
	@Override
	public void autoPayout(String batchCode) {
		BatchInfo batchInfo = null;
		//检查入参
		if(StringUtils.isEmpty(batchCode)){
			return;
		}
		try {
			batchInfo = this.batchInfoDao.queryByBatchCode(batchCode);
			if(batchInfo==null){
				logger.info("不存在该批次信息,批次号:"+batchCode);
				return;
			}
		} catch (Exception e) {
			logger.error("批次号["+batchCode+"]查询异常",e);
		}
		try{
			//调用银行出款,生成报文，放入MQ
			payout.doPayoutReq(batchInfo);
		}catch(Exception ex){
			logger.error("批次号["+batchInfo.getBatchCode()+"]出款异常,后续由轮询处理",ex);
		}
	}
}
