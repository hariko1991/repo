/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import javax.annotation.Resource;

import com.sfpay.acquirer.service.IOMSService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.pubcenter.domain.District;
import com.sfpay.pubcenter.service.IConfigruationCenter;

/**
 * 
 * 类说明：
 *  配置中心提供的接口 实现类
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-6-6
 */
@Deprecated
//@Service("omsService")
public class OMSServiceImpl implements IOMSService {
	
	@Resource
	private IConfigruationCenter configruationCenter;
	
	@Override
	public String getDistrictName(String disctrictCode) throws ServiceException {
		District district = configruationCenter.findDistrictByCode(disctrictCode);
		//return null == district ? null : district.getName();	
		return null == district ? null : district.getDistName();
	}

}
