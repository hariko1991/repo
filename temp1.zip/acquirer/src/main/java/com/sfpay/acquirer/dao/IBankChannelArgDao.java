/**
 * 
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.BankChannelArg;
import com.sfpay.acquirer.domain.BankChannelArgQueryParam;
import com.sfpay.acquirer.domain.BankChannelArgUpdateParam;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;

/**
 * 类说明：
 * 银行渠道参数配置 dao 
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 * @author 329202 符瑜鑫(Ricky Fu)
 *   
 * CreateDate: 2012-5-28
 */
@Deprecated
public interface IBankChannelArgDao {
	
	/**
	 * 方法说明：
	 * 分页查询银行渠道参数配置 总条数
	 * @param map 查询条件
	 * @return
	 */
	public long queryBankChannelArgPageCount(@Param("param") BankChannelArgQueryParam param);
	
	/**	 
	 * 方法说明：
	 * 分页查询银行渠道参数配置 当页数据
	 * @param map 查询条件
	 * @return
	 */
	public List<BankChannelArg> queryBankChannelArgPageList(@Param("param") BankChannelArgQueryParam param, @Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：
	 * 根据id号修改银行渠道参数配置
	 * @param param
	 */
	public void updateBankChannelArgById(@Param("param") BankChannelArgUpdateParam param);
	
	/**
	 * 方法说明：<br>
	 * 根据银行简称、渠道编码查询对应的银行渠道参数信息
	 * 
	 * @param bank 银行简称 {@link BankCode}
	 * @param channel 渠道编码 {@link ChannelCode}
	 * @return
	 */
	public List<BankChannelArg> findBankChannelArgs(@Param("bank") BankCode bank, @Param("channel") ChannelCode channel);
	
	/**
	 * 方法说明：<br>
	 * 查询所有银行渠道参数信息
	 * 
	 * @return
	 */
	public List<BankChannelArg> findAllArgs();
	
	/**
	 * 方法说明：
	 * 根据id号查询银行渠道参数配置
	 * @param id
	 * 
	 */
	public BankChannelArg queryBankChannelArgById(long id);
	
}
