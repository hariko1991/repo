/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.AcquirerHelper;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.dao.IAccountInfoDao;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.AccountTransInfo;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.HisAcctTxQueryParam;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.service.IAccountTransService;
import com.sfpay.acquirer.service.common.BankCommonService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 
 * 类说明：<br>
 * 账户交易明细查询 
 * 
 * <p>
 * 详细描述：<br>
 * 账户交易明细查询 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2012-10-25
 */
@Service("accountTransService")
@HessianExporter
public class AccountTransServiceImpl extends BankCommonService implements IAccountTransService {
	private static final Logger logger = LoggerFactory.getLogger(AccountTransServiceImpl.class);
	@Resource
	private IAccountInfoDao accountInfoDao;
	
	@Override
	public List<AccountTransInfo> queryCurAccountTransList(BankCode bankCode,
			String accountNo) throws ServiceException {
		//检查参数
		if(bankCode == null){
			throw new ServiceException(InfoCode.PARAM_INVALID, "bankCode can't be null");
		}
		if(accountNo == null || "".equals(accountNo.trim())){
			throw new ServiceException(InfoCode.PARAM_INVALID, "accountNo can't be null");
		}
		
		
		//调用接口 
		AccountInfo accountInfo = accountInfoDao.queryAccountInfoByAccountNo(accountNo.trim(),null);
		//生成BankProperty 根据账号的所在银行，获取BankProperty。 sfhq270 2014-12-12
		ChannelCode channel = ChannelCode.B2E;
		BankProperty property = AcquirerHelper.getProperties(accountInfo.getBankCode(), channel);
		if(property == null){
			throw new ServiceException(InfoCode.NO_QUERY_RECORD, "bank no query record");
		}
		return getIQuery(bankCode).queryCurAccountTransList(property, accountInfo);
	}

	@Override
	public List<AccountTransInfo> queryHisAccountTransList(
			HisAcctTxQueryParam param) throws ServiceException {
		//检查参数
		if(param == null){
			throw new ServiceException(InfoCode.PARAM_INVALID, "param can't be null");
		}
		if(param.getBankCode() == null){
			throw new ServiceException(InfoCode.PARAM_INVALID, "bankCode can't be null");
		}
		if(param.getAccountNo() == null || "".equals(param.getAccountNo().trim())){
			throw new ServiceException(InfoCode.PARAM_INVALID, "accountNo can't be null");
		}
		if(param.getBeginTxDate() == null){
			throw new ServiceException(InfoCode.PARAM_INVALID, "beginTxDate can't be null");
		}
		if(param.getEndTxDate() == null){
			throw new ServiceException(InfoCode.PARAM_INVALID, "endTxDate can't be null");
		}
		//增加查询付款账户信息  sfhq270 2014-12-12
		AccountInfo accountInfo = this.accountInfoDao.queryAccountInfoByAccountNo(param.getAccountNo(),null);
		if(accountInfo == null){
			logger.error("找不到{}对应的付款账户信息", param.getAccountNo());
			throw new ServiceException(InfoCode.NO_QUERY_RECORD,"accountInfo is null");
		}
		
		//生成BankProperty  add 根据账号的所在银行，获取BankProperty。 sfhq270 2014-12-12
		ChannelCode channel = ChannelCode.B2E;
		BankProperty property = AcquirerHelper.getProperties(accountInfo.getBankCode(), channel);
		if(property == null){
			throw new ServiceException(InfoCode.NO_QUERY_RECORD, "bank no query record");
		}
		
		return getIQuery(param.getBankCode()).queryHisAccountTransList(property, param);
		
	}

}
