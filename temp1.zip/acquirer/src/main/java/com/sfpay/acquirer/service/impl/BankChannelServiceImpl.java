/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IBankChannelDao;
import com.sfpay.acquirer.domain.BankChannel;
import com.sfpay.acquirer.domain.BankChannelQueryParam;
import com.sfpay.acquirer.domain.BankChannelUpdateParam;
import com.sfpay.acquirer.enums.BankChannelStatus;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.service.IBankChannelService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明： 银行渠道设置 实现类
 * 
 * <p/>
 * 详细描述：
 * 
 * 
 * @author 312932 何国兴
 * CreateDate: 2012-5-28
 */
@Service("bankChannelService")
@HessianExporter
public class BankChannelServiceImpl implements IBankChannelService {

	private static Logger logger = LoggerFactory.getLogger(BankChannelServiceImpl.class);
	private static boolean isDebug = logger.isDebugEnabled();

	@Resource
	private IBankChannelDao bankChannelDao;

	@Deprecated
	@Override
	public IPage<BankChannel> queryBankChannelPage(BankChannelQueryParam param, int pageNo, int pageSize) throws ServiceException {
		// 查询总记录数
		long count = bankChannelDao.queryBankChannelPageCount(param);
		List<BankChannel> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			list = bankChannelDao.queryBankChannelPageList(param, start, end);
		}
		return new Page<BankChannel>(list, count, pageNo, pageSize);
	}

	@Deprecated
	@Override
	public void updateStatus(ChannelCode channel, BankCode bank, BankChannelStatus status) {
		if (null == bank) {
			throw new ServiceException(InfoCode.BANK_CODE_IS_NULL, "银行编码不能为空");
		}
		if (null == channel) {
			throw new ServiceException(InfoCode.CHANNEL_CODE_IS_NULL, "渠道编码不能为空");
		}
		if (null == status) {
			throw new ServiceException("", "status can't null");
		}
		bankChannelDao.updateBankChannelStatus(bank, channel, status);
	}

	@Deprecated
	@Override
	public void updateBankChannel(BankChannelUpdateParam param) {
		// 如果银行名称不为空,修改BANK_INFO表
		if (null != param.getBankCode() && !StringUtils.isEmpty(param.getBankName())) {
			bankChannelDao.updateBankInfo(param.getBankName(), param.getBankCode());
		}

		// 判断渠道编码不能为空
		if (null != param.getChannelCode()) {
			// 如果渠道名称不为空,修改 CHANNEL表
			if (!StringUtils.isEmpty(param.getChannelName())) {
				bankChannelDao.updateChannel(param.getChannelName(), param.getChannelCode());
			}
			// 如果显示顺序不为空,修改BANK_CHANNEL_REL表
			if (null != param.getShowIndex()) {
				bankChannelDao.updateBankChannelOrder(param.getBankCode(), param.getChannelCode(), param.getShowIndex());
			}
		}

	}

	@Override
	public List<BankChannel> queryBankChannelList(ChannelCode channelCode) throws ServiceException {
		if (null == channelCode) {
			throw new ServiceException(InfoCode.CHANNEL_CODE_IS_NULL, "渠道编码不能为空");
		}
		return bankChannelDao.queryBankChannelList(channelCode, false);
	}

	@Deprecated
	@Override
	public List<BankChannel> queryBankChannelAllList(ChannelCode channelCode) throws ServiceException {
		if (null == channelCode) {
			throw new ServiceException(InfoCode.CHANNEL_CODE_IS_NULL, "渠道编码不能为空");
		}
		return bankChannelDao.queryBankChannelList(channelCode, false);
	}

	@Deprecated
	@Override
	public BankChannel queryBankChannel(ChannelCode channelCode, BankCode bankCode) {
		if (null == bankCode) {
			throw new ServiceException(InfoCode.BANK_CODE_IS_NULL, "银行编码不能为空");
		}
		if (null == channelCode) {
			throw new ServiceException(InfoCode.CHANNEL_CODE_IS_NULL, "渠道编码不能为空");
		}
		return bankChannelDao.queryBankChannel(channelCode, bankCode);
	}

	/**
	 * 查询所有银行列表包括被代理的第三方银行
	 * 
	 * @param channelCode
	 * @param orderAsc
	 * @return
	 */
	@Deprecated
	@Override
	public List<BankChannel> queryAllBankList(ChannelCode channelCode, boolean orderAsc) throws ServiceException {
		return queryAllBank(channelCode, null, orderAsc);
	}

	/**
	 * 查询所有银行列表包括被代理的第三方银行<br>
	 * <b style="color:red;">注意:此接口用于测试！</b>
	 * 
	 * @param channelCode
	 * @param testIp
	 *            用于测试绑定的Ip,不能为空
	 * @param orderAsc
	 * @return
	 */
	@Deprecated
	@Override
	public List<BankChannel> queryAllBankList4Test(ChannelCode channelCode, String testIp, boolean orderAsc) throws ServiceException {
		if (StringUtils.isEmpty(testIp)) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "testIp can't be null");
		}
		if (isDebug) {
			logger.debug("testIp is: {}", testIp);
		}
		return queryAllBank(channelCode, testIp, orderAsc);
	}

	/**
	 * 方法说明：<br>
	 * 根据渠道和ip查询当银行为enAble 或者 银行为 disAble 并且 包含 ip ,该ip符合条件的情况的银行查询出来
	 * 
	 * @param channelCode
	 * @param testIp
	 * @param orderAsc
	 * @return
	 * @throws ServiceException
	 */
	@Deprecated
	private List<BankChannel> queryAllBank(ChannelCode channelCode, String testIp, boolean orderAsc) throws ServiceException {
		if (null == channelCode) {
			throw new ServiceException(InfoCode.CHANNEL_CODE_IS_NULL, "渠道编码不能为空");
		}
		if (isDebug) {
			logger.debug("channelcode is: {}", channelCode);
		}
		return bankChannelDao.queryAllBankList(channelCode, testIp, orderAsc);
	}

}
