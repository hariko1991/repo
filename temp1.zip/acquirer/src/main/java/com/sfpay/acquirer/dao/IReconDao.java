/**
 * 
 */
package com.sfpay.acquirer.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.ReconChangeQueryParam;
import com.sfpay.acquirer.domain.ReconChangeQueryRlt;
import com.sfpay.acquirer.domain.ReconChangeUpdateInfo;
import com.sfpay.acquirer.domain.ReconCollectRlt;
import com.sfpay.acquirer.domain.ReconDetailQueryParam;
import com.sfpay.acquirer.domain.ReconDetailQueryRlt;
import com.sfpay.acquirer.domain.ReconExpClearQueryParam;
import com.sfpay.acquirer.domain.ReconExpClearQueryRlt;
import com.sfpay.acquirer.domain.ReconExpDetailQueryParam;
import com.sfpay.acquirer.domain.ReconExpDetailQueryRlt;
import com.sfpay.acquirer.domain.ReconOutTmp;
import com.sfpay.acquirer.domain.ReconReportQueryParam;
import com.sfpay.acquirer.domain.ReconReportQueryRlt;
import com.sfpay.acquirer.domain.paycenter.EcsRecon;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.ReconClearFlag;

/**
 * 
 * 类说明：
 * 对账
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 * @author 329202 符瑜鑫(Ricky Fu)
 *   
 * CreateDate: 2012-5-9
 */
public interface IReconDao {
	
	/**
	 * 方法说明：批量插入外部记录对账临时表 
	 *
	 * @param reconOutTmpList
	 */
	public void addTradeOrderList(List<ReconOutTmp> reconOutTmpList);
	
	/**
	 * 方法说明：<br>
	 * 内部对账
	 *
	 * @param bank 银行简称 {@link BankCode}
	 * @param channel 渠道编码 {@link ChannelCode}
	 * @param tradeDate 交易日期
	 */
	public void saveRecon(@Param("bank") BankCode bank, @Param("channel") ChannelCode channel, @Param("tradeDate") Date tradeDate);
	
	/**
	 * 方法说明：<br>
	 * 查询银行简称,渠道编码,资金方向对应的对账记录总数
	 *
	 * @param bank 银行简称 {@link BankCode}
	 * @param channel 渠道编码 {@link ChannelCode}
	 * @param fw 资金方向{@link FundWay}
	 *  
	 * @return
	 */
	public long queryReconCount(@Param("bank") BankCode bank, @Param("channel") ChannelCode channel, @Param("fundWay") FundWay fw);
	
	/**	 
	 * 方法说明：
	 * 分页查询对账信息
	 * @param bank 银行简称 {@link BankCode}
	 * @param channel 渠道编码 {@link ChannelCode}
	 * @param fw 资金方向{@link FundWay}
	 * @param start 起始行
	 * @param end 结束行
	 * 
	 * @return
	 */
	public List<ReconCollectRlt> queryReconPageList(@Param("bank") BankCode bank, @Param("channel") ChannelCode channel, @Param("fundWay") FundWay fundWay, @Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：<br>
	 * 对账明细查询记录总数
	 *
	 * @return
	 */
	public long queryReconDetailCount(@Param("param") ReconDetailQueryParam param);
	
	/**	 
	 * 方法说明：
	 * 对账明细分页查询
	 * @param start 起始行
	 * @param end 结束行
	 * 
	 * @return
	 */
	public List<ReconDetailQueryRlt> queryReconDetail(@Param("param") ReconDetailQueryParam param, @Param("start") int start, @Param("end") int end);

	
	/**
	 * 方法说明：<br>
	 * 对账报表查询记录总数
	 *
	 * @return
	 */
	public long queryReconReportCount(@Param("param") ReconReportQueryParam param);
	
	/**	 
	 * 方法说明：
	 * 对账报表分页查询
	 * @param start 起始行
	 * @param end 结束行
	 * 
	 * @return
	 */
	public List<ReconReportQueryRlt> queryReconReport(@Param("param") ReconReportQueryParam param, @Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：<br>
	 * 对账差异明细查询记录总数
	 *
	 * @return
	 */
	public long queryReconExpCount(@Param("param") ReconExpDetailQueryParam param);
	
	/**	 
	 * 方法说明：
	 * 对账差异明细分页查询
	 * @param start 起始行
	 * @param end 结束行
	 * 
	 * @return
	 */
	public List<ReconExpDetailQueryRlt> queryReconExp(@Param("param") ReconExpDetailQueryParam param, @Param("start") int start, @Param("end") int end);

	/**
	 * 方法说明：<br>
	 * 对账差异清理前的查询记录总数
	 *
	 * @return
	 */
	public long queryReconExpClearCount(@Param("param") ReconExpClearQueryParam param);
	
	/**	 
	 * 方法说明：
	 * 对账差异清理前的查询 分页查询
	 * @param start 起始行
	 * @param end 结束行
	 * 
	 * @return
	 */
	public List<ReconExpClearQueryRlt> queryReconExpClear(@Param("param") ReconExpClearQueryParam param, @Param("start") int start, @Param("end") int end);
	
	/**	 
	 * 方法说明：
	 * 根据记录主键进行清理
	 * 
	 * @return
	 */
	public void clearReconExp(@Param("ids") List<Long>ids,@Param("remark") String remark ,@Param("status") ReconClearFlag clearFlag);
	
	/**
	 * 方法说明：
	 * 调账更新- 更新对账结果表为已调账
	 */
	public void updateReconChange(@Param("recon") ReconChangeUpdateInfo rcu);
	
	/**
	 * 方法说明：
	 * 根据主键id查询对账结果表信息
	 * @param reconRltId
	 * @return
	 */
	public ReconCollectRlt queryReconCollectRltById(@Param("reconRltId")long reconRltId);
	
	/**
	 * 方法说明：<br>
	 * 分页查询需要调账的记录 总数
	 *
	 * @return
	 */
	public long queryReconChangeCount(@Param("param") ReconChangeQueryParam param);
	
	/**	 
	 * 方法说明：
	 * 分页查询需要调账的记录 分页查询
	 * @param start 起始行
	 * @param end 结束行
	 * 
	 * @return
	 */
	public List<ReconChangeQueryRlt> queryReconChangeList(@Param("param") ReconChangeQueryParam param, @Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：<br>
	 * 按银行+渠道+日期，查询
	 *
	 * @return
	 * @throws Exception
	 */
	public List<ReconCollectRlt> selectFee(@Param("bankCode")BankCode bankCode
			,@Param("channelCode")ChannelCode channelCode,@Param("tradeDate")String tradeDate);
	
	
	/**
	 * 方法说明：<br>
	 * ecs分页查询的记录 总数
	 * sfhq272
	 * @return
	 */
	public long queryEcsReconCount(@Param("param") EcsRecon param);
	
	/**	 
	 * 方法说明：
	 * ecs分页查询的记录 分页查询
	 * @param start 起始行
	 * @param end 结束行
	 * sfhq272
	 * @return
	 */
	public List<EcsRecon> queryECSReconList(@Param("param") EcsRecon param, @Param("start") int start, @Param("end") int end);
	
	/**
	 * sfhq272
	 * Ecs导出列表查询 
	 * @param param
	 * @return
	 */
	public List<EcsRecon> queryECSReconListExport(@Param("param") EcsRecon param);
}
