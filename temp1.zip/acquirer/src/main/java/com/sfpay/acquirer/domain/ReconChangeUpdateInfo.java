/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.domain;

import com.sfpay.acquirer.enums.ReconChangeType;
import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：<br>
 * 调账更新结果Bean
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * CreateDate: 2013-11-18
 */
public class ReconChangeUpdateInfo extends BaseEntity {
	private static final long serialVersionUID = -645462974573361878L;
	/**
	 * 对账结果Id
	 */
	private Long reconId;
	/**
	 * 调账类型
	 */
	private ReconChangeType changeType;
	/**
	 * 调账状态
	 */
	private String status;
	/**
	 * 调账失败原因
	 */
	private String failReason;
	/**
	 * 调账备注
	 */
	private String remark;

	public Long getReconId() {
		return reconId;
	}

	public void setReconId(Long reconId) {
		this.reconId = reconId;
	}

	public ReconChangeType getChangeType() {
		return changeType;
	}

	public void setChangeType(ReconChangeType changeType) {
		this.changeType = changeType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFailReason() {
		return failReason;
	}

	public void setFailReason(String failReason) {
		this.failReason = failReason;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}
}
