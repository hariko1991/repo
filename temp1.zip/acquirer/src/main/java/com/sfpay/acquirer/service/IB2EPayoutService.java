package com.sfpay.acquirer.service;

import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.framework.base.exception.ServiceException;

public interface IB2EPayoutService {

	public void doPayoutReq(BatchInfo bi,BatchRuleInfo rule) throws ServiceException;
	
	public void doPayoutReq(BatchInfo bi) throws ServiceException;
}
