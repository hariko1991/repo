/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.paycenter.AccountBookInfo;
import com.sfpay.acquirer.domain.paycenter.AccountBookParam;

/**
 * 类说明：<br>
 * 白名单数据层操作业务
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 400928 向鹏
 * 
 * CreateDate: 2014-1-16
 */
public interface IPayoutAccountBookDao {
	
	/**
	 * 
	 * 方法说明：<br>
	 * 新增白名单信息
	 * @param info
	 */
	 public void addAccountBook(@Param("info")AccountBookInfo info);
	 
	 /**
	  * 
	  * 方法说明：<br>
	  * 物理删除白名单信息
	  * @param param
	  */
	 public void delAccountBook(@Param("id")Long id);
	 
	 /**
	  * 
	  * 方法说明：<br>
	  * 分页查询白名单信息
	  * @param param
	  * @param start
	  * @param end
	  */
	 public List<AccountBookInfo> queryAccountBookByPage(@Param("param")AccountBookParam param,@Param("start")int start,@Param("end")int end);
	 
	 /**
	  * 
	  * 方法说明：<br>
	  * 统计符合条件的白名单记录笔数模糊匹配
	  * @param param
	  * @return
	  */
	 public Long countAccountBook(@Param("param")AccountBookParam param);
	 
	 /**
	  * 
	  * 方法说明：<br>
	  * 统计符合条件的白名单记录笔数精确匹配
	  * @param param
	  * @return
	  */
	 public Long countAccountBookByReel(@Param("param")AccountBookParam param);
	 
	 /**
	  * 
	  * 方法说明：<br>
	  * 根据ID号查询相应的白名单信息
	  * @param id
	  * @return
	  */
	 public AccountBookInfo queryAccountBookInfoById(@Param("id")Long id);
	 
	 /**
	  * 
	  * 方法说明：<br>
	  * 更新白名单信息
	  * @param param
	  */
	 public void updateAccountBookInfo(@Param("param")AccountBookInfo param);

}
