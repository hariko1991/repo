package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.enums.BatchRuleStatus;

/**
 * 类说明：
 * 路由规则维护
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 349508 韦健
 * @author 329202 符瑜鑫(Ricky Fu)
 *   
 * CreateDate: 2012-10-25
 */
public interface IBatchRuleInfoDao {

	/**
	 * 方法说明：
	 * 分页查询常用收款单位信息
	 * @param map 查询条件
	 * @return
	 */
	public long queryBatchRuleInfoPageCount(@Param("param") BatchRuleInfo param);
	
	/**
	 * 方法说明：<br>
	 * 分页查询常用收款单位信息      当页数据
	 * @param param
	 * @param start
	 * @param end
	 * @return
	 */
	public List<BatchRuleInfo> queryBatchRuleInfoPageList(@Param("param") BatchRuleInfo param, @Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：<br>
	 * 根据主键id查询常用收款单位信息
	 * @param id
	 * @return
	 */
	public BatchRuleInfo queryBatchRuleInfoById(@Param("id") long id);

	/**
	 * 方法说明：<br>
	 * 罗列路由规则所有记录
	 * @return
	 */
	public List<BatchRuleInfo> listAllBatchRuleInfo();
	
	/**
	 * 方法说明：<br>
	 * 增加路由规则信息 
	 * @param param查询条件
	 */
	public void  addBatchRuleInfo(@Param("param") BatchRuleInfo param);
	
	/**
	 * 方法说明：
	 * 修改路由规则信息       总条数
	 * @param map 查询条件
	 * @return
	 */         
	public void updateBatchRuleInfoById(@Param("param") BatchRuleInfo param);
	
	/**
	 * 方法说明：<br>
	 * 删除路由规则信息
	 * @param ids
	 */
	public void deleteBatchRuleInfo(@Param("ids") List<Long> ids);
	
	/**
	 * 方法说明：根据规则编码查询对象
	 *
	 * @param ruleCode
	 */
	public BatchRuleInfo queryBatchRuleInfoByCode(@Param("ruleCode") String ruleCode);
	
	/**
	 * 方法说明：设置是否启用
	 * 
	 * @param id
	 */
	public void isEnAble(@Param("id") Long id, @Param("status") BatchRuleStatus status);

	
	/**
	 * 方法说明：
	 * 根据规则编码查询对象-自动路由
	 *
	 * @param ruleCode
	 */
	public BatchRuleInfo queryBatchRuleInfoByCodeAuto(@Param("ruleCode") String ruleCode);
}
