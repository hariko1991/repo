/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.CollectInfo;
import com.sfpay.acquirer.domain.RecData;
import com.sfpay.acquirer.domain.ReverseInfo;
import com.sfpay.acquirer.enums.CardType;
import com.sfpay.acquirer.enums.CollectStatus;
import com.sfpay.acquirer.enums.SystemSource;
import com.sfpay.framework.base.dao.IDao;

/**
 * 类说明：收单信息数据存取类
 *  
 * 
 * <p>
 * 详细描述：
 *   
 * 
 * @author 271762
 * @author 329202 符瑜鑫(Ricky Fu)
 *   
 * CreateDate: 2012-3-14
 */
public interface ICollectInfoDao extends IDao<CollectInfo, String> {
	
	/**
	 * 方法说明：
	 * 根据收单编号获取对应收单记录.此记录唯一
	 *
	 * @param collectNo
	 * @return
	 * @throws Exception
	 */
	public CollectInfo findByCollectNo(String collectNo) throws Exception;
	
	/**
	 * 方法说明：
	 * 根据收单业务流水号获取对应收单记录.<br>
	 * <span style="color:red;">此记录可能不唯一</span>
	 *
	 * @param bizNo
	 * @return
	 * @throws Exception
	 */
	public CollectInfo findByBizNo(String bizNo) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 根据支付流水号、系统来源查找对应的收单状态
	 * 
	 * @param payNo 支付流水号
	 * @param src 系统来源
	 * @return
	 * @throws Exception
	 */
	public CollectInfo findByPayNo(@Param("payNo") String payNo, @Param("src") SystemSource src) throws Exception;
	
	/**
	 * 方法说明：创建一条收单记录
	 *
	 * @param ci
	 * @throws Exception
	 */
	public void createCollectInfo(CollectInfo ci) throws Exception;
	
	/**
	 * 方法说明：根据收单编号更新收单记录
	 * @param ci
	 */
	public void updateByCollectNo(@Param("param") CollectInfo ci) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 开通快捷支付的用户信息保存
	 * 
	 * @param mobile 手机
	 * @param cards 卡号(后4位)
	 * @throws Exception
	 */
	public void createQPayUser(@Param("mobile") String mobile, @Param("cards") List<String> cards) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 根据收单编号更新退款/撤销(反向操作)的收单的退款&状态信息
	 * 
	 * @param reverse 反向收单信息
	 * @throws Exception
	 */
	public int updateByReverse(ReverseInfo reverse) throws Exception;
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据收单编号更新收单记录 
	 * 更新一条收单记录 用在银行回调返回时的更新 该记录状态为INIT
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public int updateForBankCall(@Param("ci") CollectInfo ci) throws Exception;
	
//	/**
//	 * 方法说明：根据银行交易流水号更新收单记录
//	 * @param map
//	 * @throws Exception
//	 */
//	public void updateByReqBankSn(@Param("param") UpdateCollectResult param) throws Exception;
	
//	/**
//	 * 方法说明：根据批次编号修改收单状态
//	 * @param map
//	 * @throws Exception
//	 */
//	public void updateByBatchCode(@Param("batchCode")String batchCode,@Param("status")CollectStatus status);
	
	/**
	 * 方法说明：<br>
	 * 根据收单编号更新备注字段
	 * 
	 * @param collectNo 收单编号
	 * @param remark 备注
	 */
	public void updateRemark(@Param("collectNo") String collectNo, @Param("remark") String remark);
	
//	/**
//	 * 方法说明：根据条件返回结果集
//	 *
//	 * @param map
//	 * @return
//	 * @throws Exception
//	 */
//	public List<CollectInfo> selectCollectInfo(Map<String,Object> map) throws Exception;
	
//	/**
//	 * 方法说明：出款查询
//	 *
//	 * @param map
//	 * @return
//	 * @throws Exception
//	 */
//	public List<CollectInfo> selectCollectNoBatchCode(Map<String,Object> map) throws Exception;
	
//	/**
//	 * 方法说明：<br>
//	 * 获得成功状态的记录条数
//	 */
//	public long countReconCollectInfo(@Param("reconDate") String reconDate);
	
//	/**
//	 * 方法说明：获得符合条件的记录条数
//	 */
//	public long selectCollectInfoCount(@Param("param") CollectQueryParam param);
	
//	/**
//	 * 方法说明：分页查询使用
//	 */
//	public List<CollectInfo> selectCollectInfoList(@Param("param") CollectQueryParam param, @Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：<br>
	 * 查询收款表和出款表复核对账日期的记录总数
	 */
	public Long countRecon(@Param("reconDate") String reconDate);
	
	/**
	 * 方法说明：<br>
	 * 查询收款表和出款表复核对账日期的每页记录
	 */
    public List<RecData> queryRecon(@Param("reconDate") String reconDate, @Param("start") int start, @Param("end") int end);	
	
	/**
	 * 方法说明：<br>
	 * 关闭<code>end</code>天前状态为初始的收单记录
	 *
	 * @param end
	 */
	public void closeCollectInfo(@Param("endTime") Date endTime, @Param("status") CollectStatus status);
	
	/**
	 * 方法说明：	 
	 * 查询关闭<code>end</code>天前状态为初始的收单记录
	 * @param map
	 * @return
	 * @throws Exception
	 */
	public List<CollectInfo> queryCloseCollectInfo(@Param("endTime") Date endTime) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 根据银行业务流水和交易时间查询收单记录
	 * @param bankCode
	 * @param reqBankSn
	 * @param tradeDate
	 * @return
	 * @throws Exception
	 */
	public CollectInfo queryCollectInfoForCheck(@Param("bussinessSn")String bussinessSn,@Param("tradeDate")Date tradeDate) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 根据收单编号修改收单状态(当天补单)
	 * @param collectNo
	 * @param rtnBankMsg
	 * @param rtnBankCode
	 * @param rtnPayCode
	 * @return
	 * @throws Exception
	 */
	public int updateForResupplyByNo(@Param("collectNo") String collectNo,@Param("rtnBankMsg") String rtnBankMsg,@Param("rtnBankCode") String rtnBankCode,@Param("rtnPayCode") String rtnPayCode)throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 根据银行交易流水号，修改卡类型和手续费
	 *
	 * @param ci
	 * @return
	 * @throws Exception
	 */
	public int updateFee(@Param("payerCardType")CardType payerCardType, @Param("fee")Long fee, @Param("reqBankSn")String reqBankSn) ;	
	
//	/**
//	 * 方法说明：查询出收款表复核对账日期的记录<br>
//	 */
//	public List<RecData> selectCollectInfoReconList(Map<String,Object> map) throws Exception;
}
