/**
 * 
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.ThirdCoverBank;
import com.sfpay.acquirer.domain.ThirdCoverBankQueryParam;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.ThirdBankCode;
import com.sfpay.acquirer.enums.ThirdCoverBankStatus;

/**
 * 
 * 类说明：
 * 第三方支持的银行 dao层 
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 * @author 329202 符瑜鑫(Ricky Fu)
 *   
 * CreateDate: 2012-6-1
 */
public interface IThirdCoverBankDao {
	/**
	 * 方法说明：
	 * 分页查询第三方支持的银行 总条数
	 * @param map 查询条件
	 * @return
	 */
	public long countThirdCoverBankPage(@Param("param") ThirdCoverBankQueryParam param);
	
	/**	 
	 * 方法说明：
	 * 分页查询第三方支持的银行 当页数据
	 * @param map 查询条件
	 * @return
	 */
	public List<ThirdCoverBank> queryThirdCoverBankPage(@Param("param") ThirdCoverBankQueryParam param, @Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：
	 * 根据id号修改状态
	 * @param id
	 * @param status
	 * @param remark
	 */
	public void updateStatus(@Param("id")long id,@Param("status")ThirdCoverBankStatus status,@Param("remark")String remark);
	
	/**
	 * 
	 *
	 * 方法说明：
	 * 查询第三方支持的银行列表(状态为可用的)
	 * @param channelCode
	 * @param bankCode
	 * @return
	 */
	public List<ThirdCoverBank> queryThirdCoverBankList(@Param("channelCode")ChannelCode channelCode,@Param("bankCode")ThirdBankCode bankCode);
	
	/**
	 * 根据id获取对象
	 * @param id
	 * @return
	 */
	public ThirdCoverBank queryThirdCoverBankById(@Param("id") long id);
	
    /**
     * 修改第三方对象属性，除了修改状态
     * @param thirdCoverBank
     */
	public void updateThirdCoverBankById(@Param("param") ThirdCoverBank thirdCoverBank);
	
}
