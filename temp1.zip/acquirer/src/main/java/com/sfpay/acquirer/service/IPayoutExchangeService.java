package com.sfpay.acquirer.service;

import java.util.List;

import com.sfpay.acquirer.domain.PayoutExchange;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.enums.ExchangeType;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 
 * 类说明：<br>
 * 付款交互接口
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-8-13
 */
public interface IPayoutExchangeService {

	/**
	 * 方法说明：<br>
	 * 生成交互信息
	 *
	 * @param ps
	 * @throws ServiceException
	 */
	public PayoutExchange createExchange(PayoutInfo info,ExchangeType exchangeType) throws ServiceException;
	
	/**
	 * 方法说明：<br>
	 * 生成退票交互信息
	 *
	 * @param ps
	 * @throws ServiceException
	 */
	public List<PayoutExchange> createBounceExchange(PayoutInfo info,List<PayoutExchange> oldExchanges,ExchangeType exchangeType) throws ServiceException;
	
	/**
	 * 方法说明：<br>
	 * 批量生成交互信息
	 *
	 * @param ps
	 * @throws ServiceException
	 */
	public List<PayoutExchange> createExchangeList(List<PayoutInfo> ps,ExchangeType exchangeType) throws ServiceException;
	
	/**
	 * 方法说明：<br>
	 * 更新交互信息
	 *
	 * @param info
	 * @param exchangeType
	 * @return
	 * @throws ServiceException
	 */
	public void updateOrderResp(String tradeNo,
			String exchangeNo,
			String returnCode,
			String returnMsg,
			ExchangeType exchangeType) throws ServiceException;
	
	/**
	 * 方法说明：<br>
	 * 根据付款编号查询交互信息(如交互类型不为空，则查询所属交互类类型的交互信息)
	 *
	 * @param PayoutNo
	 * @param exchangeTypes
	 * @throws ServiceException
	 */
	public  List<PayoutExchange> queryExchange(PayoutExchange info,List<ExchangeType> exchangeTypes) throws ServiceException;
}
