/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IAffiliateBankDao;
import com.sfpay.acquirer.domain.AffiliateBank;
import com.sfpay.acquirer.domain.AffiliateBankParam;
import com.sfpay.acquirer.service.IAffiliateBankService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：<br>
 * 银行联行号service实现
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2012-10-23
 */
@Service("affiliateBankService")
@HessianExporter
public class AffiliateBankServiceImpl implements IAffiliateBankService {
	private static final Logger logger = LoggerFactory.getLogger(AffiliateBankServiceImpl.class);
	private static final boolean isDebug = logger.isDebugEnabled();
	@Resource
	private IAffiliateBankDao affiliateBankDao;

	@Override
	public List<AffiliateBank> queryBank() throws ServiceException {
		return affiliateBankDao.queryBank();
	}

	@Override
	public List<AffiliateBank> queryAffiliate(String affiliateNo, String countryCode, String affiliateName, String provinceCode) throws ServiceException {
		if (StringUtils.isEmpty(affiliateNo)) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "affiliateNo can't be null");
		}
		return affiliateBankDao.queryAffiliate(affiliateNo.trim(), countryCode, affiliateName, provinceCode);
	}

	@Override
	public IPage<AffiliateBank> queryAffiliatePage(AffiliateBankParam param, int pageNo, int pageSize) throws ServiceException {
		// 查询总记录数
		long count = affiliateBankDao.queryPageCount(param);
		List<AffiliateBank> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			list = affiliateBankDao.queryPage(param, start, end);
		}
		return new Page<AffiliateBank>(list, count, pageNo, pageSize);
	}

	@Override
	public AffiliateBank getBankByAffiliateNo(String affiliateNo) throws ServiceException {
		if (StringUtils.isEmpty(affiliateNo)) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "affiliateNo can't be null");
		}
		return affiliateBankDao.queryBankByAffiliateNo(affiliateNo.trim());
	}

	@Override
	public List<AffiliateBank> getPayBankByPayChannelNo(String payChannelNo)throws ServiceException {
		logger.info("进入getPayBankByPayChannelNo,payChannelNo;={}",payChannelNo);
		if(isDebug){
			logger.debug("getPayBankByPayChannelNo param include payChannelNo：={}",payChannelNo);
		}
		List<AffiliateBank> affiliateBankList=affiliateBankDao.queryPayBankByPayChannelNo(payChannelNo);
		logger.info("结束getPayBankByPayChannelNo,affiliateBankList;={}",affiliateBankList);
		return affiliateBankList;
	}
	
}
