/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.gate.b2e.command;

import java.util.ArrayList;
import java.util.List;

import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchPayoutReqResult;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutReqResult;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.RemitMethod;
import com.sfpay.acquirer.gate.b2e.BaseCommand;
import com.sfpay.acquirer.gate.b2e.domain.AgtexchTransferSubInfo;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.TransferInfo;
import com.sfpay.acquirer.gate.b2e.domain.TransferSubInfo;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 400928 向鹏
 * 
 * CreateDate: 2014-3-11
 */
public class BatchAgtexchTransfer extends BaseCommand{

	private BatchInfo bi;
	private List<PayoutInfo> pis;
	private BankCode bankCode;
	
	public BatchAgtexchTransfer(){		
		super(TradeCodeB2E.BATCH_AGENT_TRANSFER);
	}
	public BatchAgtexchTransfer(BatchInfo bi,List<PayoutInfo> pis,BankCode bankCode){
		super(TradeCodeB2E.BATCH_AGENT_TRANSFER);
		this.bi = bi;
		this.pis = pis;
		this.bankCode = bankCode;		
	}
	
	@Override
	protected BeanBase assemble(BankProperty property) throws Exception {
		try{
			PayoutInfo payoutInfo = pis.get(0);
			CurrencyType ccy = null;
			
			if(payoutInfo.getCcy() == null){
				//默认为人民币
				ccy = CurrencyType.RMB;
			}else{
				ccy = payoutInfo.getCcy();
			}
			//设置报文头 
			BeanBase beanBase = new BeanBase(bankCode, super.tradeCodeB2E);
			/**
			 * 用于结算中心报文序列号
			 * sfh270   2014-12-03
			 */
			beanBase.setSeqNo(CUID.getSZFSMsgNo());
			//测试时间
			if(BankCode.ICBC.equals(bankCode)){
				String testDate = Property.getProperty("B2E_TEST_ICBC_DATE");
				if(testDate != null && !"".equals(testDate.trim())){
					property.put("testDate", testDate);
				}
			}
			
			beanBase.setBankProperties(property);//银行参数
			
			TransferInfo transferInfo = new TransferInfo();
			//设置共用参数
			transferInfo.setSerialId(bi.getReqBankSn());
			transferInfo.setCheckStr("");
			transferInfo.setCur(ccy);
			transferInfo.setPayerAccNo(payoutInfo.getPayerAcctNo());
			transferInfo.setPayerAccName(payoutInfo.getPayerAcctName());
			transferInfo.setPayerProv(payoutInfo.getPayerAcctProvinceName());
			transferInfo.setPayerCity(payoutInfo.getPayerAcctCityName());
			transferInfo.setPayerOpenBranchName(payoutInfo.getPayerBranchName());
			transferInfo.setSendTime(DateUtil.getCDateString(DateUtil.DATA_FORMAT_PATTERN));
			transferInfo.setBatchCode(bi.getBatchCode());
			if(BankCode.BOC.equals(bankCode)){
				transferInfo.setBocBankCode(payoutInfo.getPayerBranchCode());
			}
			
			List<TransferSubInfo> subInfoList = new ArrayList<TransferSubInfo>();
			//设置子记录信息
			int totalNum = 0;
			long totalAmt = 0l;
			for(PayoutInfo payInfo : pis){
				AgtexchTransferSubInfo subInfo = new AgtexchTransferSubInfo();
				
				subInfo.setSubSerialId(payInfo.getReqBankSn());
				subInfo.setAmt(payInfo.getAmt());
				subInfo.setPayeeAccName(payInfo.getPayeeAcctName());
				subInfo.setPayeeAccNo(payInfo.getPayeeAcctNo());
				subInfo.setPayeeProv(payInfo.getPayeeAcctProvinceName());
				subInfo.setPayeeCity(payInfo.getPayeeAcctCityName());
				subInfo.setPayeeOpenBranchName(payInfo.getPayeeBranchName());
				subInfo.setPayeeBankNo(payInfo.getPayeeBranchCode());
				//增加收款方联行号 sfhq270 2014-12-01
				subInfo.setPayeeUnionBankCode(payInfo.getPayeeUnionBankCode());
				subInfo.setPostscript(payInfo.getSummary());//附言
				subInfo.setRemark(payInfo.getSummary());//备注
				subInfo.setSummary(payInfo.getSummary());//摘要
				subInfo.setUsefor(payInfo.getUseType());
				subInfo.setPayAgentAccNo(payInfo.getAgentAcctNo());
				subInfo.setPayAgentName(payInfo.getAgentName());				
				subInfo.setDifBankFlag(payInfo.getPayerOrgCode().equals(payInfo.getPayeeOrgCode())?"0":"1");
				
				if(RemitMethod.FAST.equals(payInfo.getRemitMethod())){
					//加急
					subInfo.setUrgencyFlag("1");
				}else {
					//普通
					subInfo.setUrgencyFlag("0");
				}
				
				String payerOrgCode = payInfo.getPayerOrgCode().name();
				String payeeOrgCode = payInfo.getPayeeOrgCode().name();
				if(!payerOrgCode.equals(payeeOrgCode)){//跨行
					subInfo.setDifBankFlag("1");
				}else{//同行
					subInfo.setDifBankFlag("0");
				}
				
//				不做判断
//				try{
//					if(pi.getPayerAcctCity().equals(pi.getPayeeAcctCity())){
//						subInfo.setDifAreaFlag("0");
//					}else{
//						subInfo.setDifAreaFlag("1");
//					}
//				}catch(Exception ex){
//					logger.error("无法判断同城异地.");
//				}
				
				//计算总数和总金额
				totalNum += 1;
				totalAmt += payInfo.getAmt();
				
				subInfoList.add(subInfo);
			}
			
			transferInfo.setTotalAmt(totalAmt);
			transferInfo.setTotalCount(totalNum);
			transferInfo.setSubInfoList(subInfoList);
			beanBase.setBusDetailBeanBase(transferInfo);
			
			
			return beanBase;
		}catch(Exception ex){
			logger.error("批次[请求流水号:"+bi.getReqBankSn()+"]生成报文异常:",ex);
			throw new ServiceException(InfoCode.FAILURE, ex);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	protected PayoutReqResult parseMsg(BeanBase resp) throws Exception {
		//2050607 避免重复代码
		return new BatchPayoutReqResult(resp);
	}

}
