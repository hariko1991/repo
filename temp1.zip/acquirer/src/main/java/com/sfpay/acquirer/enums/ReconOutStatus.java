/**
 * 
 */
package com.sfpay.acquirer.enums;

/**
 * 
 * 类说明：
 * 外部记录对账的状态 
 * 
 * <p/>
 * 详细描述：
 *   SUCCESS成功  FAILURE失败 UNKOWN未知不明
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-5-9
 */
public enum ReconOutStatus {
	/**
	 * 成功
	 */
	SUCCESS,
	
	/**
	 * 失败
	 */
	 FAILURE,
	 
	 /**
	  *未知不明
	  */
	 UNKOWN
}
