package com.sfpay.acquirer.task;


import javax.annotation.Resource;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.dao.rb.IBankBounceFileDao;
import com.sfpay.acquirer.dao.rb.IBankReconFileDao;
import com.sfpay.acquirer.task.thread.SZFSADJThread;
import com.sfpay.acquirer.task.thread.SZFSRECThread;
import com.sfpay.acquirer.task.thread.SZFSRTNThread;

/**
 * 结算中心和银企(批量代付和单笔代付对账
 * @author sfhq272
 *
 */
@Service("SZFSReconBounceTask")
public class SZFSReconBounceTask {
	private static final Logger logger = LoggerFactory.getLogger(SZFSReconBounceTask.class);
	
	@Resource
	private IBankReconFileDao bankReconFileDao;
	@Resource
	private IBankBounceFileDao bankBounceFileDao;
	
	@Resource
	private SZFSADJThread szfsADJThread;
	@Resource
	private SZFSRECThread szfsRECThread;
	@Resource
	private SZFSRTNThread szfsRTNThread;
	
	public void execute(){
		
		//目前每次只需要下载3个文件
		try {
			//先删除已经下载的数据
			int reconInner = bankReconFileDao.deleteBankInnerFileCurday();
			int reconOuter = bankReconFileDao.deleteBankOuterFileCurday();
			int reconRlt = bankReconFileDao.deleteBankReconFileCurday();
			int bounceRlt=  bankBounceFileDao.deleteBankBounceFileCurday();
			
			logger.info("deleteBankInnerFileCurday[{}],deleteBankOuterFileCurday[{}],deleteBankReconFileCurday[{}],deleteBankBounceFileCurday[{}]",
					new Object[]{reconInner,reconOuter,reconRlt,bounceRlt});
			
			szfsADJThread.run();
			szfsRECThread.run();
			szfsRTNThread.run();
		} catch (Exception e) {
			logger.error("信息处理异常", e);
		}
	}
}
