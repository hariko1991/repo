/**
 * 
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.BankChannel;
import com.sfpay.acquirer.domain.BankChannelQueryParam;
import com.sfpay.acquirer.enums.BankChannelStatus;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;

/**
 * 类说明：
 * 银行渠道设置 dao 
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 * @author 329202 符瑜鑫(Ricky Fu)
 *   
 * CreateDate: 2012-5-28
 */
public interface IBankChannelDao {
	
	/**
	 * 方法说明：
	 * 分页查询银行渠道设置 总条数
	 * @param map 查询条件
	 * @return
	 */
	public long queryBankChannelPageCount(@Param("param") BankChannelQueryParam param);
	
	/**	 
	 * 方法说明：
	 * 分页查询银行渠道设置 当页数据
	 * @param map 查询条件
	 * @return
	 */
	public List<BankChannel> queryBankChannelPageList(@Param("param") BankChannelQueryParam param, @Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：<br>
	 * 根据银行简称、渠道编码更新对应的记录状态
	 *
	 * @param bank 银行简称{@link BankCode}
	 * @param channel 渠道编码{@link ChannelCode}
	 * @param status 状态
	 */
	public void updateBankChannelStatus(@Param("bank") BankCode bank, @Param("channel") ChannelCode channel, @Param("status") BankChannelStatus status);
	
	/**
	 * 方法说明：<br>
	 * 根据渠道编码更新渠道名称
	 *
	 * @param channelName 渠道名称
	 * @param channel 渠道编码{@link ChannelCode}
	 */
	public void updateChannel(@Param("channelName") String channelName, @Param("channel") ChannelCode channel);
	
	/**
	 * 方法说明：<br>
	 * 根据银行简称更新银行名称
	 *
	 * @param bankName 银行名称
	 * @param bank 银行简称{@link BankCode}
	 */
	public void updateBankInfo(@Param("bankName") String bankName, @Param("bank") BankCode bank);
	
	/**
	 * 方法说明：<br>
	 * 根据银行简称、渠道编码更新对应的显示顺序
	 *
	 * @param bank 银行简称{@link BankCode}
	 * @param channelName 渠道名称
	 * @param showIndex 显示顺序
	 */
	public void updateBankChannelOrder(@Param("bank") BankCode bank, @Param("channel") ChannelCode channel, @Param("showIndex") Long showIndex);
	
	/**
	 * 方法说明：
	 * 查询渠道所有的银行列表(状态为可用的)
	 * @param channelCode
	 * @param isFilter 是否过滤第三方.true则过滤,否则不过滤
	 * @return
	 */
	public List<BankChannel> queryBankChannelList(@Param("channelCode")ChannelCode channelCode, @Param("isFilter") boolean isFilter);
	
	/**
	 * 查询所有银行列表包括被代理的第三方银行
	 * @param channelCode
	 * @param orderby
	 * @return
	 */
	public List<BankChannel> queryAllBankList(@Param("channelCode")ChannelCode channelCode, @Param("testIp")String testIp, @Param("orderAsc") boolean orderAsc);
	
	/**
	 * 
	 *
	 * 方法说明：
	 * 根据渠道、银行编码查询银行渠道信息
	 * @param channelCode 渠道编码
	 * @param bankCode 银行编码
	 * @return
	 */
	public BankChannel queryBankChannel(@Param("channelCode")ChannelCode channelCode,@Param("bankCode")BankCode bankCode);
	
}
