/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.task;

import java.util.Calendar;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.service.IReconGatewayFileService;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：<br>
 * 生成网关对账文件
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-7-22
 */
@Deprecated
@Service("createGatewayFileTask")
public class CreateGatewayFileTask {
	private static final Logger logger = LoggerFactory.getLogger(CreateGatewayFileTask.class);
	
	@Resource
	private IReconGatewayFileService rgService;
	
	/**
	 * 方法说明：
	 * 生成网关对账文件并上传FTP
	 */
	public void execute()throws ServiceException{
		logger.info("------进入生成未生成网关对账文件任务调度------");
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DATE,cal.get(Calendar.DATE)-1);//对昨天的
		//生成并上传网关对账文件
		rgService.doGateReconFile(cal.getTime(), false);
		logger.info("------完成生成网关对账文件的收单记录任务调度------");
	}
}
