/**
 * 
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.Account;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.AccountInfoQueryParam;
import com.sfpay.acquirer.domain.AccountInfoUpdateParam;
import com.sfpay.acquirer.enums.AccountInfoStatus;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;

/**
 * 
 * 类说明：
 *  集团账户 dao
 * 
 * <p/>
 * 详细描述：
 * 银行开设的账户信息      
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-5-29
 */
public interface IAccountInfoDao {
	/**
	 * 方法说明：
	 * 分页查询银行开设的账户信息       总条数
	 * @param map 查询条件
	 * @return
	 */
	public long queryAccountInfoPageCount(@Param("param") AccountInfoQueryParam param);
	
	/**	 
	 * 方法说明：
	 * 分页查询银行开设的账户信息       当页数据
	 * @param map 查询条件
	 * @return
	 */
	public List<AccountInfo> queryAccountInfoPageList(@Param("param") AccountInfoQueryParam param, @Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：<br>
	 * 根据Id查询对应的银行账户信息
	 *
	 * @param id 表主键
	 * @return
	 */
	public AccountInfo queryAccountInfo(Long id);
	
	/**
	 * 方法说明：<br>
	 * 根据账户号更新对应的账户状态
	 *
	 * @param accountNo
	 * @param status
	 * @param remark
	 */
	public void updateStatus(@Param("accountNo") String accountNo, @Param("status") AccountInfoStatus status, @Param("remark") String remark);
	
	/**
	 * 方法说明：<br>
	 * 根据账户号更新更新对应的账户信息
	 *
	 * @param param 更新参数
	 */
	public void updateAccountInfo(@Param("param") AccountInfoUpdateParam param);
	
	/**
	 * 方法说明：<br>
	 * 根据ID更新更新对应的账户信息
	 *
	 * @param param 更新参数
	 */
	public void updateAccountInfoById(@Param("param") AccountInfoUpdateParam param);
	
	/**
	 * 方法说明：<br>
	 * 根据账户参数新增对应的账户
	 *
	 * @param param 账户参数
	 */
	public void addAccountInfo(@Param("param") AccountInfoUpdateParam param);
	
	/**
	 * 方法说明：<br>
	 * 查询银行简称({@link BankCode}),渠道编码({@link ChannelCode}),订单类型({@link OrderType})账户信息.
	 * 若参数为null则为查询所有账户信息
	 *
	 * @return
	 */
	public Account findAccount(@Param("bank") BankCode bank, @Param("channel") ChannelCode channel, @Param("type") OrderType type, @Param("fundWay") FundWay fundWay);

	
	/**
	 * 方法说明：
	 *
	 * @param accountNo
	 * @return
	 */
	public AccountInfo queryAccountInfoByAccountNo(@Param("accountNo") String accountNo,@Param("channelCode")ChannelCode channelCode);
	
	/**	 
	 * 方法说明：
	 * 查询渠道下的有效可用的银行账户信息
	 * @param channelCode 渠道编码
	 * @param bankCode 银行编码
	 * @return
	 */
	public List<AccountInfo> queryAccountInfoList(@Param("channelCode")ChannelCode channelCode,@Param("bankCode")BankCode bankCode);
	
	
	/**
	 * sfhq272
	 * 结算中心资金对账付款银行列表
	 * @return
	 */
	public List<AccountInfo> queryBankPayoutReconAccountInfoList(String sysChannelCode);
}
