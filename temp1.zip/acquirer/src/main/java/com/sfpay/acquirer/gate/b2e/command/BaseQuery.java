package com.sfpay.acquirer.gate.b2e.command;

import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.PayoutResult;
import com.sfpay.acquirer.gate.b2e.BaseCommand;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;

/**
 * 
 * 
 * 类说明：<br>
 * 查询（余额、交易明细） 指令基类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-5-16
 */
public abstract class BaseQuery extends BaseCommand {

	@Override
	public abstract BeanBase assemble(BankProperty property) throws Exception;

	protected BaseQuery(TradeCodeB2E tradeCodeB2E) {
		super(tradeCodeB2E);
	}
	
	@Override
	protected <T extends PayoutResult> T parseMsg(BeanBase respBean)
			throws Exception {
		return null;
	}

}
