/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.web;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.web.domain.PayoutNotifyItem;
import com.sfpay.acquirer.web.domain.PayoutNotifyRlt;
import com.sfpay.cod.dto.PayAmtInfoDTO;
import com.sfpay.cod.enums.PayStatus;
import com.sfpay.cod.service.IPayApplyInfoService;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 类说明：<br>
 * 付款、退票结果通知COD系统,暂时由收单提供.后续版本优化时由COD系统提供
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-11-21
 */
@Controller
@RequestMapping(value="/notify/cod")
public class PayoutNotifyForCod {
	private static final Logger logger = LoggerFactory.getLogger(PayoutNotifyForCod.class);
	
	private static final String SUCCESS = "SUCCESS";
	private static final String FAILURE = "FAILURE";
	
	@Resource
	private IPayApplyInfoService cod;
	
	/**
	 * 方法说明：<br>
	 * 付款结果通知
	 */
	@RequestMapping(value="/payout")
	public void payoutNotify(String result, HttpServletResponse resp) {
		notifyRs(result, "付款通知");
	}
	
	/**
	 * 方法说明：<br>
	 * 退票结果通知
	 */
	@RequestMapping(value="/bound")
	public void boundNotify(String result, HttpServletResponse resp) {
		notifyRs(result, "退票通知");
	}
	
	private void notifyRs(String xml, String text) {
		logger.info("[COD]接收{}报文:{}", text, xml);
		PayoutNotifyRlt rlt = new PayoutNotifyRlt();
		try {
			rlt.parse(xml);
		} catch (Exception e) {
			logger.error(String.format("解析%s报文异常", text), e);
			return;
		}
		if(rlt.getItem().size() == 0) {
			logger.info(String.format("[COD]处理%s结束[无处理结果]", text));
			return;
		}
		logger.info("[COD]{}转换实体:[{}]", text, rlt.toString());
		List<PayAmtInfoDTO> ls = new ArrayList<PayAmtInfoDTO>();
		for(Iterator<PayoutNotifyItem> it = rlt.getItem().iterator(); it.hasNext(); ) {
			PayAmtInfoDTO dto = convert2Bean(it.next());
			if(null != dto) {
				ls.add(dto);
			}
		}
		if(ls.size() == 0) {
			logger.info(String.format("[COD]处理%s结束[无处理结果]", text));
			return;
		}
		try {
			cod.updatePayApplyInfoByBillNo(ls);
		} catch (Exception e) {
			logger.error(String.format("[COD]处理%s异常", text), e);
		}
		logger.info(String.format("[COD]处理%s结束", text));
	}
	
	/**
	 * 方法说明：<br>
	 * 转换COD对象
	 */
	private PayAmtInfoDTO convert2Bean(PayoutNotifyItem item) throws ServiceException {
		if(StringUtils.isEmpty(item.getTradeOutNo()) || StringUtils.isEmpty(item.getStatus())) {
			return null;
		}
		PayAmtInfoDTO cod = new PayAmtInfoDTO();
		cod.setBillNo(item.getTradeOutNo());
		cod.setPaySErialNum(item.getReqBankSn());
		cod.setPayTime(item.getEndTime());
		cod.setPayApplyOrderNo(item.getPayoutNo());
		if (SUCCESS.equals(item.getStatus())) {
			cod.setPayStatus(PayStatus.SUCCESS);
		} else if (FAILURE.equals(item.getStatus())) {
			cod.setPayStatus(PayStatus.FAIL);
		}
		return cod;
	}
}
