/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.common;

import java.util.Date;

import com.sfpay.acquirer.service.IGenerateInfoService;

/**
 * 
 * 类说明：通用ID生成工具(common unique identity)
 * 
 * 
 * <p>
 * 详细描述：提供3类ID的生成策略<br>
 * 		1，length < 13，即，短ID。以流水号的方式提供新ID，新ID为上次的ID + 1.适用于普通流水号生成。<br>
 * 		2，length > 13 and length < 17，即，中长ID。可以灵活的设置短前缀来做小范围内的流水号生成。比如YYMMDD000000001，ICBCB2E00000001等等<br>
 * 		3，length >= 17，即，长ID。会自动加入时间戳为前缀，余下为随机数。
 * 
 * 
 * @author 321302 
 * @author 349508 韦健
 * 
 *         CreateDate: 2012-3-26
 *         CreateDate: 2012-8-27
 */
public final class CUID {
	
	private static IGenerateInfoService igs = ApplicationContextHelper.getBean(IGenerateInfoService.class);
	
	private CUID() {}

	/**
	 * 方法说明：生成定长长度的ID<br>
	 * 供网银和快捷支付使用
	 * @param length ID的长度
	 * @return 指定长度的ID
	 * @throws Exception 
	 */
	public static String generate(Integer length) throws Exception {
		return igs.getGenerateId(length);
	}
	
	/**
	 * 方法说明：生成定长长度的ID<br>
	 * 供银企直联使用
	 * @param length ID的长度
	 * @return 指定长度的ID
	 * @throws Exception 
	 */
	public static String generateId4B2E(Integer length) throws Exception {
		return igs.getGenerateId4B2E(length);
	}
	
	/**
	 * 获取随机数（供结算中心使用）
	 * 2014-12-03
	 * @param diLength
	 * @return
	 * @throws Exception
	 */
	public static String getRandomCode(Integer length) throws Exception {
		return igs.getRandomCode(length);
	}
	
	/**
	 * 获取序列号，用于结算中心
	 * @return
	 * @throws Exception
	 */
	public static String getSZFSMsgNo() throws Exception{
		return DateUtil.getDateString(new Date(), "yyMMdd")+CUID.getRandomCode(8);
	}
	
}
