package com.sfpay.acquirer.service.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.IInsertAll;
import com.sfpay.acquirer.InsertAllExecutor;
import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.dao.IParamInfoDao;
import com.sfpay.acquirer.dao.IPayoutReconDao;
import com.sfpay.acquirer.domain.ReconPayoutOuterTemp;
import com.sfpay.acquirer.domain.ReconPayoutRlt;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.ReconOutStatus;
import com.sfpay.acquirer.enums.ReconStatus;
import com.sfpay.acquirer.service.IPayoutReconService;
import com.sfpay.acquirer.service.IReconLogService;
import com.sfpay.coreplatform.order.common.enums.tradeStatus;
import com.sfpay.coreplatform.order.service.IOrderQueryService;
import com.sfpay.coreplatform.order.valueobject.dto.PayTrade;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.common.net.ftp.SFTPClient;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.pubcenter.domain.BaseParam;
import com.sfpay.pubcenter.enums.SystemEnums.SystemName;
import com.sfpay.pubcenter.service.IConfigruationCenter;

/**
 * 
 * 
 * 类说明：<br>
 * 银企（付款）对账
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-8-14
 */
@Service
public class PayoutReconService implements IPayoutReconService{
	private static final Logger logger = LoggerFactory.getLogger(PayoutReconService.class);
	private static final boolean isDebug = logger.isDebugEnabled();
	
	@Resource
	private IParamInfoDao pDao;
	
	//本地路径
	private  String localPathStr ;
	//远程文件服务器IP
	private String fileSystemIp;
	//远程文件服务器端口
	private int fileSystemPort;
	//远程文件服务器登录名
	private String fileSystemUser;
	//远程文件服务器口令
	private String fileSystemPass;
	//远程服务器路径
	private String filesystemPathStr;
	
	private String tradeDateStr;//交易日期 yyyymmdd
	
	@Resource
	private IPayoutReconDao dao;
	
	@Resource
	private IReconLogService reconLogService;
	
	@Resource
	private IConfigruationCenter configruationCenter;
	
	@Resource
	private IOrderQueryService orderQueryService;
	
	//平台号
	private Long memberNo = 0L;
	
	/**
	 * 方法说明：初始化参数
	 *
	 */
	private void initParam() throws Exception{
		Map<String, BaseParam> paramMap = configruationCenter.findParamBySystemName(SystemName.ORDER);
		
		//本地路径
		String localPath = pDao.getParameter("PAYOUT_LOCAL_PATH");
		localPathStr = (localPath.endsWith("/")?localPath:localPath+"/")+tradeDateStr+"/";
		//生成本地文件夹
		File localFile = new File(localPathStr);
		if(!localFile.exists()){
			try{
				localFile.mkdirs();
			}catch(SecurityException e) {
				throw new IOException("[ It doesn't own the create directory rights. ]", e);
			}
		}
		//远程文件服务器IP
		fileSystemIp = paramMap.get("fileSysIp").getParamValue();
		//远程文件服务器端口
		fileSystemPort = Integer.parseInt( paramMap.get("fileSysPort").getParamValue());
		//远程文件服务器登录名
		fileSystemUser = paramMap.get("fileSysUser").getParamValue();
		//远程文件服务器口令
		fileSystemPass = paramMap.get("fileSysPass").getParamValue();
		//远程服务器路径
		String fileSystemPath = paramMap.get("e2oOrdRemotePath").getParamValue();
		filesystemPathStr = (fileSystemPath.endsWith("/")?fileSystemPath:fileSystemPath+"/")+tradeDateStr+"/";
		//平台号
		memberNo = Long.valueOf(Property.getProperty("PLATFORM_MEMBER_NO"));
	}

	@Override
	public void doRecon(Date tradeDate) throws ServiceException {
		String logStr = null;
		logger.info("开始执行,银企付款对账.");
		try{
			if(tradeDate == null){
				logger.warn("交易日期不能为空");
				throw new ServiceException("交易日期不为能空");
			}
			tradeDateStr = DateUtil.getDateString(tradeDate, DateUtil.DATA_FORMAT_PATTERN_2);
			
			//记录开始日志
			logStr = "银企付款对账["+tradeDateStr+"],开始执行.";
			logger.info(logStr);
			reconLogService.insertReconLog("INFO", logStr);
			
			logger.info("第一步：银企付款对账[{}],检查是否已调账",tradeDateStr);
			try {
				Long cnt = dao.totalReconPayoutRltCount(tradeDate);
				if(cnt != null && cnt > 0L){
					logStr = "银企付款对账["+tradeDateStr+"],已调账,不执行对账";
					logger.warn(logStr);
					reconLogService.insertReconLog("WARN", logStr);
					return;
				}
			} catch (Exception ex) {
				logStr = "银企付款对账["+tradeDateStr+"],检查是否已调账异常.";
				logger.error(logStr,ex);
				reconLogService.insertReconLog("ERROR", logStr);
				throw new ServiceException(logStr+ex);
			}
			
			logger.info("第二步：银企付款对账[{}],初始化参数.",tradeDateStr);
			try {
				initParam();
			} catch (Exception ex) {
				logStr = "银企付款对账["+tradeDateStr+"],初始化参数异常.";
				logger.error(logStr,ex);
				reconLogService.insertReconLog("ERROR", logStr);
				throw new ServiceException(logStr+ex);
			}
			
			logger.info("第三步：银企付款对账[{}],下载文件.",tradeDateStr);
			try {
				downloadFile();
			} catch (Exception ex) {
				logStr = "银企付款对账["+tradeDateStr+"],下载文件异常.";
				logger.error(logStr,ex);
				reconLogService.insertReconLog("ERROR", logStr);
				throw new ServiceException(logStr+ex);
			}
			
			logger.info("第四步：银企付款对账[{}],导入外部临时表.",tradeDateStr);
			try{
				importFileData();
			}catch(Exception ex){
				logStr = "银企付款对账["+tradeDateStr+"],导入外部临时表异常.";
				logger.error(logStr,ex);
				reconLogService.insertReconLog("ERROR", logStr);
				throw new ServiceException(logStr+ex);
			}
			
			logger.info("第五步：银企付款对账[{}],调用对账存储过程",tradeDateStr);
			try{
				dao.saveRecon(tradeDate);
			}catch(Exception ex){
				logStr = "银企付款对账["+tradeDateStr+"],调用对账存储过程异常.";
				logger.error(logStr,ex);
				reconLogService.insertReconLog("ERROR", logStr);
				throw new ServiceException(logStr+ex);
			}
			
			logger.info("第六步：银企付款对账[{}],处理丢单记录",tradeDateStr);
			try{
				proLose(new Date());
			}catch(Exception ex){
				logStr = "银企付款对账["+tradeDateStr+"],处理丢单记录异常(不影响对账结果).";
				logger.error(logStr,ex);
				reconLogService.insertReconLog("ERROR", logStr);
			}
			
			logger.info("第七步：银企付款对账[{}],统计结果",tradeDateStr);
			try {
				String totalResult = dao.totalReconPayoutRlt(new Date());
				reconLogService.insertReconLog("INFO", "银企付款对账["+tradeDateStr+"]对账完成:"+totalResult);
			} catch (Exception ex) {
				logStr = "银企付款对账["+tradeDateStr+"],统计结果(不影响对账结果).";
				logger.error(logStr,ex);
				reconLogService.insertReconLog("ERROR", logStr);
				return;
			}
			
		}finally{
			//记录结束日志
			logStr = "银企付款对账["+tradeDateStr+"],执行结束.";
			logger.info(logStr);
			reconLogService.insertReconLog("INFO", logStr);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 处理丢单记录
	 *
	 * @param reconDate
	 * @throws ServiceException
	 */
	private void proLose(Date reconDate) throws ServiceException {
		List<ReconPayoutRlt> loseList = null;
		
		//查询丢单记录
		try {
			loseList = dao.selectLose(reconDate);
		} catch (Exception ex) {
			throw new ServiceException("查询丢单记录异常",ex);
		}
		
		if(loseList == null || loseList.size() == 0){
			logger.info("无丢单记录");
			return;
		}
		
		//查询订单系统
		for(ReconPayoutRlt rlt : loseList){
			List<PayTrade> payTradeList = orderQueryService.queryPayTrade(rlt.getExchangeNo(), memberNo);
			
			PayTrade payTrade = null;
			if(payTradeList == null || payTradeList.size() == 0){
				if(isDebug){
					logger.debug("无交互流水号[{}]记录",rlt.getExchangeNo());
				}
				continue;
			}
			payTrade = payTradeList.get(0);
			logger.info(String.format("交互流水号[%s],查询订单交易结果:[%s,%s]"
					,rlt.getExchangeNo(),payTrade.getOutTradeNo(),payTrade.getOrderStatus()));
			ReconStatus status = null;
			if(tradeStatus.SUCCESS.equals(payTrade.getOrderStatus())){
				status = ReconStatus.TIMEEXP;
			}
			try {
				int cnt = dao.updateReconPayoutRltState(rlt.getId(),status,ReconStatus.LOSE);
				if(isDebug){
					logger.debug("更新交互流水号[{}],时间差异性条数:[{}]",rlt.getExchangeNo(),cnt);
				}
			} catch (Exception e) {
				logger.error("对账记录[交互流水号:"+rlt.getExchangeNo()+"],更新丢单为时间性差异异常",e);
			}
		}
		
	}
	
	/**
	 * 方法说明：<br>
	 * 导入对账文件数据
	 *
	 * @throws ServiceException
	 */
	private void importFileData() throws ServiceException {
		File file = new File(localPathStr);
		String[] fileNames = file.list();
		if(fileNames == null || fileNames.length == 0){
			logger.warn("无交易文件");
			return;
		}
		
		for(String name : fileNames){
			String fullName = localPathStr + name;
			List<ReconPayoutOuterTemp> temp = readFile(fullName);
			
			if(temp == null || temp.size() == 0){
				logger.warn("[{}]无交易数据!",fullName);
				continue;
			}
			
			//导入数据库
			if(isDebug){
				logger.debug("[{}]交易总数:[{}]",fullName,temp.size());
			}
			try {
				InsertAllExecutor.insert(temp, new IInsertAll<ReconPayoutOuterTemp>() {
					public void execute(List<ReconPayoutOuterTemp> sbuLs) throws Exception {
						dao.addReconOutList(sbuLs);//导入数据库
					}
				});
			} catch (Exception e) {
				logger.error("导入外部数据异常",e);
				throw new ServiceException("导入外部数据异常:"+e);
			}
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 下载文件
	 *
	 * @param localFileFullName
	 * @throws Exception
	 */
	private void downloadFile() throws Exception{
		logger.info(String.format("下载信息:远程IP[%s],远程断口[%s],远程目录[%s],本地目录[%s]"
				,fileSystemIp,fileSystemPort,filesystemPathStr,localPathStr));
		SFTPClient client = new SFTPClient(fileSystemIp, fileSystemPort, fileSystemUser, fileSystemPass);
		client.downloadDirectory(filesystemPathStr, localPathStr, true);
	}
	
	/**
	 * 方法说明：<br>
	 * 读取文件
	 *
	 * @param fullName
	 * @throws ServiceException
	 */
	private List<ReconPayoutOuterTemp> readFile(String fullName) throws ServiceException{
		FileReader fr =  null;
		 BufferedReader br = null;
		 List<ReconPayoutOuterTemp> tempList = new ArrayList<ReconPayoutOuterTemp>();
		 try{
				fr =  new FileReader(fullName);
				br=new BufferedReader(fr);
				String content = null;
				
				while((content=br.readLine())!=null){
					if(!"".equals(content = content.trim())){
						ReconPayoutOuterTemp temp = conver(content);
						tempList.add(temp);
					}
				}
			}catch(Exception ex){
				logger.error("对账文件["+fullName+"]读取异常.",ex);
				throw new ServiceException("对账文件["+fullName+"]读取异常."+ex);
			}finally{
				try{
					if(br != null){
						br.close();
					}
					if(fr != null){
						fr.close();
					}
				}catch(Exception ex){
					logger.error("",ex);
				}
			}
		 return tempList;
	}

	/**
	 * 方法说明：<br>
	 * 转换对账文件内容
	 *
	 * @param content
	 * @return
	 * @throws ServiceException
	 */
	private ReconPayoutOuterTemp conver(String content) throws ServiceException{
		String[] contents = content.split("\\|");
		if(5 != contents.length){
			throw new ServiceException("文件内容格式有误");
		}
		
		ReconPayoutOuterTemp temp = new ReconPayoutOuterTemp();
		temp.setOutCcy(CurrencyType.valueOf(contents[3]));
		temp.setOutAmt(Long.valueOf(contents[2]));
		temp.setOutExchangeNo(contents[0]);
		temp.setOutStatus(ReconOutStatus.SUCCESS);
		temp.setOutTradeDate(DateUtil.getDateFormatStr(contents[4], DateUtil.DATA_FORMAT_PATTERN));
		
		return temp;
	}
}
