package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sfpay.acquirer.dao.IParamInfoDao;
import com.sfpay.acquirer.domain.ParamInfo;
import com.sfpay.acquirer.service.IParamInfoService;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
@Service("paramInfoService")
@HessianExporter
public class ParamInfoServiceImpl implements IParamInfoService{

	@Resource
	private IParamInfoDao paramInfoDao;
	/**
	 * 方法说明：<br>
	 * 根据指定的批量健名查找对应的参数配置信息
	 * 
	 * @param keys 参数名列表
	 * @return
	 */
	@Override
	public List<ParamInfo> findByKeys(List<String> keys)throws Exception {
		return paramInfoDao.findByKeys(keys);
	}

}
