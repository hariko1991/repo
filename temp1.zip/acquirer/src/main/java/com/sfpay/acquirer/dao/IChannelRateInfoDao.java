package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import com.sfpay.acquirer.domain.ChannelRateInfo;
import com.sfpay.acquirer.domain.ChannelRateInfoQueryParam;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.ChargeType;




/**
 * 
 * 类说明：
 *  支付渠道费用设置以及维护基础实现类
 * 
 * <p/>
 * 详细描述：
 * 支付渠道费用信息      
 * 
 * @author 349508 韦健
 *   
 * CreateDate: 2012-8-10
 */  
@Deprecated
public interface IChannelRateInfoDao {

	/**
	 * 方法说明：
	 * 分页查询支付渠道费用信息       总条数
	 * @param map 查询条件
	 * @return
	 */
	public long queryChannelRateInfoPageCount(@Param("param") ChannelRateInfoQueryParam param);
	
	/**	 
	 * 方法说明：
	 * 分页查询支付渠道费用信息       当页数据
	 * @param map 查询条件
	 * @return
	 */
	public List<ChannelRateInfo> queryChannelInfoPageList(@Param("param") ChannelRateInfoQueryParam param, @Param("start") int start, @Param("end") int end);
	
    /**
     * 根据支付的金额，银行码查询出对应的手续费率，打折率
     * @param payCost
     * @param bankCode
     * @return
     */
	public ChannelRateInfo queryChannelRateInfo(@Param("payCost") Long payCost,@Param("bankCode") BankCode bankCode,@Param("channelCode") ChannelCode channelCode,@Param("chargeType") ChargeType chargeType);       
	/**
	 * 方法说明：<br>
	 * 修改支付渠道费用信息
	 *
	 * @param param 更新参数
	 */
	public void updateChannelRateInfo(@Param("param") ChannelRateInfoQueryParam param);
	
	/**
	 * 方法说明：<br>
	 * 添加支付渠道费用信息
	 *
	 * @param param 支付渠道费用信息参数
	 */
	public void addChannelRateInfo(@Param("param") ChannelRateInfoQueryParam param);
	
	/**
	 *删除渠道信息 
	 * @param id
	 */
	public void deleteChannelRateInfo(@Param("id") long id);
	
	
	
}
