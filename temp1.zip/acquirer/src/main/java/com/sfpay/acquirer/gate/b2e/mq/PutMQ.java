package com.sfpay.acquirer.gate.b2e.mq;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;

import com.sfpay.acquirer.common.ApplicationContextHelper;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 发送至MQ类
 * 
 * @author sfhq534 卢隆洲
 *	CreateDate 2015-06-01
 */
public class PutMQ {

	private static Logger logger = LoggerFactory.getLogger(PutMQ.class);
	
	private final Map<String, JmsTemplate> sendMQMap;
	
	private PutMQ() {
		sendMQMap = new HashMap<String, JmsTemplate>(32);
		
		// 工商银行交易对公指令
		sendMQMap.put(BankCode.ICBC.name() + TradeCodeB2E.BATCH_TRANSFER.name(), (JmsTemplate)ApplicationContextHelper.getBean("ICBCTransPublicSender"));
		// 工商银行交易对私指令
		sendMQMap.put(BankCode.ICBC.name() + TradeCodeB2E.BATCH_PAYOFF.name(), (JmsTemplate)ApplicationContextHelper.getBean("ICBCTransPrivateSender"));
		// 工商银行交易代理指令
		sendMQMap.put(BankCode.ICBC.name() + TradeCodeB2E.BATCH_AGENT_TRANSFER.name(), (JmsTemplate)ApplicationContextHelper.getBean("ICBCTransProxySender"));
		// 工商银行交易查询对公指令
		sendMQMap.put(BankCode.ICBC.name() + TradeCodeB2E.QUERY_BATCH_TRANSFER.name(), (JmsTemplate)ApplicationContextHelper.getBean("ICBCQueryPublicSender"));
		// 工商银行交易查询对私指令
		sendMQMap.put(BankCode.ICBC.name() + TradeCodeB2E.QUERY_BATCH_PAYOFF.name(), (JmsTemplate)ApplicationContextHelper.getBean("ICBCQueryPrivateSender"));
		// 工商银行交易查询代理指令
		sendMQMap.put(BankCode.ICBC.name() + TradeCodeB2E.QUERY_BATCH_AGENT_TRANSFER.name(), (JmsTemplate)ApplicationContextHelper.getBean("ICBCQueryProxySender"));
		
		// 结算中心交易批量指令
		sendMQMap.put(BankCode.SZFS.name() + TradeCodeB2E.BATCH_TRANSFER.name(), (JmsTemplate)ApplicationContextHelper.getBean("SZFSTransBatchSender"));
		sendMQMap.put(BankCode.SZFS.name() + TradeCodeB2E.BATCH_PAYOFF.name(), (JmsTemplate)ApplicationContextHelper.getBean("SZFSTransBatchSender"));
		sendMQMap.put(BankCode.SZFS.name() + TradeCodeB2E.BATCH_AGENT_TRANSFER.name(), (JmsTemplate)ApplicationContextHelper.getBean("SZFSTransBatchSender"));
		// 结算中心交易批量指令
		sendMQMap.put(BankCode.SZFS.name() + TradeCodeB2E.SZFS_SINGLEPAY.name(), (JmsTemplate)ApplicationContextHelper.getBean("SZFSTransSingleSender"));
		// 结算中心交易查询批量指令
		sendMQMap.put(BankCode.SZFS.name() + TradeCodeB2E.QUERY_BATCH_TRANSFER.name(), (JmsTemplate)ApplicationContextHelper.getBean("SZFSQueryBatchSender"));
		sendMQMap.put(BankCode.SZFS.name() + TradeCodeB2E.QUERY_BATCH_PAYOFF.name(), (JmsTemplate)ApplicationContextHelper.getBean("SZFSQueryBatchSender"));
		sendMQMap.put(BankCode.SZFS.name() + TradeCodeB2E.QUERY_BATCH_AGENT_TRANSFER.name(), (JmsTemplate)ApplicationContextHelper.getBean("SZFSQueryBatchSender"));
		// 结算中心交易查询单笔指令
		sendMQMap.put(BankCode.SZFS.name() + TradeCodeB2E.QUERY_SZFS_SINGLEPAY.name(), (JmsTemplate)ApplicationContextHelper.getBean("SZFSQuerySingleSender"));
		
		//招行代发工资交易批量指令 sfhq814  add 2015-7-10
		sendMQMap.put(BankCode.CMB.name() + TradeCodeB2E.BATCH_PAYOFF.name(), (JmsTemplate)ApplicationContextHelper.getBean("CMBAgentRequestSender"));
		//招行查询明细批量指令 sfhq814 add 2015-7-10
		sendMQMap.put(BankCode.CMB.name() + TradeCodeB2E.QUERY_BATCH_PAYOFF.name(), (JmsTemplate)ApplicationContextHelper.getBean("CMBGetagentDetailSender"));
		
		sendMQMap.put(BankCode.CMB.name() + TradeCodeB2E.BATCH_TRANSFER.name(), (JmsTemplate)ApplicationContextHelper.getBean("CMBTransPublicSender"));
		
		sendMQMap.put(BankCode.CMB.name() + TradeCodeB2E.QUERY_BATCH_TRANSFER.name(), (JmsTemplate)ApplicationContextHelper.getBean("CMBQueryPublicSender"));
		
		
	}
	
	private static PutMQ putMQ;
	
	public static PutMQ getInstance() {
		if (putMQ == null) {
			synchronized(PutMQ.class) {
				if (putMQ == null) {
					putMQ = new PutMQ();
				}
			}
		}
		
		return putMQ;
	}
	
	
	public boolean putMQ(BankCode bankCode, TradeCodeB2E tradeCodeB2E,
			BeanBase payoutReq) throws ServiceException {
		// 检查参数
		this.check(payoutReq);

		try {
			JmsTemplate sender = sendMQMap.get(bankCode.name() + tradeCodeB2E.name());
			sender.convertAndSend(payoutReq);
		} catch (Exception e) {
			logger.error("发送MQ异常", e);
			throw new ServiceException(InfoCode.FAILURE, "发送MQ异常",e);
		}
		logger.info("存放结果, seqNo = {}.", payoutReq.getSeqNo());
		return true;
	}
	
	private void check(BeanBase payoutReq) throws ServiceException {
		 if(payoutReq == null){
			 throw new ServiceException(InfoCode.FAILURE, "请求MQ的信息不能为空");
		 }
		
	}
	
}
