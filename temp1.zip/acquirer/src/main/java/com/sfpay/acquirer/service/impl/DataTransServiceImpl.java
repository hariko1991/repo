/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.dao.IDataTransDao;
import com.sfpay.acquirer.domain.DataTrans;
import com.sfpay.acquirer.enums.CmdStatus;
import com.sfpay.acquirer.service.IDataTransService;

/**
 * 类说明：<br>
 * 与银行交互的数据报文接口实现<br>
 * 采用多线程方式保存
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-8-28
 */
@Service("dataTransService")
public class DataTransServiceImpl implements IDataTransService {
	private static final Logger logger = LoggerFactory.getLogger(DataTransServiceImpl.class);
	
	private ExecutorService executor = Executors.newCachedThreadPool();
	
	@Resource
	private IDataTransDao dao;

	@Override
	public void addDataTrans(DataTrans dt) {
		executor.execute(new AsynTrans(dt, true));
	}

	@Override
	public void updateDataTrans(DataTrans dt) {
		executor.execute(new AsynTrans(dt, false));
	}
	
	/**
	 * 类说明：<br>
	 * 异步交互执行器
	 * <p>
	 * 详细描述：<br>
	 * </p>
	 * @author 329202 符瑜鑫(Ricky Fu)
	 * CreateDate: 2013-8-28
	 */
	private class AsynTrans implements Runnable {
		private DataTrans dt;
		private boolean isAdd;
		public AsynTrans(DataTrans dt, boolean isNew) {
			this.dt = dt;
			this.isAdd = isNew;
		}
		@Override
		public void run() {
			try {
				if(isAdd) {
					logger.info("插入数据交互表[reqBankSn: {}]...", dt.getSerieNo());
					dt.setCmdStatus(CmdStatus.INIT);
					dao.addDataTrans(dt);
				} else {
					logger.info("更新数据交互表[reqBankSn: {}]...", dt.getSerieNo());
					dao.updateDataTrans(dt);
				}
			} catch (Exception e) {//保存不成功,不影响业务.不可抛异常
				logger.error(String.format("%s数据交互表[serieNo: %s]异常", isAdd ? "插入" : "更新", dt.getSerieNo()), e);
			}
		}
	}

}
