package com.sfpay.acquirer.gate.b2e;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.common.ApplicationContextHelper;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IDualDao;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.DataTrans;
import com.sfpay.acquirer.domain.PayoutResult;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.CmdStatus;
import com.sfpay.acquirer.enums.CommonTradeType;
import com.sfpay.acquirer.enums.PackageFlag;
import com.sfpay.acquirer.enums.PayoutSendStatus;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.acquirer.gate.b2e.mq.PutMQ;
import com.sfpay.acquirer.service.IDataTransService;

/**
 * 类说明：<br>
 * 指令基类
 * 
 * <p>
 * 详细描述：<br>
 * （猜测）原设计应该是命令模式。通过将域数据与相应的动作封装在一起，从而方便调用。
 * 然而有如下问题：
 * 1、依赖于外部资源，资源注入不方便； 
 * 2、其中有些方法如parse存在较多的重复； 
 * 3、在服务器端，此类的实例被创建较多，尤其的很多时候创建一个无实际数据的简单对象，只是为了调用parse方法。在服务器较大访问量时易造成频繁GC。
 * 4、后续逐步想办法拆离其中的服务方法与bean实例数据，
 * @see IDataTransService
 * @see IDualDao
 * TODO 重新设计BaseCommand、PayoutResult、BaseBean、BankProperties等域对象模型 .
 * TODO 以无状态服务+有状态数据的方式设计； 
 * </p>
 * 
 * @author 361424 詹锡宁
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-5-6
 */
public abstract class BaseCommand {
	
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	
	protected final boolean isDebug = logger.isDebugEnabled();
	
	private IDataTransService dataTransService = ApplicationContextHelper.getBean(IDataTransService.class);
	
	private IDualDao dualDao = ApplicationContextHelper.getBean(IDualDao.class);
	
	protected TradeCodeB2E tradeCodeB2E;
	
	protected BaseCommand(TradeCodeB2E tradeCodeB2E) {
		this.tradeCodeB2E = tradeCodeB2E;
	}
	
	/**
	 * 方法说明：<br>
	 * 组装银企直联请求报文.<br>
	 * <span style="color:red;">须知:组装报文时需要的具体的参数,由子类通过<code>setXX()</code>/<code>getXX()</code>方式获取</span>
	 * 
	 * @param property 银行渠道基础参数.[目前通过直接读取DB方式,以后可改进为使用分布式缓存模式.Ricky Fu]
	 * @return
	 * @throws Exception
	 */
	protected abstract BeanBase assemble(BankProperty property) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 解析银行响应报文并封装成具体的响应Bean.
	 * 
	 * @param respMsg 银行回传的报文信息.格式为Xml.
	 * @return 
	 * @return
	 * @throws Exception
	 */
	protected abstract <T extends PayoutResult> T parseMsg(BeanBase respBean) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 发送
	 *
	 * @param url
	 * @param reqMsg
	 * @return
	 * @throws Exception
	 */
	protected PayoutSendStatus sendPost(BatchInfo bi, BankCode bankCode, BeanBase payoutReq) {
		try {// 发送MQ
			boolean flag = PutMQ.getInstance().putMQ(bankCode, tradeCodeB2E, payoutReq);
			return flag ? PayoutSendStatus.SUCCESS : PayoutSendStatus.FAILURE;
		} catch(Exception e) {
			logger.error(String.format("批次[批次号:%s]发送MQ异常", bi.getBatchCode()), e);
		}
		return PayoutSendStatus.UNKOWN;
	}
	
	public BeanBase assembleXml(BankProperty property) throws Exception {
		return assemble(property);
	}
	/**
	 * TODO 移动到QueryPayout
	 * @param bankCode
	 * @param property
	 * @param bi
	 * @return
	 * @throws Exception
	 */
	public PayoutSendStatus send(BankCode bankCode, BankProperty property,BatchInfo bi) throws Exception {
		return send(null, bankCode, property,bi);
	}
	
	/**
	 * TODO 移动到BasePayout
	 * @param reqBankSn
	 * @param bankCode
	 * @param property
	 * @param bi
	 * @return
	 * @throws Exception
	 */
	public PayoutSendStatus send(String reqBankSn, BankCode bankCode, BankProperty property, BatchInfo bi) throws Exception {
		logger.info("组装并发送请求报文[{}](查询类reqBankSn为空,付款类不为空)", reqBankSn);
		BeanBase bean = assemble(property);
		String reqMsg = bean.toReqMsg();
		if(StringUtils.isEmpty(reqMsg)) {
			logger.warn("[{}]请求报文不能为空, 结束", reqBankSn);
			return null;
		}
		logger.info("发送报文:\n{}", bean.toString());
		//TODO 确保保存到此表中的数据是没有被实际使用的。后续重构时，准备删除此表中的数据。
		savePre(reqBankSn, reqMsg, bankCode);//发送前保存数据交互表
		PayoutSendStatus status = sendPost(bi, bankCode, bean);
		logger.info("组装银企直联请求报文[{}]结束.", reqBankSn);
		return status;
	}
	
	
	@SuppressWarnings("unchecked")
	public <T extends PayoutResult> T parse(BeanBase respBean) throws Exception {
		PayoutResult resp = null;
		String respMsg = respBean.toString();//TODO ....
		logger.info("响应报文明文: {}", respMsg);
		try {
			resp = parseMsg(respBean);
			logger.info("转换的付款结果: {}", (resp == null ? "null" : resp.toString()));
		} catch (Exception e) {
			logger.error("报文解析异常", e);
			savePost(respBean.getBankCode(), respMsg, false, resp);//发送后保存数据交互表[失败]
			return null;
		}
		savePost(respBean.getBankCode(), respMsg, true, resp);//发送后保存数据交互表[成功]
		return (T)resp;
	}
	
	/**
	 * 方法说明：<br>
	 * 发送前保存数据交互表,用于备查.<br>
	 * <span style="color:red;">注意:</span><code>batchNo</code>为<code>Null</code>或空串时,不作保存
	 * 
	 * @param batchNo 批次号
	 * @param reqMsg 请求报文
	 * @throws Exception
	 */
	private void savePre(String reqBankSn, String reqMsg, BankCode bankCode) {
		//异步保存数据交互表.By 优化单[201308029], Ricky Fu, 20130826
		if(StringUtils.isEmpty(reqBankSn)) {
			return;
		}
		DataTrans dt = new DataTrans();
		dt.setBankCode(bankCode);
		dt.setChannelCode(ChannelCode.B2E);
		dt.setDataTransType(CommonTradeType.PAY);
		dt.setSerieNo(reqBankSn);//REQ_BANK_SN,填入批次号
		dt.setPackageFlag(PackageFlag.BATCH);
		dt.setRequestMsg(reqMsg);//SEND_MSG,向银行发送的请求报文信息
		dt.setBeginTime(dualDao.getDBDatetime());
		dataTransService.addDataTrans(dt);
	}
	
	/**
	 * 方法说明：<br>
	 * 发送后保存数据交互表,用于备查.<br>
	 * <span style="color:red;">注意:</span><code>batchNo</code>为<code>Null</code>或空串时,不作保存
	 * 
	 * @param reqBankSn 批次号
	 * @param respMsg 响应报文
	 * @param success 是否成功
	 * @param resp 由响应报文解析得到的响应实体Bean
	 * @throws Exception
	 */
	private void savePost(BankCode bankCode, String respMsg, boolean success, PayoutResult respBean) {
		//异步保存数据交互表.By 优化单[201308029], Ricky Fu, 20130826
		if(respBean == null) {
			return;
		}
		String reqBankSn = respBean.getReqBankSn();
		if(StringUtils.isEmpty(reqBankSn)) {
			return;
		}
		DataTrans dt = new DataTrans();
		dt.setBankCode(bankCode);
		dt.setChannelCode(ChannelCode.B2E);
		dt.setDataTransType(CommonTradeType.PAY);
		dt.setSerieNo(reqBankSn);//REQ_BANK_SN
		dt.setReceiveMsg(respMsg);//银行回传报文
		dt.setEndTime(dualDao.getDBDatetime());
		if (success) {
			dt.setCmdStatus(CmdStatus.SUCCESS);
			dt.setBankRetCode(respBean.getRtnBankCode());
			dt.setBankRetMsg(respBean.getRtnBankMsg());
		} else {
			dt.setCmdStatus(CmdStatus.FAILURE);
		}
		dataTransService.updateDataTrans(dt);
	}
	
}
