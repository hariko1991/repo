package com.sfpay.acquirer.web;

import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.service.IReconGatewayFileService;

/**
 * 类说明：<br>
 * 支付网关对账　后门
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-7-30
 */
@Deprecated
@Controller
@RequestMapping(value="/gateway/recon")
public class GatewayFileRecon {
	private Logger logger = LoggerFactory.getLogger(GatewayFileRecon.class);

	@Resource
	private IReconGatewayFileService rgService;
	
	@RequestMapping(value = {"", "/"})
	public String index(HttpServletRequest request, HttpServletResponse response) {
		return "/gateway_recon";
	}
	
	@RequestMapping(value = "/exec")
	public String acqRecon(HttpServletRequest request, HttpServletResponse response) {
		String clearDateStr = request.getParameter("clearDate");
		Date clearDate = DateUtil.getDateFormatStr(clearDateStr, "yyyy-MM-dd");
		try {
			rgService.doGateReconFile(clearDate, true);
			request.setAttribute("msg", "支付网关对账完成,请检查.");
		} catch (Exception e) {
			logger.error("", e);
			request.setAttribute("msg", "支付网关对账异常["+e.getMessage()+"]");
		}
		return "/gateway_recon";
	}
}
