/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.AcquirerHelper;
import com.sfpay.acquirer.common.HttpHelper;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.ICollectInfoDao;
import com.sfpay.acquirer.dao.IDualDao;
import com.sfpay.acquirer.dao.IParamInfoDao;
import com.sfpay.acquirer.dao.IReconDao;
import com.sfpay.acquirer.domain.Account;
import com.sfpay.acquirer.domain.CollectInfo;
import com.sfpay.acquirer.domain.ReconChangeRedoReq;
import com.sfpay.acquirer.domain.ReconChangeReq;
import com.sfpay.acquirer.domain.ReconChangeResp;
import com.sfpay.acquirer.domain.ReconChangeResupplyReq;
import com.sfpay.acquirer.domain.ReconChangeRs;
import com.sfpay.acquirer.domain.ReconChangeUpdateInfo;
import com.sfpay.acquirer.domain.ReconChangeXml;
import com.sfpay.acquirer.domain.ReconCollectRlt;
import com.sfpay.acquirer.enums.AppendBusType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.CollectStatus;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.ReSupplyFlag;
import com.sfpay.acquirer.enums.ReconChangeFlag;
import com.sfpay.acquirer.enums.ReconChangeStatus;
import com.sfpay.acquirer.enums.ReconChangeType;
import com.sfpay.acquirer.enums.SystemSource;
import com.sfpay.acquirer.service.IReconChangeService;
import com.sfpay.coreplatform.order.service.IOrderUpdateService;
import com.sfpay.coreplatform.order.valueobject.dto.UpdateCollectNo;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：
 * 调账接口实现.各URL返回结果报文定义见{@link ReconChangeXml} 
 * 
 * <p/>
 * 详细描述：
 *   
 * @author 312932 何国兴
 * @author 329202 符瑜鑫(Ricky Fu)
 *   
 * CreateDate: 2012-8-17
 */
@Deprecated
@Service("reconChangeService")
@HessianExporter
public class ReconChangeServiceImpl implements IReconChangeService {
	
	private static final Logger logger = LoggerFactory.getLogger(ReconChangeServiceImpl.class);
	private static final boolean isDebug = logger.isDebugEnabled();
	
	private static final String SUCCESS = "SUCCESS";

	@Resource
	private IReconDao reconDao;
	
	@Resource
	private ICollectInfoDao collectInfoDao;
	
	@Resource
	private IDualDao dualDao;
	
	@Resource
	private IParamInfoDao paramDao;
	
	@Resource
	private IOrderUpdateService orderUpdate;
	
	@Override
	public ReconChangeResp doResupply(ReconChangeResupplyReq req) throws ServiceException {
		//参数检查
		if(null == req) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "请求参数不能为空");
		}
		if(isDebug){
			logger.debug("补单请求参数:{}", req.toString());
		}
		if(null == req.getReconRltId()) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "参数[reconRltId]不能为空");
		}
		if(null == req.getFlag()) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "补单标识不能为空");
		}
		
		//根据id号查询当前的收单结果表记录
		ReconCollectRlt reconRlt = queryReconRltById(req.getReconRltId());
		Long resupplyAmt = reconRlt.getOutAmt();//补单金额 (外部金额)
		
		StringBuffer meta = new StringBuffer(100);
		if(ReSupplyFlag.BYSN == req.getFlag()) {
			if(!req.getBusinessSn().equals(reconRlt.getBusinessSn())) {
				throw new ServiceException(InfoCode.PARAM_INVALID, String.format("输入的业务流水号[%s]与对账结果记录不一致", req.getBusinessSn()));
			}
			meta.append("&businessSn=").append(reconRlt.getBusinessSn());
		} else if(ReSupplyFlag.BYCARD == req.getFlag()) {
			meta.append("&cardNo=").append(req.getCardNo());
		}
		meta.append("&operatorNo=").append(req.getOperatorNo());
		meta.append("&orgId=").append(req.getOrgId());
		meta.append("&requestIp=").append(req.getRequestIp());
		meta.append("&outAmt=").append(reconRlt.getOutAmt());
		meta.append("&bankCode=").append(null == reconRlt.getBankCode() ? "" : reconRlt.getBankCode().name());
		ReconChangeXml resp = doBizReconChange(reconRlt, "URL_RECON_RESUPPLY", meta);
		ReconChangeRs rs = resp.getResupplyRs();
		
		CollectInfo ci = null;
		if(null != rs) {
			ci = addCollectInfo(req, reconRlt, rs, resupplyAmt, AppendBusType.RESUPPLY);//创建收单信息表
			updateOrderRela(ci, null);//调用订单系统更新收单编号
		}
		updateReconChange(req, resp, ReconChangeType.RESUPPLY);//更新对账结果表为的调账类型为补单
		
		//返回
		ReconChangeResp ret = new ReconChangeResp();
		if(null == rs) {
			ret.setRtnMsg(resp.getFailReason());
			logger.info("[{}]调账[补单]结束[失败].", req.getReconRltId());
			return ret;
		}
		ret.setRtnMsg(SUCCESS);
		
		//前端Controller不使用,先屏蔽.2013-12-28下一版本删除.Fuyx
//		ReconChangeRltInfo ri = new ReconChangeRltInfo();//补单信息
//		ri.setCollectNo(ci.getCollectNo());
//		ri.setReconChangeAmt(resupplyAmt);
//		ri.setBusinessSn(rs.getBusinessNo());
//		ri.setPayNo(rs.getPayNo());
//		ri.setTradeNo(rs.getTradeNo());
//		ret.setResupplyInfo(ri);
		logger.info("[{}]调账[补单]结束[成功].", req.getReconRltId());
		return ret;
	}

	@Override
	public ReconChangeResp doReverse(ReconChangeReq req) throws ServiceException {
		//参数检查
		if(null == req) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "参数不能为空");
		}
		if (isDebug) {
			logger.debug("红冲参数: {}", req.toString());
		}
		if (null == req.getReconRltId()) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "参数[reconRltId]不能为空");
		}
		
		//根据id号查询当前的收单结果表记录
		ReconCollectRlt reconRlt = queryReconRltById(req.getReconRltId());
		
		StringBuffer meta = new StringBuffer(100);
		meta.append("&businessSn=").append(reconRlt.getBusinessSn());
		meta.append("&operatorNo=").append(req.getOperatorNo());
		meta.append("&orgId=").append(req.getOrgId());
		meta.append("&requestIp=").append(req.getRequestIp());
		ReconChangeXml resp = doBizReconChange(reconRlt, "URL_RECON_REVERSE", meta);
		ReconChangeRs rs = resp.getReverseRs();
		Long reverseAmt = 0-reconRlt.getAmt();//红冲金额
		CollectInfo ci = null;
		if(null != rs) {
			ci = addCollectInfo(req, reconRlt, rs, reverseAmt, AppendBusType.REVERSE);////创建收单信息表
			updateOrderRela(ci, null);//调用订单系统更新收单编号
		}
		
		updateReconChange(req, resp, ReconChangeType.REVERSE);//更新对账结果表为的调账类型为红冲
		
		//返回
		ReconChangeResp ret = new ReconChangeResp();
		if(null == rs) {
			ret.setRtnMsg(resp.getFailReason());
			logger.info("[{}]调账[红冲]结束[失败].", req.getReconRltId());
			return ret;
		}
		ret.setRtnMsg(SUCCESS);
		
		//前端Controller不使用,先屏蔽.2013-12-28下一版本删除.Fuyx
//		ReconChangeRltInfo ri = new ReconChangeRltInfo();
//		ri.setCollectNo(ci.getCollectNo());
//		ri.setBusinessSn(rs.getBusinessNo());
//		ri.setPayNo(rs.getPayNo());
//		ri.setTradeNo(rs.getTradeNo());
//		ri.setReconChangeAmt(reverseAmt);//红冲金额		
//		ret.setReverseInfo(ri);
		logger.info("[{}]调账[红冲]结束[成功].", req.getReconRltId());
		return ret;
	}

	@Override
	public ReconChangeResp doRedo(ReconChangeRedoReq req) throws ServiceException {
		//参数检查
		if(null == req) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "参数不能为空");
		}
		if(isDebug){
			logger.debug("先红冲后补单参数:{}", req.toString());
		}
		if(null == req.getReconRltId()) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "参数[reconRltId]不能为空");
		}
		
		//根据id号查询当前的收单结果表记录		
		ReconCollectRlt reconRlt = queryReconRltById(req.getReconRltId());
		long reverseAmt = 0-reconRlt.getAmt();//红冲金额
		long resupplyAmt = reconRlt.getOutAmt();//补单金额 (外部金额)
		
		StringBuffer meta = new StringBuffer(100);
		meta.append("&businessSn=").append(reconRlt.getBusinessSn());
		meta.append("&resupplyAmt=").append(resupplyAmt);
		meta.append("&operatorNo=").append(req.getOperatorNo());
		meta.append("&orgId=").append(req.getOrgId());
		meta.append("&requestIp=").append(req.getRequestIp());
		ReconChangeXml resp = doBizReconChange(reconRlt, "URL_RECON_REDO", meta);
		
		ReconChangeRs revRs = resp.getReverseRs();
		ReconChangeRs resRs = resp.getResupplyRs();
		
		CollectInfo ciRev = null;
		CollectInfo ciRes = null;
		if(null != revRs && null != resRs) {
			ciRev = addCollectInfo(req, reconRlt, revRs, reverseAmt, AppendBusType.REVERSE);//创建红冲收单信息
			ciRes = addCollectInfo(req, reconRlt, resRs, resupplyAmt, AppendBusType.RESUPPLY);//创建补单收单信息
			updateOrderRela(ciRev, ciRes);//调用订单系统更新收单编号
		}
		
		updateReconChange(req, resp, ReconChangeType.REDO);//更新对账结果表为的调账类型为先红冲后补单
		
		//返回
		ReconChangeResp ret = new ReconChangeResp();
		if(null == revRs || null == resRs) {
			ret.setRtnMsg(resp.getFailReason());
			logger.info("[{}]调账[先红冲后补单]结束[失败].", req.getReconRltId());
			return ret;
		}
		ret.setRtnMsg(SUCCESS);
		
		// 前端Controller不使用,先屏蔽.2013-12-28下一版本删除.Fuyx
//		ReconChangeRltInfo rev = new ReconChangeRltInfo();//红冲信息
//		rev.setCollectNo(ciRev.getCollectNo());
//		rev.setBusinessSn(revRs.getBusinessNo());
//		rev.setPayNo(revRs.getPayNo());
//		rev.setTradeNo(revRs.getTradeNo());
//		rev.setReconChangeAmt(reverseAmt);
//		
//		ReconChangeRltInfo res = new ReconChangeRltInfo();//补单信息
//		res.setCollectNo(ciRes.getCollectNo());
//		res.setBusinessSn(resRs.getBusinessNo());
//		res.setPayNo(resRs.getPayNo());
//		res.setTradeNo(resRs.getTradeNo());
//		res.setReconChangeAmt(resupplyAmt);
//		
//		ret.setReverseInfo(rev);
//		ret.setResupplyInfo(res);
		logger.info("[{}]调账[先红冲后补单]结束[成功].", req.getReconRltId());
		return ret;
	}

	/*@Override
	public ReconChangeResp doNoOper(ReconChangeReq req) throws ServiceException {		
		//参数检查
		if(null == req) {
			throw new ServiceException(InfoCode.PARAM_INVALID,"doNoOper's parameter is null");
		}
		if(logger.isDebugEnabled()){
			logger.debug("doNoOper's parameter is：{}",req.toString());
		}		
		if(null == req.getReconRltId()) {
			throw new ServiceException(InfoCode.PARAM_INVALID,"doNoOper's parameter[reconRltId] is null");
		}
		
		//更新对账结果表为的调账类型为不操作
		reconChange(req, ReconChangeType.NOOPER);
		
		//返回
		ReconChangeResp resp = new ReconChangeResp();
		resp.setRtnMsg(RTNMSG_SUCCESS);
		
		return resp;
	}*/
	
	/**
	 * 方法说明：
	 * 更新对账结果表
	 */
	private void updateReconChange(ReconChangeReq req, ReconChangeXml resp, ReconChangeType changeType) {
		// 把其它信息追加到备注栏中
		StringBuffer meta = new StringBuffer();
		meta.append(req.getRemark()).append("[");
		meta.append("operatorNo:").append(req.getOperatorNo()).append(";");
		meta.append("orgId:").append(req.getOrgId()).append(";");
		meta.append("requestIp:").append(req.getRequestIp()).append("].");
		
		ReconChangeUpdateInfo rcu = new ReconChangeUpdateInfo();
		rcu.setReconId(req.getReconRltId());
		rcu.setStatus(resp.getStatus());
		rcu.setFailReason(resp.getFailReason());
		rcu.setChangeType(changeType);
		rcu.setRemark(meta.toString());
		logger.info("更新对账记录[{}]的调账结果...", req.getReconRltId());
		try {
			reconDao.updateReconChange(rcu);// 调用更新调账
		} catch (Exception e) {
			logger.error(String.format("更新对账[%s]结果异常", req.getReconRltId()), e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE, "更新对账结果异常", e);
		}
	}
	
	/**
	 * 方法说明：
	 * 根据id号查询对账结果表信息
	 * @param reconId
	 * @return
	 */
	private ReconCollectRlt queryReconRltById(long reconId){
		ReconCollectRlt rlt = null;
		logger.info("查找对账[{}]信息...", reconId);
		try {
			rlt = reconDao.queryReconCollectRltById(reconId);
		} catch (Exception e) {
			logger.error(String.format("查询对账记录[%s]异常", reconId), e);
		}
		if (rlt == null) {
			throw new ServiceException(InfoCode.NO_QUERY_RECORD, String.format("无法找到对账结果记录[%s", reconId));
		} else if (ReconChangeFlag.Y.equals(rlt.getChangeReconFlag())) {
			throw new ServiceException(InfoCode.RECON_IS_ALREADY_CHANGE, "调账已执行");
		}
		return rlt;
	}
	
	/**
	 * 方法说明：
	 * 插入收单信息表
	 * @param req 
	 * @param reconRlt
	 * @param businessModel
	 * @param amt
	 * @param appendBusType
	 * @return
	 */
	private CollectInfo addCollectInfo(ReconChangeReq req, ReconCollectRlt reconRlt, ReconChangeRs rs, Long amt, AppendBusType appendBusType) {
		CollectInfo ci = new CollectInfo();
		ci.setBankCode(reconRlt.getBankCode());
		ci.setChannelCode(reconRlt.getChannelCode());
		ci.setOrderType(reconRlt.getOrderType());
		ci.setFundWay(reconRlt.getFundWay());
		ci.setTradeNo(rs.getTradeNo());
		ci.setPayNo(rs.getPayNo());
		ci.setBusinessSn(rs.getBusinessNo());
		ci.setAmt(amt);
		ci.setCcy(CurrencyType.RMB);
		ci.setStatus(CollectStatus.SUCCESS);
		Date sysDate = dualDao.getDBDatetime();
		ci.setBeginTime(sysDate);
		ci.setEndTime(sysDate);
		ci.setClientIp(req.getRequestIp());
		ci.setOldCollectNo(reconRlt.getCollectNo());
		ci.setAppendBusType(appendBusType);
		ci.setSystemSource(reconRlt.getSystemSource());
		
		//查询收款方信息
		Account ai = null;
		try {
			ai = AcquirerHelper.getAccount(reconRlt.getBankCode(), reconRlt.getChannelCode(), reconRlt.getOrderType(), reconRlt.getFundWay());
		} catch (Exception e) {
			logger.error("查询账户信息异常", e);
		}
		if(null == ai) {
			throw new ServiceException(InfoCode.ACCOUNT_NO_EXIST, "查无对应账户信息");
		}
		ci.setPayeeMemberNo(null);
		ci.setPayeeOrgCode(ai.getBankCode().name());
		ci.setPayeeBranchCode(ai.getOpeningBankNo());
		ci.setPayeeBranchName(ai.getOpeningBankName());
		ci.setPayeeAcctCode(ai.getAccountNo());
		ci.setPayeeAcctName(ai.getAccountName());
		ci.setPayeeAcctProvince(ai.getProvince());
		ci.setPayeeAcctCity(ai.getCity());
		
		if(AppendBusType.RESUPPLY.equals(appendBusType)){
			ci.setReqBankSn(reconRlt.getOutSeqno());//外部流水号
			//补单时,银联需要填写计算手续费,并记录卡类型
			if(BankCode.UPOP.equals(ci.getBankCode())){
				//添加手续费、卡类型
				ci.setPayerCardType(reconRlt.getOutTradeCardType());
				ci.setFee(reconRlt.getOutFee());
			}
		}
		logger.info("创建[{}]对应的收单调账流水...", reconRlt.getId());
		try {
			collectInfoDao.createCollectInfo(ci);
			logger.info("收单调账流水[{}]已生成.", ci.getCollectNo());
			return ci;
		} catch (Exception e) {			
			logger.error("创建收单记录异常", e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE, "创建收单记录异常", e);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 处理业务系统调账
	 * @param reconId 对账结果Id
	 * @param reconRlt 对账结果记录
	 * @param prefix 业务系统调账对应的URL前缀
	 * @param meta 业务系统调账参数.以&开头
	 * @return
	 */
	private ReconChangeXml doBizReconChange(ReconCollectRlt rlt, String prefix, StringBuffer meta) {
		Long reconId = rlt.getId();
		SystemSource src = rlt.getSystemSource();
		if(null == src) {
			throw new ServiceException(InfoCode.PARAM_INVALID, String.format("无法找到[%s]对应的系统来源", reconId));
		}
		logger.info("查找调账URL[{}_{}]...", prefix, src);
		String url = paramDao.getParameter(String.format("%s_%s", prefix, src));//如: URL_RECON_RESUPPLY_PORTAL
		if(StringUtils.isEmpty(url)) {
			throw new ServiceException(InfoCode.PARAM_INVALID, String.format("请配置参数[%s_%s]", prefix, src));
		}
		logger.info("调用[{}]处理[{}]调账...", src, reconId);
		String xml = null;
		try {
			xml = HttpHelper.sendByPost(url, meta.substring(1));
		} catch (Exception e) {
			logger.error(String.format("处理Id为[%s]的[%s]调账异常", reconId, src), e);
		}
		if(isDebug) {
			logger.debug("[{}]处理结果报文:{}", src, xml);
		}
		ReconChangeXml rs = new ReconChangeXml();
		if(StringUtils.isEmpty(xml)) {
			rs.setStatus(ReconChangeStatus.FAILURE.name());
			rs.setFailReason(String.format("无法获取[%s]调账结果", src));
			return rs;
		}
		try {
			rs.parse(xml);
		} catch (Exception e) {
			logger.error(String.format("解析Id为[%s]的[%s]调账结果异常", reconId, src), e);
		}
		try {
			ReconChangeStatus.valueOf(rs.getStatus());
		} catch (Exception e) {
			throw new ServiceException(InfoCode.PARAM_INVALID, String.format("状态值必须为[%s]定义的值", ReconChangeStatus.class.getName()),e);
		}
		return rs;
	}
	
	/**
	 * 方法说明：<br>
	 * 更新订单系统
	 */
	private void updateOrderRela(CollectInfo ci, CollectInfo ci2) {
		//调用订单系统更新收单编号
		List<UpdateCollectNo> ls = new ArrayList<UpdateCollectNo>();
		UpdateCollectNo uc = new UpdateCollectNo();//红冲或补单
		uc.setCollectNo(ci.getCollectNo());
		uc.setPayNo(ci.getPayNo());
		ls.add(uc);
		if(null != ci2) {//先红冲再补单时需要
			UpdateCollectNo uc2 = new UpdateCollectNo();
			uc2.setCollectNo(ci2.getCollectNo());
			uc2.setPayNo(ci2.getPayNo());
			ls.add(uc2);
		}
		logger.info("[调用订单系统]更新调账后的支付流水、收单流水关联关系...");
		try {
			orderUpdate.updateCollectNoList(ls);
		} catch (ServiceException e) {
			logger.error("调用订单系统更新收单编号异常", e);
			throw e;
		} catch (Exception e) {
			logger.error("调用订单系统更新收单编号异常", e);
			throw new ServiceException(InfoCode.HESSIAN_FAILURE, "调用订单系统更新收单编号异常", e);
		}
	}
	
}
