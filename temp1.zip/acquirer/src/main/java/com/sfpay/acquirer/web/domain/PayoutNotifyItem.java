/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.web.domain;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：<br>
 * 付款通知结果详情.目前暂为COD、PAS、GATEWAY使用.若此3部分代码移除,则可删除此类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-11-21
 */
public class PayoutNotifyItem extends BaseEntity {
	private static final long serialVersionUID = 2271730049736985024L;
	/**
	 * 外部交易流水号
	 */
	private String tradeOutNo;
	/**
	 * 付款编号
	 */
	private String payoutNo;
	/**
	 * 开始时间
	 */
	private Date beginTime;
	/**
	 * 结束时间
	 */
	private Date endTime;
	/**
	 * 付款金额
	 */
	private Long amt;
	/**
	 * 应收金额
	 */
	private Long shouldAmt;
	/**
	 * 抵扣金额
	 */
	private Long deductionAmt;
	/**
	 * 手续费
	 */
	private Long fee;
	/**
	 * 银行流水号
	 */
	private String reqBankSn;
	/**
	 * 银行返回码
	 */
	private String rtnBankCode;
	/**
	 * 状态
	 */
	private String status;
	/**
	 * 返回消息
	 */
	private String returnMsg;

	public String getTradeOutNo() {
		return tradeOutNo;
	}

	public void setTradeOutNo(String tradeOutNo) {
		this.tradeOutNo = tradeOutNo;
	}

	public String getPayoutNo() {
		return payoutNo;
	}

	public void setPayoutNo(String payoutNo) {
		this.payoutNo = payoutNo;
	}

	public Date getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(String beginTime) {
		this.beginTime = conver2Date(beginTime);
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(String endTime) {
		this.endTime = conver2Date(endTime);
	}

	public Long getAmt() {
		return amt;
	}

	public void setAmt(Long amt) {
		this.amt = amt;
	}

	public Long getShouldAmt() {
		return shouldAmt;
	}

	public void setShouldAmt(Long shouldAmt) {
		this.shouldAmt = shouldAmt;
	}

	public Long getDeductionAmt() {
		return deductionAmt;
	}

	public void setDeductionAmt(Long deductionAmt) {
		this.deductionAmt = deductionAmt;
	}

	public Long getFee() {
		return fee;
	}

	public void setFee(Long fee) {
		this.fee = fee;
	}

	public String getReqBankSn() {
		return reqBankSn;
	}

	public void setReqBankSn(String reqBankSn) {
		this.reqBankSn = reqBankSn;
	}

	public String getRtnBankCode() {
		return rtnBankCode;
	}

	public void setRtnBankCode(String rtnBankCode) {
		this.rtnBankCode = rtnBankCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getReturnMsg() {
		return returnMsg;
	}

	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}
	
	private Date conver2Date(String date) {
		if(StringUtils.isEmpty(date)) {
			return null;
		}
		try {
			return new SimpleDateFormat("yyyyMMddHHmmss").parse(date);
		} catch (ParseException e) {
		}
		return null;
	}
}
