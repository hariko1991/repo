package com.sfpay.acquirer.gate.b2e.command;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutRespResult;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.acquirer.enums.CmdStatus;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.gate.b2e.BaseCommand;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.QueryBatchPayOffInfo;
import com.sfpay.acquirer.gate.b2e.domain.QueryTransferSubInfo;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 
 * 类说明：<br>
 * 查询支付结果（对私）
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-5-6
 */
public class QueryBatchPayOff extends BaseCommand {
	
	private BatchInfo bi;
	private List<PayoutInfo> pis;
	private BankCode bankCode;
	
	public QueryBatchPayOff(){
		super(TradeCodeB2E.QUERY_BATCH_PAYOFF);
	}
	
	public QueryBatchPayOff(BatchInfo bi,List<PayoutInfo> pis,BankCode bankCode){
		super(TradeCodeB2E.QUERY_BATCH_PAYOFF);
		this.bi = bi;
		this.pis = pis;
		this.bankCode = bankCode;
	}

	@Override
	protected BeanBase assemble(BankProperty property) throws Exception {
		try{
			PayoutInfo info = pis.get(0);
			
			//设置报文头
			BeanBase bean = new BeanBase(bankCode, super.tradeCodeB2E);
			/**
			 * 用于结算中心报文序列号
			 * sfh270   2014-12-03
			 */
			bean.setSeqNo(CUID.getSZFSMsgNo());
			bean.setBankProperties(property);
			
			QueryBatchPayOffInfo  detail = new QueryBatchPayOffInfo();
			/**
			 * 招行返回流程实例号，也可以用作其他银行返回业务号或流水号
			 */
			detail.setSerialId(CUID.generateId4B2E(20));
			detail.setRtnBankSn(bi.getRtnBankSn());
			detail.setBankRetCode(bi.getRtnBankCode());
			detail.setBankRetMsg(bi.getRtnBankMsg());
			detail.setMainSerialId(bi.getReqBankSn());
			detail.setPayerAccNo(info.getPayerAcctNo());
			detail.setPayerCity(info.getPayerAcctCityName());
			detail.setPayerAccName(info.getPayerAcctName());
			detail.setPayerProv(info.getPayerAcctProvince());
			detail.setPayerOpenBranchName(info.getPayerBranchName());
			detail.setSendTime(DateUtil.getCDateString(DateUtil.DATA_FORMAT_PATTERN));
			Date queryDate = bi.getPayBatchDate() == null?bi.getSecCheckDate():bi.getPayBatchDate();
			detail.setBatchStatus(bi.getStatus());// 批次状态 sfhq814 2015-8-13
			detail.setTradeTime(DateUtil.getDateString(queryDate,DateUtil.DATA_FORMAT_PATTERN_2));
			List<QueryTransferSubInfo> subInfoList = new ArrayList<QueryTransferSubInfo>();
			//设置查询子信息
			long totalAmt = 0l;
			int totalCnt = 0;
			for(PayoutInfo pi : pis){
				QueryTransferSubInfo subInfo = new QueryTransferSubInfo();
				subInfo.setPayeeAccName(pi.getPayeeAcctName());
				subInfo.setSubSerialId(pi.getReqBankSn());
				subInfo.setAmt(pi.getAmt());
				subInfo.setPayeeAccNo(pi.getPayeeAcctNo());
				totalAmt += pi.getAmt();
				totalCnt += 1;
				subInfoList.add(subInfo);
			}
			
			detail.setSubInfo(subInfoList);
			detail.setTotalAmt(totalAmt);
			detail.setTotalCount(totalCnt);
			bean.setBusDetailBeanBase(detail);
			
			
			return bean;
		}catch(Exception ex){
			logger.error("批次[批次号:"+bi.getBatchCode()+"]生成查询批量对私支付结果报文异常:",ex);
			throw new ServiceException(InfoCode.FAILURE, ex);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	protected PayoutRespResult parseMsg(BeanBase respBean)
			throws Exception {
		PayoutRespResult resp = new PayoutRespResult();
		
		QueryBatchPayOffInfo detail = (QueryBatchPayOffInfo)respBean.getBusDetailBeanBase();
		//转换批次信息
		resp.setBatchReqBankSn(detail.getMainSerialId());
		resp.setReqBankSn("");
		resp.setRtnBankCode(detail.getBankRetCode());
		if(detail.getBankRetMsg() == null || "".equals(detail.getBankRetMsg())){
			resp.setRtnBankMsg(detail.getRetMsg());
		}else {
			resp.setRtnBankMsg(detail.getBankRetMsg());
		}
		if(!StringUtils.isEmpty(detail.getRtnBankSn())){
			resp.setRtnBankSn(detail.getRtnBankSn());
		}else{
			resp.setRtnBankSn("");
		}
		resp.setCmdStatus(CmdStatus.convertToCmdStatus(detail.getRetCode()));
		resp.setRemark(detail.getRetMsg());
		
		//转换付款信息
		List<PayoutInfo> payoutDetail = null;
		List<QueryTransferSubInfo> subInfoList = detail.getSubInfo();
		if(subInfoList != null){
			payoutDetail = new ArrayList<PayoutInfo>();
			for(QueryTransferSubInfo subInfo : subInfoList){
				PayoutInfo info = new PayoutInfo();
				
				info.setAmt(subInfo.getAmt());
				info.setReqBankSn(subInfo.getSubSerialId());
				info.setRtnBankCode(subInfo.getBankRetCode());
				info.setRtnBankMsg(subInfo.getBankRetMsg());
				info.setPayeeAcctNo(subInfo.getPayeeAccNo());
				PayoutStatus payoutStatus = PayoutStatus.convertToPayoutStatus(subInfo.getCmdStat());
				info.setStatus(payoutStatus);
/*				if(payoutStatus.equals(PayoutStatus.RECEIVED)){
					i++;
				}
*/				payoutDetail.add(info);
			}
			/*if(i==subInfoList.size())
				resp.setStatus(BatchStatus.RECEIVED);*/
		}
		resp.setPayoutDetail(payoutDetail);
		
		return resp;
	}


}
