package com.sfpay.acquirer.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutQueryParam;
import com.sfpay.acquirer.domain.PayoutQueryRlt;

/**
 * 海外订单
 * 跨境支付
 * @author sfhq814
 *add 2015-9-24
 */
public interface IOverseasOrdersDao {
	/**
	 * 方法说明：<br>
	 * 添加
	 *
	 * @param payoutInfo
	 */
	public void saveOverseasOrders(PayoutInfo payoutInfo);
	
	/**
	 * 跨境出款业务登记修改
	 * @param payoutInfo
	 * @return
	 */
	public int updateCrossborderById(PayoutInfo payoutInfo);
	
	 /**
	 * 方法说明：<br>
	 * 跨境出款业务登记，其他功能不要调用，后续可能要删除
	 * 分页查询总条数
	 *
	 * @param param
	 * @return
	 */
	public Map<String,BigDecimal> countCrossborderPage(@Param("param") PayoutQueryParam param);
	
	/**
	 * 方法说明：<br>
	 * 跨境出款业务登记，其他功能不要调用，后续可能要删除
	 * 分页查询
	 *
	 * @param param
	 * @param start
	 * @param end
	 * @return
	 */
	public List<PayoutInfo> queryCrossborderPage(@Param("param") PayoutQueryParam param, @Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：<br>
	 * 根据ID查询
	 * @param batchCode
	 * @return
	 */
	public PayoutInfo queryById(@Param("id")Long id) throws Exception;
	/**
	 * 退票处理
	 * @param info
	 * @return
	 */
	public int updateRefundById(PayoutInfo info);
	
	public List<PayoutInfo> queryBankCode();
}
