package com.sfpay.acquirer.gate.b2e.command;

import java.util.ArrayList;
import java.util.List;

import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchPayoutReqResult;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutReqResult;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.RemitMethod;
import com.sfpay.acquirer.gate.b2e.BaseCommand;
import com.sfpay.acquirer.gate.b2e.domain.BatchPayOffInfo;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.TransferSubInfo;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;

/**
 * 
 * 
 * 类说明：<br>
 * 批量支付（对私）
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-5-6
 */
public class BatchPayOff extends BaseCommand {

	private BatchInfo bi;
	private List<PayoutInfo> pis;
	private BankCode bankCode;
	private BatchRuleInfo br;
	
	public BatchPayOff(){
		super(TradeCodeB2E.BATCH_PAYOFF);
	}
	
	public BatchPayOff(BatchInfo bi,List<PayoutInfo> pis,BankCode bankCode,BatchRuleInfo br){
		super(TradeCodeB2E.BATCH_PAYOFF);
		this.bi = bi;
		this.pis = pis;
		this.bankCode = bankCode;
		this.br= br;
	}
	

	@Override
	protected BeanBase assemble(BankProperty property) throws Exception {
		try{
			PayoutInfo payout = pis.get(0);
			CurrencyType ccy = null;
			
			if(payout.getCcy() == null){
				//默认为人民币
				ccy = CurrencyType.RMB;
			}else{
				ccy = payout.getCcy();
			}
			//设置报文头 
			BeanBase baseInfo = new BeanBase(bankCode, super.tradeCodeB2E);
			/**
			 * 用于结算中心报文序列号
			 * sfh270   2014-12-03
			 */
			baseInfo.setSeqNo(CUID.getSZFSMsgNo());
			//测试时间
			if(BankCode.ICBC.equals(bankCode)){
				String testDate = Property.getProperty("B2E_TEST_ICBC_DATE");
				if(testDate != null && !"".equals(testDate.trim())){
					property.put("testDate", testDate);
				}
			}
			
			baseInfo.setBankProperties(property);//银行参数
			
			
			BatchPayOffInfo detail = new BatchPayOffInfo();
			//设置共用参数
			detail.setSerialId(bi.getReqBankSn());
			detail.setCheckStr("");
			detail.setCur(ccy);
			detail.setPayerAccNo(payout.getPayerAcctNo());
			detail.setPayerAccName(payout.getPayerAcctName());
			detail.setPayerProv(payout.getPayerAcctProvinceName());
			detail.setPayerCity(payout.getPayerAcctCityName());
			detail.setPayerOpenBranchName(payout.getPayerBranchName());
			detail.setSendTime(DateUtil.getCDateString(DateUtil.DATA_FORMAT_PATTERN));
			detail.setBatchCode(payout.getBatchCode());
			if(BankCode.BOC.equals(bankCode)){
				detail.setBocBankCode(payout.getPayerBranchCode());
			}
			
			List<TransferSubInfo> subInfoList = new ArrayList<TransferSubInfo>();
			//设置子记录信息
			int totalCount = 0;
			long totalAmt = 0L;
			for(PayoutInfo pi : pis){
				TransferSubInfo transferInfo = new TransferSubInfo();
				
				transferInfo.setSubSerialId(pi.getReqBankSn());
				transferInfo.setAmt(pi.getAmt());
				transferInfo.setPayeeAccName(pi.getPayeeAcctName());
				transferInfo.setPayeeAccNo(pi.getPayeeAcctNo());
				transferInfo.setPayeeProv(pi.getPayeeAcctProvinceName());
				transferInfo.setPayeeCity(pi.getPayeeAcctCityName());
				transferInfo.setPayeeOpenBranchName(pi.getPayeeBranchName());
				transferInfo.setPayeeBankNo(pi.getPayeeBranchCode());
				//增加收款方联行号 sfhq270 2014-12-01
				transferInfo.setPayeeUnionBankCode(pi.getPayeeUnionBankCode());
				transferInfo.setPayeeUnionBankName(pi.getPayeeUnionBankName());
				transferInfo.setPostscript(pi.getSummary());//附言
				transferInfo.setRemark(pi.getSummary());//备注
				transferInfo.setSummary(pi.getSummary());//摘要
				transferInfo.setUsefor(pi.getUseType());
				RemitMethod remitMethod =pi.getRemitMethod() ;
				if("Y".equals(br.getSuperInterFlag())){
					remitMethod=RemitMethod.SUPERINTER;
				}
				switch (remitMethod) {
				case SUPERINTER:
					transferInfo.setUrgencyFlag("3");
					break;
				case FAST:
					transferInfo.setUrgencyFlag("1");
					break;
				default:
					transferInfo.setUrgencyFlag("2");
				}
 				
				String acctOrgCode = pi.getPayerOrgCode().name();
				String orgName = pi.getPayeeOrgCode().name();
				if(!acctOrgCode.equals(orgName)){//跨行
					transferInfo.setDifBankFlag("1");
				}else{//同行
					transferInfo.setDifBankFlag("0");
				}
				
//				不做判断
//				try{
//					if(pi.getPayerAcctCity().equals(pi.getPayeeAcctCity())){
//						subInfo.setDifAreaFlag("0");
//					}else{
//						subInfo.setDifAreaFlag("1");
//					}
//				}catch(Exception ex){
//					logger.error("无法判断同城异地.");
//				}
				
				//计算总数和总金额
				totalCount += 1;
				totalAmt += pi.getAmt();
				
				subInfoList.add(transferInfo);
			}
			
			detail.setTotalAmt(totalAmt);
			detail.setTotalCount(totalCount);
			detail.setSubInfoList(subInfoList);
			baseInfo.setBusDetailBeanBase(detail);
			
			
			return baseInfo;
		}catch(Exception ex){
			logger.error("批次[请求流水号:"+bi.getReqBankSn()+"]生成报文异常:",ex);
			throw new ServiceException(InfoCode.FAILURE, ex);
		}
	}


	@SuppressWarnings("unchecked")
	@Override
	protected PayoutReqResult parseMsg(BeanBase respBean) throws Exception {
		//2050607 避免重复代码
		return new BatchPayoutReqResult(respBean);
	}

}
