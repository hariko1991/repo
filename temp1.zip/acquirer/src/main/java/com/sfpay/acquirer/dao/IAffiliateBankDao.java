/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.AffiliateBank;
import com.sfpay.acquirer.domain.AffiliateBankParam;

/**
 * 类说明：<br>
 * 银行联行号 dao
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2012-10-23
 */
public interface IAffiliateBankDao {

	/**
	 * 方法说明：<br>
	 * 查询开户行（第一级）
	 *
	 * @return
	 */
	public List<AffiliateBank> queryBank();
	
	/**
	 * 方法说明：<br>
	 * 查询各支行/分行
	 *
	 * @param parentId
	 * @param countryCode
	 * @param affiliateName
	 * @return
	 */
	public List<AffiliateBank> queryAffiliate(@Param("affiliateNo")String affiliateNo
			,@Param("countryCode")String countryCode,@Param("affiliateName")String affiliateName
			,@Param("provinceCode")String  provinceCode);
	
	/**
	 * 方法说明：<br>
	 * 分页查询
	 *
	 * @param map
	 * @return
	 */
	public List<AffiliateBank> queryPage(@Param("param") AffiliateBankParam param, @Param("start")  int start, @Param("end") int end);
	
	/**
	 * 方法说明：
	 * 分页查询 总条数
	 * @param param 查询条件
	 * @return
	 */
	public long queryPageCount(@Param("param") AffiliateBankParam param); 
	
	/**
	 * 方法说明：<br>
	 * 查询父银行
	 *
	 * @param affiliateNo
	 * @return
	 */
	public AffiliateBank queryBankByAffiliateNo(String affiliateNo);
	
	/**
	 * 方法说明：<br>
	 * 按联行号查询
	 *
	 * @param affiliateNo
	 * @return
	 */
	public  List<AffiliateBank> queryByAffiliateNo(String affiliateNo);
	
	/**
	 * 根据付款渠道查询收款银行
	 * @author sfhq270
	 * 2014-11-27
	 * @param payChannelNo
	 * @return
	 */
	public List<AffiliateBank> queryPayBankByPayChannelNo(String payChannelNo);
	
}
