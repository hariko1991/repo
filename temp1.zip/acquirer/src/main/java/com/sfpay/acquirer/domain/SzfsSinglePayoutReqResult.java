package com.sfpay.acquirer.domain;

import com.sfpay.acquirer.enums.ChannelPayType;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.gate.b2e.domain.SinglePayInfo;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;

/**
 * 只用于深圳结算中心的支付请求结果。
 * 对应于指令地：TradeCodeB2E.SZFS_SINGLEPAY
 * @author sfhq534
 *
 */
public class SzfsSinglePayoutReqResult extends PayoutReqResult {

	/**
	 * 提供信息格式的封装类，不同情况有不同的子类，但尽量重用。
	 * 应该从源头进行信息的分类处理，避免过多的if else 耦合。通过子类的继承变化可降低if else 对于 OCP原则的入侵。
	 * @return 
	 */
	@SuppressWarnings("unchecked")
	public  SzfsSinglePayoutReqResult(
			com.sfpay.acquirer.gate.b2e.domain.BeanBase respBean){
		super.parseMsg(respBean);
		
		// 此行是结算中心单笔代付和其他不一样的地方
		this.setChannelPayType(ChannelPayType.SINGLE_PAY);
		// 此行是结算中心单笔代付和其他不一样的地方
		SinglePayInfo detail = (SinglePayInfo)respBean.getBusDetailBeanBase();
		// 此行是结算中心单笔代付和其他不一样的地方
		this.setReqBankSn(detail.getSubSerialId());
		
		this.setPayoutStatus(PayoutStatus.convertToSinglePayoutStatus(detail.getRetCode()));
				
	}
}
