/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.common;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.util.Enumeration;
import java.util.zip.GZIPInputStream;

import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveStreamFactory;
import org.apache.commons.compress.archivers.tar.TarArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipArchiveEntry;
import org.apache.commons.compress.archivers.zip.ZipFile;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


/**
 * 
 * 类说明：<br>
 * 压缩帮助类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 <a href="mailto:fuyuxin@sf-express.com">符瑜鑫(Ricky Fu)</a>
 * 
 * CreateDate: 2012-5-20
 */
public final class ZipHelper {
	private static final Logger logger = LoggerFactory.getLogger(ZipHelper.class);
	private ZipHelper() {}
	
	/**
	 * 方法说明：<br>
	 * 解压<tt>tar.gz</tt>类型文件并写入<tt>outputDir</tt>对应的目录
	 *
	 * @param zipFileName tar.gz格式的压缩文件
	 * @param outputDir 输入文件目录
	 * @throws Exception
	 */
	public static void unZipTargz(String zipFileName, String outputDir) throws Exception {
		ArchiveInputStream in = null;
		BufferedInputStream bis = null;
		BufferedOutputStream bos = null;
		byte[] b = null;
		File file = null;
		char last = outputDir.charAt(outputDir.length()-1);
		String dir = last == '/' || last == '\\' ? outputDir : outputDir+'/';
		try {
			GZIPInputStream gis = new GZIPInputStream(new BufferedInputStream(new FileInputStream(zipFileName)));
			in = new ArchiveStreamFactory().createArchiveInputStream("tar", gis);
			TarArchiveEntry entry = null;
			while (null != (entry = (TarArchiveEntry) in.getNextEntry())) {
				String name = entry.getName();
				file = new File(dir+name);
				if(name.charAt(name.length()-1) == '/') {
					if (!file.exists()) {
						try{
							file.mkdirs();
						}catch(SecurityException e) {
							logger.error("[ It doesn't own the create directory rights. ]", e);
						}
					}
				} else {
					try{
						file.createNewFile();
					}catch(SecurityException e) {
						logger.error("[ It doesn't own the create directory rights. ]", e);
					}
					try {
						bis = new BufferedInputStream(in);
						bos = new BufferedOutputStream(new FileOutputStream(file));
						b = new byte[bis.available()];
						bis.read(b);
						bos.write(b);
						bos.flush();
					}catch(Exception e){
						logger.error("unZipTargz", e);
					} finally {
						try {
							if(null != bos) { bos.close(); }
						} catch (IOException e) {
							logger.error("unZipTargz", e);
						}
					}
				}
			}
		} catch (IOException e) {
			logger.error("unZipTargz", e);
		} catch (Exception e) {
			logger.error("unZipTargz", e);
		} finally {
			try {
				if(null != bis) { bis.close(); }
				if(null != in) { in.close(); }
			} catch (IOException e) {
				logger.error("unZipTargz", e);
			}
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 解压<tt>zip</tt>类型文件并写入<tt>outputDir</tt>对应的目录
	 *
	 * @param zipFileName zip格式的压缩文件
	 * @param outputDir 输入文件目录
	 * @throws Exception
	 */
	public static void unZip(String zipFileName, String outputDir) throws Exception {
		File zipFile = new File(zipFileName); 	
		File pathFile = new File(outputDir); 
		if(!pathFile.exists()){ 
			try{
			    pathFile.mkdirs();
			}catch(SecurityException e) {
				throw new IOException("[ It doesn't own the create directory rights. ]", e);
			}
		} 
		char last = outputDir.charAt(outputDir.length()-1);
		String dir = last == '/' || last == '\\' ? outputDir : outputDir+'/';
		
		InputStream in = null;
		OutputStream out = null;
		ZipFile zip =  null;
		try{
			zip = new ZipFile(zipFile); 
			for(Enumeration<ZipArchiveEntry> entries = zip.getEntries();entries.hasMoreElements();){ 
				ZipArchiveEntry entry = (ZipArchiveEntry)entries.nextElement(); 
			    String zipEntryName = entry.getName(); 
			    in = zip.getInputStream(entry); 
			    String outPath = dir+zipEntryName; 
				//判断路径是否存在,不存在则创建文件路径 
				File file = new File(outPath.substring(0, outPath.lastIndexOf('/'))); 
				if(!file.exists()){ 
					try{
					    file.mkdirs(); 
					} catch (SecurityException e) {
						logger.error("[ It doesn't own the create directory rights. ]", e);
					}
				} 
				//判断文件全路径是否为文件夹,如果是上面已经上传,不需要解压 
				if(new File(outPath).isDirectory()){ 
				    continue; 
				} 
				 
				out = new FileOutputStream(outPath); 
				byte[] buf1 = new byte[1024]; 
				int len; 
				while((len=in.read(buf1))>0){ 
				    out.write(buf1,0,len); 
				} 
				
			} 
		}finally{
			try {
				if(null != in) { in.close(); }
				if(null != out) { out.close(); }
				if(null != zip){zip.close();}
			}catch(Exception ex){
				logger.info("正常释放资源");
			}
		}

	}   
       
    public static boolean isPics(String filename)   
    {   
        boolean flag = false;   
           
        if(filename.endsWith(".jpg") || filename.endsWith(".gif")  || filename.endsWith(".bmp") || filename.endsWith(".png"))   
            flag = true;   
           
        return flag;   

	}
	
	
}
