/**
 * 
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.UnkownCollect;
import com.sfpay.acquirer.domain.UnkownCollectParam;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;

/**
 * 类说明：
 * 未知收单信息 dao 
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 * @author 329202 符瑜鑫(Ricky Fu)
 *   
 * CreateDate: 2012-8-9
 */
public interface IUnkownCollectDao {
	
	/**
	 * 方法说明：
	 *	从收单信息表中增加未知收单信息表
	 * @param uc
	 */
	public void addUnkownCollectFromCollectInfo(); 
	
	/**
	 * 方法说明：
	 * 查询未知状态的收单记录列表
	 * @param channelCode 渠道编码
	 * @param bankCode 银行编码
	 * @param orderType 订单类型
	 * @param fundWay 资金方向
	 * @return
	 */
	public List<UnkownCollect> queryUnkownCollectList(@Param("channelCode")ChannelCode channelCode,@Param("bankCode")BankCode bankCode,@Param("orderType")OrderType orderType,@Param("fundWay")FundWay fundWay);
	
	/**
	 * 方法说明：
	 * 通过未知状态的变更，确定更新收单记录表
	 * 调用存储过程
	 */
	public void updateUnkownCollect(UnkownCollectParam param);
}
