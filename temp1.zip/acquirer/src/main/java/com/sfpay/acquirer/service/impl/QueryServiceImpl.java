/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;


import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.AcquirerHelper;
import com.sfpay.acquirer.domain.QueryInfo;
import com.sfpay.acquirer.domain.QueryParam;
import com.sfpay.acquirer.enums.AcqBizType;
import com.sfpay.acquirer.gate.AcquirerBizFactory;
import com.sfpay.acquirer.gate.IQuery;
import com.sfpay.acquirer.service.IQueryService;
/**
 * 类说明：向外暴露出查询接口
 * @author 349508 韦健
 *
 */
@Deprecated
@Service("queryService")
public class QueryServiceImpl implements IQueryService{
	/**
	 * 获取报文
	 * @return
	 * @throws Exception
	 */ 
	@Override
	public QueryInfo getQueryInfo(QueryParam queryParam) throws Exception{
		IQuery acqQuery = AcquirerBizFactory.getInstance(queryParam.getBank(), queryParam.getChannel(), AcqBizType.QUERY);
		//获取查询信息，构造查询数据
		acqQuery.setQueryParam(queryParam);
		//返回查询数据
		return acqQuery.getQueryInfo(AcquirerHelper.getProperties(queryParam.getBank(),queryParam.getChannel()));
		  
	}
}
