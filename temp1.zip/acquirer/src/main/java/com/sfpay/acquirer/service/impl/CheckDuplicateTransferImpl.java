package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.service.ICheckDuplicateTransfer;
import com.sfpay.acquirer.service.SendPayoutResp;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * @author sfhq270 检查重复提交付款请求
 *
 */
@Service
public class CheckDuplicateTransferImpl implements ICheckDuplicateTransfer {
	@Resource
	private SendPayoutResp sendPayout;
	@Resource
	private IPayoutInfoDao payoutInfoDao;
	private static Logger logger = LoggerFactory.getLogger(CheckDuplicateTransferImpl.class);
	private static final boolean isDebug = logger.isDebugEnabled();

	/**
	 * @throws ServiceException
	 *             检查重复提交的付款请求并处理重复付款请求 2015-01-16 sfhq270
	 */
	public void checkAndProcessDuplicatePayout() throws ServiceException {
		logger.info("进入防重检查...");
		long start = System.currentTimeMillis();
		List<String> tradeOutNos = payoutInfoDao.queryDuplicateTransfer();
		if (null == tradeOutNos || tradeOutNos.size() == 0) {
			if (isDebug) {
				logger.info("没有重复请求的付款流水,防重检查结束...");
			}
			return;
		}
		for (String tradeOutNo : tradeOutNos) {
			processPayout(tradeOutNo);
		}
		logger.info("防重检查结束，耗时：" + (System.currentTimeMillis() - start) + " 毫秒");
	}

	private void processPayout(String tradeOutNo) {
		// 第一步将该笔业务流水为INIT（初始录入）
		List<PayoutInfo> payoutInfos = payoutInfoDao.queryPayoutInfoByTradeOutNo(tradeOutNo);
		if (null == payoutInfos || payoutInfos.size() == 0) {
			if (isDebug) {
				logger.info("没有需要通知业务系统的付款请求payoutInfos：{}", payoutInfos);
			}
			return;
		}
		// 第二步状态的更改为FAILURE（失败）状态。
		StringBuffer payoutNosString = new StringBuffer();
		for (PayoutInfo payoutInfo : payoutInfos) {
			// 组装返回信息。
			payoutNosString.append(payoutInfo.getPayoutNo()).append(",");
		}
		for (PayoutInfo payoutInfo : payoutInfos) {
			StringBuffer msgStr = new StringBuffer("付款编号payoutNo[");
			payoutInfo.setStatus(PayoutStatus.FAILURE);
			msgStr.append(payoutNosString.toString()).append("]存在重复的付款请求,请求tradeOutNo:=")
					.append(payoutInfo.getTradeOutNo());
			payoutInfo.setRtnBankMsg(msgStr.toString());
			payoutInfoDao.updatesDuplicatePayoutStatus(payoutInfo);
		}
		// 第三步将失败结果发送给业务系统。
		sendPayout.sendBusinessSysResp(payoutInfos);
		logger.info("通知业务系统结束。。。。");
	}
}
