/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.common;

import java.util.Map;

import com.sfpay.acquirer.domain.Account;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.acquirer.gate.IAcqBiz;
import com.sfpay.acquirer.gate.annotation.AcquirerBiz;
import com.sfpay.acquirer.service.IAccountInfoService;
import com.sfpay.acquirer.service.IBankChannelArgService;

/**
 * 
 * 类说明：
 * 收单系统配置信息读取类
 * 
 * <p>
 * 详细描述：
 * 
 * @author 321302 程俊杰
 * @author 329202 <a href="mailto:fuyuxin@sf-express.com">符瑜鑫(Ricky Fu)</a>
 *   
 * CreateDate: 2012-4-27
 */
public final class AcquirerHelper {
	
	private AcquirerHelper() {
	}

	private static IBankChannelArgService srvProp = ApplicationContextHelper.getBean(IBankChannelArgService.class);
	
	private static IAccountInfoService srvAccount = ApplicationContextHelper.getBean(IAccountInfoService.class);
	
	/**
	 * 方法说明：<br>
	 * 根据银行简称({@link BankCode}),渠道编码({@link ChannelCode})和属性键获取该属性对应值
	 *
	 * @param bank 银行简称
	 * @param channel 渠道编码
	 * @return
	 */
	public static BankProperty getProperties(BankCode bank, ChannelCode channel) {
		return srvProp.getBankChannelArgs(bank, channel);
	}
	
	/**
	 * 方法说明：<br>
	 * 获取所有银行配置参数值.Key格式: ChannelCode_BankCode
	 * @return
	 */
	public static Map<String, BankProperty> getProperties() {
		return srvProp.getBankChannelArgs();
	}
	
	/**
	 * 方法说明：<br>
	 * 根据资金方向类型获取账户信息.<br>
	 * 此方法在{@link IAcqBiz}实现类中使用,第一参数传入<code>this</code>即可.
	 *
	 * @param bizGate {@link IAcqBiz}实例
	 * @param fw
	 * @return
	 */
	public static Account getAccount(IAcqBiz bizGate, OrderType type, FundWay fw) {
		AcquirerBiz ab = bizGate.getClass().getAnnotation(AcquirerBiz.class);
		if (ab == null) {
			throw new IllegalArgumentException("["+bizGate.getClass()+"] not present AcquirerBiz annotation");
		}
		return getAccount(ab.bank(), ab.channel(), type, fw);
	}
	
	/**
	 * 方法说明：<br>
	 * 根据银行简称({@link BankCode}),渠道编码({@link ChannelCode}),订单类型({@link OrderType})和资金方向({@link FundWay})
	 * 获取账户信息
	 *
	 * @param bank 银行简称
	 * @param channel 渠道编码
	 * @param type 订单类型
	 * @param fw 资金方向
	 * @return
	 */
	public static Account getAccount(BankCode bank, ChannelCode channel, OrderType type, FundWay fw) {
		return srvAccount.getAccount(bank, channel, type, fw);
	}
	
}
