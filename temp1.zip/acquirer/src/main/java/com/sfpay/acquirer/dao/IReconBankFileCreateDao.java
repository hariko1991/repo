package com.sfpay.acquirer.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.ReconBankFileCreate;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;

public interface IReconBankFileCreateDao {
	
	/**
	 * 方法说明：<br>
	 * 添加
	 *
	 * @param payoutInfo
	 */
	public int save(ReconBankFileCreate info);
	
	/**
	 * 方法说明：<br>
	 * 修改
	 *
	 * @param info
	 * @return
	 */
	public int update(ReconBankFileCreate info);
	
	/**
	 * 方法说明：<br>
	 * 查询
	 *
	 * @param bankCode
	 * @param channelCode
	 * @param tradeDate
	 * @return
	 */
	public List<ReconBankFileCreate> query(@Param("bankCode")BankCode bankCode
			,@Param("channelCode")ChannelCode channelCode,@Param("tradeDate")Date tradeDate);

}
