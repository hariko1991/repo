package com.sfpay.acquirer.service;

import java.util.List;
import java.util.Map;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2015年12月9日
 */
public interface IChannelFieldMappingService {
	/**
	 * 方法说明：<br>
	 * 通过渠道查询映射关系
	 * 
	 * @param channel
	 *            渠道编码
	 * @return key:转换的字段，value，映射关系
	 */
	Map<String, Map<String,String>> queryMappingByChannel(String channel);

	/**
	 * 方法说明：<br>
	 * 根据映射关系，转换bean的属性值
	 * @param bean 待转换的javabean
	 * @param mapping 映射关系
	 */
	void execFieldMapping(Object bean,Map<String,Map<String,String>> mapping);
	/**
	 * 方法说明：<br>
	 * 根据映射关系，批量转换bean的属性值
	 * @param list javabean列表
	 * @param channel 渠道编码 
	 */
	void batchExecFieldMapping(List<?> list,String channel);
}
