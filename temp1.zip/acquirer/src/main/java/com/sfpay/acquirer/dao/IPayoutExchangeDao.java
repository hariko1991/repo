package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.PayoutExchange;
import com.sfpay.acquirer.enums.ExchangeType;

/**
 * 
 * 
 * 类说明：<br>
 * 付款交互　DAO
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-8-13
 */
public interface IPayoutExchangeDao {

	/**
	 * 方法说明：<br>
	 * 添加交互信息
	 *
	 * @param exchange
	 * @throws Exception
	 */
	public void saveExchange(PayoutExchange exchange) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 更新
	 *
	 * @param exchange
	 * @return
	 * @throws Exception
	 */
	public int updateOrderResp(PayoutExchange exchange) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 查询交互信息
	 *
	 * @param payoutNo
	 * @param type
	 * @return
	 * @throws Exception
	 */
	public PayoutExchange selectExchange(@Param("payoutNo")String payoutNo
			,@Param("exchangeType")ExchangeType exchangeType,@Param("revExchangeNo")String revExchangeNo) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 根据付款编号查询交互信息(如交互类型不为空，则查询所属交互类类型的交互信息) 
	 *
	 * @param info
	 * @param exchangeTypes
	 * @return
	 * @throws Exception
	 */
	public List<PayoutExchange> queryExchange(@Param("info")PayoutExchange info,@Param("exchangeTypes")List<ExchangeType> exchangeTypes) throws Exception;
	
}
