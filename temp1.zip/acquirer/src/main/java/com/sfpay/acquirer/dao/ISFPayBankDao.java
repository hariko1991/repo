/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.SFPayBank;
import com.sfpay.acquirer.enums.ChannelCode;

/**
 * 类说明：<br>
 * 顺银银行编码与实际银行编码的映射接口
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-7-23
 */
public interface ISFPayBankDao {
	
	/**
	 * 方法说明：<br>
	 * 根据渠道编码、顺银银行编码获取对应的映射记录.
	 * 参数使用String而非枚举.
	 * 
	 * @param channel 渠道编码{@link ChannelCode channel}.
	 * @param sfpBank 顺银银行编码,值为支付网关里的SFPayBankCode.
	 */
	public SFPayBank findBank(@Param("channel") ChannelCode channel, @Param("sfpBank") String sfpBank) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 查询所有映射银行
	 * 
	 * @param channel 渠道编码{@link ChannelCode channel}
	 */
	public List<SFPayBank> queryBank(@Param("channel") ChannelCode channel) throws Exception;

}
