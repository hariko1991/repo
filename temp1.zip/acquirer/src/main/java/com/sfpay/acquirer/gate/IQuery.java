/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.gate;

import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.QueryInfo;
import com.sfpay.acquirer.domain.QueryParam;

/**
* 
* 类说明：
* 对账接口 
* 
* <p/>
* 详细描述：
* 网银、快捷支付所有对账接口基类  
* 
* @author 312932 韦健
*   
* CreateDate: 2012-8-02
*/
public interface IQuery extends IAcqBiz {
	
	/**
	 * 获取并封装查询信息
	 * @return
	 * @throws Exception
	 */
	public QueryInfo getQueryInfo(BankProperty property) throws Exception;
	
	/**
	 * 获取配置封装参数
	 */
	public void setQueryParam(QueryParam queryParam);
	
	/**
	 * 封装报文
	 * @return
	 * @throws Exception
	 */
	public String getPostParam() throws Exception;
	

}
