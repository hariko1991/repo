package com.sfpay.acquirer.service.impl;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IBatchInfoDao;
import com.sfpay.acquirer.dao.IOverseasOrdersDao;
import com.sfpay.acquirer.dao.IParamInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.PayoutExchange;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutQueryParam;
import com.sfpay.acquirer.domain.PayoutQueryRlt;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.BatchOperatorType;
import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.ExchangeType;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.acquirer.service.B2EPayoutServiceImpl;
import com.sfpay.acquirer.service.ICrossborderService;
import com.sfpay.acquirer.service.IPayoutExchangeService;
import com.sfpay.acquirer.service.IPayoutInfoService;
import com.sfpay.acquirer.service.IPayoutQueryService;
import com.sfpay.acquirer.service.SendPayoutResp;
import com.sfpay.coreplatform.order.service.IBankPayService;
import com.sfpay.coreplatform.order.valueobject.dto.PayBeforeRequest;
import com.sfpay.coreplatform.order.valueobject.dto.PayResponse;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.um.domain.User;

@Service("crossborderService")
@HessianExporter
public class CrossborderServiceImpl implements ICrossborderService {
	private static Logger logger = LoggerFactory.getLogger(B2EPayoutServiceImpl.class);
	/**
	 * 平台会员号
	 */
	private Long memberNo = Long.valueOf(Property.getProperty("PLATFORM_MEMBER_NO"));
	@Resource
	private IPayoutExchangeService exchangeService;
	@Resource
	private IBankPayService orderService;
	@Resource
	private SendPayoutResp sendPayoutResp;
	@Resource
	private IParamInfoDao paramInfoDao;
	
	@Resource
	private IOverseasOrdersDao overseasOrdersDao;
	
	@Resource
	private SendPayoutResp sendPayout;
	
	@Override
	public void sendOrder(String id, String payoutStatus, String remark,String userName,Date draftTime) {
		List<PayoutInfo> list = new ArrayList<PayoutInfo>();
		try {
			//String batchCode = getRrqBankSnRandom();
			PayoutInfo info = null;
			String[] ids = id.split(",");
			for (String i : ids) {
				info = new PayoutInfo();
				PayoutStatus status =  PayoutStatus.SUCCESS;
				if(PayoutStatus.FAILURE.toString().equals(payoutStatus)){
					info.setOfflineFlag(YNFlag.Y);
					status  = PayoutStatus.FAILURE;
				}
				info.setId(Long.valueOf(i));
				info.setStatus(status);
				info.setRemark(remark);
				info.setRtnBankCode("0");
				info.setExpectPayDate(draftTime);//登记日期
				info.setRtnBankMsg("手工登记"+status.getText());
				info.setReqBankSn(CUID.generateId4B2E(20));
				info.setPayerOrgCode(BankCode.ICBC);
				info.setBankCode(BankCode.ICBC);
				updatePayOutInfo(info);
				info = overseasOrdersDao.queryById(Long.valueOf(i));
				list.add(info);
			}
			sendOrderReq(list);
			sendPayoutResp.sendOrderResp(list,ExchangeType.SEND_AFTER);
		} catch (Exception e) {
			logger.error("跨境业务出款登记异常", e);
			throw new ServiceException("跨境业务出款登记异常异常", e);
		}
		
	}

	private static String getRrqBankSnRandom(){
		SimpleDateFormat format =new  SimpleDateFormat("yyyyMMddssSSS");
		int random = (int)((Math.random()*(999-100)+100));
		return format.format(new Date())+random;
	}

	@Override
	public IPage<PayoutInfo> queryCrossborderPage(PayoutQueryParam param, int pageNo, int pageSize)
			throws ServiceException {
		Map<String, BigDecimal> res = this.overseasOrdersDao.countCrossborderPage(param);
		long count =  res.get("TOTAL_NUM").longValue();
		List<PayoutInfo> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			list = overseasOrdersDao.queryCrossborderPage(param, start, end);
		}
		return new Page<PayoutInfo>(list, count, pageNo, pageSize);
	}
	
	/**
	 * 方法说明：<br>
	 * 发送请求信息到订单系统
	 *
	 * @param list 发送外系统的数据
	 * @param batchInfo　批次信息
	 */
	private void sendOrderReq(List<PayoutInfo> list){
		
		//生成交互信息
		List<PayoutExchange> ecList = null;
		try{
			ecList = this.exchangeService.createExchangeList(list, ExchangeType.SEND_BEFORE);
		}catch(Exception ex){
			logger.error("生成交互信息(发银行前)异常",ex);
			return;
		}
		
		//发送订单系统
		try{
			List<PayBeforeRequest> outPayout = this.converToOutPayRequest(ecList);
			if(outPayout.size() == 0){
				logger.info("跨境支付——不存在需要发送到订单系统的付款信息(发银行前)");
				return;
			}
			logger.info("开始调用订单系统(发银行前)");
			List<PayResponse> outPayResList = orderService.BankBeforepayAcc(outPayout);
			
			if(outPayResList == null || outPayResList.size() == 0){
				logger.info("跨境支付——订单系统返回结果 = null");
				return;
			}
			logger.info("调用订单系统结束(发银行前),订单系统处理条数size:[{}]",outPayResList.size());
			
			for (PayResponse payInfo:outPayResList){
				try{
					//打印日志
					StringBuffer buf = new StringBuffer();
					buf.append("[payNo:").append(payInfo.getPayNo()).append(",")
						.append("retrunCode:").append(payInfo.getReturnCode()).append(",")
						.append("returnMsg:").append(payInfo.getReturnMsg()).append(",")
						.append("tradeNo:").append(payInfo.getTradeNo()).append(",")
						.append("tradeOutNo:").append(payInfo.getTradeOutNo()).append(",")
						.append("payDate:").append(payInfo.getPayDate()).append("]");
					logger.info("付款信息[交互流水:{}],更新订单系统返回(发银行前)信息:{}",payInfo.getTradeOutNo(),buf.toString());
					this.exchangeService.updateOrderResp(payInfo.getTradeNo(), payInfo.getTradeOutNo(), payInfo.getReturnCode()+"", payInfo.getReturnMsg(), ExchangeType.SEND_BEFORE);
				}catch(Exception ex){
					logger.error("付款信息[交互流水:"+payInfo.getTradeOutNo()+"],更新订单系统返回信息(发银行前)异常 = ",ex);
				}
			}
		}catch(Exception ex){
			logger.error("跨境支付——发送订单系统(发银行前)异常 = ",ex);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 转换订单系统请求对象
	 *
	 * @param infoList
	 * @param batchInfo
	 * @return
	 * @throws Exception
	 */
	private List<PayBeforeRequest> converToOutPayRequest(List<PayoutExchange> infoList) throws Exception {
		List<PayBeforeRequest> outPayout = new ArrayList<PayBeforeRequest>();
		if(infoList == null ||infoList.size() == 0){
			logger.info("不存在需要转换订单系统对象的信息");
			return outPayout;
		}
		
		StringBuffer buf = new StringBuffer();
		for(Iterator<PayoutExchange> it = infoList.iterator();it.hasNext();){
			PayoutExchange info = it.next();
			PayBeforeRequest outPay = new PayBeforeRequest();
			outPay.setBusinessType(com.sfpay.coreplatform.order.common.enums.BusinessType.WIH_OUTPAY);
			outPay.setOrderType(com.sfpay.coreplatform.order.common.enums.OrderType.TRANSFER);
			outPay.setCct(com.sfpay.coreplatform.order.common.enums.CcyType.valueOf(info.getCcy()==CurrencyType.CNY?"RMB":info.getCcy().name()));
			outPay.setTradeOutNo(info.getExchangeNo());
			outPay.setPayAmt(info.getAmt());
			outPay.setPlatformMemberNo(memberNo);

			//打印日志
			buf.append(",{tradeOutNo:").append(outPay.getTradeOutNo())
				.append(",businessType:").append(outPay.getBusinessType())
				.append(",ccy:").append(outPay.getCct())
				.append(",orderType:").append(outPay.getOrderType())
				.append(",payAmt:").append(outPay.getPayAmt())
				.append(",platformMemberNo:").append(outPay.getPlatformMemberNo())
				.append("}");
			outPayout.add(outPay);
		}
		logger.info("需发送订单系统(发银行前)的付款信息 :\n\t{}", buf.substring(1));
		return outPayout;
	}

	@Override
	public int updatePayOutInfo(PayoutInfo payoutInfo) throws ServiceException {
		try {
			//payoutInfo.setSummary(StringUtils.substr(payoutInfo.getSummary(), SUMMARY_LIMIT));
			return  overseasOrdersDao.updateCrossborderById(payoutInfo);
		} catch (Exception e) {
			logger.error("修改跨境登记信息异常", e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE, "修改跨境登记信息异常", e);
		}
	}


	@Override
	public void sendRefund(String id){
		List<ExchangeType> exchangeTypes = Arrays.asList(new ExchangeType[]{ExchangeType.SEND_BEFORE, ExchangeType.SEND_AFTER});
		HashMap<String,List<PayoutExchange>> oldEcMap = new HashMap<String,List<PayoutExchange>>();
		List<PayoutInfo> list = new ArrayList<PayoutInfo>();
		PayoutInfo info = new PayoutInfo();
		info.setId(Long.valueOf(id));
		info.setOfflineFlag(YNFlag.Y);
		info.setOfflineRemark("人工操作退票");
		info.setRtnBankCode("9");
		info.setRtnBankMsg("人工操作退票");
		info.setStatus(PayoutStatus.FAILURE);
		info.setOldStatus(PayoutStatus.SUCCESS);
		try {
			try {
				overseasOrdersDao.updateRefundById(info);
			} catch (Exception e) {
				logger.error("修改退票异常", e);
				throw new ServiceException("修改退票异常",e);
			}
			info = overseasOrdersDao.queryById(Long.valueOf(id));
			PayoutExchange exchange = new PayoutExchange();
			exchange.setPayoutNo(info.getPayoutNo());
			List<PayoutExchange> ecList = exchangeService.queryExchange(exchange, exchangeTypes);
			if(ecList == null || ecList.size()!=2){
				logger.error("付款信息[付款编号:{}],交互信息不完整,不能执行退票.",info.getPayoutNo());
				throw new ServiceException("交互信息不完整,不能执行退票");
			}
			oldEcMap.put(info.getPayoutNo(), ecList);
			list.add(info);
			if(list!=null&&list.size()>0){
				sendPayout.sendBounceResp(list, oldEcMap);
			}else{
				throw new ServiceException("无退票成功的记录，没有数据发送业务系统");
			}
		} catch (Exception e) {
			logger.error("跨境业务退票异常", e);
			throw new ServiceException("跨境业务退票异常", e);
		}
	}


	@Override
	public List<PayoutInfo> queryBankCode() {
		return this.overseasOrdersDao.queryBankCode();
	}


	@Override
	public Map<String, Object> queryCrossBorderTotal(PayoutQueryParam param) {
		Map<String, BigDecimal> total = this.overseasOrdersDao.countCrossborderPage(param);
		Map<String, Object> res = new HashMap<String, Object>();
        res.put("totalNum", total.get("TOTAL_NUM"));
        res.put("totalAmt", total.get("TOTAL_AMT"));
        String maxExportNum =  paramInfoDao.getParameter("MAX_EXCEL_EXPORT_NUM");
        res.put("maxExportNum", maxExportNum);
        return res;
	}
	
}
