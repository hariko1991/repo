package com.sfpay.acquirer.gate.b2e.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.CurrencyUtil;
import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.AccountBalance;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.AccountTransInfo;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.HisAcctTxQueryParam;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.gate.b2e.BaseQuery;
import com.sfpay.acquirer.gate.b2e.domain.BalInfo;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.QueryCurBalInfo;
import com.sfpay.acquirer.gate.b2e.domain.TransDtlInfo;
import com.sfpay.acquirer.gate.b2e.service.IBankService;
import com.sfpay.acquirer.gate.b2e.service.IQuery;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author sfhq272 sfhq272
 * 
 * CreateDate: 2015-6-25
 */
@Service("cmbQuery")
@SuppressWarnings("deprecation")
public class CMBQuery extends BaseQuery implements IQuery {
	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource 
	private IBankService cmbService;
	@Resource
	private IPayoutInfoDao payoutInfoDao;
	

	@Override
	protected AccountBalance convert2AccountBalance(BeanBase bean) {
		AccountBalance result = null;
		try{
			QueryCurBalInfo resp = (QueryCurBalInfo)bean.getBusDetailBeanBase();
			BalInfo balInfo = resp.getBalInfo();

			//转换查询结果
			result = new AccountBalance();
			result.setAccountNo(balInfo.getAccNo()); //银行账号
			result.setCurrencyType(balInfo.getCur());//币种
			result.setCurrentAmt(balInfo.getCurBal()+"");//当前余额
			result.setAvailableAmt(balInfo.getUsableBal()+"");//可用余额
			result.setYesterdayAmt(balInfo.getLastBal()+"");//昨日余额
			result.setRetainAmt(balInfo.getHoldBal()+"");//保留余额
			result.setFrozenAmt(balInfo.getFreezeBal()+"");//冻结余额
			result.setBankCode(BankCode.CMB); //银行编码
			result.setQueryDate(DateUtil.getDateFormatStr(resp.getSendTime(), DateUtil.DATA_FORMAT_PATTERN));//查询时间 20130103124300000051
			logger.info("余额信息:{}",result.toString());
		}catch(Exception ex){
			logger.error("查询余额异常",ex);
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "查询余额异常", ex);
		}
		return result;
	}

	@Override
	protected List<AccountTransInfo> convert2CurAccountTransInfoList(
			List<TransDtlInfo> transInfos) {

		List<AccountTransInfo> respList = new ArrayList<AccountTransInfo>();
		//迭代封装接口返回对象
		try{
			for(TransDtlInfo transDtlInfo : transInfos){
				respList.add(setAccountTransInfo(transDtlInfo));
			}
		}catch(Exception ex){
			logger.error("查询当天交易异常",ex);
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "查询当天交易异常", ex);
		}
		return respList;
	}
	
	private AccountTransInfo setAccountTransInfo(TransDtlInfo transDtlInfo){
		AccountTransInfo trans = new AccountTransInfo();
		trans.setAccountNo(transDtlInfo.getAccNo());//账号
		trans.setAccountName(transDtlInfo.getAccName());
		trans.setBalanceAmt(CurrencyUtil.fen2Yuan(transDtlInfo.getBalance()));//余额
		trans.setBankCode(BankCode.CMB);//银行编码
		trans.setBankTxSn(transDtlInfo.getBankSerialid());//银行交易流水号
		String drcrf = transDtlInfo.getCdSign();//1:借 0:贷
		if("C".equals(drcrf)){
			trans.setCrAmt(transDtlInfo.getAmt()+"");//贷方金额
		}else if("D".equals(drcrf)){
			trans.setDrAmt(transDtlInfo.getDrAmt()+"");//借方金额
		}
		trans.setRemark("");//备注
		trans.setSummary(transDtlInfo.getUserfor());//摘要
		trans.setTransDate(transDtlInfo.getTransDate());
		trans.setTransTimes(transDtlInfo.getTransTimes());
		trans.setTxDate(transDtlInfo.getTransTime());//交易日期
		if(StringUtils.isNotBlank(transDtlInfo.getPayeeAccName())&&StringUtils.isNotBlank(transDtlInfo.getPayeeAccNo())){
			trans.setReverseAcctName(transDtlInfo.getPayeeAccName());//对方单位名称
			trans.setReverseAcctNo(transDtlInfo.getPayeeAccNo());//对方单位账号
		}else{
			PayoutInfo info =payoutInfoDao.queryPayoutInfo(null, transDtlInfo.getSerialId());
			if(info==null)
				trans.setSummary("该信息已被删除");//摘要
		}
		return trans;
	}

	@Override
	protected List<AccountTransInfo> convert2HisAccountTransInfoList(
			List<TransDtlInfo> transInfos) {

		List<AccountTransInfo> respList = new ArrayList<AccountTransInfo>();
		//迭代封装接口返回对象
		try{
			for(TransDtlInfo transDtlInfo : transInfos){
				respList.add(setAccountTransInfo(transDtlInfo));
			}
		}catch(Exception ex){
			logger.error("查询历史交易异常",ex);
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "查询历史交易异常",ex);
		}
		return respList;
	}

	@Override
	public AccountBalance queryAccountBalance(BankProperty property,
			AccountInfo acct) throws ServiceException {
		return super.doQueryAccountBalance(property, acct, cmbService);
	}

	@Override
	public List<AccountTransInfo> queryCurAccountTransList(
			BankProperty property, AccountInfo acct) throws ServiceException {
		return super.doQueryCurAccountTransList(property, acct, cmbService);
	}

	@Override
	public List<AccountTransInfo> queryHisAccountTransList(
			BankProperty property, HisAcctTxQueryParam param)
					throws ServiceException {
		return super.doQueryHisAccountTransList(property, param, cmbService);
	}


}
