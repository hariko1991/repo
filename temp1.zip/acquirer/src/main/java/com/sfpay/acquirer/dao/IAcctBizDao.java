/**
 * 
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.AcctBizDetail;
import com.sfpay.acquirer.domain.AcctBizQueryParam;

/**
 * 类说明：
 * 银行账户业务详情 dao  
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 * @author 329202 符瑜鑫(Ricky Fu)
 *   
 * CreateDate: 2012-5-29
 */
public interface IAcctBizDao {

	/**
	 * 方法说明：
	 * 分页查询银行账户业务详情 总条数
	 * @param map 查询条件
	 * @return
	 */
	public long queryAcctBizPageCount(@Param("param") AcctBizQueryParam param);
	
	/**	 
	 * 方法说明：
	 * 分页查询银行账户业务详情 当页数据
	 * @param map 查询条件
	 * @return
	 */
	public List<AcctBizDetail> queryAcctBizPageList(@Param("param") AcctBizQueryParam param, @Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：
	 * 查询银行渠道订单类型资金方向记录数
	 * @param channelCode 渠道编码
	 * @param bankCode 银行编码
	 * @param orderType 订单类型
	 * @param fundWay 资金方向
	 * @return
	 */
	public long queryBankChannelCount(@Param("param") AcctBizDetail acctBiz);
	
	/**
	 * 
	 *
	 * 方法说明：
	 * 添加
	 * @param acctBiz
	 */
	public void addAcctBiz(AcctBizDetail acctBiz);
	
	/**
	 * 
	 *
	 * 方法说明：
	 * 删除
	 * @param id
	 */
	public void deleteAcctBiz(long id);
}
