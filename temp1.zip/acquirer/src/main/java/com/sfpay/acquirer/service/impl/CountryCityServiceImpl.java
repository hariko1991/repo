/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.dao.ICountryCityDao;
import com.sfpay.acquirer.domain.CountryCity;
import com.sfpay.acquirer.service.ICountryCityService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：<br>
 * 省份城市地区码 service实现
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2012-10-23
 */
@Service("countryCityService")
@HessianExporter
public class CountryCityServiceImpl implements ICountryCityService {
	
	@Resource
	private ICountryCityDao countryCityDao;
	
	@Override
	public List<CountryCity> queryProvince() throws ServiceException{
		return countryCityDao.queryProvince();
	}

	@Override
	public List<CountryCity> queryByParentCode(String countryCode) throws ServiceException{
		if(countryCode == null){
			throw new ServiceException(InfoCode.PARAM_INVALID, "countryCode can't be null");
		}
		return countryCityDao.queryByParentCode(countryCode);
	}

	@Override
	public List<CountryCity> queryProvinceByName(String name) {
		if(name == null){
			throw new ServiceException(InfoCode.PARAM_INVALID, "参数不能为空");
		}
		return countryCityDao.queryProvinceByName(name);
	}
	
}
