/**
 * 
 */
package com.sfpay.acquirer.dao.rb;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.rb.BankReconFileRlt;
import com.sfpay.acquirer.domain.rb.szfs.BankReconFile;

/**
 * 
 * @author sfhq272
 *
 */
public interface IBankReconFileDao {
	
	
	public void importSZFSReconFile(@Param("tradeTime")Date tradeTime, @Param("curTime")Date curTime) throws Exception;
	
	
	public void addSZFSReconList(List<BankReconFile> szfsReconList);
	
	
	public long countBankRecon(@Param("param") BankReconFileRlt param);
	
	
	public BankReconFileRlt countAmt(@Param("param") BankReconFileRlt param);
	
	
	public List<BankReconFileRlt> findBankReconList(@Param("param") BankReconFileRlt param, @Param("start") int start, @Param("end") int end);
	
	
	public List<BankReconFileRlt> exportBankReconList(@Param("param") BankReconFileRlt param);
	
	
	public void exceptionCmd(@Param("param")BankReconFileRlt param);
	
	public Long queryBadDebitAmout(@Param("param")BankReconFileRlt param);
	
	public int deleteBankReconFileCurday();
	public int deleteBankOuterFileCurday();
	public int deleteBankInnerFileCurday();
	
}
