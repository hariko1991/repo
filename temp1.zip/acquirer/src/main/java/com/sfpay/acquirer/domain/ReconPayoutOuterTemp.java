package com.sfpay.acquirer.domain;

import java.util.Date;

import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.ReconOutStatus;
import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-8-14
 */
public class ReconPayoutOuterTemp extends BaseEntity{
	
	private static final long serialVersionUID = 9121451920549910472L;

	/**
	 * OUT_EXCHANGE_NO	N	VARCHAR2(30)	N			外部交互流水号
	 */
	private String outExchangeNo;
	
	/**
	 * OUT_AMT	N	NUMBER(16)	N			外部金额
	 */
	private Long outAmt;
	
	/**
	 * OUT_CCY	N	CHAR(3)	Y			外部币种
	 */
	private CurrencyType outCcy;
	
	/**
	 * OUT_TRADE_DATE	N	DATE	N			外部交易时间
	 */
	private Date outTradeDate;
	
	/**
	 * OUT_STATUS	N	VARCHAR2(20)	N			外部状态 SUCCESS成功 
	 */
	private ReconOutStatus outStatus;

	public String getOutExchangeNo() {
		return outExchangeNo;
	}

	public void setOutExchangeNo(String outExchangeNo) {
		this.outExchangeNo = outExchangeNo;
	}

	public Long getOutAmt() {
		return outAmt;
	}

	public void setOutAmt(Long outAmt) {
		this.outAmt = outAmt;
	}

	public CurrencyType getOutCcy() {
		return outCcy;
	}

	public void setOutCcy(CurrencyType outCcy) {
		this.outCcy = outCcy;
	}

	public Date getOutTradeDate() {
		return outTradeDate;
	}

	public void setOutTradeDate(Date outTradeDate) {
		this.outTradeDate = outTradeDate;
	}

	public ReconOutStatus getOutStatus() {
		return outStatus;
	}

	public void setOutStatus(ReconOutStatus outStatus) {
		this.outStatus = outStatus;
	}
	

}
