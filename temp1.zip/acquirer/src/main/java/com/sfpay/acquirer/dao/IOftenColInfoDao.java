package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.OftenColInfo;
import com.sfpay.acquirer.domain.OftenColInfoQueryParam;

/**
 * 类说明：<br>
 * 常用收款单位表信息  
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 349508 韦健
 * @author 312932 何国兴
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2012-11-12
 */
public interface IOftenColInfoDao  {
	/**
	 * 方法说明：
	 * 分页查询常用收款单位信息       总条数
	 * @param map 查询条件
	 * @return
	 */
	public long queryOftenColInfoPageCount(@Param("param") OftenColInfoQueryParam param);
	
	/**
	 * 方法说明：
	 * 分页查询常用收款单位信息      当页数据
	 * @param map 查询条件
	 * @return
	 */ 
	public List<OftenColInfo> queryOftenColInfoPageList(@Param("param") OftenColInfoQueryParam param, @Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：
	 * 根据主键id查询常用收款单位信息 
	 * @param map 查询条件
	 * @return
	 */
	public OftenColInfo queryOftenColInfoById(@Param("id") long id);
	
	/**
	 * 方法说明：
	 * 根据账号查询常用收款单位信息
	 * 存在则只会有一条记录，不存在返回null
	 * @param accountNo 账号
	 * @return
	 */
	public OftenColInfo queryOftenColInfoByAcctNo(@Param("accountNo") String accountNo);
	
	/**
	 * 方法说明：
	 * 查询所以常用收款单位信息       
	 * @return
	 */
	public List<OftenColInfo> listAllOftenColInfo();
	
	/**
	 * 方法说明：
	 * 增加常用收款单位信息
	 * @param map 查询条件
	 * @return
	 */
	public void addOftenColInfo(@Param("param") OftenColInfo param);
	
	/**
	 * 方法说明：<br>
	 * 
	 * @param param
	 */
	public void saveOrUpdateOften(OftenColInfo param);
	
	/**
	 * 方法说明：
	 * 修改常用收款单位信息 
	 * @param map 查询条件
	 * @return
	 */         
	public void updateOftenColInfoById(@Param("param") OftenColInfo param);
	
	/**
	 * 方法说明：
	 * 删除常用收款单位信息
	 * @param map 查询条件
	 * @return
	 */
	public void deleteOftenColInfo(@Param("ids") List<Long>ids); 
	
	
	/**
	 * 方法说明：<br>
	 * 
	 * @param param
	 */
	public void saveOrUpdateEcsOften(OftenColInfo param);
	
	
	
	/**
	 * 方法说明：
	 * 手动分页查询常用收款单位信息       总条数
	 * @param map 查询条件
	 * @return
	 */
	public long queryEcsOftenColInfoPageCount(@Param("param") OftenColInfoQueryParam param);
	
	/**
	 * 方法说明：
	 * 分页查询常用收款单位信息      当页数据
	 * @param map 查询条件
	 * @return
	 */ 
	public List<OftenColInfo> queryEcsOftenColInfoPageList(@Param("param") OftenColInfoQueryParam param, @Param("start") int start, @Param("end") int end);

}
