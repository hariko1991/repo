package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sfpay.acquirer.dao.IChannelRateInfoDao;
import com.sfpay.acquirer.domain.ChannelRateInfo;
import com.sfpay.acquirer.domain.ChannelRateInfoQueryParam;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.ChargeType;
import com.sfpay.acquirer.service.IChangelRateService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 
 * 类说明：
 * 支付渠道费用设置以及维护实现类
 * 
 * <p/>
 * 详细描述：
 * 银行支付渠道费用设置    
 * 
 * @author 349508 韦健
 *   
 * CreateDate: 2012-8-10
 */
@Deprecated
@Service("changelRateService")
@HessianExporter
public class ChangelRateServiceImpl implements IChangelRateService{
	@Resource
	private IChannelRateInfoDao channelRateInfoDao;
/**
 * 列表分页显示
 */
	public IPage<ChannelRateInfo> queryChannelRateInfoPage(ChannelRateInfoQueryParam param, int pageNo, int pageSize) throws ServiceException {
		//查询总记录数
		long count = channelRateInfoDao.queryChannelRateInfoPageCount(param);
		IPage<ChannelRateInfo> page = null;
		if(count != 0){
			if(pageNo <= 0){
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			//查询当前页记录
			List<ChannelRateInfo> list = channelRateInfoDao.queryChannelInfoPageList(param, start, end);
			page = new Page<ChannelRateInfo>(list, count, pageNo, pageSize);
		}	
		return page;
	}
	
	/**
	 * 根据支付的金额，银行码查询出对应的手续费率，打折率
	 * @param payCost
	 * @param bankCode
	 * @param channelCode
	 * @param chargeType
	 * @return
	 */
	public ChannelRateInfo queryChannelRateInfo(Long payCost, BankCode bankCode,ChannelCode channelCode,ChargeType chargeType){
		ChannelRateInfo rate = channelRateInfoDao.queryChannelRateInfo(payCost, bankCode , channelCode,chargeType);
		if(rate == null){
			rate = new ChannelRateInfo();
			rate.setFeeRate(0.0d);
		}
		return rate;
	}
	/**
	 * 添加支付渠道费用信息
	 * @param param
	 */
	public void addChannelRateInfo(ChannelRateInfoQueryParam param){
		channelRateInfoDao.addChannelRateInfo(param);
	}
	
	/**
	 * 修改支付渠道费用信息
	 */
	public void updateChannelRateInfo(ChannelRateInfoQueryParam param){
		channelRateInfoDao.updateChannelRateInfo(param);
	}
	
}
