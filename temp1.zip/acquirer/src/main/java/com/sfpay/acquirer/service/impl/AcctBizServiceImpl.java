/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.dao.IAcctBizDao;
import com.sfpay.acquirer.domain.AcctBizDetail;
import com.sfpay.acquirer.domain.AcctBizQueryParam;
import com.sfpay.acquirer.service.IAcctBizService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 
 * 类说明：
 * 银行账户业务详情 实现
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-5-28
 */
@Deprecated
@Service("acctBizService")
@HessianExporter
public class AcctBizServiceImpl implements IAcctBizService {

	@Resource
	private IAcctBizDao acctBizDao;
	
	@Override
	public IPage<AcctBizDetail> queryAcctBizPage(AcctBizQueryParam param, int pageNo, int pageSize) throws ServiceException {
		//查询总记录数
		long count = acctBizDao.queryAcctBizPageCount(param);
		IPage<AcctBizDetail> page = null;
		List<AcctBizDetail> list = null;
		if(count!=0){
			if(pageNo<=0){
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			//查询当前页记录
			list = acctBizDao.queryAcctBizPageList(param, start, end);
			page = new Page<AcctBizDetail>(list,count,pageNo,pageSize);
		}	
		return page;
	}
	
	@Override
	public void saveAcctBiz(AcctBizDetail acctBiz) throws ServiceException {
		//判断
		if(acctBiz.getChannelCode()==null){
			throw new ServiceException(InfoCode.CHANNEL_CODE_IS_NULL,"channelCode is null");
		}
		if(acctBiz.getBankCode()==null){
			throw new ServiceException(InfoCode.BANK_CODE_IS_NULL,"bankCode is null");
		}
		if(acctBiz.getOrderType()==null){
			throw new ServiceException(InfoCode.ORDER_TYPE_IS_NULL,"orderType is null");
		}
		if(acctBiz.getFundWay()==null){
			throw new ServiceException(InfoCode.FUND_WAY_IS_NULL,"fundType is null");
		}
		if(acctBiz.getAccountNo()==null){
			throw new ServiceException(InfoCode.ACCOUNT_NO_IS_NULL,"accountNo is null");
		}
		//增加前判断是否重复		
		long ct = acctBizDao.queryBankChannelCount(acctBiz);
		if(ct>0){
			throw new ServiceException(InfoCode.EXIST_BANK_CHANNEL_FUNDWAY,"exist bank channel fundway ");
		}
		//增加
		acctBizDao.addAcctBiz(acctBiz);
	}

	
	@Override
	public void deleteAcctBiz(long id) throws ServiceException {		
		acctBizDao.deleteAcctBiz(id);		
	}

}
