package com.sfpay.acquirer.service.common;

import javax.annotation.Resource;

import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.gate.b2e.service.IQuery;

/**
 * 
 * 类说明：<br>
 * service 的公共实现部分
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author sfhq272 sfhq272
 * 
 * CreateDate: 2015-7-7
 */
public class BankCommonService {
	
	@Resource
	private IQuery cmbQuery;
	@Resource
	private IQuery icbcQuery;
	
	protected IQuery getIQuery(BankCode bankCode){
		if(bankCode.name().equals(BankCode.ICBC.name())){
			return icbcQuery;
		}else if(bankCode.name().equals(BankCode.CMB.name())){
			return cmbQuery;
		}else{
			return null;
		}
	}
}
