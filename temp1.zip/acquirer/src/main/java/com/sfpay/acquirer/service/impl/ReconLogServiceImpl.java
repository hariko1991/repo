package com.sfpay.acquirer.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.dao.IReconLogDao;
import com.sfpay.acquirer.domain.ReconLog;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.service.IReconLogService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
/**
 * 
 * 类说明：
 * 日志维护service  
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 349508 韦健
 * @author 329202 符瑜鑫(Ricky Fu)
 *   
 * CreateDate: 2012-8-28
 */
@Deprecated
@Service("reconLogService")
public class ReconLogServiceImpl implements IReconLogService {
	
	@Resource
	private IReconLogDao reconLogDao;
	
	/**
	 * 插入到日志表中
	 */
	public void insertReconLog(String logLevel,String logContent) throws ServiceException {
		reconLogDao.insertReconLog(logLevel,logContent);
	}
	
	/**
     * 统计对账结算后的成功笔数，失败笔数，丢单笔数，调单笔数，时间性差异笔数
     * @param bankCode
     * @param channelCode
     * @return
     * @throws Exception
     */
	public String totalReconCollectRlt(BankCode bankCode, ChannelCode channelCode) throws ServiceException {
		String strDate = DateUtil.getDateString(new Date(), "yyyy-MM-dd");
		return reconLogDao.totalReconCollectRlt(strDate, bankCode, channelCode);
	}
	
	/**
	 * 查询对账结果表在对账前的核查统计总条数
	 * @param tradeDate
	 * @param bankCode
	 * @param channelCode
	 * @return
	 * @throws Exception 
	 */
	public Long totalReconCollectRltCount(String tradeDate,BankCode bankCode,ChannelCode channelCode) throws ServiceException {
		return reconLogDao.totalReconCollectRltCount(tradeDate, bankCode, channelCode);
	}

	
	@Override
	public IPage<ReconLog> findReconLogPage(Date createTime, int pageNo, int pageSize) throws ServiceException {				
		//查询总记录数
		long count = reconLogDao.queryReconLogCount(createTime);
		List<ReconLog> list = null;
		pageNo = pageNo <= 0 ? 1 : pageNo;
		pageSize = pageSize <= 0 ? 10 : pageSize;
		if(count > 0){
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			//查询当前页记录
			list = reconLogDao.queryReconLogList(createTime, start, end);
		}	
		return new Page<ReconLog>(list, count, pageNo, pageSize);
	}

}
