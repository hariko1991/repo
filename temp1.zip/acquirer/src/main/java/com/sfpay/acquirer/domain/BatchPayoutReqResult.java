package com.sfpay.acquirer.domain;

import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.acquirer.enums.ChannelPayType;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.gate.b2e.domain.SinglePayInfo;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;

/**
 * 用于工行、深圳结算中心的指量支付请求结果。
 * 对应于指令：TradeCodeB2E.BATCH_PAYOFF、BATCH_AGENT_TRANSFER、TradeCodeB2E.BATCH_TRANSFER
 * @author sfhq534
 *
 */
public class BatchPayoutReqResult extends PayoutReqResult {

	/**
	 * 提供信息格式的封装类，不同情况有不同的子类，但尽量重用。
	 * 应该从源头进行信息的分类处理，避免过多的if else 耦合。通过子类的继承变化可降低if else 对于 OCP原则的入侵。

	 * @return 
	 * @throws Exception 
	 */
	public  BatchPayoutReqResult(
			com.sfpay.acquirer.gate.b2e.domain.BeanBase respBean) throws Exception{
		super.parseMsg(respBean);
		//只有批量支付才需要设置批量状态
		if(this.getStatus()==null){
			this.setStatus(BatchStatus.convertToBatchStatus(respBean.getBusDetailBeanBase().getRetCode()));		
		}
	}
}
