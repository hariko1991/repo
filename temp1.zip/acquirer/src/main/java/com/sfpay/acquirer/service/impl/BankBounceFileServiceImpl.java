package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.dao.rb.IBankBounceFileDao;
import com.sfpay.acquirer.domain.rb.BankBounceFileRlt;
import com.sfpay.acquirer.domain.rb.szfs.BankBounceFile;
import com.sfpay.acquirer.service.IBankBounceFileService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * @author sfhq272
 *
 */
@HessianExporter
@Service("bankBounceFileService")
public class BankBounceFileServiceImpl  implements IBankBounceFileService {
	private static final Logger logger = LoggerFactory.getLogger(BankBounceFileServiceImpl.class);
	@Resource
	private IBankBounceFileDao bankBounceFileDao;

	@Override
	public IPage<BankBounceFileRlt> findBankBounceList(BankBounceFileRlt param, int pageNo, int pageSize)throws ServiceException {
		logger.info("findBankBounceList开始,参数是{}", param);
		//查询总记录数
		long count = bankBounceFileDao.countBankBounce(param);
		List<BankBounceFileRlt> list = null;
		pageNo = pageNo <= 0 ? 1 : pageNo;
		pageSize = pageSize <= 0 ? 10 : pageSize;
		if(count > 0){
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			//查询当前页记录
			list = bankBounceFileDao.findBankBounceList(param, start, end);
		}	
		logger.info("findBankBounceList结束");
		return new Page<BankBounceFileRlt>(list, count, pageNo, pageSize);
	}

	@Override
	public long countBankBounce(BankBounceFileRlt param) throws ServiceException {
		logger.info("countBankBounce开始,参数是{}", param);
		long count  = bankBounceFileDao.countBankBounce(param);
		logger.info("countBankBounce结束,返回count：{}",count);
		return count;
	}


	@Override
	public List<BankBounceFileRlt> exportBankBounceList(BankBounceFileRlt param)
			throws ServiceException {
		return bankBounceFileDao.exportBankBounceList(param);
	}

	@Override
	public void exceptionCmd(String reqBankSn, String updateId) throws ServiceException {
		logger.info("exceptionCmd开始, 参数reqBankText：{} ,updateId:{}",reqBankSn,updateId);
		if(null==reqBankSn){
			throw new ServiceException("没有选择可操作的付款流水");
		}
		BankBounceFile bankBounceFile = new BankBounceFile();
		
		bankBounceFile.setUpdateId(updateId);
		bankBounceFile.setHandleFlag("1");
		bankBounceFile.setReqBankSn(reqBankSn);
		bankBounceFileDao.exceptionCmd(bankBounceFile);
		logger.info("reqBankSn ：{} 更新退票信息成功",reqBankSn);
	}

}
