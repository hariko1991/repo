/**
 * 
 */
package com.sfpay.acquirer.domain;

import java.util.Date;

import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.CardType;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.acquirer.enums.ReconOutStatus;
import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 
 * 类说明：
 * 外部记录对账临时表实体 
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-5-9
 */
public class ReconOutTmp extends BaseEntity {
		
	private static final long serialVersionUID = -968257651929205512L;

	/**
	 * 渠道编码
	 */
	private ChannelCode channelCode;
	
	/**
	 * 银行编码
	 */
	private BankCode bankCode;
	
	/**
	 * 外部交易流水号
	 */
	private String outSeqNo;
		
	/**
	 * 外部记录交易金额
	 */
	private Long amt;
	
	/**
	 * 外部记录的状态
	 */
	private ReconOutStatus outStatus;
	
	/**
	 * 外部记录交易时间
	 */
	private Date outTradeDate;
	
	/**
	 * 外部卡类型
	 */
	private CardType outCardType;
	
	/**
	 * 外部订单类型
	 */
	private OrderType outOrderType;
	
	/**
	 * 手续费
	 */
	private Long outFee;
	
	public ReconOutTmp(){
	}

	public ReconOutTmp(BankCode bankCode, ChannelCode channelCode) {
		this.channelCode = channelCode;
		this.bankCode = bankCode;
	}

	public ChannelCode getChannelCode() {
		return channelCode;
	}

	public Long getOutFee() {
		return outFee;
	}

	public void setOutFee(Long outFee) {
		this.outFee = outFee;
	}

	/**
	 * 渠道编码
	 */
	public void setChannelCode(ChannelCode channelCode) {
		this.channelCode = channelCode;
	}

	/**
	 * 方法说明：<br>
	 * 外部卡类型
	 *
	 * @return
	 */
	public CardType getOutCardType() {
		return outCardType;
	}

	public void setOutCardType(CardType outCardType) {
		this.outCardType = outCardType;
	}

	/**
	 * 方法说明：<br>
	 * 外部订单类型
	 *
	 * @return
	 */
	public OrderType getOutOrderType() {
		return outOrderType;
	}

	public void setOutOrderType(OrderType outOrderType) {
		this.outOrderType = outOrderType;
	}

	public BankCode getBankCode() {
		return bankCode;
	}

	/**
	 * 银行编码
	 */
	public void setBankCode(BankCode bankCode) {
		this.bankCode = bankCode;
	}

	public String getOutSeqNo() {
		return outSeqNo;
	}

	/**
	 * 外部交易流水号,即支付公司发送给银行的商品订单号.<br>
	 * <span style="color:red;">注:此值与{@link PaymentParam#setSerieNo()}相同</span>
	 */
	public void setOutSeqNo(String outSeqNo) {
		this.outSeqNo = outSeqNo;
	}

	public Long getAmt() {
		return amt;
	}

	/**
	 * 外部记录交易金额
	 */
	public void setAmt(Long amt) {
		this.amt = amt;
	}

	public ReconOutStatus getOutStatus() {
		return outStatus;
	}

	/**
	 * 外部记录的状态
	 */
	public void setOutStatus(ReconOutStatus outStatus) {
		this.outStatus = outStatus;
	}

	public Date getOutTradeDate() {
		return outTradeDate;
	}

	/**
	 * 外部记录交易时间
	 */
	public void setOutTradeDate(Date outTradeDate) {
		this.outTradeDate = outTradeDate;
	}

}
