package com.sfpay.acquirer.service;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IPayoutExchangeDao;
import com.sfpay.acquirer.domain.PayoutExchange;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.enums.ExchangeStatus;
import com.sfpay.acquirer.enums.ExchangeType;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 
 * 类说明：<br>
 * 付款交互接口实现
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-8-13
 */
@Service
public class PayoutExchangeService implements IPayoutExchangeService{
	private static Logger logger = LoggerFactory.getLogger(B2EPayoutServiceImpl.class);
	private static final boolean isDebug = logger.isDebugEnabled();
	
	@Resource
	private IPayoutExchangeDao dao;
	
	/**
	 * 生成交互信息
	 */
	@Override
	public PayoutExchange createExchange(PayoutInfo info,ExchangeType exchangeType) throws ServiceException {
		if(info == null){
			throw new ServiceException(InfoCode.PARAM_INVALID,"生成交互信息:付款信息为空");
		}
		if(StringUtils.isEmpty(info.getPayoutNo())){
			throw new ServiceException(InfoCode.PARAM_INVALID,"生成交互信息:付款编号为空");
		}
		if(info.getCcy() == null){
			throw new ServiceException(InfoCode.PARAM_INVALID,"生成交互信息:币种为空");
		}
		if(exchangeType == null){
			throw new ServiceException(InfoCode.PARAM_INVALID,"生成交互信息:交互类型为空");
		}
		
		//判断记录是否存在
		boolean flag = isExist(info, exchangeType, null);
		if(flag){
			return null;
		}
		
		//转换信息
		PayoutExchange ec = this.conver(info, exchangeType,null);
		
		//添加数据库
		try {
			dao.saveExchange(ec);
		} catch (Exception e) {
			logger.error("生成交互信息异常",e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE,"生成交互信息异常:"+e);
		}
		
		return ec;
	}
	
	/**
	 * 生成退票交互信息
	 */
	@Override
	public List<PayoutExchange> createBounceExchange(PayoutInfo info,List<PayoutExchange> oldExchanges,ExchangeType exchangeType) throws ServiceException {
		if(info == null){
			throw new ServiceException(InfoCode.PARAM_INVALID,"生成交互信息:付款信息为空");
		}
		if(StringUtils.isEmpty(info.getPayoutNo())){
			throw new ServiceException(InfoCode.PARAM_INVALID,"生成交互信息:付款编号为空");
		}
		if(info.getCcy() == null){
			throw new ServiceException(InfoCode.PARAM_INVALID,"生成交互信息:币种为空");
		}
		if(exchangeType == null){
			throw new ServiceException(InfoCode.PARAM_INVALID,"生成交互信息:交互类型为空");
		}
		if(oldExchanges == null || oldExchanges.size() == 0){
			throw new ServiceException(InfoCode.PARAM_INVALID,"生成交互信息:原交互信息为空");
		}
		
		List<PayoutExchange> ecList = new ArrayList<PayoutExchange>();
		for(PayoutExchange old : oldExchanges){
			String oldExchangeNo = old.getExchangeNo();
			if(StringUtils.isEmpty(oldExchangeNo)){
				logger.error("[付款编号:{}+交互类型:{}]的原交互流水号为空",info.getPayoutNo(),exchangeType);
				throw new ServiceException(InfoCode.PARAM_INVALID,String.format("[付款编号:%s+交互类型:%s]的原交互流水号为空",info.getPayoutNo(),exchangeType));
			}
			
			//判断记录是否存在
			boolean flag = isExist(info, exchangeType, old.getExchangeNo());
			if(flag){
				continue;
			}
			
			//转换信息
			PayoutExchange ec = this.conver(info, exchangeType,old.getExchangeNo());
			//添加数据库
			try {
				dao.saveExchange(ec);
			} catch (Exception e) {
				logger.error("生成交互信息异常",e);
				throw new ServiceException(InfoCode.DATABASE_FAILURE,"生成交互信息异常:"+e);
			}
			if(ec != null){
				ecList.add(ec);
			}
		}
		return ecList;
	}


	/**
	 * 批量生成交互信息
	 */
	@Override
	public List<PayoutExchange> createExchangeList(List<PayoutInfo> ps,ExchangeType exchangeType) throws ServiceException {
		if(ps == null || ps.size() == 0){
			throw new ServiceException(InfoCode.PARAM_INVALID,"批量生成交互信息:付款信息为空");
		}
		if(exchangeType == null){
			throw new ServiceException(InfoCode.PARAM_INVALID,"生成交互信息:交互类型为空");
		}
		
		//转换信息
		List<PayoutExchange> ecList = new ArrayList<PayoutExchange>();
		for(PayoutInfo info : ps){
			PayoutExchange ec = createExchange(info, exchangeType);
			if(ec != null){
				ecList.add(ec);
			}
		}
		return ecList;
	}
	
	@Override
	public void updateOrderResp(String tradeNo,
			String exchangeNo,
			String returnCode,
			String returnMsg,
			ExchangeType exchangeType)
			throws ServiceException {
		if(isDebug){
			logger.debug(String.format("更新交互信息:交互流水号[%s],交易号[%s],返回码[%s],返回描述[%s]"
					,exchangeNo,tradeNo,returnCode,returnMsg));
		}
		
		PayoutExchange ec = new PayoutExchange();
		ec.setOutTradeNo(tradeNo);
		ec.setRtnCode(returnCode+"");
		ec.setRtnMsg(returnMsg);
		ec.setExchangeNo(exchangeNo);
		//<0就是失败的，如果>10000就是原来已经支付成功的
		if(0 < Integer.parseInt(returnCode)){
			ec.setStatus(ExchangeStatus.SUCCESS);
		}else{
			ec.setStatus(ExchangeStatus.FAUILURE);
		}
		
		
		try {
			int cnt = dao.updateOrderResp(ec);
			if(isDebug){
				logger.debug("更新交互信息条数:[{}]",cnt);
			}
		} catch (Exception e) {
			logger.error("更新交互信息异常",e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE,"更新交互信息异常:"+e);
		}
	}
	

	/**
	 * 方法说明：<br>
	 * 判断记录是否存在
	 *
	 * @return
	 */
	private boolean isExist(PayoutInfo info,ExchangeType exchangeType,String revExchangeNo){
		//判断记录是否存在
		PayoutExchange ec = null;
		try {
			ec = dao.selectExchange(info.getPayoutNo(), exchangeType,revExchangeNo);
		} catch (Exception ex) {
			logger.error("查询交互信息(检查)异常",ex);
			throw new ServiceException(InfoCode.DATABASE_FAILURE,"查询交互信息(检查)异常:"+ex);
		}
		if(ec != null){
			logger.warn("交互信息[{}+{}]已经存在",info.getPayoutNo(),exchangeType);
			return true;
		}
		return false;
	}
	
	/**
	 * 方法说明：<br>
	 * 转换交互对象
	 *
	 * @param info
	 * @param exchangeType
	 * @return
	 * @throws ServiceException
	 */
	private PayoutExchange conver(PayoutInfo info,ExchangeType exchangeType,String revExchangeNo) throws ServiceException{
		PayoutExchange ec = new PayoutExchange();
		ec.setPayoutNo(info.getPayoutNo());
		ec.setAmt(info.getAmt());
		ec.setCcy(info.getCcy());
		ec.setExchangeType(exchangeType);
		ec.setRemark("付款状态:"+info.getStatus());
		ec.setStatus(ExchangeStatus.TRADING);
		ec.setRevExchangeNo(revExchangeNo);
		
		return ec;
	}

	/**
	 * 方法说明：<br>
	 * 根据付款编号查询交互信息(如交互类型不为空，则查询所属交互类类型的交互信息)
	 *
	 * @param PayoutNo
	 * @param exchangeTypes
	 * @throws ServiceException
	 */
	@Override
	public List<PayoutExchange> queryExchange(PayoutExchange info,List<ExchangeType> exchangeTypes) throws ServiceException{
		if(info == null){
			throw new ServiceException(InfoCode.PARAM_INVALID, "param can't be null");
		}
		
		try {
			return dao.queryExchange(info, exchangeTypes);
		} catch (Exception e) {
			logger.error("查询交互信息异常",e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE, "查询交互信息异常:"+e);
		}
	}

	
}
