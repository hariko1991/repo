/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.domain;

import org.apache.commons.digester3.Digester;

import com.sfpay.acquirer.enums.ReconChangeStatus;

/**
 * 类说明：<br>
 * 各业务系统执行"红冲"、"补单"、"先红冲后补单"调账后的返回结果定义.对应的报文见详细描述.<br>
 * 各业务系统返回该报文使用如下模式:<pre><code>
 * private void writeResp(HttpServletResponse resp, StringBuffer xml) {
 *   resp.setContentType("text/plain;charset=UTF-8");
 *   try {
 *     PrintWriter out = resp.getWriter();
 *     out.println(xml.toString());
 *   } catch (Exception e) {
 *     logger.error("返回信息流写入异常", e);
 *   }
 * }
 * </code></pre>
 * 
 * <p>
 * 详细描述：<br>
 * 返回结果为xml, 格式如下:<pre>{@code
 * <?xml version="1.0" encoding="UTF-8" ?>
 * <result>
 *   <reverse>
 *     <businessSn>001</businessSn>
 *     <payNo>002</payNo>
 *     <tradeNo>003</tradeNo>
 *   </reverse>
 *   <resupply>
 *     <businessSn>001</businessSn>
 *     <payNo>002</payNo>
 *     <tradeNo>003</tradeNo>
 *   </resupply>
 *   <status>FAILURE</status>
 *   <failReason>超时</failReason>
 * </result>
 * }</pre>
 * 其中, <code>status值为{@link ReconChangeStatus}</code>.<ul>
 * <li>当调账类型为"红冲"时,仅存在{@code<reverse>}节点;</li>
 * <li>当调账类型为"补单"时,仅存在{@code<resupply>}节点;</li>
 * <li>当调账类型为"先红冲后补单"时,则同时存在{@code<reverse>}&{@code<resupply>}节点</li>
 * </ul></p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-11-18
 */
public class ReconChangeXml extends RespXml {
	private static final long serialVersionUID = -2670798719450599097L;
	/**
	 * 红冲结果
	 */
	private ReconChangeRs reverseRs;
	/**
	 * 补单结果
	 */
	private ReconChangeRs resupplyRs;
	/**
	 * 调账状态(SUCCESS/FAILURE)
	 */
	private String status;
	/**
	 * 调账失败原因
	 */
	private String failReason;

	public ReconChangeRs getReverseRs() {
		return reverseRs;
	}

	public void setReverseRs(ReconChangeRs reverseRs) {
		this.reverseRs = reverseRs;
	}

	public ReconChangeRs getResupplyRs() {
		return resupplyRs;
	}

	public void setResupplyRs(ReconChangeRs resupplyRs) {
		this.resupplyRs = resupplyRs;
	}
	
	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getFailReason() {
		return failReason;
	}

	public void setFailReason(String failReason) {
		this.failReason = failReason;
	}

	@Override
	protected void addRule(Digester digester) {
		digester.addObjectCreate("result/reverse", ReconChangeRs.class);
		digester.addCallMethod("result/reverse/businessSn", "setBusinessNo", 0);
		digester.addCallMethod("result/reverse/payNo", "setPayNo", 0);
		digester.addCallMethod("result/reverse/tradeNo", "setTradeNo", 0);
		digester.addSetNext("result/reverse", "setReverseRs");
		
		digester.addObjectCreate("result/resupply", ReconChangeRs.class);
		digester.addCallMethod("result/resupply/businessSn", "setBusinessNo", 0);
		digester.addCallMethod("result/resupply/payNo", "setPayNo", 0);
		digester.addCallMethod("result/resupply/tradeNo", "setTradeNo", 0);
		digester.addSetNext("result/resupply", "setResupplyRs");
		
		digester.addCallMethod("result/status", "setStatus", 0);
		digester.addCallMethod("result/failReason", "setFailReason", 0);
	}

}
