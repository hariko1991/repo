package com.sfpay.acquirer.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;
import com.sfpay.acquirer.dao.IGenerateInfoDao;
import com.sfpay.acquirer.service.IGenerateInfoService;

@Service("generateInfoService")
public class GenerateInfoServiceImpl implements IGenerateInfoService{
	@Resource
	private IGenerateInfoDao generateInfoDao;
	/**
	 * 获取当天不重复（供网银和快捷支付使用）
	 * @return
	 * @throws Exception
	 */
	public String getGenerateId(int diLength)throws Exception{
		return generateInfoDao.getGenerateId(diLength);
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 *  获取当天不重复（供银企直联使用）
	 * @param diLength
	 * @return
	 * @throws Exception
	 */
	public String getGenerateId4B2E(int diLength)throws Exception{
		return generateInfoDao.getGenerateId4B2E(diLength);
	}
	
	/**
	 * 获取随机数（供结算中心使用）
	 * @param diLength
	 * @return
	 * @throws Exception
	 */
	public String getRandomCode(int diLength)throws Exception{
		return generateInfoDao.getRandomCode(diLength);
	}
}
