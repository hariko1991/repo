package com.sfpay.acquirer.domain.rb.szfs;


import java.util.Date;

import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 渠道对应的服务器上的对账文件对应的bean   
 * 针对REC文件
 * @author sfhq272
 *
 */
public class BankReconFile extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = -212602225744051718L;


	private String	reqBankSn;
	private Date rcvDate;
	private Date checkDate;
	private String msgType;
	private String lstNo;
	private String transType;
	private String transNo;
	private String transCode;
	private String feeItem;
	private String ccy;
	private Long amt;
	private Long actAmt;
	private String status;
	private String retcode;
	private String returnFlag;
	private String reverseFlag;
	private Date clearDate;
	private String clearNo;
	private String payerBankNo;
	private String payerAcctNo;
	private String payerAcctName;
	private String payeeBankNo;
	private String payeeAcctNo;
	private String payeeAcctName;
	private BankCode payChannelCode;
	private Date createDate;
	private String remark;
	private String changeReconFlag;
	private Date updateDate;
	private String lstOutid;
	private String outid;
	
	public String getReqBankSn() {
		return reqBankSn;
	}
	public void setReqBankSn(String reqBankSn) {
		this.reqBankSn = reqBankSn;
	}
	public Date getRcvDate() {
		return rcvDate;
	}
	public void setRcvDate(Date rcvDate) {
		this.rcvDate = rcvDate;
	}
	public Date getCheckDate() {
		return checkDate;
	}
	public void setCheckDate(Date checkDate) {
		this.checkDate = checkDate;
	}
	public void setClearDate(Date clearDate) {
		this.clearDate = clearDate;
	}
	public String getMsgType() {
		return msgType;
	}
	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}
	public String getLstNo() {
		return lstNo;
	}
	public void setLstNo(String lstNo) {
		this.lstNo = lstNo;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public String getTransNo() {
		return transNo;
	}
	public void setTransNo(String transNo) {
		this.transNo = transNo;
	}
	public String getTransCode() {
		return transCode;
	}
	public void setTransCode(String transCode) {
		this.transCode = transCode;
	}
	public String getFeeItem() {
		return feeItem;
	}
	public void setFeeItem(String feeItem) {
		this.feeItem = feeItem;
	}
	public String getCcy() {
		return ccy;
	}
	public void setCcy(String ccy) {
		this.ccy = ccy;
	}
	public Long getAmt() {
		return amt;
	}
	public void setAmt(Long amt) {
		this.amt = amt;
	}
	public Long getActAmt() {
		return actAmt;
	}
	public void setActAmt(Long actAmt) {
		this.actAmt = actAmt;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRetcode() {
		return retcode;
	}
	public void setRetcode(String retcode) {
		this.retcode = retcode;
	}
	public String getReturnFlag() {
		return returnFlag;
	}
	public void setReturnFlag(String returnFlag) {
		this.returnFlag = returnFlag;
	}
	public String getReverseFlag() {
		return reverseFlag;
	}
	public void setReverseFlag(String reverseFlag) {
		this.reverseFlag = reverseFlag;
	}
	public Date getClearDate() {
		return clearDate;
	}
	public String getClearNo() {
		return clearNo;
	}
	public void setClearNo(String clearNo) {
		this.clearNo = clearNo;
	}
	public String getPayerBankNo() {
		return payerBankNo;
	}
	public void setPayerBankNo(String payerBankNo) {
		this.payerBankNo = payerBankNo;
	}
	public String getPayerAcctNo() {
		return payerAcctNo;
	}
	public void setPayerAcctNo(String payerAcctNo) {
		this.payerAcctNo = payerAcctNo;
	}
	public String getPayerAcctName() {
		return payerAcctName;
	}
	public void setPayerAcctName(String payerAcctName) {
		this.payerAcctName = payerAcctName;
	}
	public String getPayeeBankNo() {
		return payeeBankNo;
	}
	public void setPayeeBankNo(String payeeBankNo) {
		this.payeeBankNo = payeeBankNo;
	}
	public String getPayeeAcctNo() {
		return payeeAcctNo;
	}
	public void setPayeeAcctNo(String payeeAcctNo) {
		this.payeeAcctNo = payeeAcctNo;
	}
	public String getPayeeAcctName() {
		return payeeAcctName;
	}
	public void setPayeeAcctName(String payeeAcctName) {
		this.payeeAcctName = payeeAcctName;
	}
	public BankCode getPayChannelCode() {
		return payChannelCode;
	}
	public void setPayChannelCode(BankCode payChannelCode) {
		this.payChannelCode = payChannelCode;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getChangeReconFlag() {
		return changeReconFlag;
	}
	public void setChangeReconFlag(String changeReconFlag) {
		this.changeReconFlag = changeReconFlag;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public String getLstOutid() {
		return lstOutid;
	}
	public void setLstOutid(String lstOutid) {
		this.lstOutid = lstOutid;
	}
	public String getOutid() {
		return outid;
	}
	public void setOutid(String outid) {
		this.outid = outid;
	}
	
}
