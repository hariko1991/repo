package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IOftenColInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.OftenColInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.acquirer.service.IPayoutInfoService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：<br>
 * 对付款信息进行修改、删除等
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-6-22
 */
@Service("payoutInfoService")
@HessianExporter
public class PayoutInfoServcieImpl implements IPayoutInfoService {
	private static Logger logger = LoggerFactory.getLogger(PayoutInfoServcieImpl.class);
	private static final boolean isDebug = logger.isDebugEnabled();
	
	@Resource
	private IPayoutInfoDao payoutInfoDao;
	
	@Resource
	private IOftenColInfoDao oftenColInfoDao;
	
	//摘要最大长度
	private int summaryLimit = Integer.valueOf(Property.getProperty("B2E_SUMMARY_LIMIT"));

	@Override
	public void deletePayOutInfo(List<Long> ids) throws ServiceException {
		if(ids == null || ids.size() == 0){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"付款ID信息不能为空.");
		}
		
		//软删除
		try {
			int cnt = payoutInfoDao.softDeleteByIds(ids,PayoutStatus.INIT);
			if(isDebug){
				logger.info("(删除付款信息)删除付款信息条数:[{}]",cnt);
			}
		} catch (Exception e) {
			logger.error("(删除付款信息)删除付款信息异常:",e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE,"删除付款信息异常:"+e);
		}
		
	}

	@Override
	public int updatePayOutInfo(PayoutInfo payoutInfo) throws ServiceException {
		//检查参数
		this.check(payoutInfo);
		
		int cnt = 0;
		try {
			payoutInfo.setSummary(StringUtils.substr(payoutInfo.getSummary(), summaryLimit));
			int agent = payoutInfo.getAgentFlag().equals(YNFlag.Y)?1:0;
			cnt = payoutInfoDao.updatePayoutById(payoutInfo,agent);
		} catch (Exception e) {
			logger.error("修改付款信息异常", e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE, "修改付款信息异常", e);
		}
		if (YNFlag.Y.equals(payoutInfo.getSaveColtCompFlag())) {
			OftenColInfo param = converToOftenCol(payoutInfo);
			try {
				oftenColInfoDao.saveOrUpdateOften(param);
			} catch (Exception ex) {
				logger.error("保存常用收款单位异常", ex);
			}
		}
		return cnt;
	}
	
	/**
	 * 方法说明：<br>
	 * 参数检查
	 *
	 * @param editor
	 */
	private void check(PayoutInfo editor) throws ServiceException {
		if(editor == null) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "入参不能为空");
		}
		if(YNFlag.N.equals(editor.getAgentFlag())){
			editor.setAgentAcctNo(null);
			editor.setAgentName(null);
		}
		
	}
	
	/**
	 * 方法说明：<br>
	 * 转换成常用收款单位实体
	 *
	 * @param data
	 * @return
	 */
	private OftenColInfo converToOftenCol(PayoutInfo data) {
		OftenColInfo oftenColInfo = new OftenColInfo();
		oftenColInfo.setAccountName(data.getPayeeAcctName());
		oftenColInfo.setAccountNo(data.getPayeeAcctNo());
		oftenColInfo.setAcctType(data.getPayeeAcctType());
		oftenColInfo.setBankCode(data.getPayeeOrgCode());
		oftenColInfo.setCcy(CurrencyType.RMB);//默认为RMB
//		oftenColInfo.setColCompName(colCompName);
//		oftenColInfo.setCompManager(compManager);
//		oftenColInfo.setCreateDate(createDate);
		oftenColInfo.setManagerMobile(data.getPayeeMobile());
		oftenColInfo.setObAddr(data.getPayeeAcctAddr());
		oftenColInfo.setObCity(data.getPayeeAcctCity());
		oftenColInfo.setObNo(data.getPayeeBranchCode());
		oftenColInfo.setObProvince(data.getPayeeAcctProvince());
		oftenColInfo.setRemark(data.getRemark());
		oftenColInfo.setAffiliateName(data.getPayeeBranchName());
		oftenColInfo.setCountryNameC(data.getPayeeAcctProvinceName());
		oftenColInfo.setCityName(data.getPayeeAcctCityName());
		return oftenColInfo;
	}

}
