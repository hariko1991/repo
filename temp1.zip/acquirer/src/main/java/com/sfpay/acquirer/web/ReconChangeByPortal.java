/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.web;

import java.io.PrintWriter;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.util.HtmlUtils;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ReconChangeStatus;
import com.sfpay.acquirer.service.IReconChangeService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.order.enums.SourcesCode;
import com.sfpay.product.domain.recharge.adjust.BusinessModel;
import com.sfpay.product.domain.recharge.adjust.WebRedoRequest;
import com.sfpay.product.domain.recharge.adjust.WebRedoResponse;
import com.sfpay.product.domain.recharge.adjust.WebResupplyLateRequest;
import com.sfpay.product.domain.recharge.adjust.WebResupplyRequest;
import com.sfpay.product.domain.recharge.adjust.WebResupplyResponse;
import com.sfpay.product.domain.recharge.adjust.WebReverseRequest;
import com.sfpay.product.domain.recharge.adjust.WebReverseResponse;
import com.sfpay.product.service.IWebRrechargeAdjustService;

/**
 * 类说明：<br>
 * 储值卡Portal系统调账Controller,包含: 红冲、补单、先红冲后补单.<br>
 * 供 {@link IReconChangeService} 调用,URL定义在数据库配置参数中.
 * 
 * <p>
 * 详细描述：<br>
 * 因原先调账功能仅适用于储值卡Portal系统,现将改接口改照为适用于任何业务系统的接口,故将该部分功能提取出来.<br>
 * 若此实现移动至储值卡系统中,则删除此实现
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-11-14
 */
@Deprecated
@Controller
@RequestMapping(value="/reconchange/portal")
public class ReconChangeByPortal {
	
	private static final Logger logger = LoggerFactory.getLogger(ReconChangeByPortal.class);
	
	@Resource
	private IWebRrechargeAdjustService rechgAdjust;
	
	/**
	 * 方法说明：<br>
	 * 补单
	 */
	@RequestMapping(value="/resupply", method=RequestMethod.POST)
	public void doResupply(HttpServletRequest req, HttpServletResponse resp) {
		BusinessModel model = null;
		String cardNo = HtmlUtils.htmlEscape(req.getParameter("cardNo"));
		String reason = null;
		try {//调用订单接口
			if (StringUtils.isEmpty(cardNo)) {
				model = supplyByBusinessSn(req);
			} else {
				model = supplyByCardNo(cardNo, req);
			}
		} catch (ServiceException e) {
			logger.error("执行补单异常", e);
			reason = e.getMessage();
		} catch (Exception e) {
			logger.error("执行补单异常", e);
			reason = String.format("系统异常[%s]", e.getMessage());
		}
		StringBuffer xml = new StringBuffer("<?xml version=\"1.0\" encoding=\"UTF-8\" ?><result>");
		if(null == model) {
			xml.append("<status>").append(ReconChangeStatus.FAILURE).append("</status>");
			xml.append("<failReason>").append(StringUtils.isEmpty(reason) ? "获取补单结果失败" : reason).append("</failReason>");
		} else {
			xml.append("<resupply>");
			xml.append("<businessSn>").append(model.getBusinessSn()).append("</businessSn>");
			xml.append("<payNo>").append(model.getPayNo()).append("</payNo>");
			xml.append("<tradeNo>").append(model.getTradeNo()).append("</tradeNo>");
			xml.append("</resupply>");
			xml.append("<status>").append(ReconChangeStatus.SUCCESS).append("</status>");
		}
		xml.append("</result>");
		writeResp(resp, xml);
	}
	
	/**
	 * 方法说明：<br>
	 * 红冲
	 */
	@RequestMapping(value="/reverse", method=RequestMethod.POST)
	public void doReverse(HttpServletRequest req, HttpServletResponse resp) {
		BusinessModel model = null;
		String reason = null;
		WebReverseRequest revReq = new WebReverseRequest();
		revReq.setBusinessSn(HtmlUtils.htmlEscape(req.getParameter("businessSn")));
		revReq.setOperatorNo(HtmlUtils.htmlEscape(req.getParameter("operatorNo")));
		revReq.setOrgId(Long.valueOf(req.getParameter("orgId")));
		revReq.setRequestIp(HtmlUtils.htmlEscape(req.getParameter("requestIp")));
		revReq.setSourcesCode(SourcesCode.ACQ);
		try {
			WebReverseResponse rs = rechgAdjust.reverse(revReq);//调用老订单接口
			model = rs.getModel();
		} catch (ServiceException e) {
			logger.error("处理储值卡红冲异常", e);
			reason = e.getMessage();
		} catch (Exception e) {
			logger.error("处理储值卡红冲异常", e);
			reason = String.format("系统异常[%s]", e.getMessage());
		}
		StringBuffer xml = new StringBuffer("<?xml version=\"1.0\" encoding=\"UTF-8\" ?><result>");
		if(null == model) {
			xml.append("<status>").append(ReconChangeStatus.FAILURE).append("</status>");
			xml.append("<failReason>").append(StringUtils.isEmpty(reason) ? "获取红冲结果失败" : reason).append("</failReason>");
		} else {
			xml.append("<reverse>");
			xml.append("<businessSn>").append(model.getBusinessSn()).append("</businessSn>");
			xml.append("<payNo>").append(model.getPayNo()).append("</payNo>");
			xml.append("<tradeNo>").append(model.getTradeNo()).append("</tradeNo>");
			xml.append("</reverse>");
			xml.append("<status>").append(ReconChangeStatus.SUCCESS).append("</status>");
		}
		xml.append("</result>");
		writeResp(resp, xml);
	}
	
	
	/**
	 * 方法说明：<br>
	 * 先红冲后补单.
	 */
	@RequestMapping(value="/redo", method=RequestMethod.POST)
	public void doRedo(HttpServletRequest req, HttpServletResponse resp) {
		BusinessModel revRlt = null;
		BusinessModel resRlt = null;
		String reason = null;
		WebRedoRequest redo = new WebRedoRequest();
		redo.setAdjustAmt(Long.valueOf(req.getParameter("resupplyAmt")));// 补单金额
		redo.setBusinessSn(HtmlUtils.htmlEscape(req.getParameter("businessSn")));
		redo.setOperatorNo(HtmlUtils.htmlEscape(req.getParameter("operatorNo")));
		redo.setOrgId(Long.valueOf(req.getParameter("orgId")));
		redo.setRequestIp(HtmlUtils.htmlEscape(req.getParameter("requestIp")));
		redo.setSourcesCode(SourcesCode.ACQ);
		try {
			WebRedoResponse rs = rechgAdjust.redo(redo);// 调用订单接口
			revRlt = rs.getReverseModel();// 红冲返回
			resRlt = rs.getResupplyModel();// 补单返回
		} catch (ServiceException e) {
			logger.error(InfoCode.HESSIAN_FAILURE, e);
			reason = e.getMessage();
		} catch (Exception e) {
			logger.error(InfoCode.HESSIAN_FAILURE, e);
			reason = String.format("系统异常[%s]", e.getMessage());
		}
		StringBuffer xml = new StringBuffer("<?xml version=\"1.0\" encoding=\"UTF-8\" ?><result>");
		if (null != revRlt && null != resRlt) {
			xml.append("<reverse>");//红冲结果
			xml.append("<businessSn>").append(revRlt.getBusinessSn()).append("</businessSn>");
			xml.append("<payNo>").append(revRlt.getPayNo()).append("</payNo>");
			xml.append("<tradeNo>").append(revRlt.getTradeNo()).append("</tradeNo>");
			xml.append("</reverse><resupply>");//补单结果
			xml.append("<businessSn>").append(resRlt.getBusinessSn()).append("</businessSn>");
			xml.append("<payNo>").append(resRlt.getPayNo()).append("</payNo>");
			xml.append("<tradeNo>").append(resRlt.getTradeNo()).append("</tradeNo>");
			xml.append("</resupply>");
			xml.append("<status>").append(ReconChangeStatus.SUCCESS).append("</status>");
		} else {
			xml.append("<status>").append(ReconChangeStatus.FAILURE).append("</status>");
			xml.append("<failReason>").append(StringUtils.isEmpty(reason) ? "获取先红冲再补单结果失败" : reason).append("</failReason>");
		}
		xml.append("</result>");
		writeResp(resp, xml);
	}
	
	/**
	 * 方法说明：
	 * 补单操作-有流水号的补单
	 * @param req
	 * @return BusinessModel
	 */
	private BusinessModel supplyByBusinessSn(HttpServletRequest req) throws Exception {
		String businessNo = HtmlUtils.htmlEscape( req.getParameter("businessSn"));
		if(StringUtils.isEmpty(businessNo)) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "参数[businessSn]不能为空");
		}
		WebResupplyLateRequest resReq = new WebResupplyLateRequest();
		resReq.setBusinessSn(businessNo);
		resReq.setOperatorNo(HtmlUtils.htmlEscape( req.getParameter("operatorNo")));
		resReq.setRequestIp(HtmlUtils.htmlEscape( req.getParameter("requestIp")));
		resReq.setOrgId(Long.valueOf( req.getParameter("orgId")));
		resReq.setResupplyAmtBool(true);
		resReq.setResupplyAmt(Long.valueOf(req.getParameter("outAmt")));
		resReq.setSourcesCode(SourcesCode.ACQ);	
		WebResupplyResponse resp = rechgAdjust.resupply(resReq);// 调用订单有流水号补单接口
		return null == resp ? null : resp.getModel();
	}
	
	
	/**
	 * 方法说明：
	 * 补单操作-按卡号补单
	 * @param reconRlt
	 * @param req
	 * @return BusinessModel
	 */
	private BusinessModel supplyByCardNo(String cardNo, HttpServletRequest req) throws Exception {
		if (StringUtils.isEmpty(HtmlUtils.htmlEscape(cardNo))) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "参数[cardNo]不能为空");
		}
		String bank = HtmlUtils.htmlEscape( req.getParameter("bankCode"));
		WebResupplyRequest resReq = new WebResupplyRequest();
		resReq.setCardCode(cardNo);
		resReq.setOperatorNo(HtmlUtils.htmlEscape( req.getParameter("operatorNo")));
		resReq.setRequestIp(HtmlUtils.htmlEscape( req.getParameter("requestIp")));
		resReq.setOrgId(Long.valueOf(req.getParameter("orgId")));
		resReq.setRechargeAmt(Long.valueOf( req.getParameter("outAmt")));// 取外部金额
		resReq.setBankCode(null == bank ? null : BankCode.valueOf(bank).name());// 银行编码
		resReq.setSourcesCode(SourcesCode.ACQ);
		WebResupplyResponse resp = rechgAdjust.resupply(resReq);// 调用订单有流水号补单接口
		return null == resp ? null : resp.getModel();
	}
	
	private void writeResp(HttpServletResponse resp, StringBuffer xml) {
		resp.setContentType("text/plain;charset=UTF-8");
		try {
			PrintWriter out = resp.getWriter();
			out.println(xml.toString());
		} catch (Exception e) {
			logger.error("返回信息流写入异常", e);
		}
	}
}
