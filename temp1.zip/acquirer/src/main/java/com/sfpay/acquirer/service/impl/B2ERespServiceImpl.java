package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IBatchInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutReqResult;
import com.sfpay.acquirer.domain.PayoutRespResult;
import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.acquirer.enums.CmdStatus;
import com.sfpay.acquirer.enums.ExchangeType;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.QuerySinglePayInfo;
import com.sfpay.acquirer.gate.b2e.domain.QueryTransferInfo;
import com.sfpay.acquirer.gate.b2e.domain.SinglePayInfo;
import com.sfpay.acquirer.gate.b2e.domain.TransferInfo;
import com.sfpay.acquirer.gate.b2e.domain.TransferSubInfo;
import com.sfpay.acquirer.gate.b2e.enums.BizStatus;
import com.sfpay.acquirer.gate.b2e.service.impl.Payout;
import com.sfpay.acquirer.gate.b2e.service.impl.QueryPayout;
import com.sfpay.acquirer.service.IB2ERespService;
import com.sfpay.acquirer.service.ICheckTransStatusService;
import com.sfpay.acquirer.service.SendPayoutResp;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：<br>
 * 处理银行和结算中心返回结果数据
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-4-27
 */
@Service("b2eRespService")
@HessianExporter
public class B2ERespServiceImpl implements IB2ERespService {
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	protected final boolean isDebug = logger.isDebugEnabled();
	// TODO 删除属性文件 constant.properties 中的属性： HANDLER_TRANSFER_RESULT_POOL_SIZE
	// 删除ExecutorService的处理逻辑。如有问题，查看SVN库版本号为4204的版本
	@Resource
	private IPayoutInfoDao payoutInfoDao;
	@Resource
	private IBatchInfoDao batchInfoDao;
	@Resource
	private SendPayoutResp sendPayoutResp;
	@Resource
	private ICheckTransStatusService checkTrans;
	
	/**
	 * 方法说明：<br>
	 * 查询批次受理状态结果
	 *
	 * @param respXml
	 * @param head
	 * @throws ServiceException
	 */
	@Override
	public void procBatchResp(BeanBase respBean) throws ServiceException {
		Payout payout = new Payout();
		PayoutReqResult result = null;
		String reqBankSn = respBean.getBusDetailBeanBase().getSerialId();
		logger.info("解析批次[{}]响应结果...", reqBankSn);
		try {
			//解析并转换结果
			result = payout.doResp(respBean);
		} catch (Exception e) {
			logger.error(String.format("解析批次[%s]响应结果异常", reqBankSn), e);
		}
		if(result == null) {
			throw new ServiceException(InfoCode.FAILURE, String.format("解析批次[%s]响应结果失败.", reqBankSn));
		}
		logger.info("更新批次[{}]受理结果...", reqBankSn);
		//更新批次受理结果
		BatchInfo bi = null;
		try {
			bi = updateRes(result);
		} catch(Exception ex) {
			logger.error("批次[请求流水号:"+reqBankSn+"],更新银行返回异常 :",ex);
			throw new ServiceException(InfoCode.FAILURE,"更新银行返回异常 ["+ex.getMessage()+"]", ex);
		}
		
		
		logger.info("批次[{}]受理结束(出款结果 : {})", reqBankSn, bi == null ? "不存在批次" : bi.getStatus());
	}
	

	/**
	 * 方法说明：<br>
	 * 查询交易状态结果
	 *
	 * @param respXml
	 * @param head
	 * @throws ServiceException
	 */
	@Override
	public void procPayoutResp(BeanBase respBean) throws ServiceException {
		QueryPayout query = new QueryPayout();
		
		PayoutRespResult result = null;
		String reqBankSn = ((QueryTransferInfo)respBean.getBusDetailBeanBase()).getMainSerialId();
		logger.info("解析批次[{}]响应结果...", reqBankSn);
		try {
			//解析并转换结果
			result = query.doResp(respBean);
		} catch (Exception ex) {
			logger.error(String.format("批次[%s]转换付款结果异常:", reqBankSn), ex);
		}
		if(result == null){
			throw new ServiceException(InfoCode.FAILURE, String.format("批次[%s]转换付款结果异常:", reqBankSn));
		}
		if(!CmdStatus.SUCCESS.equals(result.getCmdStatus())){
			String str = String.format("批次[%s]，查询请求异常:[%s-%s]", reqBankSn,result.getCmdStatus(),result.getRemark());
			logger.info(str);
			return;
		}
		logger.info("更新批次[{}]付款结果...", reqBankSn);
		//查询批次信息
		BatchInfo batchInfo = batchInfoDao.queryBiByReqBankSn(result.getBatchReqBankSn());
		if(batchInfo == null){
			logger.error("不存在批次[{}].", result.getBatchReqBankSn());
			return;
		}
		//2.1.2 更新结果
		List<PayoutInfo> batchNotify = checkTrans.doPayoutResp(batchInfo, result);
		
		//2.2调用订单系统
		if(batchNotify != null && batchNotify.size() > 0) {
			logger.info("将批次[{}]付款结果发送给外部系统.", reqBankSn);
			try {
				sendPayoutResp.sendOrderResp(batchNotify,ExchangeType.SEND_AFTER);
			} catch (Exception ex) {
				logger.error("批次[" + batchInfo.getBatchCode() + "],调用订单系统异常", ex);
			}
		}
		logger.info("批次[{}]付款结果处理结束.", reqBankSn);
	}
	
	//sfhq272
	@Override
	public void procSingleBatchResp(BeanBase respBean) throws ServiceException {
		Payout payout = new Payout();
		PayoutReqResult result = null;

		SinglePayInfo spi = (SinglePayInfo)respBean.getBusDetailBeanBase();
		logger.info("解析单笔代付[{}]响应结果...", spi);
		String reqBankSn = spi.getSubSerialId();
		logger.info("解析单笔代付[{}]响应结果...", reqBankSn);
		try {
			//解析并转换结果
			result = payout.doResp(respBean);
		} catch (Exception e) {
			logger.error(String.format("解析单笔代付[%s]响应结果异常", reqBankSn), e);
		}
		if(result == null) {
			throw new ServiceException(InfoCode.FAILURE, String.format("解析单笔代付[%s]响应结果失败.", reqBankSn));
		}
		logger.info("解析单笔代付[{}]受理结果...", reqBankSn);
		//更新单笔代付受理结果
		BatchInfo bi = null;
		try {
			bi = updateSingleRes(result);
		} catch(Exception ex) {
			logger.error("单笔代付[请求流水号:"+reqBankSn+"],更新银行返回异常 :",ex);
			throw new ServiceException(InfoCode.FAILURE,"更新银行返回异常 ["+ex.getMessage()+"]", ex);
		}
		logger.info("单笔代付[{}]受理结束(出款结果 : {})", reqBankSn, bi == null ? "不存在批次" : bi.getStatus());
	}

	//sfhq272
	@Override
	public void procSinglePayoutResp(BeanBase respBean) throws ServiceException {
		QueryPayout query = new QueryPayout();
		
		PayoutRespResult result = null;
		
		QuerySinglePayInfo qsp = (QuerySinglePayInfo)respBean.getBusDetailBeanBase();
		logger.info("解析单笔代付[{}]响应结果...", qsp);
		String reqBankSn = qsp.getSubSerialId();
		logger.info("解析单笔代付[{}]响应结果...", reqBankSn);
		try {
			//解析并转换结果
			result = query.doResp(respBean);
		} catch (Exception ex) {
			logger.error(String.format("单笔代付[%s]转换付款结果异常:", reqBankSn), ex);
		}
		if(result == null){
			throw new ServiceException(InfoCode.FAILURE, String.format("单笔代付[%s]转换付款结果异常:", reqBankSn));
		}
		
		if(!PayoutStatus.SUCCESS.equals(result.getPayoutStatus())&&
				!PayoutStatus.FAILURE.equals(result.getPayoutStatus())&&
				!PayoutStatus.RECEIVED.equals(result.getPayoutStatus())&&
				!PayoutStatus.UNKOWN.equals(result.getPayoutStatus())){
			throw new ServiceException(InfoCode.RESPONSE_EXCEPTION
					,String.format("单笔代付[%s]，查询请求异常:[%s-%s]", reqBankSn, result.getPayoutStatus(), result.getRemark()));
		}
		
		//根据payoutInfo的reqBankSn得到BatchInfo
		BatchInfo batchInfo = batchInfoDao.queryBatchByPayoutReqBankSn(reqBankSn);
		if(batchInfo == null){
			logger.error("单笔代付不存在批次[{}].", result.getBatchReqBankSn());
			return;
		}
		
		logger.info("单笔代付更新[{}]付款结果...", reqBankSn);
		//2.1.2 更新结果
		List<PayoutInfo> batchNotify = checkTrans.doSinglePayoutResp(batchInfo, result);
		
		//2.2调用订单系统
		if(batchNotify != null && batchNotify.size() > 0) {
			logger.info("单笔代付将批次[{}]付款结果发送给外部系统.", reqBankSn);
			try {
				sendPayoutResp.sendOrderResp(batchNotify,ExchangeType.SEND_AFTER);
			} catch (Exception ex) {
				logger.error("单笔代付批次[" + batchInfo.getBatchCode() + "],调用订单系统异常", ex);
			}
		}
		logger.info("单笔代付批次[{}]付款结果处理结束.", reqBankSn);
	}
	
	/**
	 * 方法说明：<br>
	 * 更新结果(处理批次受理的结果)
	 *
	 * @param batchInfo
	 * @param result
	 */
	private BatchInfo updateRes(PayoutReqResult result) throws Exception{
		//检查返回结果
		this.checkBatchResp(result);
		
		//更新批次表
		BatchInfo batchInfo = batchInfoDao.queryBiByReqBankSn(result.getReqBankSn());
		if(batchInfo == null){
			logger.error("批次[{}]不存在.", result.getReqBankSn());
			return batchInfo;
		}
		
		batchInfo.setRtnBankCode(result.getRtnBankCode());
		batchInfo.setRtnBankMsg(result.getRtnBankMsg());
		batchInfo.setStatus(result.getStatus());
		batchInfo.setPayBatchDate(result.getSendTime());
		if(!StringUtils.isEmpty(result.getRtnBankSn())){
			batchInfo.setRtnBankSn(result.getRtnBankSn());//银行返回的批次流水号（招行实例号） add by sfhq814 2015-8-5
		}
		if(BatchStatus.SEC_CHECK_PASS.equals(result.getStatus())) {
			logger.info("等待批次[{}]反馈结果(不更新受理状态).", result.getReqBankSn());
			return batchInfo;
		}
		
		logger.info(String.format("更新批次表[%s]信息: status[%s], rtnBankCode[%s], rtnBankMsg[%s].", result.getReqBankSn(), batchInfo.getStatus(), batchInfo.getRtnBankCode(), batchInfo.getRtnBankMsg()));
		int cnt = this.batchInfoDao.updateBankRnt(batchInfo);
		if(cnt == 0) {
			logger.error("无批次[{}]记录更新.", result.getReqBankSn());
			return null;
		}
		//更新付款信息表
		logger.info("更新付款信息表(批次[{}]).", result.getReqBankSn());
		PayoutStatus payoutStatus = null;
		if(BatchStatus.DONE.equals(result.getStatus())) {
			sendPayoutResp.doSendOrderResp(result.getInfos(), batchInfo, PayoutStatus.FAILURE);
			payoutStatus = PayoutStatus.FAILURE;
		} else if(BatchStatus.RECEIVED.equals(result.getStatus())) {
			for(PayoutInfo pi:result.getInfos()){
				this.payoutInfoDao.updateReceivedByReqBankSn(pi);
			}
			
			//this.payoutInfoDao.updateStatusByBatchReq(PayoutStatus.RECEIVED, batchInfo.getReqBankSn(), PayoutStatus.SEC_CHECK_PASS);
			
			payoutStatus = PayoutStatus.RECEIVED;
		} else {
			//未知不需要通知订单
			this.payoutInfoDao.updateStatusByBatchReq(PayoutStatus.UNKOWN, batchInfo.getReqBankSn(), PayoutStatus.SEC_CHECK_PASS);
			payoutStatus = PayoutStatus.UNKOWN;
		}
		logger.info("更新信息:reqBankSn[{}],batchCode[{}],status[{}].",new Object[]{result.getReqBankSn(),batchInfo.getBatchCode(),payoutStatus});
		return batchInfo;
	}
	
	//sfhq272
	private BatchInfo updateSingleRes(PayoutReqResult result) throws Exception{
		//检查返回结果
		this.checkSingleResp(result);
		
		String reqBankSn = result.getReqBankSn();
		//更新批次表
		BatchInfo batchInfo = batchInfoDao.queryBatchByPayoutReqBankSn(reqBankSn);
		if(batchInfo == null){
			logger.error("单笔代付批次[{}]不存在.", result.getReqBankSn());
			return batchInfo;
		}
		
		//根据明细的状态来赋值批次的状态
		BatchStatus batchStatus = null;
		if(result.getPayoutStatus().name().equals(PayoutStatus.SUCCESS.name()) ||
				result.getPayoutStatus().name().equals(PayoutStatus.FAILURE.name())){
			batchStatus = BatchStatus.DONE;
		}else if(result.getPayoutStatus().name().equals(PayoutStatus.RECEIVED.name())){
			batchStatus = BatchStatus.RECEIVED;
		}else if(result.getPayoutStatus().name().equals(PayoutStatus.UNKOWN.name())){
			batchStatus = BatchStatus.UNKOWN;
		}
		
		
		batchInfo.setRtnBankCode(result.getRtnBankCode());
		batchInfo.setRtnBankMsg(result.getRtnBankMsg());
		batchInfo.setStatus(batchStatus);
		batchInfo.setPayBatchDate(result.getSendTime());
		
		if(BatchStatus.SEC_CHECK_PASS.name().equals(result.getPayoutStatus().name())) {
			logger.info("单笔代付等待批次[{}]反馈结果(不更新受理状态).", result.getReqBankSn());
			return batchInfo;
		}
		
		logger.info(String.format("单笔代付更新批次表[%s]信息: status[%s], rtnBankCode[%s], rtnBankMsg[%s].", result.getReqBankSn(), batchInfo.getStatus(), batchInfo.getRtnBankCode(), batchInfo.getRtnBankMsg()));
		int cnt = this.batchInfoDao.updateBankRnt(batchInfo);
		if(cnt == 0) {
			logger.error("无批次[{}]记录更新.", result.getReqBankSn());
			return null;
		}
		//更新付款信息表
		logger.info("单笔代付更新付款信息表([{}]).", result.getReqBankSn());
		PayoutStatus payoutStatus = null;
		if(BatchStatus.DONE.equals(batchStatus)) {
			sendPayoutResp.doSendOrderResp(result.getInfos(), batchInfo, result.getPayoutStatus());
			payoutStatus = result.getPayoutStatus();
		} else if(BatchStatus.RECEIVED.equals(batchStatus)) {
			this.payoutInfoDao.updateStatusByBatchReq(PayoutStatus.RECEIVED, batchInfo.getReqBankSn(), PayoutStatus.SEC_CHECK_PASS);
			payoutStatus = result.getPayoutStatus();
		} else {
			//未知不需要通知订单
			this.payoutInfoDao.updateStatusByBatchReq(PayoutStatus.UNKOWN, batchInfo.getReqBankSn(), PayoutStatus.SEC_CHECK_PASS);
			payoutStatus = PayoutStatus.UNKOWN;
		}
		logger.info("单笔代付更新信息:reqBankSn[{}],batchCode[{}],status[{}].",new Object[]{result.getReqBankSn(),batchInfo.getBatchCode(),payoutStatus});
		return batchInfo;
	}
	
	/**
	 * 方法说明：<br>
	 * 检查批次返回结果
	 *
	 * @throws ServiceException
	 */
	private void checkBatchResp(PayoutReqResult result) throws ServiceException {
		if(result == null) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "转换银行返回值结果不能为空 ");
		}
		if(StringUtils.isEmpty(result.getReqBankSn())) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "转换银行返回值结果的银行请求流水号不能为空 ");
		}
		if(result.getStatus() == null) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "转换银行返回值结果的交易状态不能为空 ");
		}
		if(result.getSendTime() == null) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "转换银行返回值结果的发送时间不能为空 ");
		}
		/*if(result.getInfos().size()<=0||result.getInfos()==null){
			throw new ServiceException(InfoCode.PARAM_INVALID, "转换银行返回值结果的子集合不能为空 ");
		}*/
	}
	
	
	//检查单笔代付返回结果
	private void checkSingleResp(PayoutReqResult result) throws ServiceException {
		if(result == null) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "转换银行返回值结果不能为空 ");
		}
		if(StringUtils.isEmpty(result.getReqBankSn())) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "转换银行返回值结果的银行请求流水号不能为空 ");
		}
		if(result.getPayoutStatus() == null) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "转换银行返回值结果的交易状态不能为空 ");
		}
		if(result.getSendTime() == null) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "转换银行返回值结果的发送时间不能为空 ");
		}
	}
	
}
