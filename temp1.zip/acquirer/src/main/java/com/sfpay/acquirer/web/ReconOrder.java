package com.sfpay.acquirer.web;

import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.service.IPayoutReconService;
import com.sfpay.acquirer.service.IReconciliationService;

/**
 * 类说明：<br>
 * 与订单对账
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-8-20
 */
@Deprecated
@Controller
@RequestMapping(value="/recon")
public class ReconOrder {
	private Logger logger = LoggerFactory.getLogger(ReconOrder.class);

	@Resource
	private IReconciliationService createService;
	
	@Resource
	private IPayoutReconService recon;
	
	@RequestMapping(value = {"/create"})
	public String createIndex(HttpServletRequest request, HttpServletResponse response) {
		return "/testCreateFiles_order";
	}
	
	/**
	 * 方法说明：<br>
	 * 生成网银对账文件
	 *
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/create/b2cReconFile")
	public String createFiles(HttpServletRequest request, HttpServletResponse response) {
		String reconDate = request.getParameter("reconDate");
		try {
			createService.createFiles(reconDate);
			request.setAttribute("msg", "生成网银对账文件完成,请检查.");
		} catch (Exception e) {
			logger.error("", e);
			request.setAttribute("msg", "生成网银对账文件异常["+e.getMessage()+"]");
		}
		return "/testCreateFiles_order";
	}
	
	@RequestMapping(value = {"/payout"})
	public String payoutIndex(HttpServletRequest request, HttpServletResponse response) {
		return "/testPayoutRecon";
	}
	
	/**
	 * 方法说明：<br>
	 * 银企付款对账
	 *
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/payout/b2eRecon")
	public String payoutRecon(HttpServletRequest request, HttpServletResponse response) {
		String tradeDateStr = request.getParameter("tradeDate");
		Date tradeDate = DateUtil.getDateFormatStr(tradeDateStr, "yyyy-MM-dd");
		recon.doRecon(tradeDate);
		request.setAttribute("msg", "银企付款对账完成,请检查.");
		return "/testPayoutRecon";
	}
}
