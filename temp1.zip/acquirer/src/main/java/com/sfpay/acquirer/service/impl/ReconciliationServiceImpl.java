/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.io.File;
import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.ICollectInfoDao;
import com.sfpay.acquirer.domain.RecData;
import com.sfpay.acquirer.service.IReconciliationService;
import com.sfpay.framework.common.net.ftp.SFTPClient;
import com.sfpay.pubcenter.domain.BaseParam;
import com.sfpay.pubcenter.enums.SystemEnums.SystemName;
import com.sfpay.pubcenter.service.IConfigruationCenter;

/**
 * 
 * 类说明：生成对账文件接口实现
 *  
 * 
 * <p>
 * 详细描述：
 *   
 * 
 * @author 271762
 * @author 329202 符瑜鑫(Ricky Fu)
 *   
 * CreateDate: 2012-4-20
 */
@Deprecated
@Service("reconciliationService")
public class ReconciliationServiceImpl implements IReconciliationService {

	private Logger logger = LoggerFactory.getLogger(ReconciliationServiceImpl.class);
	
	//本地路径
	private static String localPathStr ;
	//远程文件服务器IP
	private static String fileSystemIp;
	//远程文件服务器端口
	private static int fileSystemPort;
	//远程文件服务器登录名
	private static String fileSystemUser;
	//远程文件服务器口令
	private static String fileSystemPass;
	//远程服务器路径
	private static String fileSystemPathStr;
	//单个文件大小
	private static int fileSize;
	//每次获取记录条数
	private static int fetchSize;
	
	@Resource
	private ICollectInfoDao collectInfoDao;
	
	@Resource
	private IConfigruationCenter configruationCenter;
	
	@Override
	public void createFiles(String reconDate) {
		logger.info("开始生成[{}]对账文件...", reconDate);
		try {
			// 统计总记录数
			final long payNum = collectInfoDao.countRecon(reconDate);
			if(payNum <= 0) {
				logger.info("[{}]无对账记录,对账结束.", reconDate);
				return;
			}
			//初始化参数
			initParam();
			// 用于已完成写入操作的文件上传队列
			List<File> files = new ArrayList<File>();
			
			// 计算出所需生成的文件数
			final int fileNum = (int) (payNum % fileSize > 0 ? payNum / fileSize + 1	: payNum / fileSize);
			String date = reconDate.replace("-", "");
			int times = fileSize / fetchSize;
			// 开始写文件
			for (int i = 0; i < fileNum; i++) {
				String fileName = getFileName(reconDate, i + 1, fileNum);
				File file = generateFile(localPathStr, date, fileName);
				List<RecData> data = null;
				for (int k = 0; k < times; k++) {
					int pageIndex = k + 1 + times * i;
					data = getDB(reconDate, pageIndex, fetchSize);
					if (data == null || data.size() == 0) {
						break;
					}
					write2File(file, data);
				}
				files.add(file);
			}
			// 所有文件写入完成时开始上传
			upload(files, date);
			// 清空本地数据
			removeLocal(localPathStr + date);
		} catch (Exception e) {
			logger.error("生成网银对账文件异常", e);
		}
		logger.info("[{}]对账文件生成完毕", reconDate);
	}
	
	@Override
	public void createFiles() {
		Calendar c = Calendar.getInstance();
		c.set(Calendar.DAY_OF_MONTH, c.get(Calendar.DAY_OF_MONTH)-1);
		createFiles(DateUtil.getDateString(c.getTime(), "yyyy-MM-dd"));
	}
	
	private void write2File(File file, List<RecData> content) {
		PrintWriter pw = null;
		try {
			pw = new PrintWriter(new FileWriter(file, true));
			for (RecData row : content) {
				pw.println(row.toString());
			}
		} catch (Exception e) {
			logger.error(String.format("生成对账文件[%s]失败", file.getName()), e);
		} finally {
			if (pw != null) {
				pw.close();
			}
		}
	}
	
	private String getFileName(String date, int fileNo, int totalfileNum) {
		if (date == null || date.length() == 0) {
			return null;
		}
		return new StringBuilder().append("ord_bank.").append(date)
				.append(".").append(fileNo).append("-").append(totalfileNum)
				.append(".txt").toString();
	}
	
	/**
	 * 方法说明：生成文件
	 * 
	 * @param path 路径
	 * @param filename 文件名
	 * @return
	 */
	private File generateFile(String path, String date, String filename) {
		if (StringUtils.isEmpty(path) || StringUtils.isEmpty(filename)) {
			return null;
		}
		String dirStr = path + date + "/";
		File dir = new File(dirStr);
		if (!dir.exists()) {
			try{
				dir.mkdirs();
			}catch(SecurityException e) {
				logger.info("[ It doesn't own the create directory rights. ]");
			}
		}
		return new File(dirStr + filename);
	}
	
	private void upload(List<File> files,String date) {
		SFTPClient client = new SFTPClient(fileSystemIp, fileSystemPort, fileSystemUser, fileSystemPass);
		client.upload(files, fileSystemPathStr + date + "/", true);
	}

	/**
	 * 清除本地文件
	 * 
	 * 方法说明：
	 * 
	 * @param dirPath
	 */
	private void removeLocal(String dirPath) {
		File dir = new File(dirPath);
		for (File file : dir.listFiles()) {
			try{
				file.delete();
			}catch(SecurityException e) {
				logger.info("[ It doesn't own the create directory rights. ]");
			}
		}
		try{
			dir.delete();
		}catch(SecurityException e) {
			logger.info("[ It doesn't own the create directory rights. ]");
		}
	}
	
	/**
	 * 方法说明：获得结果集
	 *
	 * @param reconDate
	 * @param pageNo
	 * @param pageSize
	 * @return
	 * @throws Exception
	 */
	private List<RecData> getDB(String reconDate, int pageNo, int pageSize) throws Exception {
		if (pageNo <= 0) {
			pageNo = 1;
		}
		int start = (pageNo - 1) * pageSize;
		int end = start + pageSize;
		return collectInfoDao.queryRecon(reconDate, start, end);
	}
	
	/**
	 * 方法说明：初始化参数
	 *
	 */
	private void initParam() {
		Map<String, BaseParam> paramMap = configruationCenter.findParamBySystemName(SystemName.ACQUIRER);
		//本地路径
		ReconciliationServiceImpl.localPathStr = paramMap.get("acqLocalPath").getParamValue();
		//远程文件服务器IP
		ReconciliationServiceImpl.fileSystemIp = paramMap.get("fileSysIp").getParamValue();
		//远程文件服务器端口
		ReconciliationServiceImpl.fileSystemPort = Integer.parseInt(paramMap.get("fileSysPort").getParamValue());
		//远程文件服务器登录名
		ReconciliationServiceImpl.fileSystemUser = paramMap.get("fileSysUser").getParamValue();
		//远程文件服务器口令
		ReconciliationServiceImpl.fileSystemPass = paramMap.get("fileSysPass").getParamValue();
		//远程服务器路径
		ReconciliationServiceImpl.fileSystemPathStr = paramMap.get("acqRemotePath").getParamValue();
		//单个文件大小
		ReconciliationServiceImpl.fileSize = Integer.parseInt(paramMap.get("fileSize").getParamValue());
		//每次获取记录条数
		ReconciliationServiceImpl.fetchSize = Integer.parseInt(paramMap.get("fetchSize").getParamValue());
	}
	
}
