package com.sfpay.acquirer.domain;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：<br>
 * 枚举参数类型表
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2015年12月8日
 */
public class EnumTypeInfoDTO extends BaseEntity {

	private static final long serialVersionUID = -1470697314469996241L;

	/**
	 * 主类型
	 */
	private String enumType;
	/**
	 * 编码
	 */
	private String enumCode;
	/**
	 * 名称
	 */
	private String enumName;
	/**
	 * 备注
	 */
	private String remark;

	public String getEnumCode() {
		return enumCode;
	}

	public String getEnumName() {
		return enumName;
	}

	public String getRemark() {
		return remark;
	}

	public String getEnumType() {
		return enumType;
	}

	public void setEnumCode(String enumCode) {
		this.enumCode = enumCode;
	}

	public void setEnumName(String enumName) {
		this.enumName = enumName;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public void setEnumType(String enumType) {
		this.enumType = enumType;
	}

}
