/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IBatchInfoDao;
import com.sfpay.acquirer.dao.IBatchRuleInfoDao;
import com.sfpay.acquirer.dao.IParamInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.dao.ITotalBatchInfoDao;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.domain.PayoutForCheckBatchQueryParam;
import com.sfpay.acquirer.domain.PayoutForCheckTotalBatchQueryParam;
import com.sfpay.acquirer.domain.PayoutForCreateBatchQueryParam;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutQueryParam;
import com.sfpay.acquirer.domain.PayoutQueryRlt;
import com.sfpay.acquirer.domain.PayoutRlt;
import com.sfpay.acquirer.domain.PayoutRlt4Ext;
import com.sfpay.acquirer.domain.TotalBatchInfo;
import com.sfpay.acquirer.enums.AcctType;
import com.sfpay.acquirer.enums.BatchOperatorType;
import com.sfpay.acquirer.enums.PaymentStatusExt;
import com.sfpay.acquirer.enums.PayoutBatchQueryType;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.enums.SystemSource;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.acquirer.service.ICheckDuplicateTransfer;
import com.sfpay.acquirer.service.IPayoutQueryService;
import com.sfpay.ebank.gw.IPayoutSAO;
import com.sfpay.ebank.gw.domain.PayoutDTO;
import com.sfpay.ebank.gw.domain.QryPayoutReq;
import com.sfpay.ebank.gw.domain.QryPayoutResp;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 
 * 类说明：<br>
 * 付款 查询类service实现
 * 包括付款明细查询、生成批次前的查询等
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2012-10-25
 */
@Service("payoutQueryService")
@HessianExporter
public class PayoutQueryServiceImpl implements IPayoutQueryService {
	private static Logger logger = LoggerFactory.getLogger(PayoutQueryServiceImpl.class);
	private static final boolean isDebug = logger.isDebugEnabled();
	@Resource
	private IPayoutInfoDao payoutInfoDao;
	
	@Resource
	private IBatchInfoDao batchInfoDao;
	
	@Resource
	private IBatchRuleInfoDao ruleDao;
	
	@Resource
	private ITotalBatchInfoDao totalBatchInfoDao;
	@Resource
	private IParamInfoDao paramInfoDao;
	
	@Resource
	private ICheckDuplicateTransfer checkDuplicateTrans;
	
	@Resource
	IPayoutSAO payoutSAO;
	
	@Override
	public IPage<PayoutQueryRlt> queryPayoutPage(PayoutQueryParam param, int pageNo, int pageSize) throws ServiceException {
		//检查并处理重复提交付款请求  2015-01-16 sfhq270
		/*try{去掉查询防重检查
		  checkDuplicateTrans.checkAndProcessDuplicatePayout();
		}catch(Exception e ){
			logger.info("检查或处理重复付款请求异常 e：{}",e);
		}*/
		//查询总记录数
		Map<String, BigDecimal> res = payoutInfoDao.countPayoutPage(param);
		long count =  res.get("TOTAL_NUM").longValue();
		List<PayoutQueryRlt> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			list = payoutInfoDao.queryPayoutPage(param, start, end);
		}
		return new Page<PayoutQueryRlt>(list, count, pageNo, pageSize);
	}
	
    @Override
    public Map<String, Object> queryPayoutTotal(PayoutQueryParam param) throws ServiceException {
        Map<String, BigDecimal> total = payoutInfoDao.countPayoutPage(param);
        Map<String, Object> res = new HashMap<String, Object>();
        res.put("totalNum", total.get("TOTAL_NUM"));
        res.put("totalAmt", total.get("TOTAL_AMT"));
        String maxExportNum =  paramInfoDao.getParameter("MAX_EXCEL_EXPORT_NUM");
        res.put("maxExportNum", maxExportNum);
        return res;
    }
    
	@Override
	public IPage<PayoutInfo> queryPayoutForCreateBatch(PayoutForCreateBatchQueryParam param,int pageNo, int pageSize) throws ServiceException {
		
		//检查并处理重复提交付款请求  2015-01-16 sfhq270
		try{
		  checkDuplicateTrans.checkAndProcessDuplicatePayout();
		}catch(Exception e ){
			logger.info("检查或处理重复付款请求异常 e：{}",e);
		}
		//检查参数
		if(param == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"param is null");
		}
		AcctType oppAcctType = null;
		//路由生成
		if(PayoutBatchQueryType.BY_RULE.equals(param.getQueryType())){
			if(StringUtils.isEmpty(param.getRuleCode())) {
				throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "RuleCode is null");
			}
			param.setRuleCode(param.getRuleCode().trim());
			
			BatchRuleInfo rule = ruleDao.queryBatchRuleInfoByCode(param.getRuleCode());
			if(rule == null) {
				throw new ServiceException(InfoCode.NO_QUERY_RECORD,"batchRule is null");
			}
			oppAcctType = rule.getOppAcctType();
			if(!StringUtils.isEmpty(rule.getSuperInterFlag()))//跨行查询需要
				param.setCrossline(rule.getSuperInterFlag().trim());
			param.setBankCode(rule.getBankCode());
		}
		
		//查询总记录数 
		//#on:非结算中心的路由规则不能查询顺手付的流水. off:不限制。2014-12-02 by sfhq270
		String switchFlag=Property.getProperty("SZFS_SWITCH");
		logger.info("开关标志switchFlag:{}",switchFlag);
		long count = this.payoutInfoDao.countQueryByRule(param, PayoutStatus.INIT, oppAcctType,switchFlag);
		List<PayoutInfo> list = null;
		if(count!=0){
			if(pageNo<=0){
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			list = this.payoutInfoDao.queryByRule(param, PayoutStatus.INIT, oppAcctType, start, end,switchFlag);
		}
		//余额不足异常处理
		return new Page<PayoutInfo>(list, count, pageNo, pageSize);
	}

	@Override
	public IPage<BatchInfo> queryPayoutForCheckBatch(PayoutForCheckBatchQueryParam param, int pageNo, int pageSize) throws ServiceException {
		//检查参数
		if(param == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"param is null");
		}
		
		if (BatchOperatorType.AUTO.equals(param.getOperatorType())) {
			return queryPayoutForAutoCheckBatch(param, pageNo, pageSize);
		} else {
			return queryPayoutForHandCheckBatch(param, pageNo, pageSize);
		}
	}
	
	/**
	 * 查询需要复核的手工方式生成的批次的付款信息，
	 * @param param
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	private IPage<BatchInfo> queryPayoutForHandCheckBatch(PayoutForCheckBatchQueryParam param, int pageNo, int pageSize) {
		//查询总记录数
		long count = this.batchInfoDao.countPayoutForCheckBatch(param);
		List<BatchInfo> list = null;
		if(count!=0){
			if(pageNo<=0){
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			list = this.batchInfoDao.queryPayoutForCheckBatch(param, start, end);
		}
		return new Page<BatchInfo>(list, count, pageNo, pageSize);
	}
	
	/**
	 * 查询需要复核的自动方式生成的批次的付款信息
	 * @param param
	 * @param pageNo
	 * @param pageSize
	 * @return
	 */
	private IPage<BatchInfo> queryPayoutForAutoCheckBatch(PayoutForCheckBatchQueryParam param, int pageNo, int pageSize) {
		//查询总记录数
		long count = this.batchInfoDao.countPayoutForAutoCheckBatch(param);
		List<BatchInfo> list = null;
		if(count!=0){
			if(pageNo<=0){
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			list = this.batchInfoDao.queryPayoutForAutoCheckBatch(param, start, end);
		}
		return new Page<BatchInfo>(list, count, pageNo, pageSize);
	}

	@Override
	public PayoutRlt queryPayout(String payoutNo) throws ServiceException {
		if(payoutNo == null || "".equals(payoutNo = payoutNo.trim())){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"付款编号不能为空");
		}
		PayoutRlt rlt = payoutInfoDao.queryPayoutByPayoutNo(payoutNo);
		
		if(rlt == null){
			if(isDebug){
				logger.debug("无此付款编号[{}]记录.",payoutNo);
			}
			throw new ServiceException(InfoCode.NO_QUERY_RECORD,"无此付款编号["+payoutNo+"]记录.");
		}
		
		rlt.setPaymentStatusExt(convertToExtStatus(rlt.getPayoutStatus(),rlt.getOfflineFlag()));
		
		if(isDebug){
			logger.info("查询结果:{}",rlt.toString());
		}
		return rlt;
	}
	
	@Override
	public PayoutRlt4Ext queryPayout(SystemSource src, String payoutNo, String tradeNo, String businessNo) throws ServiceException {
		if(null == src) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "系统来源不能为空");
		}
		if(StringUtils.isEmpty(payoutNo) && StringUtils.isEmpty(tradeNo) && StringUtils.isEmpty(businessNo)) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "付款流水号、外部交易流水号、外部业务流水号必填其一");
		}
		logger.info(String.format("查询付款记录参数: [%s]-[%s]-[%s]-[%s]", src, payoutNo, tradeNo, businessNo));
		PayoutRlt4Ext rlt = null;
		try {
			QryPayoutReq qryPayoutReq = new QryPayoutReq();
			qryPayoutReq.setPageNo(1);
			qryPayoutReq.setPageSize(10);
			qryPayoutReq.setPayoutNo(payoutNo);
			qryPayoutReq.setReqDate(new Date());
			qryPayoutReq.setReqSn(RandomStringUtils.randomAlphanumeric(12));
			if (src != null) {
				qryPayoutReq.setSystemSource(src.name());
			}
			if (tradeNo != null) {
				qryPayoutReq.setTradeOutNo(tradeNo);
			}
			qryPayoutReq.setVersion("0");
			logger.info(String.format("查询付款记录参数: [%s]-[%s]-[%s]-[%s]，调用ebank-gw", src, payoutNo, tradeNo, businessNo));
			QryPayoutResp resp = payoutSAO.queryPayouts(qryPayoutReq );
			List<PayoutDTO> list = resp.getPayoutList();
			if (list != null && list.size() == 1) {
				PayoutDTO dto = list.get(0);
				rlt = new PayoutRlt4Ext();
				rlt.setPayoutNo(payoutNo);
				rlt.setPaymentStatusExt(PaymentStatusExt.valueOf(dto.getStatus()));
				rlt.setAmt(dto.getAmt());
				if (PaymentStatusExt.FAILURE.name().equals(dto.getStatus())
						|| PaymentStatusExt.SUCCESS.name().equals(dto.getStatus())) {
					rlt.setPayoutStatus(PayoutStatus.valueOf(dto.getStatus()));
				} else {
					rlt.setPayoutStatus(PayoutStatus.RECEIVED);
				}
				rlt.setTransDate(dto.getEndTime());
				rlt.setRemark((dto.getRtnBankMsg() == null ? "" : dto.getRtnBankMsg())
						+ (dto.getRemark() == null ? "" : dto.getRemark()));
			}
			
//			rlt = payoutInfoDao.queryPayoutByExt(src, payoutNo, tradeNo, businessNo);
		} catch (Exception e) {
			logger.error(String.format("查询付款记录([%s]-[%s]-[%s]-[%s])异常", src, payoutNo, tradeNo, businessNo), e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE, "查询付款记录异常",e);
		}
		if(rlt == null) {
			logger.info(String.format("无法找到([%s]-[%s]-[%s]-[%s])对应的付款记录", src, payoutNo, tradeNo, businessNo));
			return null;
		}
//		rlt.setPaymentStatusExt(convertToExtStatus(rlt.getPayoutStatus(),rlt.getOfflineFlag()));
		return rlt;
	}
	
	private PaymentStatusExt convertToExtStatus(PayoutStatus status, YNFlag offlineFlag) {
		PaymentStatusExt res;
		switch (status) {
		case SUCCESS:// ("交易成功"),
			res = PaymentStatusExt.SUCCESS;
			break;
		case FIR_CHECK_REFUSE:// ("第一次复核拒绝"),
		case SEC_CHECK_REFUSE:// ("第二次复核拒绝"),
		case REJECT:// ("受理被拒绝"),
			res = PaymentStatusExt.FAILURE;
			break;
		case FAILURE:// ("交易失败"),
			if (YNFlag.Y.equals(offlineFlag)) {//人工确认
				res = PaymentStatusExt.FAILURE;
			} else {
				res = PaymentStatusExt.WAITING;
			}
			break;
		default:
			res =  PaymentStatusExt.WAITING;
		}
		return res;
	}

	@Override
	public PayoutInfo queryPayoutInfobyID(Long id) throws ServiceException{
		if(isDebug){
			logger.debug("查询ID:{}",id);
		}
		if(id == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"ID不能为空.");
		}
		try{
			PayoutInfo info = payoutInfoDao.queryById(id);
			if(isDebug){
				logger.debug("根据ID查询出的付款信息:[{}]", info == null?"无此付款记录":info.toString());
			}
			return info;
		}catch(Exception ex){
			logger.error("根据ID查询异常:",ex);
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR,"查询异常："+ex);
		}
	}

	@Override
	public IPage<TotalBatchInfo> queryForCheckTotalBatch(PayoutForCheckTotalBatchQueryParam param, int pageNo, int pageSize)throws ServiceException {
		//检查参数
		if(param == null){
		   throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"param is null");
		}
		// 查询总记录数
		long count = this.totalBatchInfoDao.queryPayoutForCheckTotalBatchCount(param);
		IPage<TotalBatchInfo> page = null;
		List<TotalBatchInfo> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int startPosition = (pageNo - 1) * pageSize;
			int endPosition = startPosition + pageSize;

			// 查询当前页记录
			list = this.totalBatchInfoDao.queryPayoutForCheckTotalBatch(param,
					startPosition, endPosition);

			page = new Page<TotalBatchInfo>(list,count, pageNo, pageSize);
		}
		return page;
	}

	@Override
	public IPage<PayoutQueryRlt> queryPageByTotalBatch(PayoutQueryParam param,int pageNo, int pageSize) throws ServiceException {		      
		//直接调用原有接口  增加总批次号查询条件
		return this.queryPayoutPage(param, pageNo, pageSize);
	}



}
