/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.CountryCity;

/**
 * 
 * 类说明：<br>
 * 省份城市地区码dao
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2012-10-23
 */
public interface ICountryCityDao {

	/**
	 * 方法说明：<br>
	 * 添加
	 *
	 * @param countryCity
	 */
	public void save(CountryCity countryCity);
	
	/**
	 * 方法说明：<br>
	 * 删除
	 *
	 * @param id
	 */
	public void deleteById(@Param("id")long id);
	
	/**
	 * 方法说明：<br>
	 * 查询所有省/直辖市
	 *
	 * @return
	 */
	public List<CountryCity> queryProvince();
	
	/**
	 * 方法说明：<br>
	 * 按父节点的countryCode查询
	 *
	 * @param countryCode 父节点的城市编码
	 * @return
	 */
	public List<CountryCity> queryByParentCode(@Param("countryCode")String countryCode);
	
	/**
	 * 方法说明：<br>
	 * 按countryCode查询
	 *
	 * @param countryCode
	 * @return
	 */
	public List<CountryCity> queryByCode(@Param("countryCode")String countryCode);
	
	/**
	 * 方法说明：<br>
	 * 查询父节点
	 *
	 * @param countryCode
	 * @return
	 */
	public CountryCity queryParentByCode(@Param("countryCode")String countryCode);
	
	/**
	 * 方法说明：<br>
	 * 按省份城市中文名称模糊查询
	 * 
	 * @param countryName
	 * @return
	 */
	public List<CountryCity> queryProvinceByName(@Param("name") String name);
}
