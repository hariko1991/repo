package com.sfpay.acquirer.gate.b2e.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.domain.AccountBalance;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.AccountTransInfo;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.HisAcctTxQueryParam;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.gate.b2e.BaseQuery;
import com.sfpay.acquirer.gate.b2e.domain.BalInfo;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.QueryCurBalInfo;
import com.sfpay.acquirer.gate.b2e.domain.TransDtlInfo;
import com.sfpay.acquirer.gate.b2e.service.IBankService;
import com.sfpay.acquirer.gate.b2e.service.IQuery;
import com.sfpay.framework.base.exception.ServiceException;
/**
 * 
 * 
 * 类说明：<br>
 * 查询（余额、交易明细）
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-5-16
 */
@Service("icbcQuery")
@SuppressWarnings("deprecation")
public class ICBCQuery extends BaseQuery implements IQuery {
	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IBankService bankService;

	@Override
	protected AccountBalance convert2AccountBalance(BeanBase bean) {
		AccountBalance balRes = null;
		try{
			QueryCurBalInfo resp = (QueryCurBalInfo)bean.getBusDetailBeanBase();
			BalInfo balInfo = resp.getBalInfo();

			//转换查询结果
			balRes = new AccountBalance();
			balRes.setAccountNo(balInfo.getAccNo()); //银行账号
			balRes.setBankCode(BankCode.ICBC); //银行编码
			balRes.setCurrencyType(balInfo.getCur());//币种
			balRes.setAvailableAmt(balInfo.getUsableBal()+"");//可用余额
			balRes.setCurrentAmt(balInfo.getCurBal()+"");//当前余额
			balRes.setYesterdayAmt(balInfo.getLastBal()+"");//昨日余额
			balRes.setFrozenAmt(balInfo.getFreezeBal()+"");//冻结余额
			balRes.setRetainAmt(balInfo.getHoldBal()+"");//保留余额
			balRes.setQueryDate(DateUtil.getDateFormatStr(resp.getSendTime(), DateUtil.DATA_FORMAT_PATTERN));//查询时间 20130103124300000051
			logger.info("余额信息:{}",balRes.toString());
		}catch(Exception ex){
			logger.error("查询余额异常",ex);
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "查询余额异常", ex);
		}
		return balRes;
	}

	@Override
	protected List<AccountTransInfo> convert2CurAccountTransInfoList(
			List<TransDtlInfo> transInfos) {

		List<AccountTransInfo> respList = new ArrayList<AccountTransInfo>();
		//迭代封装接口返回对象
		try{
			for(TransDtlInfo info : transInfos){
				AccountTransInfo trans = new AccountTransInfo();
				trans.setBalanceAmt("");//余额
				trans.setAccountNo(info.getAccNo());//账号
				trans.setBankTxSn(info.getSerialId());//银行交易流水号
				trans.setBankCode(BankCode.ICBC);//银行编码
				String drcrf = info.getCdSign();//1:借 0:贷
				if("1".equals(drcrf)){
					trans.setDrAmt(info.getAmt()+"");//借方金额
					trans.setCrAmt("");//贷方金额
				}else if("0".equals(drcrf)){
					trans.setCrAmt(info.getAmt()+"");//贷方金额
					trans.setDrAmt("");//借方金额
				}
				trans.setReverseAcctNo(info.getPayeeAccNo());//对方单位账号
				trans.setReverseAcctName(info.getPayeeAccName());//对方单位名称
				trans.setSummary(info.getUserfor());//摘要
				trans.setTxDate(info.getTransTime());//交易日期
				trans.setRemark("");//备注
				respList.add(trans);
			}
		}catch(Exception ex){
			logger.error("查询当天交易异常",ex);
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "查询当天交易异常", ex);
		}
		return respList;
	}

	@Override
	protected List<AccountTransInfo> convert2HisAccountTransInfoList(
			List<TransDtlInfo> transInfos) {

		List<AccountTransInfo> respList = new ArrayList<AccountTransInfo>();
		//迭代封装接口返回对象
		try{
			for(TransDtlInfo transDtlInfo : transInfos){
				AccountTransInfo trans = new AccountTransInfo();
				trans.setAccountNo(transDtlInfo.getAccNo());//账号
				trans.setBalanceAmt("");//余额
				trans.setBankCode(BankCode.ICBC);//银行编码
				trans.setBankTxSn(transDtlInfo.getSerialId());//银行交易流水号
				String drcrf = transDtlInfo.getCdSign();//1:借 0:贷
				if("1".equals(drcrf)){
					trans.setCrAmt("");//贷方金额
					trans.setDrAmt(transDtlInfo.getAmt()+"");//借方金额
				}else if("0".equals(drcrf)){
					trans.setCrAmt(transDtlInfo.getAmt()+"");//贷方金额
					trans.setDrAmt("");//借方金额
				}
				trans.setRemark("");//备注
				trans.setReverseAcctName(transDtlInfo.getPayeeAccName());//对方单位名称
				trans.setReverseAcctNo(transDtlInfo.getPayeeAccNo());//对方单位账号
				trans.setSummary(transDtlInfo.getUserfor());//摘要
				trans.setTxDate(transDtlInfo.getTransTime());//交易日期
				respList.add(trans);
			}
		}catch(Exception ex){
			logger.error("查询历史交易异常",ex);
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "查询历史交易异常", ex);
		}
		return respList;
	}

	@Override
	public AccountBalance queryAccountBalance(BankProperty property,
			AccountInfo acct) throws ServiceException {
		return super.doQueryAccountBalance(property, acct, bankService);
	}

	@Override
	public List<AccountTransInfo> queryCurAccountTransList(
			BankProperty property, AccountInfo acct) throws ServiceException {
		return super.doQueryCurAccountTransList(property, acct, bankService);
	}

	@Override
	public List<AccountTransInfo> queryHisAccountTransList(
			BankProperty property, HisAcctTxQueryParam param)
					throws ServiceException {
		return super.doQueryHisAccountTransList(property, param, bankService);
	}

}
