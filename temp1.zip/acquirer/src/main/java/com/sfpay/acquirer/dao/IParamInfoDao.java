/**
 * =================================================================
 * 版权所有 2011-2013 深圳市泰海网络科技服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.ParamInfo;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 银企配置参数类,从数据库中获取相应的配置参数
 * </p>
 *  
 * @author 400928 向鹏
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-5-27
 */
public interface IParamInfoDao {
	
	/**
	 * 方法说明：<br>
	 * 传入变量名称到数据获取相应的变量配置值
	 * @param parameterName
	 * @return
	 */
	public String getParameter(@Param("paramCode") String paramCode);
	
	/**
	 * 方法说明：<br>
	 * 根据指定的批量健名查找对应的参数配置信息
	 * 
	 * @param keys 参数名列表
	 * @return
	 */
	public List<ParamInfo> findByKeys(@Param("keys") List<String> keys);

}
