/**
 * =================================================================
 * 版权所有 2011-2013 深圳市泰海网络科技服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;


import java.util.List;

import org.apache.ibatis.annotations.Param;
import com.sfpay.acquirer.domain.PayoutForCheckTotalBatchQueryParam;
import com.sfpay.acquirer.domain.TotalBatchInfo;
import com.sfpay.acquirer.enums.BatchStatus;

/**
 * 类说明：<br>
 * 总批次数据库操作类
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 *  
 * @author 400928 向鹏
 * 
 * CreateDate: 2013-9-4
 */
public interface ITotalBatchInfoDao {
	
	/**
	 * 方法说明：<br>
	 * 添加总批次信息
	 *
	 * @param batchInfo
	 */
	public void saveTotalBatchInfo(TotalBatchInfo batchInfo);
	
	/**
	 * 方法说明：<br>
	 * 查询生成批次前的付款信息 总条数
	 *
	 * @param param
	 * @return
	 */
	public long queryPayoutForCheckTotalBatchCount(@Param("param")PayoutForCheckTotalBatchQueryParam param);
	
	
	
	/**
	 * 方法说明：<br>
	 * 查询生成批次前的付款信息
	 *
	 * @param param
	 * @return
	 */
	public List<TotalBatchInfo> queryPayoutForCheckTotalBatch(@Param("param")PayoutForCheckTotalBatchQueryParam param,@Param("startPosition") int startPosition, @Param("endPosition") int endPosition);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 更新总批次状态信息，用以支持批量复核支付
	 * @param totalBatchCode
	 * @param status
	 * @return
	 */
	public int updateTotalBatchStatus(@Param("totalBatchCode")String totalBatchCode,@Param("status")BatchStatus status,@Param("checkDesc")String checkDesc,@Param("checkOperator")String checkOperator,@Param("oldStatus")BatchStatus oldStatus);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据总批次号查询单个总批次信息
	 * @param totalBatchCode
	 * @return
	 */
	public TotalBatchInfo queryBatchInfo(@Param("totalBatchCode")String totalBatchCode);

	/**
	 * 方法说明：<br>
	 * 修改冻结/解冻信息
	 *
	 * @param payoutInfo
	 * @param remark 状态为DONE时记录的备注信息
	 * @return
	 */
	public int updateFreeze(@Param("tbNos")List<String> tbNos,@Param("remark")String remark) throws Exception;
}
