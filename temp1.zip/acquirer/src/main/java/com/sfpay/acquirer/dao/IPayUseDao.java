/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.PayUse;
import com.sfpay.acquirer.domain.PayUseQueryParam;

/**
 * 类说明：<br>
 * 付款用途　dao
 * 
 * <p>
 * 详细描述：<br>
 * 付款用途　dao
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2012-9-28
 */
public interface IPayUseDao {
	
	/**
	 * 方法说明：<br>
	 * 添加付款用途
	 *
	 * @param payUse
	 */
	public void addPayUse(PayUse payUse);
	
	/**
	 * 方法说明：<br>
	 * 删除付款用途
	 *
	 * @param id　
	 */
	public void deletePayUse(@Param("id")long id);
	
	/**
	 * 方法说明：<br>
	 * 分页查询付款用途
	 *
	 * @param map 查询条件
	 * @return
	 */
	public List<PayUse> queryUsePage(@Param("param") PayUseQueryParam param, @Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：
	 * 分页查询 总条数
	 * @param map 查询条件
	 * @return
	 */
	public long countUsePage(@Param("param") PayUseQueryParam param); 
	
	/**
	 * 方法说明：<br>
	 * 查询所有付款用途
	 *
	 * @return
	 */
	public List<PayUse> queryUseAll();
	
	/**
	 * 方法说明：<br>
	 * 查询某用途记录数
	 * id!=null 查询除ID外记录，
	 * @param useDesc
	 * @param id
	 * @return
	 */
	public long queryUseCount(@Param("useDesc")String useDesc,@Param("id")Long id);
	
	/**
	 * 方法说明：<br>
	 * 修改
	 *
	 * @param payUse
	 */
	public void updatePayUse(PayUse payUse);
	
	/**
	 * 方法说明：<br>
	 * 根据ID修改
	 *
	 * @param id
	 * @param userDesc
	 * @param remark
	 * @param showIndex
	 */
	public void updatePayUseById(@Param("id")Long id, @Param("useDesc")String useDesc, @Param("remark")String remark, @Param("showIndex")Long showIndex);
	
	/**
	 * 方法说明：<br>
	 * 按条件查询
	 *
	 */
	public List<PayUse> queryUse(PayUse payUse);
	
	/**
	 * 方法说明：<br>
	 * 根据ID查询　
	 *
	 * @param id
	 * @return
	 */
	public PayUse queryUseById(@Param("id")long id);

}
