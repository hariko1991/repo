package com.sfpay.acquirer.service;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.AcquirerHelper;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.dao.IBatchInfoDao;
import com.sfpay.acquirer.dao.IBatchRuleInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.domain.PayoutExchange;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.ExchangeType;
import com.sfpay.acquirer.enums.PayoutSendStatus;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.gate.b2e.service.impl.Payout;
import com.sfpay.coreplatform.order.service.IBankPayService;
import com.sfpay.coreplatform.order.valueobject.dto.PayBeforeRequest;
import com.sfpay.coreplatform.order.valueobject.dto.PayResponse;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;

/**
 * 
 * 
 * 类说明：<br>
 * 发起付款指令
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-4-27
 */
@Service
public class B2EPayoutServiceImpl implements IB2EPayoutService {
	private static Logger logger = LoggerFactory.getLogger(B2EPayoutServiceImpl.class);
	
	/**
	 * 平台会员号
	 */
	private Long memberNo = Long.valueOf(Property.getProperty("PLATFORM_MEMBER_NO"));
	
	@Resource
	private IPayoutInfoDao payoutInfoDao;
	
	@Resource
	private IBatchInfoDao batchInfoDao;
	
	@Resource
	private IBatchRuleInfoDao ruleDao;
	
	@Resource
	private IBankPayService orderService;
	
	@Resource
	private IPayoutExchangeService exchangeService;
	@Resource
	private IChannelFieldMappingService channelFieldMappingService;

	@Override
	public void doPayoutReq(BatchInfo bi,BatchRuleInfo rule) throws ServiceException {
		if(bi == null){
			throw new ServiceException(InfoCode.FAILURE, "批次信息不为空.");
		}
		if(rule == null){
			throw new ServiceException(InfoCode.FAILURE, "批次[请求流水号:"+bi.getReqBankSn()+"]的路由规则不能为空.");
		}
		
		logger.info("开始处理批次[{}]交易请求信息...\n\t批次信息:[{}]", bi.getReqBankSn(), bi.toString());
		
		BankCode bankCode = bi.getPayerOrgCode();
		BankProperty property = AcquirerHelper.getProperties(bankCode, ChannelCode.B2E);
		
		//发起请求 放前面的目的是，自动出款需要，防止超时
		try {
			logger.info("更新发送交易请求状态为:{}", PayoutSendStatus.WAIT);
			bi.setSendStatus(PayoutSendStatus.WAIT);// 设置发送状态
			bi.setOldSendStatus(PayoutSendStatus.NOSEND);// 原来状态
			this.updateMQStatus(bi);
		} catch (Exception ex) {
			logger.error("批次[" + bi.getReqBankSn() + "],更新批次发送状态异常:", ex);
			// logger.error("批次[" + bi.getReqBankSn() + "],更新发送MQ结果异常:", ex);
			throw new ServiceException(InfoCode.FAILURE, "更新批次发送状态异常[" + ex.getMessage() + "]", ex);
		}
		
		//查询付款信息
		logger.info("第一步:查询批次流水[{}]付款信息...", bi.getReqBankSn());
		//增加查询条件付款渠道，查询收款行联行号。sfhq270  周丽佩  2014-12-01
		List<PayoutInfo> pis = this.payoutInfoDao.queryPay(bi.getBatchCode(),bankCode.name(), PayoutStatus.SEC_CHECK_PASS);
		if (pis == null || pis.size() == 0) {
			logger.error("查无批次流水[{}]付款记录.", bi.getReqBankSn());
			throw new ServiceException(InfoCode.FAILURE, "无第二次复核通过的付款记录");
		}
		
		logger.info("第二步:发送批次流水[{}]付款信息给订单系统...", bi.getReqBankSn());
		//发送订单系统
		this.sendOrderReq(pis, bi);
		
		//根据通道要求转换字段
		channelFieldMappingService.batchExecFieldMapping(pis, bi.getRuleCode());
		
		
		logger.info("第三步:组装批次流水[{}]请求报文并发送...",bi.getReqBankSn());
		PayoutSendStatus sendStatus = null;
		try {
			sendStatus = new Payout().doReq(bi, pis, property, bankCode, rule);
		} catch (Exception ex) {
			logger.error("批次流水["+bi.getReqBankSn()+"],生成付款报文异常:",ex);
			throw new ServiceException(InfoCode.FAILURE, "生成付款报文异常["+ex.getMessage()+"]", ex);
		}
		
		//更新结果
		logger.info("第四步:更新批次流水[{}]发送交易报文结果:{}", bi.getReqBankSn(), sendStatus);
		try {
			bi.setSendStatus(sendStatus);// 设置发送状态
			bi.setOldSendStatus(PayoutSendStatus.WAIT);
			this.updateMQStatus(bi);
		} catch (Exception ex) {
			logger.error("更新批次流水[" + bi.getReqBankSn() + "]发送MQ结果异常:", ex);
			throw new ServiceException(InfoCode.FAILURE, "更新发送MQ结果异常[" + ex.getMessage() + "]", ex);
		}
		
		logger.info("批次流水[{}]交易请求信息处理完成.发送结果 :{}", bi.getReqBankSn(), bi.getSendStatus());
	}
	
	
	/**
	 * 方法说明：<br>
	 * 更新结果
	 *
	 * @param batchInfo
	 * @param status
	 */
	private void updateMQStatus(BatchInfo batchInfo) throws Exception {
		//更新批次表
		int cnt = this.batchInfoDao.updateSend(batchInfo.getSendStatus(),batchInfo.getOldSendStatus(),batchInfo.getBatchCode(),batchInfo.getRemark());
		String msg = "更新批次[请求流水号:{}]发送状态("+batchInfo.getSendStatus()+")结果:";
		if(cnt > 0){
			logger.info(msg+"成功.",batchInfo.getReqBankSn());
		}else{
			logger.error(msg+"无记录更新.",batchInfo.getReqBankSn());
		}
	}


	@Override
	public void doPayoutReq(BatchInfo bi) throws ServiceException {
		if(bi == null){
			logger.error("批次信息不为空.");
			throw new ServiceException(InfoCode.FAILURE, "批次信息不为空.");
		}
		
		//查询规则
		BatchRuleInfo rule =ruleDao.queryBatchRuleInfoByCode(bi.getRuleCode());
		if(rule == null){
			throw new ServiceException(InfoCode.NO_QUERY_RECORD, "批次[请求流水号:"+bi.getReqBankSn()+"],规则["+bi.getRuleCode()+"]不存在.");
		}
		
		doPayoutReq(bi, rule);
	}

	/**
	 * 方法说明：<br>
	 * 发送请求信息到订单系统
	 *
	 * @param list 发送外系统的数据
	 * @param batchInfo　批次信息
	 */
	private void sendOrderReq(List<PayoutInfo> list,BatchInfo batchInfo){
		
		//生成交互信息
		List<PayoutExchange> ecList = null;
		try{
			ecList = this.exchangeService.createExchangeList(list, ExchangeType.SEND_BEFORE);
		}catch(Exception ex){
			logger.error("生成交互信息(发银行前)异常",ex);
			return;
		}
		
		//发送订单系统
		try{
			List<PayBeforeRequest> outPayout = this.converToOutPayRequest(ecList, batchInfo);
			if(outPayout.size() == 0){
				logger.info("批次[{}]不存在需要发送到订单系统的付款信息(发银行前)",batchInfo.getReqBankSn());
				return;
			}
			logger.info("开始调用订单系统(发银行前)");
			List<PayResponse> outPayResList = orderService.BankBeforepayAcc(outPayout);
			
			if(outPayResList == null || outPayResList.size() == 0){
				logger.info("批次【请求流水号:"+batchInfo.getReqBankSn()+"】,订单系统返回结果 = null");
				return;
			}
			logger.info("调用订单系统结束(发银行前),订单系统处理条数size:【{}】",outPayResList.size());
			
			for (PayResponse payInfo:outPayResList){
				try{
					//打印日志
					StringBuffer sb = new StringBuffer();
					sb.append("[payNo:").append(payInfo.getPayNo()).append(",")
						.append("retrunCode:").append(payInfo.getReturnCode()).append(",")
						.append("returnMsg:").append(payInfo.getReturnMsg()).append(",")
						.append("tradeNo:").append(payInfo.getTradeNo()).append(",")
						.append("tradeOutNo:").append(payInfo.getTradeOutNo()).append(",")
						.append("payDate:").append(payInfo.getPayDate()).append("]");
					logger.info("付款信息[交互流水:{}],更新订单系统返回( 发银行前 )信息:{}",payInfo.getTradeOutNo(),sb.toString());
					this.exchangeService.updateOrderResp(payInfo.getTradeNo(), payInfo.getTradeOutNo(), payInfo.getReturnCode()+"", payInfo.getReturnMsg(), ExchangeType.SEND_BEFORE);
				}catch(Exception ex){
					logger.error("付款信息[交互流水:"+payInfo.getTradeOutNo()+"],更新订单系统返回信息(发银行前)异常 = ",ex);
				}
			}
		}catch(Exception ex){
			logger.error("批次[请求流水号:"+batchInfo.getReqBankSn()+"],发送订单系统(发银行前)异常 = ",ex);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 转换订单系统请求对象
	 *
	 * @param infoList
	 * @param batchInfo
	 * @return
	 * @throws Exception
	 */
	private List<PayBeforeRequest> converToOutPayRequest(List<PayoutExchange> infoList,BatchInfo batchInfo) throws Exception {
		List<PayBeforeRequest> outPayout = new ArrayList<PayBeforeRequest>();
		if(infoList == null ||infoList.size() == 0){
			logger.info("批次[请求流水号{}],不存在需要转换订单系统对象的信息",batchInfo.getReqBankSn());
			return outPayout;
		}
		
		StringBuffer sb = new StringBuffer();
		for(Iterator<PayoutExchange> it = infoList.iterator();it.hasNext();){
			PayoutExchange exchange = it.next();
			PayBeforeRequest payBefore = new PayBeforeRequest();
			payBefore.setBusinessType(com.sfpay.coreplatform.order.common.enums.BusinessType.WIH_OUTPAY);
			payBefore.setCct(com.sfpay.coreplatform.order.common.enums.CcyType.valueOf(exchange.getCcy()==CurrencyType.CNY?"RMB":exchange.getCcy().name()));
			payBefore.setOrderType(com.sfpay.coreplatform.order.common.enums.OrderType.TRANSFER);
			payBefore.setPlatformMemberNo(memberNo);
			payBefore.setTradeOutNo(exchange.getExchangeNo());
			payBefore.setPayAmt(exchange.getAmt());

			//打印日志
			sb.append(",{tradeOutNo:").append(payBefore.getTradeOutNo())
				.append(",businessType:").append(payBefore.getBusinessType())
				.append(",ccy:").append(payBefore.getCct())
				.append(",orderType:").append(payBefore.getOrderType())
				.append(",payAmt:").append(payBefore.getPayAmt())
				.append(",platformMemberNo:").append(payBefore.getPlatformMemberNo())
				.append("}");
			outPayout.add(payBefore);
		}
		logger.info("需发送订单系统(发银行前)的付款信息 :\n\t{}", sb.substring(1));
		return outPayout;
	}
}
