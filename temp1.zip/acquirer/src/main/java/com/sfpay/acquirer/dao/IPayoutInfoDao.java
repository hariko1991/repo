/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.BatchTotal;
import com.sfpay.acquirer.domain.DeductionQueryParam;
import com.sfpay.acquirer.domain.FreezeQueryParam;
import com.sfpay.acquirer.domain.PayoutForCreateBatchQueryParam;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutOffline;
import com.sfpay.acquirer.domain.PayoutOfflineQueryParam;
import com.sfpay.acquirer.domain.PayoutQueryParam;
import com.sfpay.acquirer.domain.PayoutQueryRlt;
import com.sfpay.acquirer.domain.PayoutRlt;
import com.sfpay.acquirer.domain.PayoutRlt4Ext;
import com.sfpay.acquirer.enums.AcctType;
import com.sfpay.acquirer.enums.FreezeFlag;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.enums.SystemSource;
import com.sfpay.acquirer.enums.YNFlag;

/**
 * 类说明：<br>
 * 付款信息表 dao
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2012-10-25
 */
public interface IPayoutInfoDao {

	/**
	 * 方法说明：<br>
	 * 添加
	 *
	 * @param payoutInfo
	 */
	public void addPayoutInfo(PayoutInfo payoutInfo);
	
	/**
	 * 方法说明：<br>
	 * 分页查询
	 *
	 * @param param
	 * @param start
	 * @param end
	 * @return
	 */
	public List<PayoutQueryRlt> queryPayoutPage(@Param("param") PayoutQueryParam param, @Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：<br>
	 * 分页查询总条数
	 *
	 * @param param
	 * @return
	 */
	public Map<String,BigDecimal> countPayoutPage(@Param("param") PayoutQueryParam param);
	
	
	/**
	 * 方法说明：<br>
	 * 修改状态
	 *
	 * @param batchCode
	 * @param status
	 */
	public int updateStatusByBatchCode(@Param("batchCode")String batchCode
			,@Param("status")PayoutStatus status,@Param("oldStatus")PayoutStatus oldStatus);
	
	/**
	 * 方法说明：<br>
	 * 查询需要出批次的数据
	 *
	 * @param batchCode
	 * @param status
	 * @return
	 */
	public List<PayoutInfo> queryPayoutByBatch(@Param("batchCode")String batchCode,@Param("status")PayoutStatus status);
	
	/**
	 * 方法说明：<br>
	 * 查询出款数据
	 *
	 * @param batchCode
	 * @param status
	 * @param freezeFlag
	 * @return
	 */
	public List<PayoutInfo> queryPay(@Param("batchCode")String batchCode,@Param("bankCode")String bankCode,
			@Param("status")PayoutStatus status);
	
//	/**
//	 * 方法说明：<br>
//	 * '',''的格式
//	 * 查询总金额和总笔数
//	 *
//	 * @param payoutNos
//	 * @return
//	 */
//	public Long queryTotalCntByPayoutNos(@Param("payoutNos")List<String> payoutNos);
	
//	/**
//	 * 方法说明：<br>
//	 * '',''的格式
//	 * 查询总金额和总笔数
//	 *
//	 * @param payoutNos
//	 * @return
//	 */
//	public Long queryTotalAmtByPayoutNos(@Param("payoutNos")List<String> payoutNos);
	
	/**
	 * 方法说明：<br>
	 * 统计总金额和总笔数
	 * 
	 * @param payoutNos
	 * @return
	 */
	public BatchTotal totalAmtAndNum(@Param("batchCode") String batchCode);
	
	/**
	 * 方法说明：<br>
	 * 生成批次后，更新批次信息到付款信息中(单笔)
	 *
	 * @param payoutInfo
	 * @param payoutNos
	 * @param oldStatus
	 */
	public void batchUpdatePayout(@Param("payoutInfo") PayoutInfo payoutInfo, @Param("payoutNos") List<String> payoutNo, @Param("oldStatus")PayoutStatus oldStatus);
	
	/**
	 * 方法说明：<br>
	 * 更新银行返回结果
	 *
	 * @param payoutInfo
	 */
	public int updateBankRtn(@Param("payoutInfo")PayoutInfo payoutInfo);
	
	/**
	 * 方法说明：<br>
	 * 修改状态
	 *
	 * @param lastStatus
	 * @param status
	 * @param batchCode
	 */
//	public int updateStatus(@Param("status")PayoutStatus status
//			,@Param("batchCode")String batchCode,@Param("oldStatus")PayoutStatus oldStatus);
	
	/**
	 * 方法说明：<br>
	 * 修改状态(批次请求流水号)
	 *
	 * @param lastStatus
	 * @param status
	 * @param batchCode
	 */
	public void updateStatusByBatchReq(@Param("status")PayoutStatus status
			,@Param("batchReqBankSn")String batchReqBankSn,@Param("oldStatus")PayoutStatus oldStatus);
	
//	/**
//	 * 方法说明：<br>
//	 * 更新订单系统返回的流水号
//	 *
//	 * @param payoutInfo
//	 */
//	public int updateOrderRtn(@Param("tradeNo") String tradeNo, @Param("payNo") String payNo, @Param("payoutNo") String payoutNo, @Param("businessNo") String businessNo);
	
	/**
	 * 方法说明：<br>
	 * 查询生成批次前的信息
	 *
	 * @param map
	 * @return
	 */
	public List<PayoutInfo> queryByRule(@Param("param")PayoutForCreateBatchQueryParam param
			, @Param("status")PayoutStatus status, @Param("oppAcctType") AcctType oppAcctType,@Param("start") int start, @Param("end") int end,@Param("flag")String flag);
	
	/**
	 * 方法说明：<br>
	 * 查询生成批次前的信息 总条数
	 *
	 * @param param
	 * @return
	 */
	public long countQueryByRule(@Param("param")PayoutForCreateBatchQueryParam param,@Param("status")PayoutStatus status, @Param("oppAcctType") AcctType oppAcctType,@Param("flag")String flag);
	/**
	 * 方法说明：<br>
	 * 查询付款信息
	 *
	 * @param reqBankSn
	 * @return
	 */
	public PayoutInfo queryPayoutInfo(@Param("batchCode")String batchCode,@Param("reqBankSn")String reqBankSn);
	
	/**
	 * 方法说明：<br>
	 * 查询已生成批次的笔数
	 *
	 * @param payerOrgCode
	 * @param payoutNos
	 * @return
	 */
	public Long hasBuildBatch(@Param("payoutNos") List<String> payoutNos);
	
	/**
	 * 方法说明：<br>
	 * 检查账户
	 *
	 * @param batchCode
	 * @return
	 */
	public Long checkAcctType(@Param("payoutNos")List<String> payoutNos, @Param("payeeAcctType") AcctType payeeAcctType);
	
	/**
	 * 方法说明：<br>
	 * 查询付款信息
	 *
	 * @param batchCode
	 * @return
	 */
	public List<PayoutInfo> queryPayoutByBatchCode(@Param("batchCode")String batchCode);
	
	/**
	 * 方法说明：<br>
	 * 根据路由系统来源过滤顺手付付款总条数  2014-11-28
	 * @author sfhq270
	 * @param payoutNoList
	 * @return
	 */
	public Long filterTradeOut(@Param("payoutNoList")List<String> payoutNoList);
	
	/**
	 * 方法说明：<br>
	 * 根据路由规则支付收款银行过滤付款信息条数
	 *
	 * @param payoutNoList
	 * @param ruleCode
	 * @return
	 */
	public Long filterByBankGroup(@Param("payoutNoList")List<String> payoutNoList, @Param("ruleCode")String ruleCode);
	
	/**
	 * 方法说明：<br>
	 * 查询外系统最新记录
	 *
	 * @param systemSource
	 * @param tradeOutNo
	 * @return
	 */
	public PayoutInfo queryMaxTime(@Param("systemSource")SystemSource systemSource, @Param("tradeOutNo")String tradeOutNo,@Param("tradeOutBussinessNo")String tradeOutBussinessNo);
	
	/**
	 * 方法说明：<br>
	 * 按付款编号查询(外部业务系统使用)
	 *
	 * @param payoutNo
	 * @return
	 */
	public PayoutRlt queryPayoutByPayoutNo(@Param("payoutNo")String payoutNo);
	
	/**
	 * 方法说明：<br>
	 * 提供给外部使用调用的付款信息查询接口
	 *
	 * @param payoutNo
	 * @return
	 */
	public PayoutRlt4Ext queryPayoutByExt(@Param("src") SystemSource src, @Param("payoutNo") String payoutNo, @Param("tradeNo") String tradeNo, @Param("businessNo") String businessNo);
	
	/**
	 * 方法说明：<br>
	 * 按付款编号查询
	 *
	 * @param payoutNo
	 * @return
	 */
	public PayoutInfo findByPayoutNo(@Param("payoutNo")String payoutNo,@Param("freezeFlag")FreezeFlag freezeFlag);
	
	/**
	 * 方法说明：<br>
	 * 修改状态(异常处理：状态调整使用)
	 *
	 * @param batchCode
	 * @param status
	 */
	public int updateExceptionProcess(@Param("reqBankSn")String reqBankSn
			,@Param("status")PayoutStatus status,@Param("oldStatus")PayoutStatus oldStatus,@Param("remark")String remark
			,@Param("offlineFlag")YNFlag offlineFlag,@Param("offlineRemark")String offlineRemark);
	
	/**
	 * 方法说明：<br>
	 * 
	 * @param batchCode
	 * @return
	 */
	public  List<PayoutQueryRlt> queryPayoutDtlByBatchCode(@Param("batchCode")String batchCode);
	
	/**
	 * 方法说明：<br>
	 * 查找需要查询交易状态的数据
	 *
	 * @param batchCode
	 * @param status
	 * @return
	 */
	public List<PayoutInfo> queryByStatus(@Param("batchCode")String batchCode,@Param("status")PayoutStatus status);
	
	
	/**
	 * 方法说明：<br>
	 * 查找需要查询交易状态的数据
	 *
	 * @param batchCode
	 * @param status
	 * @return
	 */
	public List<PayoutInfo> queryByStatusNew(@Param("batchCode")String batchCode);

	/**
	 * 方法说明：<br>
	 * 根据ID查询
	 * @param batchCode
	 * @return
	 */
	public PayoutInfo queryById(@Param("id")Long id) throws Exception;
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据ID查询(批量)
	 * @param batchCode
	 * @return
	 */
//	public List<PayoutInfo> queryByIds(@Param("ids")List<Long> ids) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 修改付款信息
	 *
	 * @param payoutInfo
	 * @return
	 */
	public int updatePayoutById(@Param("param")PayoutInfo payoutInfo,@Param("agent")int agent) throws Exception ;
	
	/**
	 * 方法说明：<br>
	 * 根据ID删除（批量）
	 *
	 * @param id
	 * @return
	 */
//	public int deleteByIds(@Param("ids")List<Long> ids) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 根据ID删除（批量）
	 *
	 * @param id
	 * @return
	 */
	public int softDeleteByIds(@Param("ids")List<Long> ids,@Param("oldStatus")PayoutStatus oldStatus) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 计算已删除的付款信息
	 * 
	 * @param payoutNos
	 * @return
	 */
	public Long countDelPayout(@Param("payoutNos") List<String> payoutNos);
	
	/**
	 * 方法说明：<br>
	 * 更新人工操作信息
	 *
	 * @param payoutNos
	 * @param status
	 * @param offlineFlag
	 * @param offlineRemark
	 * @param oldOfflineFlag
	 * @return
	 * @throws Exception
	 */
	public int updateOfflineInfo(PayoutOffline payoutOffline) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 根据payoutNos查询
	 *
	 * @param payoutNos
	 * @return
	 * @throws Exception
	 */
	public List<PayoutInfo> queryByPayoutNos(@Param("payoutNos")List<String> payoutNos) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 分页查询(查询未人工操作)
	 *
	 * @param param
	 * @param start
	 * @param end
	 * @return
	 */
	public List<PayoutQueryRlt> queryOfflinePayoutPage(@Param("param") PayoutOfflineQueryParam param, @Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：<br>
	 * 分页查询总条数（查询未人工操作）
	 *
	 * @param param
	 * @return
	 */
	public Long countOfflinePayoutPage(@Param("param") PayoutOfflineQueryParam param);
	
	
	/**
	 * 
	 * 方法说明：<br>
	 * 抵扣明细总条数
	 * @param param
	 * @return
	 */
	public Long countNeedDeduction(@Param("param") DeductionQueryParam param);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 分页查询抵扣支付明细记录
	 * @param param
	 * @param start
	 * @param end
	 * @return
	 */
	public List<PayoutQueryRlt> queryNeedDeduction(@Param("param") DeductionQueryParam param,@Param("start") int start, @Param("end") int end);
	
//	/**
//	 * 
//	 * 方法说明：<br>
//	 * 抵扣明细总条数
//	 * @param param
//	 * @return
//	 */
//	public Long countDeductionInfos(@Param("param") DeductionQueryParam param);
//	/**
//	 * 
//	 * 方法说明：<br>
//	 * 分页查询已抵扣支付明细记录
//	 * @param param
//	 * @param start
//	 * @param end
//	 * @return
//	 */
//	public List<PayoutQueryRlt> queryDeductionInfos(@Param("param") DeductionQueryParam param,@Param("start") int start, @Param("end") int end);
	
	
	/**
	 * 
	 * 方法说明：<br>
	 * 更新抵扣记录信息
	 * @param payoutNo      支付指令编号
	 * @param deductionOper 抵扣操作员
	 * @param desc          抵扣描述
	 * @param deductionAmt  抵扣金额
	 * @param amt           实付金额
	 * @param status        指令状态
	 * @return
	 */
	public int updateDeductionInfo(@Param("payoutNo")String payoutNo,@Param("deductionOper")String deductionOper
			,@Param("desc")String desc,@Param("deductionAmt")Long deductionAmt
			,@Param("amt")Long amt,@Param("status")PayoutStatus status
			,@Param("freezeFlag")FreezeFlag freezeFlag);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据支付编号查询支付指令信息
	 * @param payoutNo
	 * @return
	 */
	public PayoutInfo queryPayoutInfoByPayNo(@Param("payoutNo")String payoutNo);
	
	
	/**
	 * 
	 * 方法说明：<br>
	 * 更新批次总批次号 用以支持批量付复支付
	 * @param totalBatchCode
	 * @return
	 */
	public int updateTotalBatchCode(@Param("totalBatchCode")String totalBatchCode,@Param("subBatchCode")List<String> subBatchCode);
	
	
	/**
	 * 
	 * 方法说明：<br>
	 * 统计冻结记录信息条数
	 * @param param
	 * @return
	 */
	
	public Long countFreezeInfos(@Param("param")FreezeQueryParam param);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 查询冻结付款记录信息
	 * @param param
	 * @return
	 */
	public List<PayoutQueryRlt> queryFreezeInfos(@Param("param")FreezeQueryParam param,@Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：<br>
	 * 查询付款信息(冻结使用)
	 *
	 * @param payoutNo
	 * @param statusList
	 * @return
	 */
	public List<PayoutInfo> findByStatus(@Param("payoutNos")List<String> payoutNo
			,@Param("statusList") List<PayoutStatus> statusList,@Param("freezeFlag")FreezeFlag freezeFlag);
	
	/**
	 * 方法说明：<br>
	 * 修改冻结/解冻信息
	 *
	 * @param payoutNo
	 * @param oldStatus
	 * @param oldFreezeFlag
	 * @return
	 */
	public int updateFreeze(@Param("payoutNos")List<String> payoutNos,@Param("freezeFlag")FreezeFlag freezeFlag
			,@Param("status")PayoutStatus status
			,@Param("oldFreezeFlag")FreezeFlag oldFreezeFlag) throws Exception;
	
	
	/**
	 * 查询重复的付款请求
	 * @return
	 * @throws Exception
	 */
	public List<String> queryDuplicateTransfer();	
	
	/**
	 * 查询重复的付款请求信息
	 * @param tradeOutNo
	 * @return
	 */
	public List<PayoutInfo>queryPayoutInfoByTradeOutNo(@Param("tradeOutNo")String tradeOutNo);
	
	 /**
	  * 将重复的付款请求更新为失败
	 * @param payoutInfo
	 */
	public void updatesDuplicatePayoutStatus(@Param("payoutInfo") PayoutInfo payoutInfo);
	
	/**
	 * 根据付款请求流水号 查询付款信息
	 * sfhq270 2015-01-21
	 * @param reqBankSn
	 * @return
	 */
	public PayoutInfo queryPayoutInfoByReqBankSn(@Param("reqBankSn")String reqBankSn);
	
	/**
	 * 根据付款请求流水号更新状态
	 * @param payoutInfo
	 */
	public void updatePayoutStatusByReqBankSn(@Param("payoutInfo") PayoutInfo payoutInfo);
	
	
	
	public void updatePayoutForFreeze(@Param("payoutNos") List<String> payoutNos);
	
	/**
	 * 根据流水号更新已受理的记录
	 */
	public void updateReceivedByReqBankSn(@Param("payoutInfo") PayoutInfo payoutInfo);

	 
	   /**
     * 方法说明：<br>
     * 根据路由规则金额上下限过滤付款信息条数
     *
     * @param payoutNoList
     * @param ruleCode
     * @return
     */
    public Long filterByAmtRange(@Param("payoutNoList")List<String> payoutNoList, @Param("ruleCode")String ruleCode);
    
    
   
	
	
	/**
	 * 方法说明：<br>
	 * 自动出款修改状态
	 *
	 * @param batchCode
	 * @param status
	 */
	public int updateStatusByBatchCodeAuto(@Param("batchCode")String batchCode
			,@Param("status")PayoutStatus status);

	/**
	 * 方法说明：<br>
	 * 按付款编号查询
	 *
	 * @param payoutNo
	 * @return
	 */
	public PayoutInfo findBankRtn(@Param("payoutNo")String payoutNo);

	/**
	 * 方法说明：<br>
	 * 通过ID更新银行返回信息
	 */
	public void updateBankRtnMsgById(@Param("rtnBankMsg") String rtnBankMsg, @Param("id") Long id);
	
}
