/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IApproveListDao;
import com.sfpay.acquirer.dao.IMerInfoDao;
import com.sfpay.acquirer.dao.IOftenColInfoDao;
import com.sfpay.acquirer.dao.IParamInfoDao;
import com.sfpay.acquirer.dao.IPayBusinessDao;
import com.sfpay.acquirer.dao.IPayoutWhiteListDao;
import com.sfpay.acquirer.domain.OftenColInfo;
import com.sfpay.acquirer.domain.PayoutEditor;
import com.sfpay.acquirer.domain.paycenter.ApproveListInfo;
import com.sfpay.acquirer.domain.paycenter.ApproveListParam;
import com.sfpay.acquirer.domain.paycenter.MerInfo;
import com.sfpay.acquirer.domain.paycenter.MerInfoParam;
import com.sfpay.acquirer.domain.paycenter.PaymentTranInfoParam;
import com.sfpay.acquirer.domain.paycenter.PayoutReqInfo;
import com.sfpay.acquirer.domain.paycenter.PayoutReqInfoParam;
import com.sfpay.acquirer.domain.paycenter.PayoutReqInfoView;
import com.sfpay.acquirer.domain.paycenter.WhiteListInfo;
import com.sfpay.acquirer.domain.paycenter.WhiteListParam;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.PayCenterPayStatus;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.enums.PayoutType;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.acquirer.service.IPayoutCenterService;
import com.sfpay.acquirer.service.IPayoutService;
import com.sfpay.acquirer.service.SendPayoutResp;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.organ.domain.OrgAccount;
import com.sfpay.organ.service.IOrgAccountService;

/**
 * 类说明：<br>
 * 付款中心业务实现类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 400928 向鹏
 * 
 * CreateDate: 2014-1-15
 */
@Service("payoutCenterService")
@HessianExporter
public class PayoutCenterServiceImpl implements IPayoutCenterService{

	private static Logger logger = LoggerFactory.getLogger(PayoutCenterServiceImpl.class);
	
	//摘要最大长度
	private int summaryLimit = Integer.valueOf(Property.getProperty("B2E_SUMMARY_LIMIT"));
	
	@Resource
	private IPayoutWhiteListDao whiteListDao;
	
	@Resource
	private IPayBusinessDao payCenterInfoDao;	

	@Resource
	private IMerInfoDao merInfoDao;
	
	@Resource
	private IPayoutService payoutService;
	
	@Resource
	private SendPayoutResp notify;
	
	@Resource
	private IOrgAccountService orgAccountService;
	
	@Resource
	private IParamInfoDao paramInfoDao;
	
	@Resource
	private IOftenColInfoDao oftenColInfoDao;
	
	@Resource
	private IApproveListDao approveListDao;
	
		
	@Override
	public List<PayoutReqInfo> payCenterCreatePayout(List<PayoutReqInfo> reqList) throws ServiceException {
		       //检查参数
				if(reqList == null || reqList.size() == 0){
					throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "参数不能为空");
				}
			
				List<PayoutReqInfo> payoutEditorResp = new ArrayList<PayoutReqInfo>();
				for (Iterator<PayoutReqInfo> it = reqList.iterator(); it.hasNext(); ) {
					PayoutReqInfo editor = it.next();			
					//检查参数,检查不通过的请求，直接返回失败
					String msg = "";
					if(!StringUtils.isEmpty(editor.getTradeNo())){
						msg = "["+editor.getTradeNo()+"]";
					}
					try{
						if(!this.checkAdd(editor)){
							logger.error("付款请求:"+msg+"检查不通过:"+editor.getBankRetMsg());
							continue;
						}
					}catch(Exception ex){
						logger.error("付款请求"+msg+"不符合要求：",ex);					
						editor.setStatus(PayCenterPayStatus.FAILURE);
						payoutEditorResp.add(editor);
						editor.setBankRetMsg("其他错误");
						editor.setBankRetCode(InfoCode.ERROR_MSG);
						continue;
					}					
					//将付款指令重付性检查抽像出来公共调用
				    if(checkDupPay(editor, payoutEditorResp)){
				    	continue;
				    }
				    //检验通过直接保存付款信息
				    savePayoutInfo(editor);
				    payoutEditorResp.add(editor);				  
				}		
				return payoutEditorResp;
	}

	@Override
	public List<PayoutReqInfo> payCenterGXPCreatePayout(List<PayoutReqInfo> payoutReqList) throws ServiceException {
		// 检查参数
		if (payoutReqList == null || payoutReqList.size() == 0) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "参数不能为空");
		}

		List<PayoutReqInfo> payoutEditorResp = new ArrayList<PayoutReqInfo>();
		for (Iterator<PayoutReqInfo> it = payoutReqList.iterator(); it
				.hasNext();) {
			PayoutReqInfo editor = it.next();
			// 检查参数,检查不通过的请求，直接返回失败
			String msg = "";
			if (!StringUtils.isEmpty(editor.getTradeNo())) {
				msg = "[" + editor.getTradeNo() + "]";
			}
			try {
				//由于报销平台无需录入代理支付名称信息故在此强行设置成N躲过要素检查，后再还原
				YNFlag flag=editor.getAgentFlag();
				editor.setAgentFlag(YNFlag.N);
				if(!this.checkAdd(editor)){
					logger.error("付款请求:"+msg+"检查不通过:"+editor.getBankRetMsg());
					payoutEditorResp.add(editor);
					continue;
				}
				editor.setAgentFlag(flag);
			} catch (Exception ex) {
				logger.error("付款请求" + msg + "不符合要求：", ex);
				editor.setBankRetMsg("其他错误");
				editor.setBankRetCode(InfoCode.ERROR_MSG);
				editor.setStatus(PayCenterPayStatus.FAILURE);
				payoutEditorResp.add(editor);
				continue;
			}
			// 将付款指令重付性检查抽像出来公共调用
			if (checkDupPay(editor, payoutEditorResp)) {
				continue;
			}
            //共享中心支付判断共享中心业务论逻辑，如
			if (!gxpCheck(editor, payoutEditorResp)) {
				continue;
			}
			editor.setPayType(PayoutType.B2E);
			//检验通过直接保存付款信息
			savePayoutInfo(editor);
			//保存收款单位信息
			if(YNFlag.Y.equals(editor.getSaveColtCompFlag())){
				try {
					OftenColInfo param = this.converToOftenCol(editor);
					oftenColInfoDao.saveOrUpdateEcsOften(param);
				} catch (Exception ex) {
					logger.error("保存常用收款单位异常", ex);
				}
			}
			
			payoutEditorResp.add(editor);
			   
		}
		return payoutEditorResp;

	}
	
	@Override
	public IPage<MerInfo> findMerInfoByPage(MerInfoParam param,int pageNo, int pageSize) throws ServiceException {
		// 查询总记录数
		long count = merInfoDao.countMerInfo(param);
		List<MerInfo> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			list = merInfoDao.queryMerInfoByPage(param, start, end);
		}
		return new Page<MerInfo>(list, count, pageNo, pageSize);	
	}
	
	@Override
	public MerInfo queryMerInfoByNo(String merNo)throws ServiceException{
		if(StringUtils.isEmpty(merNo)){
			throw new ServiceException(InfoCode.ERROR_MSG,"传入参数商户号不能为空!");
		}		
		MerInfoParam param=new MerInfoParam();
		param.setMerNo(merNo);
		return merInfoDao.queryMerInfo(param);
	}
	
	@Override
	public void saveMerInfo(MerInfo merInfo) throws ServiceException {
		if(StringUtils.isEmpty(merInfo.getMerNo())){
			throw new ServiceException(InfoCode.PARAM_INVALID,"传入的参数商户号码不能为空!");			
	    }
		if(merInfo.getSysName()==null){
			throw new ServiceException(InfoCode.PARAM_INVALID,"传入的参数系统名称不能为空!");			
	    }
		if(StringUtils.isEmpty(merInfo.getMerKey())){
			throw new ServiceException(InfoCode.PARAM_INVALID,"传入的参数商户密钥不能为空!");			
	    }
		if(StringUtils.isEmpty(merInfo.getCreateId())){
			throw new ServiceException(InfoCode.PARAM_INVALID,"传入的信息创建人ID不能为空!");
		}
		MerInfoParam param=new MerInfoParam();
		if(merInfo.getId()==0L){			
			param.setMerNo(merInfo.getMerNo());
			Long cnt=merInfoDao.countMerInfo(param);
			if(cnt>0L){
				throw new ServiceException(InfoCode.ERROR_MSG,"商户号："+param.getMerNo()+"在系统中已存在！");
			}
			merInfoDao.addMerInfo(merInfo);			
		}else{
			param.setId(merInfo.getId());
			param.setMerNo(merInfo.getMerNo());
			param.setSysName(merInfo.getSysName());			
			param.setMerKey(merInfo.getMerKey());
			param.setApproveFlag(merInfo.getApproveFlag());
			Long cnt=merInfoDao.countMerInfo(param);
			if(cnt>0L){
				throw new ServiceException(InfoCode.ERROR_MSG,"商户号："+param.getMerNo()+"的信息未进行过任何修改！");
			}			
			
			MerInfo info=merInfoDao.queryMerInfoById(param.getId());
			if(info==null){
				throw new ServiceException(InfoCode.ERROR_MSG,"系统找不到ID号为："+param.getId()+"的商户信息无法进行修改!");
			}
			if(info.getMerNo().equals(merInfo.getMerNo())){ //表示商户号没有修改
				//更新记录信息
				merInfoDao.updateMerInfo(merInfo);
			}else{//表示商户号已被修改还需要继续拿新证件号进行统计若重复则报错
				param.setId(0L);
				param.setSysName(null);
				param.setMerKey(null);
				param.setApproveFlag(null);
				cnt=merInfoDao.countMerInfo(param);
				if(cnt>0L){
					throw new ServiceException(InfoCode.ERROR_MSG,"修改商户信息后商户号："+merInfo.getMerNo()+"与其它商户号重复，无法修改！");
				}
				//更新记录信息
				merInfoDao.updateMerInfo(merInfo);
			}			
		}		
	}

	@Override
	public void saveWhiteList(WhiteListInfo wl) throws ServiceException {
		if(StringUtils.isEmpty(wl.getCertNo())){
			throw new ServiceException(InfoCode.PARAM_INVALID,"传入的参数证件号码不能为空!");			
	    }
		if(StringUtils.isEmpty(wl.getUserName())){
			throw new ServiceException(InfoCode.PARAM_INVALID,"传入的参数姓名不能为空!");			
	    }
		if(StringUtils.isEmpty(wl.getAccountNo())){
			throw new ServiceException(InfoCode.PARAM_INVALID,"传入的参数账号不能为空!");			
	    }
		if(StringUtils.isEmpty(wl.getCreateId())){
			throw new ServiceException(InfoCode.PARAM_INVALID,"传入的信息创建人ID不能为空!");
		}
		if(StringUtils.isEmpty(wl.getUserId())){
			throw new ServiceException(InfoCode.PARAM_INVALID,"传入的白名单信息工号不能为空!");
		}
		WhiteListParam param=new WhiteListParam();
		if(wl.getId()==0L){		
			param.setUserId(wl.getUserId());
			Long cnt=whiteListDao.countWhiteListByReel(param);
			if(cnt>0L){
				throw new ServiceException(InfoCode.ERROR_MSG,"白名单对应的工号在系统中已存在！");
			}
			param.setUserId(null);
			param.setCertNo(wl.getCertNo());			
			cnt=whiteListDao.countWhiteListByReel(param);
			if(cnt>0L){
				throw new ServiceException(InfoCode.ERROR_MSG,"白名单对应的身份证号在系统中已存在！");
			}
			whiteListDao.addWhiteList(wl);			
		}else{
			param.setId(wl.getId());
			param.setAccountNo(wl.getAccountNo());
			param.setUserName(wl.getUserName());
			param.setCertNo(wl.getCertNo());
			param.setUserId(wl.getUserId());
			Long cnt=whiteListDao.countWhiteListByReel(param);
			if(cnt>0L){
				throw new ServiceException(InfoCode.ERROR_MSG,"白名单记录："+param.getCertNo()+"的信息未进行过任何修改！");
			}			
			
			WhiteListInfo info=whiteListDao.queryWhiteListInfoById(param.getId());
			if(info==null){
				throw new ServiceException(InfoCode.ERROR_MSG,"系统找不到ID号为："+param.getId()+"的白名单信息无法进行修改!");
			}
			if(info.getCertNo().equals(wl.getCertNo())){ //表示证件号没有修改
				//更新记录信息
				whiteListDao.updateWhiteListInfo(wl);
			}else{//表示证件号已被修改还需要继续拿新证件号进行统计若重复则报错
				param.setId(0L);
				param.setUserName(null);
				param.setAccountNo(null);
				param.setUserId(null);
				cnt=whiteListDao.countWhiteListByReel(param);
				if(cnt>0L){
					throw new ServiceException(InfoCode.ERROR_MSG,"修改后白名单信息证件号："+wl.getCertNo()+"与其它白名单证件号重复，无法修改！");
				}
				//更新记录信息
				whiteListDao.updateWhiteListInfo(wl);
			}			
		}		
	}

	@Override
	public void delWhiteList(Long id) throws ServiceException {
		whiteListDao.delWhiteList(id);
	}
	
	@Override
	public void delMerInfo(Long id) throws ServiceException {
		merInfoDao.delMerInfo(id);
	}

	@Override
	public IPage<WhiteListInfo> findWhiteListByPage(WhiteListParam param,int pageNo, int pageSize) throws ServiceException {
		// 查询总记录数
		long count = whiteListDao.countWhiteList(param);
		List<WhiteListInfo> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			list = whiteListDao.queryWhiteListByPage(param, start, end);
		}
		return new Page<WhiteListInfo>(list, count, pageNo, pageSize);	
	}
	
	@Override
	public IPage<PayoutReqInfoView> queryPayoutReqInfoByPage(PayoutReqInfoParam param,int pageNo, int pageSize) throws ServiceException {
		// 查询总记录数
		long count = payCenterInfoDao.countPayoutReqInfo(param);
		List<PayoutReqInfoView> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			list = payCenterInfoDao.queryPayoutReqInfoByPage(param, start, end);
		}
		Long serachDayCnt=10L;
		try{
			serachDayCnt=Long.parseLong(paramInfoDao.getParameter("DUP_PAY_CHECK_SERACH_DAY"));
		}catch(Exception e){
			logger.error("获取校验重复天数出错！",e);
			serachDayCnt=10L;
		}	
		
		if(null!=list){
			for(PayoutReqInfoView info:list){
				info.setMerNo(""+info.getAmt());
				Long cnt=payCenterInfoDao.countDuplicate(info.getAcctNo(),info.getAcctName(),info.getAmt(), serachDayCnt);
				if(cnt>1){
					info.setDuplicateFlag(YNFlag.Y);
				}else{
					info.setDuplicateFlag(YNFlag.N);
				}
			}
		}
		return new Page<PayoutReqInfoView>(list, count, pageNo, pageSize);	
	}
	

	private void savePayoutInfo(PayoutReqInfo editor)throws ServiceException{
	    //判断相应的商户是否需要审批
		//插入付款中心付款信息表
		//判断是否是B2E的付款方式
	    //若审批则无需先期插入PayoutInfo表，若无需审批则直则向payoutInfo表插入支付记录
		MerInfoParam param=new MerInfoParam();
		param.setMerNo(editor.getMerNo());
		MerInfo merInfo=merInfoDao.queryMerInfo(param);
		if(merInfo==null){
			throw new ServiceException(InfoCode.ERROR_MSG,"付款中心在保存付款单号："+editor.getTradeNo()+"的付款信息时找不到相对应的商户信息！");			
		}
		if(YNFlag.N.equals(merInfo.getApproveFlag())){
		   editor.setStatus(PayCenterPayStatus.WAITING);
		}else{
			editor.setStatus(PayCenterPayStatus.INPUTED);	
		}
		//向付款中心数据表追加记录
		payCenterInfoDao.addPayCenterPayInfo(editor);
		//若无需审批则直接默认走银企下联，若需要审批则由审批页面选择支付方式
		if(YNFlag.N.equals(merInfo.getApproveFlag())){
			editor.setPayType(PayoutType.B2E);
			switch (editor.getPayType()) {
			case B2E:
				sendToB2E(editor);
				break;
			case CASH:
			case NETBANK:
			case CHECK:	
				return;
			}			
		}
		
		editor.setBankRetMsg("付款记录录入成功！");		
	}
	
	private void sendToB2E(PayoutReqInfo editor){
		PayoutEditor tem=convert2PayoutEditor(editor);
		List<PayoutEditor> req=new ArrayList<PayoutEditor>();
		req.add(tem);
		List<PayoutEditor>res=null;
		try{
		   res=payoutService.createPayout(req);
		}catch(ServiceException e){			
			editor.setBankRetMsg(e.getMsg());
			editor.setStatus(PayCenterPayStatus.FAILURE);
			return;
		}catch(Exception e){
			logger.error("调用银企直连录入接口出错(merNo:"+editor.getMerNo()+"tradeNo:"+editor.getTradeNo()+")!",e);
			editor.setBankRetMsg("调用银企直连录入接口出错(merNo:"+editor.getMerNo()+"tradeNo:"+editor.getTradeNo()+")!");
			editor.setStatus(PayCenterPayStatus.WAITING);
			return;
		}
		if(res.size()>0){
		   tem=res.get(0);		   
		   editor.setStatus(PayCenterPayStatus.valueOf(tem.getStatus().name()));
		}else{
		   editor.setBankRetMsg("付款已发送至银企直联！");
		   editor.setStatus(PayCenterPayStatus.WAITING);
		}		
	}
	
	private PayoutEditor convert2PayoutEditor(PayoutReqInfo item) {
		PayoutEditor pe = new PayoutEditor();
		pe.setTradeOutNo(item.getMerNo()+"N"+item.getTradeNo());
		pe.setTradeOutBussinessNo(item.getPayBusinessNo());
		pe.setPayeeOrgCode(item.getBankNo());
		pe.setPayeeBranchCode(item.getBranchNo());
		pe.setPayeeBranchName(item.getBranchName());		
		pe.setPayeeAcctNo(item.getAcctNo());
		pe.setPayeeAcctName(item.getAcctName());
		pe.setPayeeAcctType(item.getAcctType());
		pe.setPayeeAcctProvinceName(item.getProvinceName());
		pe.setPayeeAcctCityName(item.getCityName());
		pe.setPayeeMobile(item.getMobile());
		pe.setMsgFlag(item.getMsgFlag());		
		pe.setAmt(item.getAmt());
		pe.setRemitMethod(item.getRemitType());
		pe.setUseDesc(item.getUseDesc());
		pe.setSummary(item.getSummary());
		pe.setExpectPayDate(DateUtil.getDateFormatStr(item.getExpectPayDate(),"yyyyMMdd"));
		pe.setSaveColtCompFlag(YNFlag.N);
		pe.setSystemSource(item.getSystemSource());
		pe.setAgentFlag(item.getAgentFlag());
		pe.setAgentName(item.getAgentName());
		pe.setAgentAcctNo(item.getAgentAcctNo());
		return pe;
	}
	
	
	// 付款重复提交检验
	private boolean checkDupPay(PayoutReqInfo editor,List<PayoutReqInfo> payoutEditorResp) {
		// 防重检查
		PayoutReqInfo pi = null;
		if (!StringUtils.isEmpty(editor.getTradeNo())) {
			logger.info(String.format("检查[%s]交易[%s]是否重复...",
					editor.getSystemSource(), editor.getTradeNo()));
			pi = payCenterInfoDao.queryPayoutReqInfoByTradeNo(editor.getMerNo(), editor.getTradeNo());

			if (pi != null) {				
				switch (pi.getStatus()) {
				case FIR_APPROVE_REFUSE:// ("第一次复核拒绝"),
				case SEC_APPROVE_REFUSE:// ("第二次复核拒绝"),
				case FAILURE:// ("交易失败"),	
					return false;
				case SUCCESS:// ("交易成功"),					
				case INPUTED:// ("录入")
				case FIR_APPROVE_PASS:// ("第一次复核通过"),			
				case WAITING://等待结果
				default:					
					pi.setStatus(PayCenterPayStatus.WAITING);
					payoutEditorResp.add(pi);				
				}
				pi.setBankRetMsg("商户号："+editor.getMerNo()+"的付款流水号："+editor.getTradeNo()+"在系统中已存在！");
				return true;
			}
			return false;
		}
		return false;
	}

	/**
	 * 方法说明：<br>
	 * 录入参数检查
	 *
	 * @param editor
	 */
	private boolean checkAdd(PayoutReqInfo editor){
		String retCode=null;
		String retMsg="";
		PayCenterPayStatus status=null;
		if(null==editor) {			
			retCode=InfoCode.INPUT_PARAM_IS_NULL;
			retMsg="入参不能为空";
			status=PayCenterPayStatus.FAILURE;
		}else{
			if(StringUtils.isEmpty(editor.getAcctNo())) {			
				retCode=InfoCode.INPUT_PARAM_IS_NULL;
				retMsg="收款账号不能为空";
				status=PayCenterPayStatus.FAILURE;
			}
			if(StringUtils.isEmpty(editor.getTradeNo())){			
				retCode=InfoCode.INPUT_PARAM_IS_NULL;
				retMsg="外部付款单号tradeNo不能为空!";
				status=PayCenterPayStatus.FAILURE;
			}
			if(editor.getAmt() <= 0) {			
				retCode=InfoCode.INPUT_PARAM_IS_NULL;
				retMsg="收款账号["+editor.getAcctNo()+"]对应的金额必填且必须大于0";
				status=PayCenterPayStatus.FAILURE;
			}
			if(editor.getBankNo() == null) {			
				retCode=InfoCode.INPUT_PARAM_IS_NULL;
				retMsg="收款账号["+editor.getAcctNo()+"]对应的收款方银行(bankNo)不能为空";
				status=PayCenterPayStatus.FAILURE;
			}
			if(StringUtils.isEmpty(editor.getBranchName())) {			
				retCode=InfoCode.INPUT_PARAM_IS_NULL;
				retMsg="收款账号["+editor.getAcctNo()+"]对应的收款方开户行名称(branchName)不能为空";
				status=PayCenterPayStatus.FAILURE;
			}
			if(StringUtils.isEmpty(editor.getAcctName())) {			
				retCode=InfoCode.INPUT_PARAM_IS_NULL;
				retMsg="收款账号["+editor.getAcctNo()+"]对应的收款方账户名称(acctName)不能为空";
				status=PayCenterPayStatus.FAILURE;
			}
			if(editor.getAcctType() == null) {			
				retCode=InfoCode.INPUT_PARAM_IS_NULL;
				retMsg="收款账号["+editor.getAcctNo()+"]对应的收款方账户类型(acctType)不能为空";
				status=PayCenterPayStatus.FAILURE;
			}
			if(StringUtils.isEmpty(editor.getProvinceName())) {			
				retCode=InfoCode.INPUT_PARAM_IS_NULL;
				retMsg="收款账号["+editor.getAcctNo()+"]对应的收款方省份名称(provinceName)不能为空";
				status=PayCenterPayStatus.FAILURE;
			}
			if(StringUtils.isEmpty(editor.getCityName())) {			
				retCode=InfoCode.INPUT_PARAM_IS_NULL;
				retMsg="收款账号["+editor.getAcctNo()+"]对应的收款方城市名称(cityName)不能为空";
				status=PayCenterPayStatus.FAILURE;
			}
			if(StringUtils.isEmpty(editor.getUseDesc())) {
				retCode=InfoCode.INPUT_PARAM_IS_NULL;
				retMsg="收款账号["+editor.getAcctNo()+"]对应的用途(UseDesc)不能为空";
				status=PayCenterPayStatus.FAILURE;
			}
			
			if(null==editor.getAgentFlag()){
				editor.setAgentFlag(YNFlag.N);
			}		
			if (YNFlag.Y.equals(editor.getAgentFlag()) && StringUtils.isEmpty(editor.getAgentName())) {
				retCode = InfoCode.INPUT_PARAM_IS_NULL;
				retMsg = "代理付款信息代理付款人信息不能为空！";
				status = PayCenterPayStatus.FAILURE;
			}
					
			if(editor.getMsgFlag() == null) {
				editor.setMsgFlag(YNFlag.N);//MsgFlag为空时，标识为否（不需要发送）
			}
			if(YNFlag.Y.equals(editor.getMsgFlag())) {
				if(StringUtils.isEmpty(editor.getMobile())) {				
					retCode=InfoCode.INPUT_PARAM_IS_NULL;
					retMsg="手机号(PayeeMobile)不能为空";
					status=PayCenterPayStatus.FAILURE;
				}
				editor.setMobile(editor.getMobile().trim());
			}
			if(editor.getRemitType() == null) {			
				retCode=InfoCode.INPUT_PARAM_IS_NULL;
				retMsg="付款方式(RemitMethod)不能为空";
				status=PayCenterPayStatus.FAILURE;
			}
		
			if(StringUtils.isEmpty(editor.getTradeNo())) {			
				retCode=InfoCode.INPUT_PARAM_IS_NULL;
				retMsg="外部交易单号 (TradeNo)不能为空";
				status=PayCenterPayStatus.FAILURE;
			}		
			if(editor.getCcy()==null){
				editor.setCcy(CurrencyType.RMB);
			}
			editor.setSummary(StringUtils.substr(editor.getSummary(), summaryLimit));//截取过长的摘要
			editor.setAcctNo(editor.getAcctNo().trim());
			editor.setAcctName(editor.getAcctName().trim());
			editor.setProvinceName(editor.getProvinceName()== null?null:editor.getProvinceName().trim());
			editor.setCityName(editor.getCityName() == null?null:editor.getCityName().trim());
			editor.setUseDesc(editor.getUseDesc().trim());
			editor.setBranchNo(editor.getBranchNo() == null?null:editor.getBranchNo().trim());
			editor.setBranchName(editor.getBranchName().trim());
		}
		if(PayCenterPayStatus.FAILURE.equals(status)){
			editor.setBankRetCode(retCode);
			editor.setBankRetMsg(retMsg);
			editor.setStatus(status);
			return false;
		}
		return true;
	}
	
	
	
	private boolean gxpCheck(PayoutReqInfo editor,List<PayoutReqInfo> payoutEditorResp){
		
		//付款中心过来指令信息需要进行白名单及账套检验  同时产生虚批次以供总部财务进行审批
	
		String certNo=editor.getCertNo();				
		String accountBookNo=editor.getAcctSetNo();
		YNFlag flag=editor.getAgentFlag();
		
		if(flag==null){
			logger.error("付款请求外部流水号："+editor.getTradeNo()+"的代理支付标志为空！");
			editor.setBankRetMsg("付款请求外部流水号："+editor.getTradeNo()+"的代理支付标志为空！");
			editor.setStatus(PayCenterPayStatus.FAILURE);					
			payoutEditorResp.add(editor);
			return false;				
		}
		//账套编码为空表示无需代理支付 否则需要向COD查询账套相应的信息生成代理支付相应的信息
		if(StringUtils.isEmpty(accountBookNo)){
			logger.error("付款请求外部流水号："+editor.getTradeNo()+"的账套信息编码为空！");
			editor.setBankRetMsg("付款请求外部流水号："+editor.getTradeNo()+"的账套信息编码为空！");
			editor.setStatus(PayCenterPayStatus.FAILURE);					
			payoutEditorResp.add(editor);
			return false;				
		}				
		//向COD查询账套信息 并生成代理支付相关信息若COD无相应的账套信息则直接失败表示账套检验不通过
		//TODO:此处改成从HR系统取账套信息
			
		OrgAccount orgAcc=orgAccountService.queryOrgAccount(accountBookNo);
		if(null==orgAcc){
			logger.error("系统找不到付款请求外部流水号："+editor.getTradeNo()+"的账套信息:"+accountBookNo);
			editor.setBankRetMsg("系统找不到付款请求外部流水号："+editor.getTradeNo()+"的账套信息:"+accountBookNo);
			editor.setStatus(PayCenterPayStatus.FAILURE);					
			payoutEditorResp.add(editor);
			return false;			
		}		
		editor.setAgentName(orgAcc.getOrgAccountInfo().getAccountName());
		if(orgAcc.getOrgAccountBankList().size()!=1){
			logger.error("付款请求外部流水号："+editor.getTradeNo()+"的账套信息:"+accountBookNo+"无法确定唯一的代理账号信息！");
			editor.setBankRetMsg("付款请求外部流水号："+editor.getTradeNo()+"的账套信息:"+accountBookNo+"无法确定唯一的代理账号信息！");
			editor.setStatus(PayCenterPayStatus.FAILURE);					
			payoutEditorResp.add(editor);
			return false;			
		}
		String agenAcc=orgAcc.getOrgAccountBankList().get(0).getAccount();
		if(StringUtils.isEmpty(agenAcc)){
			logger.error("付款请求外部流水号："+editor.getTradeNo()+"的账套信息:"+accountBookNo+"代理账号信息为空！");
			editor.setBankRetMsg("付款请求外部流水号："+editor.getTradeNo()+"的账套信息:"+accountBookNo+"代理账号信息为空！");
			editor.setStatus(PayCenterPayStatus.FAILURE);					
			payoutEditorResp.add(editor);
			return false;			
		}
		editor.setAgentAcctNo(agenAcc);
		//外部供应商白名单先其不检验
		if(!StringUtils.isEmpty(certNo)){
//			logger.error("付款请求外部流水号："+payoutInfo.getTradeOutNo()+"的白名单证件号为空！");
//			editor.setRemark("付款请求外部流水号："+payoutInfo.getTradeOutNo()+"的白名单证件号为空！");
//			editor.setStatus(PaymentStatusExt.FAILURE);					
//			payoutEditorResp.add(editor);
//			continue;
			
			WhiteListParam param=new WhiteListParam();
			param.setCertNo(certNo);
			WhiteListInfo info=whiteListDao.queryWhiteListByReel(param);
			if(info==null){                                        //白名单检查不通过
				logger.error("付款请求外部流水号："+editor.getTradeNo()+"的白名单不存在！");
				editor.setBankRetMsg("付款请求外部流水号："+editor.getTradeNo()+"的白名单不存在！");
				editor.setStatus(PayCenterPayStatus.FAILURE);					
				payoutEditorResp.add(editor);
				return false;
			}
			if(!info.getAccountNo().equals(editor.getAcctNo())){
				logger.error("付款请求外部流水号："+editor.getTradeNo()+"的收款账号在白名单检验不通过！");
				editor.setBankRetMsg("付款请求外部流水号："+editor.getTradeNo()+"的收款账号白名单检验不通过！");
				editor.setStatus(PayCenterPayStatus.FAILURE);					
				payoutEditorResp.add(editor);
				return false;
			}
			if(!info.getUserName().equals(editor.getAcctName())){
				logger.error("付款请求外部流水号："+editor.getTradeNo()+"的收款户名白名单检验不通过！");
				editor.setBankRetMsg("付款请求外部流水号："+editor.getTradeNo()+"的收款户名白名单检验不通过！");
				editor.setStatus(PayCenterPayStatus.FAILURE);					
				payoutEditorResp.add(editor);
				return false;
			}
	
		}
		return true;
		
  }

	@Override
    public PayoutReqInfo queryPayoutReqInfoByID(Long id)throws ServiceException {
		if(id==null){
			throw new ServiceException(InfoCode.ERROR_MSG,"传入参数ID号不能为空！");
		}
		return payCenterInfoDao.queryPayoutReqInfoById(id);
	}

	@Override
	public void checkPayOutInfo(String ids, String checkDesc,PayCenterPayStatus status,String checkOperator) throws ServiceException {
		if(StringUtils.isEmpty(ids)){
			throw new ServiceException(InfoCode.PARAM_INVALID,"传入的待审批记录ID号不能为空!");
		}
		if(StringUtils.isEmpty(checkDesc)){
			//throw new ServiceException(InfoCode.PARAM_INVALID,"传入的审批描述信息不能为空!");
			checkDesc="";
		}
		if(null==status){
			throw new ServiceException(InfoCode.PARAM_INVALID,"传入的审批状态信息不能为空!");
		}
		StringTokenizer strs=new StringTokenizer(ids,"&");
		if(strs.countTokens()==0){
			throw new ServiceException(InfoCode.PARAM_INVALID,"传入的审批ID信息不能为空!");
		}
		if(status!=PayCenterPayStatus.FIR_APPROVE_PASS&&status!=PayCenterPayStatus.FIR_APPROVE_REFUSE&&status!=PayCenterPayStatus.WAITING&&status!=PayCenterPayStatus.SEC_APPROVE_REFUSE){
		   throw new ServiceException(InfoCode.PARAM_INVALID,"传入的审批状态:"+status.name()+"不正确！");	
		}
		List<PayoutReqInfo> notifyList=new ArrayList<PayoutReqInfo>();
		List<PayoutEditor> sendPayInfoB2E=new ArrayList<PayoutEditor>();
		while(strs.hasMoreTokens()){
			String str=strs.nextToken();
			try{
			  Long id=Long.valueOf(str);
			  PayoutReqInfo info=payCenterInfoDao.queryPayoutReqInfoById(id);
			  if(null==info){
				  throw new ServiceException(InfoCode.ERROR_MSG,"找不到ID号为:"+str+"的付款记录无法进行审批!");
			  }
			  Long checkDup=payCenterInfoDao.countCheckOperator(checkOperator,id);
			  if(checkDup>0){
				  throw new ServiceException(InfoCode.ERROR_MSG,"ID号："+id+"的创建人，第一次审批人或第二次审批人不能为同一个人!");
			  }			  
			  switch(status){
			     //状态为第一次审批操作需要原始状态为INPUTED状态
			     case FIR_APPROVE_PASS:
			     case FIR_APPROVE_REFUSE:
			    	 if(!PayCenterPayStatus.INPUTED.equals(info.getStatus())){
			    		throw new ServiceException(InfoCode.ERROR_MSG,"付款ID号："+id+"的状态为非录入状态无法进行第一次审批动作!"); 
			    	 }
			    	 payCenterInfoDao.approvePayInfoByFir(checkOperator, checkDesc, id,status);
			    	 break;
			    //状态为第二次审批操作需要原始状态为FIR_APPROVE_PASS
			     case WAITING:
			     case SEC_APPROVE_REFUSE:
                     if(!PayCenterPayStatus.FIR_APPROVE_PASS.equals(info.getStatus())){
                    	 throw new ServiceException(InfoCode.ERROR_MSG,"付款ID号："+id+"的状态为非第一次审批通过状态无法进行第二次审批动作!");
			    	 }
                     payCenterInfoDao.approvePayInfoBySec(checkOperator, checkDesc, id,status);
			    	 break;
			     default:
			    	 throw new ServiceException(InfoCode.ERROR_MSG,"传入的审批状态:"+status.name()+"无效!");
			  }
			   //审批处理完后需再次从数据库取支付信息以防状态更新不到位
			   info=payCenterInfoDao.queryPayoutReqInfoById(id);
			   
			  //若审批拒绝则需要通知业务系统
			  if(PayCenterPayStatus.FIR_APPROVE_REFUSE.equals(info.getStatus())){				  
				 payCenterInfoDao.updateCheckPayStatus(info.getId(),info.getStatus(),checkDesc,new Date(),PayCenterPayStatus.INPUTED);
				 notifyList.add(info);
			  }else if(PayCenterPayStatus.SEC_APPROVE_REFUSE.equals(info.getStatus())){				  
					 payCenterInfoDao.updateCheckPayStatus(info.getId(),info.getStatus(),checkDesc,new Date(),PayCenterPayStatus.FIR_APPROVE_PASS);
					 notifyList.add(info);
			  }
			  
				if (PayCenterPayStatus.WAITING.equals(info.getStatus()) && PayoutType.B2E.equals(info.getPayType())) {
					// 判断付款方式若为银企则需要转换
					PayoutEditor editor = convert2PayoutEditor(info);
					sendPayInfoB2E.add(editor);
				}
			}catch(NumberFormatException ne){
			  throw new ServiceException(InfoCode.ERROR_MSG,"传入的ID号："+str+"有误!", ne);	
			}catch(Exception e){
				logger.info("执行审批出错:",e);
			  	throw new ServiceException(InfoCode.ERROR_MSG,"执行审批出错:"+e);
			}
		}		
		//向银企发送付款业务记录
		try{
		   if(sendPayInfoB2E.size()>0){
			   payoutService.createPayout(sendPayInfoB2E);
		   }
		}catch(Exception e){
			logger.info("向银企创建付款记录失败!",e);
			throw new ServiceException("调用银企直联系统录入付款记录失败！",e);
		}
		
		try{
			//回调业务系统
			if(notifyList.size()>0){
				notify.doPayCenterResp(notifyList,PayoutStatus.FAILURE,checkDesc);
			}
		}catch(Exception e){
			logger.info("回调业务系统异常！",e);
		}
	}

	@Override
	public PayoutReqInfo queryPayoutReqInfo(String merNo,String tradeOutNo)throws ServiceException {
		if(StringUtils.isEmpty(tradeOutNo)){
			throw new ServiceException(InfoCode.ERROR_MSG,"传入的查询单号不能为空！");
		}
		if(StringUtils.isEmpty(merNo)){
			throw new ServiceException(InfoCode.ERROR_MSG,"传入的查询商户号不能为空！");
		}
		
		return payCenterInfoDao.queryPayoutReqInfoByTradeNo(merNo, tradeOutNo);
	}
	
	
	/**
	 * 方法说明：<br>
	 * 转换成常用收款单位实体
	 *
	 * @param editor
	 * @return
	 */
	private OftenColInfo converToOftenCol(PayoutReqInfo editor) throws ServiceException{
		OftenColInfo oftenColInfo = new OftenColInfo();
		oftenColInfo.setAccountName(editor.getAcctName()); //银行账户名 -- 收款方账户名称
		oftenColInfo.setAccountNo(editor.getAcctNo()); //银行账户号 -- 收款方账号
		oftenColInfo.setAcctType(editor.getAcctType()); //账户类型 --  收款方账户类型
		oftenColInfo.setBankCode(editor.getBankNo()); //银行编号  --  收款方银行编码
		oftenColInfo.setCcy(CurrencyType.RMB);//默认为RMB
//		oftenColInfo.setColCompName(colCompName);
//		oftenColInfo.setCompManager(compManager);
//		oftenColInfo.setCreateDate(createDate);
		oftenColInfo.setManagerMobile(editor.getMobile()); //收款单位负责人手机号 -- 收款方手机号
		oftenColInfo.setObNo(editor.getBranchNo()); //开户行行号
		oftenColInfo.setRemark(editor.getSummary()); //备注 --摘要
		oftenColInfo.setAffiliateName(editor.getBranchName()); //开户行名字
		oftenColInfo.setCountryNameC(editor.getProvinceName());  //省份名字
		oftenColInfo.setCityName(editor.getCityName()); //城市名字
		return oftenColInfo;
	}
	
	@Override
	public IPage<ApproveListInfo> findApproveListByPage(ApproveListParam param, int pageNo, int pageSize) throws ServiceException {
		logger.info(String.format("进入查询审批权限(findApproveListByPage),[%s],[%s],[%s]", param.getUsername(), param.getRealName(), param.getAcctSetNo()));
		// 查询总记录数
		long count = approveListDao.queryApproveListPageCount(param);
		List<ApproveListInfo> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			list = approveListDao.queryApproveListByPage(param, start, end);
		}
		logger.info("结束查询审批权限(findApproveListByPage)");
		return new Page<ApproveListInfo>(list, count, pageNo, pageSize);	
	}
	
	@Override
	public void delApproveList(Long id) throws ServiceException {
		logger.info(String.format("进入删除审批权限(delApproveList),[%s]", String.valueOf(id)));
		approveListDao.updateApproveListDeleteById(id);
		logger.info("结束删除审批权限(delApproveList)");
	}
	
	public Map<String,String> saveApproveList(ApproveListInfo param) throws ServiceException{
		logger.info("进入保存和修改审批权限(saveApproveList)");
		Map<String,String> retMap = new HashMap<String,String>();
		String retcode = "";
		String str = "";
		
		if(param.getAcctSetFlag().equals("0")){
			param.setAcctSetNo("ALL");
		}
		
		OrgAccount orgAcc = orgAccountService.queryOrgAccount(param.getAcctSetNo());
		if(null == orgAcc && !param.getAcctSetNo().equals("ALL")){
			retcode = "0001";
			str = "该账套【" + param.getAcctSetNo()+ "】不存在,请确认";
			retMap.put("retcode",retcode);
			retMap.put("str",str);
			logger.info(String.format("(saveApproveList)判断账套是否存在的结果[%s],[%s]", retcode, str));
			return retMap;
		}
		
		if(param.getId() == 0L){
			//添加的情况
			//查询该账套是  ALL  或者是  该账套
			//
			List<ApproveListInfo> listAdd = approveListDao.queryApproveListByAcctSetNo(param);// 检查是否有启用状态的相同规则
			if(listAdd != null && listAdd.size() != 0){
				retcode = "0002";
				str = "该审核规则已经存在，请修改";
				retMap.put("retcode",retcode);
				retMap.put("str",str);
				logger.info(String.format("添加(saveApproveList)判断账套是否存在的结果[%s],[%s]", retcode, str));
				return retMap;
			}
			
			if(param.getAcctSetNo().equals("ALL")){
				approveListDao.updateApproveListDeleteByUsername(param);//如果账套为ALL删除该工号下所有的规则
			}
			
			List<ApproveListInfo> listAddAgain = approveListDao.queryApproveListByAcctSetNoAgain(param);//查询是否存在没有启用的相同规则
			if(listAddAgain != null && listAddAgain.size() != 0){
				approveListDao.updateApproveListById(param);//如果存在就更新原有的规则，则更新deleteflag为0
			}else{
				
				approveListDao.addApproveList(param);//添加新的规则
			}
			retcode = "0000";
			str = "操作成功!";
			logger.info(String.format("添加(saveApproveList)判断账套是否存在的结果[%s],[%s]", retcode, str));
		}else{
			long count = approveListDao.queryApproveListInfoByAll(param);
			if(0 != count){
				retcode = "0003";
				str = "工号" + param.getUsername() + "的该审批记录没有任何改变！";
				retMap.put("retcode",retcode);
				retMap.put("str",str);
				logger.info(String.format("修改(saveApproveList)判断审批记录是否修改的结果[%s],[%s]", retcode, str));
				return retMap;
			}
			
			if(param.getAcctSetNo().equals("ALL")){
				approveListDao.updateApproveListDeleteByUsername(param);//如果账套为ALL删除该工号下所有的规则
			}else{
				//如果添加的不是ALL的账套,则删除该工号下的账套是ALL的账套
				approveListDao.updateApproveListDeleteByUsernameAll(param);
			}
			List<ApproveListInfo> listUpdate = approveListDao.queryApproveListByAcctSetNoAgain(param);
			if(listUpdate != null && listUpdate.size() != 0){
				approveListDao.updateApproveListById(param);
			}else{
				approveListDao.addApproveList(param);
			}
			retcode = "0000";
			str = "操作成功!";
			logger.info(String.format("修改(saveApproveList)判断账套是否存在的结果[%s],[%s]", retcode, str));
		}
		retMap.put("retcode",retcode);
		retMap.put("str",str);
		return retMap;
	}
	
	public String batchApproveList(List<ApproveListInfo> param) throws ServiceException{
		logger.info("进入批量添加审批权限(batchApproveList)");
		Iterator<ApproveListInfo> it = param.iterator();
		ApproveListInfo approveList = null;
		List<ApproveListInfo> updateList = new ArrayList<ApproveListInfo>();
		List<ApproveListInfo> addList = new ArrayList<ApproveListInfo>();
		while (it.hasNext()) {
			approveList = it.next();
			if(approveList.getAcctSetNo().equals("ALL")){
				approveListDao.updateApproveListDeleteByUsername(approveList);//如果账套为ALL删除该工号下所有的规则
			}else{
				//如果添加的不是ALL的账套,则删除该工号下的账套是ALL的账套
				approveListDao.updateApproveListDeleteByUsernameAll(approveList);
			}
			List<ApproveListInfo> approveLists = approveListDao.queryApproveListByAcctSetNoThird(approveList);
			if(approveLists != null && approveLists.size() != 0){
				updateList.add(approveList);
				approveListDao.updateApproveListById(approveList);
			}else{
				addList.add(approveList);
				approveListDao.addApproveList(approveList);
			}
		}
		logger.info("批量添加审批权限(batchApproveList)结束");
		return "batchApproveList success";
	}
	
	@Override
	public IPage<PaymentTranInfoParam> queryPaymentTranListByPage(PaymentTranInfoParam param, int pageNo, int pageSize)throws ServiceException {
		// 查询总记录数
		logger.info("付款中心查询付款记录开始，参数：{}",param);
		long count = payCenterInfoDao.countPaymentTran(param);
		List<PaymentTranInfoParam> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			list = payCenterInfoDao.queryPaymentTranListByPage(param, start, end);
		}
		logger.info("付款中心查询付款记录结束!");
		return new Page<PaymentTranInfoParam>(list, count, pageNo, pageSize);	
	}

	@Override
	public String checkAcctSetNo(ApproveListInfo param) {
		logger.info(String.format("添加和修改[%s]时检查工号[%s]是否拥有所有账套权限(checkAcctSetNo)", param.getModifyFlag(), param.getUsername()));
		String str = "";
		long count = approveListDao.checkAcctSetNo(param);
		if(count != 0){  
			if(param.getModifyFlag().equals("0")&&!param.getAcctSetNo().equals("ALL")){
				str = "该工号【" + param.getUsername() + "】已经拥有所有账套权限，不能添加";
			}
			if(param.getModifyFlag().equals("1")&&!param.getAcctSetNo().equals("ALL")){
				str = "该工号【" + param.getUsername() + "】已经拥有所有账套权限，是否修改";
			}
		}
		logger.info(String.format("添加和修改[%s]时检查是否拥有所有账套权限的结果：[%s](checkAcctSetNo)", param.getModifyFlag(), str));
		return str; 
	}
	
	@Override
	public String validationAcctSetNo(ApproveListInfo param){
		logger.info(String.format("检查帐套[%s]是否存在(validationAcctSetNo)", param.getAcctSetNo()));
		String str = "";
		
		OrgAccount orgAcc = orgAccountService.queryOrgAccount(param.getAcctSetNo());
		if(null == orgAcc && !param.getAcctSetNo().equals("ALL")){
			str = "该账套【" + param.getAcctSetNo()+ "】不存在,请确认";
		}
		logger.info(String.format("检查帐套结果(validationAcctSetNo)[%s]", str));
		return str;
	}

	@Override
	public long countPaymentTran(PaymentTranInfoParam param) throws ServiceException {
		logger.info("进入付款流水记录数查询countPaymentTran方法，param=:{}",param);
		long count = payCenterInfoDao.countPaymentTran(param);
		logger.info("付款记录流水总数{}",count);
		return count;
	}
	
}
