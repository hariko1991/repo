package com.sfpay.acquirer.common.rb;


import java.util.Date;

import javax.annotation.Resource;

import com.sfpay.acquirer.common.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.service.IReconLogService;
import com.sfpay.framework.base.exception.ServiceException;


/**
 * 用线程来实现结算中心的
 * 对账定时任务
 * 退票定时任务
 * 以免过多的定时任务
 * @author sfhq272
 *
 */
public abstract class AbstractBankFileThread<T> extends BankFileCommon<T> {

	private static final Logger logger = LoggerFactory.getLogger(AbstractBankFileThread.class);
	private String tradeDateStr;
	private Date tradeDate;
	private Date curDate;
	
	protected String fileName;

	@Resource
	protected IReconLogService reconLogService;

	public void run() throws ServiceException{
		try{
			initThread();
			initLocalFullName(tradeDateStr);
			downloadSFTPFile(fileName, tradeDateStr);
			processor(tradeDateStr, tradeDate, curDate);
		} catch (Exception ex) {
			logger.error("结算中心[{}],对账异常!", tradeDateStr, ex);
			throw new ServiceException("结算中心对账异常","结算中心对账异常",ex);
		}
	}

	protected abstract void processor(String tradeDateStr, Date tradeDate, Date curDate) ;
	
	private void initThread(){
		curDate = new Date();
		tradeDate = DateUtil.getBeforeDate(curDate, 1);
		tradeDateStr = DateUtil.getDateString(tradeDate, DateUtil.DATA_FORMAT_PATTERN_2);
		logger.info("处理结算中心交易日[{}]数据!", tradeDateStr);
	}
	
}
