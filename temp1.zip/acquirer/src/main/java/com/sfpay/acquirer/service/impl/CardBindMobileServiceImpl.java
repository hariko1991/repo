/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.dao.ICardBindMobileDao;
import com.sfpay.acquirer.domain.CardBindMobile;
import com.sfpay.acquirer.enums.CardBindMobileStatus;
import com.sfpay.acquirer.service.ICardBindMobileService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.utils.StringUtils;

/**
 * 
 * 类说明：
 * 卡号绑定手机号 service  
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-5-22
 */
@Deprecated
@Service("cardBindMobileService")
public class CardBindMobileServiceImpl implements ICardBindMobileService {
	
	@Resource
	private ICardBindMobileDao dao;
	
	@Override
	public String getMobileByCard(String cardNo) throws ServiceException {
		//验证
		if(StringUtils.isEmpty(cardNo)){
			throw new ServiceException(InfoCode.CARDNO_IS_NULL,"cardno is null");
		}
		//查询
		return dao.getMobileByCard(cardNo);
	}

	
	@Override
	public void addCard(String cardNo,String mobile,String remark) throws ServiceException {
		//验证
		if(StringUtils.isEmpty(cardNo)){
			throw new ServiceException(InfoCode.CARDNO_IS_NULL,"cardno is null");
		}
		if(StringUtils.isEmpty(mobile)){
			throw new ServiceException(InfoCode.MOBILE_IS_NULL,"mobile is null");
		}
		//增加
		CardBindMobile card = new CardBindMobile();
		card.setCardNo(cardNo);
		card.setMobile(mobile);
		card.setRemark(remark);
		card.setStatus(CardBindMobileStatus.ENABLED);
		dao.addCard(card);
	}

	
	@Override
	public void updateDisabledStatus(String cardNo) throws ServiceException {
		//验证
		if(StringUtils.isEmpty(cardNo)){
			throw new ServiceException(InfoCode.CARDNO_IS_NULL,"cardno is null");
		}
		//修改
		dao.updateDisabledStatus(cardNo);		
	}

}
