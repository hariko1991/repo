/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.domain;

import java.util.List;

import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.acquirer.enums.CmdStatus;

/**
 * 类说明：<br>
 * 付款响应报文解析结果类
 * 
 * <p>
 * 详细描述：<br>
 * 将付款响应报文解析的结果保存到该类,再通过此类将对应的信息更新到付款信息表和批次信息表
 * 
 * </p>
 * 
 * @author 329202 <a href="mailto:fuyuxin@sf-express.com">符瑜鑫(Ricky Fu)</a>
 * 
 * CreateDate: 2012-9-17
 */
public class PayoutRespResult extends PayoutResult {
	
	private static final long serialVersionUID = -2191478248732403605L;

	//批次出款时的银行请求流水号
	private String batchReqBankSn;
	
	private BatchStatus status;
	
	private Long totalAmt;
	
	private Long totalNum;
	
	/**
	 * 请求状态
	 */
	private CmdStatus cmdStatus;
	
	private String remark;
	
	private List<PayoutInfo> payoutDetail;

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public CmdStatus getCmdStatus() {
		return cmdStatus;
	}

	public void setCmdStatus(CmdStatus cmdStatus) {
		this.cmdStatus = cmdStatus;
	}

	public String getBatchReqBankSn() {
		return batchReqBankSn;
	}

	public void setBatchReqBankSn(String batchReqBankSn) {
		this.batchReqBankSn = batchReqBankSn;
	}

	public BatchStatus getStatus() {
		return status;
	}

	public void setStatus(BatchStatus status) {
		this.status = status;
	}

	public Long getTotalAmt() {
		return totalAmt;
	}

	public void setTotalAmt(Long totalAmt) {
		this.totalAmt = totalAmt;
	}

	public Long getTotalNum() {
		return totalNum;
	}

	public void setTotalNum(Long totalNum) {
		this.totalNum = totalNum;
	}

	public List<PayoutInfo> getPayoutDetail() {
		return payoutDetail;
	}

	public void setPayoutDetail(List<PayoutInfo> payoutDetail) {
		this.payoutDetail = payoutDetail;
	}
	
}
