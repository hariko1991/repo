package com.sfpay.acquirer.service;

import com.sfpay.framework.base.exception.ServiceException;

public interface ICheckDuplicateTransfer {
	/**
	 * @throws ServiceException
	 * 检查重复提交的付款请求并处理重复付款请求
	 * 2015-01-16
	 * sfhq270
	 */
	public void checkAndProcessDuplicatePayout() throws ServiceException;
}
