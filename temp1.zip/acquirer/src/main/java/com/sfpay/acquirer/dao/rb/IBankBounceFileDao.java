package com.sfpay.acquirer.dao.rb;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.rb.BankBounceFileRlt;
import com.sfpay.acquirer.domain.rb.szfs.BankBounceFile;

public interface IBankBounceFileDao {
	
	public void addSZFSBounceList(List<BankBounceFile> szfsBounceList);
	
	public long countBankBounce(@Param("param") BankBounceFileRlt param);
	
	public List<BankBounceFileRlt> findBankBounceList(@Param("param") BankBounceFileRlt param, @Param("start") int start, @Param("end") int end);
	
	public void exceptionCmd(@Param("param")BankBounceFile param);
	
	public List<BankBounceFileRlt> exportBankBounceList(@Param("param") BankBounceFileRlt param);
	
	public int deleteBankBounceFileCurday();
	
	public int updatePayoutInfoForBounce(@Param("param")List<BankBounceFile> bankBounceFile);
}
