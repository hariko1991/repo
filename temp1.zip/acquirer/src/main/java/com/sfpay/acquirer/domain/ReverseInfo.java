/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.domain;

import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：<br>
 * 撤销/退款信息
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 <a href="mailto:fuyuxin@sf-express.com">符瑜鑫(Ricky Fu)</a>
 * 
 * CreateDate: 2013-1-28
 */
public class ReverseInfo extends BaseEntity {

	private static final long serialVersionUID = 3298241000090472464L;
	
	private String collectNo;
	
	private Long reverseAmt;
	
	private String reverseReason;
	
	private OrderType reverseType;
	
	public String getCollectNo() {
		return collectNo;
	}

	public void setCollectNo(String collectNo) {
		this.collectNo = collectNo;
	}

	public Long getReverseAmt() {
		return reverseAmt;
	}

	public void setReverseAmt(Long reverseAmt) {
		this.reverseAmt = reverseAmt;
	}

	public String getReverseReason() {
		return reverseReason;
	}

	public void setReverseReason(String reverseReason) {
		this.reverseReason = reverseReason;
	}

	public OrderType getReverseType() {
		return reverseType;
	}

	public void setReverseType(OrderType reverseType) {
		this.reverseType = reverseType;
	}

}
