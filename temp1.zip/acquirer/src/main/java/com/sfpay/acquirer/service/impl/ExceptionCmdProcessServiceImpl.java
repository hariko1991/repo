/**
 * =================================================================
 * 版权所有 2011-2013 深圳市泰海网络科技服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.dao.IBatchInfoDao;
import com.sfpay.acquirer.dao.IParamInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.BankCmdResult;
import com.sfpay.acquirer.domain.BatchCmdStatusParam;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.CmdBean;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutQueryRlt;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.acquirer.enums.ExchangeType;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.acquirer.service.IB2EPayoutService;
import com.sfpay.acquirer.service.ICheckTransStatusService;
import com.sfpay.acquirer.service.IExceptionCmdProcessService;
import com.sfpay.acquirer.service.SendPayoutResp;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.utils.StringUtils;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：<br>
 * 异常指令处理业务
 * <p>
 * 详细描述：<br>
 * 异常指令状态调整,异常指令重发，异常指令结果再次查询，异常指令批次令处获取，异常指令明细付款记录获取
 * </p>
 *  
 * @author 400928 向鹏
 * 
 * CreateDate: 2013-5-21
 */
@Service("exceptionCmdProcessService")
@HessianExporter
public class ExceptionCmdProcessServiceImpl implements IExceptionCmdProcessService {
	
	private static Logger logger = LoggerFactory.getLogger(ExceptionCmdProcessServiceImpl.class);
	@Resource
	private IPayoutInfoDao payoutInfoDao;
	
	@Resource
	private IBatchInfoDao batchInfoDao;
	
	@Resource
	private ICheckTransStatusService checkTrans;
	
	@Resource
	private SendPayoutResp sendPayoutResp;
	
	@Resource
	private IParamInfoDao paramDao;
	
	@Resource
	private IB2EPayoutService payout;
	
	/**
	 * 调整异常付款指令状态
	 */
	@Override
	public void updateExceptionCmdStatus(BatchCmdStatusParam status)throws ServiceException {
            
		 
			BatchInfo batchInfo=batchInfoDao.queryByReqBankSn(status.getReqBankSn());
			List<PayoutInfo> updateDetail=new ArrayList<PayoutInfo>();
			
			if(batchInfo==null){
				throw new ServiceException("根据传入的请求流水："+status.getReqBankSn()+"找不到相应的批次信息!");
			}
			//处理待调整子记录状态
			for(CmdBean cmd:status.getDtsCmds()){
			  try{				
				 //根据记录批次号，子指令新状态 及子指令旧状态更新数据子指令记录状态
				 int k=payoutInfoDao.updateExceptionProcess(cmd.getReqBankSn(),cmd.getStatus()
						 ,cmd.getOldPayOutStatus(),cmd.getRemark(),YNFlag.Y,"异常处理:状态调整操作");
				 if(k!=1){
					 throw new ServiceException("更新付款指令状态","更新记录条数不为1更新结果为:"+k);
				 }else{
					PayoutInfo temInfo=payoutInfoDao.queryPayoutInfo(batchInfo.getBatchCode(),cmd.getReqBankSn());
					if(temInfo!=null){
						updateDetail.add(temInfo);
					}
				 }
				 
			  }catch(Exception e){
				  logger.info("更新付款指令状态失败,请求银行流水号:"+cmd.getReqBankSn(),e);
			  }
			}			
			checkTrans.doBatchCheck(batchInfo.getBatchCode());
			if(updateDetail.size()>0){
				try{
					this.sendPayoutResp.sendOrderResp(updateDetail,ExchangeType.SEND_AFTER);
				}catch(Exception ex){
					logger.error(batchInfo.getBatchCode()+",调用业务系统异常 = ",ex);
				}
			}
			
	}
	
	/**
	 * 异常指令重发接口
	 */
	@Override
	public BankCmdResult rePayOut(BatchInfo batchInfo, BankCode bankCode)throws ServiceException {
		//创建返回结果对象
		BankCmdResult result=new BankCmdResult();	
		
		// 获取操作类型(手工、自动)
		//String operatorType = batchInfoDao.getOperatorType(batchInfo.getBatchCode());
		
		//直接调用银行出款
		BatchInfo _batchInfo=batchInfoDao.queryByBatchCode(batchInfo.getBatchCode());
		if(_batchInfo==null){
			throw new ServiceException("系统找不到批次号为："+batchInfo.getBatchCode()+"的批次信息！");
		}
		if(!StringUtils.isEmpty(batchInfo.getRemark())){
		  if(StringUtils.isEmpty(_batchInfo.getRemark())){
			  _batchInfo.setRemark(batchInfo.getRemark());  
		  }else{
		     _batchInfo.setRemark(_batchInfo.getRemark()+","+batchInfo.getRemark());
		  }
		}
		//把批次发送状态改成为发送
		
		try {
			int cnt = this.batchInfoDao.updateSendForNOSEND(_batchInfo.getBatchCode());
			if(cnt==0){
				throw new ServiceException("更新发送状态异常，批次号为："+batchInfo.getBatchCode()+"的批次信息！");
			}
		} catch (Exception e) {
			throw new ServiceException("更新发送状态异常，批次号为："+batchInfo.getBatchCode()+"的批次信息！",e);
		}
		
		//生成报文，放入MQ
		payout.doPayoutReq(_batchInfo);
			
		//设置银行返回码
		result.setBankRetCode(_batchInfo.getRtnBankCode());
		//设置银行编码
		result.setBankCode(bankCode);
		//设置银行返回信息
		result.setBankRetMsg(_batchInfo.getRtnBankMsg());
		//设置银行请求流水号
		result.setReqBankSn(_batchInfo.getReqBankSn());
		//设置批次状态
		result.setStatus(_batchInfo.getStatus());
//		if(BatchStatus.DONE.equals(batchInfo.getStatus())){
//			List<PayoutInfo> payoutInfoDetail=new ArrayList<PayoutInfo>();
//			payoutInfoDetail=this.payoutInfoDao.queryPayoutByBatchCode(batchInfo.getBatchCode());
//			if(payoutInfoDetail.size()>0){
//				try{
//					
//					this.sendPayoutResp.sendOrderResp(payoutInfoDetail);
//				}catch(Exception ex){
//					logger.error(batchInfo.getBatchCode()+",调用业务系统异常 = ",ex);
//				}
//			}
//		}
		return result;		
		
	}
	
    /**
     * 向银行发起查询转结果记录
     */
	@Override
	public List<PayoutInfo> queryCmdStatus(BatchCmdStatusParam batchCmdStatInfo)throws ServiceException {
			
		    BatchInfo binfo=batchInfoDao.queryByReqBankSn(batchCmdStatInfo.getReqBankSn());
		    if(binfo==null){
		    	throw new ServiceException("找不到银行流水号为:"+batchCmdStatInfo.getReqBankSn()+"的批次信息！");
		    }
		    if(!StringUtils.isEmpty(batchCmdStatInfo.getRemark())){
		       if(StringUtils.isEmpty(binfo.getRemark())){
		    	   binfo.setRemark(batchCmdStatInfo.getRemark());  
		       }else{
		         binfo.setRemark(binfo.getRemark()+","+batchCmdStatInfo.getRemark());
		       }
		    }
			List<PayoutInfo> payoutInfoDetail=checkTrans.doBatch(batchCmdStatInfo.getBankCode(), binfo);
			
			//2.2调用订单系统
			if(payoutInfoDetail != null && payoutInfoDetail.size() > 0){
				try{
					this.sendPayoutResp.sendOrderResp(payoutInfoDetail,ExchangeType.SEND_AFTER);
				}catch(Exception ex){
					logger.error(binfo.getBatchCode()+",调用业务系统异常 = ",ex);
				}
			}			
		return payoutInfoDetail;
	}

	/**
	 * 根据异常状态集合查询相应的付款批次记录集合
	 */
	@Override
	public List<BatchInfo> queryBatchInfoByExceptionStatus(List<BatchStatus> statusList,Date startDate,Date endDate,BankCode bankCode,String batchCode)throws ServiceException {
		if(statusList.size()==0){
			return null;
		}
		List<BatchInfo> list=batchInfoDao.queryBatchByStatus1(statusList);
		List<BatchInfo> result=new ArrayList<BatchInfo>();
		for(BatchInfo info:list){
			Date secCheckDate=info.getSecCheckDate();
		    SimpleDateFormat sdf=new SimpleDateFormat("yyyyMMdd");	   
		   
		    //若第二次复核通过时间为空或不在查询日期范围则不用记录
			if(secCheckDate==null){
				continue;
			}
			String tem=sdf.format(secCheckDate);
			try {			    	
				secCheckDate=sdf.parse(tem);
			} catch (ParseException e) {
				throw new ServiceException(e.getMessage(), e);
			}
			if(startDate!=null&&secCheckDate.before(startDate)){
				continue;
			}
			if(endDate!=null&&secCheckDate.after(endDate)){
					continue;
			}
			
			//新增银行类别判断
			if (bankCode != null && !bankCode.equals(info.getPayerOrgCode())) {
				continue;
			}
			//根据批次号查询
			if (!StringUtils.isEmpty(batchCode) && !info.getBatchCode().equals(batchCode)) {
				continue;
			}
			
			
			//若第二次复核通过时间小于配置的时间过滤值则不作为异常指令
			try{
				if(info.getStatus().equals(BatchStatus.SEC_CHECK_PASS))
				{
					long diffMin=DateUtil.dateDiff(info.getSecCheckDate(), new Date());
					String payoutExpTime=paramDao.getParameter("B2E_EXP_REDO_TIME");
					if(StringUtils.isEmpty(payoutExpTime)){
						payoutExpTime="20";
					}
					if(!(diffMin>Integer.parseInt(payoutExpTime))){
						continue;
					}
				}
			}catch(Exception e){
				logger.info("进行记录第二次复核通过日期过滤时出错:"+e.getMessage(),e);
				continue;
			}
			
			if(info.getStatus().equals(BatchStatus.RECEIVED)){
				Date payDate=info.getSecCheckDate();
				if(payDate==null){
					continue;
				}
				String expDay=paramDao.getParameter("B2E_EXP_RECEIVED_LIMIT");
				if(StringUtils.isEmpty(expDay)){
					expDay="2";
				}
				
				
				expDay=expDay.trim();
				int day=1;
				try{
				  day=Integer.parseInt(expDay);
				  if(day<1){
					  day=1;
				  }
				}catch(Exception e){
					day=1;
				}
				
				//注意此处暂设置成2天前,表示超过两天还处在受理状态的的记录
				if(!payDate.before(DateUtil.getBeforeDate(new Date(),day-1))){
					continue;
				}			
			}
			result.add(info);
		}
		return result;
	}

	/**
	 *根据批次号查询相应的异常付款明细记录
	 */
	@Override
	public List<PayoutQueryRlt> queryExceptionPayoutInfoByBatchCode(String batchCode)throws ServiceException {
		return payoutInfoDao.queryPayoutDtlByBatchCode(batchCode);
	}

}
