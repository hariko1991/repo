/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.RandomStringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.common.CurrencyUtil;
import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IAccountInfoDao;
import com.sfpay.acquirer.dao.IBatchInfoDao;
import com.sfpay.acquirer.dao.IBatchRuleInfoDao;
import com.sfpay.acquirer.dao.IDeductionInfoDao;
import com.sfpay.acquirer.dao.IDeductionLogDao;
import com.sfpay.acquirer.dao.IEnumTypeInfoDao;
import com.sfpay.acquirer.dao.IOftenColInfoDao;
import com.sfpay.acquirer.dao.IOverseasOrdersDao;
import com.sfpay.acquirer.dao.IParamInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.dao.ITotalBatchInfoDao;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.domain.BatchTotal;
import com.sfpay.acquirer.domain.DeductionLog;
import com.sfpay.acquirer.domain.EnumTypeInfoDTO;
import com.sfpay.acquirer.domain.NeedDeductionInfo;
import com.sfpay.acquirer.domain.OftenColInfo;
import com.sfpay.acquirer.domain.PayoutEditor;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.TotalBatchInfo;
import com.sfpay.acquirer.domain.TotalDeductInfo;
import com.sfpay.acquirer.enums.AcctType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.BatchOperatorType;
import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.DeductInfoStatus;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.acquirer.enums.PaymentStatusExt;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.enums.SystemSource;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.acquirer.service.IB2EPayoutService;
import com.sfpay.acquirer.service.IPayoutService;
import com.sfpay.acquirer.service.IReconLogService;
import com.sfpay.acquirer.service.NotifyResultHandler;
import com.sfpay.acquirer.service.SendPayoutResp;
import com.sfpay.ebank.gw.IPayoutSAO;
import com.sfpay.ebank.gw.domain.PayoutDTO;
import com.sfpay.ebank.gw.domain.TransPayoutReq;
import com.sfpay.ebank.gw.domain.TransPayoutResp;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.sypay.member.service.ISypayAccountFreezeService;

import net.rubyeye.xmemcached.impl.RandomMemcachedSessionLocaltor;

/**
 * 类说明：<br>
 * 付款服务实现
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2012-10-26O
 */
@Service("payoutService")
@HessianExporter
@SuppressWarnings("deprecation")
public class PayoutServiceImpl  implements IPayoutService {
	private static Logger logger = LoggerFactory.getLogger(PayoutServiceImpl.class);
	private static final boolean isDebug = logger.isDebugEnabled();
	private static final String DATABASE_UNIQUE_EXCEPTION = "ORA-00001";

	
	@Resource
	private IPayoutInfoDao payoutInfoDao;
	
	@Resource
	private IOverseasOrdersDao overseasOrdersDao;
	
	@Resource
	private IBatchInfoDao batchInfoDao;
	
	@Resource
	private IOftenColInfoDao oftenColInfoDao;
	
	@Resource
	private IBatchRuleInfoDao ruleDao;
	
	@Resource
	private IAccountInfoDao accountInfoDao;
	
	@Resource
	private SendPayoutResp sendPayoutResp;
	
	@Resource
	private IB2EPayoutService payout;
	
	@Resource
	private ITotalBatchInfoDao totalBatchDao;
	
	@Resource
	private IParamInfoDao paramInfoDao;
	
	@Resource
	private IDeductionInfoDao deductDao;
	
	@Resource
	private IDeductionLogDao deductLogDao;
		
	@Resource
	private IReconLogService reconLogService;
	
	@Resource 
	private NotifyResultHandler notifyResultHandler;
	@Resource
	private ISypayAccountFreezeService sypayAccountFreezeService;
	@Resource
	private IEnumTypeInfoDao enumTypeInfoDao;
	@Resource
	IPayoutSAO payoutSAO;
	
	//摘要最大长度
	private int summaryLimit = Integer.valueOf(Property.getProperty("B2E_SUMMARY_LIMIT"));
	
	/**
	 * 方法说明：
	 * 创建付款信息(单笔录入和批量录入)
	 */
	@Override
	public List<PayoutEditor> createPayout(List<PayoutEditor> payoutEditorList) throws ServiceException {
		//检查参数
		if(payoutEditorList == null || payoutEditorList.size() == 0){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "参数不能为空");
		}
		logger.info("进入PayoutServiceImpl->createPayout方法，payoutEditorList的size为:{}", payoutEditorList.size());
		List<PayoutEditor> payoutEditorResp = new ArrayList<PayoutEditor>();
		List<PayoutInfo> sendRespInfos=new ArrayList<PayoutInfo>();
		for (Iterator<PayoutEditor> it = payoutEditorList.iterator(); it.hasNext(); ) {
			PayoutEditor editor = it.next();
			
			//检查参数,检查不通过的请求，直接返回失败
			String msg = "";
			if(!StringUtils.isEmpty(editor.getTradeOutNo())){
				msg = "["+editor.getTradeOutNo()+"]";
			}
			try{
				this.checkAdd(editor);
			}catch(ServiceException e){
				logger.error("付款请求"+msg+"不符合要求：",e);
				editor.setRemark(e.getMsg());
				editor.setStatus(PaymentStatusExt.FAILURE);
				payoutEditorResp.add(editor);
				continue;
			}catch(Exception ex){
				logger.error("付款请求"+msg+"不符合要求：",ex);
				editor.setRemark("其他错误");
				editor.setStatus(PaymentStatusExt.FAILURE);
				payoutEditorResp.add(editor);
				continue;
			}
			
			PayoutInfo payoutInfo = this.converToPayoutInfo(editor);
			//转换用途，将中文转换成编码
			String useDesc = editor.getUseDesc();
			Map<String,String> typeMap = this.queryTypeMap();
			if(typeMap.containsKey(useDesc)){
				payoutInfo.setUseType(typeMap.get(useDesc));
			}else{
				payoutInfo.setUseType("OTHER");
			}
			//所有信息检验通过后进行自动抵扣且只有COD的交易才能进行自动抵扣
			DeductionLog log=null;
			if(SystemSource.COD.equals(payoutInfo.getSystemSource())){
			  log=autoDeduct(payoutInfo,sendRespInfos);
			}
			/**
			 * add 2015-9-24 sfhq814	顺手付跨境支付临时用
			 */
			try {
				if (SystemSource.SYPAY.equals(payoutInfo.getSystemSource())
						&& "OFFLINE".equals(payoutInfo.getPayoutBusType())) {
					this.overseasOrdersDao.saveOverseasOrders(payoutInfo);
				} else {
//					this.payoutInfoDao.addPayoutInfo(payoutInfo);// 由于插入后需要返回付款单编号，故不能用批量插入模式
					logger.info("调用gw进行数据录入");
					payoutInfo = this.createPayoutPyGw(payoutInfo);
				}
			} catch (Exception e) {
				boolean flag = e.getMessage().indexOf(DATABASE_UNIQUE_EXCEPTION) != -1;
				if (flag) {//重复数据
					this.dealDuplicateBussinessTrans(payoutEditorResp, editor);
				} else {
					logger.error("付款请求插入异常：",e);
					editor.setRemark("其他错误");
					editor.setStatus(PaymentStatusExt.FAILURE);
					payoutEditorResp.add(editor);
				}
				continue;
			}
			if(log!=null){
				try{
					log.setPayoutNo(payoutInfo.getPayoutNo());
				    deductLogDao.save(log);
				}catch(Exception e){
					logger.error("保存付款单号："+payoutInfo.getPayoutNo()+"的抵扣日志信息失败!",e);
				}
			}
			//录入后，存放付款编号，返回
			editor.setPayoutNo(payoutInfo.getPayoutNo());
			if(payoutInfo.getStatus().equals(PayoutStatus.SUCCESS)){
			   editor.setStatus(PaymentStatusExt.SUCCESS);
			}else if(payoutInfo.getStatus().equals(PayoutStatus.FAILURE)){
				editor.setStatus(PaymentStatusExt.FAILURE);
				editor.setRemark(payoutInfo.getRemark());
			}else{
			   editor.setStatus(PaymentStatusExt.WAITING);
			}			
			payoutEditorResp.add(editor);
			
			if(isDebug){
				logger.debug("添加成功[acctNo = "+editor.getPayeeAcctNo()+",payoutNo = "+editor.getPayoutNo()+",status = "+editor.getStatus()+"]");
			}
			
			//保存常用收款单位
			if(isDebug){
				logger.debug("是否保存常用收款单位:{}",editor.getSaveColtCompFlag());
			}
			if(YNFlag.Y.equals(editor.getSaveColtCompFlag())){
				try {
					OftenColInfo param = this.converToOftenCol(editor);
					oftenColInfoDao.saveOrUpdateOften(param);
				} catch (Exception ex) {
					logger.error("保存常用收款单位异常", ex);
				}
			}
		}
		if (sendRespInfos.size() > 0) {
			new Thread(new CODNotify(sendRespInfos, sendPayoutResp)).start();
		}
		return payoutEditorResp;
	}
	
	private PayoutInfo createPayoutPyGw(PayoutInfo payoutInfo) {
		TransPayoutReq req = new TransPayoutReq();
		req.setVersion("0");
		req.setReqDate(new Date());
		req.setReqSn(RandomStringUtils.randomNumeric(16));
		List<PayoutDTO> payoutList = new ArrayList<PayoutDTO>();
		PayoutDTO param = new PayoutDTO();
		param.setAgentAcctName(payoutInfo.getAgentName());
		param.setAgentAcctNo(payoutInfo.getAgentAcctNo());
		param.setAgentFlag(payoutInfo.getAgentFlag() == null ? "N" : payoutInfo.getAgentFlag().name());
		param.setAmt(payoutInfo.getAmt());
		param.setCcy("CNY" );
		param.setPayeeAcctCity(payoutInfo.getPayeeAcctCity());
		param.setPayeeAcctCityName(payoutInfo.getPayeeAcctCityName());
		param.setPayeeAcctName(payoutInfo.getPayeeAcctName());
		param.setPayeeAcctNo(payoutInfo.getPayeeAcctNo());
		param.setPayeeAcctProvince(payoutInfo.getPayeeAcctProvince());
		param.setPayeeAcctProvinceName(payoutInfo.getPayeeAcctProvinceName());
		param.setPayeeAcctType(payoutInfo.getPayeeAcctType().name());
		param.setPayeeBranchCode(payoutInfo.getPayeeBranchCode());
		param.setPayeeBranchName(payoutInfo.getPayeeBranchName());
		param.setPayeeOrgCode(payoutInfo.getPayeeOrgCode().name());
		param.setPayoutBusType("OTHER");
		param.setRemark(payoutInfo.getUseDesc() + payoutInfo.getRemark());
		param.setRemitMethod(payoutInfo.getRemitMethod().name());
		param.setSummary(payoutInfo.getSummary());
		param.setSystemSource( payoutInfo.getSystemSource().name());
		param.setTradeOutNo(payoutInfo.getTradeOutNo());
		param.setUseType(payoutInfo.getUseType());
		param.setVersion("0");
		if (StringUtils.isEmpty(param.getTradeOutNo())) {
			param.setTradeOutNo(DateFormatUtils.format(new Date(), DateUtil.DATA_FORMAT_PATTERN)
					+ RandomStringUtils.randomAlphanumeric(10));
		}
		payoutList.add(param);
		req.setPayoutList(payoutList);
		TransPayoutResp resp = payoutSAO.applyPayouts(req);
		payoutList = resp.getPayoutList();
		if (CollectionUtils.isNotEmpty(payoutList) && payoutList.size() == 1) {
			PayoutDTO res = payoutList.get(0);
			payoutInfo.setPayoutNo(res.getPayoutNo());
			payoutInfo.setStatus(PayoutStatus.valueOf(res.getStatus()));
			payoutInfo.setRemark(res.getReturnMsg());
		} else {
			payoutInfo.setStatus(PayoutStatus.FAILURE);
			payoutInfo.setRemark("接收失败");
		}
		return payoutInfo;
	}

	/**
	 * 方法说明：<br>
	 * 重复检查
	 * @param payoutEditorResp
	 * @param editor
	 */
	private void dealDuplicateBussinessTrans(List<PayoutEditor> payoutEditorResp, PayoutEditor editor) {
		String msg;
		PayoutInfo pi;
		pi = payoutInfoDao.queryMaxTime(editor.getSystemSource(), editor.getTradeOutNo(),
				editor.getTradeOutBussinessNo());
		if (pi != null) {
			msg = String.format("[%s]交易[%s%s]状态 : %s", pi.getSystemSource(), pi.getTradeOutNo(),
					StringUtils.isEmpty(pi.getTradeOutBussinessNo()) ? "" : "+" + pi.getTradeOutBussinessNo(),
					pi.getStatus());
			switch (pi.getStatus()) {
			case FIR_CHECK_REFUSE:// ("第一次复核拒绝"),
			case SEC_CHECK_REFUSE:// ("第二次复核拒绝"),
			case REJECT:// ("受理被拒绝"),
			case FAILURE:// ("交易失败"),
				break;
			case SUCCESS:// ("交易成功"),
				editor.setPayoutNo(pi.getPayoutNo());
				editor.setStatus(PaymentStatusExt.SUCCESS);
				editor.setPaymentNo(pi.getReqBankSn());
				editor.setPaymentTime(pi.getEndTime());
				payoutEditorResp.add(editor);
				logger.info(String.format("%s, 不录入.(payoutNo: %s, status: %s, paymentNo: %s, paymentTime: %s)", msg,
						editor.getPayoutNo(), editor.getStatus(), editor.getPaymentNo(), editor.getPaymentTime()));
				break;
			case INIT:// ("录入")
			case BATCH:// ("已生成批次")
			case FIR_CHECK_PASS:// ("第一次复核通过"),
			case SEC_CHECK_PASS:// ("第二次复核通过"),
			case RECEIVED:// ("已受理"),
			case UNKOWN:// ("交易未知");
				// 已经受理，不新增收款信息，返回结果
			default:
				editor.setPayoutNo(pi.getPayoutNo());
				editor.setStatus(PaymentStatusExt.WAITING);
				payoutEditorResp.add(editor);
				logger.info(String.format("%s, 不录入.(payoutNo: %s, status: %s)", msg, editor.getPayoutNo(),
						editor.getStatus()));
				return;
			}

		}
	}

	/**
	 * 方法说明：
	 * 生成批次
	 */
	@Override
	@Deprecated
	public BatchInfo createPayout(String ruleCode, String createOperator, List<String> payoutNoList) throws ServiceException {
		return createBatch(ruleCode, createOperator, payoutNoList);
	}
	
	/**
	 * 方法说明：
	 * 生成批次
	 */
	@Override
	public BatchInfo createBatch(String ruleCode, String createOperator, List<String> payoutNoList) throws ServiceException {
		//检查参数
		if(StringUtils.isEmpty(ruleCode)) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "规则编号不能为空");
		}
		if(payoutNoList == null || payoutNoList.size() == 0) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "付款编号列表不能为空");
		}
		if(StringUtils.isEmpty(createOperator)){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "操作员不能为空");
		}
		//查询规则信息
		BatchRuleInfo rule = ruleDao.queryBatchRuleInfoByCode(ruleCode);
		if(rule == null) {
			String eMsg = String.format("找不到[%s]路由规则", ruleCode);
			logger.error(eMsg);
			throw new ServiceException(InfoCode.NO_QUERY_RECORD, eMsg);
		}
		
		//生成批次之前检查收款方账号是否被冻结
		try{
			checkPayeeAcctNoOrFreeze(payoutNoList);
		}catch(Exception e){
			logger.info("生成批次的交易信息中包含被冻结的账号,请重新查询后生成批次!");
			throw new ServiceException(InfoCode.DATABASE_FAILURE,"生成批次的交易信息中包含被冻结的账号,请重新查询后生成批次!" + e);
		}
		//检查数据
		checkBatch(payoutNoList, rule,false);
		
		//查询付款账户信息
		AccountInfo accountInfo = this.accountInfoDao.queryAccountInfoByAccountNo(rule.getAccountNo(),ChannelCode.B2E);
		if(accountInfo == null){
			logger.error("账户(账号:{})不支持银企直联出款", rule.getAccountNo());
			throw new ServiceException(InfoCode.NO_QUERY_RECORD,"账户(账号:"+rule.getAccountNo()+")不支持银企直联出款");
		}
		
		//生成批次
		return doCreateBatch(createOperator, rule, accountInfo, payoutNoList);
	}
	
	/**
	 * 方法说明：<br>
	 * 生成批次
	 *
	 * @param createOperator
	 * @param rule
	 * @param accountInfo
	 * @param payoutNoList
	 * @return
	 * @throws ServiceException
	 */
	private BatchInfo doCreateBatch(String createOperator,BatchRuleInfo rule
			,AccountInfo accountInfo,List<String> payoutNoList) throws ServiceException {
		
		
		//生成批次信息
		BatchInfo batchInfo = new BatchInfo();
		batchInfo.setOperatorType(BatchOperatorType.HAND);//手动
		batchInfo.setCreateOperator(createOperator);
		batchInfo.setRuleCode(rule.getRuleCode());
		batchInfo.setStatus(BatchStatus.INIT);//批次生成
		batchInfo.setTotalAmt(0L);//修改付款信息后生成
		batchInfo.setTotalCnt(0L);//修改付款信息后生成
		try{
			batchInfo.setReqBankSn(CUID.generateId4B2E(20));
		}catch(Exception ex){
			logger.error("生成批次银行请求流水号异常", ex);
			throw new ServiceException(InfoCode.DATABASE_FAILURE,"生成批次银行请求流水号异常", ex);
		}
//				batchInfo.setExpectDate(expectDate);//暂时屏蔽,日后依据情况开放.
//				batchInfo.setRemark(remark);//暂时屏蔽,日后依据情况开放.
		this.batchInfoDao.saveBatchInfo(batchInfo);
		
		//更新付款信息
		PayoutInfo payoutInfo = new PayoutInfo();
		payoutInfo.setPayerAcctAddr(accountInfo.getProvinceName()+accountInfo.getCityName());//暂填省份+城市
		payoutInfo.setPayerAcctCity(accountInfo.getCity());
		payoutInfo.setPayerAcctName(accountInfo.getAccountName());
		payoutInfo.setPayerAcctNo(accountInfo.getAccountNo());
		payoutInfo.setPayerAcctProvince(accountInfo.getProvince());
		payoutInfo.setPayerAcctType(accountInfo.getAcctType());
		payoutInfo.setStatus(PayoutStatus.BATCH);//更新为生成批次
		payoutInfo.setBatchCode(batchInfo.getBatchCode());
		payoutInfo.setPayerBranchCode(accountInfo.getOpeningBankNo());
		payoutInfo.setPayerOrgCode(accountInfo.getBankCode());
		payoutInfo.setPayerEmail("");
		payoutInfo.setPayerMobile("");
		payoutInfo.setCcy(accountInfo.getCcy());
		payoutInfo.setPayerAcctCityName(accountInfo.getCityName());
		payoutInfo.setPayerAcctProvinceName(accountInfo.getProvinceName());
		payoutInfo.setPayerBranchName(accountInfo.getOpeningBankName());
		//增加付款通道,sfhq270   2014-12-16
		payoutInfo.setBankCode(rule.getBankCode());
		
		//如果规则的通道是结算中心的，且规则支持的条数是1 该笔payout_info标记为单笔的 sfhq272  20150302
		if(rule.getBankCode().name().equals(BankCode.SZFS.name())&&1==rule.getBatchMaxSize()){
			payoutInfo.setSzfsFlag("1");
		}
		
		payoutInfoDao.batchUpdatePayout(payoutInfo, payoutNoList, PayoutStatus.INIT);
		
		//查询总笔数和总金额
		BatchTotal total = payoutInfoDao.totalAmtAndNum(batchInfo.getBatchCode());
		batchInfo.setTotalAmt(total.getTotalAmt());
		batchInfo.setTotalCnt(total.getTotalNum());
		
		//更新批次总笔数及总金额(未在生成批次信息时添加。避免并发时其中有一些付款编号已经生成其他批次或删除,造成总笔数、总金额不等的情况)
		batchInfoDao.updateTotal(batchInfo, BatchStatus.INIT);
		
		return batchInfo;
	}
	
	/**
	 * 方法说明：<br>
	 * 生成批次时检查数据
	 *
	 * @param payoutNoList
	 * @param bankCode
	 * @param isBatchCreate //是否批量生成批次
	 * @return
	 */
	private void checkBatch(List<String> payoutNoList, BatchRuleInfo rule,boolean isBatchCreate) throws ServiceException {
		
		if (0 == payoutNoList.size()) {
			throw new ServiceException(InfoCode.PARAM_INVALID,
			        "所有选择的交易均被冻结,所以不能生成批次");
		}

		// 获得路由规则允许出款的最大批次
		long batchMaxSize = rule.getBatchMaxSize();
		if (!isBatchCreate && payoutNoList.size() > batchMaxSize) {
			throw new ServiceException(InfoCode.PARAM_INVALID,
			        "付款笔数大于该批次允许的最大笔数");
		}
		List<PayoutInfo> payouts = null;
		try {
			payouts = payoutInfoDao.queryByPayoutNos(payoutNoList);
		} catch (Exception e) {
			logger.error("付款明细查询报错", e);
			throw new ServiceException(InfoCode.PARAM_INVALID, "付款明细查询报错");
		}
		if (payouts == null || payouts.size() != payoutNoList.size()) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "付款信息中存在已删除信息");
		}
		String[] bankGroup = rule.getBankGroup().split("\\|");
		List<String> bankList = Arrays.asList(bankGroup);
		BigDecimal minAmt = rule.getMinAmt();
		BigDecimal maxAmt = rule.getMaxAmt();
		String ruleAccountNo = rule.getAccountNo();
		for (PayoutInfo payoutInfo : payouts) {
			// 生成批次的判断
			if (!StringUtils.isEmpty(payoutInfo.getBatchCode())) {
				throw new ServiceException(InfoCode.PARAM_INVALID,
				        "部分付款记录已生成过批次");
			}
			// 收款账号类型判断
			AcctType oppAcctType = rule.getOppAcctType();
			if (AcctType.ALL != oppAcctType && payoutInfo
			        .getPayeeAcctType() != oppAcctType) {
				throw new ServiceException(InfoCode.ACCOUNT_EXIST_COMP,
				        "收款账号存与路由规则不匹配的账号类型");
			}
			// 增加对支持的银行判断
			if (!bankList.contains(payoutInfo.getPayeeOrgCode().name())) {
				throw new ServiceException(InfoCode.PARAM_INVALID,
				        "批次付款信息中存在不支持的收款方银行.");
			}
			// 增加路由规则金额上下限判断
			BigDecimal amt = BigDecimal.valueOf(payoutInfo.getAmt());
			if (minAmt != null && amt.compareTo(minAmt) < 0) {
				throw new ServiceException(InfoCode.PARAM_INVALID,
				        "批次付款信息中存在付款金额超过路由规则金额范围");
			}
			if (maxAmt != null && amt.compareTo(maxAmt) > 0) {
				throw new ServiceException(InfoCode.PARAM_INVALID,
				        "批次付款信息中存在付款金额超过路由规则金额范围");
			}
			// 付款账号检测
			if (!StringUtils.isEmpty(payoutInfo.getPayerAcctNo())
			        && !ruleAccountNo.equals(payoutInfo.getPayerAcctNo())) {
				throw new ServiceException(InfoCode.PARAM_INVALID,
				        "批次付款信息存在指定付款账户且与规则账户不一样");
			}
		}

		// 增加对顺手付的付款流水只从走结算中心 出款 sfhq270 周丽佩 2014-11-28
		if (!"SZFS".equals(rule.getBankCode().name()) && "on".equals(Property
		        .getProperty("SZFS_SWITCH"))) {
			// 过滤顺手付交易流水
			// 顺手付的流水如果收款银行是工商银行，出款通道可以是结算中心，也可以是其它的
			// TODO 工行跨行快汇，是否修改待定，2015-07-27
			long count = this.payoutInfoDao.filterTradeOut(payoutNoList);
			if (count != payoutNoList.size()) {
				throw new ServiceException(InfoCode.PARAM_INVALID,
				        "顺手付出款请求出款通道必须为结算中心(除对公业务外)，请重新选择路由.");
			}
		}
		
	}

	/**
	 * 方法说明：
	 * 复核批次
	 * 第二次复核后直接出款
	 * @param batchCode 批次号
	 * @param checkOperator 复核人
	 * @param checkDesc 复核信息备注
	 * @param checkStatus 需要复核的状态
	 * @return
	 * @throws ServiceException
	 */
	@Override
	public BatchStatus checkPayout(String batchCode, String checkOperator, String checkDesc, BatchStatus checkStatus) throws ServiceException {//TODO 第几次复核是否分开接口好些?
		//检查入参
		if(StringUtils.isEmpty(batchCode)) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "批次编号不能为空");
		}
		if(StringUtils.isEmpty(checkOperator)) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "操作员不能为空");
		}
		if(null == checkStatus) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "复核状态不能为空");
		}
		if ((BatchStatus.FIR_CHECK_REFUSE == checkStatus || BatchStatus.SEC_CHECK_REFUSE == checkStatus) && StringUtils.isEmpty(checkDesc)) {//拒绝如果无备注信息抛错
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "拒绝原因不能为空");
		}
		
		// 获取操作类型(手工、自动)
		//String operatorType = batchInfoDao.getOperatorType(batchCode);
		
		//获取批次信息
		BatchInfo batchInfo = this.batchInfoDao.queryByBatchCode(batchCode);
		if(batchInfo == null){
			throw new ServiceException(InfoCode.NO_QUERY_RECORD, "无法找到对应批次信息");
		}
		
		//获取状态
		BatchStatus batchStatus = batchInfo.getStatus();
		
		//检查各级复核人不能相同
		this.checkOperator(batchCode, checkOperator,batchStatus,checkStatus,false);
		
		//更新复核信息（复核人、复核状态、更新时间）
		BatchInfo info = new BatchInfo();
		BatchStatus oldStatus = null;
		PayoutStatus oldPayoutStatus = null;
		if(BatchStatus.INIT.equals(batchStatus)){
			//第一次复核
			info.setFirCheckOperator(checkOperator);
			info.setFirCheckDesc(checkDesc);
			info.setStatus(checkStatus);
			oldStatus = BatchStatus.INIT;
			oldPayoutStatus = PayoutStatus.BATCH;
		}else if(BatchStatus.FIR_CHECK_PASS.equals(batchStatus)){
			//第二次复核
			info.setSecCheckOperator(checkOperator);
			info.setSecCheckDesc(checkDesc);
			info.setStatus(checkStatus);
			oldStatus = BatchStatus.FIR_CHECK_PASS;
			oldPayoutStatus = PayoutStatus.FIR_CHECK_PASS;
		}
		info.setBatchCode(batchCode);
		int cnt = this.batchInfoDao.updateByBatchCode(info,oldStatus);
		int payoutCnt = 0;
		if(cnt > 0){
			//转换付款状态
			PayoutStatus status = null;
			if(BatchStatus.FIR_CHECK_PASS.equals(checkStatus)){
				status = PayoutStatus.FIR_CHECK_PASS;
			}else if(BatchStatus.FIR_CHECK_REFUSE.equals(checkStatus)){
				status = PayoutStatus.FIR_CHECK_REFUSE;
			}else if(BatchStatus.SEC_CHECK_PASS.equals(checkStatus)){
				status = PayoutStatus.SEC_CHECK_PASS;
			}else if(BatchStatus.SEC_CHECK_REFUSE.equals(checkStatus)){
				status = PayoutStatus.SEC_CHECK_REFUSE;
			}
			//更新付款状态
			payoutCnt = this.payoutInfoDao.updateStatusByBatchCode(batchCode, status,oldPayoutStatus);
		}
		
		if(payoutCnt == 0 || payoutCnt != batchInfo.getTotalCnt().intValue()){
			String msg = String.format("更新[%s]付款明细状态条数[%s]与批次总笔数不符,或更新条数为0,不进行出款操作.",batchCode,payoutCnt);
			logger.error(msg);
			throw new ServiceException(InfoCode.ERROR_MSG,msg);	
		}
		
		if(BatchStatus.FIR_CHECK_REFUSE.equals(checkStatus) || BatchStatus.SEC_CHECK_REFUSE.equals(checkStatus) || BatchStatus.SEC_CHECK_PASS.equals(checkStatus)){
			batchInfo = this.batchInfoDao.queryByBatchCode(batchCode);
		}
		
		//复核拒绝,发送结果
		try {
			if(BatchStatus.FIR_CHECK_REFUSE.equals(checkStatus)) {
				sendPayoutResp.doSendOrderResp(PayoutStatus.FIR_CHECK_REFUSE, batchInfo);
			} else if(BatchStatus.SEC_CHECK_REFUSE.equals(checkStatus)) {
				sendPayoutResp.doSendOrderResp(PayoutStatus.SEC_CHECK_REFUSE, batchInfo);
			}
		} catch(Exception ex) {
			logger.error("批次["+batchInfo.getBatchCode()+"]发送复核拒绝结果异常",ex);
		}
		
		//第二次复核通过，出款
		try{
			if(BatchStatus.SEC_CHECK_PASS.equals(checkStatus) ){
				//调用银行出款,生成报文，放入MQ
				payout.doPayoutReq(batchInfo);
			}
		}catch(Exception ex){
			logger.error("批次["+batchInfo.getBatchCode()+"]出款异常,后续由轮询处理",ex);
		}
		
		//返回结果
		return checkStatus;
	}
	
	/**
	 * 方法说明：<br>
	 * 检查复核人及复核状态
	 *
	 * @param batchCode
	 * @param operator
	 * @param batchStatus　当前数据库状态(上次复核状态)
	 * @param checkStatus 复核状态（将要更新）
	 * @return
	 * @throws ServiceException
	 */
	private void checkOperator(String batchCode,String operator,BatchStatus batchStatus,
			BatchStatus checkStatus,boolean isBatch) throws ServiceException{
//		if("AUTO".equals(operatorType)){
//			return;
//		}
		if(!BatchStatus.INIT.equals(batchStatus) && !BatchStatus.FIR_CHECK_PASS.equals(batchStatus)){
			throw new ServiceException(InfoCode.PARAM_INVALID,"now status can not audit.now status = "+batchStatus.name());
		}
		
		BatchStatus status = null;
		if(BatchStatus.INIT.equals(batchStatus)) {
			//当前录入状态
			if(!isBatch&&!BatchStatus.FIR_CHECK_PASS.equals(checkStatus) && !BatchStatus.FIR_CHECK_REFUSE.equals(checkStatus)) {
				//复核状态不属于复核人范围
				throw new ServiceException(InfoCode.PARAM_INVALID,"status is error");
			}
			status = BatchStatus.INIT;
		} else if(BatchStatus.FIR_CHECK_PASS.equals(batchStatus)) {
			//第一次通过
			if(!BatchStatus.SEC_CHECK_PASS.equals(checkStatus) && !BatchStatus.SEC_CHECK_REFUSE.equals(checkStatus)) {
				//复核状态不属于复核人范围
				throw new ServiceException(InfoCode.PARAM_INVALID,"status is error");
			}
			status = BatchStatus.FIR_CHECK_PASS;
		}
		long check = this.batchInfoDao.checkOperator(operator, batchCode, status);
		if(check != 0){
			throw new ServiceException(InfoCode.HAVE_BEEN_AUDITED,"Can not repeat audit");
		}
	}
	
	
	/**
	 * 方法说明：<br>
	 * 转换成常用收款单位实体
	 *
	 * @param editor
	 * @return
	 */
	private OftenColInfo converToOftenCol(PayoutEditor editor) throws ServiceException{
		OftenColInfo oftenColInfo = new OftenColInfo();
		oftenColInfo.setAccountName(editor.getPayeeAcctName());
		oftenColInfo.setAccountNo(editor.getPayeeAcctNo());
		oftenColInfo.setAcctType(editor.getPayeeAcctType());
		oftenColInfo.setBankCode(editor.getPayeeOrgCode());
		oftenColInfo.setCcy(CurrencyType.RMB);//默认为RMB
//		oftenColInfo.setColCompName(colCompName);
//		oftenColInfo.setCompManager(compManager);
//		oftenColInfo.setCreateDate(createDate);
		oftenColInfo.setManagerMobile(editor.getPayeeMobile());
		oftenColInfo.setObAddr(editor.getPayeeAcctAddr());
		oftenColInfo.setObCity(editor.getPayeeAcctCity());
		oftenColInfo.setObNo(editor.getPayeeBranchCode());
		oftenColInfo.setObProvince(editor.getPayeeAcctProvince());
		oftenColInfo.setRemark(editor.getRemark());
		oftenColInfo.setAffiliateName(editor.getPayeeBranchName());
		oftenColInfo.setCountryNameC(editor.getPayeeAcctProvinceName());
		oftenColInfo.setCityName(editor.getPayeeAcctCityName());
		return oftenColInfo;
	}
	/**
	 * 方法说明：<br>
	 * 录入参数检查
	 *
	 * @param editor
	 */
	private void checkAdd(PayoutEditor editor) throws ServiceException {
		if(editor == null) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "入参不能为空");
		}
		if(StringUtils.isEmpty(editor.getPayeeAcctNo())) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "收款账号不能为空");
		}
		if(editor.getAmt() <= 0) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "收款账号["+editor.getPayeeAcctNo()+"]对应的金额必填且必须大于0");
		}
		if(editor.getPayeeOrgCode() == null) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "收款账号["+editor.getPayeeAcctNo()+"]对应的收款方银行(PayeeOrgCode)不能为空");
		}
		if(StringUtils.isEmpty(editor.getPayeeAcctName())) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "收款账号["+editor.getPayeeAcctNo()+"]对应的收款方账户名称(payeeAcctName)不能为空");
		}
		if(editor.getPayeeAcctType() == null) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "收款账号["+editor.getPayeeAcctNo()+"]对应的收款方账户类型(PayeeAcctType)不能为空");
		}
		//顺手付 收款方开行、收款方省份、城市为非必输
		if(editor.getSystemSource()!=null&&!(SystemSource.DBP.name().equals(editor.getSystemSource().name())
				||SystemSource.SYPAY.name().equals(editor.getSystemSource().name())||
				SystemSource.PROV.name().equals(editor.getSystemSource().name()))){
			if(StringUtils.isEmpty(editor.getPayeeBranchName())) {
				throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "收款账号["+editor.getPayeeAcctNo()+"]对应的收款方开户行名称(payeeBranchName)不能为空");
			}
			if(StringUtils.isEmpty(editor.getPayeeAcctProvinceName())) {
				throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "收款账号["+editor.getPayeeAcctNo()+"]对应的收款方省份名称(payeeAcctProvinceName)不能为空");
			}
			if(StringUtils.isEmpty(editor.getPayeeAcctCityName())) {
				throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "收款账号["+editor.getPayeeAcctNo()+"]对应的收款方城市名称(payeeAcctCityName)不能为空");
			}
		}
		if(StringUtils.isEmpty(editor.getUseDesc())) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "收款账号["+editor.getPayeeAcctNo()+"]对应的用途(UseDesc)不能为空");
		}
		
		/* //添加省、城市、银行名称，批量时为空.因业务需求要求,暂时屏蔽,后续是否启用待定.
		if(StringUtils.isEmpty(editor.getPayeeBranchCode())) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "PayeeBranchCode is null");
		}
		if(StringUtils.isEmpty(editor.getPayeeAcctProvince())) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "PayeeAcctProvince is null");
		}
		if(StringUtils.isEmpty(editor.getPayeeAcctCity())) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "cityCode is null");
		}
		*/
		
		if(editor.getSystemSource() == null) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "收款账号["+editor.getPayeeAcctNo()+"]对应的系统来源(SystemSource)不能为空");	
		}
		if(editor.getMsgFlag() == null) {
			editor.setMsgFlag(YNFlag.N);//MsgFlag为空时，标识为否（不需要发送）
		}
		if(YNFlag.Y.equals(editor.getMsgFlag())) {
			if(StringUtils.isEmpty(editor.getPayeeMobile())) {
				throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "收款账号["+editor.getPayeeAcctNo()+"]对应的手机号(PayeeMobile)不能为空");
			}
			editor.setPayeeMobile(editor.getPayeeMobile().trim());
		}
		if(editor.getRemitMethod() == null) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "收款账号["+editor.getPayeeAcctNo()+"]对应的汇款方式(RemitMethod)不能为空");	
		}
		if(!SystemSource.OMS.equals(editor.getSystemSource()) && StringUtils.isEmpty(editor.getTradeOutNo())) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "收款账号["+editor.getPayeeAcctNo()+"]对应的外部交易订单编号 (TradeOutNo)不能为空");	
		}
		
		if(YNFlag.Y.equals(editor.getAgentFlag())){
			if(StringUtils.isEmpty(editor.getAgentAcctNo())){
				throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "代理付款账号["+editor.getAgentAcctNo()+"]不能为空");
			}
			if(StringUtils.isEmpty(editor.getAgentName())){
				throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "代理付款账号名称["+editor.getAgentName()+"]不能为空");
			}
			editor.setAgentAcctNo(editor.getAgentAcctNo().trim());
			editor.setAgentName(editor.getAgentName().trim());
		}
		
		
		editor.setSummary(StringUtils.substr(editor.getSummary(), summaryLimit));//截取过长的摘要
		editor.setPayeeAcctNo(editor.getPayeeAcctNo().trim());
		editor.setPayeeAcctName(editor.getPayeeAcctName().trim());
		editor.setPayeeAcctProvince(editor.getPayeeAcctProvince() == null?null:editor.getPayeeAcctProvince().trim());
		editor.setPayeeAcctCity(editor.getPayeeAcctCity() == null?null:editor.getPayeeAcctCity().trim());
		editor.setUseDesc(editor.getUseDesc().trim());
		editor.setPayeeBranchCode(editor.getPayeeBranchCode() == null?null:editor.getPayeeBranchCode().trim());
		editor.setPayeeAcctCityName(org.apache.commons.lang.StringUtils.isNotBlank(editor.getPayeeAcctCityName())?editor.getPayeeAcctCityName().trim():editor.getPayeeAcctCityName());
		editor.setPayeeAcctProvinceName(org.apache.commons.lang.StringUtils.isNotBlank(editor.getPayeeAcctProvinceName())?editor.getPayeeAcctProvinceName().trim():editor.getPayeeAcctProvinceName());
		editor.setPayeeBranchName(org.apache.commons.lang.StringUtils.isNotBlank(editor.getPayeeBranchName())?editor.getPayeeBranchName().trim():editor.getPayeeBranchName());
		
		
		
		/*  //添加省、城市、银行名称，无法验证.因业务需求要求,暂时屏蔽,后续是否启用待定.
		//检查省是否存在
		List<CountryCity> proList = this.countryCityDao.queryByCode(editor.getPayeeAcctProvince());
		if(proList == null || proList.size() == 0){
			throw new ServiceException(InfoCode.ERROR_MSG
					,"收款账号["+editor.getPayeeAcctNo()+"]对应的收款方省份["+editor.getPayeeAcctProvince()+"]不存在");
		}
		
		//检查城市是否存在
		List<CountryCity> cityList = this.countryCityDao.queryByCode(editor.getPayeeAcctCity());
		if(cityList == null || cityList.size() == 0){
			throw new ServiceException(InfoCode.ERROR_MSG
					,"收款账号["+editor.getPayeeAcctNo()+"]对应的收款方城市["+editor.getPayeeAcctCity()+"]不存在");
		}
		
		//城市是否属于省
		CountryCity city = this.countryCityDao.queryParentByCode(editor.getPayeeAcctCity());
		if(city == null){
			throw new ServiceException(InfoCode.ERROR_MSG
					,"收款账号["+editor.getPayeeAcctNo()+"]对应的收款方城市["+editor.getPayeeAcctCity()+"]无省级别数据");
		}
		if(!city.getCountryCode().equals(editor.getPayeeAcctProvince())){
			throw new ServiceException(InfoCode.ERROR_MSG
					,"收款账号["+editor.getPayeeAcctNo()+"]对应的收款方城市["+editor.getPayeeAcctCity()+"]不属于收款方省份["+editor.getPayeeAcctProvince()+"]");
		}
		
		//检查银行是否存在
		List<AffiliateBank> bankList = this.affiliateBankDao.queryByAffiliateNo(editor.getPayeeOrgCode().name());
		if(bankList == null || bankList.size() == 0){
			throw new ServiceException(InfoCode.ERROR_MSG
					,"不支持收款账号["+editor.getPayeeAcctNo()+"]对应的收款方银行["+editor.getPayeeOrgCode()+"]");
		}
		//检查联行号是否存在
		List<AffiliateBank> affiliateList = this.affiliateBankDao.queryByAffiliateNo(editor.getPayeeBranchCode());
		if(affiliateList == null || affiliateList.size() == 0){
			throw new ServiceException(InfoCode.ERROR_MSG
					,"收款账号["+editor.getPayeeAcctNo()+"]对应的收款方开户行联行号["+editor.getPayeeBranchCode()+"]不存在");
		}
		
		//检查联行号是否属于该城市
		AffiliateBank affiliateBank = this.affiliateBankDao.queryBankByAffiliateNo(editor.getPayeeBranchCode());
		if(affiliateBank == null){
			throw new ServiceException(InfoCode.ERROR_MSG
					,"收款账号["+editor.getPayeeAcctNo()+"]对应的收款方联行号["+editor.getPayeeBranchCode()+"]无银行级别数据");
		}
		if(!editor.getPayeeOrgCode().name().equals(affiliateBank.getAffiliateNo())){
			throw new ServiceException(InfoCode.ERROR_MSG
					,"收款账号["+editor.getPayeeAcctNo()+"]" +
							"对应的收款方联行号["+editor.getPayeeBranchCode()+"]不属于银行["+editor.getPayeeOrgCode()+"]" +
									"(该联行号属于["+affiliateBank.getAffiliateNo()+"])");
		}
		*/
	}
	
	/**
	 * 方法说明：<br>
	 * 转换成付款实体
	 *
	 * @param editor
	 * @return
	 */
	private PayoutInfo converToPayoutInfo(PayoutEditor editor) throws ServiceException{
		
		PayoutInfo payoutInfo = new PayoutInfo();
		payoutInfo.setAmt(editor.getAmt());//单位：分
		payoutInfo.setShouldAmt(editor.getAmt());
		payoutInfo.setCcy(CurrencyType.RMB);//默认为RMB
		payoutInfo.setChannelCode(ChannelCode.B2E);
		payoutInfo.setFundWay(FundWay.OUT);
		payoutInfo.setMsgFlag(editor.getMsgFlag());
		payoutInfo.setOrderType(OrderType.PAYOUT);
		payoutInfo.setPayeeAcctAddr(editor.getPayeeAcctAddr());
		payoutInfo.setPayeeAcctCity(editor.getPayeeAcctCity());
		payoutInfo.setPayeeAcctName(editor.getPayeeAcctName());
		payoutInfo.setPayeeAcctNo(editor.getPayeeAcctNo());
		payoutInfo.setPayeeAcctProvince(editor.getPayeeAcctProvince());
		payoutInfo.setPayeeAcctType(editor.getPayeeAcctType());
		payoutInfo.setPayeeBranchCode(editor.getPayeeBranchCode());
		payoutInfo.setPayeeEmail(editor.getPayeeEmail());
		payoutInfo.setPayeeMobile(editor.getPayeeMobile());
		payoutInfo.setPayeeOrgCode(editor.getPayeeOrgCode());
		payoutInfo.setRemark(editor.getRemark());
		payoutInfo.setRemitMethod(editor.getRemitMethod());
		payoutInfo.setStatus(PayoutStatus.INIT);
		payoutInfo.setSummary(editor.getSummary());
		payoutInfo.setUseDesc(editor.getUseDesc());
		payoutInfo.setPayeeBranchName(editor.getPayeeBranchName());
		payoutInfo.setPayeeAcctProvinceName(editor.getPayeeAcctProvinceName());
		payoutInfo.setPayeeAcctCityName(editor.getPayeeAcctCityName());
		payoutInfo.setExpectPayDate(editor.getExpectPayDate());
		String busType = editor.getPayoutBusType()==null?"OTHER":editor.getPayoutBusType().name();
		payoutInfo.setPayoutBusType(busType);
		payoutInfo.setSystemSource(editor.getSystemSource());
		payoutInfo.setTradeOutNo(editor.getTradeOutNo());
		payoutInfo.setTradeOutBussinessNo(editor.getTradeOutBussinessNo());
		payoutInfo.setDeductionAmt(0L);//默认抵扣金额为0
		if(null==editor.getAgentFlag()){
			editor.setAgentFlag(YNFlag.N);
		}
		payoutInfo.setAgentFlag(editor.getAgentFlag());
		payoutInfo.setAgentAcctNo(editor.getAgentAcctNo());
		payoutInfo.setAgentName(editor.getAgentName());
		
		if(YNFlag.Y.equals(editor.getAgentFlag())){
			payoutInfo.setAgentFlag(YNFlag.Y);
			payoutInfo.setAgentAcctNo(editor.getAgentAcctNo());
			payoutInfo.setAgentName(editor.getAgentName());
		}
		return payoutInfo;
		
	}

	@Override
	public TotalBatchInfo createBatchPayout(String ruleCode, String createOperator,List<String> payoutNoList) throws ServiceException {
		//检查参数
		if(StringUtils.isEmpty(ruleCode)){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"ruleCode is null");
		}
		if(payoutNoList == null || payoutNoList.size() == 0){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"payoutNoList is null");
		}
		if(StringUtils.isEmpty(createOperator)){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"createOperator is null");
		}
		//查询规则信息
		BatchRuleInfo rule = ruleDao.queryBatchRuleInfoByCode(ruleCode);
		if(rule == null) {
			String eMsg = String.format("找不到[%s]路由规则", ruleCode);
			logger.error(eMsg);
			throw new ServiceException(InfoCode.NO_QUERY_RECORD, eMsg);
		}
		
		//生成批次之前检查收款方账号是否被冻结
		try{
			checkPayeeAcctNoOrFreeze(payoutNoList);
		}catch(Exception e){
			logger.info("生成批次的交易信息中包含被冻结的账号,请重新查询后生成批次!");
			throw new ServiceException(InfoCode.DATABASE_FAILURE,"生成批次的交易信息中包含被冻结的账号,请重新查询后生成批次!" + e);
		}
		//检查数据
		checkBatch(payoutNoList,rule,true);
		
		
		//查询付款账户信息
		AccountInfo accountInfo = this.accountInfoDao.queryAccountInfoByAccountNo(rule.getAccountNo(),ChannelCode.B2E);
		if(accountInfo == null){
			logger.error("账户(账号:{})不支持银企直联出款", rule.getAccountNo());
			throw new ServiceException(InfoCode.NO_QUERY_RECORD,"账户(账号:"+rule.getAccountNo()+")不支持银企直联出款");
		}
		
		int paySize=payoutNoList.size();
		
		int maxSize=Integer.parseInt(String.valueOf(rule.getBatchMaxSize()));
		
		int blockSize=paySize/maxSize;
		
		int loopSize=paySize%maxSize==0?blockSize:blockSize+1;
		
		List<BatchInfo> subBatch=new ArrayList<BatchInfo>();
		int limitBatchCnt=0;
		try{
		  limitBatchCnt=Integer.parseInt(paramInfoDao.getParameter("LIMIT_BATCH_CNT"));
		}catch(Exception e){
			limitBatchCnt=30;
		}
		if(loopSize>limitBatchCnt){
			throw new ServiceException(InfoCode.ERROR_MSG,"批量生成批次生成批次数已超过最大生成批次数限制,最大支持"+limitBatchCnt*rule.getBatchMaxSize()+"笔记录!");
		}
		
		for(int i=0;i<loopSize;i++){
		  try{
			//按路由规则拆分付款明细记录
			List<String> subBatchNoList=payoutNoList.subList(i*maxSize,(i+1)*maxSize>payoutNoList.size()?payoutNoList.size():(i+1)*maxSize);
			//调用原有生成批次方法生成批次
			BatchInfo temBatch=doCreateBatch(createOperator, rule, accountInfo, subBatchNoList);
			//若生成批次成功则将生成的子批次存入缓存
			if(temBatch!=null){
				subBatch.add(temBatch);
			}
		  }catch(Exception e){
			  logger.error("系统批量生成子批次时出错!",e);
		  }
		}
		//统计各子批次信息
		long totalAmt=0;
		long totalNum=0;
		List<String> subBatchCode=new ArrayList<String>();
		for(BatchInfo binfo:subBatch){
			totalAmt+=binfo.getTotalAmt();
			totalNum+=binfo.getTotalCnt();
			subBatchCode.add(binfo.getBatchCode());
		}
		//存总比次信息
		TotalBatchInfo tBatchInfo=new TotalBatchInfo();
		tBatchInfo.setCreateOperator(createOperator);
		tBatchInfo.setRuleCode(ruleCode);
		tBatchInfo.setStatus(BatchStatus.INIT);//批次生成
		tBatchInfo.setTotalBatchAmt(totalAmt);
		tBatchInfo.setTotalBatchCnt(totalNum);
		totalBatchDao.saveTotalBatchInfo(tBatchInfo);
		
	    //更新各子批次的总批次号
		batchInfoDao.updateTotalBatchCode(tBatchInfo.getTotalBatchCode(), subBatchCode);				
		//更新付款明细记录总批次号
		payoutInfoDao.updateTotalBatchCode(tBatchInfo.getTotalBatchCode(), subBatchCode);
		return tBatchInfo;
	}
	
	
	
	@Override
	public String batchCheckPayout(String totalBatchCode,String checkOperator, String checkDesc, BatchStatus checkStatus)throws ServiceException {
		if(isDebug){
			logger.debug("checkDesc = "+totalBatchCode+",checkDesc = "+checkOperator
					+",checkDesc = "+checkDesc+",checkStatus = "+checkStatus);
		}
		//检查入参
		if(StringUtils.isEmpty(totalBatchCode)) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "totalBatchCode is null");
		}
		if(StringUtils.isEmpty(checkOperator)) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "checkOperator is null");
		}
		if(null == checkStatus) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "checkStatus is null");
		}
		if ((BatchStatus.FIR_CHECK_REFUSE == checkStatus || BatchStatus.SEC_CHECK_REFUSE == checkStatus) && StringUtils.isEmpty(checkDesc)) {//拒绝如果无备注信息抛错
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "checkDesc is null");
		}
		
		if(!(BatchStatus.SEC_CHECK_PASS.equals(checkStatus)||BatchStatus.SEC_CHECK_REFUSE.equals(checkStatus))){
			throw new 	ServiceException(InfoCode.ERROR_MSG,"批量复核支付复核状态只充许为二次复核通过或拒绝!");
		}
		
		TotalBatchInfo tBatchInfo=totalBatchDao.queryBatchInfo(totalBatchCode);
		if(tBatchInfo==null){
			throw new ServiceException(InfoCode.ERROR_MSG,"找不到总批次号为"+totalBatchCode+"的总批次信息！");
		}		
		// 检查各级复核人不能相同
		if (checkOperator.equals(tBatchInfo.getCreateOperator())) {
			throw new ServiceException(InfoCode.ERROR_MSG,"批量复核人与批次创建人不能为同一个人！");
		}		
		
		//获取子批次批次号
		List<String> batchCodes=batchInfoDao.queryBatchCodeByTotalBatchCode(totalBatchCode);
		
		
		if(batchCodes==null||batchCodes.size()==0){
			long cnt=batchInfoDao.countStatusByTotalBatchCode(totalBatchCode,BatchStatus.FIR_CHECK_PASS);
			totalBatchDao.updateTotalBatchStatus(totalBatchCode,BatchStatus.DONE, checkDesc, checkOperator, BatchStatus.INIT);
			if(cnt>0){
				return InfoCode.NO_INFO_HAS_FIR_CHECKED;
			}
		    return InfoCode.NO_BATCH_CHECK_INFO;
		}
		
		BatchRuleInfo ruleInfo=	ruleDao.queryBatchRuleInfoByCode(tBatchInfo.getRuleCode());
		if(ruleInfo==null){
			throw new ServiceException(InfoCode.ERROR_MSG,"总批次号："+tBatchInfo.getTotalBatchCode()+"找不到路由规则："+tBatchInfo.getRuleCode()+"的信息！");
		}
	    int count=0;
		for(String batchCode:batchCodes){
			try{
				//处理各批次并发送至银行处理
				processBatch(batchCode, checkOperator, checkStatus, checkDesc,ruleInfo);
				count++;
			}catch(Exception e){
				logger.info("批理复核支付处理批次号"+batchCode+"的批次信息出错!",e);
			}
		}
		if(count>0){
			//更新总批次信息TotalBatchInfo表
			totalBatchDao.updateTotalBatchStatus(totalBatchCode,BatchStatus.DONE, checkDesc, checkOperator, BatchStatus.INIT);
			logger.info("总批次号{}的批量复核支付处理处理完成!",totalBatchCode);
		}else{
			throw new ServiceException(InfoCode.ERROR_MSG,"批量复核支付处理失败（处理记录条数为0）！");
		}
		return InfoCode.SUCCESS;		
	}
	
	
	
	//内部方法用以处理批量复核支付批次处理
	private void processBatch(String batchCode,String checkOperator,BatchStatus checkStatus,String checkDesc,BatchRuleInfo ruleInfo)throws Exception{
		
		// 获取操作类型(手工、自动)
		//String operatorType = batchInfoDao.getOperatorType(batchCode);
				
		//获取批次信息
		BatchInfo batchInfo = this.batchInfoDao.queryByBatchCode(batchCode);
		if(batchInfo == null){
			throw new ServiceException(InfoCode.NO_QUERY_RECORD,"batchInfo is null");
		}
		//获取状态
		BatchStatus batchStatus = batchInfo.getStatus();
		if(!BatchStatus.INIT.equals(batchStatus)){
			logger.info("批量复核支付处理批次号"+batchInfo.getBatchCode()+"的批次状态非INIT状态不能进行复核!");
			return;
			
		}		
		
		//更新批次表为第二次复核通过
		BatchInfo info = new BatchInfo();
		BatchStatus oldStatus = BatchStatus.INIT;				
		PayoutStatus oldPayoutStatus = PayoutStatus.BATCH;
		
		//设置批次状态 checkStatus由外部传入，直接为第二次复核通过或拒绝
		//以前的第一次及第二次复核信息则一样直接写入传入参数
		info.setStatus(checkStatus);
		info.setFirCheckDesc(checkDesc);
		info.setFirCheckOperator(checkOperator);
		info.setSecCheckDesc(checkDesc);
		info.setSecCheckOperator(checkOperator);
		info.setBatchCode(batchCode);
		//更新批次信息表状态由原来的INIT直接更新成第二次复核通过或拒绝
		int cnt = this.batchInfoDao.updateByBatchCode(info,oldStatus);
		int payoutCnt = 0;
		if(cnt > 0){           
			//表示更新批次表成功需要更新明细记录表状态 
			//因批量复核支付没有第一次复核信息故在此无需判断第一次复核的状态信息
			PayoutStatus status = null;
			if(BatchStatus.SEC_CHECK_PASS.equals(checkStatus)){
				status = PayoutStatus.SEC_CHECK_PASS;
			}else if(BatchStatus.SEC_CHECK_REFUSE.equals(checkStatus)){
				status = PayoutStatus.SEC_CHECK_REFUSE;
			}
			//更新付款状态
			payoutCnt = this.payoutInfoDao.updateStatusByBatchCode(batchCode, status,oldPayoutStatus);
		}
		logger.info("共更新[{}]条付款记录.",payoutCnt);
		if(payoutCnt == 0 || payoutCnt != batchInfo.getTotalCnt().intValue()){
			String msg = String.format("更新[%s]付款明细状态条数与批次总笔数不符,或更新条数为0,不进行出款操作.",batchCode);
			logger.error(msg);
			throw new ServiceException(InfoCode.ERROR_MSG,msg);	
		}
		
		//因批量复核支付只有第二次复核通过或拒绝故需要重新获取信息以取得最终的状态值
		batchInfo = this.batchInfoDao.queryByBatchCode(batchCode);
		
		// 复核拒绝,发送结果
		try {
			if (BatchStatus.SEC_CHECK_REFUSE.equals(checkStatus)) {
				sendPayoutResp.doSendOrderResp(PayoutStatus.SEC_CHECK_REFUSE,
						batchInfo);
			} else if (BatchStatus.SEC_CHECK_PASS.equals(checkStatus)) {
				// 调用银行出款,生成报文，放入MQ
				payout.doPayoutReq(batchInfo, ruleInfo);
			}
		} catch (Exception ex) {
			logger.error("批次[" + batchInfo.getBatchCode() + "]发送外部系统或银行处理异常！", ex);
		}		
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据待抵扣信息执行自动抵扣 
	 * @param payoutEditorList
	 * @throws ServiceException
	 */
	private DeductionLog autoDeduct(PayoutInfo info,List<PayoutInfo> sendRespInfos){
		
		String tradeOutNo=info.getTradeOutNo();
		String[] tem=tradeOutNo.split("N");
		String custNo=tem[0];
		TotalDeductInfo deductInfo=deductDao.countCustDeductionInfos(custNo,DeductInfoStatus.INIT);
		if(deductInfo.getTotalCnt()==0L){
			logger.info("付款单号:"+info.getTradeOutNo()+"无抵扣信息！");
			return null;
		}
		if(deductInfo.getTotalAmt()==0L){
			logger.info("付款单号:"+info.getTradeOutNo()+"待抵扣金额为0无需进行抵扣！");
			return null;
		}
		//更新待抵扣信息状态
		deductDao.finlishCustDeductionInfoStatus(custNo);		
		DeductionLog deductLog=new DeductionLog();
		deductLog.setBeginTime(new Date());
		deductLog.setCreateDate(new Date());
		deductLog.setDeducationDate(new Date());
		deductLog.setDeductionOper(deductInfo.getOperatorId());
		deductLog.setCreateId(deductInfo.getOperatorId());
		deductLog.setPayeeAcctName(info.getPayeeAcctName());
		deductLog.setPayeeAcctNo(info.getPayeeAcctNo());
		deductLog.setRemark(info.getRemark());
		deductLog.setSystemSource(info.getSystemSource());
		deductLog.setTradeOutBussinessNo(info.getTradeOutBussinessNo());
		deductLog.setTradeOutNo(info.getTradeOutNo());
		deductLog.setShouldAmt(info.getShouldAmt());		
		if(info.getShouldAmt()>deductInfo.getTotalAmt()){                  //应付金额>抵扣金额
			info.setAmt(info.getShouldAmt()-deductInfo.getTotalAmt());
			deductLog.setDeductionAmt(deductInfo.getTotalAmt());
			info.setDeductionAmt(deductInfo.getTotalAmt());
		}else if(info.getShouldAmt().equals(deductInfo.getTotalAmt())){          //应付金额=抵扣金额
			//需通知COD
			info.setAmt(0L);
			info.setStatus(PayoutStatus.SUCCESS);	
			sendRespInfos.add(info);
			deductLog.setDeductionAmt(deductInfo.getTotalAmt());
			info.setDeductionAmt(deductInfo.getTotalAmt());
			info.setEndTime(new Date());			
		}else if(info.getShouldAmt()<deductInfo.getTotalAmt()){           //应付金额<抵扣金额
		    //需通知COD,产生新的扣款指令
			info.setAmt(0L);
			info.setStatus(PayoutStatus.SUCCESS);
			NeedDeductionInfo needDedectInfo=new NeedDeductionInfo();
			needDedectInfo.setCustAccNo(custNo);
			needDedectInfo.setCustName(deductInfo.getCustName());
			needDedectInfo.setDisputeAmt(deductInfo.getTotalAmt()-info.getShouldAmt());
	        needDedectInfo.setOperatorId(deductInfo.getOperatorId());
	        needDedectInfo.setRecDay(new Date());
	        needDedectInfo.setRemark("自动抵扣合并后，抵扣总金额("+CurrencyUtil.fen2Yuan(deductInfo.getTotalAmt())+"元)大于应付金额("+CurrencyUtil.fen2Yuan(info.getShouldAmt())+"元)，等待下次抵扣操作!");     
	        needDedectInfo.setStatus(DeductInfoStatus.INIT);
	        needDedectInfo.setSystemSource(SystemSource.COD);
	        deductDao.addDeductionInfo(needDedectInfo);
	        sendRespInfos.add(info);
	        deductLog.setDeductionAmt(info.getShouldAmt());
	        info.setDeductionAmt(info.getShouldAmt());
	        info.setEndTime(new Date());
		}
		deductLog.setAmt(deductLog.getShouldAmt()-deductLog.getDeductionAmt());
		deductLog.setCurDeductionAmt(deductLog.getDeductionAmt());
		deductLog.setDeductionRemark("系统实现客户："+custNo+"自动抵扣！");		
		return deductLog;
		
	}
	
	/**
	 * 类说明：<br>
	 * 
	 * 
	 * <p>
	 * 详细描述：<br>
	 * 
	 * 
	 * </p>
	 * 
	 * @author 400928 向鹏
	 * 
	 * CreateDate: 2014-1-8
	 */
	private static class  CODNotify  implements Runnable {
		private SendPayoutResp sendPayoutResp;
		private List<PayoutInfo> datas;
		public CODNotify(List<PayoutInfo> list, SendPayoutResp send){
			datas=list;
			sendPayoutResp=send;
		}
		@Override
		public void run() {		
			logger.info("共有" + datas.size() + "条抵扣完成后交易成功记录返回给COD");
			try{
			  Thread.sleep(600000);	
			  sendPayoutResp.sendResp(datas);
			}catch(Exception e){
				logger.error("向COD返回抵扣处理完成后成功交易结果失败！", e);
			}
		}
	}
	
	
	private class FreezePayoutInfoHandler extends Thread {
		private List<String> payoutNos;
		private List<PayoutInfo> freezePayoutInfos;
		
		public FreezePayoutInfoHandler(List<String> payoutNos, List<PayoutInfo> freezePayoutInfos) {
			this.payoutNos = payoutNos;
			this.freezePayoutInfos = freezePayoutInfos;
		}
		
		@Override
		public void run() {	
			String log = String.format("冻结:操作时间[%s],付款编号[%s]",new Date(), payoutNos);
			try{
				payoutInfoDao.updatePayoutForFreeze(payoutNos);
				notifyResultHandler.doSendOrderResp(freezePayoutInfos, PayoutStatus.SEC_CHECK_REFUSE);
				logger.info("FreezePayoutInfoHandler更新为冻结,付款编号:[{}]", payoutNos);
				logger.info("记录冻结日志：[{}]...",log);
				reconLogService.insertReconLog("INFO", log);
			}catch(Exception ex){
				logger.info("记录["+log+"]异常",ex);
			}
		}
	}
	
	/**
	 * 根据顺手付查询出的冻结账号处理交易
	 * add by sfh272  2015.4.15
	 * @param payoutNoList
	 * @return
	 * @throws ServiceException
	 */
	private void checkPayeeAcctNoOrFreeze(List<String> payoutNoList) throws ServiceException {
		if(null == payoutNoList || payoutNoList.size() == 0)
			return ;
		
		try{
			List<PayoutInfo> payoutInfos = payoutInfoDao.queryByPayoutNos(payoutNoList);
			Set<String> payeeAcctNos = new HashSet<String>();
			List<PayoutInfo> freezePayoutInfos = new ArrayList<PayoutInfo>();
			List<String> freezePayoutNos = new ArrayList<String>();
			if(null != payoutInfos && payoutInfos.size() != 0){
				for(PayoutInfo pi : payoutInfos){
					if(pi.getSystemSource().name().equals(SystemSource.SYPAY.name())){
						payeeAcctNos.add(pi.getPayeeAcctNo());
					}
				}
			}
			if(payeeAcctNos.size()==0){
				return;
			}
			List<String> freezePayeeAcctNos = sypayAccountFreezeService.queryFrozenSypayAccount(new ArrayList<String>(payeeAcctNos));
			
			if(null != freezePayeeAcctNos && 0 != freezePayeeAcctNos.size()){
			//第一步：调用顺手付接口查询账号是否冻结,返回被冻结的银行账号
			//第二步：根据返回的银行账号判断哪些payoutInfo被拒绝,找到相应的payoutNo
				for(PayoutInfo pi : payoutInfos){
					for(String freezePayeeAcctNo : freezePayeeAcctNos){
						if(pi.getPayeeAcctNo().equals(freezePayeeAcctNo)){
							pi.setOldStatus(pi.getStatus());
							pi.setStatus(PayoutStatus.SEC_CHECK_REFUSE);
							logger.info("风控冻结,付款编号:[{}]",new Object[]{pi.getPayoutNo()});
							freezePayoutInfos.add(pi);
							freezePayoutNos.add(pi.getPayoutNo());
							payoutNoList.remove(pi.getPayoutNo());
						}
					}
				}
				new FreezePayoutInfoHandler(freezePayoutNos, freezePayoutInfos).start();
				//notifyResultHandler.doSendOrderResp(freezePayoutInfos, PayoutStatus.SEC_CHECK_REFUSE);
			}
		}catch(Exception e){
			logger.error("checkPayeeAcctNoOrFreeze异常[{}]", e);
			throw new ServiceException("checkPayeeAcctNoOrFreeze异常" + e.getMessage(), e);
		}
	}

	/**
	 * 方法说明：<br>
	 * key：用途名称 value：用途编码
	 * 
	 * @return
	 */
	private Map<String, String> queryTypeMap() {
		List<EnumTypeInfoDTO> useList = enumTypeInfoDao.queryByType("useType");
		Map<String, String> res = new HashMap<String, String>();
		if (useList != null) {
			for (EnumTypeInfoDTO type : useList) {
				res.put(type.getEnumName(), type.getEnumCode());
			}
		}
		return res;
	}
}
