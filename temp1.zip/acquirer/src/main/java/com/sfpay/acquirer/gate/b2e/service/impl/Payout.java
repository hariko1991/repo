package com.sfpay.acquirer.gate.b2e.service.impl;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutReqResult;
import com.sfpay.acquirer.enums.AcctType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.PayoutSendStatus;
import com.sfpay.acquirer.gate.b2e.BasePayout;
import com.sfpay.acquirer.gate.b2e.command.BatchAgtexchTransfer;
import com.sfpay.acquirer.gate.b2e.command.BatchPayOff;
import com.sfpay.acquirer.gate.b2e.command.BatchTransfer;
import com.sfpay.acquirer.gate.b2e.command.SinglePayTransfer;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.acquirer.gate.b2e.service.IPayout;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 
 * 类说明：<br>
 * 出款指令（请求/响应）
 * TODO 基于此服务，不同的银行不同的付款指令就应该有不同的支付服务实现
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * @author 400928 向鹏
 * 
 * CreateDate: 2013-5-6
 */
public class Payout extends BasePayout implements IPayout {
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	protected final boolean isDebug = logger.isDebugEnabled();


	@Override
	public PayoutSendStatus doReq(BatchInfo bi, List<PayoutInfo> info, BankProperty property, BankCode bankCode, BatchRuleInfo rule) throws Exception {
		//如果是结算中心的批次且批次只有一笔走结算中心单笔代付的接口
		if(1 == bi.getTotalCnt() && bankCode.name().equals(BankCode.SZFS.name())){
			PayoutInfo pi = info.get(0);
			logger.info("银企直连单笔代付组报文,批次号{},明细流水号{},通道{}", new Object[]{bi.getBatchCode(), pi.getReqBankSn(), bankCode.name()});
			SinglePayTransfer spt = new SinglePayTransfer(pi, bankCode);
			return spt.send(bi.getReqBankSn(),bankCode, property, bi);
		}
		
//		if(YNFlag.Y.equals(info.get(0).getAgentFlag())){ //判断是否为代理支付
//			BatchAgtexchTransfer bagt=new BatchAgtexchTransfer(bi,info, bankCode);
//			return bagt.send(bi.getReqBankSn(),bankCode, property, bi);
//		}
		AcctType oppAcctType = this.getAcctType(rule);
		if (AcctType.COMPANY.equals(oppAcctType)) {// 公
			BatchTransfer req = new BatchTransfer(bi, info, bankCode,rule);
			return req.send(bi.getReqBankSn(), bankCode, property, bi);
		} else if (AcctType.PERSON.equals(oppAcctType)) {// 私
			BatchPayOff req = new BatchPayOff(bi, info, bankCode,rule);
			return req.send(bi.getReqBankSn(), bankCode, property, bi);		
		} else {
			logger.error("账号类型有误!");
			throw new ServiceException(InfoCode.FAILURE, "账号类型[" + oppAcctType + "]有误!");
		}
	}

	
	@Override
	public PayoutReqResult doResp(BeanBase respBean) throws Exception {
		if(TradeCodeB2E.BATCH_AGENT_TRANSFER.equals(respBean.getTradeCode())){
			BatchAgtexchTransfer resp=new BatchAgtexchTransfer();
			return resp.parse(respBean);
		}else if (TradeCodeB2E.BATCH_PAYOFF.equals(respBean.getTradeCode())) {
			BatchPayOff resp = new BatchPayOff();
			return resp.parse(respBean);
		} else if (TradeCodeB2E.BATCH_TRANSFER.equals(respBean.getTradeCode())) {
			BatchTransfer resp = new BatchTransfer();
			return resp.parse(respBean);
		} else if(TradeCodeB2E.SZFS_SINGLEPAY.equals(respBean.getTradeCode())){
			logger.info("银企直连单笔代付解报文");
			SinglePayTransfer spt = new SinglePayTransfer();
			return spt.parse(respBean);
		} else {
			logger.error("不支持该指令: {}", respBean.getTradeCode());
			throw new ServiceException(InfoCode.FAILURE, "不支持该指令: " + respBean.getTradeCode());
		}
	}

}
