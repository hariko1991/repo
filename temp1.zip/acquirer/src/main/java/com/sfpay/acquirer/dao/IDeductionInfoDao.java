/**
 * =================================================================
 * 版权所有 2011-2013 深圳市泰海网络科技服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.NeedDeductionInfo;
import com.sfpay.acquirer.domain.NeedDeductionInfoQueryParam;
import com.sfpay.acquirer.domain.TotalDeductInfo;
import com.sfpay.acquirer.enums.DeductInfoStatus;

/**
 * 类说明：<br>
 * 抵扣信息录入数据层业务处理类 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 *  
 * @author 400928 向鹏
 * 
 * CreateDate: 2013-12-25
 */
public interface IDeductionInfoDao {
	
	/**
	 * 
	 * 方法说明：<br>
	 * 扣款信息录入
	 * @param info
	 */
	public void  addDeductionInfo(@Param("info")NeedDeductionInfo info);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 按条件统计待抵扣信息记录总数
	 * @param param
	 */
	public Long  countNeedDeductionInfos(@Param("param")NeedDeductionInfoQueryParam param);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 分页查询待抵扣信息
	 * @param param
	 * @param start
	 * @param end
	 * @return
	 */
	public List<NeedDeductionInfo> queryNeedDeductionInfos(@Param("param")NeedDeductionInfoQueryParam param,@Param("start")int start,@Param("end")int end);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 统计客户待抵扣信息
	 * @param custNo
	 * @return
	 */
	public TotalDeductInfo countCustDeductionInfos(@Param("custNo")String custNo,@Param("status")DeductInfoStatus status);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 批量完成同一客户下所有待处理抵扣指令
	 * @param custNo
	 */
	public void finlishCustDeductionInfoStatus(@Param("custNo")String custNo);
}
