package com.sfpay.acquirer.gate.b2e.command;

import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.gate.b2e.domain.BalInfo;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.QueryCurBalInfo;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.framework.base.exception.ServiceException;

public class QueryCurBal extends BaseQuery {
	
	private AccountInfo acct;
	
	private BankCode bankCode;
	
	public QueryCurBal(AccountInfo acct){
		super(TradeCodeB2E.QUERY_CUR_BAL);
		this.acct = acct;
		this.bankCode = acct.getBankCode();
	}

	@Override
	public BeanBase assemble(BankProperty property) throws Exception {
		try{
			//设置报文头 
			BeanBase bean = new BeanBase(bankCode, super.tradeCodeB2E);
			/**
			 * 用于结算中心报文序列号
			 * sfh270   2014-12-03
			 */
			bean.setSeqNo(CUID.getSZFSMsgNo());
			bean.setBankProperties(property);
			
			QueryCurBalInfo detail = new QueryCurBalInfo();
			detail.setSerialId(CUID.generateId4B2E(20));
			
			detail.setSendTime(DateUtil.getCDateString(DateUtil.DATA_FORMAT_PATTERN));
			
			BalInfo balInfo = new BalInfo();
			balInfo.setAccNo(acct.getAccountNo());
			balInfo.setAccName(acct.getAccountName());
			balInfo.setCity(acct.getCityName());
			balInfo.setCur(acct.getCcy());
			balInfo.setOpenBranchName(acct.getOpeningBankName());
			balInfo.setProv(acct.getProvinceName());
			//组装分行号
			balInfo.setSubBankName(acct.getSubBankName());
			balInfo.setSubBankNo(acct.getSubBankNo());
			
			if(BankCode.BOC.equals(bankCode)){
				balInfo.setBocBankCode(acct.getOpeningBankNo());
			}
			
			detail.setBalInfo(balInfo);
			bean.setBusDetailBeanBase(detail);
			
			
			return bean;
		}catch(Exception ex){
			logger.error("生成查询余额报文异常:",ex);
			throw new ServiceException(InfoCode.FAILURE, ex);
		}
	}

}
