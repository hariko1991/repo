package com.sfpay.acquirer.task.b2e;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.service.IB2EQueryStatusService;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 
 * 类说明：<br>
 * 工行　查询交易状态
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-5-7
 */
@Service("ICBCQueryStatusReqTask")
public class ICBCQueryStatusReqTask {
	
	@Resource
	private IB2EQueryStatusService service;
	
	private final BankCode bankCode = BankCode.ICBC;
	
	public void execute() throws ServiceException {
			service.proQueryReq(bankCode);
	}
}
