/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service;

import java.util.List;

import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutRespResult;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：<br>
 * 查询银企直联交易状态
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2012-10-29
 */
public interface ICheckTransStatusService {
	
	/**
	 * 方法说明：<br>
	 * 银行+状态，查询批次
	 *
	 * @param bankCode
	 * @param batchStatus
	 * @return
	 */
	public List<BatchInfo> queryBatch(BankCode bankCode,BatchStatus batchStatus) 
			throws ServiceException;
	
	/**
	 * 方法说明：<br>
	 * 处理批次 交易状态
	 *
	 * @param batchInfo
	 * @param bankCode
	 * @param payoutStatusList
	 * @throws ServiceException
	 */
	public List<PayoutInfo> doBatch(BankCode bankCode,BatchInfo batchInfo)
			throws ServiceException;
	
	/**
	 * 方法说明：<br>
	 * 检查批次是否已全部完成
	 *
	 * @param batchCode
	 * @throws ServiceException
	 */
	public void doBatchCheck(String batchCode) throws ServiceException ;
	
	/**
	 * 方法说明：<br>
	 * 更新交易状态,并返回需要发送外部系统的付款信息
	 *
	 * @param batchInfo
	 * @param result
	 * @return
	 * @throws ServiceException
	 */
	public List<PayoutInfo> doPayoutResp(BatchInfo batchInfo,PayoutRespResult result)
			throws ServiceException;
	
	
	/**
	 * 更新交易状态,并返回需要发送外部系统的付款信息
	 * 
	 * @param batchInfo
	 * @param result
	 * @return
	 * @throws ServiceException
	 */
	public List<PayoutInfo> doSinglePayoutResp(BatchInfo batchInfo, PayoutRespResult result) throws ServiceException;
}
