package com.sfpay.acquirer.domain;

import com.sfpay.acquirer.enums.ChannelPayType;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 
 * 
 * 类说明：<br>
 * 付款结果类 基类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-5-13
 */
public class PayoutResult extends BaseEntity{

	private static final long serialVersionUID = 7364001025287307381L;

	//银行返回码/批次查询银行返回码
	private String rtnBankCode;
	
	//银行返回结果描述/批次查询银行返回结果描述
	private String rtnBankMsg;
	
	//银行交易流水号(返回)/批次查询银行交易流水号(返回)
	private String rtnBankSn;
	
	//银行交易流水号(发送)/批次查询银行交易流水号(发送)
	private String reqBankSn;
	
	//sfhq272  单笔交易需要添加交易类型
	private PayoutStatus payoutStatus;
	
	//sfhq272 响应结果区分是批量代付还是单位笔代付
	private ChannelPayType channelPayType;

	public String getRtnBankCode() {
		return rtnBankCode;
	}

	public void setRtnBankCode(String rtnBankCode) {
		this.rtnBankCode = rtnBankCode;
	}

	public String getRtnBankMsg() {
		return rtnBankMsg;
	}

	public void setRtnBankMsg(String rtnBankMsg) {
		this.rtnBankMsg = rtnBankMsg;
	}

	public String getRtnBankSn() {
		return rtnBankSn;
	}

	public void setRtnBankSn(String rtnBankSn) {
		this.rtnBankSn = rtnBankSn;
	}

	public String getReqBankSn() {
		return reqBankSn;
	}

	public void setReqBankSn(String reqBankSn) {
		this.reqBankSn = reqBankSn;
	}

	public PayoutStatus getPayoutStatus() {
		return payoutStatus;
	}

	public void setPayoutStatus(PayoutStatus payoutStatus) {
		this.payoutStatus = payoutStatus;
	}

	public ChannelPayType getChannelPayType() {
		return channelPayType;
	}

	public void setChannelPayType(ChannelPayType channelPayType) {
		this.channelPayType = channelPayType;
	}

}
