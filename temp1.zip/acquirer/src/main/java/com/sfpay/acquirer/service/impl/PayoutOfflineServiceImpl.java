package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.OfflineConfirm;
import com.sfpay.acquirer.domain.PayoutExchange;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutOffline;
import com.sfpay.acquirer.domain.PayoutOfflineQueryParam;
import com.sfpay.acquirer.domain.PayoutQueryRlt;
import com.sfpay.acquirer.enums.ExchangeType;
import com.sfpay.acquirer.enums.OfflineType;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.acquirer.service.IPayoutExchangeService;
import com.sfpay.acquirer.service.IPayoutOfflineService;
import com.sfpay.acquirer.service.SendPayoutResp;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 
 * 
 * 类说明：<br>
 * 线下操作(线下确认、退票)
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-9-7
 */
@Service("payoutOfflineService")
@HessianExporter
public class PayoutOfflineServiceImpl implements IPayoutOfflineService{
	private static Logger logger = LoggerFactory.getLogger(PayoutOfflineServiceImpl.class);
	private static final boolean isDebug = logger.isDebugEnabled();
	
	@Resource
	private IPayoutInfoDao dao;
	
	@Resource
	private SendPayoutResp sendPayout;
	
	@Resource
	private IPayoutExchangeService exchangeService;

	/**
	* 线下确认（线下付款确认、失败确认）
	* @param ls   人工操作对象集合
	* 
	*/
	@Override
	public void doConfirmOffline(List<OfflineConfirm> ls) throws ServiceException {
		//检查参数
		if(ls == null || ls.size() == 0){
			throw new ServiceException(InfoCode.PARAM_INVALID, "param can't be null");
		}
		
		//按操作类型分组,并更新付款信息(未使用批量更新，避免并发操作时下面重复发送业务系统)
		List<String> payoutNos = new ArrayList<String>();
		for(OfflineConfirm confirm : ls){
			String payoutNo = confirm.getPayoutNo();
			String offlineOper = confirm.getOfflineOper();
			PayoutStatus status = null;
			String offlineRemark = null;
			if(confirm.getOfflineType() == null || StringUtils.isEmpty(payoutNo)){
				logger.info("付款编号[付款编号:{}],无人工操作类型或无付款编号，不操作.",confirm.getPayoutNo());
				continue;
			}else if(StringUtils.isEmpty(offlineOper)){
				logger.info("付款编号[付款编号:{}],无操作员，不操作.",confirm.getPayoutNo());
				continue;
			}else if(OfflineType.OFFLINE_SUCCESS.equals(confirm.getOfflineType())){
				status = PayoutStatus.SUCCESS;
				offlineRemark = StringUtils.isEmpty(confirm.getOfflineRemark())?"人工付款确认":confirm.getOfflineRemark();
			}else if(OfflineType.OFFLINE_FAILURE.equals(confirm.getOfflineType())){
				status = PayoutStatus.FAILURE;
				offlineRemark = StringUtils.isEmpty(confirm.getOfflineRemark())?"人工失败确认":confirm.getOfflineRemark();
			}
			//更新线下确认信息
			int cnt = 0;
			try {
				PayoutOffline payoutOffline = new PayoutOffline();
				payoutOffline.setOfflineFlag(YNFlag.Y);
				payoutOffline.setOfflineOper(confirm.getOfflineOper());
				payoutOffline.setOfflineRemark(offlineRemark);
				payoutOffline.setOldOfflineFlag(YNFlag.N);
				payoutOffline.setOldStatus(PayoutStatus.FAILURE);
				payoutOffline.setPayoutNo(payoutNo);
				payoutOffline.setStatus(status);
				cnt = dao.updateOfflineInfo(payoutOffline);
			} catch (Exception e) {
				logger.error("更新人工操作(线下确认)信息[付款编号:"+payoutNo+"]异常",e);
				continue;
			}
			if(isDebug){
				logger.debug("更新人工操作(线下确认)信息记录数:[{}]",cnt);
			}
			//记录操作成功的付款编号，用于下面发送业务系统
			if(cnt > 0){
				payoutNos.add(payoutNo);
			}
		}
		
		//发送业务系统
		List<PayoutInfo> payoutInfos = null;
		if(payoutNos == null || payoutNos.size() == 0){
			logger.debug("无人工操作(线下确认)成功的记录，没有数据发送业务系统");
			throw new ServiceException(InfoCode.FAILURE, "无操作成功的记录");
		}
		try {
			payoutInfos = dao.queryByPayoutNos(payoutNos);
		} catch (Exception e) {
			logger.error("查询付款信息异常",e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE, "查询付款信息异常:"+e);
		}
		try{
			sendPayout.sendOrderResp(payoutInfos,ExchangeType.OFFLINE);
		}catch(Exception ex){
			logger.error("人工操作(线下确认),调用业务系统异常 = ",ex);
		}
	}

	/**
	 * 执行退票
	 * @param payoutNos  付款编号集合
	 * 
	 */
	@Override
	public void doBouncePayout(List<OfflineConfirm> ls) throws ServiceException {
		//检查参数
		if(ls == null || ls.size() == 0){
			throw new ServiceException(InfoCode.PARAM_INVALID, "param can't be null");
		}
		
		List<ExchangeType> exchangeTypes = Arrays.asList(new ExchangeType[]{ExchangeType.SEND_BEFORE, ExchangeType.SEND_AFTER});
		List<String> sendPayoutNos = new ArrayList<String>();//需要发送业务系统的付款编号
		HashMap<String,List<PayoutExchange>> oldEcMap = new HashMap<String,List<PayoutExchange>>();
		for(OfflineConfirm confirm : ls){
			String payoutNo = confirm.getPayoutNo();
			String offlineOper = confirm.getOfflineOper();
			if(StringUtils.isEmpty(payoutNo)){
				continue;
			}else if(StringUtils.isEmpty(offlineOper)){
				logger.info("付款编号[付款编号:{}],无操作员，不操作.",confirm.getPayoutNo());
				continue;
			}
			
			//查询原交互信息
			PayoutExchange info = new PayoutExchange();
			info.setPayoutNo(payoutNo);
			List<PayoutExchange> ecList = exchangeService.queryExchange(info, exchangeTypes);
			if(ecList == null || ecList.size()!=2){
				logger.error("付款信息[付款编号:{}],交互信息不完整,不能执行退票.",payoutNo);
				continue;
			}
			
			//更新退票信息
			int cnt = 0;
			try {
				String offlineRemark = StringUtils.isEmpty(confirm.getOfflineRemark())?"人工操作：退票":confirm.getOfflineRemark();
				
				PayoutOffline payoutOffline = new PayoutOffline();
				payoutOffline.setOfflineFlag(YNFlag.Y);
				payoutOffline.setOfflineOper(confirm.getOfflineOper());
				payoutOffline.setOfflineRemark(offlineRemark);
				payoutOffline.setOldOfflineFlag(YNFlag.N);
				payoutOffline.setOldStatus(PayoutStatus.SUCCESS);
				payoutOffline.setPayoutNo(payoutNo);
				payoutOffline.setStatus(PayoutStatus.FAILURE);
				cnt = dao.updateOfflineInfo(payoutOffline);
			} catch (Exception e) {
				logger.error("更新退票信息[付款编号:"+payoutNo+"]异常",e);
				continue;
			}
			if(isDebug){
				logger.debug("更新退票信息记录数:[{}]",cnt);
			}
			//记录操作成功的付款编号，用于下面发送业务系统
			if(cnt > 0){
				sendPayoutNos.add(payoutNo);
				oldEcMap.put(payoutNo, ecList);
			}
		}
		
		//发送业务系统
		List<PayoutInfo> payoutInfos = null;
		if(sendPayoutNos.size() == 0){
			logger.debug("无退票成功的记录，没有数据发送业务系统");
			throw new ServiceException(InfoCode.FAILURE, "无操作成功的记录");
		}
		try {
			payoutInfos = dao.queryByPayoutNos(sendPayoutNos);
		} catch (Exception e) {
			logger.error("查询付款信息异常",e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE, "查询付款信息异常:"+e);
		}
		try{
			sendPayout.sendBounceResp(payoutInfos, oldEcMap);
		}catch(Exception ex){
			logger.error("退票操作,调用业务系统异常 = ",ex);
		}
	}
	/**
	 * 方法说明：
	 * 更新退票原因
	 * @param rtnBankMsg  银行返回信息
	 * @param id  付款Id
	 */
	@Override
	public void updateBounceReason(String rtnBankMsg, Long id) throws ServiceException {
		try{
			dao.updateBankRtnMsgById(rtnBankMsg, id);
		} catch(Exception ex){
			logger.error("更新退票信息操作,调用业务系统异常 = ",ex);
		}
	}
	/**
	 * 方法说明：
	 * 分页查询未人工操作的付款明细信息
	 * @param param 参数
	 * @param pageNo 当前页
	 * @param pageSize 每页显示数
	 * @return
	 * @throws ServiceException
	 */
	@Override
	public IPage<PayoutQueryRlt> queryPayoutOfflinePage(
			PayoutOfflineQueryParam param, int pageNo, int pageSize)
			throws ServiceException {
		//查询总记录数
		long count = dao.countOfflinePayoutPage(param);
		List<PayoutQueryRlt> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			list = dao.queryOfflinePayoutPage(param, start, end);
		}
		return new Page<PayoutQueryRlt>(list, count, pageNo, pageSize);
	}

}
