/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.domain;

import com.sfpay.acquirer.enums.CollectStatus;
import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-9-2
 */
public class UnkownCollectParam extends BaseEntity {
	
	private static final long serialVersionUID = 5221385618250917493L;

	private String collectNo;
	
	private String rtnBankCode;
	
	private String rtnBankMsg;
	
	private String rtnPayCode;
	
	private CollectStatus status;
	
	/**
	 * 返回值.
	 * 0000: 不需要再轮询;
	 * 0001: 需要继续轮询;
	 * 9999: 调用出错;
	 */
	private String proRtnCode;

	public String getCollectNo() {
		return collectNo;
	}

	public void setCollectNo(String collectNo) {
		this.collectNo = collectNo;
	}

	public String getRtnBankCode() {
		return rtnBankCode;
	}

	public void setRtnBankCode(String rtnBankCode) {
		this.rtnBankCode = rtnBankCode;
	}

	public String getRtnBankMsg() {
		return rtnBankMsg;
	}

	public void setRtnBankMsg(String rtnBankMsg) {
		this.rtnBankMsg = rtnBankMsg;
	}

	public String getRtnPayCode() {
		return rtnPayCode;
	}

	public void setRtnPayCode(String rtnPayCode) {
		this.rtnPayCode = rtnPayCode;
	}

	public CollectStatus getStatus() {
		return status;
	}

	public void setStatus(CollectStatus status) {
		this.status = status;
	}

	public String getProRtnCode() {
		return proRtnCode;
	}

	public void setProRtnCode(String proRtnCode) {
		this.proRtnCode = proRtnCode;
	}
	
}
