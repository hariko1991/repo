package com.sfpay.acquirer.gate.b2e.command;

import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutResult;
import com.sfpay.acquirer.domain.SzfsSinglePayoutReqResult;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.acquirer.gate.b2e.BaseCommand;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.SinglePayInfo;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;

/**
 * @author sfhq272
 * 单笔支付
 */
public class SinglePayTransfer extends BaseCommand {

	private PayoutInfo info;
	private BankCode bankCode;
	
	public SinglePayTransfer(){
		super(TradeCodeB2E.SZFS_SINGLEPAY);
	}

	public SinglePayTransfer(PayoutInfo info, BankCode bankCode){
		super(TradeCodeB2E.SZFS_SINGLEPAY);
		this.info = info;
		this.bankCode = bankCode;
	}

	
	@Override
	protected BeanBase assemble(BankProperty property) throws Exception {
		try{
			CurrencyType ccy = null;
			
			if(info.getCcy() == null){
				//默认为人民币
				ccy = CurrencyType.RMB;
			}else{
				ccy = info.getCcy();
			}
			//设置报文头 
			BeanBase bean = new BeanBase(bankCode, super.tradeCodeB2E);
			/**
			 * 用于结算中心报文序列号
			 */
			bean.setSeqNo(CUID.getSZFSMsgNo());
			//测试时间
			if(BankCode.ICBC.equals(bankCode)){
				String testDate = Property.getProperty("B2E_TEST_ICBC_DATE");
				if(testDate != null && !"".equals(testDate.trim())){
					property.put("testDate", testDate);
				}
			}
			bean.setBankProperties(property);//银行参数
			
			
			SinglePayInfo detail = new SinglePayInfo();
			detail.setPayFlag("1");//单笔实时代付
			//设置共用参数
			detail.setSubSerialId(info.getReqBankSn());
			detail.setPayerAccNo(info.getPayerAcctNo());
			detail.setPayerAccName(info.getPayerAcctName());
			detail.setSendTime(DateUtil.getCDateString(DateUtil.DATA_FORMAT_PATTERN));
			detail.setPayeeUnionBankCode(info.getPayeeUnionBankCode());//收款方联行号
			detail.setPayeeAccName(info.getPayeeAcctName());
			detail.setPayeeAccNo(info.getPayeeAcctNo());
			detail.setAmt(info.getAmt());
			detail.setBatchCode(info.getBatchCode());
			detail.setCur(ccy);
			//增加代理支付
			detail.setAgentFlag(info.getAgentFlag());
			if(YNFlag.Y.equals(info.getAgentFlag())){
				detail.setAgentName(info.getAgentName());
				detail.setAgentAcctNo(info.getAgentAcctNo());
			}
			
			bean.setBusDetailBeanBase(detail);
			
			//生成请求报文信息
			return bean;
		}catch(Exception ex){
			logger.error("单笔代付[请求号:" + info.getReqBankSn() + "] 生成查询结果报文异常:",ex);
			throw new ServiceException(InfoCode.FAILURE, ex);
		}
	}



	@SuppressWarnings("unchecked")
	@Override
	protected PayoutResult parseMsg(
			com.sfpay.acquirer.gate.b2e.domain.BeanBase respBean)
			throws Exception {
		//2050607 避免重复代码
		return new SzfsSinglePayoutReqResult(respBean);
	}

}
