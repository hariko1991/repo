/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.paycenter.PaymentTranInfoParam;
import com.sfpay.acquirer.domain.paycenter.PayoutReqInfo;
import com.sfpay.acquirer.domain.paycenter.PayoutReqInfoParam;
import com.sfpay.acquirer.domain.paycenter.PayoutReqInfoView;
import com.sfpay.acquirer.enums.PayCenterPayStatus;

/**
 * 类说明：<br>
 * 付款中心付款信息表数据层业务处理类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 400928 向鹏
 * 
 * CreateDate: 2014-2-24
 */
public interface IPayBusinessDao {
	
	/**
	 * 方法说明：<br>
	 * 添加
	 *
	 * @param payoutInfo
	 */
	public void addPayCenterPayInfo(PayoutReqInfo info);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据商户号，外部交易单号查询付款请求记录
	 * @param merNo
	 * @param tradeNo
	 * @return
	 */
	public PayoutReqInfo queryPayoutReqInfoByTradeNo(@Param("merNo")String merNo,@Param("tradeNo")String tradeNo);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 统计付款中心支付信息
	 * @param param
	 * @return
	 */
	public Long countPayoutReqInfo(@Param("param")PayoutReqInfoParam param);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 分面查询付款中心支付记录
	 * @param param
	 * @param start
	 * @param end
	 * @return
	 */
	public List<PayoutReqInfoView>queryPayoutReqInfoByPage(@Param("param")PayoutReqInfoParam param,@Param("start")int start,@Param("end")int end);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据ID查询付款信息
	 * @param id
	 * @return
	 */
	public PayoutReqInfoView queryPayoutReqInfoById(@Param("id")Long id);
	
	
	/**
	 * 
	 * 方法说明：<br>
	 * 检查创建人,第一次审批，第二次审批不能为同一个人
	 * @param oper
	 * @return
	 */
	public Long countCheckOperator(@Param("oper")String oper,@Param("id")Long id);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 一次审批
	 * @param oper
	 * @param checkDesc
	 * @param id
	 */
	public void approvePayInfoByFir(@Param("oper")String oper,@Param("checkDesc")String checkDesc,@Param("id")Long id,@Param("status")PayCenterPayStatus status);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 二次审批
	 * @param oper
	 * @param checkDesc
	 * @param id
	 */
	public void approvePayInfoBySec(@Param("oper")String oper,@Param("checkDesc")String checkDesc,@Param("id")Long id,@Param("status")PayCenterPayStatus status);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 更新付款结果状态
	 * @param status
	 * @param remark
	 * @param payEndTime
	 */
	public void updateCheckPayStatus(@Param("id")Long id,@Param("status")PayCenterPayStatus status,@Param("bankRetMsg")String bankRetMsg,@Param("payEndTime")Date payEndTime,@Param("oldStatus")PayCenterPayStatus oldStatus);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 更新付款结果状态
	 * @param status
	 * @param remark
	 * @param payEndTime
	 */
	public void updateStatus(@Param("id")Long id,@Param("status")PayCenterPayStatus status,@Param("bankRetMsg")String bankRetMsg,@Param("payEndTime")Date payEndTime);
	/**
	 * 
	 * 方法说明：<br>
	 * 根据付款业务编号查询付款中心付款信息
	 * @param businessNo
	 * @return
	 */
	public PayoutReqInfo queryPayInfoByBusinessNo(@Param("businessNo")String businessNo);
	
	
	/**
	 * 
	 * 方法说明：<br>
	 * 统计收款方户名，账号，金额相同的记录笔数，进行可能重复付款的提示性判断
	 * @param param
	 * @return
	 */
	public Long countDuplicate(@Param("acctNo")String acctNo,@Param("acctName")String acctName,@Param("amt")Long amt,@Param("serachDayCnt")Long serachDayCnt);
	
	
	/**
	 * 
	 * 方法说明：<br>
	 * 统计付款记录信息总数
	 * @author sfhq270 周丽佩
	 * @date 2014-09-29
	 * @param param
	 * @return
	 */
	public Long countPaymentTran(@Param("param")PaymentTranInfoParam param);
	
	
	/**
	 * 付款记录查询
	 * @author sfhq270 周丽佩
	 * @date 2014-09-29
	 * @param param
	 * @param start
	 * @param end
	 * @return
	 */
	public List<PaymentTranInfoParam> queryPaymentTranListByPage(@Param("param")PaymentTranInfoParam param,@Param("start")int start,@Param("end")int end);

}
