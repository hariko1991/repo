package com.sfpay.acquirer.task.thread;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import com.sfpay.acquirer.common.DateUtil;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.IInsertAll;
import com.sfpay.acquirer.InsertAllExecutor;
import com.sfpay.acquirer.common.CurrencyUtil;
import com.sfpay.acquirer.common.rb.AbstractBankFileThread;
import com.sfpay.acquirer.dao.rb.IBankReconFileDao;
import com.sfpay.acquirer.domain.rb.szfs.BankReconFile;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.MsgType;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;

/**
 * 结算中心对账线程
 * 针对结算中心的REC文件
 * @author sfhq272
 */
@Service
public class SZFSRECThread extends AbstractBankFileThread<BankReconFile> {
	private static final Logger logger = LoggerFactory.getLogger(SZFSRECThread.class);

	@Resource
	protected IBankReconFileDao bankReconFiledao;
	

	@Override
	protected void processor(String tradeDateStr, Date tradeDate, Date curDate) {
		String logStr = "";
		try{
			logger.info("第一步：结算中心和银企对账[{}],导入外部临时表[{}].", tradeDateStr, localFullFileName);
			try{
				importFileData();
			}catch(Exception ex){
				logStr = "结算中心和银企对账["+tradeDateStr+"],导入外部临时表异常["+localFullFileName+"].";
				logger.error(logStr,ex);
				reconLogService.insertReconLog("ERROR", logStr);
				throw new ServiceException(logStr+ex);
			}

			logger.info("第二步：结算中心和银企对账[{}],调用对账存储过程",tradeDateStr);
			try{
				long start = System.currentTimeMillis();
				bankReconFiledao.importSZFSReconFile(tradeDate, curDate);
				long cost = System.currentTimeMillis()-start;
				logger.info("存储过程执行花费时间：{} ms",cost);
			}catch(Exception ex){
				logStr = "银企付款对账["+tradeDateStr+"],调用对账存储过程异常.";
				logger.error(logStr,ex);
				reconLogService.insertReconLog("ERROR", logStr);
				throw new ServiceException(logStr+ex);
			}

		}finally{
			//记录结束日志
			logStr = "结算中心和银企对账["+tradeDateStr+"],执行结束.";
			logger.info(logStr);
			reconLogService.insertReconLog("INFO", logStr);
		}
	}

	@Override
	public BankReconFile converContent2Object(String content)
			throws ServiceException {

		content = content + " ";
		String[] contents = content.split("\\,");
		if(29 != contents.length){
			throw new ServiceException("REC文件内容格式有误,信息长度"+contents.length);
		}

		BankReconFile temp = new BankReconFile();
		String reqBankSn = "";
		if(contents[1].equals(MsgType.BATCHPAY.name())){
			reqBankSn = contents[5]; 
			temp.setOutid(contents[3]);
			temp.setLstOutid(contents[5]);
		}else if(contents[1].equals(MsgType.SINGLEPAY.name())){
			StringBuffer sb = new StringBuffer(Property.getProperty("SZFS_CORPNO")).append(Property.getProperty("SZFS_SINGLEPAY_BUSINESSCODE"));
			int sbLength = sb.length();
			reqBankSn = contents[3].substring(sbLength);
			temp.setOutid(contents[3]);
		}
		temp.setReqBankSn(reqBankSn);
		temp.setRcvDate(DateUtil.getDateFormatStr(contents[0].trim(), DateUtil.DATA_FORMAT_PATTERN));
		temp.setCheckDate(DateUtil.getDateFormatStr(headMap.get("checkDate"), DateUtil.DATA_FORMAT_PATTERN_2));
		temp.setMsgType(contents[1]);
		temp.setLstNo(contents[4]);
		temp.setTransType(contents[6]);
		temp.setTransNo(contents[9]);
		temp.setTransCode(contents[10]);
		temp.setFeeItem(contents[11]);
		temp.setCcy(contents[13]);
		temp.setAmt(CurrencyUtil.yuan2Fen(contents[14]));
		temp.setActAmt(CurrencyUtil.yuan2Fen(contents[15]));
		temp.setStatus(contents[16]);
		temp.setRetcode(contents[17]);
		temp.setReturnFlag(contents[18]);
		temp.setReverseFlag(contents[19]);
		temp.setClearDate(DateUtil.getDateFormatStr(contents[20].trim(), DateUtil.DATA_FORMAT_PATTERN_2));
		temp.setClearNo(contents[21]);
		temp.setPayerBankNo(contents[22]);
		temp.setPayerAcctNo(contents[23]);
		temp.setPayerAcctName(contents[24]);
		temp.setPayeeBankNo(contents[25]);
		temp.setPayeeAcctNo(contents[26]);
		temp.setPayeeAcctName(contents[27]);
		temp.setPayChannelCode(BankCode.SZFS);
		temp.setRemark(contents[28]);
		temp.setChangeReconFlag("0");
		temp.setLstOutid(contents[3]);
		temp.setOutid(contents[3]);

		logger.info("content convert to BankPayoutReconOuterTemp：{}", temp);
		return temp;
	}


	/**
	 * 方法说明：<br>
	 * 导入对账文件数据
	 *
	 * @throws ServiceException
	 */
	private void importFileData() throws ServiceException {
		if(null == localFullFileName || "".equals(localFullFileName)){
			logger.warn("无效的文件名!");
			throw new ServiceException("REC文件无效,请确认是否下载完整文件!");
		}

		List<BankReconFile> temp = readFile(true,"GBK");

		//导入数据库
		logger.info("[{}]交易总数:[{}]",localFullFileName,temp.size());

		try {
			InsertAllExecutor.insert(temp, new IInsertAll<BankReconFile>() {
				public void execute(List<BankReconFile> sbuLs) throws Exception {
					bankReconFiledao.addSZFSReconList(sbuLs);//导入数据库
				}
			});
		} catch (Exception e) {
			logger.error("REC导入外部数据异常",e);
			throw new ServiceException("REC导入外部数据异常:"+e);
		}
	}

	@Override
	public void initLocalFullName(String tradeDateStr) {
		try{
			StringBuffer tempName = new StringBuffer(Property.getProperty("SZFS_CHANNEL")).append("_").
					append(Property.getProperty("SZFS_CORPNO")).append("_").append(tradeDateStr).append(".").
					append(Property.getProperty("SZFS_REC_SUFFIX"));
			fileName = tempName.toString();
		} catch (Exception e) {
			logger.error("初始化文件全名错误"+fileName,e);
			throw new ServiceException("初始化文件全名错误:"+fileName+e);
		}
	}

	@Override
	public void converHead2Map(String head)
			throws ServiceException {
		String[] heads = head.split("\\,");
		if(6 != heads.length){
			throw new ServiceException("REC文件["+localFullFileName+"]的头不符合规则");
		}
		String checkDate = heads[1].trim();
		headMap.put("checkDate", checkDate);
	}

	@Override
	public String initLocalFullPath(String localPath, String tradeDateStr) {
		return (localPath.endsWith("/") ? localPath : localPath+"/") + tradeDateStr + "/RECON/";
	}


}
