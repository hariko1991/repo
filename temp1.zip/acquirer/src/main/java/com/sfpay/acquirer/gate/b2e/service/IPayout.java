/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.gate.b2e.service;

import java.util.List;

import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutReqResult;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.PayoutSendStatus;
import com.sfpay.acquirer.gate.IAcqBiz;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;

/**
 * 
 * 
 * 类说明：<br>
 * B2E付款指令请求、响应接口类.
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-4-27
 */
public interface IPayout extends IAcqBiz {
	
	/**
	 * 方法说明：<br>
	 * 组装请求报文.<br>
	 * TODO 改为完整的名称doRequest
	 * @return
	 * @throws Exception
	 */
	public PayoutSendStatus doReq(BatchInfo bi, List<PayoutInfo> info, BankProperty property, BankCode bankCode, BatchRuleInfo rule) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 解析响应报文并封装成具体的响应Bean.
	 * TODO 改为完整的名称doRequest
	 * @return
	 * @throws Exception
	 */
	public PayoutReqResult doResp(BeanBase respBean) throws Exception;
	
}
