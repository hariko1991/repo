package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.ReconCollectRlt;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.FundWay;



/**
 * 类说明：
 * 针对对账后产生的丢单和掉单两种情况，进行相应的处理 
 * 
 * <p/>
 * 详细描述：
 * @author 349508 韦健
 *   
 * CreateDate: 2012-8-16  
 * 
 */
public interface ICheckReconInfoDao {
	
	/**
	 * 在对账以后，查询所有丢单和掉单的记录
	 * @param date
	 * @return
	 */
	public List<ReconCollectRlt> findReconLose(@Param("bankCode") BankCode bankCode ,@Param("channelCode") ChannelCode channelCode, @Param("nowDate") String nowDate);
	
    /**
     * 根据单笔查询的反回结果判断是否是丢单情况，以此更改对账结果表状态为时间性差异
     * @param id
     */
	public void updateReconCollectRltState(@Param("id") Long id);
	
	/**
	 * 根据单笔查询的反回结果判断是否是掉单情况，如果是则更新收单基础表状态为成功（如果找不到这个订单，这里不做处理）
	 * @param reqBankSn
	 * @param bankCode
	 * @param channelCode
	 * @param fundWay
	 */
	public void updateCollectInfoState(@Param("reqBankSn") String reqBankSn,@Param("bankCode") BankCode bankCode,@Param("channelCode") ChannelCode channelCode,@Param("fundWay") FundWay fundWay );
     
	/**
	 * 再把收单表中相应的记录更新到对账结果表中
	 * @param bankCode
	 * @param channelCode
	 * @param fundWay
	 * @param reqBankSn
	 */
	public void updateReconCollectRltFromCollectInfo(@Param("id") Long id,@Param("bankCode") BankCode bankCode,@Param("channelCode") ChannelCode channelCode,@Param("fundWay")FundWay fundWay,@Param("reqBankSn") String reqBankSn);
	
	}
