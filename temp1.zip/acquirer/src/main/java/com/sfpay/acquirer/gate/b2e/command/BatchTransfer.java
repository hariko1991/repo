package com.sfpay.acquirer.gate.b2e.command;

import java.util.ArrayList;
import java.util.List;

import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchPayoutReqResult;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutResult;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.RemitMethod;
import com.sfpay.acquirer.gate.b2e.BaseCommand;
import com.sfpay.acquirer.gate.b2e.domain.BatchTransferInfo;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.TransferSubInfo;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;

/**
 * 
 * 
 * 类说明：<br>
 * 批量支付（对公）
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-5-6
 */
public class BatchTransfer extends BaseCommand {

	private BatchInfo bi;
	private List<PayoutInfo> pis;
	private BankCode bankCode;
	private BatchRuleInfo br;
	
	public BatchTransfer(){
		super(TradeCodeB2E.BATCH_TRANSFER);
	}

	public BatchTransfer(BatchInfo bi,List<PayoutInfo> pis,BankCode bankCode,BatchRuleInfo br){
		super(TradeCodeB2E.BATCH_TRANSFER);
		this.bi = bi;
		this.pis = pis;
		this.bankCode = bankCode;
		this.br=br;
	}

	
	
	@Override
	protected BeanBase assemble(BankProperty property) throws Exception {
		try{
			PayoutInfo payInfo = pis.get(0);
			CurrencyType ccy = null;
			
			if(payInfo.getCcy() == null){
				//默认为人民币
				ccy = CurrencyType.RMB;
			}else{
				ccy = payInfo.getCcy();
			}
			//设置报文头 
			BeanBase baseData = new BeanBase(bankCode, super.tradeCodeB2E);
			/**
			 * 用于结算中心报文序列号
			 * sfh270   2014-12-03
			 */
			baseData.setSeqNo(CUID.getSZFSMsgNo());
			//测试时间
			if(BankCode.ICBC.equals(bankCode)){
				String testDate = Property.getProperty("B2E_TEST_ICBC_DATE");
				if(testDate != null && !"".equals(testDate.trim())){
					property.put("testDate", testDate);
				}
			}
			baseData.setBankProperties(property);//银行参数
			
			
			BatchTransferInfo transInfo = new BatchTransferInfo();
			//设置共用参数
			transInfo.setSerialId(bi.getReqBankSn());
			transInfo.setCheckStr("");
			transInfo.setCur(ccy);
			transInfo.setPayerAccNo(payInfo.getPayerAcctNo());
			transInfo.setPayerAccName(payInfo.getPayerAcctName());
			transInfo.setPayerProv(payInfo.getPayerAcctProvinceName());
			transInfo.setPayerCity(payInfo.getPayerAcctCityName());
			transInfo.setPayerOpenBranchName(payInfo.getPayerBranchName());
			transInfo.setSendTime(DateUtil.getCDateString(DateUtil.DATA_FORMAT_PATTERN));
			if(BankCode.BOC.equals(bankCode)){
				transInfo.setBocBankCode(payInfo.getPayerBranchCode());
			}
			transInfo.setBatchCode(payInfo.getBatchCode());
			List<TransferSubInfo> subInfoList = new ArrayList<TransferSubInfo>();
			//设置子记录信息
			int totalCount = 0;
			long totalAmt = 0l;
			for(PayoutInfo pi : pis){
				TransferSubInfo transferSubInfo = new TransferSubInfo();
				
				transferSubInfo.setSubSerialId(pi.getReqBankSn());
				transferSubInfo.setAmt(pi.getAmt());
				transferSubInfo.setPayeeAccName(pi.getPayeeAcctName());
				transferSubInfo.setPayeeAccNo(pi.getPayeeAcctNo());
				transferSubInfo.setPayeeProv(pi.getPayeeAcctProvinceName());
				transferSubInfo.setPayeeCity(pi.getPayeeAcctCityName());
				transferSubInfo.setPayeeOpenBranchName(pi.getPayeeBranchName());
				//增加收款方联行号 sfhq270 2014-12-01
				transferSubInfo.setPayeeUnionBankCode(pi.getPayeeUnionBankCode());
				transferSubInfo.setPayeeUnionBankName(pi.getPayeeUnionBankName());
				transferSubInfo.setPayeeBankNo(pi.getPayeeBranchCode());
				transferSubInfo.setPostscript(pi.getSummary());//附言
				transferSubInfo.setRemark(pi.getSummary());//备注
				transferSubInfo.setSummary(pi.getSummary());//摘要
				transferSubInfo.setUsefor(pi.getUseType());
				transferSubInfo.setSubBankNo(pi.getSubBankNo());//分行号
				RemitMethod remitMethod =pi.getRemitMethod() ;
				if("Y".equals(br.getSuperInterFlag())){
					remitMethod=RemitMethod.SUPERINTER;
				}
				switch (remitMethod) {
				case SUPERINTER:
					transferSubInfo.setUrgencyFlag("3");
					break;
				case FAST:
					transferSubInfo.setUrgencyFlag("1");
					break;
				default:
					transferSubInfo.setUrgencyFlag("2");
				}
								
				String org = pi.getPayeeOrgCode().name();
				String acctOrg = pi.getPayerOrgCode().name();
				if(!acctOrg.equals(org)){//跨行
					transferSubInfo.setDifBankFlag("1");
				}else{//同行
					transferSubInfo.setDifBankFlag("0");
				}				
				
				//计算总数和总金额
				totalAmt += pi.getAmt();
				totalCount += 1;
				
				subInfoList.add(transferSubInfo);
			}
			
			transInfo.setTotalCount(totalCount);
			transInfo.setTotalAmt(totalAmt);
			baseData.setBusDetailBeanBase(transInfo);
			transInfo.setSubInfoList(subInfoList);
			
			return baseData;
		}catch(Exception ex){
			logger.error("批次[请求流水号:"+bi.getReqBankSn()+"]生成报文异常:",ex);
			throw new ServiceException(InfoCode.FAILURE, ex);
		}
	}



	@SuppressWarnings("unchecked")
	@Override
	protected PayoutResult parseMsg(
			com.sfpay.acquirer.gate.b2e.domain.BeanBase respBean)
			throws Exception {
		//2050607 避免重复代码
		return new BatchPayoutReqResult(respBean);
	}

}
