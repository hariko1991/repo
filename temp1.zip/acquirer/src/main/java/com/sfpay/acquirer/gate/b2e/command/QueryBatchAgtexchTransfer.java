package com.sfpay.acquirer.gate.b2e.command;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutRespResult;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.CmdStatus;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.gate.b2e.BaseCommand;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.QueryAgtexchTransferInfo;
import com.sfpay.acquirer.gate.b2e.domain.QueryTransferSubInfo;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 
 * 类说明：<br>
 * 查询支付结果（对私）
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-5-6
 */
public class QueryBatchAgtexchTransfer extends BaseCommand {
	
	private BatchInfo bi;
	private List<PayoutInfo> pis;
	private BankCode bankCode;
	
	public QueryBatchAgtexchTransfer(){
		super(TradeCodeB2E.QUERY_BATCH_AGENT_TRANSFER);
	}
	
	public QueryBatchAgtexchTransfer(BatchInfo bi,List<PayoutInfo> pis,BankCode bankCode){
		super(TradeCodeB2E.QUERY_BATCH_AGENT_TRANSFER);
		this.bi = bi;
		this.pis = pis;
		this.bankCode = bankCode;
	}

	@Override
	protected BeanBase assemble(BankProperty property) throws Exception {
		try{
			PayoutInfo info = pis.get(0);
			
			//设置报文头
			BeanBase bean = new BeanBase(bankCode, super.tradeCodeB2E);
			/**
			 * 用于结算中心报文序列号
			 * sfh270   2014-12-03
			 */
			bean.setSeqNo(CUID.getSZFSMsgNo());
			bean.setBankProperties(property);
			
			
			QueryAgtexchTransferInfo  detail = new QueryAgtexchTransferInfo();
			detail.setMainSerialId(bi.getReqBankSn());
			detail.setSerialId(CUID.getRandomCode(20));
			detail.setPayerAccNo(info.getPayerAcctNo());
			detail.setPayerCity(info.getPayerAcctCityName());
			detail.setPayerAccName(info.getPayerAcctName());
			detail.setPayerOpenBranchName(info.getPayerBranchName());
			detail.setSendTime(DateUtil.getCDateString(DateUtil.DATA_FORMAT_PATTERN));
			detail.setPayerProv(info.getPayerAcctProvince());
			Date queryDate = bi.getPayBatchDate() == null?bi.getSecCheckDate():bi.getPayBatchDate();
			detail.setTradeTime(DateUtil.getDateString(queryDate,DateUtil.DATA_FORMAT_PATTERN_2));
			List<QueryTransferSubInfo> subInfoList = new ArrayList<QueryTransferSubInfo>();
			//设置查询子信息
			long totalAmt = 0l;
			int totalNum = 0;
			for(PayoutInfo pi : pis){
				QueryTransferSubInfo querySubInfo = new QueryTransferSubInfo();
				querySubInfo.setAmt(pi.getAmt());
				querySubInfo.setSubSerialId(pi.getReqBankSn());
				querySubInfo.setPayeeAccNo(pi.getPayeeAcctNo());
				
				totalNum += 1;
				totalAmt += pi.getAmt();
				subInfoList.add(querySubInfo);
			}
			
			detail.setSubInfo(subInfoList);
			detail.setTotalCount(totalNum);
			detail.setTotalAmt(totalAmt);
			bean.setBusDetailBeanBase(detail);
			
			
			return bean;
		}catch(Exception ex){
			logger.error("批次[批次号:"+bi.getBatchCode()+"]生成查询批量对私支付结果报文异常:",ex);
			throw new ServiceException(InfoCode.FAILURE, ex);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	protected PayoutRespResult parseMsg(BeanBase respBean)
			throws Exception {
		PayoutRespResult resp = new PayoutRespResult();
		
		QueryAgtexchTransferInfo agtInfo = (QueryAgtexchTransferInfo)respBean.getBusDetailBeanBase();
		//转换批次信息
		resp.setReqBankSn("");
		resp.setBatchReqBankSn(agtInfo.getMainSerialId());
		resp.setRtnBankCode(agtInfo.getBankRetCode());
		if(agtInfo.getBankRetMsg() == null || "".equals(agtInfo.getBankRetMsg())){
			resp.setRtnBankMsg(agtInfo.getRetMsg());
		}else {
			resp.setRtnBankMsg(agtInfo.getBankRetMsg());
		}
		resp.setCmdStatus(CmdStatus.convertToCmdStatus(agtInfo.getRetCode()));
		resp.setRtnBankSn("");
		resp.setRemark(agtInfo.getRetMsg());
		
		//转换付款信息
		List<PayoutInfo> payoutDetail = null;
		List<QueryTransferSubInfo> subInfoList = agtInfo.getSubInfo();
		if(subInfoList != null){
			payoutDetail = new ArrayList<PayoutInfo>();
			for(QueryTransferSubInfo subInfo : subInfoList){
				PayoutInfo info = new PayoutInfo();
				
				info.setAmt(subInfo.getAmt());
				info.setRtnBankCode(subInfo.getBankRetCode());
				info.setReqBankSn(subInfo.getSubSerialId());
				info.setPayeeAcctNo(subInfo.getPayeeAccNo());
				info.setRtnBankMsg(subInfo.getBankRetMsg());
				info.setStatus(PayoutStatus.convertToPayoutStatus(subInfo.getCmdStat()));
				
				payoutDetail.add(info);
			}
		}
		resp.setPayoutDetail(payoutDetail);
		
		return resp;
	}


}
