package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.PayoutForCheckBatchQueryParam;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.acquirer.enums.PayoutSendStatus;

/**
 * 类说明：批次信息
 *  
 * 
 * <p>
 * 详细描述：
 *   
 * 
 * @author 308276 彭福明
 * @author 329202 符瑜鑫(Ricky Fu)
 *   
 * CreateDate: 2012-3-15
 */
public interface IBatchInfoDao {
	
	/**
	 * 方法说明：根据批次编号查询批次信息
	 *
	 * @param batchCode
	 * @return
	 */
	public BatchInfo queryByBatchCode(@Param("batchCode")String batchCode);
	
	
	/**
	 * 方法说明：根据请求流水号查询批次信息(包含规则、账号)
	 *
	 * @param batchCode
	 * @return
	 */
	public BatchInfo queryByReqBankSn(@Param("reqBankSn")String reqBankSn);
	
	/**
	 * 方法说明：根据请求流水号查询批次信息(不包含规则、账号)
	 *
	 * @param batchCode
	 * @return
	 */
	public BatchInfo queryBiByReqBankSn(@Param("reqBankSn")String reqBankSn);
	
	/**
	 * 方法说明：<br>
	 * 检查复核人
	 */
	public Long checkOperator(@Param("operator") String operator, @Param("batchNo") String batchNo, @Param("status") BatchStatus status);
	
	/**
	 * 方法说明：<br>
	 * 修改复核信息
	 *
	 * @param batchInfo
	 */
	public int updateByBatchCode(@Param("batchInfo")BatchInfo batchInfo,@Param("oldStatus")BatchStatus oldStatus);
	
	/**
	 * 方法说明：<br>
	 * 银行返回后修改批次信息
	 *
	 * @param batchInfo
	 */
	public int updateBankRnt(BatchInfo batchInfo);
	
	/**
	 * 方法说明：<br>
	 * 更新银行返回信息
	 * sfhq270  2014-12-26
	 *
	 * @param batchInfo
	 */
	public void updateBankRtnInfo (BatchInfo batchInfo);
	/**
	 * 方法说明：<br>
	 * 添加
	 *
	 * @param batchInfo
	 */
	public void saveBatchInfo(BatchInfo batchInfo);
	
	/**
	 * 方法说明：<br>
	 * 按银行+状态查询批次
	 * @return
	 */
	public List<BatchInfo> queryBatchByStatus(@Param("bank") BankCode bank, @Param("status") BatchStatus status);
	
	/**
	 * 方法说明：<br>
	 * 按银行+状态查询批次
	 * 
	 * @return
	 */
	public List<BatchInfo> queryBatchByStatusNew(@Param("bank") BankCode bank);

	/**
	 * 方法说明：<br>
	 * 更新状态DONE
	 *
	 * @param batchCode
	 * @param status
	 */
	public int updateFinishStatus(@Param("batchCode")String batchCode,@Param("status")BatchStatus status);
	
	/**
	 * 方法说明：<br>
	 * 查询生成批次前的付款信息
	 *
	 * @param param
	 * @return
	 */
	public List<BatchInfo> queryPayoutForCheckBatch(@Param("param")PayoutForCheckBatchQueryParam param, @Param("start") int start, @Param("end") int end);
	
	/**
	 * 方法说明：<br>
	 * 查询生成批次前的付款信息 总条数
	 *
	 * @param param
	 * @return
	 */
	public long countPayoutForCheckBatch(@Param("param")PayoutForCheckBatchQueryParam param);
	
	/**
	 * 方法说明：<br>
	 * 查询自动生成批次前的付款信息 总条数
	 *
	 * @param param
	 * @return
	 */
	public long countPayoutForAutoCheckBatch(@Param("param")PayoutForCheckBatchQueryParam param);
	
	/**
	 * 方法说明：<br>
	 * 查询自动生成批次前的付款信息
	 *
	 * @param param
	 * @return
	 */
	public List<BatchInfo> queryPayoutForAutoCheckBatch(@Param("param")PayoutForCheckBatchQueryParam param, @Param("start") int start, @Param("end") int end);
	
	
	/**
	 * 方法说明：<br>
	 * 更新轮询次数
	 *
	 * @param cycleCnt
	 * @param batchCode
	 */
//	public void updateCycleCnt(@Param("cycleCnt")long cycleCnt,@Param("batchCode")String batchCode);
	
	
	/**
	 * 方法说明：<br>
	 * 根据状态查询批次信息
	 *
	 * @param map
	 * @return
	 */
	public List<BatchInfo> queryBatchByStatus1(@Param("statusList")List<BatchStatus> statusList);
	
		/**
	 * 方法说明：<br>
	 * 更新发送状态和次数
	 *
	 * @param sendStatus
	 * @param sendCnt
	 * @param batchCode
	 * @return
	 */
	public int updateSend(@Param("sendStatus")PayoutSendStatus sendStatus,@Param("oldSendStatus")PayoutSendStatus oldSendStatus,@Param("batchCode")String batchCode,@Param("remark")String remark);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 更新批次总批次号 用以支持批量付复支付
	 * @param totalBatchCode
	 * @return
	 */
	public int updateTotalBatchCode(@Param("totalBatchCode")String totalBatchCode,@Param("subBatchCode")List<String> subBatchCode);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据总批次号查询各批次号信息
	 * @param totalBatchCode
	 * @return
	 */
	public List<String> queryBatchCodeByTotalBatchCode(@Param("totalBatchCode")String totalBatchCode);
	
	/**
	 * 方法说明：<br>
	 * 更新总笔数及总金额
	 *
	 * @param totalCnt
	 * @param totalAmt
	 * @param batchCode
	 * @param oldStatus
	 * @return
	 */
	public int updateTotal(@Param("batchInfo")BatchInfo batchInfo,@Param("oldStatus")BatchStatus oldStatus);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 统计总批次中各子批次状态
	 * @param totalBatchCode
	 * @return
	 */
	public long countStatusByTotalBatchCode(@Param("totalBatchCode")String totalBatchCode,@Param("status")BatchStatus status);
	
	/**
	 * 方法说明：<br>
	 * 修改冻结/解冻信息
	 *
	 * @param payoutInfo
	 * @return
	 */
	public int updateFreeze(@Param("bNos")List<String> bNos,@Param("remark")String remark) throws Exception;
	
	//根据payoutInfo的reqBankSn得到BatchInfo  sfhq272  20150302
	public BatchInfo queryBatchByPayoutReqBankSn(@Param("reqBankSn")String reqBankSn);
	
	/**
	 * 获取操作类型(手工、自动)
	 * 
	 * @param batchCode
	 * @return
	 */
	public String getOperatorType(@Param("batchCode")String batchCode);


	public int updateByBatchCodeAuto(@Param("batchInfo")BatchInfo batchInfo, @Param("oldStatus")BatchStatus oldStatus);

	/**
	 * 更新批次发送状态
	 * @param nosend
	 * @param wait
	 * @param batchCode
	 * @return
	 */
	public int updateSendForNOSEND(@Param("batchCode")String batchCode)throws Exception;


}
