/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.AcquirerHelper;
import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.domain.Account;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.CollectInfo;
import com.sfpay.acquirer.domain.InCollectInfo;
import com.sfpay.acquirer.domain.PaymentParam;
import com.sfpay.acquirer.domain.PaymentReq;
import com.sfpay.acquirer.domain.PaymentResp;
import com.sfpay.acquirer.domain.ProcessRlt;
import com.sfpay.acquirer.domain.SFPayBank;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.ChargeType;
import com.sfpay.acquirer.enums.CollectStatus;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.acquirer.enums.SystemSource;
import com.sfpay.acquirer.service.ICollectInfoService;
import com.sfpay.acquirer.service.ISFPayBankService;
import com.sfpay.coreplatform.order.service.IBankPayService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：收单信息接口实现类
 * 
 * <p>
 * 详细描述：
 *   
 * @author 271762
 * @author 329202 符瑜鑫(Ricky Fu)
 *   
 * CreateDate: 2012-3-14
 */
@Deprecated
@Service("collectInfoService")
@HessianExporter
public class CollectInfoServiceImpl extends BaseCollcetInfoImpl implements ICollectInfoService {
	private static final Map<SystemSource, Boolean> SFP_MAPPING = new HashMap<SystemSource, Boolean>();
	
	static {//系统来源Map,采用"SFP_B2C_XXX"映射模式
		SFP_MAPPING.put(SystemSource.GATEWAY, Boolean.TRUE);
		SFP_MAPPING.put(SystemSource.SYPAY, Boolean.TRUE);
	}
	
	@Resource
	private ISFPayBankService sfpBankService;
	
	@Resource
	private IBankPayService bankPayService;
	
	@Override
	@Deprecated
	public PaymentParam createInCollect(InCollectInfo inInfo) throws Exception {//B2C收单
		return createPaymentByB2C(inInfo);
	}
	
	@Override
	public PaymentParam createPaymentByB2C(InCollectInfo inInfo) throws Exception {//B2C收单
		logger.info("===== B2C支付请求发起... =====");
		//校验类
		if(isDebug) {
			logger.debug("校验网银支付请求参数...[{}]", null == inInfo ? "null" : inInfo.toString());
		}
		if(null == inInfo) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "参数不能为空");
		}
		checkByB2C(inInfo);
		if(isDebug) {
			logger.info("将入参转换为收款对象...");
		}
		CollectInfo ci = convertB2CIn(inInfo);//资金方向、状态为初始化、渠道编码和回调地址等信息,同时将接收到的信息转化为统一信息
		createCollectInfo(ci, false);
		//生成支付请求信息
		ci.setPayerCardType(inInfo.getCardType());//供报文使用,暂不保存DB.Fuyx,2013-11-19
		ProcessRlt rlt = processBankXml(ci, true);
		PaymentReq req = rlt.getParam();
		//转换为对外对象
		PaymentParam param = new PaymentParam();
		param.setBankCode(ci.getBankCode());
		param.setAction(req.getAction());
		param.setCollectNo(req.getCollectNo());
		param.setSerieNo(req.getSerieNo());
		param.setPaymentArgs(req.getPaymentArgs());
		param.setQueryParam(req.getQueryParam());
		if(isDebug) {
			logger.debug("回传参数: {}", param.toString());
		}
		logger.info("===== B2C支付请求完毕 =====");
		return param;
	}
	
	@Override
	public PaymentResp updateBankResp(String collectNo, Map<String, String[]> param) throws Exception {//B2C模式
		return doBankInvoke(collectNo, null, param);//目前尚无退款,撤销操作.By RickyFu,2013-01-31
	}
	
	@Override
	public AccountInfo findAccountByPayNo(String payNo, SystemSource src) throws Exception {
		if(StringUtils.isEmpty(payNo)) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "支付流水号不能为空");
		}
		if(null == src) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "系统来源不能为空");
		}
		CollectInfo ci = null;
		try {
			ci = collectInfoDao.findByPayNo(payNo, src);
		} catch (Exception e) {
			logger.error(String.format("无法找到[%s]收单[%s]记录", src, payNo), e);
		}
		if(null == ci) {
			throw new ServiceException(InfoCode.DATABASE_FAILURE, "无法找到对应的收单记录");
		}
		AccountInfo ai = new AccountInfo();
		ai.setBankCode(BankCode.valueOf(ci.getPayeeOrgCode()));
		ai.setBankName(ci.getPayeeOrgName());
		ai.setSubBankNo(ci.getPayeeBranchCode());
		ai.setSubBankName(ci.getPayeeBranchName());
		ai.setAccountNo(ci.getPayeeAcctCode());
		ai.setAccountName(ci.getPayeeAcctName());
		ai.setProvince(ci.getPayeeAcctProvince());
		ai.setProvinceName(ci.getPayeeAcctProvinceN());
		ai.setCity(ci.getPayeeAcctCity());
		ai.setCityName(ci.getPayeeAcctCityN());
		return ai;
	}
	
	@Override
	public CollectInfo findByPayNo(SystemSource src, String payNo) throws Exception {
		if(StringUtils.isEmpty(payNo)) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "支付流水号不能为空");
		}
		if(null == src) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "系统来源不能为空");
		}
		CollectInfo ci = null;
		try {
			ci = collectInfoDao.findByPayNo(payNo, src);
		} catch (Exception e) {
			logger.error(String.format("无法找到[%s]收单[%s]记录", src, payNo), e);
		}
		return ci;
	}

	@Override
	public List<CollectInfo> closeCollectInfo(int before) throws Exception {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DATE, cal.get(Calendar.DATE)-before);
		logger.info("========== 开始执行关闭[{}]天前({}),状态为初始的收单记录 ==========", before, DateUtil.getDateString(cal.getTime(), "yyyy-MM-dd"));
		//查询需要关闭的记录 返回给订单系统
		List<CollectInfo> list = collectInfoDao.queryCloseCollectInfo(cal.getTime());
		if(list!=null && list.size()>0){
			collectInfoDao.closeCollectInfo(cal.getTime(), CollectStatus.CLOSED);
		}
		logger.info("========== 关闭收单记录执行完毕 ==========");
		return list;
	}

	public CollectInfo queryCollectInfoForCheck(String bussinessSn,Date tradeDate)throws Exception{
		if(StringUtils.isEmpty(bussinessSn)){
			throw new ServiceException(InfoCode.PARAM_INVALID,"bussinessSn is null or empty");
		}
		if(tradeDate==null){
			throw new ServiceException(InfoCode.PARAM_INVALID,"tradeDate is null or empty");
		}
		try {
			return collectInfoDao.queryCollectInfoForCheck(bussinessSn,tradeDate);
		} catch (Exception e) {
			logger.error("根据业务流水、交易时间查询收单记录异常", e);
			throw new ServiceException(InfoCode.FAILURE, e);
		}
	}
	
	public void resupplyByHand(String bussinessSn, Date tradeDate, String rtnBankMsg, String rtnBankCode) throws Exception {
		if (StringUtils.isEmpty(bussinessSn)) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "bussinessSn is null or empty");
		}
		if (null == tradeDate) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "tradeDate is null or empty");
		}
		CollectInfo collectInfo = null;
		try {
			collectInfo = collectInfoDao.queryCollectInfoForCheck(bussinessSn, tradeDate);
		} catch (Exception e) {
			logger.error("查询收单记录异常", e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE, "查询收单记录异常", e);
		}
		String collectNo = null == collectInfo ? null : collectInfo.getCollectNo();
		if (StringUtils.isEmpty(collectNo)) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "找不到对应的收单记录");
		}
		int upcnt = 0;
		try {
			upcnt = collectInfoDao.updateForResupplyByNo(collectNo, rtnBankMsg, rtnBankCode, rtnBankCode);
		} catch (Exception e) {
			logger.error("更新收单信息(当天补单)异常", e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE, "更新收单信息(当天补单)异常",e);
		}
		String payNo = collectInfo.getPayNo();
		if (StringUtils.isEmpty(payNo)) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "payNo is null or empty");
		}
		if (upcnt == 1) {
			logger.info("调用核心订单系统更新[{}]状态为[SUCCESS]", payNo);
			try {
				bankPayService.netBankPayNotifyByAcq(payNo, true);//调用小订单接口
			} catch (Exception e) {
				logger.error(String.format("调用核心订单系统更新[%s]状态异常", payNo), e);//不抛异常, 不影响收单
			}
		} else {
			logger.error("更新收单编号为 [{}]记录条数为0条,补单失败", collectNo);
			throw new ServiceException("更新收单编号为 [" + collectNo + "] 记录条数为0条,补单失败");
		}
	}
	
	/**
	 * 方法说明：网银收款Bean转化为统一Bean
	 *
	 * @param in {@link InCollectInfo}
	 * @return
	 */
	private CollectInfo convertB2CIn(InCollectInfo in) {
		ChannelCode channel = in.getChannelCode();
		OrderType orderType = in.getOrderType();
		BankCode bank = null;
		String coverBankCode = null;
		
		if(SFP_MAPPING.containsKey(in.getSystemSource())) {
			// 根据网关传入的顺银银行编码, 查询转换后的银行编码及第三方直联银行编号
			SFPayBank sfBank = null;
			try {
				sfBank = sfpBankService.findSFPayBank(channel, in.getOriBankCode());
			} catch (Exception e) {
				logger.error(String.format("查找顺银银行编码[%s-%s-%s]映射关系异常", channel, in.getOriBankCode(), orderType), e);
			}
			if(null == sfBank) {
				throw new ServiceException(InfoCode.FAILURE, String.format("无法找到[%s, %s]对应的银行编码映射", channel, in.getOriBankCode()));
			}
			bank = sfBank.getBankCode();
			coverBankCode = sfBank.getCoverBankCode();
		} else {//For Portal
			bank = in.getBankCode();
			coverBankCode = in.getCoverBankCode();
			if(null == in.getSystemSource()) {
				in.setSystemSource(SystemSource.PORTAL);
			}
		}
		CollectInfo ci = new CollectInfo();
		ci.setBankCode(bank);
		ci.setChannelCode(channel);
		ci.setOrderType(orderType);
		ci.setTradeNo(in.getTradeNo());
		ci.setPayNo(in.getPayNo());
		ci.setBusinessSn(in.getBusinessSn());
		ci.setFundWay(FundWay.IN);
		ci.setAmt(in.getAmt());
		ci.setCcy(in.getCcy());
		ci.setStatus(CollectStatus.INIT);
		ci.setBeginTime(dualDao.getDBDatetime());//其它过程可能需要该值,不可放在DB中设置
		ci.setFrontUrl(in.getFrontUrl());//写入原串,在DB中格式化该串.Ricky Fu
		ci.setResultUrl(in.getResultUrl());//写入原串,在DB中格式化该串.Ricky Fu
		ci.setReturnVar(in.getReturnVar());
		ci.setRemitMethod(in.getRemitMethod());
		ci.setUseDesc(in.getUseDesc());
		ci.setCoverBankCode(coverBankCode);
		ci.setSystemSource(in.getSystemSource());
		ci.setClientIp(in.getClientIp());
		
		//查询付款方信息(其它信息无法得知)
		ci.setPayerMemberNo(in.getPayerMemberNo());
		ci.setPayerOrgCode(bank.name());
		ci.setPayerMobile(in.getPayerMobile());
		//写入费率
		ci.setFee(getFee(bank, channel, in.getAmt(), ChargeType.BY_TIME, FundWay.IN));
		//查询收款方信息
		Account ai = AcquirerHelper.getAccount(bank, channel, orderType, FundWay.IN);
		if(null == ai) {
			String eMsg = String.format("无法找到[%s-%s-%s]对应的收款方信息", channel, bank, orderType);
			logger.error(eMsg);
			throw new ServiceException(InfoCode.FAILURE, eMsg);
		}
		ci.setPayeeMemberNo(null);
		ci.setPayeeOrgCode(ai.getBankCode().name());
//		ci.setPayeeOrgName(null);
		ci.setPayeeBranchCode(ai.getOpeningBankNo());
		ci.setPayeeBranchName(ai.getOpeningBankName());
		ci.setPayeeAcctCode(ai.getAccountNo());
		ci.setPayeeAcctName(ai.getAccountName());
		ci.setPayeeAcctProvince(ai.getProvince());
		//????? oms取值 ci.setPayeeAcctProvinceN(omsService.getDistrictName(ai.getProvince()));
		ci.setPayeeAcctCity(ai.getCity());
		//????? oms取值ci.setPayeeAcctCityN(omsService.getDistrictName(ai.getCity()));
		
		return ci;
	}
	
	/**
	 * 方法说明：
	 * B2C收款校验
	 * @param in
	 */
	private void checkByB2C(InCollectInfo in) {
		if(null == in) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "参数不能为空");
		}
		//必填项验证
		if(SFP_MAPPING.containsKey(in.getSystemSource())) {
			if(StringUtils.isEmpty(in.getOriBankCode())) {
				throw new ServiceException(InfoCode.BANK_CODE_IS_NULL, "银行编码[oriBankCode]不能为空");
			}
		} else {//For Portal
			if(null == in.getBankCode()) {
				throw new ServiceException(InfoCode.BANK_CODE_IS_NULL, "银行编码[bankCode]不能为空");
			}
			//如果是易宝需要传入支持的银行
			if(BankCode.YEEPAY.equals(in.getBankCode()) && StringUtils.isEmpty(in.getCoverBankCode())) {
				throw new ServiceException(InfoCode.THIRD_CONVERT_BANK_IS_NULL, "第三方转换编码不能为空");
			}
		}
		
		if(null == in.getChannelCode()) {
			throw new ServiceException(InfoCode.CHANNEL_CODE_IS_NULL, "渠道编码不能为空");
		}
		if(null == in.getOrderType()) {
			throw new ServiceException(InfoCode.BIZ_TYPE_IS_NULL, "业务类型不能为空");
		}
		if(StringUtils.isEmpty(in.getTradeNo())) {
			throw new ServiceException(InfoCode.TRADE_NO_IS_NULL, "交易订单编号不能为空");
		}
		if(StringUtils.isEmpty(in.getPayNo())) {
			throw new ServiceException(InfoCode.PAY_NO_IS_NULL, "支付订单编号不能为空");
		}
		if(StringUtils.isEmpty(in.getBusinessSn())) {
			throw new ServiceException(InfoCode.BUSINESS_SN_IS_NULL, "业务流水号不能为空");
		}
		if(null == in.getAmt() || in.getAmt() <= 0L) {
			throw new ServiceException(InfoCode.AMT_IS_NULL, "金额必填且必须大于0");
		}
		//TODO 是否必填?
//		if(null == in.getPayerMemberNo() || in.getPayerMemberNo()<=0) {
//			throw new ServiceException(InfoCode.PAYER_MEMBER_CODE_IS_NULL, "payer member code is null or empty");
//		}
	}
}
