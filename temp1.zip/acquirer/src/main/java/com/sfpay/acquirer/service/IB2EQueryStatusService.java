package com.sfpay.acquirer.service;

import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.framework.base.exception.ServiceException;

public interface IB2EQueryStatusService {

	/**
	 * 方法说明：<br>
	 * 发起查询交易状态指令
	 *
	 * @param bankCode
	 * @throws ServiceException
	 */
	public void proQueryReq(BankCode bankCode) throws ServiceException ;
}
