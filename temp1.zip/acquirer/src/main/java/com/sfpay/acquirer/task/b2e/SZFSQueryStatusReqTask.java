package com.sfpay.acquirer.task.b2e;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.service.IB2EQueryStatusService;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 深圳结算中心查询交易状态
 * @author sfhq272
 *
 */
@Service("SZFSQueryStatusReqTask")
public class SZFSQueryStatusReqTask {
	private static final Logger logger = LoggerFactory.getLogger(SZFSQueryStatusReqTask.class);
	@Resource
	private IB2EQueryStatusService service;
	
	private final BankCode bankCode = BankCode.SZFS;
	
	public void execute() throws ServiceException {
			logger.info("开始定时任务{}", "SZFSQueryStatusReqTask");
			service.proQueryReq(bankCode);
			logger.info("结束定时任务{}", "SZFSQueryStatusReqTask");
	}
}
