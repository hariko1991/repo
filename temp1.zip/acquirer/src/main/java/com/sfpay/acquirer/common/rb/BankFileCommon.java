package com.sfpay.acquirer.common.rb;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.PostConstruct;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.common.Ftp4jUtil;
import com.sfpay.acquirer.common.SFTPUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;

/**
 * 文件上传,文件下载,生成文件
 * @author sfhq272
 *
 */
@SuppressWarnings("unused")
public abstract class BankFileCommon<T> {

	private static final Logger logger = LoggerFactory.getLogger(BankFileCommon.class);

	//本地路径
	protected String localPath;
	//本地全路径
	protected String localFullPathStr;
	//文件路径加名子
	protected String localFullFileName;
	
	//针对头上可能需要的字段
	protected Map<String,String> headMap = new HashMap<String,String>();
	
	
	private String commonSftpIp;
	private int commonSftpPort;
	private String szfsSftpUser;
	private String szfsSftpPass;
	private String szfsSftpPath;

	@PostConstruct
	private void initParam(){
		//本地文件夹
		localPath = Property.getProperty("SZFS_LOCAL_PATH");
		logger.info("本地目录：{}", localPath);
	}
	
	private void initACQParam() throws ServiceException{
		
		commonSftpIp = Property.getProperty("COMMON_SFTP_IP");
		logger.info("银企公共SFTP的ip：{}", commonSftpIp);
		commonSftpPort = Integer.valueOf(Property.getProperty("COMMON_SFTP_PORT"));
		logger.info("银企公共SFTP的port：{}", commonSftpPort);
		szfsSftpUser = Property.getProperty("SZFS_SFTP_USER");
		logger.info("结算中心SFTP的user：{}", szfsSftpUser);
		szfsSftpPass = Property.getProperty("SZFS_SFTP_PASS");
		logger.info("结算中心SFTP的pass：{}", szfsSftpPass);
		String szfsPath = Property.getProperty("SZFS_SFTP_PATH");
		logger.info("结算中心SFTP的path：{}", szfsPath);
		szfsSftpPath = szfsPath.endsWith("/") ? szfsPath : szfsPath+"/";
	}
	
	public void downloadSFTPFile(String fileName, String tradeDateStr) throws ServiceException {
		//初始化连接FTP服务器参数。
		try {
			initACQParam();
			String szfsSftpFullPath = initLocalFullPath(szfsSftpPath, tradeDateStr);
			localFullPathStr = initLocalFullPath(localPath, tradeDateStr);
			File localFullPath = new File(localFullPathStr);
			if(!localFullPath.exists()){
				try{
					localFullPath.mkdirs();
				}catch(SecurityException e) {
					logger.info("生成本地文件夹{}异常:{}", localFullPathStr, e);
					throw new ServiceException("","[ It doesn't own the create directory rights. ]" + localFullPathStr, e);
				}
			}
			logger.info("downloadSFTPFile sftp服务器信息:远程IP:{},远程断口:{},远程目录:{},本地目录:{}",
					new Object[]{commonSftpIp,commonSftpPort,szfsSftpFullPath,localFullPathStr});
			SFTPUtil sftpClient = new SFTPUtil(commonSftpIp, commonSftpPort, szfsSftpUser, szfsSftpPass, 0);
			localFullFileName = localFullPathStr + fileName;
			sftpClient.download(szfsSftpFullPath, fileName, localFullFileName);
			logger.info("downloadSFTPFile从结算中心前置路径{}下载文件{}到本地路径{}",
					new Object[]{szfsSftpFullPath, fileName, localFullPathStr});
		} catch (Exception e) {
			logger.info("从SFTP下载文件失败:{}",e);
			throw new ServiceException("","从SFTP下载文件失败",e);

		}
	}

	/**
	 * 
	 * @param fullName              要读取的文件名
	 * @param clazz				           对象的class类型
	 * @param headFlag				文件是否有头
	 * @param headLength			文件 的头长度
	 * @param contentLength         文件内容长度 
	 * @return
	 * @throws ServiceException
	 */
	public List<T> readFile(boolean headFlag, String encoding) throws ServiceException{
		InputStreamReader fr =  null;
		BufferedReader br = null;
		List<T> tempList = new ArrayList<T>();
		try{
			fr = new InputStreamReader(new FileInputStream(new File(localFullFileName)), encoding);
			br = new BufferedReader(fr);

			//解析文件
			String content = br.readLine();
			if(headFlag){
				if(null != content && !"".equals(content = content.trim())){
					logger.info("解析文件头:{}", content);
				}
				converHead2Map(content);
				content = br.readLine();
			}
			//解析文件内容
			while(null != content && !"".equals(content = content.trim())){
				T temp = converContent2Object(content);
				tempList.add(temp);
				content = br.readLine();
			}
			logger.info("解析文件完成,共有{}笔数据", tempList.size());
		}catch(Exception ex){
			logger.error("解析文件["+localFullFileName+"]异常.",ex);
			throw new ServiceException("解析文件["+localFullFileName+"]异常."+ex.getMessage(), ex);
		}finally{
			try{
				if(br != null){
					br.close();
				}
				if(fr != null){
					fr.close();
				}
			}catch(Exception ex){
				logger.error("",ex);
			}
		}
		return tempList;
	}

	/**
	 * 
	 * @param content    文件内容
	 * @param checkDate  
	 * @param contentLength
	 * @param clazz
	 * @return
	 * @throws ServiceException
	 */
	public abstract T converContent2Object(String content) throws ServiceException;
	
	public void converHead2Map(String head) throws ServiceException{
		
	}

	public abstract void initLocalFullName(String tradeDateStr) throws Exception;
	
	public abstract String initLocalFullPath(String localPath, String tradeDateStr);

}
