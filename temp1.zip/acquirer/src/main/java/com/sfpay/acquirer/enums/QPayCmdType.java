/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.enums;

/**
 * 类说明：<br>
 * 快捷支付<span style="color:red;">非消费类</span>指令类型
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 <a href="mailto:fuyuxin@sf-express.com">符瑜鑫(Ricky Fu)</a>
 * 
 * CreateDate: 2013-1-25
 */
public enum QPayCmdType {
	
	UPOP_SMS("UpopSMS", "银联发送短信指令"),
	
	UPOP_ACTIVATE("UpopActivate", "银联开通状态指令"),
	
	UPOP_TRADE_QUERY("UpopTradeQuery", "银联交易查询指令");
	
	/**
	 * 该指令对应的实现接口的服务名称
	 */
	private String serviceName;
	
	private String text;
	
	private QPayCmdType(String serviceName, String text) {
		this.serviceName = serviceName;
		this.text = text;
	}
	
	public String getServiceName() {
		return this.serviceName;
	}
	
	public String text() {
		return this.text;
	}

}
