package com.sfpay.acquirer.domain;

/**
 * 类说明：<br>
 * 用于承载处理银行报文后的结果参数
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 * CreateDate: 2015年10月13日
 */
public class ProcessRlt {
	private String collectNo;
	private PaymentReq param;
	private BankProperty properties;
	public ProcessRlt(String collectNo, PaymentReq param, BankProperty properties) {
		this.collectNo = collectNo;
		this.param = param;
		this.properties = properties;
	}
	public String getCollectNo() {
		return collectNo;
	}
	public PaymentReq getParam() {
		return param;
	}
	public BankProperty getProperties() {
		return properties;
	}
}
