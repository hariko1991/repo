package com.sfpay.acquirer.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.Encoding;
import com.sfpay.acquirer.common.HttpHelper;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.RepeatInvokeHelper;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IMerInfoDao;
import com.sfpay.acquirer.dao.IParamInfoDao;
import com.sfpay.acquirer.dao.IPayBusinessDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.ParamInfo;
import com.sfpay.acquirer.domain.PayoutExchange;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutRlt;
import com.sfpay.acquirer.domain.paycenter.MerInfo;
import com.sfpay.acquirer.domain.paycenter.MerInfoParam;
import com.sfpay.acquirer.domain.paycenter.PayoutReqInfo;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.ExchangeType;
import com.sfpay.acquirer.enums.PayCenterPayStatus;
import com.sfpay.acquirer.enums.PaymentStatusExt;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.enums.SystemSource;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.coreplatform.order.service.IBankPayService;
import com.sfpay.coreplatform.order.valueobject.dto.CancelBankEnterpriseRequest;
import com.sfpay.coreplatform.order.valueobject.dto.PayConfirmRequest;
import com.sfpay.coreplatform.order.valueobject.dto.PayResponse;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：<br>
 * 发送付款结果
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 *         CreateDate: 2013-5-22
 */
@HessianExporter
@Service("sendPayoutResp")
public class SendPayoutResp implements ISendPayoutResp {
	private static Logger logger = LoggerFactory.getLogger(SendPayoutResp.class);
	private static final boolean isDebug = logger.isDebugEnabled();
	/**
	 * 平台会员号
	 */
	private Long memberNo = Long.valueOf(Property.getProperty("PLATFORM_MEMBER_NO"));
	/**
	 * 通知各系统的退票URL前缀
	 */
	private static final String PREFIX_URL_BOUNCE = "URL_BOUNCE_";
	/**
	 * 通知各系统的交易结果URL前缀
	 */
	private static final String PREFIX_URL_PAYOUT = "URL_PAYOUT_";

	private long notifyInterval = StringUtils.isEmpty(Property.getProperty("PAYOUT_NOTIFY_INTERVAL")) ? 20000
			: Long.parseLong(Property.getProperty("PAYOUT_NOTIFY_INTERVAL"));;
	// static {
	// String interval = Property.getProperty("PAYOUT_NOTIFY_INTERVAL");
	// NOTIFY_INTERVAL = StringUtils.isEmpty(interval) ? 20000 :
	// Long.parseLong(interval);
	// }

	@Resource
	private IPayoutInfoDao payoutInfoDao;

	@Resource
	private IBankPayService orderService;

	@Resource
	private IPayoutExchangeService exchangeService;

	@Resource
	private IParamInfoDao paramDao;

	@Resource
	private IPayBusinessDao payBusinessDao;

	@Resource
	private IMerInfoDao merInfoDao;

	@Resource
	private JmsTemplate payoutResultSender;

	// 复核拒绝的批次信息，用于发送业务系统获取拒绝原因
	private BatchInfo refuseBatch = null;

	private static ExecutorService executor = Executors.newCachedThreadPool();// modify
																				// sfhq270
																				// 2014-10-10
																				// 将execute

	/**
	 * 方法说明：<br>
	 * 发送结果业务系统系统（不包括订单系统）
	 *
	 * @param batchNotify
	 *            发送业务系统的数据
	 * @throws ServiceException
	 */
	public void sendResp(List<PayoutInfo> batchNotify) throws ServiceException {
		this.sendOrderResp(batchNotify, null);
	}

	/**
	 * 方法说明：<br>
	 * 发送结果给订单系统或其他业务系统
	 *
	 * @param batchNotify
	 *            发送业务系统的数据
	 * @param exchangeType
	 *            交互类型（为空时，不发送订单系统）
	 * @throws ServiceException
	 */
	public void sendOrderResp(List<PayoutInfo> batchNotify, ExchangeType exchangeType) throws ServiceException {
		if (batchNotify == null || batchNotify.size() == 0) {
			return;
		}
		List<PayConfirmRequest> orderNotify = new ArrayList<PayConfirmRequest>();// 订单系统
		StringBuffer meta = new StringBuffer();
		Map<SystemSource, StringBuffer> xmlMap = new HashMap<SystemSource, StringBuffer>();// 异步发送使用
		if (isDebug) {
			logger.debug("需要发送其他系统的付款信息：{}", batchNotify.toString());
		}
		for (PayoutInfo info : batchNotify) {
			// 非人工操作的交易失败，不发送业务系统
			if (PayoutStatus.FAILURE.equals(info.getStatus()) && YNFlag.N.equals(info.getOfflineFlag())) {
				logger.info("付款信息[付款编号:{}],非人工操作失败的交易失败，不发送业务系统", info.getPayoutNo());
				continue;
			}
			// 订单系统
			if (null != exchangeType && PayoutStatus.FIR_CHECK_REFUSE != info.getStatus()
					&& PayoutStatus.SEC_CHECK_REFUSE != info.getStatus()) {
				try {
					PayoutExchange ec = exchangeService.createExchange(info, exchangeType);// 生成交互信息
					PayConfirmRequest outPayNotify = this.converToOutPay(ec, info, meta);// 组装订单参数
					if (outPayNotify != null) {
						orderNotify.add(outPayNotify);
					}
				} catch (Exception ex) {
					logger.error("生成交互信息（银行确认）异常", ex);
				}
			} else {
				logger.info("付款信息[付款编号:{}],复核拒绝[{}]或无交互类型,不需要发送订单系统.", info.getPayoutNo(), info.getStatus());
			}
			if (!StringUtils.isEmpty(info.getPayoutNo())) {
				PayoutRlt rlt = payoutInfoDao.queryPayoutByPayoutNo(info.getPayoutNo());
				if (!"0".equals(rlt.getVersion())) {
					logger.info("标准化接口[{}]数据[{}]，采用新接口通知", rlt.getVersion(), info.getPayoutNo());
					payoutResultSender.convertAndSend(info.getPayoutNo());
					continue;
				}
			}
			buildPayoutRespXml(xmlMap, info);

		}

		// 发送
		sendOrder(orderNotify, meta);
		// 异步发送业务系统
		sendXml(xmlMap, PREFIX_URL_PAYOUT);
	}

	/**
	 * 付款请求重复，将重复的付款流水更改为失败，并通知业务系统Start 2015-01-15 sfhq 270
	 */
	public void sendBusinessSysResp(List<PayoutInfo> PayoutInfos) {
		if (PayoutInfos == null || PayoutInfos.size() == 0) {
			logger.info("没有重复的付款请求PayoutInfos:{}", PayoutInfos);
			return;
		}
		Map<SystemSource, StringBuffer> xmlMap = new HashMap<SystemSource, StringBuffer>();// 异步发送使用
		for (PayoutInfo info : PayoutInfos) {
			if (!StringUtils.isEmpty(info.getPayoutNo())) {
				PayoutRlt rlt = payoutInfoDao.queryPayoutByPayoutNo(info.getPayoutNo());
				if (!"0".equals(rlt.getVersion())) {
					logger.info("标准化接口[{}]数据[{}]，采用新接口通知", rlt.getVersion(), info.getPayoutNo());
					payoutResultSender.convertAndSend(info.getPayoutNo());
					continue;
				}
			}
			buildPayoutRespXml(xmlMap, info);
		}
		// 异常发送业务系统
		sendXml(xmlMap, PREFIX_URL_PAYOUT);
	}
	/**
	 * 付款请求重复，将重复的付款流水更改为失败，并通知业务系统end 2015-01-15 sfhq 270
	 */

	/**
	 * 方法说明：<br>
	 * 发送退票结果给订单系统或其他外系统
	 *
	 * @param batchNotify
	 *            发送外系统的数据
	 * @throws ServiceException
	 */
	public void sendBounceResp(List<PayoutInfo> batchNotify, Map<String, List<PayoutExchange>> oldEcMap)
			throws ServiceException {
		if (batchNotify == null || batchNotify.size() == 0) {
			return;
		}
		List<CancelBankEnterpriseRequest> orderNotify = new ArrayList<CancelBankEnterpriseRequest>();// 订单系统
		StringBuffer meta = new StringBuffer();
		Map<SystemSource, StringBuffer> xmlMap = new HashMap<SystemSource, StringBuffer>();
		if (isDebug) {
			logger.debug("需要发送其他系统的退票信息：{}", batchNotify.toString());
		}
		for (PayoutInfo info : batchNotify) {
			// 非人工操作的交易失败, 不发送业务系统
			if (!PayoutStatus.FAILURE.equals(info.getStatus()) || YNFlag.N.equals(info.getOfflineFlag())) {
				logger.info("退票信息[付款编号:{}],非人工操作失败的交易失败，不发送业务系统");
				continue;
			}
			// 订单系统
			try {
				// 生成交互信息
				List<PayoutExchange> ecLs = exchangeService.createBounceExchange(info, oldEcMap.get(info.getPayoutNo()),
						ExchangeType.BOUNCE);
				if (null != ecLs && ecLs.size() > 0) {// 组装订单实体
					for (PayoutExchange pe : ecLs) {
						CancelBankEnterpriseRequest er = new CancelBankEnterpriseRequest();
						er.setOutTradeNo(pe.getExchangeNo());
						er.setOldOutTradeNo(pe.getRevExchangeNo());
						er.setPlatformMemberNo(memberNo);

						meta.append("[oldOutTradeNo=").append(er.getOldOutTradeNo()).append(",outTradeNo=")
								.append(er.getOutTradeNo()).append(",platformMemberNo=")
								.append(er.getPlatformMemberNo()).append("],\n");

						orderNotify.add(er);
					}
				}
			} catch (Exception ex) {
				logger.error("生成交互信息(银行确认)异常", ex);
			}
			PayoutRlt rlt = payoutInfoDao.queryPayoutByPayoutNo(info.getPayoutNo());
			if (!"0".equals(rlt.getVersion())) {
				logger.info("标准化接口[{}]数据[{}]，采用新接口通知", rlt.getVersion(), info.getPayoutNo());
				payoutResultSender.convertAndSend(info.getPayoutNo());
				continue;
			}
			buildBounceXml(xmlMap, info);
		}

		// 发送业务系统
		sendBounceOrder(orderNotify, meta);// 订单退票接口
		// 异步发送
		sendXml(xmlMap, PREFIX_URL_BOUNCE);
	}

	/**
	 * 方法说明：<br>
	 * 只发送，不更新.审批拒绝使用
	 *
	 * @param batchCode
	 * @throws ServiceException
	 */
	public void doPayCenterResp(List<PayoutReqInfo> infos, PayoutStatus status, String desc) throws ServiceException {

		Map<SystemSource, StringBuffer> xmlMap = new HashMap<SystemSource, StringBuffer>();
		for (PayoutReqInfo info : infos) {
			logger.info("回调交易流水号【{}】的结果状态：【{}】！", info.getTradeNo(), info.getStatus().name());
			PayoutInfo payoutInfo = new PayoutInfo();
			payoutInfo.setTradeOutBussinessNo(info.getPayBusinessNo());
			payoutInfo.setStatus(status);
			payoutInfo.setRtnBankMsg(desc);
			payoutInfo.setSystemSource(info.getSystemSource());
			payoutInfo.setTradeOutNo(info.getTradeNo());
			payoutInfo.setEndTime(new Date());// 增加更新日期，修复以前Bug。sfhq270
												// 2014-11-11
			buildPayoutRespXml(xmlMap, payoutInfo);
		}
		sendXml(xmlMap, PREFIX_URL_PAYOUT);
	}

	/**
	 * 方法说明：<br>
	 * 只发送，不更新.复核拒绝使用
	 *
	 * @param batchCode
	 * @throws ServiceException
	 */
	public void doSendOrderResp(PayoutStatus queryStatus, BatchInfo batchInfo) throws ServiceException {
		logger.info("批次[批次号:{}],开始发送付款结果[{}]到外部系统.", batchInfo.getBatchCode(), queryStatus);

		// 获取需发送外系统的付款信息
		List<PayoutInfo> batchNotify = payoutInfoDao.queryPayoutByBatch(batchInfo.getBatchCode(), queryStatus);

		if (batchNotify == null || batchNotify.size() == 0) {
			logger.info("查询批次[批次号:{}]无记录.", batchInfo.getBatchCode());
			return;
		}

		// 发送外系统等
		try {
			this.refuseBatch = batchInfo;// 设置批次信息
			this.sendOrderResp(batchNotify, ExchangeType.SEND_AFTER);
		} catch (Exception ex) {
			logger.error("批次[批次号:" + batchInfo.getBatchCode() + "],调用外部系统异常 :" + ex.getMessage());
		}
		logger.info("批次[批次号:{}],发送付款结果[{}]到外部系统结束.", batchInfo.getBatchCode(), queryStatus);
	}

	/**
	 * 方法说明：<br>
	 * 更新交易状态并发送结果给外系统,批次出款时失败
	 *
	 * @param payoutStatus
	 *            交易结果
	 * @param batchCode
	 *            批次号
	 * @throws ServiceException
	 */
	public void doSendOrderResp(List<PayoutInfo> lists, BatchInfo batchInfo, PayoutStatus updateStatus)
			throws ServiceException {
		logger.info("开始发送批次[批次号:{},请求流水号:{}]付款结果[{}]给外部系统.",
				new Object[] { batchInfo.getBatchCode(), batchInfo.getReqBankSn(), updateStatus });
		// 更新结果并获取需发送外系统的付款信息
		List<PayoutInfo> list = null;
		if (lists == null || lists.size() == 0) {
			list = this.payoutInfoDao.queryPayoutByBatchCode(batchInfo.getBatchCode());
		} else {
			list = lists;
		}
		if (list == null || list.size() == 0) {
			logger.info("查询批次[批次号:{},请求流水号:{}]无记录", batchInfo.getBatchCode(), batchInfo.getReqBankSn());
			return;
		}

		List<PayoutInfo> batchNotify = new ArrayList<PayoutInfo>();
		for (PayoutInfo detail : list) {
			detail.setStatus(updateStatus);
			PayoutInfo out = this.doPayoutInfoResp(detail);
			if (out != null) {
				batchNotify.add(out);
			}
		}

		// 发送订单系统等
		if (batchNotify != null && batchNotify.size() > 0) {
			try {
				this.sendOrderResp(batchNotify, ExchangeType.SEND_AFTER);
			} catch (Exception ex) {
				logger.error("批次[批次号:" + batchInfo.getBatchCode() + ",请求流水号:" + batchInfo.getReqBankSn()
						+ "],调用外部系统异常 :" + ex.getMessage());
			}
		} else {
			logger.info("批次[批次号:{},请求流水号:{}],没有需要发送付款结果给外部系统的数据.", batchInfo.getBatchCode(), batchInfo.getReqBankSn());
		}
		logger.info("发送批次[批次号:{},请求流水号:{}]付款结果[{}]给外部系统结束.",
				new Object[] { batchInfo.getBatchCode(), batchInfo.getReqBankSn(), updateStatus });
	}

	/**
	 * 方法说明：<br>
	 * 更新交易状态并返回需要发送外系统的付款信息
	 *
	 * @param detail
	 * @return PayoutInfo 需要把结果发送外系统的付款信息
	 * @throws ServiceException
	 */
	public PayoutInfo doPayoutInfoResp(PayoutInfo detail) throws ServiceException {
		PayoutInfo newPayout = null;
		// 检查返回结果
		this.checkRes(detail);
		PayoutInfo oldPayout = this.payoutInfoDao.queryPayoutInfo(detail.getBatchCode(), detail.getReqBankSn());

		if (oldPayout == null) {
			logger.info(
					"查询付款信息([批次号:" + detail.getBatchCode() + "]+请求流水号[" + detail.getReqBankSn() + "])无记录,不需要更新并发送业务系统");
			return null;
		}

		if (!oldPayout.getStatus().equals(PayoutStatus.UNKOWN)
				&& !oldPayout.getStatus().equals(PayoutStatus.SEC_CHECK_PASS)
				&& !oldPayout.getStatus().equals(PayoutStatus.RECEIVED)) {
			logger.info(String.format("付款信息[付款编号:%s、请求流水号:%s],原状态为[%s],不能执行更新银行返回结果操作.", oldPayout.getPayoutNo(),
					detail.getReqBankSn(), oldPayout.getStatus()));
			return null;
		}

		// 更新数据库，并返回更新成功(交易成功/失败)的数据
		if (detail.getStatus().equals(PayoutStatus.UNKOWN) && !oldPayout.getStatus().equals(PayoutStatus.UNKOWN)) {
			int cnt = this.payoutInfoDao.updateBankRtn(detail);
			logger.info("(不发送业务系统)付款信息[付款编号:{}、请求流水号:{}],更新银行返回结果[status:{},rtnBankCode:{},rtnBankMsg:{}],更新行数 [{}]",
					new Object[] { oldPayout.getPayoutNo(), detail.getReqBankSn(), detail.getStatus(),
							detail.getRtnBankCode(), detail.getRtnBankMsg(), cnt });
		} else if ((detail.getStatus().equals(PayoutStatus.SUCCESS) || detail.getStatus().equals(PayoutStatus.FAILURE))
				&& (!oldPayout.getStatus().equals(PayoutStatus.SUCCESS)
						&& !oldPayout.getStatus().equals(PayoutStatus.FAILURE))) {
			// 更新银行结果
			int cnt = this.payoutInfoDao.updateBankRtn(detail);
			logger.info("(需要发送业务系统)付款信息[付款编号:{}、请求流水号:{}],更新银行返回结果[status:{},rtnBankCode:{},rtnBankMsg:{}],更新行数 [{}]",
					new Object[] { oldPayout.getPayoutNo(), detail.getReqBankSn(), detail.getStatus(),
							detail.getRtnBankCode(), detail.getRtnBankMsg(), cnt });
			if (cnt > 0) {
				try {
					newPayout = this.payoutInfoDao.queryPayoutInfo(detail.getBatchCode(), detail.getReqBankSn());
				} catch (Exception ex) {
					logger.error("付款信息[付款编号:" + oldPayout.getPayoutNo() + "、请求流水号:" + detail.getReqBankSn()
							+ "],转换订单位对象异常 :", ex);
				}
			}
		} else {
			logger.info(String.format("付款信息[付款编号:%s、请求流水号:%s],原状态为[%s],新状态为[%s],不需要更新银行返回结果", oldPayout.getPayoutNo(),
					detail.getReqBankSn(), oldPayout.getStatus(), detail.getStatus()));
		}

		return newPayout;
	}

	/**
	 * 方法说明：<br>
	 * 转换订单系统对象
	 *
	 * @param info
	 * 
	 */
	private PayConfirmRequest converToOutPay(PayoutExchange info, PayoutInfo payout, StringBuffer data)
			throws ServiceException {
		if (info == null) {
			logger.info("不存在需要转换订单系统对象的信息");
			return null;
		}
		PayConfirmRequest confirmReq = new PayConfirmRequest();
		// reqInfo.setBankCode(payout.getBankCode().name());
		confirmReq.setBankCode(payout.getPayerOrgCode().name());// 修改bankCode为付款方银行。2015-02-04
																// 周丽佩
		confirmReq.setBusinessType(com.sfpay.coreplatform.order.common.enums.BusinessType.WIH_OUTPAY);
		confirmReq.setCcy(com.sfpay.coreplatform.order.common.enums.CcyType
				.valueOf(info.getCcy() == CurrencyType.CNY ? "RMB" : info.getCcy().name()));
		confirmReq.setOrderType(com.sfpay.coreplatform.order.common.enums.OrderType.TRANSFER);
		confirmReq.setPayAmt(info.getAmt());
		confirmReq.setTradeOutNo(info.getExchangeNo());
		confirmReq.setPlatformMemberNo(memberNo);

		if (PayoutStatus.SUCCESS.equals(payout.getStatus())) {
			confirmReq.setTradeStatus(true);
		} else if (PayoutStatus.FAILURE.equals(payout.getStatus())) {
			confirmReq.setTradeStatus(false);
		} else {
			return null;// 未知状态不发送
		}
		data.append("[bankCode=").append(confirmReq.getBankCode()).append(",tradeStatus=")
				.append(confirmReq.isTradeStatus()).append(",tradeOutNo = ").append(confirmReq.getTradeOutNo())
				.append(",businessType = ").append(confirmReq.getBusinessType()).append(",ccy = ")
				.append(confirmReq.getCcy()).append(",orderType = ").append(confirmReq.getOrderType())
				.append(",payAmt = ").append(confirmReq.getPayAmt()).append(",platformMermberNo = ")
				.append(confirmReq.getPlatformMemberNo()).append("],\n");
		return confirmReq;
	}

	/**
	 * 方法说明：<br>
	 * 检查付款信息返回结果
	 *
	 * @param payoutInfo
	 * @throws ServiceException
	 */
	private void checkRes(PayoutInfo payoutInfo) throws ServiceException {
		if (payoutInfo == null) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "转换银行返回值结果不能为空 ");
		}
		if (StringUtils.isEmpty(payoutInfo.getReqBankSn())) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "转换银行返回值结果的银行请求流水号不能为空 ");
		}
		// 轮询失败后修改，没有银行返回码
		// if(StringUtils.isEmpty(payoutInfo.getRtnBankCode())) {
		// throw new
		// ServiceException(InfoCode.PARAM_INVALID,"转换银行返回值结果的银行返回码不能为空 ");
		// }
		if (payoutInfo.getStatus() == null) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "转换银行返回值结果的交易结果不能为空 ");
		}
	}

	/**
	 * 方法说明：<br>
	 * 生成退票通知外部系统报文
	 */
	private void buildBounceXml(Map<SystemSource, StringBuffer> xmlMap, PayoutInfo payoutData) {
		if (StringUtils.isEmpty(payoutData.getTradeOutNo())) {
			return;
		}
		boolean isNotify = true;
		PayCenterPayStatus centerStatus = null;
		String desc = "";
		switch (payoutData.getStatus()) {
		case FAILURE:
			centerStatus = PayCenterPayStatus.FAILURE;
			desc = "银行退票";
			break;
		default:
			isNotify = false;
			break;
		}
		if (!isNotify) {
			return;
		}

		StringBuffer bXml = xmlMap.get(payoutData.getSystemSource());
		if (null == bXml) {
			bXml = new StringBuffer(
					"<?xml version=\"1.0\" encoding=\"UTF-8\" ?><payout-result type=\"bounce\" sign=\"#signVal#\">");
		}

		// 在此处需要加入是否是付款中心数据记录的判断，若是付款中心则需要调用付款中心通知处理逻辑
		String tradeOutBusinessNo = payoutData.getTradeOutBussinessNo();// 获取外部交易业务编号用以回查付款中心记录表
		if (!StringUtils.isEmpty(tradeOutBusinessNo)) {
			PayoutReqInfo tmpInfo = payBusinessDao.queryPayInfoByBusinessNo(tradeOutBusinessNo);
			// 若在付款业务表中能查到相应的付款记录表示该笔付款是付款中心数据则需要通过另外方式实现
			if (null != tmpInfo) {
				// 更新付款中心付款业务表状态
				payBusinessDao.updateStatus(tmpInfo.getId(), centerStatus, desc, payoutData.getEndTime());
				tmpInfo = payBusinessDao.queryPayoutReqInfoById(tmpInfo.getId());
				String merNoStr = tmpInfo.getMerNo();
				MerInfoParam param = new MerInfoParam();
				param.setMerNo(merNoStr);
				MerInfo merInfo = merInfoDao.queryMerInfo(param);
				bXml.append("<item tradeNo=\"").append(tmpInfo.getTradeNo())// 外部交易订单编号
						.append("\">")// 付款编号
						.append("<tradeExt1>").append(tmpInfo.getTradeExt1()).append("</tradeExt1>")
						.append("<tradeExt2>").append(tmpInfo.getTradeExt2()).append("</tradeExt2>")
						.append("<payBusinessNo>").append(tmpInfo.getPayBusinessNo()).append("</payBusinessNo>")
						.append("<payReqTime>").append(tmpInfo.getPayReqTime()).append("</payReqTime>")
						.append("<payEndTime>").append(tmpInfo.getPayEndTime()).append("</payEndTime>")
						.append("<status>").append(tmpInfo.getStatus().name()).append("</status>")
						.append("<bankRetCode>").append(toBlank(tmpInfo.getBankRetCode())).append("</bankRetCode>")
						.append("<bankRetMsg>").append(toBlank(tmpInfo.getBankRetMsg())).append("</bankRetMsg>")
						.append("<merNo>").append(tmpInfo.getMerNo()).append("</merNo>").append("<url>")
						.append(merInfo.getNotifyUrl()).append("</url>").append("<merKey>").append(merInfo.getMerKey())
						.append("</merKey>").append("</item>");
				xmlMap.put(payoutData.getSystemSource(), bXml);
				return;
			}

		}

		bXml.append("<item tradeOutNo=\"").append(payoutData.getTradeOutNo())// 外部交易订单编号
				.append("\" payoutNo=\"").append(payoutData.getPayoutNo()).append("\">")// 付款编号
				.append("<beginTime>")
				.append(DateUtil.getDateString(payoutData.getBeginTime(), DateUtil.DATA_FORMAT_PATTERN))
				.append("</beginTime>").append("<endTime>")
				.append(DateUtil.getDateString(payoutData.getEndTime(), DateUtil.DATA_FORMAT_PATTERN))
				.append("</endTime>").append("<amt>").append(payoutData.getAmt()).append("</amt>").append("<shouldAmt>")
				.append(toBlank(payoutData.getShouldAmt())).append("</shouldAmt>").append("<deductionAmt>")
				.append(toBlank(payoutData.getDeductionAmt())).append("</deductionAmt>").append("<fee>")
				.append(toBlank(payoutData.getFee())).append("</fee>").append("<reqBankSn>")
				.append(toBlank(payoutData.getReqBankSn())).append("</reqBankSn>").append("<rtnBankCode>")
				.append(toBlank(payoutData.getRtnBankCode())).append("</rtnBankCode>").append("<status>")
				.append(PaymentStatusExt.FAILURE).append("</status>").append("<returnMsg>").append(toBlank(payoutData.getRtnBankMsg())).append("</returnMsg>")
				.append("</item>");
		xmlMap.put(payoutData.getSystemSource(), bXml);
	}

	/**
	 * 方法说明：<br>
	 * 生成交易结果通知外部系统报文
	 */
	private void buildPayoutRespXml(Map<SystemSource, StringBuffer> xmlMap, PayoutInfo info) {
		if (StringUtils.isEmpty(info.getTradeOutNo())) {
			return;
		}
		//如果明细银行响应为空，则查询批次银行响应信息
		if(StringUtils.isEmpty(info.getRtnBankCode()) 
				|| StringUtils.isEmpty(info.getRtnBankMsg())){
			PayoutInfo  tmp = payoutInfoDao.findBankRtn(info.getPayoutNo());
			info.setRtnBankCode(tmp == null ? null: tmp.getRtnBankCode());
			info.setRtnBankMsg(tmp == null ? null: tmp.getRtnBankMsg());
		}
				
		boolean notifyFlag = true;
		PaymentStatusExt status = null;
		PayCenterPayStatus centerStatus = null;
		String desc = null;
		// 状态为复核拒绝、失败、成功时，转换返回状态及返回信息；其他状态不生成报文。
		switch (info.getStatus()) {
		case FIR_CHECK_REFUSE:// ("第一次复核拒绝"),
			status = PaymentStatusExt.FAILURE;
			centerStatus = PayCenterPayStatus.FAILURE;
			desc = null == refuseBatch ? null : refuseBatch.getFirCheckDesc();
			break;
		case SEC_CHECK_REFUSE:// ("第二次复核拒绝"),
			status = PaymentStatusExt.FAILURE;
			centerStatus = PayCenterPayStatus.FAILURE;
			desc = null == refuseBatch ? null : refuseBatch.getSecCheckDesc();
			break;
		case FAILURE:// ("交易失败"),
			status = PaymentStatusExt.FAILURE;
			centerStatus = PayCenterPayStatus.FAILURE;
			desc = info.getRtnBankMsg();
			break;
		case SUCCESS:// ("交易成功"),
			status = PaymentStatusExt.SUCCESS;
			desc = info.getRtnBankMsg();
			centerStatus = PayCenterPayStatus.SUCCESS;
			break;
		default:
			notifyFlag = false;
			break;
		}
		if (!notifyFlag) {
			return;
		}
		StringBuffer xmlSb = xmlMap.get(info.getSystemSource());
		if (null == xmlSb) {
			xmlSb = new StringBuffer(
					"<?xml version=\"1.0\" encoding=\"UTF-8\" ?><payout-result type=\"payout\"  sign=\"#signVal#\">");
		}

		// 在此处需要加入是否是付款中心数据记录的判断，若是付款中心则需要调用付款中心通知处理逻辑
		String tradeOutBusinessNo = info.getTradeOutBussinessNo();// 获取外部交易业务编号用以回查付款中心记录表
		if (!StringUtils.isEmpty(tradeOutBusinessNo)) {
			PayoutReqInfo reqInfo = payBusinessDao.queryPayInfoByBusinessNo(tradeOutBusinessNo);
			// 若在付款业务表中能查到相应的付款记录表示该笔付款是付款中心数据则需要通过另外方式实现
			if (null != reqInfo) {
				// 更新付款中心付款业务表状态
				if (null == desc) {
					desc = info.getRemark();
					if (null == desc) {
						desc = "";
					}
				}

				payBusinessDao.updateStatus(reqInfo.getId(), centerStatus, desc, info.getEndTime());
				// 如果是手动的就不会去组装报文 移到更新付款中心状态之后，判断是否组装报文 2014-10-21 start
				if (("SDLR").equals(reqInfo.getCmdType()) || ("").equals(reqInfo.getCmdType())) {
					logger.info("如果是手动的就不会去组装报文,temInfo=:{}", reqInfo);
					return;
				}
				// 如果是手动的就不会去组装报文 移到更新付款中心状态之后，判断是否组装报文 2014-10-21 end
				reqInfo = payBusinessDao.queryPayoutReqInfoById(reqInfo.getId());
				String merNo = reqInfo.getMerNo();
				MerInfoParam param = new MerInfoParam();
				param.setMerNo(merNo);
				MerInfo merInfo = merInfoDao.queryMerInfo(param);
				xmlSb.append("<item tradeNo=\"").append(reqInfo.getTradeNo())// 外部交易订单编号
						.append("\">")// 付款编号
						.append("<tradeExt1>").append(reqInfo.getTradeExt1()).append("</tradeExt1>")
						.append("<tradeExt2>").append(reqInfo.getTradeExt2()).append("</tradeExt2>")
						.append("<payBusinessNo>").append(reqInfo.getPayBusinessNo()).append("</payBusinessNo>")
						.append("<payReqTime>").append(reqInfo.getPayReqTime()).append("</payReqTime>")
						.append("<payEndTime>").append(reqInfo.getPayEndTime()).append("</payEndTime>")
						.append("<status>").append(reqInfo.getStatus().name()).append("</status>")
						.append("<bankRetCode>").append(toBlank(reqInfo.getBankRetCode())).append("</bankRetCode>")
						.append("<bankRetMsg>").append(toBlank(reqInfo.getBankRetMsg())).append("</bankRetMsg>")
						.append("<merNo>").append(reqInfo.getMerNo()).append("</merNo>").append("<url>")
						.append(merInfo.getNotifyUrl()).append("</url>").append("<merKey>").append(merInfo.getMerKey())
						.append("</merKey>").append("</item>");
				xmlMap.put(info.getSystemSource(), xmlSb);
				return;
			}

		}

		xmlSb.append("<item tradeOutNo=\"").append(info.getTradeOutNo())// 外部交易订单编号
				.append("\" payoutNo=\"").append(info.getPayoutNo()).append("\">")// 付款编号
				.append("<beginTime>").append(DateUtil.getDateString(info.getBeginTime(), DateUtil.DATA_FORMAT_PATTERN))
				.append("</beginTime>").append("<endTime>")
				.append(DateUtil.getDateString(info.getEndTime(), DateUtil.DATA_FORMAT_PATTERN)).append("</endTime>")
				.append("<amt>").append(info.getAmt()).append("</amt>").append("<shouldAmt>")
				.append(toBlank(info.getShouldAmt())).append("</shouldAmt>").append("<deductionAmt>")
				.append(toBlank(info.getDeductionAmt())).append("</deductionAmt>").append("<dctAcqTime>")
				.append(DateUtil.getDateString(info.getDeducationDate(), DateUtil.DATA_FORMAT_PATTERN))
				.append("</dctAcqTime>") // modfiy 抵扣时加入抵扣日期
				.append("<fee>").append(toBlank(info.getFee())).append("</fee>").append("<reqBankSn>")
				.append(toBlank(info.getReqBankSn())).append("</reqBankSn>").append("<rtnBankCode>")
				.append(toBlank(info.getRtnBankCode())).append("</rtnBankCode>").append("<status>")
				.append(null == status ? "" : status.name()).append("</status>").append("<returnMsg>")
				.append(toBlank(desc)).append("</returnMsg>").append("</item>");
		xmlMap.put(info.getSystemSource(), xmlSb);
		// logger.info("通知业务系统的报文:{}"+bXml.toString());
	}

	private String toBlank(Object obj) {
		return null == obj ? "" : obj + "";
	}

	/**
	 * 方法说明：<br>
	 * 把结果发送订单
	 *
	 * @param orderNotify
	 * @param meta
	 */
	private void sendOrder(List<PayConfirmRequest> orderNotify, StringBuffer meta) throws ServiceException {
		if (orderNotify.size() == 0) {
			return;
		}
		logger.info("开始调用订单系统(银行交易结果),参数 = " + meta.toString());
		List<PayResponse> orderRespList = null;
		try {
			orderRespList = this.orderService.bankConfirmPayAcc(orderNotify);
		} catch (Exception ex) {
			logger.error("调用订单系统(发送付款结果)异常:", ex);
		}
		logger.info("订单系统调用结束(银行交易结果)");
		if (orderRespList == null || orderRespList.size() == 0) {
			logger.info("订单系统返回结果: null");
			return;
		}
		logger.info("调用订单系统(银行交易结果),订单系统处理条数size:[{}]", orderRespList.size());
		// 更新交互信息
		updatePayResponse(orderRespList, ExchangeType.SEND_AFTER);
	}

	/**
	 * 方法说明：<br>
	 * 把退票结果发送订单
	 *
	 * @param orderNotify
	 * @param meta
	 */
	private void sendBounceOrder(List<CancelBankEnterpriseRequest> orderNotify, StringBuffer meta)
			throws ServiceException {
		if (orderNotify.size() == 0) {
			return;
		}
		logger.info("开始调用订单系统(退票),参数: {}", meta.toString());
		List<PayResponse> respList = null;
		try {
			respList = this.orderService.cancelBankEnterprise(orderNotify);
		} catch (Exception ex) {
			logger.error("调用订单系统(退票)异常:", ex);
		}
		logger.info("订单系统调用结束(退票)");
		if (respList == null || respList.size() == 0) {
			logger.info("订单系统返回结果(退票): null");
			return;
		}
		logger.info("调用订单系统结束(退票),size:[{}]", respList.size());
		// 更新交互信息
		updatePayResponse(respList, ExchangeType.BOUNCE);
	}

	/**
	 * 方法说明：<br>
	 * 更新订单返回的交互信息
	 *
	 * @param orderRespList
	 */
	private void updatePayResponse(List<PayResponse> orderRespList, ExchangeType exchangeType) {
		// 更新交互信息
		StringBuffer buf = new StringBuffer();
		for (PayResponse payInfo : orderRespList) {
			buf.setLength(0);
			try {
				// 打印日志
				buf.append("[payNo:").append(payInfo.getPayNo()).append(",").append("retrunCode:")
						.append(payInfo.getReturnCode()).append(",").append("returnMsg:").append(payInfo.getReturnMsg())
						.append(",").append("tradeNo:").append(payInfo.getTradeNo()).append(",").append("tradeOutNo:")
						.append(payInfo.getTradeOutNo()).append(",").append("payDate:").append(payInfo.getPayDate())
						.append("]");
				logger.info("付款信息[交互流水:{}],更新订单系统返回返回信息:{}", payInfo.getTradeOutNo(), buf.toString());
				exchangeService.updateOrderResp(payInfo.getTradeNo(), payInfo.getTradeOutNo(),
						payInfo.getReturnCode() + "", payInfo.getReturnMsg(), exchangeType);
			} catch (Exception ex) {
				logger.error("付款信息[交互流水:" + payInfo.getTradeOutNo() + "],更新订单系统返回信息异常 = ", ex);
			}
		}
	}

	/**
	 * 方法说明：<br>
	 * 异步通知业务系统
	 * 
	 * @author sfhq270 周丽佩 modify 2014-10-10（将task任务由callable 改为 runnable形式）
	 * @param xmlMap
	 * @param prefix
	 */
	private void sendXml(Map<SystemSource, StringBuffer> xmlMap, String prefix) {
		if (xmlMap.size() == 0) {
			return;
		}
		List<String> pKey = new ArrayList<String>();
		for (Iterator<SystemSource> it = xmlMap.keySet().iterator(); it.hasNext();) {
			pKey.add(prefix + it.next());
		}
		List<ParamInfo> urls = paramDao.findByKeys(pKey);
		if (null == urls || urls.size() == 0) {
			return;
		}
		ParamInfo param = null;
		// List<notify> tasks = new ArrayList<notify>();
		logger.info("异步通知各业务系统...");
		for (Iterator<ParamInfo> it = urls.iterator(); it.hasNext();) {
			param = it.next();
			if (StringUtils.isEmpty(param.getParamValue())) {
				continue;
			}
			// tasks.add(new notify(param, xmlMap,prefix));
			executor.execute(new NotifyExecutor(param, xmlMap, prefix));
		}
		// if(tasks.size() == 0) {
		// return;
		// }
		// logger.info("异步通知各业务系统...");
		// try {
		// executor.invokeAll(tasks);
		// } catch (InterruptedException e) {
		// logger.error("通知其它系统异常", e);
		// }
	}

	/**
	 * 类说明：<br>
	 * 退票通知线程
	 * <p>
	 * 详细描述：<br>
	 * </p>
	 * 
	 * @author sfhq270 周丽佩 CreateDate: 2014-10-10
	 */
	private class NotifyExecutor implements Runnable {
		private String url;
		private String xml;
		private SystemSource src;

		public NotifyExecutor(ParamInfo param, Map<SystemSource, StringBuffer> xmlMap, String keyPrefix) {
			this.url = param.getParamValue();
			this.src = SystemSource.valueOf(param.getParamKey().substring(keyPrefix.length()));
			this.xml = new StringBuffer("result=").append(xmlMap.get(src)).append("</payout-result>").toString();
		}

		@Override
		public void run() {
			try {
				HttpHelper.sendByPost(url, xml, Encoding.UTF_8);
				logger.info(String.format("通知[%s]完成(URL: %s, 报文: %s)", src, url, xml));
			} catch (Exception e) {
				logger.error(String.format("通知[%s]异常(URL: %s, 报文: %s)", src, url, xml), e);
				RepeatInvokeHelper.getInstance().addQueue(new PayoutRespRepeatInvoke(url, xml, src));
			}
		}
	}

	/**
	 * 类说明：<br>
	 * 退票通知线程
	 * 
	 * <p>
	 * 详细描述：<br>
	 * 
	 * </p>
	 * 
	 * @author 329202 符瑜鑫(Ricky Fu)
	 * @author 361424 詹锡宁 CreateDate: 2013-10-21
	 */
	// private class notify implements Callable<String> {
	// private String url;
	// private String xml;
	// private SystemSource src;
	// public notify(ParamInfo param, Map<SystemSource, StringBuffer>
	// xmlMap,String keyPrefix) {
	// this.url = param.getParamValue();
	// this.src =
	// SystemSource.valueOf(param.getParamKey().substring(keyPrefix.length()));
	// this.xml = new
	// StringBuffer("result=").append(xmlMap.get(src)).append("</payout-result>").toString();
	// }
	// @Override
	// public String call() throws Exception {
	// try {
	// HttpHelper.sendByPost(url, xml, Encoding.UTF_8);
	// logger.info(String.format("通知[%s]完成(URL: %s, 报文: %s)", src, url, xml));
	// } catch (Throwable e) {
	// logger.error(String.format("通知[%s]异常(URL: %s, 报文: %s)", src, url, xml),
	// e);
	// RepeatInvokeHelper.getInstance().addQueue(new PayoutRespRepeatInvoke(url,
	// xml, src));
	// }
	// return null;
	// }
	// }
	//
	/**
	 * 类说明：<br>
	 * 付款通知失败时的重复调用尝试实现
	 * 
	 * <p>
	 * 详细描述：<br>
	 * 
	 * </p>
	 * 
	 * @author 329202 符瑜鑫(Ricky Fu)
	 * 
	 *         CreateDate: 2013-12-21
	 */
	private class PayoutRespRepeatInvoke implements IRepeatInvoke {
		private String url;
		private String xml;
		private SystemSource src;

		public PayoutRespRepeatInvoke(String url, String xml, SystemSource src) {
			this.url = url;
			this.xml = xml;
			this.src = src;
		}

		@Override
		public void execute() {
			for (int i = 0; i < 3; i++) {// 遍历次数
				try {
					Thread.sleep(notifyInterval);// 超时调用遍历间隔时间
				} catch (InterruptedException e) {
					logger.error("线程交互异常", e);
					continue;
				}
				try {
					HttpHelper.sendByPost(url, xml, Encoding.UTF_8);
					logger.info(String.format("[第%s次]通知[%s]完成(URL: %s, 报文: %s)", i + 1, src, url, xml));
					break;
				} catch (Exception e) {
					logger.info(String.format("[第%s次]通知[%s]完成(URL: %s, 报文: %s)", i + 1, src, url, xml), e);
				}
			}
		}
	}

	@Override
	public void sendPayRespForEbank(List<PayoutInfo> payoutNos) throws ServiceException {
		try {
//			List<PayoutInfo> batchNotify = payoutInfoDao.queryByPayoutNos(payoutNos);
			this.sendOrderResp(payoutNos, ExchangeType.SEND_AFTER);
		} catch (Exception e) {
			logger.error("发业务系统异常", e);
		}
	}
}
