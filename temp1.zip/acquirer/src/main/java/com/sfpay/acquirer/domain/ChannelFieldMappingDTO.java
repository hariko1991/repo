package com.sfpay.acquirer.domain;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：<br>
 * 字段映射DTO
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2015年12月9日
 */
public class ChannelFieldMappingDTO extends BaseEntity {

	private static final long serialVersionUID = 7392611596274329659L;

	/**
	 * 映射关系编码
	 */
	private String mappingCode;
	/**
	 * 映射字段
	 */
	private String mappingField;
	/**
	 * 源值（转换前）
	 */
	private String origValue;
	/**
	 * 目标值（转换后）
	 */
	private String destValue;
	/**
	 * 默认映射标志：Y：默认;N:特殊
	 */
	private String defaultFlag;
	/**
	 * 备注
	 */
	private String remark;

	public String getMappingCode() {
		return mappingCode;
	}

	public void setMappingCode(String mappingCode) {
		this.mappingCode = mappingCode;
	}

	public String getMappingField() {
		return mappingField;
	}

	public void setMappingField(String mappingField) {
		this.mappingField = mappingField;
	}

	public String getOrigValue() {
		return origValue;
	}

	public void setOrigValue(String origValue) {
		this.origValue = origValue;
	}

	public String getDestValue() {
		return destValue;
	}

	public void setDestValue(String destValue) {
		this.destValue = destValue;
	}

	public String getDefaultFlag() {
		return defaultFlag;
	}

	public void setDefaultFlag(String defaultFlag) {
		this.defaultFlag = defaultFlag;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

}
