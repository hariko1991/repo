/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.domain;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 类说明：<br>
 * 各系统红冲或补单调账结果定义.
 * 
 * <p>
 * 详细描述：<br>
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-11-14
 */
public class ReconChangeRs extends BaseEntity {
	private static final long serialVersionUID = -6936793626936870458L;
	/**
	 * 业务流水号
	 */
	private String businessNo;
	/**
	 * 支付流水号
	 */
	private String payNo;
	/**
	 * 交易流水号
	 */
	private String tradeNo;

	public String getBusinessNo() {
		return businessNo;
	}

	public void setBusinessNo(String businessNo) {
		this.businessNo = businessNo;
	}

	public String getPayNo() {
		return payNo;
	}

	public void setPayNo(String payNo) {
		this.payNo = payNo;
	}

	public String getTradeNo() {
		return tradeNo;
	}

	public void setTradeNo(String tradeNo) {
		this.tradeNo = tradeNo;
	}
}
