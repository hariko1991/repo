package com.sfpay.acquirer.domain;

import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 
 * 
 * 类说明：<br>
 * 人工操作　修改参数
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-9-9
 */
public class PayoutOffline extends BaseEntity{

	private static final long serialVersionUID = 2058612052947194656L;

	/**
	 * 付款编号
	 */
	private String payoutNo;
	
	/**
	 * 交易状态
	 */
	private PayoutStatus status;
	
	/**
	 * 人工操作标识
	 */
	private YNFlag offlineFlag;
	
	/**
	 * 人工操作备注
	 */
	private String offlineRemark;
	
	/**
	 * 人工操作员
	 */
	private String offlineOper;
	
	/**
	 * 原人工操作标识
	 */
	private YNFlag oldOfflineFlag;
	
	/**
	 * 原交易状态
	 */
	private PayoutStatus oldStatus;

	public String getPayoutNo() {
		return payoutNo;
	}

	public void setPayoutNo(String payoutNo) {
		this.payoutNo = payoutNo;
	}

	public PayoutStatus getStatus() {
		return status;
	}

	public void setStatus(PayoutStatus status) {
		this.status = status;
	}

	public YNFlag getOfflineFlag() {
		return offlineFlag;
	}

	public void setOfflineFlag(YNFlag offlineFlag) {
		this.offlineFlag = offlineFlag;
	}

	public String getOfflineRemark() {
		return offlineRemark;
	}

	public void setOfflineRemark(String offlineRemark) {
		this.offlineRemark = offlineRemark;
	}

	public String getOfflineOper() {
		return offlineOper;
	}

	public void setOfflineOper(String offlineOper) {
		this.offlineOper = offlineOper;
	}

	public YNFlag getOldOfflineFlag() {
		return oldOfflineFlag;
	}

	public void setOldOfflineFlag(YNFlag oldOfflineFlag) {
		this.oldOfflineFlag = oldOfflineFlag;
	}

	public PayoutStatus getOldStatus() {
		return oldStatus;
	}

	public void setOldStatus(PayoutStatus oldStatus) {
		this.oldStatus = oldStatus;
	}
	
	
}
