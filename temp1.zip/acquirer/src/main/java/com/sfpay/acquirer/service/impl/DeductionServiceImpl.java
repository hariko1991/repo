/**
 * =================================================================
 * 版权所有 2011-2013 深圳市泰海网络科技服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.dao.IDeductionInfoDao;
import com.sfpay.acquirer.dao.IDeductionLogDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.DeductionLog;
import com.sfpay.acquirer.domain.DeductionQueryParam;
import com.sfpay.acquirer.domain.DeductionQueryRlt;
import com.sfpay.acquirer.domain.NeedDeductionInfo;
import com.sfpay.acquirer.domain.NeedDeductionInfoQueryParam;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutQueryRlt;
import com.sfpay.acquirer.domain.PayoutRlt;
import com.sfpay.acquirer.enums.FreezeFlag;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.service.IDeductionService;
import com.sfpay.acquirer.service.SendPayoutResp;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework.base.utils.StringUtils;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：<br>
 * 抵扣业务处理实现类
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 *  
 * @author 400928 向鹏
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-9-9
 */
@Service("deductionService")
@HessianExporter
public class DeductionServiceImpl implements IDeductionService{
	
	private static final Logger logger = LoggerFactory.getLogger(DeductionServiceImpl.class);
	
	@Resource
	private IPayoutInfoDao payoutInfoDao;
	
	@Resource
    private SendPayoutResp sendPayoutResp;
	
	@Resource
	private IDeductionLogDao deductionLogDao;
	
	@Resource
	private IDeductionInfoDao deductDao;

	@Override
	public IPage<PayoutQueryRlt> queryNeedDeduction(DeductionQueryParam param, int pageNo, int pageSize)throws ServiceException {
		
		// 查询总记录数
		long count = payoutInfoDao.countNeedDeduction(param);
		List<PayoutQueryRlt> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			list = payoutInfoDao.queryNeedDeduction(param, start, end);
		}
		return new Page<PayoutQueryRlt>(list, count, pageNo, pageSize);		
	}

	@Override
	public PayoutRlt queryDeductionInfo(String payoutNo)throws ServiceException {
		return payoutInfoDao.queryPayoutByPayoutNo(payoutNo);
		
	}
	
	@Override
	public void doDeduction(String operator,String desc, String payoutNo, Long deductionAmt,FreezeFlag freezeFlag)throws ServiceException {
		//参数信息验证
		if(StringUtils.isEmpty(operator)){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"抵扣操作人不能为空！");		
		}
		if(StringUtils.isEmpty(desc)){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"抵扣描述不能为空！");		
		}
		if(StringUtils.isEmpty(payoutNo)){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"抵扣支付指令编号不能为空！");		
		}
		if(deductionAmt==null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"抵扣金额不能为空!");
		}
		if(freezeFlag == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"冻结类型不能为空!");
		}
//		if(deductionAmt==0L){
//			throw new ServiceException(InfoCode.ERROR_MSG,"抵扣金额为0无需进行抵扣！");
//		}
		
//		PayoutRlt payoutRtl=payoutInfoDao.queryPayoutByPayoutNo(payoutNo);
		PayoutInfo payoutRtl = payoutInfoDao.findByPayoutNo(payoutNo,freezeFlag);
		
		if(payoutRtl==null){
			throw new ServiceException(InfoCode.ERROR_MSG,"找不到支付流水号为"+payoutNo+"的支付指令信息，无法进行抵扣！");
		}
		
		if(!PayoutStatus.INIT.equals(payoutRtl.getStatus())){
			throw new ServiceException(InfoCode.ERROR_MSG,"交易指令"+payoutNo+"的交易状态非INIT状态无法进行抵扣！");
		}
		if(!freezeFlag.equals(payoutRtl.getFreezeFlag())){
			throw new ServiceException(InfoCode.ERROR_MSG,"交易指令"+payoutNo+"的冻结状态与不匹配，无法进行抵扣！");
		}
		if(deductionAmt>payoutRtl.getShouldAmt()){
			throw new ServiceException(InfoCode.ERROR_MSG,"抵扣金额大于应付金额无法进行抵扣！");
		}
	    
		Long amt=payoutRtl.getShouldAmt()-deductionAmt;
		logger.info("支付指令编号{}的抵扣后支付金额为：{}分",payoutNo,amt);
		int updateCnt=0;
		if(amt==0L){			
			updateCnt=payoutInfoDao.updateDeductionInfo(payoutNo,operator, desc, deductionAmt,amt,PayoutStatus.SUCCESS,freezeFlag);
		    if(updateCnt==1){
			  List<PayoutInfo> lists=new ArrayList<PayoutInfo>();
			  PayoutInfo info=payoutInfoDao.queryPayoutInfoByPayNo(payoutNo);
			  lists.add(info);
			  //发送业务系统
			  sendPayoutResp.sendResp(lists);
		    }
		}else{
			payoutInfoDao.updateDeductionInfo(payoutNo,operator, desc, deductionAmt,amt,null,freezeFlag);
		}
		
		//保存抵扣历史　
		Long curdeductionAmt = deductionAmt - (payoutRtl.getDeductionAmt() == null ? 0L:payoutRtl.getDeductionAmt());//本次抵扣金额
		DeductionLog log = converToDeductionLog(payoutRtl, operator, desc, deductionAmt, amt,curdeductionAmt);
		try {
			deductionLogDao.save(log);
		} catch (Exception e) {
			logger.error("保存抵扣历史异常",e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE,"保存抵扣历史异常",e);
		}
		
		logger.info("支付指令编号{}的抵扣业务处理完成！",payoutNo);
		
	}

	@Override
	public IPage<DeductionQueryRlt> queryDeductionInfos(DeductionQueryParam param,int pageNo,int pageSize) throws ServiceException {
		// 查询总记录数
		long count = deductionLogDao.countDeductionInfos(param);
		List<DeductionQueryRlt> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			try{
				list = deductionLogDao.queryDeductionInfos(param, start, end);
			}catch(Exception ex){
				logger.error("查询异常",ex);
				throw new ServiceException(InfoCode.DATABASE_FAILURE,"查询异常",ex);
			}
		}
		return new Page<DeductionQueryRlt>(list, count, pageNo, pageSize);

	}
	
	/**
	 * 方法说明：<br>
	 * 
	 *
	 * @return
	 */
	private DeductionLog converToDeductionLog(PayoutInfo payoutInfo,String operator, String desc, Long deductionAmt,Long amt,Long curdeductionAmt){
		DeductionLog log = new DeductionLog();
		log.setAmt(amt);//应实付金额
		log.setBeginTime(payoutInfo.getBeginTime());
		log.setDeducationDate(new Date());
		log.setDeductionAmt(deductionAmt);
		log.setCurDeductionAmt(curdeductionAmt);
		log.setDeductionOper(operator);
		log.setDeductionRemark(desc);
		log.setPayeeAcctName(payoutInfo.getPayeeAcctName());
		log.setPayeeAcctNo(payoutInfo.getPayeeAcctNo());
		log.setPayoutNo(payoutInfo.getPayoutNo());
		log.setShouldAmt(payoutInfo.getShouldAmt());//应付金额,不变
		log.setSystemSource(payoutInfo.getSystemSource());
		log.setTradeOutBussinessNo(payoutInfo.getTradeOutBussinessNo());
		log.setTradeOutNo(payoutInfo.getTradeOutNo());
		return log;
	}
	
	@Override
	public void doAddDeductInfo(NeedDeductionInfo info) throws ServiceException {
		String custAccNo=info.getCustAccNo();
		String custName=info.getCustName();
		Long disputeAmt=info.getDisputeAmt();
		String operator=info.getOperatorId();
		Date recDate=info.getRecDay();
		if(StringUtils.isEmpty(custAccNo)){
			throw new ServiceException(InfoCode.PARAM_INVALID,"客户月结账号不能为空!");
		}
		if(StringUtils.isEmpty(custName)){
			throw new ServiceException(InfoCode.PARAM_INVALID,"客户名称不能为空!");
		}
		if(disputeAmt==0){
			throw new ServiceException(InfoCode.PARAM_INVALID,"争议金额不能为零!");
		}
		if(StringUtils.isEmpty(operator)){
			throw new ServiceException(InfoCode.PARAM_INVALID,"操作员不能为空!");
		}
		if(recDate==null){
			info.setRecDay(new Date());
		}
		deductDao.addDeductionInfo(info);		
	}

	@Override
	public IPage<NeedDeductionInfo> queryNeedDeductionInfos(NeedDeductionInfoQueryParam param, int pageNo, int pageSize)throws ServiceException {
		long count = deductDao.countNeedDeductionInfos(param);
		List<NeedDeductionInfo> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			list = deductDao.queryNeedDeductionInfos(param, start, end);
		}
		return new Page<NeedDeductionInfo>(list, count, pageNo, pageSize);

	}
}
