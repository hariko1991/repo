package com.sfpay.acquirer.gate.b2e.command;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutRespResult;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.acquirer.enums.CmdStatus;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.gate.b2e.BaseCommand;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.QueryBatchTransferInfo;
import com.sfpay.acquirer.gate.b2e.domain.QueryTransferSubInfo;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 
 * 类说明：<br>
 * 查询支付结果(对公)
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-5-6
 */
public class QueryBatchTransfer extends BaseCommand {
	
	private BatchInfo bi;
	private List<PayoutInfo> pis;
	private BankCode bankCode;
	
	public QueryBatchTransfer(){
		super(TradeCodeB2E.QUERY_BATCH_TRANSFER);
	}
	
	public QueryBatchTransfer(BatchInfo bi ,List<PayoutInfo> pis,BankCode bankCode){
		super(TradeCodeB2E.QUERY_BATCH_TRANSFER);
		this.bi = bi;
		this.pis = pis;
		this.bankCode = bankCode;
	}

	@Override
	protected BeanBase assemble(BankProperty property) throws Exception {
		try{
			PayoutInfo info = pis.get(0);
			
			//设置报文头
			BeanBase bean = new BeanBase(bankCode, super.tradeCodeB2E);
			/**
			 * 用于结算中心报文序列号
			 * sfh270   2014-12-03
			 */
			bean.setSeqNo(CUID.getSZFSMsgNo());
			bean.setBankProperties(property);
			
			
			QueryBatchTransferInfo  detail = new QueryBatchTransferInfo();
			detail.setSerialId(CUID.generateId4B2E(20));
			detail.setMainSerialId(bi.getReqBankSn());
			detail.setPayerAccNo(info.getPayerAcctNo());
			detail.setPayerAccName(info.getPayerAcctName());
			detail.setPayerCity(info.getPayerAcctCityName());
			detail.setPayerOpenBranchName(info.getPayerBranchName());
			detail.setPayerProv(info.getPayerAcctProvince());
			detail.setSendTime(DateUtil.getCDateString(DateUtil.DATA_FORMAT_PATTERN));
			Date queryDate = bi.getPayBatchDate() == null?bi.getSecCheckDate():bi.getPayBatchDate();
			detail.setTradeTime(DateUtil.getDateString(queryDate,DateUtil.DATA_FORMAT_PATTERN_2));
			detail.setBatchStatus(bi.getStatus());// 批次状态 sfhq814 2015-8-13
			List<QueryTransferSubInfo> subInfoList = new ArrayList<QueryTransferSubInfo>();
			//设置查询子信息
			long totalAmt = 0l;
			int totalCnt = 0;
			for(PayoutInfo pi : pis){
				QueryTransferSubInfo subInfo = new QueryTransferSubInfo();
				subInfo.setSubSerialId(pi.getReqBankSn());
				subInfo.setAmt(pi.getAmt());
				subInfo.setPayeeAccNo(pi.getPayeeAcctNo());
				//设定报文明细请求实例号  add by sfhq272  20150521
				subInfo.setRtnBankSn(pi.getRtnBankSn());
				totalAmt += pi.getAmt();
				totalCnt += 1;
				subInfoList.add(subInfo);
			}
			
			detail.setSubInfo(subInfoList);
			detail.setTotalAmt(totalAmt);
			detail.setTotalCount(totalCnt);
			bean.setBusDetailBeanBase(detail);
			
			
			return bean;
		}catch(Exception ex){
			logger.error("批次[批次号:"+bi.getBatchCode()+"]生成查询批量对私支付结果报文异常:",ex);
			throw new ServiceException(InfoCode.FAILURE, ex);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	protected PayoutRespResult parseMsg(
			com.sfpay.acquirer.gate.b2e.domain.BeanBase respBean)
			throws Exception {
		PayoutRespResult resp = new PayoutRespResult();
		
		QueryBatchTransferInfo detail = (QueryBatchTransferInfo)respBean.getBusDetailBeanBase();
		//转换批次信息
		resp.setBatchReqBankSn(detail.getMainSerialId());
		resp.setReqBankSn("");
		resp.setRtnBankCode(detail.getBankRetCode());
		if(detail.getBankRetMsg() == null || "".equals(detail.getBankRetMsg())){
			resp.setRtnBankMsg(detail.getRetMsg());
		}else {
			resp.setRtnBankMsg(detail.getBankRetMsg());
		}
		resp.setRtnBankSn("");
		resp.setCmdStatus(CmdStatus.convertToCmdStatus(detail.getRetCode()));
		resp.setRemark(detail.getRetMsg());
		
		//转换付款信息
		List<PayoutInfo> payoutDetail = null;
		List<QueryTransferSubInfo> subInfoList = detail.getSubInfo();
		if(subInfoList != null){
			payoutDetail = new ArrayList<PayoutInfo>();
			for(QueryTransferSubInfo subInfo : subInfoList){
				PayoutInfo info = new PayoutInfo();
				
				info.setAmt(subInfo.getAmt());
				info.setReqBankSn(subInfo.getSubSerialId());
				info.setRtnBankCode(subInfo.getBankRetCode());
				info.setRtnBankMsg(subInfo.getBankRetMsg());
				info.setPayeeAcctNo(subInfo.getPayeeAccNo());
				info.setStatus(PayoutStatus.convertToPayoutStatus(subInfo.getCmdStat()));
				if(StringUtils.isNotBlank(subInfo.getRtnBankSn())){
					info.setRtnBankSn(subInfo.getRtnBankSn());//招行返回流程实例号  2015-08-12
				}
				
				payoutDetail.add(info);
			}
		}
		resp.setPayoutDetail(payoutDetail);
		//结算中心返回失败，则整个批次全部失败.批次返回已受理，则所有明细全部返回已受理。2014-12-25
		if(StringUtils.isNotBlank(detail.getRetCode())){
			if(("4").equals(detail.getRetCode())){
				resp.setStatus(BatchStatus.REJECT);
			}else if(("5").equals(detail.getRetCode())){
				resp.setStatus(BatchStatus.RECEIVED);
			}else{
				resp.setStatus(null);
			}
		}else{
			  resp.setStatus(null);
		}
		return resp;
	}


}
