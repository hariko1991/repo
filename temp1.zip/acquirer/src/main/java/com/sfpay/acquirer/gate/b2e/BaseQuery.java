package com.sfpay.acquirer.gate.b2e;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IAccountInfoDao;
import com.sfpay.acquirer.domain.AccountBalance;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.AccountTransInfo;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.HisAcctTxQueryParam;
import com.sfpay.acquirer.gate.b2e.command.QueryCurBal;
import com.sfpay.acquirer.gate.b2e.command.QueryCurDtl;
import com.sfpay.acquirer.gate.b2e.command.QueryHisDtl;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.QueryCurDtlInfo;
import com.sfpay.acquirer.gate.b2e.domain.QueryHisDtlInfo;
import com.sfpay.acquirer.gate.b2e.domain.TransDtlInfo;
import com.sfpay.acquirer.gate.b2e.service.IBankService;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br> 查询基类
 * 
 * 
 * </p>
 * 
 * @author sfhq272 sfhq272
 * 
 * CreateDate: 2015-6-25
 */
@SuppressWarnings("deprecation")
public abstract class BaseQuery {
	protected final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private IAccountInfoDao accountInfoDao;

	protected abstract AccountBalance convert2AccountBalance(BeanBase bean);

	protected abstract List<AccountTransInfo> convert2CurAccountTransInfoList(List<TransDtlInfo> transInfos);

	protected abstract List<AccountTransInfo> convert2HisAccountTransInfoList(List<TransDtlInfo> transInfos);

	public AccountBalance doQueryAccountBalance(BankProperty property,
			AccountInfo acct, IBankService bankService) throws ServiceException {
		//组查询余额请求报文
		QueryCurBal req = new QueryCurBal(acct);
		BeanBase reqBean = null;
		try {
			reqBean = req.assemble(property);
		} catch (Exception ex) {
			logger.error("组装查询余额报文异常",ex);
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "组装查询余额报文异常:"+ex);
		}

		if(StringUtils.isEmpty(reqBean.toReqMsg())) {
			logger.debug("查询余额请求报文不能为空");
			return null;
		}
		logger.info("查询余额请求的报文内容:\n{}", reqBean.toString());

		//发送查询请求
		BeanBase respBase = null;
		try{
			respBase = bankService.service(reqBean);
		}catch(Exception ex){
			logger.error("查询余额异常",ex);
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "查询余额异常",ex);
		}

		if(respBase == null){
			logger.error("查询余额报文解析失败,解析bean为null");
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "查询余额报文解析失败,解析bean为null");
		}

		logger.info("查询余额响应结果:{};具体信息：{}",respBase.getBusDetailBeanBase().getRetCode(),respBase.toString());
		if(!"0".equals(respBase.getBusDetailBeanBase().getRetCode())){
			logger.error("查询余额失败");
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "查询余额失败,响应结果:["+respBase.getBusDetailBeanBase().getRetCode()+"]-["+respBase.getBusDetailBeanBase().getRetMsg()+"]");
		}

		return convert2AccountBalance(respBase);
	}

	public List<AccountTransInfo> doQueryCurAccountTransList(
			BankProperty property, AccountInfo acct, IBankService bankService) throws ServiceException {
		//组查询当天交易
		QueryCurDtl req=new QueryCurDtl(acct);  
		BeanBase reqBean = null;
		try {
			reqBean = req.assemble(property);
		} catch (Exception ex) {
			logger.error("组装查询当天交易报文异常",ex);
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "组装查询当天交易报文异常:",ex);
		}

		if(StringUtils.isEmpty(reqBean.toReqMsg())) {
			logger.debug("查询当天交易报文不能为空");
			return null;
		}
		logger.info("查询当天交易请求的报文内容:\n{}", reqBean.toString());

		//发送查询请求
		//解析报文
		BeanBase respBean = null;
		try{
			respBean = bankService.service(reqBean);
		}catch(Exception ex){
			logger.error("查询当天明细报文解析异常", ex);
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "查询当天明细报文解析异常", ex);
		}
		if(respBean == null){
			logger.error("查询当天明细报文解析失败，解析bean为null");
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "查询当天明细报文解析失败，解析bean为null");
		}
		logger.info("查询当天明细响应结果:{};具体信息：{}",respBean.getBusDetailBeanBase().getRetCode(),respBean.toString());
		if(!"0".equals(respBean.getBusDetailBeanBase().getRetCode())){
			logger.error("查询当天明细失败");
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "查询当天明细失败,响应结果:["+respBean.getBusDetailBeanBase().getRetCode()+"]-["+respBean.getBusDetailBeanBase().getRetMsg()+"]");
		}
		
		List<TransDtlInfo> transDtlInfos = ((QueryCurDtlInfo)respBean.getBusDetailBeanBase()).getDtlInfoList();
		if(null != transDtlInfos && transDtlInfos.size() != 0){
			logger.info("查询历史交易结果条数：[{}]", transDtlInfos.size());
			return convert2CurAccountTransInfoList(transDtlInfos);
		}else{
			logger.info("查询历史交易结果条数：[{}]", 0);
			return null;
		}
	}


	public List<AccountTransInfo> doQueryHisAccountTransList(
			BankProperty property, HisAcctTxQueryParam param, IBankService bankService)
					throws ServiceException {
		//组查询账户历史
		AccountInfo accountInfo = accountInfoDao.queryAccountInfoByAccountNo(param.getAccountNo(),null);
		QueryHisDtl req=new QueryHisDtl(accountInfo,param);  
		BeanBase reqBean = null;
		try {
			reqBean = req.assemble(property);
		} catch (Exception ex) {
			logger.error("组装查询历史交易报文异常",ex);
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "组装查询历史交易报文异常:", ex);
		}

		if(StringUtils.isEmpty(reqBean.toReqMsg())) {
			logger.debug("查询历史交易报文不能为空");
			return null;
		}
		logger.info("查询历史交易请求的报文内容:\n{}", reqBean.toString());

		//发送查询请求
		BeanBase respBean = null;
		try{
			respBean = bankService.service(reqBean);
		}catch(Exception ex){
			logger.error("查询历史明细报文解析异常", ex);
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "查询历史明细报文解析异常", ex);
		}

		if(respBean == null){
			logger.error("查询历史明细报文解析失败，解析bean为null");
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "查询历史明细报文解析失败，解析bean为null");
		}
		logger.info("查询历史明细响应结果:{};具体信息：{}",respBean.getBusDetailBeanBase().getRetCode(),respBean.toString());
		if(!"0".equals(respBean.getBusDetailBeanBase().getRetCode())){
			logger.error("查询历史明细失败");
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "查询历史明细失败,响应结果:["+respBean.getBusDetailBeanBase().getRetCode()+"]-["+respBean.getBusDetailBeanBase().getRetMsg()+"]");
		}
		
		List<TransDtlInfo> transDtlInfos = ((QueryHisDtlInfo)respBean.getBusDetailBeanBase()).getDtlInfoList();
		if(null != transDtlInfos && transDtlInfos.size() != 0){
			logger.info("查询历史交易结果条数：[{}]", transDtlInfos.size());
			return convert2HisAccountTransInfoList(transDtlInfos);
		}else{
			logger.info("查询历史交易结果条数：[{}]", 0);
			return null;
		}
	}

}
