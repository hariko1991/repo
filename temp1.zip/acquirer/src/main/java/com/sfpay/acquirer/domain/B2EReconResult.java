/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.domain;

import java.io.InputStream;
import java.util.List;

/**
 * 
 * 类说明：
 *  
 * 
 * <p>
 * 详细描述：
 *   
 * 
 * @author 321302 程俊杰
 *   
 * CreateDate: 2012-5-31
 */
public class B2EReconResult
{
	/**
	 * 银行对账内容
	 */
	private InputStream bankReconContent;
	
	/**
	 * 对账记录 
	 */
	private List<ReconOutTmp> reconList;

	public InputStream getBankReconContent()
	{
		return bankReconContent;
	}

	public void setBankReconContent(InputStream bankReconContent)
	{
		this.bankReconContent = bankReconContent;
	}

	public List<ReconOutTmp> getReconList()
	{
		return reconList;
	}

	public void setReconList(List<ReconOutTmp> reconList)
	{
		this.reconList = reconList;
	}
}
