/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.gate.b2e.service;

import java.util.List;

import com.sfpay.acquirer.domain.AccountBalance;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.AccountTransInfo;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.HisAcctTxQueryParam;
import com.sfpay.acquirer.gate.IAcqBiz;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：<br>
 * B2E查询接口类.
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2012-10-24
 */
public interface IQuery extends IAcqBiz{
	
	/**
	 * 方法说明：<br>
	 * 查询余额
	 *
	 * @param property
	 * @param acctNo
	 * @return
	 */
	public AccountBalance queryAccountBalance(BankProperty property,AccountInfo acct) throws ServiceException;

	/**
	 * 方法说明：
	 * 查询账户的当天交易明细
	 * @param bankCode 银行编码
	 * @param accountNo 账号
	 * @return
	 * @throws ServiceException
	 */
	public List<AccountTransInfo> queryCurAccountTransList(BankProperty property,AccountInfo acct)throws ServiceException;
	
	
	/**
	 * 方法说明：
	 * 查询账户的历史交易明细
	 * 不包括当天的
	 * @param param
	 * @return
	 * @throws ServiceException
	 */
	public List<AccountTransInfo> queryHisAccountTransList(BankProperty property,HisAcctTxQueryParam param)throws ServiceException;
}
