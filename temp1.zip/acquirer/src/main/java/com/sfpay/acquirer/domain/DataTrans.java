/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.domain;

import java.util.Date;

import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.CommonTradeType;
import com.sfpay.acquirer.enums.CmdStatus;
import com.sfpay.acquirer.enums.PackageFlag;

/**
 * 
 * 类说明：数据交互信息实体类
 *  
 * 
 * <p>
 * 详细描述：
 *   
 * 
 * @author 321302 程俊杰
 *   
 * CreateDate: 2012-3-16
 */
public class DataTrans extends AcqBaseEntity
{
	private static final long serialVersionUID = 1904279417582536717L;

	/**
	 * 银行编码
	 */
	private BankCode bankCode;
	
	/**
	 * 渠道编码
	 */
	private ChannelCode channelCode;
	
	/**
	 * 交易流水号（银行交易流水号（发送））
	 */
	private String serieNo;
	
	/**
	 * 交互业务类型
	 */
	private CommonTradeType dataTransType;
	
	/**
	 * 单笔/包标识<br>
	 * SINGLE单笔   BATCH批量
	 */
	private PackageFlag packageFlag;
	/**
	 * 交易发送报文信息
	 */
	private String requestMsg;
	
	/**
	 * 交易接收报文信息
	 */
	private String receiveMsg;
	
	/**
	 * 交易开始时间
	 */
	private Date beginTime;
	
	/**
	 * 交易结束时间
	 */
	private Date endTime;
	
	
	/**
	 * 指令状态<br>
	 *  INIT初始<br>
	 *  SUCCESS处理成功<br>
	 *  FAILURE处理失败<br>
	 */
	private CmdStatus cmdStatus;
	
	/**
	 * 银行返回流水号
	 */
	private String bankSerieNo;
	
	/**
	 * 银行返回码
	 */
	private String bankRetCode;
	
	/**
	 * 银行返回结果
	 */
	private String bankRetMsg;
	/**
	 * 支付系统返回代码
	 */
	private String payRetCode;
	
	public BankCode getBankCode()
	{
		return bankCode;
	}

	public void setBankCode(BankCode bankCode)
	{
		this.bankCode = bankCode;
	}

	public ChannelCode getChannelCode()
	{
		return channelCode;
	}

	public void setChannelCode(ChannelCode channelCode)
	{
		this.channelCode = channelCode;
	}

	public String getSerieNo()
	{
		return serieNo;
	}

	public void setSerieNo(String serieNo)
	{
		this.serieNo = serieNo;
	}

	public CommonTradeType getDataTransType()
	{
		return dataTransType;
	}

	public void setDataTransType(CommonTradeType dataTransType)
	{
		this.dataTransType = dataTransType;
	}

	
	public PackageFlag getPackageFlag() {
		return packageFlag;
	}

	public void setPackageFlag(PackageFlag packageFlag) {
		this.packageFlag = packageFlag;
	}

	public String getRequestMsg()
	{
		return requestMsg;
	}

	public void setRequestMsg(String requestMsg)
	{
		this.requestMsg = requestMsg;
	}

	public String getReceiveMsg()
	{
		return receiveMsg;
	}

	public void setReceiveMsg(String receiveMsg)
	{
		this.receiveMsg = receiveMsg;
	}

	public Date getBeginTime()
	{
		return beginTime;
	}

	public void setBeginTime(Date beginTime)
	{
		this.beginTime = beginTime;
	}

	public Date getEndTime()
	{
		return endTime;
	}

	public void setEndTime(Date endTime)
	{
		this.endTime = endTime;
	}

	public CmdStatus getCmdStatus()
	{
		return cmdStatus;
	}

	public void setCmdStatus(CmdStatus cmdStatus)
	{
		this.cmdStatus = cmdStatus;
	}

	public String getBankSerieNo()
	{
		return bankSerieNo;
	}

	public void setBankSerieNo(String bankSerieNo)
	{
		this.bankSerieNo = bankSerieNo;
	}

	public String getBankRetCode()
	{
		return bankRetCode;
	}

	public void setBankRetCode(String bankRetCode)
	{
		this.bankRetCode = bankRetCode;
	}

	public String getBankRetMsg()
	{
		return bankRetMsg;
	}

	public void setBankRetMsg(String bankRetMsg)
	{
		this.bankRetMsg = bankRetMsg;
	}

	public String getPayRetCode()
	{
		return payRetCode;
	}

	public void setPayRetCode(String payRetCode)
	{
		this.payRetCode = payRetCode;
	}
}
