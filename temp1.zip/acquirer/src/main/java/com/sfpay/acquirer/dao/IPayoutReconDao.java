package com.sfpay.acquirer.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.ReconPayoutOuterTemp;
import com.sfpay.acquirer.domain.ReconPayoutRlt;
import com.sfpay.acquirer.enums.ReconStatus;

/**
 * 
 * 
 * 类说明：<br>
 * 银企对账DAO
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-8-14
 */
public interface IPayoutReconDao {

	/**
	 * 方法说明：<br>
	 * 导入外部数据
	 *
	 * @param outTempList
	 * @throws Exception
	 */
	public void addReconOutList(List<ReconPayoutOuterTemp> outTempList) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 对账存储过程
	 *
	 * @param tradeDate
	 * @throws Exception
	 */
	public void saveRecon(@Param("tradeDate")Date tradeDate) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 统计调账记录
	 *
	 * @param tradeDate
	 * @return
	 * @throws Exception
	 */
	public Long totalReconPayoutRltCount(@Param("tradeDate")Date tradeDate) throws Exception;
	
	/**
     * 统计对账结算后的成功笔数，失败笔数，丢单笔数，调单笔数，时间性差异笔数
     * @param date
     * @param bankCode
     * @param channelCode
     * @return
     * @throws Exception
     */
	public String totalReconPayoutRlt(@Param("nowDate") Date strDate ) throws Exception;

	/**
	 * 方法说明：<br>
	 * 查询丢单记录
	 *
	 * @param reconDate
	 * @return
	 * @throws Exception
	 */
	public List<ReconPayoutRlt> selectLose(@Param("reconDate") Date reconDate ) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 更新状态
	 *
	 * @param id
	 * @return
	 * @throws Exception
	 */
	public int updateReconPayoutRltState(@Param("id") Long id,@Param("reconStatus")ReconStatus reconStatus,@Param("oldStatus")ReconStatus oldStatus) throws Exception;
}
