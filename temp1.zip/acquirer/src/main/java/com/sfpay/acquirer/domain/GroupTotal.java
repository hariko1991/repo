package com.sfpay.acquirer.domain;


/**
 * 
 * 
 * 类说明：<br>
 * 分组统计
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-11-1
 */
public class GroupTotal extends AbsEntity {

	private static final long serialVersionUID = -5640082802053203019L;

	/**
	 * 分组条件
	 */
	private String sn;
	
	/**
	 * 笔数
	 */
	private Long cnt;

	public String getSn() {
		return sn;
	}

	public void setSn(String sn) {
		this.sn = sn;
	}

	public Long getCnt() {
		return cnt;
	}

	public void setCnt(Long cnt) {
		this.cnt = cnt;
	}
	
	
}
