/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.task;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.domain.CollectInfo;
import com.sfpay.acquirer.enums.CollectStatus;
import com.sfpay.acquirer.service.ICollectInfoService;
import com.sfpay.acquirer.service.IReconLogService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.order.enums.SourcesCode;
import com.sfpay.product.domain.recharge.adjust.WebCloseRequest;
import com.sfpay.product.service.IWebRrechargeAdjustService;

/**
 * 
 * 类说明：<br>
 * 关闭3天(可配)以前状态为初始({@link CollectStatus#INIT INIT})收单记录定时任务
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 <a href="mailto:fuyuxin@sf-express.com">符瑜鑫(Ricky Fu)</a>
 * 
 * CreateDate: 2012-8-20
 */
@Deprecated
@Service("CloseCollectTask")
public class CloseCollectTask {
	
	private static final Logger logger = LoggerFactory.getLogger(CloseCollectTask.class);
	
	@Resource
	private ICollectInfoService service;
	
	@Resource
	private IReconLogService reconLogService;
	
	@Resource
	private IWebRrechargeAdjustService webService;
	
	
	/**
	 * 方法说明：
	 * 关闭X天前状态为初始的收单记录
	 */
	public void execute() throws ServiceException {
		String pre = Property.getProperty("CLOSE_PREDAY");
		if(null == pre || "".equals(pre = pre.trim())) {
			reconLogService.insertReconLog("ERROR", "请配置属性: [CLOSE_PREDAY], 以天为单位的整数");
			throw new ServiceException("", "请配置属性: [CLOSE_PREDAY], 以天为单位的整数");
		}
		int before = Integer.parseInt(pre);
		logger.info("~~~~~~ 开始执行定时任务: 关闭{}天前状态为初始的收单记录~~~~~", pre);
		List<CollectInfo> colList = null;
		try {
			colList = service.closeCollectInfo(before);
		} catch (Exception e) {
			reconLogService.insertReconLog("ERROR", "关闭收单定时任务失败:"+e.getMessage());
			throw new ServiceException("关闭收单定时任务失败: ", e);
		} 
		
		//调用订单关闭接口
		try{
			if(colList!=null && colList.size()>0){
				logger.info("定时任务调用订单系统关闭交易");
				List<String> list = new ArrayList<String>(colList.size());
				for(CollectInfo col:colList){
					list.add(col.getBusinessSn());
				}
				WebCloseRequest webcloserequest = new WebCloseRequest();
				webcloserequest.setBusinessSnList(list);
				webcloserequest.setOperatorNo("SYSTEM");
				webcloserequest.setOrgId(0L);
				webcloserequest.setRequestIp("127.0.0.1");
				webcloserequest.setSourcesCode(SourcesCode.ACQ);
				webService.close(webcloserequest);
			}
		}catch(Exception e){
			logger.error("关闭交易,调用订单系统出错:",e);
			//不影响操作,不抛异常
		}
		logger.info("~~~~~~ 关闭收单记录定时任务执行结束 ~~~~~");
	}
}
