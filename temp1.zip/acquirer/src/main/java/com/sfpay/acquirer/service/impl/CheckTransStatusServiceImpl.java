/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.AcquirerHelper;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IBatchInfoDao;
import com.sfpay.acquirer.dao.IBatchRuleInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutRespResult;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.ChannelPayType;
import com.sfpay.acquirer.enums.CmdStatus;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.gate.b2e.service.impl.QueryPayout;
import com.sfpay.acquirer.service.ICheckTransStatusService;
import com.sfpay.acquirer.service.SendPayoutResp;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：<br>
 * 查询银企直联交易状态
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2012-10-29
 */
@Service
public class CheckTransStatusServiceImpl implements ICheckTransStatusService {
	private static Logger logger = LoggerFactory.getLogger(CheckTransStatusServiceImpl.class);
	private static final boolean isDebug = logger.isDebugEnabled();
	
	@Resource
	private IPayoutInfoDao payoutInfoDao;
	
	@Resource
	private IBatchInfoDao batchInfoDao;
	
	@Resource
	private SendPayoutResp sendPayoutResp;
	
	@Resource
	private IBatchRuleInfoDao ruleDao;

	@Override
	public List<BatchInfo> queryBatch(BankCode bankCode, BatchStatus batchStatus) throws ServiceException {
		//检查入参
		if(bankCode == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"bankCode is null");
		}
		if(batchStatus == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"batchStatus is null");
		}
		if(isDebug) {
			logger.debug("bankCode ="+bankCode+",batchStatus = "+batchStatus);
		}
		//查询
		return this.batchInfoDao.queryBatchByStatus(bankCode, batchStatus);
	}

	/**
	 * 方法说明：<br>
	 * 如果交易完成，把批次修改为done
	 *
	 * @param batchCode
	 * @param payoutStatusList
	 * @throws ServiceException
	 */
	public void doBatchCheck(String batchCode) throws ServiceException {
		if(batchCode == null || "".equals(batchCode.trim())){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"batchCode is null");
		}
		//查询是否已全部完成
		List<PayoutInfo> list=payoutInfoDao.queryPayoutByBatchCode(batchCode);
		if(list == null || list.size() == 0){
			logger.error("批次[批次号:{}]无付款记录.",batchCode);
			return;
		}
		
		long cnt = 0l;
		for(PayoutInfo info:list){
			PayoutStatus status=info.getStatus();
			//记录非终态个数
			if(!PayoutStatus.SUCCESS.equals(status) && !PayoutStatus.FAILURE.equals(status)){
				cnt++; 
			}
		}
		logger.info("批次[批次号:{}],共有[{}]条记录未交易完成.",batchCode,cnt);
		
		if(cnt == 0){
			logger.info("批次[批次号:{}] 已全部完成, 更新批次状态为: {}", batchCode, BatchStatus.DONE);
			try{
				//更新
				this.batchInfoDao.updateFinishStatus(batchCode.trim(), BatchStatus.DONE);
			}catch(Exception ex){
				logger.error("批次[批次号:"+batchCode+"],更新批次状态异常 = ",ex);
				throw new ServiceException(InfoCode.RESPONSE_EXCEPTION,"批次["+batchCode+"],更新批次状态异常 = ",ex);
			}
		} else {
			logger.info("批次[批次号: {}] 未全部完成", batchCode);
		}
	}
	
	
	
	/**
	 * 方法说明：<br>
	 * 处理批次 交易状态
	 * @param batchInfo
	 * @param bankCode
	 * @param payoutStatusList
	 * @throws ServiceException
	 */
	public List<PayoutInfo> doBatch(BankCode bankCode,BatchInfo batchInfo)
			throws ServiceException{
		
		if(bankCode == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"bankCode is null");
		}
		if(batchInfo == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"batchInfo is null");
		}
		logger.info("bankCode = "+bankCode+",batchInfo = "+batchInfo.toString());
		
		//2.1.1 调用银行
		BankProperty property = AcquirerHelper.getProperties(bankCode, ChannelCode.B2E);
		PayoutRespResult result = null;
		try {
			QueryPayout query = new QueryPayout();
			//查询规则
			BatchRuleInfo rule =ruleDao.queryBatchRuleInfoByCode(batchInfo.getRuleCode());
			//查询付款信息
			List<PayoutInfo> info = null;
			if(batchInfo.getStatus().equals(BatchStatus.UNKOWN)||batchInfo.getStatus().equals(BatchStatus.SEC_CHECK_PASS)){
				info = this.payoutInfoDao.queryPayoutByBatch(batchInfo.getBatchCode(),null);
			}else{
				info = this.payoutInfoDao.queryPayoutByBatch(batchInfo.getBatchCode(), PayoutStatus.RECEIVED);
			}
			
			//bankCode取自付款渠道，sfhq270 2014-12-25.
			bankCode=rule.getBankCode();
			result = query.doQuery(batchInfo, info, property, bankCode, rule);
		} catch (Exception ex) {
			throw new ServiceException(InfoCode.RESPONSE_EXCEPTION
					,batchInfo.getBatchCode()+",查询交易结果异常 = ",ex);
		}
		
		logger.info("判断单笔和批量,批次号：{},result.getChannelPayType():{}", batchInfo.getBatchCode(), result.getChannelPayType());
		if(null != result.getChannelPayType() && result.getChannelPayType().equals(ChannelPayType.SINGLE_PAY)){
			logger.info("进入单笔代付");
			return this.doSinglePayoutResp(batchInfo, result);
		}else{
			logger.info("进入批量代付");
			return this.doPayoutResp(batchInfo, result);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 更新交易状态,并返回需要发送外部系统的付款信息
	 *
	 * @param batchInfo
	 * @param result
	 * @return
	 * @throws ServiceException
	 */
	public List<PayoutInfo> doPayoutResp(BatchInfo batchInfo,PayoutRespResult result)
			throws ServiceException{
		if(batchInfo == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"batchInfo is null");
		}
		
		if(result == null){
			throw new ServiceException(InfoCode.RESPONSE_EXCEPTION
					,"批次["+batchInfo.getBatchCode()+"],查询交易失败");
		}
		if(!CmdStatus.SUCCESS.equals(result.getCmdStatus())){
			throw new ServiceException(InfoCode.RESPONSE_EXCEPTION
					,"批次["+batchInfo.getBatchCode()+"],查询交易失败:["+result.getRemark()+"]");
		}
		//增加返回银行代码已经消息更新
		logger.info("更新银行返回代码{},银行返回消息:{}",result.getRtnBankCode(),result.getRtnBankMsg());
		batchInfo.setRtnBankCode(result.getRtnBankCode());
		batchInfo.setRtnBankMsg(result.getRtnBankMsg());
		if(!StringUtils.isEmpty(result.getRtnBankSn())){//更新返回流程实例号  add by sfhq814 201508012
			batchInfo.setRtnBankSn(result.getRtnBankSn());
		}
/*		if(null!=result.getStatus())
			batchInfo.setStatus(result.getStatus());//又未知状态改为已受理
*/		this.batchInfoDao.updateBankRtnInfo(batchInfo);
		
		List<PayoutInfo>  batchNotify = new ArrayList<PayoutInfo>();
		
		List<PayoutInfo> payoutInfoDetail = result.getPayoutDetail();
		if(payoutInfoDetail == null || payoutInfoDetail.size() == 0){
			if(result.getStatus()!= null && BatchStatus.REJECT.equals(result.getStatus())){
				logger.info("批次[批次号:{},请求流水号：{}],银行未受理[{}],修改为失败"
						,new Object[]{batchInfo.getBatchCode(),result.getBatchReqBankSn(),result.getStatus()});
				List<PayoutInfo> list = this.payoutInfoDao.queryPayoutByBatchCode(batchInfo.getBatchCode());
				sendPayoutResp.doSendOrderResp(list,batchInfo, PayoutStatus.FAILURE);
			//add 2014-12-25  结算中心处理已受理状态。
			}else if(result.getStatus()!= null && BatchStatus.RECEIVED.equals(result.getStatus())){
					logger.info("批次号[{}]状态为RECEIVED无需更新状态",batchInfo.getBatchCode());
			}else{
				throw new ServiceException(InfoCode.NO_QUERY_RECORD
						,"批次["+batchInfo.getBatchCode()+"],查询交易无付款记录");
			}
		}else {
			//2.1.2 更新结果
			for(PayoutInfo detail:payoutInfoDetail){
				logger.info("交易[批次号:{},请求流水号:{}]的付款结果 :{}"
						,new Object[]{result.getBatchReqBankSn(),detail.getReqBankSn(),detail.toString()});
				try{
					detail.setBatchCode(batchInfo.getBatchCode());
					PayoutInfo out = this.sendPayoutResp.doPayoutInfoResp(detail);
					if(out != null){
						batchNotify.add(out);
					}
				}catch(Exception ex){
					logger.error("付款信息["+detail.getPayoutNo()+"],更新交易状态异常 = ",ex);
					continue;
				}
			}
		}
		
		//检查是否已全部处理完成
		this.doBatchCheck(batchInfo.getBatchCode());
		return batchNotify;
	}
	
	// sfhq272  针对单笔代付做处理
	public List<PayoutInfo> doSinglePayoutResp(BatchInfo batchInfo, PayoutRespResult result)
			throws ServiceException{
		if(batchInfo == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"singlepay batchInfo is null");
		}
		
		if(result == null){
			throw new ServiceException(InfoCode.RESPONSE_EXCEPTION
					,"单笔代付批次["+batchInfo.getBatchCode()+"],查询交易失败");
		}
		
		//增加返回银行代码已经消息更新
		logger.info("单笔代付:更新银行返回代码{},银行返回消息:{}",result.getRtnBankCode(),result.getRtnBankMsg());
		batchInfo.setRtnBankCode(result.getRtnBankCode());
		batchInfo.setRtnBankMsg(result.getRtnBankMsg());	
		this.batchInfoDao.updateBankRtnInfo(batchInfo);
		
		//根据payoutInfo的reqBankSn得到PayoutInfo
		PayoutInfo payoutInfo = payoutInfoDao.queryPayoutInfoByReqBankSn(result.getReqBankSn());
		
		List<PayoutInfo>  batchNotify = new ArrayList<PayoutInfo>();
		
		List<PayoutInfo> payoutInfoDetail = new ArrayList<PayoutInfo>();
		payoutInfo.setStatus(result.getPayoutStatus());
		payoutInfoDetail.add(payoutInfo);
		
			for(PayoutInfo detail:payoutInfoDetail){
				logger.info("单笔代付交易[批次号:{},请求流水号:{}]的付款结果 :{}"
						,new Object[]{batchInfo.getBatchCode(),detail.getReqBankSn(),detail.toString()});
				try{
					detail.setBatchCode(batchInfo.getBatchCode());
					PayoutInfo out = this.sendPayoutResp.doPayoutInfoResp(detail);
					if(out != null){
						batchNotify.add(out);
					}
				}catch(Exception ex){
					logger.error("单笔代付付款信息["+detail.getPayoutNo()+"],更新交易状态异常 = ",ex);
					continue;
				}
			}
		
		//检查是否已全部处理完成
		this.doBatchCheck(batchInfo.getBatchCode());
		return batchNotify;
	}
}
