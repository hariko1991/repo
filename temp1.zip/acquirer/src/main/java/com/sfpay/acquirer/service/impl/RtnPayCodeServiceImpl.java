package com.sfpay.acquirer.service.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.dao.IRtnPayCodeDao;
import com.sfpay.acquirer.domain.RtnChannelCodeInfo;
import com.sfpay.acquirer.domain.RtnPayCodeInfo;
import com.sfpay.acquirer.service.IRtnPayCodeService;
/**
 * 类说明
 * @author 349508 韦健
 * @author 329202 符瑜鑫(Ricky Fu)
 * 错误码对照信息的查询与维护
 */
@Deprecated
@Service("rtnPayCodeService")
public class RtnPayCodeServiceImpl implements IRtnPayCodeService {
	
	private static final Logger logger = LoggerFactory.getLogger(RtnPayCodeServiceImpl.class);

	@Resource
	private IRtnPayCodeDao rtnPayCodeDao;

	@Override
	public RtnPayCodeInfo findRtnPayCodeByBankCode(RtnChannelCodeInfo param) {
		try {
			return rtnPayCodeDao.findRtnPayCode(param.getChannelCode(), param.getBankCode(), param.getRtnCode());
		} catch (Exception e) {
			logger.error("", e);
		}
		return null;
	}
}
