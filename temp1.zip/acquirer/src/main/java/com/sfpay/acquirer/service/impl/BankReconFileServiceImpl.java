package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.dao.IBatchInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.dao.rb.IBankReconFileDao;
import com.sfpay.acquirer.domain.BatchCmdStatusParam;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.CmdBean;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.rb.BankReconFileRlt;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.service.IBankReconFileService;
import com.sfpay.acquirer.service.IExceptionCmdProcessService;
import com.sfpay.coreplatform.order.common.enums.CcyType;
import com.sfpay.coreplatform.order.common.enums.OrderType;
import com.sfpay.coreplatform.order.service.ICompositePayService;
import com.sfpay.coreplatform.order.valueobject.dto.CompositePayRequest;
import com.sfpay.coreplatform.order.valueobject.dto.PayTradeResponse;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 
 * @author sfhq272
 *
 */
@HessianExporter
@Service("bankReconFileService")
public class BankReconFileServiceImpl implements IBankReconFileService {
	
	private static final Logger logger = LoggerFactory.getLogger(BankReconFileServiceImpl.class);
	private static final String BAD_DEBIT_PAYID = "75218";
	
	private static final String EXCEPTION_CMD_LOSE = "1";
	private static final String EXCEPTION_CMD_LACK = "2";
	private static final String EXCEPTION_CMD_FAILURE_GT = "3";   //银企金额大于银行实际支付金额
	private static final String EXCEPTION_CMD_FAILURE_LT_FAILURE = "4";
	private static final String EXCEPTION_CMD_FAILURE_LT_SUCCESS = "5";
	
	@Resource
	private IBankReconFileDao bankReconFileDao;
	
	@Resource
	private IBatchInfoDao batchInfoDao;
	
	@Resource
	private IPayoutInfoDao payoutInfoDao;
	
	@Resource
	private IExceptionCmdProcessService exceptionCmdProcessService;
	
	@Resource
	private ICompositePayService compositePayService;
	/**
	 * sfhq272
	 * 资金对账(结算中心)分页查询
	 */
	@Override
	public IPage<BankReconFileRlt> findBankReconList(BankReconFileRlt param,
			int pageNo, int pageSize) throws ServiceException {
		logger.info("findBankReconList开始,参数是{}", param);
		//查询总记录数
		long count = bankReconFileDao.countBankRecon(param);
		List<BankReconFileRlt> list = null;
		pageNo = pageNo <= 0 ? 1 : pageNo;
		pageSize = pageSize <= 0 ? 10 : pageSize;
		if(count > 0){
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			//查询当前页记录
			list = bankReconFileDao.findBankReconList(param, start, end);
		}	
		logger.info("findBankReconList结束");
		return new Page<BankReconFileRlt>(list, count, pageNo, pageSize);
	}

	/**
	 * sfhq272
	 * 导出资金对账(结算中心银企)
	 */
	@Override
	public List<BankReconFileRlt> exportBankReconList(BankReconFileRlt param)
			throws ServiceException {
		logger.info("exportBankReconList开始,参数是{}", param);
		List<BankReconFileRlt> list = bankReconFileDao.exportBankReconList(param);
		logger.info("exportBankReconList结束");
		return list;
	}

	/**
	 * sfhq272
	 * 资金对账差错处理
	 * @param param
	 * @throws ServiceException
	 */
	@Override
	public void exceptionCmd(BankReconFileRlt bankReconFileRlt) throws ServiceException {
		
		if(null == bankReconFileRlt.getReqBankSn() || "".equals(bankReconFileRlt.getReqBankSn())){
			throw new ServiceException(InfoCode.FAILURE, "传入的银行请求流水号为空!");
		}
		
		try{
			BatchInfo batchInfo = null;
			PayoutInfo payoutInfo = null;
			String operatorNo = bankReconFileRlt.getUpdateId();
			bankReconFileRlt.setUpdateId(operatorNo);
			String type = bankReconFileRlt.getType();
			String remark = "";
			if(EXCEPTION_CMD_LOSE.equals(type)){
				remark = "操作员工号为：" + operatorNo + ",执行了人工支付操作!";
				bankReconFileRlt.setRemark(remark);
				bankReconFileDao.exceptionCmd(bankReconFileRlt);
			}else if(EXCEPTION_CMD_LACK.equals(type)){
				batchInfo = batchInfoDao.queryBatchByPayoutReqBankSn(bankReconFileRlt.getReqBankSn());
				payoutInfo = payoutInfoDao.queryPayoutInfo(null, bankReconFileRlt.getReqBankSn());
				List<CmdBean> cmdBeans = new ArrayList<CmdBean>();
				CmdBean cmdBean = new CmdBean();
				cmdBean.setOldPayOutStatus(payoutInfo.getStatus());
				cmdBean.setStatus(PayoutStatus.SUCCESS);
				cmdBean.setReqBankSn(bankReconFileRlt.getReqBankSn());
				remark = "操作员工号为："+operatorNo+",执行了补单操作!";
				cmdBean.setRemark(remark);
				cmdBeans.add(cmdBean);
				BatchCmdStatusParam param = new BatchCmdStatusParam();
				param.setDtsCmds(cmdBeans);
				param.setReqBankSn(batchInfo.getReqBankSn());
				exceptionCmdProcessService.updateExceptionCmdStatus(param);
				bankReconFileRlt.setRemark(remark);
				bankReconFileDao.exceptionCmd(bankReconFileRlt);
			}else if(EXCEPTION_CMD_FAILURE_GT.equals(type)){
				remark = "操作员工号为："+operatorNo+",执行了金额不符人工支付操作!";
				bankReconFileRlt.setRemark(remark);
				bankReconFileDao.exceptionCmd(bankReconFileRlt);
			}else if(EXCEPTION_CMD_FAILURE_LT_FAILURE.equals(type)){
				payoutInfo = payoutInfoDao.queryPayoutInfo(null, bankReconFileRlt.getReqBankSn());
				remark = "操作员工号为："+operatorNo+",执行了金额不符坏账操作!";
				bankReconFileRlt.setRemark(remark);
				doneBadDebit(bankReconFileRlt, payoutInfo);
				bankReconFileDao.exceptionCmd(bankReconFileRlt);
			}else if(EXCEPTION_CMD_FAILURE_LT_SUCCESS.equals(type)){
				remark = "操作员工号为："+operatorNo+",执行了金额不符追款成功操作!";
				bankReconFileRlt.setRemark(remark);
				bankReconFileDao.exceptionCmd(bankReconFileRlt);
			}
		}catch(Exception e){
			throw new ServiceException(InfoCode.FAILURE,"差错处理异常 ["+e.getMessage()+"]", e);
		}
	}
	
	/**
	 * 补单操作
	 */
	private void doneBadDebit(BankReconFileRlt bankReconFileRlt, PayoutInfo payoutInfo)throws ServiceException {
		PayTradeResponse ordResponse = null;
		try {
			Long amt = bankReconFileDao.queryBadDebitAmout(bankReconFileRlt);
			logger.info("坏账记录,请求流水号[],请求金额[],付款金额[],坏账金额[]", new Object[]{bankReconFileRlt.getReqBankSn(),
					bankReconFileRlt.getAmt(),bankReconFileRlt.getBankAmt(),amt});
			Long PLATFORM_MEMBER_NO = Long.valueOf(Property.getProperty("PLATFORM_MEMBER_NO"));
			CompositePayRequest ordRequest = new CompositePayRequest();
			ordRequest.setPlatformMemberNo(PLATFORM_MEMBER_NO);//银企平台号
			ordRequest.setAccPasword(false);
			ordRequest.setBusinessType(com.sfpay.coreplatform.order.common.enums.BusinessType.TRS_ACCT);
			ordRequest.setCcy(CcyType.RMB);
			ordRequest.setOrderType(OrderType.TRANSFER);
			//com.sfpay.coreplatform.order.common.enums.TradeType.TRANSFER
			ordRequest.setTradeType(com.sfpay.coreplatform.order.common.enums.TradeType.TRANSFER); // 类型设置为调账
			ordRequest.setSubject("坏账");
			ordRequest.setOutTradeNo(payoutInfo.getTradeOutNo());//顺手付订单号
			ordRequest.setPayId(BAD_DEBIT_PAYID);
			Map<String, Object> payInfoMap = new HashMap<String, Object>();
			ordRequest.setPayInfoMap(payInfoMap);
			payInfoMap.put("bankCode", payoutInfo.getPayerOrgCode().name()); // 付款方银行编码
			payInfoMap.put("amount", amt);//金额  分
			payInfoMap.put("desc", "坏账");
			
			// 调用核心记账
			ordResponse =  compositePayService.pay(ordRequest);
		} catch (Exception e) {
			throw new ServiceException(InfoCode.FAILURE,"调用核心定单记坏账失败 ["+e.getMessage()+"]", e);
		}

		if(ordResponse.getReturnCode()<0) {
			//处理失败
			throw new ServiceException(InfoCode.FAILURE,"调用核心定单记坏账失败 ,订单处理失败!");
		}

	}

	
	/**
	 * 方法说明：<br>
	 * 资金对账的交易金额,银行交易金额计算
	 * sfhq272
	 * @return
	 */
	@Override
	public BankReconFileRlt countAmt(BankReconFileRlt param)
			throws ServiceException {
		// TODO Auto-generated method stub
		return bankReconFileDao.countAmt(param);
	}
	
	/**
	 * 导出总数查询
	 * @param param
	 * @return
	 */
	@Override
	public long countBankRecon(BankReconFileRlt param) throws ServiceException{
		return bankReconFileDao.countBankRecon(param);
	}

}
