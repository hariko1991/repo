package com.sfpay.acquirer.gate.b2e.service.impl;

import java.util.List;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.common.ApplicationContextHelper;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutRespResult;
import com.sfpay.acquirer.enums.AcctType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.PayoutSendStatus;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.acquirer.gate.b2e.BaseCommand;
import com.sfpay.acquirer.gate.b2e.BasePayout;
import com.sfpay.acquirer.gate.b2e.command.QueryBatchAgtexchTransfer;
import com.sfpay.acquirer.gate.b2e.command.QueryBatchPayOff;
import com.sfpay.acquirer.gate.b2e.command.QueryBatchTransfer;
import com.sfpay.acquirer.gate.b2e.command.QuerySinglePayTransfer;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.acquirer.gate.b2e.service.IBankService;
import com.sfpay.acquirer.gate.b2e.service.IQueryPayout;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：<br>
 * 查询付款指令结果（请求/响应）
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * TODO 改名为QueryPayoutServiceImpl
 * TODO 此服务作为父服务，不同的指令就有不同的子类作为服务实现。
 * CreateDate: 2013-5-6
 */
public class QueryPayout extends BasePayout implements IQueryPayout {
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	protected final boolean isDebug = logger.isDebugEnabled();
	
//	private IBankService bankService = ApplicationContextHelper.getBean(IBankService.class);
	private IBankService bankService = (IBankService) ApplicationContextHelper.getBean("bankService");
	private IBankService szfsService= (IBankService) ApplicationContextHelper.getBean("szfsService");
	private IBankService cmbService= (IBankService) ApplicationContextHelper.getBean("cmbService");

	@Override
	public PayoutSendStatus doReq(BatchInfo bi, List<PayoutInfo> info, 
			BankProperty property, BankCode bankCode, BatchRuleInfo rule)
			throws Exception {
		//sfhq272   定时任务查询添加对单笔代付已受理的查询
		if(bankCode.name().equals(BankCode.SZFS.name())&&info.size()==1){
			QuerySinglePayTransfer qspt = new QuerySinglePayTransfer(bankCode, info.get(0));
			return qspt.send(bi.getReqBankSn(),bankCode, property, bi);
		}
		
		
		if(YNFlag.Y.equals(info.get(0).getAgentFlag())){ //判断是否为代理支付
			QueryBatchAgtexchTransfer bagt=new QueryBatchAgtexchTransfer(bi,info, bankCode);
			return bagt.send(bi.getReqBankSn(),bankCode, property, bi);
		}
		
		AcctType oppAcctType = this.getAcctType(rule);
		logger.info("账号类型:{}",oppAcctType);
		if(AcctType.COMPANY.equals(oppAcctType)){//公
			QueryBatchTransfer req  =  new QueryBatchTransfer(  bi, info, bankCode);
			return req.send(bankCode, property, bi);
		}else if(AcctType.PERSON.equals(oppAcctType)){//私
			QueryBatchPayOff req = new QueryBatchPayOff(  bi, info, bankCode);
			return req.send(bankCode, property, bi);
		}else {
			throw new ServiceException(InfoCode.FAILURE, "账号类型["+oppAcctType+"]有误!");
		}
	}
	
	@Override
	public PayoutRespResult doResp(BeanBase respBean) throws Exception {
	   if(TradeCodeB2E.QUERY_BATCH_AGENT_TRANSFER.equals(respBean.getTradeCode())){
		    QueryBatchAgtexchTransfer resp=new QueryBatchAgtexchTransfer();
		    return resp.parse(respBean);		
	   }else if(TradeCodeB2E.QUERY_BATCH_PAYOFF.equals(respBean.getTradeCode())) {
			QueryBatchPayOff resp = new QueryBatchPayOff();
			return resp.parse(respBean);
		} else if (TradeCodeB2E.QUERY_BATCH_TRANSFER.equals(respBean.getTradeCode())) {
			QueryBatchTransfer resp = new QueryBatchTransfer();
			return resp.parse(respBean);
		} else if (TradeCodeB2E.QUERY_SZFS_SINGLEPAY.equals(respBean.getTradeCode())){
			//sfhq272   定时任务查询添加对单笔代付已受理之后响应的结果的解析
			QuerySinglePayTransfer resp = new QuerySinglePayTransfer();
			return resp.parse(respBean);
		} else {
			logger.error("异常指令!");
			throw new ServiceException(InfoCode.FAILURE, "异常指令!");
		}
	}

	@Override
	public PayoutRespResult doQuery(BatchInfo bi, List<PayoutInfo> info,
			BankProperty property, BankCode bankCode, BatchRuleInfo rule)
			throws Exception {
		AcctType oppAcctType = this.getAcctType(rule);
		BaseCommand req = null;
		
		
		//sfhq272   定时任务查询添加对单笔代付已受理的查询
		if (bankCode.name().equals(BankCode.SZFS.name()) && info.size() == 1) {
			req = new QuerySinglePayTransfer(bankCode, info.get(0));
		} else if (AcctType.COMPANY.equals(oppAcctType)) {// 公
			req = new QueryBatchTransfer(bi, info, bankCode);
		} else if (AcctType.PERSON.equals(oppAcctType)) {// 私
			req = new QueryBatchPayOff(bi, info, bankCode);
		} else {
			throw new ServiceException(InfoCode.FAILURE, "账号类型[" + oppAcctType
					+ "]有误!");
		}
				
				
		BeanBase reqBean = null;
		try {
			reqBean = req.assembleXml(property);
		} catch (Exception ex) {
			logger.error("组装查询交易状态报文异常" ,ex);
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "组装查询交易状态报文异常:"+ex);
		}
		logger.info("查询交易状态的报文内容:\n{}", reqBean.toString());
		if (StringUtils.isEmpty(reqBean.toReqMsg())) {
			logger.debug("查询状态请求报文不能为空");
			return null;
		}

		// 发送查询请求
		BeanBase respBase = null;
		try {
			if("SZFS".equals(bankCode.name())){
				logger.info("进入结算中心查询开始");
				respBase = szfsService.service(reqBean);
				logger.info("进入结算中心查询开始结束");
			}else if("ICBC".equals(bankCode.name())){
				respBase = bankService.service(reqBean);
			}else{
				logger.info("进入招行查询开始");
				respBase = this.cmbService.service(reqBean);
				logger.info("进入招行查询结束");
			}
		} catch (Exception ex) {
			logger.error("查询交易状态异常", ex);
			throw new ServiceException(InfoCode.QUERY_FAILURE_ERROR, "查询交易状态异常", ex);
		}

		return req.parse(respBase);
	}
	
	


}
