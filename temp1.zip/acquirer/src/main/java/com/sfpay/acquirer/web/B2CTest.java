package com.sfpay.acquirer.web;

import java.text.MessageFormat;
import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sfpay.acquirer.common.AcquirerHelper;
import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.domain.CollectInfo;
import com.sfpay.acquirer.domain.InCollectInfo;
import com.sfpay.acquirer.domain.PaymentParam;
import com.sfpay.acquirer.domain.PaymentReq;
import com.sfpay.acquirer.domain.PaymentResp;
import com.sfpay.acquirer.domain.PaymentRespParam;
import com.sfpay.acquirer.domain.PaymentResult;
import com.sfpay.acquirer.enums.AcqBizType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.acquirer.gate.AcquirerBizFactory;
import com.sfpay.acquirer.gate.IPayment;
import com.sfpay.acquirer.gate.annotation.cache.RespParamMap;
import com.sfpay.acquirer.gate.annotation.parser.PaymentParser;
import com.sfpay.acquirer.service.ICollectInfoService;
import com.sfpay.framework.common.util.StringUtils;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-9-3
 */
@Deprecated
@Controller
@RequestMapping(value = "/b2c/test")
public class B2CTest {
	private static Logger logger = LoggerFactory.getLogger(B2CTest.class);
	
	@Resource
	private ICollectInfoService collectInfoService;
	
	@RequestMapping(value = {"", "/"})
	public String index(HttpServletRequest request, HttpServletResponse response) {
		return "test-gate";
	}
	
	/**
	 * 方法说明：
	 * 与数据库交互
	 */
	@RequestMapping(value = "/payment")
	public String payment(HttpServletRequest request, HttpServletResponse response) {
		String key = request.getParameter("bank");
		int pos = key.indexOf('_');
	    BankCode bank = BankCode.valueOf(key.substring(pos+1));
	    ChannelCode channel = ChannelCode.valueOf(key.substring(0, pos));
		try {
			InCollectInfo info = new InCollectInfo();
			info.setBankCode(bank);
			info.setChannelCode(channel);
			info.setResultUrl("http://58.250.130.38/acquirer/b2c/test/{0}/resp/bank");			
			info.setCcy(CurrencyType.RMB);
			info.setOrderType(OrderType.RECHARGE);
			info.setAmt(1L);//测试用,1分钱			
			info.setClientIp("121.35.249.221"); 
			long curtimemills = System.currentTimeMillis();
			info.setPayNo("11"+curtimemills);
			info.setTradeNo("22"+curtimemills);
			info.setBusinessSn("33"+curtimemills);
			info.setPayerMemberNo(curtimemills);
			
			PaymentParam param = collectInfoService.createPaymentByB2C(info);
			
			logger.debug("[{}_{}] Request Param:\n{}", new Object[]{channel, bank, param.getPaymentArgs()});
			checkReq(param);
			request.setAttribute("paymentParam", param);
			request.setAttribute("selIdx", request.getParameter("selIdx"));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		
		return "/test-gate";
	}
	
	/**
	 * 方法说明：
	 * 数据库库交互 - 回调
	 * @param request
	 * @param response
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/{collectNo}/resp/bank")
	public String testBankResp(@PathVariable String collectNo, HttpServletRequest request, HttpServletResponse response) {
	    Map<String, String[]> param = request.getParameterMap();
	    logger.debug("Receive From Bank...\nReq method: {}\n[{}]回调-原始回传参数:\n{}", new Object[]{request.getMethod(), collectNo, PaymentParser.concat(param)});
	    PaymentResp rs = null;
		try {
			rs = collectInfoService.updateBankResp(collectNo, request.getParameterMap());
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	    request.setAttribute("resp", rs);
	    
		return "/test-gate";
//	    return "success";//支付宝异步通知方式回传参数
	}
	
	@RequestMapping(value = "/gate")
	public String testGate(HttpServletRequest request, HttpServletResponse response) {
		String key = request.getParameter("bank");
		int pos = key.indexOf('_');
		String channelName = key.substring(0, pos);
		String bankName = key.substring(pos+1);
	    BankCode bank = BankCode.valueOf(bankName);
	    ChannelCode channel = ChannelCode.valueOf(channelName);
		try {
			int len = Integer.parseInt(request.getParameter("len"));
			CollectInfo info = new CollectInfo();
			info.setCollectNo(CUID.generate(len));
			info.setClientIp("121.35.249.221"); //
//			info.setClientIp(AdslHelper.getIp());
//			if(BankCode.BOC.equals(bank)) {//中行测试固定回调此地址
//				info.setResultUrl("http://113.108.118.81:8080/acquirer/{0}_{1}/testGateBack");
//			} else {
//				info.setResultUrl("http://"+info.getClientIp()+"/acquirer/{0}_{1}/testGateBack");
//			}
			info.setResultUrl("http://58.250.130.38/acquirer/b2c/test/{0}_{1}/resp/gate");
			
			if(ChannelCode.QPAY.equals(channel)){
				info.setPayerMobile("13811111111");
				info.setPayerAcctCode("6212341111111111111");
			}
			
			info.setCcy(CurrencyType.RMB);
			info.setOrderType(OrderType.RECHARGE);
			info.setFundWay(FundWay.IN);
			info.setBeginTime(new Date());
			info.setAmt(1L);//测试用,1分钱
			//测试类采用channelCode作为参数统一设置给回调url.Ricky Fu
			info.setResultUrl(new MessageFormat(info.getResultUrl()).format(new Object[]{channel, bank}));
			IPayment gate = AcquirerBizFactory.getInstance(bank, channel , AcqBizType.PAYMENT);
			PaymentReq req = gate.send(info, AcquirerHelper.getProperties(bank, channel));
			PaymentParser.buildPaymentArgs(req);//手动生成支付表单域,不对外提供BankField等注解类
			
			PaymentParam param = new PaymentParam();
			param.setAction(req.getAction());
			param.setCollectNo(req.getCollectNo());
			param.setSerieNo(req.getSerieNo());
			param.setPaymentArgs(req.getPaymentArgs());
			param.setQueryParam(req.getQueryParam());
			logger.debug("[{}_{}] Request Param:\n{}", new Object[]{channel, bank, param.getPaymentArgs()});
			checkReq(param);
			request.setAttribute("paymentParam", param);
			request.setAttribute("selIdx", request.getParameter("selIdx"));
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
		return "/test-gate";
	}
	
	/**
	 * 
	 * 方法说明：
	 *
	 * @param request
	 * @param response
	 */
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/{collectNo}/resp/gate")
	public String testGateBack(@PathVariable String collectNo, HttpServletRequest request, HttpServletResponse response) {
	    logger.debug("Receive From Bank... req method: "+request.getMethod());
	    int pos = collectNo.indexOf('_');//测试时将此参数设置为[channel]_[bank].
		String channelName = collectNo.substring(0, pos);
		String bankName = collectNo.substring(pos+1);
	    BankCode bank = BankCode.valueOf(bankName);
	    ChannelCode channel = ChannelCode.valueOf(channelName);
	    Map<String, String[]> param = request.getParameterMap();
	    logger.debug("[{}_{}]回调-原始回传参数:\n{}", new Object[]{channel, bank, PaymentParser.concat(param)});
	    PaymentResult rs = null;
		try {
//			result = collectInfoService.updateBankResp(collectNo, request.getParameterMap());
			IPayment gate = AcquirerBizFactory.getInstance(bank, channel, AcqBizType.PAYMENT);
			PaymentRespParam respParam = PaymentParser.convert(RespParamMap.get(bank, channel), param);
			rs = gate.receive(respParam, AcquirerHelper.getProperties(bank, channel));
			logger.debug("\nReceiveMsg:\n{}\n执行结果:\n{}", respParam.oriBuf(), rs.toString());
		} catch (Exception e) {
			logger.error(e.getMessage(), e);
		}
	 if(null!=rs){
		 checkResult(rs);
		 request.setAttribute("result", rs);
	 }
	    
		return "/test-gate";
//	    return "success";//支付宝异步通知方式回传参数
	}

	@RequestMapping(value = "/query")
	public String testQueryGet(HttpServletRequest request, HttpServletResponse response) {
		return "/test-query";
	}
	
	/**
	 * 方法说明：<br>
	 * 测试时验证发送结果必填项的正确性
	 *
	 * @param param
	 */
	private void checkReq(PaymentParam param) {
		//此处不用logger打印以提高测试关注程度
		if(StringUtils.isNullOrEmpty(param.getSerieNo())) {
			logger.error("[serieNo]:{必填}请设置向银行发送时的流水号[唯一标识,可能是orderId,collectNo].");
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 测试时验证填写回传结果的正确性
	 *
	 * @param rs
	 */
	private void checkResult(PaymentResult rs) {
		//此处不用logger打印以提高测试关注程度
		if(null == rs.getCollectStatus()) {
			logger.error("[collectStatus]:{必填}请根据银行返回状态设置对应的收单状态.");
		}
		if(StringUtils.isNullOrEmpty(rs.getRtnBankSn())) {
			logger.error("[rtnBankSn]:请检查银行回传的流水号(也可能是回传的原始orderId).");
		}
		if(StringUtils.isNullOrEmpty(rs.getRtnBankCode())) {
			logger.error("[rtnBankCode]:请检查银行回传的状态码.");
		}
		if(StringUtils.isNullOrEmpty(rs.getRtnBankMsg())) {
			logger.error("[rtnBankMsg]:请检查银行结果描述.");
		}
	}
	
}
