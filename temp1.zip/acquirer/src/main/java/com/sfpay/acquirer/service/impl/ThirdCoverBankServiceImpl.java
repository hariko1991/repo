/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.dao.IThirdCoverBankDao;
import com.sfpay.acquirer.domain.ThirdCoverBank;
import com.sfpay.acquirer.domain.ThirdCoverBankQueryParam;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.ThirdBankCode;
import com.sfpay.acquirer.enums.ThirdCoverBankStatus;
import com.sfpay.acquirer.service.IThirdCoverBankService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明： 第三方支持的银行 实现类
 * 
 * <p/>
 * 详细描述：
 * 
 * 
 * @author 312932 何国兴
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2012-6-1
 */
@Deprecated
@Service("thirdCoverBankService")
@HessianExporter
public class ThirdCoverBankServiceImpl implements IThirdCoverBankService {

	private static Logger logger = LoggerFactory.getLogger(ThirdCoverBankServiceImpl.class);

	@Resource
	private IThirdCoverBankDao dao;

	@Override
	public IPage<ThirdCoverBank> queryThirdCoverBankPage(ThirdCoverBankQueryParam param, int pageNo, int pageSize) throws ServiceException {
		// 查询总记录数
		long count = dao.countThirdCoverBankPage(param);
		List<ThirdCoverBank> list = null;
		if (count > 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			list = dao.queryThirdCoverBankPage(param, start, end);
		}
		return new Page<ThirdCoverBank>(list, count, pageNo, pageSize);
	}

	@Override
	public void updateStatus(long id, ThirdCoverBankStatus status, String remark) throws ServiceException {
		if (status == null) {
			throw new ServiceException("status is null");
		}
		dao.updateStatus(id, status, remark);

	}

	@Override
	public List<ThirdCoverBank> queryThirdCoverBankList(ChannelCode channelCode, ThirdBankCode bankCode) throws ServiceException {
		if (channelCode == null) {
			logger.info("queryThirdCoverBankList parameter[channelCode] is null");
		}
		if (bankCode == null) {
			logger.info("queryThirdCoverBankList parameter[bankCode] is null");
		}
		return dao.queryThirdCoverBankList(channelCode, bankCode);
	}

	/**
	 * 查询第三方的银行表属性
	 */
	@Override
	public ThirdCoverBank queryThirdCoverBankById(long id) throws ServiceException {
		return dao.queryThirdCoverBankById(id);
	}

	/**
	 * 修改第三方的银行表属性
	 */
	@Override
	public void updateThirdCoverBankById(ThirdCoverBank thirdCoverBank) throws ServiceException {
		if (null == thirdCoverBank) {
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "参数不能为空");
		}
		if (null == thirdCoverBank.getChannelCode()) {
			throw new ServiceException(InfoCode.CHANNEL_CODE_IS_NULL, "渠道编码不能为空");
		}
		if (null == thirdCoverBank.getBankCode()) {
			throw new ServiceException(InfoCode.BANK_CODE_IS_NULL, "银行编码不能为空");
		}
		if (null == thirdCoverBank.getCoverBankCode()) {
			throw new ServiceException(InfoCode.THIRD_CONVERT_BANK_IS_NULL, "第三方支持银行不能为空");
		}
		dao.updateThirdCoverBankById(thirdCoverBank);
	}

}
