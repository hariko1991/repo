package com.sfpay.acquirer.service.impl;

import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.AcquirerHelper;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.dao.IAccountInfoDao;
import com.sfpay.acquirer.dao.IBatchInfoDao;
import com.sfpay.acquirer.dao.IBatchRuleInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.BatchOperatorType;
import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.PayoutSendStatus;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.gate.b2e.service.impl.QueryPayout;
import com.sfpay.acquirer.service.IB2EQueryStatusService;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 
 * 类说明：<br>
 * 发起查询状态指令
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-4-27
 */
@Service
public class B2EQueryStatusServiceImpl implements IB2EQueryStatusService {
	private static Logger logger = LoggerFactory.getLogger(CheckTransStatusServiceImpl.class);
	
	@Resource
	private IBatchInfoDao batchInfoDao;
	
	@Resource
	private IBatchRuleInfoDao ruleDao;
	
	@Resource
	private IPayoutInfoDao payoutInfoDao;
	
	@Resource
	private IAccountInfoDao accountInfoDao;

	/**
	 * 方法说明：<br>
	 * 发起查询交易状态指令
	 *
	 * @param bankCode
	 * @throws ServiceException
	 */
	@Override
	public void proQueryReq(BankCode bankCode) throws ServiceException {
		
		//查询批次信息
		//检查入参
		if(bankCode == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"银行编码不能为空");
		}
		logger.info("开始发起银行[{}]查询交易状态指令.",bankCode);
		//查询
		logger.info("第一步:查询银行[{}]RECEIVED,UNKOWN状态的批次信息", bankCode);
		
		
		List<BatchInfo> batchInfoList = this.batchInfoDao.queryBatchByStatusNew(bankCode);
		if(batchInfoList == null || batchInfoList.size() == 0){
			logger.info("银行[{}],没有需要查询交易状态的批次",bankCode);
			return;
		}
		
		logger.info("第二步:查询银行[{}]每个批次的付款状态",bankCode);
		//循环处理每个批次
		for (BatchInfo batchInfo:batchInfoList){
			logger.info("批次[请求流水号:{}],开始处理查询交易状态请求.",batchInfo.getReqBankSn());
			
			BankProperty property = AcquirerHelper.getProperties(bankCode, ChannelCode.B2E);
			
			//工行区分公私账户接口
			//查询规则信息
			BatchRuleInfo rule =ruleDao.queryBatchRuleInfoByCode(batchInfo.getRuleCode());
			if(rule == null){
				logger.error("批次[请求流水号:{}],规则[{}]不存在.",batchInfo.getReqBankSn(),batchInfo.getRuleCode());
				continue;
			}
			/**
			 * rule.getAccountNo()加这个值是自动出款异常转人工，查询是没有付款账号的。原来的手工出款是有付款账号的
			 * 
			 * 去掉这个逻辑
			 */
			/*if (BatchOperatorType.HAND.equals(batchInfo.getOperatorType())&&StringUtils.isNotEmpty(rule.getAccountNo())) {
				//查询付款账户信息
				AccountInfo acct = this.accountInfoDao.queryAccountInfoByAccountNo(rule.getAccountNo(),null);
				if(acct == null){
					logger.error("批次[请求流水号:{}], 找不到{}对应的付款账户信息",batchInfo.getReqBankSn(), rule.getAccountNo());
					continue;
				}
			}*/
			
			//查询付款信息
			List<PayoutInfo> pis = this.payoutInfoDao.queryByStatusNew(batchInfo.getBatchCode());
			if(pis == null || pis.size() == 0){
				logger.error("批次[请求流水号:{}],没有需要查询交易状态的付款记录",batchInfo.getReqBankSn());
				continue;
			}
			
			PayoutSendStatus sendStatus= null;
			logger.info("批次[请求流水号:{}],组装请求报文并发送",batchInfo.getReqBankSn());
			try{
				//生成请求报文
				sendStatus = new QueryPayout().doReq(batchInfo, pis, property, bankCode, rule);
			}catch(Exception ex){
				logger.error("批次[请求流水号:"+batchInfo.getReqBankSn()+"],生成查询报文异常",ex);
				continue;
			}
			
			logger.info("批次[请求流水号:{}]，发送查询报文结果:{}",new Object[]{batchInfo.getReqBankSn(),sendStatus});
			
			logger.info("批次[请求流水号:{}],处理查询交易状态请求结束,发送MQ结果 :{}",new Object[]{batchInfo.getReqBankSn(),sendStatus});
		}
		
		logger.info("开始发起银行[{}]查询交易状态指令结束.",bankCode);
	}

}
