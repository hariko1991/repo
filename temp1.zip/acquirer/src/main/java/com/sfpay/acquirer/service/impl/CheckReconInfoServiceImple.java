package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sfpay.acquirer.dao.ICheckReconInfoDao;
import com.sfpay.acquirer.domain.ReconCollectRlt;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.service.ICheckReconInfoService;
/**
 * 类说明：
 * 针对对账后产生的丢单和掉单两种情况，进行相应的处理 
 * 
 * <p/>
 * 详细描述：
 * @author 349508 韦健
 *   
 * CreateDate: 2012-8-16  
 * 
 */
@Deprecated
@Service("checkReconInfoService")
public class CheckReconInfoServiceImple implements ICheckReconInfoService{
	
    @Resource
	private ICheckReconInfoDao checkReconInfoDao;
    /**
     * 在对账以后，查询所有丢单和掉单的记录
     * @param bankCode
     * @param channelCode
     * @param date
     * @return
     */
	public List<ReconCollectRlt> findReconLose(BankCode bankCode ,ChannelCode channelCode,String nowDate){
		return checkReconInfoDao.findReconLose(bankCode,channelCode,nowDate);
	}
	
    /**
     * 根据单笔查询的反回结果判断是否是丢单情况，以此更改对账结果表状态为时间性差异
     * @param id
     */
	public void updateReconCollectRltState(Long id){
		checkReconInfoDao.updateReconCollectRltState(id);
	}
	
	/**
	 * 根据单笔查询的反回结果判断是否是掉单情况，如果是则更新收单基础表状态为成功（如果找不到这个订单，这里不做处理）
	 * @param reqBankSn
	 * @param bankCode
	 * @param channelCode
	 * @param fundWay
	 */
	public void updateCollectInfoState(String reqBankSn,BankCode bankCode,ChannelCode channelCode,FundWay fundWay ){
		checkReconInfoDao.updateCollectInfoState(reqBankSn, bankCode, channelCode, fundWay);
	}
     
	/**
	 * 再把收单表中相应的记录更新到对账结果表中
	 * @param id
	 * @param bankCode
	 * @param channelCode
	 * @param fundWay
	 * @param reqBankSn
	 */
	public void updateReconCollectRltFromCollectInfo(Long id,BankCode bankCode,ChannelCode channelCode,FundWay fundWay,String reqBankSn){
		checkReconInfoDao.updateReconCollectRltFromCollectInfo(id,bankCode, channelCode, fundWay, reqBankSn);
	}
	

	
}
