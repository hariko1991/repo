/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.gate;

import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.CollectInfo;
import com.sfpay.acquirer.domain.PaymentParam;
import com.sfpay.acquirer.domain.PaymentReq;
import com.sfpay.acquirer.domain.PaymentRespParam;
import com.sfpay.acquirer.domain.PaymentResult;

/**
 * 
 * 类说明：<br>
 * 网上银行(B2C, 快捷支付等)支付请求、支付回调接口
 * 
 * <p>
 * 详细描述：<br>
 * 1, send 向银行送支付请求报文
 * 2, receive 网上支付请求成功后银行回调接口
 * </p>
 * 
 * @author 329202 <a href="mailto:fuyuxin@sf-express.com">符瑜鑫(Ricky Fu)</a>
 * 
 * CreateDate: 2012-4-9
 */
public interface IPayment extends IAcqBiz {
	
	/**
	 * 方法说明：
	 * 向银行送支付请求报文.<br>
	 * 返回的Bean实例必须写入以下信息:<ul>
	 * <li>{@link PaymentParam#setSerieNo()}: 请求流水号.发送给银行的唯一标识(<code>orderId</code>)</li>
	 * </ul>
	 * 
	 * @param info 收单信息表
	 * @param property 银行渠道基础参数.[目前通过直接读取DB方式,以后可改进为使用分布式缓存模式.Ricky Fu]
	 * 
	 * @return 支付请求数据Bean
	 */
	public PaymentReq send(CollectInfo info, BankProperty property) throws Exception;

	/**
	 * 方法说明：
	 * 网上支付请求成功后银行回调接口.<br>
	 * <span style="color:red;">注意:</span>
	 * 返回的Bean实例必须写入以下信息:<ul>
	 * <li>{@link PaymentResult#setCollectStatus()}: 收单状态.根据各银行状态判断</li>
	 * <li>{@link PaymentResult#setRtnBankSn()}: 银行流水号.银行回传的流水号(也可能是回传的原始<code>orderId</code>)</li>
	 * <li>{@link PaymentResult#setRtnBankCode()}: 银行返回码.银行回传的状态码</li>
	 * <li>{@link PaymentResult#setRtnBankMsg()}: 银行结果描述.银行结果描述.对银行的各状态进行说明</li>
	 * </ul>
	 * 
	 * @param param 银行回调我们提供的url时传回的参数.在使用时需要强制转换为各银行具体的Bean
	 * @param property 银行渠道基础参数.[目前通过直接读取DB方式,以后可改进为使用分布式缓存模式.Ricky Fu]
	 * 
	 * @return
	 */
	public PaymentResult receive(PaymentRespParam param, BankProperty property) throws Exception;
	
}
