package com.sfpay.acquirer.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 银企直连payout_info对应的
 * @author sfhq272
 *
 */
public class BankPayoutReconInnerTemp extends BaseEntity{

	/**
	 * 
	 */
	private static final long serialVersionUID = -212602225744051718L;

	private String	reqBankSn;       
	private String 	payoutNo;         
	private String 	payChannelCode;  
	private String 	transBussType;   
	private Long 	amt;               
	private String 	ccy;               
	private String 	status;            
	private String 	systemSource;     
	private String 	payerAcctNo;     
	private String 	payerAcctName;   
	private String 	payerBankCode;   
	private Date 	tradeEndDate;    
	private Date 	checkDate;        
	private Date 	createDate;
	
	public String getReqBankSn() {
		return reqBankSn;
	}
	public void setReqBankSn(String reqBankSn) {
		this.reqBankSn = reqBankSn;
	}
	public String getPayoutNo() {
		return payoutNo;
	}
	public void setPayoutNo(String payoutNo) {
		this.payoutNo = payoutNo;
	}
	public String getPayChannelCode() {
		return payChannelCode;
	}
	public void setPayChannelCode(String payChannelCode) {
		this.payChannelCode = payChannelCode;
	}
	public String getTransBussType() {
		return transBussType;
	}
	public void setTransBussType(String transBussType) {
		this.transBussType = transBussType;
	}
	public Long getAmt() {
		return amt;
	}
	public void setAmt(Long amt) {
		this.amt = amt;
	}
	public String getCcy() {
		return ccy;
	}
	public void setCcy(String ccy) {
		this.ccy = ccy;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSystemSource() {
		return systemSource;
	}
	public void setSystemSource(String systemSource) {
		this.systemSource = systemSource;
	}
	public String getPayerAcctNo() {
		return payerAcctNo;
	}
	public void setPayerAcctNo(String payerAcctNo) {
		this.payerAcctNo = payerAcctNo;
	}
	public String getPayerAcctName() {
		return payerAcctName;
	}
	public void setPayerAcctName(String payerAcctName) {
		this.payerAcctName = payerAcctName;
	}
	public String getPayerBankCode() {
		return payerBankCode;
	}
	public void setPayerBankCode(String payerBankCode) {
		this.payerBankCode = payerBankCode;
	}
	public Date getTradeEndDate() {
		return tradeEndDate;
	}
	public void setTradeEndDate(Date tradeEndDate) {
		this.tradeEndDate = tradeEndDate;
	}
	public Date getCheckDate() {
		return checkDate;
	}
	public void setCheckDate(Date checkDate) {
		this.checkDate = checkDate;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

}
