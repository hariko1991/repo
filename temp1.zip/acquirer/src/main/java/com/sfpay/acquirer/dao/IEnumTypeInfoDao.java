package com.sfpay.acquirer.dao;

import java.util.List;

import com.sfpay.acquirer.domain.EnumTypeInfoDTO;

/**
 * 类说明：<br>
 * 枚举类型表DAO
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2015年12月8日
 */
public interface IEnumTypeInfoDao {
	
	/**
	 * 方法说明：<br>
	 * 查询指定类型的列表
	 * @param type
	 * @return
	 * */
	List<EnumTypeInfoDTO> queryByType(String type);
}
