/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.dao.IPayUseDao;
import com.sfpay.acquirer.domain.PayUse;
import com.sfpay.acquirer.domain.PayUseQueryParam;
import com.sfpay.acquirer.service.IPayUseService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 
 * 类说明：<br>
 * 付款用途　实现
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2012-9-28
 */
@Service("payUseService")
@HessianExporter
public class PayUseServiceImpl implements IPayUseService {
	
	@Resource
	private IPayUseDao payUseDao;

	/**
	 * 分页查询
	 */
	@Override
	public IPage<PayUse> queryPayUsePage(PayUseQueryParam param, int pageNo, int pageSize) throws ServiceException {
		//查询总记录数
		long count = payUseDao.countUsePage(param);
		List<PayUse> list = null;
		if(count!=0){
			if(pageNo<=0){
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			//查询当前页记录
			list = payUseDao.queryUsePage(param, start, end);
		}	
		return new Page<PayUse>(list,count,pageNo,pageSize);
	}

	/**
	 * 新增
	 */
	@Override
	public void savePayUse(PayUse param) throws ServiceException {
		//判断
		if(param.getUseDesc()==null || "".equals(param.getUseDesc().trim())){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL,"useDesc is null");
		}
		
		//去掉前后空格
		param.setUseDesc(param.getUseDesc().trim());
		
		//增加
		payUseDao.addPayUse(param);
	}

	/**
	 * 删除
	 */
	@Override
	public void deletePayUse(long id) throws ServiceException {
		payUseDao.deletePayUse(id);
	}

	/**
	 * 查询所有
	 */
	@Override
	public List<PayUse> queryPayUse() throws ServiceException {
		return payUseDao.queryUseAll();
	}

	/**
	 * 根据ID修改
	 */
	@Override
	public void updatePayUseById(Long id,String useDesc,String remark,Long showIndex) throws ServiceException {
		if(null == id || id < 0) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "id can't be null");
		}
		if(useDesc == null || "".equals(useDesc.trim())) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "useDesc can't be null");
		}
		useDesc = useDesc.trim();

		payUseDao.updatePayUseById(id, useDesc, remark, showIndex);
	}

	/**
	 * 根据ID查询
	 */
	@Override
	public PayUse queryPayUseById(long id) throws ServiceException {
		if(id < 0) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "id can't be null");
		}
		PayUse payUse = new PayUse();
		payUse.setId(id);
		List<PayUse> list =  payUseDao.queryUse(payUse);
		if(list != null && list.size() > 0){
			return list.get(0);
		}else{
			return null;
		}
	}

	
}
