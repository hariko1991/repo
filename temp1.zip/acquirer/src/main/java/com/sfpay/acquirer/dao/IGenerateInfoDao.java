package com.sfpay.acquirer.dao;

import org.apache.ibatis.annotations.Param;

public interface IGenerateInfoDao {
	/**
	 * 获取当天不重复id（供网银和快捷支付使用）
	 * @return
	 * @throws Exception
	 */
	public String getGenerateId(@Param("idLength") int diLength)throws Exception;
	
	/**
	 * 获取当天不重复id（供快捷支付使用）
	 * @return
	 * @throws Exception
	 */
	public String getGenerateId4B2E(@Param("idLength") int diLength)throws Exception;
	/**
	 * 获取随机数（供结算中心使用）
	 * 2014-12-03'
	 * sfhq270
	 * @param diLength
	 * @return
	 * @throws Exception
	 */
	public String getRandomCode(@Param("idLength") int diLength)throws Exception;
	
	
}
