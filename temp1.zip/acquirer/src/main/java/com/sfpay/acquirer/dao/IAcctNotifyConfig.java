/**
 * =================================================================
 * 版权所有 2011-2013 深圳市泰海网络科技服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import com.sfpay.acquirer.gate.b2e.domain.MailInfo;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 到账通知发送邮件配置
 * </p>
 *  
 * @author 400928 向鹏
 * 
 * CreateDate: 2013-7-11
 */
public interface IAcctNotifyConfig {
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据传入的账号查询相应的到账通知邮件配置信息
	 * @param accountNo
	 * @return
	 */
	public MailInfo getMailInfoByAccountNo(String accountNo);

}
