/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.Ftp4jUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IParamInfoDao;
import com.sfpay.acquirer.dao.IReconGatewayFileDao;
import com.sfpay.acquirer.domain.ReconGateFile;
import com.sfpay.acquirer.domain.ReconGatewayFile;
import com.sfpay.acquirer.enums.SystemSource;
import com.sfpay.acquirer.service.IReconGatewayFileService;
import com.sfpay.acquirer.service.IReconLogService;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：<br>
 * 网关对账文件
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-7-22
 */
@Deprecated
@Service
public class ReconGatewayFileService implements IReconGatewayFileService {
	private static Logger logger = LoggerFactory.getLogger(ReconGatewayFileService.class);
	private static final boolean isDebug = logger.isDebugEnabled();
	
	@Resource
	private IReconGatewayFileDao rDao;
	
	@Resource
	private IParamInfoDao pDao;
	
	@Resource
	private IReconLogService reconLogService;
	
	private StringBuffer logHead = null;
	
	@Override
	public void doGateReconFile(Date clearDate, boolean allowAgain)
			throws ServiceException {
		logHead = new StringBuffer();
		String clearDateStr = DateUtil.getDateString(clearDate, DateUtil.DATA_FORMAT_PATTERN_2);
		logHead.append("网关对账文件[清算日期:").append(clearDateStr).append("],");//打印日志
		
		ReconGatewayFile gatewayFile = null;
		String logStr = null;
		String uploadFilePath = null;
		try{
			logStr = "开始:"+logHead.toString()+"生成并上传网关对账文件.";
			logger.info(logStr);
			reconLogService.insertReconLog("INFO", logStr);	
			
			//生成文件
			gatewayFile = createGateReconFile(clearDate, allowAgain);
			
			//上传FTP
			if(gatewayFile != null && !StringUtils.isEmpty(gatewayFile.getFilePath())){
				uploadFilePath = gatewayFile.getFilePath();
				logStr = "第五步,"+logHead+"上传网关对账文件.文件目录:["+uploadFilePath+"].";
				logger.info(logStr);
				try{
					uploadGateReconFile(uploadFilePath,clearDateStr);
				}catch(Exception ex){
					logStr = logHead+"上传网关对账文件失败:"+ex.getMessage();
					logger.error(logStr);
					reconLogService.insertReconLog("ERROR", logHead+"出现异常:上传网关对账文件失败.");
					throw new ServiceException(logStr,ex);
				}
			}else{
				logStr = logHead+"未获取到需要上传的对账文件路径";
				logger.warn(logStr);
			}
		}finally{
			logStr = "结束:"+logHead+"生成并上传网关对账文件.文件目录:";
			if(!StringUtils.isEmpty(uploadFilePath)){
				logStr += "["+uploadFilePath+"].";
			}
			logger.info(logStr);
			reconLogService.insertReconLog("INFO", logStr);	
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 生成网关对账文件
	 *
	 * @param reconDate
	 * @param allowAgain 是否允许重新生成文件
	 * @return
	 * @throws 
	 */
	public ReconGatewayFile createGateReconFile(Date clearDate,boolean allowAgain) throws ServiceException{
		if(clearDate == null){
			throw new ServiceException("清算日期为空");
		}
		String clearDateStr = DateUtil.getDateString(clearDate, DateUtil.DATA_FORMAT_PATTERN_2);//日期
		if(isDebug){
			logger.debug("清算日期[{}]",clearDateStr);
		}
		if(logHead == null){
			logHead = new StringBuffer();
			logHead.append("网关对账文件[清算日期:").append(clearDateStr).append("],");//打印日志
		}
		//检查
		String logStr = "第一步,"+logHead+"检查是否可生成网关对账文件.";
		logger.info(logStr);
		ReconGatewayFile reconGatewayFile = null;
		try{
			reconGatewayFile = checkBankRecon(clearDate,allowAgain);
		}catch(ServiceException ex){
			logStr = logHead+"检查是否可生成网关对账文件失败.";
			logger.error(logStr,ex);
			if(!InfoCode.RESPONSE_EXCEPTION.equals(ex.getCode())){
				reconLogService.insertReconLog("WARN", logHead+"检查结果:"+ex.getMessage());
			}else{
				reconLogService.insertReconLog("ERROR", logHead+"出现异常:检查是否可生成网关对账文件失败.");
			}
			throw new ServiceException(logStr+ex);
		}
		
		//查询网关对账文件数据
		logStr = "第二步,"+logHead+"获取需生成网关对账文件数据.";
		logger.info(logStr);
		List<ReconGateFile> reconGateFileData = null;
		try{
			reconGateFileData = rDao.findGatyFileData(clearDate,SystemSource.GATEWAY);
		}catch(Exception ex){
			logStr = logHead+"获取需生成网关对账文件数据失败.";
			logger.error(logStr,ex);
			reconLogService.insertReconLog("ERROR", logHead+"出现异常:获取需生成网关对账文件数据失败.");
			throw new ServiceException(logStr+ex);
		}
		
		//获取文件路径信息
		String prefix = pDao.getParameter("GATEWAY_RECON_FILE_PREFIX");
		String fileName = (prefix == null?"":prefix.trim()) +clearDateStr+".txt";//文件名
		String tempFilePath = pDao.getParameter("GATEWAY_FILE_PATH");//文件路径
		if(tempFilePath.endsWith("/")){
			tempFilePath = tempFilePath+clearDateStr+"/";
		}else{
			tempFilePath = tempFilePath+"/"+clearDateStr+"/";
		}
		String fullName = tempFilePath + fileName;//文件绝对路径
		
		//生成对账文件
		logStr = "第三步,"+logHead+"生成对账文件["+fullName+"].";
		ReconGatewayFile fileBean =  null;
		try{
			fileBean = saveFile(tempFilePath, fullName, reconGateFileData);
			fileBean.setClearDate(clearDate);//设置清算日期
		}catch(Exception ex){
			logStr = logHead+"生成对账文件失败.";
			logger.error(logStr,ex);
			reconLogService.insertReconLog("ERROR", logHead+"出现异常:生成对账文件["+fullName+"]失败.");
			ReconGatewayFile errorBean = new ReconGatewayFile();
			errorBean.setRemark("生成对账文件失败:"+ex.getMessage());
			throw new ServiceException(logStr+ex);
		}	
		
		//保存生成网关对账文件表
		logStr = "第四步,"+logHead+"保存生成网关对账文件信息.";
		try{
			if(reconGatewayFile == null){
				//添加
				rDao.addReconGatewayFile(fileBean);
			}else{
				//更新
				rDao.updateReconGatewayFile(fileBean);
			}
		}catch(Exception ex){
			logStr = logHead+"保存生成网关对账文件信息失败.";
			logger.error(logStr,ex);
			reconLogService.insertReconLog("ERROR", logHead+"出现异常:保存生成网关对账文件信息失败.");
			throw new ServiceException(logStr+ex);
		}
			
		logger.info("{},生成信息:[{}]",logHead.toString(),fileBean);
		return fileBean;
	}
	
	/**
	 * 方法说明：<br>
	 * 上传FTP
	 *
	 * @param fullName
	 * @param clearDateStr yyyymmdd
	 */
	public void uploadGateReconFile(String filePath,String clearDateStr) throws ServiceException {
		if(isDebug){
			logger.debug("需要上传FTP的文件夹:[{}]",filePath);
		}
		if(filePath == null || "".equals(filePath = filePath.trim())){
			throw new ServiceException("","文件路径为空");
		}
		
		File pathFile = new File(filePath);
		String[] fileNames = pathFile.list();
		try{
			String serverIp = pDao.getParameter("GATEWAY_FTP_IP");
			int port = Integer.parseInt(pDao.getParameter("GATEWAY_FTP_PORT"));
			String userName = pDao.getParameter("GATEWAY_FTP_USERNAME");
			String password = pDao.getParameter("GATEWAY_FTP_PASSWORD");
			String ftpFilePath = pDao.getParameter("GATEWAY_FTP_FILE_PATH");
			if(!ftpFilePath.endsWith("/")){
				ftpFilePath = ftpFilePath+"/";
			}
			ftpFilePath = ftpFilePath + clearDateStr +"/";
			if(!filePath.endsWith("/")){
				filePath = filePath+"/";
			}
			
			if(fileNames != null && fileNames.length>0){
				for(int i = 0 ; i<fileNames.length ; i++){
					String fullName = filePath+fileNames[i];
					logger.info("网关对账文件[清算日期:{}],上传ftp信息：文件[{}],FTP服务IP[{}],FTP端口[{}],FTP文件存放路径[{}]"
								,new Object[]{clearDateStr,fullName,serverIp,port,ftpFilePath});
					Ftp4jUtil ftp = new Ftp4jUtil( serverIp,  port,  userName,  password);
					
					File file = new File(fullName);
					ftp.uploadFile(ftpFilePath, file);
				}
			}
		}catch(Exception ex){
			logger.error("上传FTP异常",ex);
			throw new ServiceException("",ex);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 检查是否可生成对账文件
	 *
	 * @param clearDate
	 * @throws ServiceException　需要区分异常码，异常码=InfoCode.RESPONSE_EXCEPTION为系统异常(日志级别为ERROR)
	 */
	private ReconGatewayFile checkBankRecon(Date clearDate,boolean allowAgain) throws ServiceException{
		//检查是否已经生成对账文件
		ReconGatewayFile reconGatewayFile = null;
		List<ReconGatewayFile> list =  null;
		try {
			list = rDao.selectReconGatewayFile(clearDate);
		} catch (Exception e) {
			logger.error("查询生成网关对账文件表异常",e);
			throw new ServiceException(InfoCode.RESPONSE_EXCEPTION,"查询生成网关对账文件表异常"+e);
		}
			
	   if(list != null && list.size() != 0){
			if(!allowAgain){
				throw new ServiceException(InfoCode.ERROR_MSG,"已生成网关对账文件.路径:["+list.get(0).getFilePath()+"]");
			}else if(list.size() == 1){
				reconGatewayFile = list.get(0);
			}else{
				throw new ServiceException(InfoCode.ERROR_MSG,"生成网关对账文件表数据异常，存在多条["+list.size()+"]生成记录");
			}
			logger.info("网关对账文件已经生成文件:[{}],现在开始重新生成.",reconGatewayFile.getFilePath());
		}else{
			logger.info("网关对账文件未生成");
		}
		
		
		//检查是否与银行对完账
	   List<HashMap<String,String>> tradeBankList = null;
	   List<HashMap<String,String>> reconBankList = null;
		try{
			tradeBankList = rDao.selectBank(clearDate,SystemSource.GATEWAY);
			if(tradeBankList == null || tradeBankList.size() == 0){
				logger.info("清算日期[{}]无交易",clearDate);
				return reconGatewayFile;
			}
			reconBankList = rDao.selectReconBank(clearDate);
		}catch(Exception ex){
			logger.error("检查是否对账完成异常",ex);
			throw new ServiceException(InfoCode.RESPONSE_EXCEPTION,"检查是否对账完成异常:"+ex);
		}
		
		int size = 0;
		for(int i=0;i<tradeBankList.size();i++) {
			HashMap<String,String> tradeMap = tradeBankList.get(i);
		    String tradeBank = tradeMap.get("BANKCODE").toString();
		    for(int j=0;j<reconBankList.size();j++){
		    	HashMap<String,String> reconMap = reconBankList.get(j);
		    	String reconBank = reconMap.get("BANKCODE").toString();
		    	if(tradeBank.equals(reconBank)){
		    		size++;
		    		break;
		    	}
		    }
		}
		
		if(size != tradeBankList.size()){
			throw new ServiceException(InfoCode.ERROR_MSG,"银行对账没有完成");
		}
		
		
		return reconGatewayFile;
	}

	/**
	 * 方法说明：<br>
	 * 生成对账文件
	 *
	 * @param tempFilePath 存放目录　
	 * @param fileName　文件名
	 * @param reconDate
	 * @param reconGateFileData
	 * @return
	 * @throws Exception
	 */
	private ReconGatewayFile saveFile(String tempFilePath,String fullName,List<ReconGateFile> reconGateFileData) throws Exception {
		 FileWriter writer = null;
		 PrintWriter pw = null; 
		try{
			File tempFile = new File(tempFilePath);
			if(!tempFile.exists()){
				try{
					tempFile.mkdirs();
				}catch(SecurityException e) {
					throw new IOException("[ It doesn't own the create directory rights. ]",e);
				}
			}
			
			if(isDebug){
				logger.debug("文件全路径:[{}]",fullName);
			}
			File file = new File(fullName);
			if(file.exists()){
				if(isDebug){
					logger.debug("已存在对账文件，删除文件，重新生成.全路径:[{}]",fullName);
				}
				try{
					file.delete();
				}catch(SecurityException e) {
					throw new IOException("[ It doesn't own the create directory rights. ]",e);
				}
			}
			//生成文件
			try{
				file.createNewFile();
			}catch(SecurityException e) {
				throw new IOException("[ It doesn't own the create directory rights. ]",e);
			}
			
			ReconGatewayFile fileBean = new ReconGatewayFile();
			fileBean.setFilePath(tempFilePath);
			
			if(reconGateFileData == null || reconGateFileData.size() == 0){
				if(isDebug){
					logger.debug("没有数据,生成空文件");
				}
				fileBean.setTotalAmt(0L);
				fileBean.setTotalNum(0L);
				fileBean.setRemark("没有数据,生成空文件");
				return fileBean;
			}
			
			
			 writer = new FileWriter(fullName);
			 pw=new PrintWriter(writer);
			 Long totalAmt = 0l;
			 
			 if(isDebug){
				 logger.debug("开始写入数据");
			 }
			for(ReconGateFile gateContent:reconGateFileData){
				String content = content(gateContent);
				if(isDebug){
					logger.debug("content:[{}]",content);
				}
				pw.println(content); 
				totalAmt += gateContent.getAmt();
			}
			if(isDebug){
				 logger.debug("数据写入完成");
			}
			
			fileBean.setTotalAmt(totalAmt);
			fileBean.setTotalNum(Long.valueOf(reconGateFileData.size()));
			fileBean.setRemark("总笔数:["+fileBean.getTotalNum()+"],总金额["+fileBean.getTotalAmt()+"]");
			return fileBean;
		}finally{
			try{
				if(pw != null){
					pw.flush();
					pw.close();
				}
//				pw已经同时关闭
//				if(writer != null){
//					writer.flush();
//					writer.close();
//				}
			}catch(Exception ex){
				logger.error("",ex);
			}
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 文件明细
	 *
	 * @param gateContent
	 * @return
	 */
	private String content(ReconGateFile gateContent) throws Exception{
		StringBuffer content = new StringBuffer();
		content.append(gateContent.getBankReqSn()).append("|")
				.append(gateContent.getAmt()).append("|")
				.append(gateContent.getStatus()).append("|")
				.append(DateUtil.getDateString(gateContent.getTradeDate(), DateUtil.DATA_FORMAT_PATTERN)).append("|")
				.append(DateUtil.getDateString(gateContent.getClearDate(), DateUtil.DATA_FORMAT_PATTERN)).append("|")
				.append(gateContent.getAppendBusType()==null?"":gateContent.getAppendBusType()).append("|");
		return content.toString();
	}

}
