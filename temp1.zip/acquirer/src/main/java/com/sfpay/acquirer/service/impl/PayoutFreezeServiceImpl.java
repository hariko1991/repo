/**
 * =================================================================
 * 版权所有 2011-2013 深圳市泰海网络科技服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IBatchInfoDao;
import com.sfpay.acquirer.dao.IPayoutInfoDao;
import com.sfpay.acquirer.dao.ITotalBatchInfoDao;
import com.sfpay.acquirer.domain.FreezeQueryParam;
import com.sfpay.acquirer.domain.PayoutFreezeParam;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutQueryRlt;
import com.sfpay.acquirer.enums.FreezeFlag;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.service.IPayoutFreezeService;
import com.sfpay.acquirer.service.IReconLogService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 *  
 * @author 400928 向鹏
 * 
 * CreateDate: 2013-11-11
 */
@Service("payoutFreezeService")
@HessianExporter
public class PayoutFreezeServiceImpl implements IPayoutFreezeService {
	private static Logger logger = LoggerFactory.getLogger(PayoutFreezeServiceImpl.class);

	@Resource
	private IPayoutInfoDao payoutInfoDao;
	
	@Resource
	private IBatchInfoDao batchDao;
	
	@Resource
	private ITotalBatchInfoDao totalBatchDao;
	
	@Resource
	private IReconLogService reconLogService;
	
	@Override
	public IPage<PayoutQueryRlt> queryFreezePage(FreezeQueryParam param,int pageNo, int pageSize) throws ServiceException {
		
		// 查询总记录数
		long count = payoutInfoDao.countFreezeInfos(param);
		List<PayoutQueryRlt> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			list = payoutInfoDao.queryFreezeInfos(param, start, end);
		}
		return new Page<PayoutQueryRlt>(list, count, pageNo, pageSize);	
		
	}

	/**
	 * 冻结/解冻
	 */
	@Override
	public void doFreeze(List<PayoutFreezeParam> param) throws ServiceException {
		if(param == null){
			throw new ServiceException(InfoCode.PARAM_INVALID,"冻结/解冻的请求参数为空");
		}
		List<PayoutStatus> statusList = new ArrayList<PayoutStatus>();
		statusList.add(PayoutStatus.INIT);
		statusList.add(PayoutStatus.BATCH);
		statusList.add(PayoutStatus.FIR_CHECK_PASS);
		
		List<String> freezePayoutNos = new ArrayList<String>();
		List<String> unfreezePayoutNos = new ArrayList<String>();
		String operator = "";
		for(PayoutFreezeParam req : param){
			//检查参数
			try{
				checkFreeze(req);
			}catch(Exception ex){
				continue;
			}
			operator = req.getOperator();
			
			if(FreezeFlag.Y.equals(req.getFreezeFlag())){
				//设置冻结付款编号
				freezePayoutNos.add(req.getPayoutNo());
			}else if(FreezeFlag.N.equals(req.getFreezeFlag())) {
				//设置解冻付款编号
				unfreezePayoutNos.add(req.getPayoutNo());
			}
		}
		
		//冻结
		if(freezePayoutNos.size() > 0){
			freeze(freezePayoutNos, FreezeFlag.Y, statusList,operator);
		}
		//解冻
		if(unfreezePayoutNos.size() > 0){
			unfreeze(unfreezePayoutNos, FreezeFlag.N,operator);
		}
		
		
	}
	
	/***
	 * 方法说明：<br>
	 * 解冻
	 *
	 * @param req
	 * @throws ServiceException
	 */
	private void unfreeze(List<String> unfreezePayoutNos,FreezeFlag freezeFlag,String operator) throws ServiceException {
		//修改冻结信息
		int cnt = 0;
		try {
			cnt = payoutInfoDao.updateFreeze(unfreezePayoutNos, freezeFlag, PayoutStatus.INIT,FreezeFlag.Y);
		} catch (Exception e) {
			logger.error("更新解冻信息异常",e);
		}
		logger.info("更新解冻信息的笔数为[{}]",cnt);
		if(cnt > 0){
			String log = String.format("解冻:操作员[%s],操作时间[%s].",operator,new Date());
			logger.info("记录解冻日志：[{}]...",log);
			try{
				reconLogService.insertReconLog("INFO", log);
			}catch(Exception ex){
				logger.info("记录["+log+"]异常",ex);
			}
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 冻结
	 *
	 * @param req
	 * @param statusList
	 * @throws ServiceException
	 */
	private void freeze(List<String> freezePayoutNos , FreezeFlag freezeFlag
			,List<PayoutStatus> statusList,String operator) throws ServiceException {
		logger.info("根据付款编号查询符合冻结要求的付款信息...");
		List<PayoutInfo> pis = payoutInfoDao.findByStatus(freezePayoutNos, statusList,FreezeFlag.N);
		if(null == pis || pis.size() == 0){
			logger.warn("不存在符合冻结要求的付款信息");
			return;
		}
		
		logger.info("更新冻结信息...");
		int cnt = 0;//冻结成功的笔数
		try {
			cnt = payoutInfoDao.updateFreeze(freezePayoutNos, freezeFlag,PayoutStatus.INIT, FreezeFlag.N);
		} catch (Exception e) {
			logger.error("[{}]更新冻结信息异常",e);
		}
		if(cnt == 0){
			logger.warn("更新冻结信息条数为[{}]",cnt);
			return;
		}
		
		List<String> bNos = new ArrayList<String>();//需要修改批次信息的批次号
		Map<String,String> bNoMap= new HashMap<String,String>();
		List<String> tpNos = new ArrayList<String>();//需要修改总批次信息的批次号
		Map<String,String> tbNoMap= new HashMap<String,String>();
		for(PayoutInfo pi : pis){
			//记录批次信息的付款编号
			if (!StringUtils.isEmpty(pi.getBatchCode()) && !bNoMap.containsKey(pi.getBatchCode())) {
				bNoMap.put(pi.getBatchCode(), pi.getBatchCode());
				bNos.add(pi.getBatchCode());
			}
			//记录总批次信息的付款编号
			if (!StringUtils.isEmpty(pi.getTotalBatchCode()) && !tbNoMap.containsKey(pi.getTotalBatchCode())) {
				tbNoMap.put(pi.getTotalBatchCode(), pi.getTotalBatchCode());
				tpNos.add(pi.getTotalBatchCode());
			}
		}
		
		//修改批次信息
		if(bNos.size() > 0){
			logger.info("修改批次信息...");
			try {
				batchDao.updateFreeze(bNos,"付款信息已经全部冻结");
			} catch (Exception e) {
				logger.error("修改批次冻结信息异常",e);
				throw new ServiceException(InfoCode.DATABASE_FAILURE,"修改批次信息失败",e);
			}
		}
		//修改总批次信息
		if(tpNos.size() > 0){
			logger.info("修改总批次信息...");
			try {
				totalBatchDao.updateFreeze(tpNos,"付款信息已经全部冻结");
			} catch (Exception e) {
				logger.error("修改总批次冻结信息异常",e);
				throw new ServiceException(InfoCode.DATABASE_FAILURE,"修改总批次信息失败",e);
			}
		}
		
		String log = String.format("冻结:操作员[%s],操作时间[%s].",operator,new Date());
		logger.info("记录冻结日志：[{}]...",log);
		try{
			reconLogService.insertReconLog("INFO", log);
		}catch(Exception ex){
			logger.info("记录["+log+"]异常",ex);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 检查冻结/解冻请求参数
	 *
	 * @param req
	 * @throws ServiceException
	 */
	private void checkFreeze(PayoutFreezeParam req) throws ServiceException {
		if (req == null) {
			String msg = "冻结/解冻对象为空";
			logger.error(msg);
			throw new ServiceException(InfoCode.PARAM_INVALID, msg);
		}
		if (StringUtils.isEmpty(req.getPayoutNo())) {
			String msg = "冻结/解冻的付款编号为空";
			logger.error(msg);
			throw new ServiceException(InfoCode.PARAM_INVALID, msg);
		}
		if (null == req.getFreezeFlag()) {
			String msg = String.format("[%s]操作类型(冻结/解冻)为空", req.getPayoutNo());
			logger.error(msg);
			throw new ServiceException(InfoCode.PARAM_INVALID, msg);
		}
		if (StringUtils.isEmpty(req.getOperator())) {
			String msg = String.format("[%s]冻结/解冻的操作员为空", req.getPayoutNo());
			logger.error(msg);
			throw new ServiceException(InfoCode.PARAM_INVALID, msg);
		}
	}

}
