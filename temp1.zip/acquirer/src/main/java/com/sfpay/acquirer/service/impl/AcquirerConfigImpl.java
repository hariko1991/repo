/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.Map;

import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.AcquirerHelper;
import com.sfpay.acquirer.domain.Account;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.acquirer.service.IAcquirerConfig;

/**
 * 
 * 类说明：<br>
 * 收单系统配置文件内存共享实现类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 <a href="mailto:fuyuxin@sf-express.com">符瑜鑫(Ricky Fu)</a>
 * 
 * CreateDate: 2012-5-8
 */
@Deprecated
@Service("acquirerConfig")
public class AcquirerConfigImpl implements IAcquirerConfig {
	
	@Override
	public BankProperty loadProperty(BankCode bank, ChannelCode channel) throws Exception {
		return AcquirerHelper.getProperties(bank, channel);
	}
	
	@Override
	public Map<String, BankProperty> loadProperty() throws Exception {
		return AcquirerHelper.getProperties();
	}

	@Override
	public Account loadAccount(BankCode bank, ChannelCode channel, OrderType type, FundWay fw) throws Exception {
		return AcquirerHelper.getAccount(bank, channel, type, fw);
	}

}
