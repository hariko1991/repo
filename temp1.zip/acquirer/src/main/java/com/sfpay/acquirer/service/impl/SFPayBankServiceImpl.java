/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.ISFPayBankDao;
import com.sfpay.acquirer.domain.SFPayBank;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.service.ISFPayBankService;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-7-23
 */
@Deprecated
@Service("sfPayBankService")
public class SFPayBankServiceImpl implements ISFPayBankService {
	
	private static final Logger logger = LoggerFactory.getLogger(SFPayBankServiceImpl.class);
	
	@Resource
	private ISFPayBankDao dao;

	@Override
	public SFPayBank findSFPayBank(ChannelCode channel, String sfpBank) throws ServiceException {
		if(null == channel) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "渠道编码不能为空");
		}
		if(StringUtils.isEmpty(sfpBank)) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "顺银银行编码不能为空");
		}
		try {
			return dao.findBank(channel, sfpBank);
		} catch (Exception e) {
			logger.error(String.format("查询[%s]顺银银行编码[%s]对应的银行映射异常", channel, sfpBank), e);
		}
		return null;
	}

	@Override
	public List<SFPayBank> querySFPayBank(ChannelCode channel) throws ServiceException {
		try {
			return dao.queryBank(channel);
		} catch (Exception e) {
			logger.error("查询顺银银行编码对应的银行映射异常", e);
		}
		return null;
	}

}
