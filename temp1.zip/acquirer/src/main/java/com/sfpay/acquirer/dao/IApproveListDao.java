package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.paycenter.ApproveListInfo;
import com.sfpay.acquirer.domain.paycenter.ApproveListParam;


public interface IApproveListDao {
	
	
	public long queryApproveListPageCount(@Param("param") ApproveListParam param);
	
	public List<ApproveListInfo> queryApproveListByPage(@Param("param") ApproveListParam param, @Param("start") int start, @Param("end") int end);
	
	public ApproveListInfo queryApproveListById(Long id);
	
	public void delApproveList(Long id);
	
	public void updateApproveListById(@Param("param") ApproveListInfo param);

	public void addApproveList(@Param("param") ApproveListInfo param);
	
	public List<ApproveListInfo> queryApproveListByAcctSetNo(@Param("param") ApproveListInfo param);
	
	//public List<ApproveListInfo> queryApproveListByAll(@Param("param") ApproveListInfo param);
	
	public List<ApproveListInfo> queryApproveListByAcctSetFlag(@Param("param") ApproveListInfo param);
	
	public void updateApproveListDelete(@Param("param") ApproveListInfo param);
	
	public List<ApproveListInfo> queryApproveListByAcctSetNoAgain(@Param("param") ApproveListInfo param);
	
	public void updateApproveListDeleteById(Long id);
	
	public void updateApproveListDeleteByUsername(@Param("param") ApproveListInfo param);
	
	public void updateApproveListDeleteByUsernameAll(@Param("param") ApproveListInfo param);
	
	public List<ApproveListInfo> queryApproveListByAcctSetNoThird(@Param("param") ApproveListInfo param);
	
	public long checkAcctSetNo(@Param("param") ApproveListInfo param);
	
	public long queryApproveListInfoByAll(@Param("param") ApproveListInfo param);

}
