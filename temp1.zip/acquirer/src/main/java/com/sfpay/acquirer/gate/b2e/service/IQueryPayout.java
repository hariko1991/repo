package com.sfpay.acquirer.gate.b2e.service;

import java.util.List;

import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.BatchInfo;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutRespResult;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.PayoutSendStatus;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;

/**
 * 
 * 
 * 类说明：<br>
 * B2E查询(付款指令结果)请求、响应接口类.
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-4-27
 */
public interface IQueryPayout {
	/**
	 * 方法说明：<br>
	 * 组装请求报文.<br>
	 * 
	 * @return
	 * @throws Exception
	 */
	public PayoutSendStatus doReq(BatchInfo bi, List<PayoutInfo> info, BankProperty property, BankCode bankCode, BatchRuleInfo rule) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 解析响应报文并封装成具体的响应Bean.
	 * 
	 * @return
	 * @throws Exception
	 */
	public PayoutRespResult doResp(BeanBase respBean) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 解析响应报文并封装成具体的响应Bean.
	 * 
	 * @return
	 * @throws Exception
	 */
	public PayoutRespResult doQuery(BatchInfo bi, List<PayoutInfo> info, BankProperty property, BankCode bankCode, BatchRuleInfo rule) throws Exception;
	
}
