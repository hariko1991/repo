/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service;

import com.sfpay.acquirer.domain.DataTrans;

/**
 * 类说明：<br>
 * 与银行交互的数据报文接口
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-8-28
 */
public interface IDataTransService {
	
	/**
	 * 方法说明：<be>
	 * 插入数据交互信息
	 */
	public void addDataTrans(DataTrans dt);
	
	/**
	 * 方法说明：<br>
	 * 修改数据交互信息
	 */
	public void updateDataTrans(DataTrans dt);
}
