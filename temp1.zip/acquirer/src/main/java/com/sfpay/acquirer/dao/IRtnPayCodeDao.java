package com.sfpay.acquirer.dao;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.RtnPayCodeInfo;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;

/**
 * 类说明：<br>
 * 对系统返回错误码的查询与维护
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * @author 349508 韦健 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-8-28
 */
public interface IRtnPayCodeDao {
	
	/**
	 * 根据银行编码，渠道，错误返回码取得对照的系统错误返回码对象
	 */
	public RtnPayCodeInfo findRtnPayCode(@Param("channel") ChannelCode channel, @Param("bank") BankCode bank, @Param("rtnCode") String rtnCode) throws Exception;

}
