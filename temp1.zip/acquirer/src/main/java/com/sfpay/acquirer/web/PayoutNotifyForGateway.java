/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.web;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.web.domain.PayoutNotifyItem;
import com.sfpay.acquirer.web.domain.PayoutNotifyRlt;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.gateway.domain.SettleRlt;
import com.sfpay.gateway.enums.SettleStatus;
import com.sfpay.gateway.service.ISettleService;

/**
 * 类说明：<br>
 * 付款结果通知Gat系统,暂时由收单提供.后续版本优化时由Gat系统提供
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-11-21
 */
@Controller
@RequestMapping(value="/notify/gateway")
public class PayoutNotifyForGateway {
	private static final Logger logger = LoggerFactory.getLogger(PayoutNotifyForCod.class);
	
	private static final String SUCCESS = "SUCCESS";
	private static final String FAILURE = "FAILURE";
	
	@Resource
	private ISettleService settle;
	
	@RequestMapping(value="/payout")
	public void payoutNotify(String result, HttpServletResponse resp) {
		logger.info("[GAT]接收付款通知报文:{}", result);
		PayoutNotifyRlt rlt = new PayoutNotifyRlt();
		try {
			rlt.parse(result);
		} catch (Exception e) {
			logger.error("解析付款通知报文异常", e);
			return;
		}
		if(rlt.getItem().size() == 0) {
			logger.info("[GAT]处理付款通知结束[无处理结果]");
			return;
		}
		logger.info("[GAT]付款通知转换实体:[{}]", rlt.toString());
		List<SettleRlt> ls = new ArrayList<SettleRlt>();
		for(Iterator<PayoutNotifyItem> it = rlt.getItem().iterator(); it.hasNext(); ) {
			SettleRlt sr = convert2Bean(it.next());
			if(null != sr) {
				ls.add(sr);
			}
		}
		if(ls.size() == 0) {
			logger.info("[GAT]处理付款通知结束[无处理结果]");
			return;
		}
		try {
			settle.updateSettle(ls);
		} catch (Exception e) {
			logger.error("[GAT]处理付款通知异常", e);
		}
		logger.info("[GAT]处理付款通知结束");
	}
	
	/**
	 * 方法说明：<br>
	 * 转换GATEWAY对象
	 */
	private SettleRlt convert2Bean(PayoutNotifyItem item) throws ServiceException {
		if(StringUtils.isEmpty(item.getTradeOutNo()) || StringUtils.isEmpty(item.getStatus())) {
			return null;
		}
		SettleRlt rlt = new SettleRlt();
		rlt.setSettleNo(item.getTradeOutNo());
		rlt.setRetCode(item.getRtnBankCode());
		rlt.setRetMsg(item.getReturnMsg());
		if(SUCCESS.equals(item.getStatus())) {
			rlt.setStatus(SettleStatus.SUCCESS_PAY);
		} else if(FAILURE.equals(item.getStatus())) {
			rlt.setStatus(SettleStatus.FAILURE_PAY);
		}
		return rlt;
	}
}
