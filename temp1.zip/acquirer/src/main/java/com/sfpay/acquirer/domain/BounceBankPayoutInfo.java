package com.sfpay.acquirer.domain;

import java.util.Date;

import com.sfpay.framework.base.entity.BaseEntity;

/**
 * @author sfhq270
 *  退票文件信息
 *  2015-01-19
 */
public class BounceBankPayoutInfo extends BaseEntity{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8747985005479150765L;
	/**
	 * 付款请求流水号
	 */
	private String reqBankSn;
	/**
	 * 接收时间
	 */
	private Date  rcvTime;
	/**
	 * BATCHPAY:批量代付  SINGLEPAY 单笔代付
	 */
	private String  transBussType;
	/**
	 * 明细序号
	 */
	private String  detailLstNo;
	/**
	 * 币种
	 */
	private String  ccy;
	/**
	 * 退汇金额
	 */
	private Long    amt;
	/**
	 * 处理状态
	 */
	private String  status;
	/**
	 * 返回码
	 */
	private String  retCode;
	/**
	 * 对账日期
	 */
	private Date  checkDate;
	/**
	 * 清算日期
	 */
	private Date  clearDate;
	/**
	 * 清算场次
	 */
	private String  clearNo;
	/**
	 * 备注
	 */
	private String  remark;
	
	/**
	 * 出款渠道
	 */
	private String payChannelCode;
	
	/**
	 * 系统来源
	 */
	private String 	systemSource; 
	
	/**
	 * 创建时间
	 */
	private Date createTime;
	
	/**
	 * 更新时间
	 */
	private Date updateTime;
	
	/**
	 * 更新人
	 */
	private String updateId;
	
	/**
	 * 处理状态 0：未处理 1：已处理
	 */
	private String handleFlag;
	
	public String getReqBankSn() {
		return reqBankSn;
	}
	public void setReqBankSn(String reqBankSn) {
		this.reqBankSn = reqBankSn;
	}
	public Date getRcvTime() {
		return rcvTime;
	}
	public void setRcvTime(Date rcvTime) {
		this.rcvTime = rcvTime;
	}
	public void setCheckDate(Date checkDate) {
		this.checkDate = checkDate;
	}
	public Date getCheckDate() {
		return checkDate;
	}
	public Date getClearDate() {
		return clearDate;
	}
	public void setClearDate(Date clearDate) {
		this.clearDate = clearDate;
	}
	public String getTransBussType() {
		return transBussType;
	}
	public void setTransBussType(String transBussType) {
		this.transBussType = transBussType;
	}
	public String getDetailLstNo() {
		return detailLstNo;
	}
	public void setDetailLstNo(String detailLstNo) {
		this.detailLstNo = detailLstNo;
	}
	public String getCcy() {
		return ccy;
	}
	public void setCcy(String ccy) {
		this.ccy = ccy;
	}
	public Long getAmt() {
		return amt;
	}
	public void setAmt(Long amt) {
		this.amt = amt;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}
	public String getUpdateId() {
		return updateId;
	}
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}
	public String getHandleFlag() {
		return handleFlag;
	}
	public void setHandleFlag(String handleFlag) {
		this.handleFlag = handleFlag;
	}
	
	public String getRetCode() {
		return retCode;
	}
	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}
	public String getClearNo() {
		return clearNo;
	}
	public void setClearNo(String clearNo) {
		this.clearNo = clearNo;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getPayChannelCode() {
		return payChannelCode;
	}
	public void setPayChannelCode(String payChannelCode) {
		this.payChannelCode = payChannelCode;
	}
	public String getSystemSource() {
		return systemSource;
	}
	public void setSystemSource(String systemSource) {
		this.systemSource = systemSource;
	}
}
