/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.dao.IBankChannelArgDao;
import com.sfpay.acquirer.domain.BankChannelArg;
import com.sfpay.acquirer.domain.BankChannelArgQueryParam;
import com.sfpay.acquirer.domain.BankChannelArgUpdateParam;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.service.IBankChannelArgService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 
 * 类说明： 银行渠道参数配置
 * 
 * <p/>
 * 详细描述：
 * 
 * 
 * @author 312932 何国兴
 * 
 *         CreateDate: 2012-5-28
 */
@Deprecated
@Service("bankChannelArgService")
@HessianExporter
public class BankChannelArgServiceImpl implements IBankChannelArgService {

	@Resource
	private IBankChannelArgDao dao;

	@Override
	public IPage<BankChannelArg> queryBankChannelArgPage(BankChannelArgQueryParam param, int pageNo, int pageSize) throws ServiceException {
		// 查询总记录数
		long count = dao.queryBankChannelArgPageCount(param);
		List<BankChannelArg> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			list = dao.queryBankChannelArgPageList(param, start, end);
		}
		return new Page<BankChannelArg>(list, count, pageNo, pageSize);
	}

	@Override
	public void updateBankChannelArgById(BankChannelArgUpdateParam param) throws ServiceException {
		if (param.getId() <= 0L) {
			throw new ServiceException(InfoCode.INPUT_PARAM_ID_IS_NULL, "input param id is null");
		}
		dao.updateBankChannelArgById(param);
	}

	@Override
	public BankProperty getBankChannelArgs(BankCode bank, ChannelCode channel) throws ServiceException {
		List<BankChannelArg> rs = dao.findBankChannelArgs(bank, channel);
		BankProperty property = new BankProperty(rs.size() << 1);
		property.setBank(bank);
		property.setChannel(channel);
		for (BankChannelArg arg : rs) {
			property.put(arg.getArgKey(), arg.getArgValue());
		}
		return property;
	}
	
	@Override
	public Map<String, BankProperty> getBankChannelArgs() throws ServiceException {
		List<BankChannelArg> ls = dao.findAllArgs();
		BankProperty property = null;
		Map<String, BankProperty> rs = new HashMap<String, BankProperty>();
		StringBuffer compKey = new StringBuffer(20);
		String pKey = null;
		for (BankChannelArg arg : ls) {
			compKey.setLength(0);
			pKey = compKey.append(arg.getChannelCode()).append("_").append(arg.getBankCode()).toString();
			property = rs.get(pKey);
			if(null == property) {
				property = new BankProperty();
				property.setChannel(ChannelCode.valueOf(arg.getChannelCode()));
				property.setBank(BankCode.valueOf(arg.getBankCode()));
				rs.put(pKey, property);
			}			
			property.put(arg.getArgKey(), arg.getArgValue());
		}
		return rs;
	}

	@Override
	public BankChannelArg queryBankChannelArgById(long id) throws ServiceException {
		return dao.queryBankChannelArgById(id);
	}

}
