package com.sfpay.acquirer.task;

import java.util.Calendar;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.service.IPayoutReconService;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 
 * 类说明：<br>
 * 银企（付款）对账 调度任务
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-8-14
 */
@Service("payoutReconTask")
public class PayoutReconTask {
	private static final Logger logger = LoggerFactory.getLogger(PayoutReconTask.class);

	@Resource
	private IPayoutReconService recon;
	
	public void execute() throws ServiceException {
		Calendar cal = Calendar.getInstance();
		cal.set(Calendar.DATE,cal.get(Calendar.DATE)-1);//对昨天的
		logger.info("开始执行[{}]银企付款对账",cal.getTime());
		recon.doRecon(cal.getTime());
		logger.info("[{}]银企付款对账执行结束",cal.getTime());
	}
}
