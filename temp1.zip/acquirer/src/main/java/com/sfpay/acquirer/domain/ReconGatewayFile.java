/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.domain;

import java.util.Date;

/**
 * 
 * 类说明：<br>
 * 生成网关对账文件 实体类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-7-22
 */
public class ReconGatewayFile extends AcqBaseEntity{

	private static final long serialVersionUID = -1212356593015698786L;

	
	/**
	 * RECON_DATE	N	DATE	N			对账日期
	 */
	private Date reconDate;
	
	/**
	 * CLEAR_DATE	N	DATE	N			清算日期 非真正交易日期，包含交易日期、调账日期
	 */
	private Date clearDate;
	
	/**
	 * TOTAL_AMT	N	NUMBER(16)	N			总金额，单位：分
	 */
	private Long totalAmt;
	
	/**
	 * TOTAL_NUM	N	NUMBER(16)	N			总笔数
	 */
	private Long totalNum;
	
	/**
	 * FILE_PATH	N	VARCHAR2(200)	N			文件路径
	 */
	private String filePath;
	
	/**
	 * BUILD_DATE	N	TIMESTAMP(6)	N			文件生成日期
	 */
	private Date buildDate;

	public Date getClearDate() {
		return clearDate;
	}

	public void setClearDate(Date clearDate) {
		this.clearDate = clearDate;
	}

	public Date getReconDate() {
		return reconDate;
	}

	public void setReconDate(Date reconDate) {
		this.reconDate = reconDate;
	}

	public Long getTotalAmt() {
		return totalAmt;
	}

	public void setTotalAmt(Long totalAmt) {
		this.totalAmt = totalAmt;
	}

	public Long getTotalNum() {
		return totalNum;
	}

	public void setTotalNum(Long totalNum) {
		this.totalNum = totalNum;
	}

	public String getFilePath() {
		return filePath;
	}

	public void setFilePath(String filePath) {
		this.filePath = filePath;
	}

	public Date getBuildDate() {
		return buildDate;
	}

	public void setBuildDate(Date buildDate) {
		this.buildDate = buildDate;
	}
}
