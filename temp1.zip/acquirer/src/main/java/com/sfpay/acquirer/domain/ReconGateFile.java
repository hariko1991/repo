/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.domain;

import java.util.Date;

import com.sfpay.acquirer.enums.AppendBusType;
import com.sfpay.acquirer.enums.CollectStatus;

/**
 * 
 * 类说明：<br>
 * 网关对账文件字段
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-7-22
 */
public class ReconGateFile implements java.io.Serializable {

	private static final long serialVersionUID = -1356887116134740641L;

	/**
	 * 交易流水号	OUT_BANK_REQ_SN	VARCHAR2(30)	30		FALSE	FALSE	TRUE
	 */
	private String bankReqSn;
	
	/**
	 * 交易金额	OUT_AMT	NUMBER(16)	16		FALSE	FALSE	TRUE
	 */
	private Long amt;
	
	/**
	 * 交易时间	OUT_TRADE_DATE	DATE			FALSE	FALSE	TRUE
	 */
	private Date tradeDate;
	
	/**
	 * 清算日期
	 */
	private Date clearDate;
	
	/**
	 * 交易状态	OUT_STATUS	VARCHAR2(10)	10		FALSE	FALSE	TRUE
	 */
	private CollectStatus status;
	/**
	 * 附加业务类型	OUT_APPEND_BUS_TYPE	VARCHAR2(10)	10		FALSE	FALSE	FALSE
	 */
	private AppendBusType appendBusType;
	
	
	public Date getClearDate() {
		return clearDate;
	}
	public void setClearDate(Date clearDate) {
		this.clearDate = clearDate;
	}
	public String getBankReqSn() {
		return bankReqSn;
	}
	public void setBankReqSn(String bankReqSn) {
		this.bankReqSn = bankReqSn;
	}
	public Long getAmt() {
		return amt;
	}
	public void setAmt(Long amt) {
		this.amt = amt;
	}
	public Date getTradeDate() {
		return tradeDate;
	}
	public void setTradeDate(Date tradeDate) {
		this.tradeDate = tradeDate;
	}
	public CollectStatus getStatus() {
		return status;
	}
	public void setStatus(CollectStatus status) {
		this.status = status;
	}
	public AppendBusType getAppendBusType() {
		return appendBusType;
	}
	public void setAppendBusType(AppendBusType appendBusType) {
		this.appendBusType = appendBusType;
	}
	
	
	
}
