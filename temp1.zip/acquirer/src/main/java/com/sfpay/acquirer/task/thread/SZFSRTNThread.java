package com.sfpay.acquirer.task.thread;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.IInsertAll;
import com.sfpay.acquirer.InsertAllExecutor;
import com.sfpay.acquirer.common.CurrencyUtil;
import com.sfpay.acquirer.common.rb.AbstractBankFileThread;
import com.sfpay.acquirer.dao.rb.IBankBounceFileDao;
import com.sfpay.acquirer.domain.rb.szfs.BankBounceFile;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.MsgType;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;


/**
 * 结算中心退票线程
 * @author sfhq272
 */
@Service
public class SZFSRTNThread extends AbstractBankFileThread<BankBounceFile> {
	private static final Logger logger = LoggerFactory.getLogger(SZFSRTNThread.class);

	@Resource
	private IBankBounceFileDao bankBounceFileDao;
	
	@Override
	protected void processor(String tradeDateStr, Date tradeDate, Date curDate) {
		String logStr = "";
		logger.info("结算中心和银企退票[{}],导入外部临时表[{}].",tradeDateStr,localFullFileName);
		try{
			importFileData();
		}catch(Exception ex){
			logStr = "结算中心和银企退票["+tradeDateStr+"],导入外部临时表异常["+localFullFileName+"].";
			logger.error(logStr,ex);
			reconLogService.insertReconLog("ERROR", logStr);
			throw new ServiceException(logStr+ex);
		}
	}


	@Override
	public BankBounceFile converContent2Object(String content)
			throws ServiceException {
		
		content = content + " ";
		String[] contents = content.split("\\,");
		if(16 != contents.length){
			throw new ServiceException("RTN文件内容格式有误,信息长度"+contents.length);
		}
		BankBounceFile temp = new BankBounceFile();
		String reqBankSn = "";
		if(contents[2].equals(MsgType.BATCHPAY.name())){
			temp.setOutid(contents[3]);
		}else if(contents[2].equals(MsgType.SINGLEPAY.name())){
			StringBuffer sb = new StringBuffer(Property.getProperty("SZFS_CORPNO")).append(Property.getProperty("SZFS_SINGLEPAY_BUSINESSCODE"));
			int sbLength = sb.length();
			reqBankSn = contents[3].substring(sbLength);
			temp.setOutid(contents[3]);
		}
		temp.setReqBankSn(reqBankSn);
		temp.setRcvDate(DateUtil.getDateFormatStr(contents[0].trim(), DateUtil.DATA_FORMAT_PATTERN));         
		temp.setTransType(contents[4]);       
		temp.setLstNo(contents[8]);           
		temp.setCcy(contents[9]);         
		temp.setReturnMoney(CurrencyUtil.yuan2Fen(contents[10]));     
		temp.setStatus(contents[11]);           
		temp.setRetcode(contents[12]);          
		temp.setCheckDate(DateUtil.getDateFormatStr(contents[1], DateUtil.DATA_FORMAT_PATTERN_2));       
		temp.setClearDate(DateUtil.getDateFormatStr(contents[13].trim(), DateUtil.DATA_FORMAT_PATTERN_2));       
		temp.setClearNo(contents[14]);         
		temp.setPayChannelCode(BankCode.SZFS); 
		temp.setHandleFlag("0");      
		temp.setRemark(contents[15]);           
		temp.setMsgType(contents[2]);         
		return temp;
	}


	/**
	 * 方法说明：<br>
	 * 导入对账文件数据
	 *
	 * @throws ServiceException
	 */
	private void importFileData() throws ServiceException {
		if(null == localFullFileName || "".equals(localFullFileName)){
			logger.warn("无效的文件名!");
			throw new ServiceException("RTN文件无效,请确认是否下载完整文件!");
		}

		List<BankBounceFile> temp = readFile(true,"GBK");

		//导入数据库
		logger.info("[{}]交易总数:[{}]",localFullFileName,temp.size());

		try {
			InsertAllExecutor.insert(temp, new IInsertAll<BankBounceFile>() {
				public void execute(List<BankBounceFile> sbuLs) throws Exception {
					bankBounceFileDao.addSZFSBounceList(sbuLs);//导入数据库
					//返回更新payout_info
					bankBounceFileDao.updatePayoutInfoForBounce(sbuLs);
				}
			});
		} catch (Exception e) {
			logger.error("导入外部数据异常",e);
			throw new ServiceException("导入外部数据异常:"+e);
		}
	}

	@Override
	public void initLocalFullName(String tradeDateStr) {
		try{
			StringBuffer tempName = new StringBuffer(Property.getProperty("SZFS_CHANNEL")).append("_").
					append(Property.getProperty("SZFS_CORPNO")).append("_").append(tradeDateStr).append(".").
					append(Property.getProperty("SZFS_RTN_SUFFIX"));
			fileName = tempName.toString();
		} catch (Exception e) {
			logger.error("初始化文件全名错误"+fileName,e);
			throw new ServiceException("初始化文件全名错误:"+fileName+e);
		}
	}
	
	@Override
	public String initLocalFullPath(String localPath, String tradeDateStr) {
		return (localPath.endsWith("/") ? localPath : localPath+"/") + tradeDateStr + "/BOUNCE/";
	}

}
