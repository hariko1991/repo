/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.dao.IAccountInfoDao;
import com.sfpay.acquirer.domain.Account;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.AccountInfoQueryParam;
import com.sfpay.acquirer.domain.AccountInfoUpdateParam;
import com.sfpay.acquirer.enums.AccountInfoStatus;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.acquirer.service.IAccountInfoService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework.common.util.StringUtils;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 
 * 类说明：
 * 集团账户 实现类
 * 
 * <p/>
 * 详细描述：
 * 银行开设的账户信息    
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-5-29
 */
@Deprecated
@Service("accountInfoService")
@HessianExporter
public class AccountInfoServiceImpl implements IAccountInfoService {
	
	@Resource
	private IAccountInfoDao accountInfoDao;
	
	@Override
	public IPage<AccountInfo> queryAccountInfoPage(AccountInfoQueryParam param, int pageNo, int pageSize) throws ServiceException {
		//查询总记录数
		long count = accountInfoDao.queryAccountInfoPageCount(param);
		IPage<AccountInfo> page = null;
		if(count != 0){
			if(pageNo <= 0){
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			//查询当前页记录
			List<AccountInfo> list = accountInfoDao.queryAccountInfoPageList(param, start, end);
			page = new Page<AccountInfo>(list, count, pageNo, pageSize);
		}	
		return page;
	}
	
	@Override
	public AccountInfo queryAccountInfo(Long id) throws ServiceException {
		if(null == id || id < 0) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "id can't be null");
		}
		return accountInfoDao.queryAccountInfo(id);
	}

	@Override	
	public void updateStatus(String accountNo, AccountInfoStatus status, String remark) {
		if(StringUtils.isNullOrEmpty(accountNo)) {
			throw new ServiceException(InfoCode.ACCOUNT_NO_IS_NULL, "银行账户号不能为空");
		}
		if(null == status) {
			throw new ServiceException(InfoCode.STATUS_IS_NULL, "状态不能为空");
		}
		accountInfoDao.updateStatus(accountNo, status, remark);
	}

	@Override	
	public void updateAccountInfo(AccountInfoUpdateParam param) {
		if(null == param) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "参数不能为空");
		}
		if(StringUtils.isNullOrEmpty(param.getAccountNo())) {
			throw new ServiceException(InfoCode.ACCOUNT_NO_IS_NULL, "银行账户号不能为空");
		}
		//如果所有字段都不设置值,是否循环判断不更新?
		accountInfoDao.updateAccountInfo(param);
	}
	
	@Override	
	public void updateAccountInfoById(AccountInfoUpdateParam param) {
		if(null == param) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "参数不能为空");
		}
		if(StringUtils.isNullOrEmpty(param.getAccountNo())) {
			throw new ServiceException(InfoCode.ACCOUNT_NO_IS_NULL, "银行账户号不能为空");
		}
		if(param.getBankCode()==null) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "updateAccountInfoById method's parameter[bankCode] is null");
		}
		if(param.getId()==0L) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "updateAccountInfoById method's parameter[id] is null");
		}
		if(StringUtils.isNullOrEmpty(param.getAccountName())) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "updateAccountInfoById method's parameter[accountName] is null");
		}
		if(StringUtils.isNullOrEmpty(param.getStoreCode())) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "updateAccountInfoById method's parameter[storeCode] is null");
		}
				
		accountInfoDao.updateAccountInfoById(param);
	}
	

	@Override	
	public void addAccountInfo(AccountInfoUpdateParam param) {
		if(null == param) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "参数不能为空");
		}
		if(null == param.getBankCode()) {
			throw new ServiceException(InfoCode.BANK_CODE_IS_NULL, "银行编号不能为空");
		}
		if(StringUtils.isNullOrEmpty(param.getAccountNo())) {
			throw new ServiceException(InfoCode.ACCOUNT_NO_IS_NULL, "银行账户号不能为空");
		}
		if(StringUtils.isNullOrEmpty(param.getStoreCode())) {
			throw new ServiceException(InfoCode.STORE_CODE_IS_NULL, "银行分配的商户代码不能为空");
		}
		accountInfoDao.addAccountInfo(param);
	}
	
	@Override
	public Account getAccount(BankCode bank, ChannelCode channel, OrderType type, FundWay fw) {
		return accountInfoDao.findAccount(bank, channel, type, fw);
	}

	@Override
	public List<AccountInfo> queryAccountInfoList(ChannelCode channelCode,BankCode bankCode)
			throws ServiceException {
		if(channelCode==null) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "queryAccountInfoList method's parameter[channelCode] is null");
		}
		if(bankCode==null) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "queryAccountInfoList method's parameter[bankCode] is null");
		}
		return accountInfoDao.queryAccountInfoList(channelCode, bankCode);
	}

	@Override
	public List<AccountInfo> queryBankPayoutReconAccountInfoList(String sysChannelCode) {
		return accountInfoDao.queryBankPayoutReconAccountInfoList(sysChannelCode);
	}
	
}
