package com.sfpay.acquirer.gate.b2e.command;

import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.PayoutRespResult;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelPayType;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.gate.b2e.BaseCommand;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.QuerySinglePayInfo;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * @author sfhq272
 * 结算中心单笔代付查询接口
 */
public class QuerySinglePayTransfer extends BaseCommand {
	
	private PayoutInfo info;
	private BankCode bankCode;
	
	public QuerySinglePayTransfer(){
		super(TradeCodeB2E.QUERY_SZFS_SINGLEPAY);
	}
	
	public QuerySinglePayTransfer(BankCode bankCode, PayoutInfo info){
		super(TradeCodeB2E.QUERY_SZFS_SINGLEPAY);
		this.info = info;
		this.bankCode = bankCode;
	}

	@Override
	protected BeanBase assemble(BankProperty property) throws Exception {
		try{
			
			//设置报文头
			BeanBase bean = new BeanBase(bankCode, super.tradeCodeB2E);
			
			bean.setSeqNo(CUID.getSZFSMsgNo());
			bean.setBankProperties(property);
			
			
			QuerySinglePayInfo  detail = new QuerySinglePayInfo();
			detail.setSubSerialId(info.getReqBankSn());
			detail.setPayerAccNo(info.getPayerAcctNo());
			detail.setPayerAccName(info.getPayerAcctName());
			detail.setSendTime(DateUtil.getCDateString(DateUtil.DATA_FORMAT_PATTERN));
			
			detail.setAmt(info.getAmt());
			detail.setPayeeAccNo(info.getPayeeAcctNo());
			bean.setBusDetailBeanBase(detail);
			
			
			return bean;
		}catch(Exception ex){
			logger.error("单笔代付[请求号:" + info.getReqBankSn() + "] 生成查询结果报文异常:",ex);
			throw new ServiceException(InfoCode.FAILURE, ex);
		}
	}

	@SuppressWarnings("unchecked")
	@Override
	protected PayoutRespResult parseMsg(
			com.sfpay.acquirer.gate.b2e.domain.BeanBase respBean)
			throws Exception {
		PayoutRespResult resp = new PayoutRespResult();
		
		QuerySinglePayInfo detail = (QuerySinglePayInfo)respBean.getBusDetailBeanBase();
		
		resp.setChannelPayType(ChannelPayType.SINGLE_PAY);
		resp.setReqBankSn(detail.getSubSerialId());
		resp.setRtnBankCode(detail.getBankRetCode());
		if(detail.getBankRetMsg() == null || "".equals(detail.getBankRetMsg())){
			resp.setRtnBankMsg(detail.getRetMsg());
		}else {
			resp.setRtnBankMsg(detail.getBankRetMsg());
		}
		resp.setPayoutStatus(PayoutStatus.convertToSinglePayoutStatus((detail.getRetCode())));
		resp.setRemark(detail.getRetMsg());
		
		return resp;
	}


}
