/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.common;

import java.util.LinkedList;
import java.util.Queue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.service.IRepeatInvoke;

/**
 * 类说明：
 * 异步重发队列帮助类.用于重发机制处理
 * 
 * <p>
 * 详细描述：
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * CreateDate: 2013-12-21
 * 
 */
public class RepeatInvokeHelper {
	private static final Logger logger = LoggerFactory.getLogger(RepeatInvokeHelper.class);

    private Queue<IRepeatInvoke> queue = new LinkedList<IRepeatInvoke>();
    
    private static RepeatInvokeHelper _ins;
    
    private RepeatInvokeHelper() {//单例模式
    }
    
    public static RepeatInvokeHelper getInstance() {
        if(null == _ins) {
            synchronized (RepeatInvokeHelper.class) {
                if(null == _ins) {
                    _ins = new RepeatInvokeHelper();
                    new Thread(_ins.taskRun).start();
                }
            }
        }
        return _ins;
    }
    
    public void addQueue(IRepeatInvoke task) {
        queue.add(task);
    }
    
    // 支付线程
    private Runnable taskRun = new Runnable() {
        @Override
        public void run() {
        	logger.info("开始执行异步线程...");
            while (true) {
            	if(queue.isEmpty()) {
            		continue;
            	}
	            try {
	            	IRepeatInvoke task = queue.poll();
	                task.execute();
	            } catch (Exception e) {
	                logger.error("异步线程执行异常", e);
	            }
            }
        }
    };
    
}
