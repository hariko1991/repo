package com.sfpay.acquirer.service.impl;

import java.util.Date;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.AcquirerHelper;
import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.CollectInfo;
import com.sfpay.acquirer.domain.PaymentReq;
import com.sfpay.acquirer.domain.PaymentRespParam;
import com.sfpay.acquirer.domain.PaymentResult;
import com.sfpay.acquirer.domain.qpay.QPayPrepareRlt;
import com.sfpay.acquirer.enums.AcqBizType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.gate.AcquirerBizFactory;
import com.sfpay.acquirer.gate.IPayment;
import com.sfpay.acquirer.gate.annotation.cache.RespParamMap;
import com.sfpay.acquirer.gate.annotation.parser.PaymentParser;
import com.sfpay.acquirer.service.IQPayBankInterfaceService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;

/**
 * 
 * 
 * 类说明：<br>
 * 快捷支付退款
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-3-27
 */
@Deprecated
@Service("qpayBankInterfaceService")
public class QPayBankInterfaceService implements IQPayBankInterfaceService {
	private final Logger logger = LoggerFactory.getLogger(QPayBankInterfaceService.class);

	@Override
	public QPayPrepareRlt doQPayPaymentPrepare(CollectInfo in)
			throws ServiceException {
		//入参判断在acq-web处,此处不再判断
		logger.info("========== 执行的快捷支付[{}]请求... ==========", in.getOrderType().getText());
		PaymentReq param = null;
		IPayment gate = AcquirerBizFactory.getInstance(in.getBankCode(), in.getChannelCode(), AcqBizType.PAYMENT);
		BankProperty properties = AcquirerHelper.getProperties(in.getBankCode(), in.getChannelCode());
		
		try {
			//生成银行请求流水号、交易开始日期
			in.setBeginTime(new Date());
			in.setReqBankSn(CUID.generate(20));
			in.setResultUrl(Property.getProperty("URL_QPAY_NOTIFY").replace("{0}", "0"));
			param = gate.send(in, properties);
		} catch (Exception e) {
			logger.error("",e);
			throw new ServiceException(InfoCode.FAILURE, "支付请求报文异常",e);
		}
		//生成银行支付请求参数域,&连接.
		PaymentParser.buildQueryParam(param);
		
		QPayPrepareRlt rlt = new QPayPrepareRlt();
		rlt.setUrl(param.getAction());
		rlt.setQueryParam(param.getQueryParam());
		rlt.setProperties(properties);
		rlt.setCollectNo("");
		logger.info("========== 快捷支付[{}]请求处理完毕. ==========", in.getOrderType().getText());
		return rlt;
	}

	@Override
	public CollectInfo doQPayPaymentPost(CollectInfo in,
			String xml) throws ServiceException {
		logger.info("========== 处理银行请求流水号为[{}]的快捷支付回调... ==========", in.getReqBankSn());
		BankCode bank = in.getBankCode();
		ChannelCode channel = in.getChannelCode();
		
		Map<String, String[]> param = PaymentParser.convert2Map(xml, null);
		
		IPayment gate = AcquirerBizFactory.getInstance(bank, channel, AcqBizType.PAYMENT);
		BankProperty properties = AcquirerHelper.getProperties(bank, channel);
		logger.info("调用[{}]-{}支付网关解析报文", bank, in.getChannelCode());
		PaymentRespParam respParam = null;
		PaymentResult rs = null;
		respParam = PaymentParser.convert(RespParamMap.get(bank, channel), param);
		try {
			rs = gate.receive(respParam, properties);
		} catch (Exception e) {
			logger.error(bank+"处理银行回调异常", e);
			throw new ServiceException(InfoCode.FAILURE, bank+"处理银行回调异常", e);
		}
		logger.info("报文解析结果: {}", rs.toString());
		
		//转换返回参数
		in.setStatus(rs.getCollectStatus());
		in.setRtnBankSn(rs.getRtnBankSn());
		in.setRtnBankMsg(rs.getRtnBankMsg());
		in.setRtnBankCode(rs.getRtnBankCode());
		return in;
	}

}
