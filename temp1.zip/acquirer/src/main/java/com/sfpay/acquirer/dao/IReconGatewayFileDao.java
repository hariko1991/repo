/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.dao;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.ReconGateFile;
import com.sfpay.acquirer.domain.ReconGatewayFile;
import com.sfpay.acquirer.enums.SystemSource;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-7-22
 */
public interface IReconGatewayFileDao {
	
	/**
	 * 方法说明：<br>
	 * 添加
	 *
	 * @param reconGatewayFile
	 * @throws Exception
	 */
	public void addReconGatewayFile(ReconGatewayFile reconGatewayFile) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 根据对账日期修改
	 *
	 * @param reconGatewayFile
	 * @return
	 * @throws Exception
	 */
	public int updateReconGatewayFile(ReconGatewayFile reconGatewayFile) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 查询对账数据对应的交易，共有哪几家银行
	 *
	 * @param reconDate
	 * @return
	 * @throws Exception
	 */
	public List<HashMap<String,String>> selectBank(@Param("tradeDate")Date tradeDate,@Param("systemSource")SystemSource systemSource) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 查询已经对账几家银行
	 *
	 * @param reconDate
	 * @return
	 * @throws Exception
	 */
	public List<HashMap<String,String>> selectReconBank(@Param("tradeDate")Date tradeDate) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 根据对账日期查询网关对账文件
	 *
	 * @param reconDate
	 * @return
	 * @throws Exception
	 */
	public List<ReconGatewayFile> selectReconGatewayFile(@Param("clearDate")Date clearDate) throws Exception;
	
	/**
	 * 方法说明：<br>
	 * 根据对账日期查询网关对账文件数据
	 *
	 * @param reconDate
	 * @return
	 * @throws Exception
	 */
	public List<ReconGateFile> findGatyFileData(@Param("tradeDate")Date tradeDate,@Param("systemSource")SystemSource systemSource) throws Exception;

}
