/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.service.impl;

import java.text.MessageFormat;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.common.AcquirerHelper;
import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.ICollectInfoDao;
import com.sfpay.acquirer.dao.IDualDao;
import com.sfpay.acquirer.dao.IRtnPayCodeDao;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.ChannelRateInfo;
import com.sfpay.acquirer.domain.CollectInfo;
import com.sfpay.acquirer.domain.DataTrans;
import com.sfpay.acquirer.domain.PaymentReq;
import com.sfpay.acquirer.domain.PaymentResp;
import com.sfpay.acquirer.domain.PaymentRespParam;
import com.sfpay.acquirer.domain.PaymentResult;
import com.sfpay.acquirer.domain.ProcessRlt;
import com.sfpay.acquirer.domain.ReverseInfo;
import com.sfpay.acquirer.domain.RtnPayCodeInfo;
import com.sfpay.acquirer.enums.AcqBizType;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.ChargeType;
import com.sfpay.acquirer.enums.CmdStatus;
import com.sfpay.acquirer.enums.CollectStatus;
import com.sfpay.acquirer.enums.CommonTradeType;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.PackageFlag;
import com.sfpay.acquirer.gate.AcquirerBizFactory;
import com.sfpay.acquirer.gate.IPayment;
import com.sfpay.acquirer.gate.annotation.cache.RespParamMap;
import com.sfpay.acquirer.gate.annotation.parser.PaymentParser;
import com.sfpay.acquirer.service.IChangelRateService;
import com.sfpay.acquirer.service.IDataTransService;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 类说明：<br>
 * B2C、QPay公共收款类实现
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-8-26
 */
@Deprecated
abstract class BaseCollcetInfoImpl {
	protected final Logger logger = LoggerFactory.getLogger(getClass());
	protected final boolean isDebug = logger.isDebugEnabled();
	
	@Resource
	protected ICollectInfoDao collectInfoDao;
	
	@Resource
	protected IDualDao dualDao;
	
	@Resource
	private IDataTransService dataTransService;
	
	@Resource
	private IChangelRateService changelRateService;
	
	@Resource
	private IRtnPayCodeDao rtnPayCodeDao;
	
	/**
	 * 方法说明：<br>
	 * 处理银行报文组装,并同步更新对应的收单记录状态<br>
	 * 共用于B2C,快捷支付过程
	 * 
	 * @throws ServiceException
	 */
	protected ProcessRlt processBankXml(CollectInfo ci, boolean isFormType) throws ServiceException {
		//生成支付请求信息
		PaymentReq param = null;
		BankProperty properties = null;
		try {			
			properties = AcquirerHelper.getProperties(ci.getBankCode(), ci.getChannelCode());//TODO 使用分布式缓存?Ricky Fu
			logger.info(String.format("组装收单[%s][%s-%s]银行报文...", ci.getCollectNo(), ci.getChannelCode(), ci.getBankCode()));
			IPayment gate = AcquirerBizFactory.getInstance(ci.getBankCode(), ci.getChannelCode(), AcqBizType.PAYMENT);
			param = gate.send(ci, properties);
			if(isFormType) {
				PaymentParser.buildPaymentArgs(param);//生成银行支付表单域(前端采用Ajax时得不到).Ricky Fu.
				logger.info("收单[{}]请求报文:\n\t{}", ci.getCollectNo(), param.getPaymentArgs());
			} else {
				PaymentParser.buildQueryParam(param);//生成银行支付请求参数域,&连接.Ricky Fu.
				logger.info("收单[{}]请求报文:\n\t{}", ci.getCollectNo(), param.getQueryParam());
			}
		} catch (Exception e) {
			String eMsg = String.format("组装收单[%s][%s-%s]银行报文异常", ci.getCollectNo(), ci.getChannelCode(), ci.getBankCode());
			logger.error(eMsg, e);
			throw new ServiceException(InfoCode.FAILURE, eMsg, e);
		}
		
		saveDataTrans(ci, param, isFormType);//保存数据交互表
		
		if(null == ci.getReqBankSn()) {//B2C为null,QPay已更新过
			updateReqBankSN(param.getSerieNo(), ci.getCollectNo());
		}
		
		param.setCollectNo(ci.getCollectNo());//将保存后的收单编号送给订单系统
		logger.info("收单[{}]处理完成.", ci.getCollectNo());
		return new ProcessRlt(ci.getCollectNo(), param, properties); 
	}
	
	/**
	 * 方法说明：<br>
	 * 银行回调后解析报文,更新状态等处理过程
	 * 
	 * @param collectNo 收单编号
	 * @param rev 撤销/退款信息Bean
	 * @param param 银行回调参数
	 * @return
	 * @throws Exception
	 */
	protected PaymentResp doBankInvoke(String collectNo, ReverseInfo rev, Map<String, String[]> param) throws Exception {//B2C,QPay
		logger.info("===== 银行回调[{}]开始... =====", collectNo);
		logger.info("回调[{}]参数: {}", collectNo, PaymentParser.concat(param));
		if(null == param || param.isEmpty()) {//易宝可能传回空参数.RickyFu
			logger.info("===== 银行回调[{}]结束【空报文】 =====", collectNo);
			return null;
		}
		CollectInfo info = collectInfoDao.findByCollectNo(collectNo);
		if(null == info) {
			String eMsg = String.format("找不到收单[%s]流水", collectNo);
			logger.error(eMsg);
			throw new ServiceException(InfoCode.FAILURE, eMsg);
		}
		
		PaymentResult rs = null;
		PaymentRespParam respParam = null;
		BankCode bank = info.getBankCode();
		ChannelCode channel = info.getChannelCode();
		try {
			//走网银通道处理回调逻辑
			BankProperty properties = AcquirerHelper.getProperties(bank, channel);//TODO 使用分布式缓存?Ricky Fu
			logger.info(String.format("解析收单[%s][%s-%s]报文...", collectNo, channel, bank));
			respParam = PaymentParser.convert(RespParamMap.get(bank, channel), param);
			IPayment gate = AcquirerBizFactory.getInstance(bank, channel, AcqBizType.PAYMENT);
			rs = gate.receive(respParam, properties);
		} catch (Exception e) {
			String eMsg = String.format("收单[%s][%s-%s]报文解析异常", collectNo, channel, bank);
			logger.error(eMsg, e);
			throw new ServiceException(InfoCode.FAILURE, eMsg, e);
		}
		if(null == rs) {
			logger.info("===== 银行回调[{}]结束【无解析】 =====", collectNo);
			return null;
		}
		if(isDebug) {
			logger.debug("收单[{}]报文解析结果: {}", collectNo, rs.toString());
		}
		if(rs.isIgnore()) {//忽略该次通知
			/**忽略银行回调, 不通知订单系统 **/
			PaymentResp resp = new PaymentResp();
			resp.setPayNo(info.getPayNo());//支付订单需要送回给前台
			resp.setBusinessSn(info.getBusinessSn());
			resp.setRepeat(false);
			resp.setInvoke(false);//不通知订单系统
			if(isDebug) {
				logger.debug("回调[{}]回传参数: {}", collectNo, resp.toString());
			}
			logger.info("===== 银行回调[{}]结束【忽略】 =====", collectNo);
			return resp;
		}
		
		//银行重复回调时直接返回,各银行不需要自己判断.RickyFu
		if(!CollectStatus.INIT.equals(info.getStatus())) {//重复回调时直接返回(非INIT状态即可)
			/**银行回调,不允许重复通知订单系统 **/
			PaymentResp resp = new PaymentResp();
			resp.setPayNo(info.getPayNo());//支付订单需要送回给前台
			resp.setReqBankSn(info.getReqBankSn());//发送给银行的流水号
			resp.setRtnBankSn(info.getRtnBankSn());//银行返回的交易流水号
			resp.setStatus(info.getStatus());
			resp.setOutput(rs.getOutput());//易宝会返回两次成功通知，回调后统一都设置为success
			resp.setBusinessSn(info.getBusinessSn());
			resp.setRepeat(true);
			resp.setInvoke(false);
			if(isDebug) {
				logger.debug("回调[{}]回传参数: {}", collectNo, resp.toString());
			}
			logger.info("===== 银行回调[{}]结束【重复】 =====", collectNo);
			return resp;
		}
		
		/* 根据银行编码，渠道，错误（构建查询条件）返回码取得对照的系统错误返回码对象update by weijian*/
		String rtnPayCode = null;
		if(!StringUtils.isEmpty(rs.getRtnBankCode())) {
			RtnPayCodeInfo rtnPay = rtnPayCodeDao.findRtnPayCode(channel, bank, rs.getRtnBankCode());
			rtnPayCode = null == rtnPay ? rs.getRtnBankCode() : rtnPay.getRtnCode();
		}
		
		updateDataTrans(info, respParam, rs, rtnPayCode);//更新数据交互表
		
		int hasUpd = -1;
		if(null != rev && !StringUtils.isEmpty(rev.getCollectNo())) {//撤销,退款
			String oriNo = rev.getCollectNo();
			String text = rev.getReverseType().getText();
			try {
				//更新原收单记录状态
				logger.info("更新收单流水[{}]<{}>信息...", oriNo, text);
				hasUpd = collectInfoDao.updateByReverse(rev);//更新状态为成功的原交易
			} catch (Exception e) {
				String eMsg = String.format("更新收单流水[%s]<%s>信息异常", oriNo, text);
				logger.error(eMsg, e);
				throw new ServiceException(InfoCode.DATABASE_FAILURE, eMsg, e);
			}
		} else {
			hasUpd = 1;//B2C需要更新
		}
		
		long upcnt = -1;
		if(hasUpd == 1) {
			//更新收单记录状态
			logger.info("更新收单[{}]信息...(状态: {})", info.getCollectNo(), rs.getCollectStatus());
			CollectInfo ci = new CollectInfo();
			ci.setStatus(rs.getCollectStatus());// 收单状态
			ci.setRtnBankSn(rs.getRtnBankSn()); // 银行返回的交易流水号
			ci.setRtnBankCode(rs.getRtnBankCode()); // 银行返回码
			ci.setRtnBankMsg(rs.getRtnBankMsg()); // 银行返回结果描述
			ci.setRemark(rs.getRemark()); // 备注
			ci.setRtnPayCode(rtnPayCode); // 支付系统返回代码
			ci.setCollectNo(info.getCollectNo()); // 收单编号
			try {
				upcnt = collectInfoDao.updateForBankCall(ci);//更新当前交易
			} catch(Exception e) {
				String eMsg = String.format("更新收单[%s]异常", collectNo);
				logger.error(eMsg, e);
				throw new ServiceException(InfoCode.DATABASE_FAILURE, eMsg, e);
			}
		}
		//返回
		PaymentResp resp = new PaymentResp();
		resp.setPayNo(info.getPayNo());//支付订单需要送回给前台
		resp.setReqBankSn(info.getReqBankSn());//发送给银行的流水号
		resp.setRtnBankSn(info.getRtnBankSn());//银行返回的交易流水号
		resp.setStatus(rs.getCollectStatus());
		resp.setOutput(rs.getOutput());
		resp.setBusinessSn(info.getBusinessSn());
		resp.setRepeat(false);
		resp.setInvoke(upcnt == 1);//有更新到记录才通知订单系统
		if(isDebug) {
			logger.debug("回调[{}]回传参数: {}", collectNo, resp.toString());
		}
		logger.info("===== 银行回调[{}]结束【首次】 =====", collectNo);
		return resp;
	}
	
	/**
	 * 方法说明：<br>
	 * 创建收单流水,并设置对应的回调地址
	 * 
	 * @param ci 传入的参数,不含collectNo
	 * @param hasReqNo 是否需要生成银行请求流水号(QPay需要)
	 * @throws ServiceException
	 */
	protected void createCollectInfo(CollectInfo ci, boolean hasReqNo) throws ServiceException {
		logger.info("创建收单流水...");
		if(hasReqNo) {//是否需要生成银行请求流水号,QPay需要
			String serieNo = null;
			try {
				serieNo = CUID.generate(20);
			} catch (Exception e) {
				logger.error("生成银行请求流水号异常", e);
				throw new ServiceException(InfoCode.DATABASE_FAILURE, "生成银行请求流水号异常", e);
			}
			ci.setReqBankSn(serieNo);//先生成银行请求流水号,传入指令接口以便于发短信
		}
		try {
			collectInfoDao.createCollectInfo(ci);//回调地址在DB中格式化.RickyFu
			//以下DB中已经设置,因MyBatis无法返回保存的实体,故在代码中做相同设置以供网关接口调用(减少DB查询).Ricky Fu
			if(!StringUtils.isEmpty(ci.getResultUrl()) && ci.getResultUrl().indexOf("{0}") > 0) {
				ci.setResultUrl(new MessageFormat(ci.getResultUrl()).format(new Object[]{ci.getCollectNo()}));
			}
			if(!StringUtils.isEmpty(ci.getFrontUrl()) && ci.getFrontUrl().indexOf("{0}") > 0) {
				ci.setFrontUrl(new MessageFormat(ci.getFrontUrl()).format(new Object[]{ci.getCollectNo()}));
			}
		} catch (Exception e) {
			logger.error("创建收单流水异常", e);
			throw new ServiceException(InfoCode.FAILURE, "创建收单流水异常", e);
		}
		logger.info("收单流水[{}]已生成.", ci.getCollectNo());
	}
	
	/**
	 * 计算手续费
	 * @param bank
	 * @param channel
	 * @param amt
	 * @param chargeType
	 * @param fundWay
	 * @return
	 */
	protected Long getFee(BankCode bank, ChannelCode channel, Long amt, ChargeType chargeType, FundWay fundWay) {
		if(!FundWay.IN.equals(fundWay)) {
			return 0L;
		}
		ChannelRateInfo rate = changelRateService.queryChannelRateInfo(amt, bank, channel, chargeType);
		if(null == rate) {
			logger.error("找不到对应费率,无法计算手续费");
			throw new ServiceException(InfoCode.FAILURE, "找不到对应费率,无法计算手续费");
		}
		Double doubleTmp = (amt.doubleValue()*rate.getFeeRate());
		return doubleTmp.longValue();
	}
	
	/**
	 * 方法说明：<br>
	 * 更新银行收单流水
	 * 
	 * @param serieNo 对应的银行订单编号
	 * @param collectNo 收单编号
	 */
	private void updateReqBankSN(String serieNo, String collectNo) {
		logger.info("更新收单[{}]银行请求流水号[{}]...", collectNo, serieNo);
		//更新收单记录表的银行流水和状态
		CollectInfo ci = new CollectInfo();
		ci.setReqBankSn(serieNo);
		ci.setCollectNo(collectNo);
		try{
			collectInfoDao.updateByCollectNo(ci);
		} catch(Exception e) {
			logger.error("更新银行收单流水异常", e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE, "更新银行收单流水异常", e);
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 保存数据交互表.By优化单[201308029].RickyFu,20130826
	 */
	private void saveDataTrans(CollectInfo ci, PaymentReq param, boolean isFormType) {
		DataTrans dt = new DataTrans();
		dt.setBankCode(ci.getBankCode());
		dt.setChannelCode(ci.getChannelCode());
		dt.setDataTransType(CommonTradeType.PAY);
		dt.setSerieNo(param.getSerieNo());//REQ_BANK_SN
		dt.setPackageFlag(PackageFlag.SINGLE);
		dt.setBeginTime(ci.getBeginTime());
		dt.setRequestMsg(isFormType ? param.getPaymentArgs() : param.getQueryParam());//SEND_MSG,向银行发送的请求报文信息
		dataTransService.addDataTrans(dt);
	}
	
	/**
	 * 方法说明：<br>
	 * 更新数据交互表.By优化单[201308029].RickyFu,20130826
	 */
	private void updateDataTrans(CollectInfo ci, PaymentRespParam param, PaymentResult rs, String rtnCode) {
		DataTrans dt = new DataTrans();
		dt.setBankCode(ci.getBankCode());
		dt.setChannelCode(ci.getChannelCode());
		dt.setSerieNo(ci.getReqBankSn());
		dt.setReceiveMsg(param.oriBuf());//银行回传参数串,统一设置.
		dt.setBankSerieNo(rs.getRtnBankSn());
		dt.setBankRetCode(rs.getRtnBankCode());
		dt.setBankRetMsg(rs.getRtnBankMsg());
		dt.setPayRetCode(rtnCode);//写入支付系统返回代码 
		dt.setCmdStatus(CmdStatus.SUCCESS);
		dt.setEndTime(dualDao.getDBDatetime());
		dataTransService.updateDataTrans(dt);
	}
}
