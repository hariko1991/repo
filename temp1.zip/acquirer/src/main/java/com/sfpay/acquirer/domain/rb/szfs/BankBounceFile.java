package com.sfpay.acquirer.domain.rb.szfs;

import java.util.Date;

import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 渠道对应的服务器上的对账文件对应的bean   
 * 针对RTN和ADJ文件
 * @author sfhq272
 *
 */
public class BankBounceFile extends BaseEntity{
	/**
	 * 
	 */
	private static final long serialVersionUID = 8747985005479150765L;
	
	private String	reqBankSn;      
	private Date  rcvDate;         
	private String  transType;       
	private String  lstNo;           
	private String  ccy;         
	private Long  returnMoney;     
	private String  status;           
	private String  retcode;          
	private Date  checkDate;       
	private Date  clearDate;       
	private String  clearNo;         
	private BankCode  payChannelCode; 
	private String  handleFlag;      
	private Date  createDate;      
	private String  updateId;        
	private Date  updateDate;      
	private String  remark;           
	private String  msgType;         
	private String  lstOutid;        
	private Long  payMoney;        
	private String  returnFlag;      
	private String  reverseFlag;     
	private String  outid;
	
	public String getReqBankSn() {
		return reqBankSn;
	}
	public void setReqBankSn(String reqBankSn) {
		this.reqBankSn = reqBankSn;
	}
	public String getTransType() {
		return transType;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
	public String getLstNo() {
		return lstNo;
	}
	public void setLstNo(String lstNo) {
		this.lstNo = lstNo;
	}
	public String getCcy() {
		return ccy;
	}
	public void setCcy(String ccy) {
		this.ccy = ccy;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRetcode() {
		return retcode;
	}
	public void setRetcode(String retcode) {
		this.retcode = retcode;
	}
	public Date getRcvDate() {
		return rcvDate;
	}
	public void setRcvDate(Date rcvDate) {
		this.rcvDate = rcvDate;
	}
	public Date getCheckDate() {
		return checkDate;
	}
	public void setCheckDate(Date checkDate) {
		this.checkDate = checkDate;
	}
	public Date getClearDate() {
		return clearDate;
	}
	public void setClearDate(Date clearDate) {
		this.clearDate = clearDate;
	}
	public String getClearNo() {
		return clearNo;
	}
	public void setClearNo(String clearNo) {
		this.clearNo = clearNo;
	}
	public String getHandleFlag() {
		return handleFlag;
	}
	public void setHandleFlag(String handleFlag) {
		this.handleFlag = handleFlag;
	}
	public String getUpdateId() {
		return updateId;
	}
	public void setUpdateId(String updateId) {
		this.updateId = updateId;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getMsgType() {
		return msgType;
	}
	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}
	public String getLstOutid() {
		return lstOutid;
	}
	public void setLstOutid(String lstOutid) {
		this.lstOutid = lstOutid;
	}
	public String getReturnFlag() {
		return returnFlag;
	}
	public void setReturnFlag(String returnFlag) {
		this.returnFlag = returnFlag;
	}
	public String getReverseFlag() {
		return reverseFlag;
	}
	public void setReverseFlag(String reverseFlag) {
		this.reverseFlag = reverseFlag;
	}
	public String getOutid() {
		return outid;
	}
	public void setOutid(String outid) {
		this.outid = outid;
	}
	public Long getReturnMoney() {
		return returnMoney;
	}
	public void setReturnMoney(Long returnMoney) {
		this.returnMoney = returnMoney;
	}
	public BankCode getPayChannelCode() {
		return payChannelCode;
	}
	public void setPayChannelCode(BankCode payChannelCode) {
		this.payChannelCode = payChannelCode;
	}
	public Date getCreateDate() {
		return createDate;
	}
	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}
	public Date getUpdateDate() {
		return updateDate;
	}
	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
	public Long getPayMoney() {
		return payMoney;
	}
	public void setPayMoney(Long payMoney) {
		this.payMoney = payMoney;
	}   
	
}
