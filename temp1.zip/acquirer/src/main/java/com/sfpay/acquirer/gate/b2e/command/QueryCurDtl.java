/**
 * =================================================================
 * 版权所有 2011-2013 深圳市泰海网络科技服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.gate.b2e.command;

import java.util.Date;

import com.sfpay.acquirer.common.CUID;
import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.domain.AccountInfo;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.QueryCurDtlInfo;
import com.sfpay.acquirer.gate.b2e.enums.TradeCodeB2E;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 类说明：当日明细查询
 * 
 * 
 * <p>
 * 详细描述：封装账户当日明细查询报文
 * 
 * 
 * </p>
 * 
 * @author 349508 韦健
 * 
 * CreateDate: 2013-5-17
 */
public class QueryCurDtl extends BaseQuery{
	//集团账户
	private AccountInfo acct;
	//银行信息
	private BankCode bankCode;
	
	public QueryCurDtl(AccountInfo acct){
		super(TradeCodeB2E.QUERY_CUR_DTL);
		this.acct = acct;
		this.bankCode = acct.getBankCode();
	}

	@Override
	public BeanBase assemble(BankProperty property) throws Exception {
		try{
			//交易名称
			BeanBase bean = new BeanBase(bankCode, super.tradeCodeB2E);
			/**
			 * 用于结算中心报文序列号
			 * sfh270   2014-12-03
			 */
			bean.setSeqNo(CUID.getSZFSMsgNo());
			bean.setBankProperties(property);
			//获取当日明细查询实体类
			QueryCurDtlInfo detail=new QueryCurDtlInfo();
			//交易流水号
			detail.setSerialId(CUID.generateId4B2E(20));
			//设置时间
			detail.setSendTime(DateUtil.getCDateString(DateUtil.DATA_FORMAT_PATTERN));
			//账号
			detail.setAccNo(acct.getAccountNo());
			//户名
			detail.setAccName(acct.getAccountName());
			//开户行
			detail.setOpenBranchName(acct.getOpeningBankName());
			//中行联行号
			if(BankCode.BOC.equals(bankCode)){
				detail.setBocBankCode(acct.getOpeningBankNo());
			}
			//城市
			detail.setCity(acct.getCityName());
			//币种
			detail.setCur(acct.getCcy());
			
			Date queryDate = new Date();
			detail.setStartDate(DateUtil.getDateString(queryDate, "yyyyMMdd"));
			//结束时间
			detail.setEndDate(DateUtil.getDateString(queryDate, "yyyyMMdd"));
			//设置分行号和分行名称
			detail.setSubBankName(acct.getSubBankName());
			detail.setSubBankNo(acct.getSubBankNo());
			
			bean.setBusDetailBeanBase(detail);
			
			return bean;
		}catch(Exception ex){
			logger.error("当日明细查询组包错误！",ex);
			throw new ServiceException(InfoCode.FAILURE, ex);
		}
		
	}
	
}
