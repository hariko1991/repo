package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IOftenColInfoDao;
import com.sfpay.acquirer.domain.OftenColInfo;
import com.sfpay.acquirer.domain.OftenColInfoQueryParam;
import com.sfpay.acquirer.service.IOftenColInfoService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 
 * 类说明：<br>
 * 常用收款单位表信息
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 349508 韦健
 * @author 312932 何国兴
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2012-11-12
 */
@Service("oftenColInfoService")
@HessianExporter
public class OftenColInfoServiceImpl implements IOftenColInfoService{
	private static Logger logger = LoggerFactory.getLogger(OftenColInfoServiceImpl.class);
	
	@Resource
	private IOftenColInfoDao oftenColInfoDao;

	/**
	 * 方法说明：
	 * 分页查询常用收款单位信息      当页数据
	 * @param map 查询条件
	 * @return
	 */ 
	public IPage<OftenColInfo> queryOftenColInfoPage(OftenColInfoQueryParam param, int pageNo, int pageSize) throws ServiceException {
		//查询总记录数
		long count = oftenColInfoDao.queryOftenColInfoPageCount(param);
		List<OftenColInfo> list = null;
		if(count > 0) {
			if(pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			//查询当前页记录
			list = oftenColInfoDao.queryOftenColInfoPageList(param, start, end);
		}	
		return new Page<OftenColInfo>(list, count, pageNo, pageSize);
	}
	
	/**
	 * 方法说明：
	 * 根据主键id查询常用收款单位信息 
	 * @param id 查询id
	 * @return
	 */
	public OftenColInfo queryOftenColInfoById(long id) throws ServiceException {
		if(id <= 0) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "id can't be null");
		}
		return oftenColInfoDao.queryOftenColInfoById(id);
	}
	
	/**
	 * 方法说明：
	 * 根据账号查询常用收款单位信息
	 * 存在则只会有一条记录，不存在返回null
	 * @param accountNo 账号
	 * @return
	 */
	public OftenColInfo queryOftenColInfoByAcctNo(String accountNo) throws ServiceException {
		if(StringUtils.isEmpty(accountNo)){
			throw new ServiceException(InfoCode.PARAM_INVALID, "accountNo can't be null");
		}
		return oftenColInfoDao.queryOftenColInfoByAcctNo(accountNo);
	}
	
	
	/**
	 * 方法说明：
	 * 查询所有常用收款单位信息       
	 * @return
	 */
	public List<OftenColInfo> listAllOftenColInfo()throws ServiceException{
		return oftenColInfoDao.listAllOftenColInfo();
	}
	
	/**
	 * 方法说明：
	 * 增加常用收款单位信息  
	 * @return
	 */
	public void addOftenColInfo(OftenColInfo data)throws ServiceException{
		if(data==null){
			throw new ServiceException(InfoCode.PARAM_INVALID, "param can't be null");
		}
		if(data.getBankCode()==null){
			throw new ServiceException(InfoCode.PARAM_INVALID, "bankCode can't be null");
		}		
		if(StringUtils.isEmpty(data.getAccountNo())){
			throw new ServiceException(InfoCode.PARAM_INVALID, "accountNo can't be null");
		}
		if(StringUtils.isEmpty(data.getAccountName())){
			throw new ServiceException(InfoCode.PARAM_INVALID, "accountName can't be null");
		}
		if(data.getAcctType()==null){
			throw new ServiceException(InfoCode.PARAM_INVALID, "acctType can't be null");
		}
		//根据账号查询是否已经存在有收款单位，有不能添加
		OftenColInfo dbCol = oftenColInfoDao.queryOftenColInfoByAcctNo(data.getAccountNo());
		if(dbCol!=null){
			throw new ServiceException(InfoCode.ACCOUNTNO_EXIST,data.getAccountNo());
		}
		//增加
		try{
			oftenColInfoDao.addOftenColInfo(data);
		}catch(Exception e){
			logger.error("addOftenColInfo error:{}",e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE,"database error:"+e);
		}
	}
	
	/**
	 * 方法说明：
	 * 修改常用收款单位信息       
	 * @return
	 */
	public void updateOftenColInfoById(OftenColInfo param)throws ServiceException{
		if(param==null){
			throw new ServiceException(InfoCode.PARAM_INVALID, "param can't be null");
		}
		if(param.getId() <= 0) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "id can't be null");
		}
		if(param.getBankCode()==null){
			throw new ServiceException(InfoCode.PARAM_INVALID, "bankCode can't be null");
		}		
		if(StringUtils.isEmpty(param.getAccountNo())){
			throw new ServiceException(InfoCode.PARAM_INVALID, "accountNo can't be null");
		}
		if(StringUtils.isEmpty(param.getAccountName())){
			throw new ServiceException(InfoCode.PARAM_INVALID, "accountName can't be null");
		}
		if(param.getAcctType()==null){
			throw new ServiceException(InfoCode.PARAM_INVALID, "acctType can't be null");
		}
		//根据账号查询是否已经存在有收款单位，有不能添加
		OftenColInfo dbCol = oftenColInfoDao.queryOftenColInfoByAcctNo(param.getAccountNo());
		if(dbCol!=null && dbCol.getId()!=param.getId()){
			throw new ServiceException(InfoCode.ACCOUNTNO_EXIST,"accountNo is Exist,please change accountNo");
		}
		oftenColInfoDao.updateOftenColInfoById(param);
	}
	
	/**
	 * 方法说明：
	 * 删除常用收款单位信息       
	 * @return
	 */
	public void deleteOftenColInfo(List<Long>ids)throws ServiceException{
		if(ids==null || ids.size()==0){
			throw new ServiceException(InfoCode.PARAM_INVALID, "ids can't be null");
		}
		oftenColInfoDao.deleteOftenColInfo(ids);
	} 
	
	
	
	/**
	 * 方法说明：
	 * 分页查询常用收款单位信息      当页数据
	 * @param map 查询条件
	 * @return
	 */ 
	public IPage<OftenColInfo> queryEcsOftenColInfoPage(OftenColInfoQueryParam param, int pageNo, int pageSize) throws ServiceException {
		//查询总记录数
		long count = oftenColInfoDao.queryEcsOftenColInfoPageCount(param);
		List<OftenColInfo> list = null;
		if(count > 0) {
			if(pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			//查询当前页记录
			list = oftenColInfoDao.queryEcsOftenColInfoPageList(param, start, end);
		}	
		return new Page<OftenColInfo>(list, count, pageNo, pageSize);
	}
	

}
