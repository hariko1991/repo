/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.web.domain;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.digester3.Digester;

import com.sfpay.acquirer.domain.RespXml;

/**
 * 类说明：<br>
 * 付款通知结果.目前暂为COD、PAS、GATEWAY使用.若此3部分代码移除,则可删除此类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 * CreateDate: 2013-11-21
 */
public class PayoutNotifyRlt extends RespXml {
	private static final long serialVersionUID = 1666753472367956820L;
	/**
	 * 付款类型
	 */
	private String type;
	/**
	 * 付款详情
	 */
	private List<PayoutNotifyItem> item = new ArrayList<PayoutNotifyItem>();

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<PayoutNotifyItem> getItem() {
		return item;
	}

	public void addItem(PayoutNotifyItem item) {
		this.item.add(item);
	}

	@Override
	protected void addRule(Digester digester) {
		digester.addSetProperties("payout-result", "type", "type");
		
		digester.addObjectCreate("payout-result/item", PayoutNotifyItem.class);// 创建节点的实例
		digester.addSetProperties("payout-result/item", "tradeOutNo", "tradeOutNo");
		digester.addSetProperties("payout-result/item", "payoutNo", "payoutNo");
		digester.addCallMethod("payout-result/item/beginTime", "setBeginTime", 0);
		digester.addCallMethod("payout-result/item/endTime", "setEndTime", 0);
		digester.addCallMethod("payout-result/item/amt", "setAmt", 0, new Class<?>[]{Long.class});
		digester.addCallMethod("payout-result/item/shouldAmt", "setShouldAmt", 0, new Class<?>[]{Long.class});
		digester.addCallMethod("payout-result/item/deductionAmt", "setDeductionAmt", 0, new Class<?>[]{Long.class});
		digester.addCallMethod("payout-result/item/fee", "setFee", 0, new Class<?>[]{Long.class});
		digester.addCallMethod("payout-result/item/reqBankSn", "setReqBankSn", 0);
		digester.addCallMethod("payout-result/item/status", "setStatus", 0);
		digester.addCallMethod("payout-result/item/returnMsg", "setReturnMsg", 0);
		digester.addCallMethod("payout-result/item/rtnBankCode", "setRtnBankCode", 0);
		digester.addSetNext("payout-result/item", "addItem");// 调用addItem方法,读取所有item节点
	}
	
}
