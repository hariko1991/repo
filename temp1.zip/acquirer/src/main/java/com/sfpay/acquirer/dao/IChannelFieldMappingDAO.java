package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.domain.ChannelFieldMappingDTO;

/**
 * 类说明：<br>
 * 渠道字段属性转换表
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 * CreateDate: 2015年12月9日
 */
public interface IChannelFieldMappingDAO {
	List<ChannelFieldMappingDTO> queryByChannel(String channel);
	void bindMapping( BatchRuleInfo batchRule);
}
