/**
 * 
 */
package com.sfpay.acquirer.service;

import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：
 * 配置中心提供的接口  
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-6-6
 */
public interface IOMSService {

	/**
	 * 方法说明：根据区域码获得区域名称
	 * <p>
	 * 不存在则返回空字符串
	 * @param disctrictCode
	 * @return
	 */
	public String getDistrictName(String disctrictCode)throws ServiceException;
}
