package com.sfpay.acquirer.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.beanutils.PropertyUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.dao.IChannelFieldMappingDAO;
import com.sfpay.acquirer.domain.ChannelFieldMappingDTO;
import com.sfpay.acquirer.service.IChannelFieldMappingService;

@Service
public class ChannelFieldMappingServiceImpl implements IChannelFieldMappingService {
	private static Logger logger = LoggerFactory.getLogger(ChannelFieldMappingServiceImpl.class);
	private final static String DEFAULT_MAPPING_KEY = "DEFAULT_MAPPING_KEY";
	private final static String CH_Y = "Y";

	@Resource
	IChannelFieldMappingDAO channelFieldMappingDAO;

	@Override
	public Map<String, Map<String, String>> queryMappingByChannel(String channel) {
		Map<String, Map<String, String>> res = new HashMap<String, Map<String, String>>();
		List<ChannelFieldMappingDTO> mappingList = channelFieldMappingDAO.queryByChannel(channel);
		if (mappingList != null && mappingList.size() != 0) {
			Map<String, String> prop;
			for (ChannelFieldMappingDTO dto : mappingList) {
				String feild = dto.getMappingField();
				if (res.containsKey(feild)) {
					prop = res.get(feild);
					prop.put(dto.getOrigValue(), dto.getDestValue());
					if (CH_Y.equals(dto.getDefaultFlag())) {
						prop.put(DEFAULT_MAPPING_KEY, dto.getDestValue());
					}
				} else {
					prop = new HashMap<String, String>();
					prop.put(dto.getOrigValue(), dto.getDestValue());
					if (CH_Y.equals(dto.getDefaultFlag())) {
						prop.put(DEFAULT_MAPPING_KEY, dto.getDestValue());
					}
					res.put(feild, prop);
				}
			}
		}
		return res;
	}

	@Override
	public void execFieldMapping(Object bean, Map<String, Map<String, String>> mapping) {
		try {
			if (bean == null || mapping == null) {
				return;
			}
			for (Map.Entry<String, Map<String, String>> entry : mapping.entrySet()) {
				String name = entry.getKey();
				if (!PropertyUtils.isReadable(bean, name) || !PropertyUtils.isWriteable(bean, name)) {
					continue;// 不可读写的字段跳过
				}
				Object origObj = PropertyUtils.getProperty(bean, name);
				if (origObj == null) {// 空值不转换
					logger.error("转换字段[{}]的值不能为空");
					continue;
				}
				String orig = origObj.toString();
				Map<String, String> prop = entry.getValue();
				if (prop == null) {
					continue;// 无转换关系，跳过
				}
				String destStr = null;
				if (prop.containsKey(orig)) {
					destStr = prop.get(orig);
				} else if (prop.containsKey(DEFAULT_MAPPING_KEY)) {
					destStr = prop.get(DEFAULT_MAPPING_KEY);
				}
				if(destStr == null){
					continue;//未找到映射值，不转换
				}
				if (origObj instanceof String) {
					PropertyUtils.setProperty(bean, name, destStr);
				}else if(origObj instanceof Enum){
					PropertyUtils.setProperty(bean, name, Enum.valueOf(((Enum)origObj).getClass(), destStr) );
				}
			}
		} catch (Exception e) {
			logger.error(e.getMessage());
		}
	}

	@Override
	public void batchExecFieldMapping(List<?> list, String channel) {
		if (list == null || channel == null) {
			return;
		}
		Map<String, Map<String, String>> mapping = queryMappingByChannel(channel);
		for (Object obj : list) {
			execFieldMapping(obj, mapping);
		}
	}
}
