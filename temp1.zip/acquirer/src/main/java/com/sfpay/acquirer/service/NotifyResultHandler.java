package com.sfpay.acquirer.service;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.Encoding;
import com.sfpay.acquirer.common.HttpHelper;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.RepeatInvokeHelper;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IMerInfoDao;
import com.sfpay.acquirer.dao.IParamInfoDao;
import com.sfpay.acquirer.dao.IPayBusinessDao;
import com.sfpay.acquirer.domain.ParamInfo;
import com.sfpay.acquirer.domain.PayoutExchange;
import com.sfpay.acquirer.domain.PayoutInfo;
import com.sfpay.acquirer.domain.paycenter.MerInfo;
import com.sfpay.acquirer.domain.paycenter.MerInfoParam;
import com.sfpay.acquirer.domain.paycenter.PayoutReqInfo;
import com.sfpay.acquirer.enums.CurrencyType;
import com.sfpay.acquirer.enums.ExchangeType;
import com.sfpay.acquirer.enums.PayCenterPayStatus;
import com.sfpay.acquirer.enums.PaymentStatusExt;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.enums.SystemSource;
import com.sfpay.acquirer.enums.YNFlag;
import com.sfpay.coreplatform.order.service.IBankPayService;
import com.sfpay.coreplatform.order.valueobject.dto.CancelBankEnterpriseRequest;
import com.sfpay.coreplatform.order.valueobject.dto.PayConfirmRequest;
import com.sfpay.coreplatform.order.valueobject.dto.PayResponse;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;

/**
 * 为了和批量的分开,这个类处理单笔的情况
 * @author sfhq272
 * 针对单笔的,没有批次信息
 */
@Service
public class NotifyResultHandler {
	private static Logger logger = LoggerFactory.getLogger(NotifyResultHandler.class);
	/**
	 * 平台会员号
	 */
	private Long memberNo = Long.valueOf(Property.getProperty("PLATFORM_MEMBER_NO"));
	/**
	 * 通知各系统的退票URL前缀
	 */
	private static final String PREFIX_URL_BOUNCE = "URL_BOUNCE_";
	/**
	 * 通知各系统的交易结果URL前缀
	 */
	private static final String PREFIX_URL_PAYOUT = "URL_PAYOUT_";	
	
	private long notifyInterval = StringUtils.isEmpty(Property.getProperty("PAYOUT_NOTIFY_INTERVAL")) ? 20000 : Long.parseLong(Property.getProperty("PAYOUT_NOTIFY_INTERVAL"));;
	
	@Resource
	private IBankPayService orderService;
	
	@Resource
	private IPayoutExchangeService exchangeService;
	
	@Resource
	private IParamInfoDao paramDao;
	
	@Resource
	private IPayBusinessDao payBusinessDao;
	
	@Resource
	private IMerInfoDao merInfoDao;
	
	private static ExecutorService executor = Executors.newCachedThreadPool();//modify sfhq270 2014-10-10 将execute

	/**
	 * 方法说明：<br>
	 * 发送结果业务系统系统（不包括订单系统）
	 *
	 * @param batchNotify  发送业务系统的数据
	 * @throws ServiceException
	 */
	public void sendResp(List<PayoutInfo> batchNotify) throws ServiceException{
		this.sendOrderResp(batchNotify, null);
	}
	/**
	 * 方法说明：<br>
	 * 发送结果给订单系统或其他业务系统
	 *
	 * @param batchNotifyList  发送业务系统的数据
	 * @param exchangeType  交互类型（为空时，不发送订单系统）
	 * @param flag          为flase时Failure不需要人工操作,true时需要人工操作
	 * @throws ServiceException
	 */
	public void sendOrderResp(List<PayoutInfo> batchNotifyList,ExchangeType exchangeType) throws ServiceException{
		if(batchNotifyList == null || batchNotifyList.size() == 0) {
			return;
		}
		List<PayConfirmRequest> orderNotify = new ArrayList<PayConfirmRequest>();//订单系统
		StringBuffer meta = new StringBuffer();
		Map<SystemSource, StringBuffer> xmlMap = new HashMap<SystemSource, StringBuffer>();//异步发送使用	
		logger.debug("需要发送其他系统的付款信息：{}", batchNotifyList.toString());
		for (PayoutInfo payoutInfo : batchNotifyList) {
				//非人工操作的交易失败，不发送业务系统
				if(PayoutStatus.FAILURE.equals(payoutInfo.getStatus()) && YNFlag.N.equals(payoutInfo.getOfflineFlag())){
					logger.info("付款信息[付款编号:{}],非人工操作失败的交易失败，不发送业务系统",payoutInfo.getPayoutNo());
					continue;
				}
			//订单系统
			if(null != exchangeType && PayoutStatus.FIR_CHECK_REFUSE != payoutInfo.getStatus() && PayoutStatus.SEC_CHECK_REFUSE != payoutInfo.getStatus()){
				try {
					PayoutExchange payoutExchange = exchangeService.createExchange(payoutInfo, exchangeType);//生成交互信息
					PayConfirmRequest notify = this.converToOutPay(payoutExchange, payoutInfo, meta);//组装订单参数
					if(notify != null){
						orderNotify.add(notify);
					}
				} catch(Exception ex) {
					logger.error("生成交互信息（银行确认）异常",ex);
				}
			} else {
				logger.info("付款信息[付款编号:{}],复核拒绝[{}]或无交互类型,不需要发送订单系统.", payoutInfo.getPayoutNo(), payoutInfo.getStatus());
			}			
			buildPayoutRespXml(xmlMap, payoutInfo);
			
		}
		
		//发送
		sendOrder(orderNotify, meta);
		//异常发送业务系统
		sendXml(xmlMap, PREFIX_URL_PAYOUT);		
	}
	
	/**
	 *付款请求重复，将重复的付款流水更改为失败，并通知业务系统Start
	 *2015-01-15
	 *sfhq 270
	 */
	public void sendBusinessSysResp(List<PayoutInfo> payouts){
		if(payouts == null || payouts.size() == 0) {
			logger.info("没有重复的付款请求PayoutInfos:{}",payouts);
			return;
		}
		Map<SystemSource, StringBuffer> xmlMap = new HashMap<SystemSource, StringBuffer>();//异步发送使用
		for (PayoutInfo info : payouts) {
			buildPayoutRespXml(xmlMap, info);
		}
		//异常发送业务系统
		sendXml(xmlMap, PREFIX_URL_PAYOUT);	
	}
	/**
	 *付款请求重复，将重复的付款流水更改为失败，并通知业务系统end
	 *2015-01-15
	 *sfhq 270
	 */
	
	/**
	 * 方法说明：<br>
	 * 发送退票结果给订单系统或其他外系统
	 *
	 * @param batchNotify  发送外系统的数据
	 * @throws ServiceException
	 */
	public void sendBounceResp(List<PayoutInfo> batchNotify, Map<String, List<PayoutExchange>> oldEcMap) throws ServiceException {
		if(batchNotify == null || batchNotify.size() == 0) {
			return;
		}
		List<CancelBankEnterpriseRequest> orderNotify = new ArrayList<CancelBankEnterpriseRequest>();//订单系统
		StringBuffer meta = new StringBuffer();
		Map<SystemSource, StringBuffer> xmlMap = new HashMap<SystemSource, StringBuffer>();
		
		for (PayoutInfo payoutInfo : batchNotify) {
			//非人工操作的交易失败, 不发送业务系统
			if (!PayoutStatus.FAILURE.equals(payoutInfo.getStatus()) || YNFlag.N.equals(payoutInfo.getOfflineFlag())) {
				logger.info("退票信息[付款编号:{}],非人工操作失败的交易失败，不发送业务系统");
				continue;
			}
			//订单系统
			try {
				//生成交互信息
				List<PayoutExchange> ecLs = exchangeService.createBounceExchange(payoutInfo, oldEcMap.get(payoutInfo.getPayoutNo()), ExchangeType.BOUNCE);
				if(null != ecLs && ecLs.size() > 0) {//组装订单实体
					for(PayoutExchange pe : ecLs) {
						CancelBankEnterpriseRequest er = new CancelBankEnterpriseRequest();
						er.setPlatformMemberNo(memberNo);
						er.setOutTradeNo(pe.getExchangeNo());
						er.setOldOutTradeNo(pe.getRevExchangeNo());
						
						meta.append("[oldOutTradeNo=").append(er.getOldOutTradeNo())
							.append(",outTradeNo=").append(er.getOutTradeNo())
							.append(",platformMemberNo=").append(er.getPlatformMemberNo())
							.append("],\n");
						
						orderNotify.add(er);
					}
				}
			} catch(Exception ex) {
				logger.error("生成交互信息(银行确认)异常", ex);
			}
			buildBounceXml(xmlMap, payoutInfo);
		}
		
		//发送业务系统
		sendBounceOrder(orderNotify, meta);//订单退票接口
		//异步发送
		sendXml(xmlMap, PREFIX_URL_BOUNCE);
	}
	
	/**
	 * 方法说明：<br>
	 * 只发送，不更新.审批拒绝使用
	 *
	 * @param batchCode
	 * @throws ServiceException
	 */
	public void doPayCenterResp(List<PayoutReqInfo> payoutInfoList,PayoutStatus status,String desc) throws ServiceException{
			
		Map<SystemSource, StringBuffer> xmlMap = new HashMap<SystemSource, StringBuffer>();
		for (PayoutReqInfo info : payoutInfoList) {
			logger.info("回调交易流水号【{}】的结果状态：【{}】！", info.getTradeNo(), info.getStatus().name());
			PayoutInfo payoutInfo = new PayoutInfo();
			payoutInfo.setStatus(status);
			payoutInfo.setTradeOutBussinessNo(info.getPayBusinessNo());
			payoutInfo.setSystemSource(info.getSystemSource());
			payoutInfo.setRtnBankMsg(desc);
			payoutInfo.setEndTime(new Date());//增加更新日期，修复以前Bug。sfhq270  2014-11-11
			payoutInfo.setTradeOutNo(info.getTradeNo());
			buildPayoutRespXml(xmlMap, payoutInfo);
		}
		sendXml(xmlMap, PREFIX_URL_PAYOUT);
	}
	
	
	/**
	 * 方法说明：<br>
	 * 只发送，不更新.复核拒绝使用
	 * 收款方账号被风控冻结使用
	 * @param batchCode
	 * @param flag 区分是否需要人工操作
	 * @throws ServiceException
	 */
	public void doSendOrderResp(List<PayoutInfo> batchNotify, PayoutStatus payoutStatus) throws ServiceException{
		logger.info("开始发送付款结果[{}]到外部系统.", batchNotify, payoutStatus);
		
		if(batchNotify == null || batchNotify.size() == 0){
			logger.info("无明细交易,请确认!");
			return;
		}
		
		//发送外系统等
		try {
			this.sendOrderResp(batchNotify, ExchangeType.SEND_AFTER);
		} catch (Exception ex) {
			logger.error("调用外部系统异常 :" + ex.getMessage());
		}
		logger.info("发送付款结果[{}]到外部系统结束.",batchNotify);
	}
	

	/**
	 * 方法说明：<br>
	 * 转换订单系统对象
	 *
	 * @param info
	 * 
	 */
	private PayConfirmRequest converToOutPay(PayoutExchange info, PayoutInfo payout, StringBuffer meta) throws ServiceException {
		if (info == null) {
			logger.info("不存在需要转换订单系统对象的信息");
			return null;
		}
		PayConfirmRequest reqInfo = new PayConfirmRequest();
//		reqInfo.setBankCode(payout.getBankCode().name());
		reqInfo.setBusinessType(com.sfpay.coreplatform.order.common.enums.BusinessType.WIH_OUTPAY);
		reqInfo.setBankCode(payout.getPayerOrgCode().name());//修改bankCode为付款方银行。2015-02-04 周丽佩 
		reqInfo.setCcy(com.sfpay.coreplatform.order.common.enums.CcyType.valueOf(info.getCcy()==CurrencyType.CNY?"RMB":info.getCcy().name()));
		reqInfo.setOrderType(com.sfpay.coreplatform.order.common.enums.OrderType.TRANSFER);
		reqInfo.setPlatformMemberNo(memberNo);
		reqInfo.setPayAmt(info.getAmt());
		reqInfo.setTradeOutNo(info.getExchangeNo());

		if (PayoutStatus.SUCCESS.equals(payout.getStatus())) {
			reqInfo.setTradeStatus(true);
		} else if (PayoutStatus.FAILURE.equals(payout.getStatus())) {
			reqInfo.setTradeStatus(false);
		} else {
			return null;// 未知状态不发送
		}
		meta.append("[bankCode=").append(reqInfo.getBankCode())
			.append(",tradeStatus=").append(reqInfo.isTradeStatus())
			.append(",tradeOutNo = ").append(reqInfo.getTradeOutNo())
			.append(",businessType = ").append(reqInfo.getBusinessType())
			.append(",ccy = ").append(reqInfo.getCcy())
			.append(",orderType = ").append(reqInfo.getOrderType())
			.append(",payAmt = ").append(reqInfo.getPayAmt())
			.append(",platformMermberNo = ")
			.append(reqInfo.getPlatformMemberNo()).append("],\n");
		return reqInfo;
	}
	
	/**
	 * 方法说明：<br>
	 * 检查付款信息返回结果
	 *
	 * @param payoutInfo
	 * @throws ServiceException
	 */
	private void checkRes(PayoutInfo payoutInfo) throws ServiceException {
		if(payoutInfo == null) {
			throw new ServiceException(InfoCode.PARAM_INVALID,"转换银行返回值结果不能为空 ");
		}
		
		if(payoutInfo.getStatus() == null) {
			throw new ServiceException(InfoCode.PARAM_INVALID,"转换银行返回值结果的交易结果不能为空 ");
		}
		
		if(StringUtils.isEmpty(payoutInfo.getReqBankSn())) {
			throw new ServiceException(InfoCode.PARAM_INVALID,"转换银行返回值结果的银行请求流水号不能为空 ");
		}
//		轮询失败后修改，没有银行返回码
//		if(StringUtils.isEmpty(payoutInfo.getRtnBankCode())) {
//			throw new ServiceException(InfoCode.PARAM_INVALID,"转换银行返回值结果的银行返回码不能为空 ");
//		}

	}
	
	/**
	 * 方法说明：<br>
	 * 生成退票通知外部系统报文
	 */
	private void buildBounceXml(Map<SystemSource, StringBuffer> xmlMap, PayoutInfo payoutInfo) {
		if(StringUtils.isEmpty(payoutInfo.getTradeOutNo())) {
			return;
		}
		PayCenterPayStatus centerStatus =null;
		String desc="";
		boolean isNotify = true;
		switch (payoutInfo.getStatus()) {
			case FAILURE:
				desc="银行退票";
				centerStatus=PayCenterPayStatus.FAILURE;
				break;
			default:
				isNotify = false;
				break;
		}
		if(!isNotify) {
			return;
		}
		
		StringBuffer xmlBuffer = xmlMap.get(payoutInfo.getSystemSource());
		if (null == xmlBuffer) {
			xmlBuffer = new StringBuffer(
					"<?xml version=\"1.0\" encoding=\"UTF-8\" ?><payout-result type=\"bounce\" sign=\"#signVal#\">");
		}

		// 在此处需要加入是否是付款中心数据记录的判断，若是付款中心则需要调用付款中心通知处理逻辑
		String tradeOutBusinessNo = payoutInfo.getTradeOutBussinessNo();// 获取外部交易业务编号用以回查付款中心记录表
		if (!StringUtils.isEmpty(tradeOutBusinessNo)) {
			PayoutReqInfo reqData = payBusinessDao
					.queryPayInfoByBusinessNo(tradeOutBusinessNo);
			// 若在付款业务表中能查到相应的付款记录表示该笔付款是付款中心数据则需要通过另外方式实现
			if (null != reqData) {
				// 更新付款中心付款业务表状态					
				payBusinessDao.updateStatus(reqData.getId(),centerStatus, desc,payoutInfo.getEndTime());
				reqData = payBusinessDao
						.queryPayoutReqInfoById(reqData.getId());
				MerInfoParam param = new MerInfoParam();
				String merchantNo = reqData.getMerNo();
				param.setMerNo(merchantNo);
				MerInfo merInfo = merInfoDao.queryMerInfo(param);
				xmlBuffer.append("<item tradeNo=\"")
						.append(reqData.getTradeNo())// 外部交易订单编号
						.append("\">")// 付款编号
						.append("<tradeExt1>").append(reqData.getTradeExt1())
						.append("</tradeExt1>").append("<tradeExt2>")
						.append(reqData.getTradeExt2()).append("</tradeExt2>")
						.append("<payBusinessNo>").append(reqData.getPayBusinessNo())
						.append("</payBusinessNo>").append("<payReqTime>")
						.append(reqData.getPayReqTime())
						.append("</payReqTime>").append("<payEndTime>")
						.append(reqData.getPayEndTime())
						.append("</payEndTime>").append("<status>")
						.append(reqData.getStatus().name()).append("</status>")
						.append("<bankRetCode>")
						.append(toBlank(reqData.getBankRetCode()))
						.append("</bankRetCode>").append("<bankRetMsg>")
						.append(toBlank(reqData.getBankRetMsg()))
						.append("</bankRetMsg>").append("<merNo>")
						.append(reqData.getMerNo()).append("</merNo>")
						.append("<url>").append(merInfo.getNotifyUrl()).append("</url>")
						.append("<merKey>").append(merInfo.getMerKey()).append("</merKey>")
						.append("</item>");
				xmlMap.put(payoutInfo.getSystemSource(), xmlBuffer);
				return;
			}

		}

		xmlBuffer
		.append("<item tradeOutNo=\"").append(payoutInfo.getTradeOutNo())//外部交易订单编号
			.append("\" payoutNo=\"").append(payoutInfo.getPayoutNo()).append("\">")//付款编号
			.append("<beginTime>").append(DateUtil.getDateString(payoutInfo.getBeginTime(), DateUtil.DATA_FORMAT_PATTERN)).append("</beginTime>")
			.append("<endTime>").append(DateUtil.getDateString(payoutInfo.getEndTime(), DateUtil.DATA_FORMAT_PATTERN)).append("</endTime>")
			.append("<amt>").append(payoutInfo.getAmt()).append("</amt>")
			.append("<shouldAmt>").append(toBlank(payoutInfo.getShouldAmt())).append("</shouldAmt>")
			.append("<deductionAmt>").append(toBlank(payoutInfo.getDeductionAmt())).append("</deductionAmt>")
			.append("<fee>").append(toBlank(payoutInfo.getFee())).append("</fee>")
			.append("<reqBankSn>").append(toBlank(payoutInfo.getReqBankSn())).append("</reqBankSn>")
			.append("<rtnBankCode>").append(toBlank(payoutInfo.getRtnBankCode())).append("</rtnBankCode>")
			.append("<status>").append(PaymentStatusExt.FAILURE).append("</status>")
			.append("<returnMsg>").append(toBlank(payoutInfo.getRtnBankMsg())).append("</returnMsg>")
		.append("</item>");
		xmlMap.put(payoutInfo.getSystemSource(), xmlBuffer);
	}
	
	/**
	 * 方法说明：<br>
	 * 生成交易结果通知外部系统报文
	 */
	private void buildPayoutRespXml(Map<SystemSource, StringBuffer> xmlMap, PayoutInfo info) {
		if(StringUtils.isEmpty(info.getTradeOutNo())) {
			return;
		}
		boolean isNotify = true;
		PayCenterPayStatus centerStatus =null;     //付款中心的状态
		PaymentStatusExt status = null;            //发送,通知业务系统的状态
		String desc = null;
		//状态为复核拒绝、失败、成功时，转换返回状态及返回信息；其他状态不生成报文。
		switch (info.getStatus()) {
			case FIR_CHECK_REFUSE://("第一次复核拒绝"),
				centerStatus=PayCenterPayStatus.FAILURE;
				status = PaymentStatusExt.FAILURE;
				desc = "风控冻结账户拒绝交易";
				break;
			case SEC_CHECK_REFUSE://("第二次复核拒绝"),
				status = PaymentStatusExt.FAILURE;
				centerStatus=PayCenterPayStatus.FAILURE;
				desc = "风控冻结账户拒绝交易";
				break;
			case FAILURE://("交易失败"),
				centerStatus=PayCenterPayStatus.FAILURE;
				status = PaymentStatusExt.FAILURE;
				desc = info.getRtnBankMsg();
				break;
			case SUCCESS://("交易成功"),
				centerStatus=PayCenterPayStatus.SUCCESS;
				status = PaymentStatusExt.SUCCESS;
				desc = info.getRtnBankMsg();
				break;
			default:
				isNotify=false;
				break;
		}
		if(!isNotify) {
			return;
		}
		StringBuffer bXml = xmlMap.get(info.getSystemSource());
		if(null == bXml) {
			bXml = new StringBuffer("<?xml version=\"1.0\" encoding=\"UTF-8\" ?><payout-result type=\"payout\"  sign=\"#signVal#\">");
		}
		
		//在此处需要加入是否是付款中心数据记录的判断，若是付款中心则需要调用付款中心通知处理逻辑
		String tradeOutBusinessNo=info.getTradeOutBussinessNo();//获取外部交易业务编号用以回查付款中心记录表
		if(!StringUtils.isEmpty(tradeOutBusinessNo)){
			PayoutReqInfo payoutReqData=payBusinessDao.queryPayInfoByBusinessNo(tradeOutBusinessNo);
			//若在付款业务表中能查到相应的付款记录表示该笔付款是付款中心数据则需要通过另外方式实现
			if(null!=payoutReqData){				
				//更新付款中心付款业务表状态
				if(null==desc){
					desc=info.getRemark();
					if(null==desc){
						desc="";
					}
				}
				
				payBusinessDao.updateStatus(payoutReqData.getId(),centerStatus, desc, info.getEndTime());
				//如果是手动的就不会去组装报文    移到更新付款中心状态之后，判断是否组装报文  2014-10-21  start
				if (("SDLR").equals(payoutReqData.getCmdType()) || ("").equals(payoutReqData.getCmdType())) {
					logger.info("如果是手动的就不会去组装报文,temInfo=:{}", payoutReqData);
					return;
				}
				//如果是手动的就不会去组装报文    移到更新付款中心状态之后，判断是否组装报文  2014-10-21  end
				payoutReqData=payBusinessDao.queryPayoutReqInfoById(payoutReqData.getId());
				MerInfoParam param=new MerInfoParam();
				String merNo=payoutReqData.getMerNo();
				param.setMerNo(merNo);
				MerInfo merInfo=merInfoDao.queryMerInfo(param);
				bXml
				.append("<item tradeNo=\"").append(payoutReqData.getTradeNo())//外部交易订单编号
					.append("\">")//付款编号
					.append("<tradeExt1>").append(payoutReqData.getTradeExt1()).append("</tradeExt1>")
					.append("<tradeExt2>").append(payoutReqData.getTradeExt2()).append("</tradeExt2>")
					.append("<payBusinessNo>").append(payoutReqData.getPayBusinessNo()).append("</payBusinessNo>")
					.append("<payReqTime>").append(payoutReqData.getPayReqTime()).append("</payReqTime>")
					.append("<payEndTime>").append(payoutReqData.getPayEndTime()).append("</payEndTime>")
					.append("<status>").append(payoutReqData.getStatus().name()).append("</status>")
					.append("<bankRetCode>").append(toBlank(payoutReqData.getBankRetCode())).append("</bankRetCode>")
					.append("<bankRetMsg>").append(toBlank(payoutReqData.getBankRetMsg())).append("</bankRetMsg>")
					.append("<merNo>").append(payoutReqData.getMerNo()).append("</merNo>")
					.append("<url>").append(merInfo.getNotifyUrl()).append("</url>")
					.append("<merKey>").append(merInfo.getMerKey()).append("</merKey>")
				.append("</item>");
				xmlMap.put(info.getSystemSource(),bXml);
				return;	
			}
			
		}	
		
		bXml
		.append("<item tradeOutNo=\"").append(info.getTradeOutNo())//外部交易订单编号
			.append("\" payoutNo=\"").append(info.getPayoutNo()).append("\">")//付款编号
			.append("<beginTime>").append(DateUtil.getDateString(info.getBeginTime(), DateUtil.DATA_FORMAT_PATTERN)).append("</beginTime>")
			.append("<endTime>").append(DateUtil.getDateString(info.getEndTime(), DateUtil.DATA_FORMAT_PATTERN)).append("</endTime>")
			.append("<amt>").append(info.getAmt()).append("</amt>")
			.append("<shouldAmt>").append(toBlank(info.getShouldAmt())).append("</shouldAmt>")
			.append("<deductionAmt>").append(toBlank(info.getDeductionAmt())).append("</deductionAmt>")
			.append("<dctAcqTime>").append(DateUtil.getDateString(info.getDeducationDate(), DateUtil.DATA_FORMAT_PATTERN)).append("</dctAcqTime>")   //  modfiy   抵扣时加入抵扣日期
			.append("<fee>").append(toBlank(info.getFee())).append("</fee>")
			.append("<reqBankSn>").append(toBlank(info.getReqBankSn())).append("</reqBankSn>")
			.append("<rtnBankCode>").append(toBlank(info.getRtnBankCode())).append("</rtnBankCode>")
			.append("<status>").append(null == status ? "" : status.name()).append("</status>")
			.append("<returnMsg>").append(toBlank(desc)).append("</returnMsg>")
		.append("</item>");
		xmlMap.put(info.getSystemSource(), bXml);
//		logger.info("通知业务系统的报文:{}"+bXml.toString());
	}
	
	private String toBlank(Object object) {
		return (null == object) ? "" : object+"";
	}
	
	/**
	 * 方法说明：<br>
	 * 把结果发送订单
	 *
	 * @param notifyList
	 * @param sb
	 */
	private void sendOrder(List<PayConfirmRequest> notifyList,StringBuffer sb) throws ServiceException{
		if(notifyList.size() == 0){
			return;
		}
		logger.info("开始调用订单系统(银行交易结果),参数 = "+sb.toString());
		List<PayResponse> payList = null;
		try{
			payList = this.orderService.bankConfirmPayAcc(notifyList);
		}catch(Exception ex){
			logger.error("调用订单系统(发送付款结果)异常:",ex);
		}
		logger.info("订单系统调用结束(银行交易结果)");
		if(payList == null || payList.size() == 0){
			logger.info("订单系统返回结果: null");
			return;
		}
		logger.info("调用订单系统(银行交易结果),订单系统处理条数size:[{}]",payList.size());
		//更新交互信息
		updatePayResponse(payList,ExchangeType.SEND_AFTER);
	}
	
	/**
	 * 方法说明：<br>
	 * 把退票结果发送订单
	 *
	 * @param orderNotify
	 * @param sb
	 */
	private void sendBounceOrder(List<CancelBankEnterpriseRequest> orderNotify,StringBuffer sb) throws ServiceException{
		if (orderNotify.size() == 0) {
			return;
		}
		logger.info("开始调用订单系统(退票),参数: {}", sb.toString());
		List<PayResponse> orderRespList = null;
		try {
			orderRespList = this.orderService.cancelBankEnterprise(orderNotify);
		} catch (Exception ex) {
			logger.error("调用订单系统(退票)异常:", ex);
		}
		logger.info("订单系统调用结束(退票)");
		if (orderRespList == null || orderRespList.size() == 0) {
			logger.info("订单系统返回结果(退票): null");
			return;
		}
		logger.info("调用订单系统结束(退票),size:[{}]", orderRespList.size());
		// 更新交互信息
		updatePayResponse(orderRespList, ExchangeType.BOUNCE);
	}
	
	/**
	 * 方法说明：<br>
	 * 更新订单返回的交互信息
	 *
	 * @param orderRespList
	 */
	private void updatePayResponse(List<PayResponse> orderRespList,ExchangeType exchangeType){
		//更新交互信息
		StringBuffer buffer = new StringBuffer();
		for (PayResponse payResp : orderRespList) {
			buffer.setLength(0);
			try {
				//打印日志
				buffer.append("[payNo:").append(payResp.getPayNo()).append(",")
					.append("retrunCode:").append(payResp.getReturnCode()).append(",")
					.append("returnMsg:").append(payResp.getReturnMsg()).append(",")
					.append("tradeNo:").append(payResp.getTradeNo()).append(",")
					.append("tradeOutNo:").append(payResp.getTradeOutNo()).append(",")
					.append("payDate:").append(payResp.getPayDate()).append("]");
				logger.info("付款信息[交互流水:{}],更新订单系统返回返回信息:{}", payResp.getTradeOutNo(), buffer.toString());
				exchangeService.updateOrderResp(payResp.getTradeNo(), payResp.getTradeOutNo(), payResp.getReturnCode()+"", payResp.getReturnMsg(), exchangeType);
			} catch (Exception ex) {
				logger.error("付款信息[交互流水:"+payResp.getTradeOutNo()+"],更新订单系统返回信息异常 = ",ex);
			}
		}
	}
	
	/**
	 * 方法说明：<br>
	 * 异步通知业务系统
	 *@author sfhq270 周丽佩  modify 2014-10-10（将task任务由callable 改为 runnable形式）
	 * @param xmlMap
	 * @param prefixStr
	 */
	private void sendXml(Map<SystemSource, StringBuffer> xmlMap, String prefixStr) {
		if(xmlMap.size() == 0) {
			return;
		}
		List<String> pKeyList = new ArrayList<String>();
		for(Iterator<SystemSource> it = xmlMap.keySet().iterator(); it.hasNext(); ) {
			pKeyList.add(prefixStr + it.next());
		}
		List<ParamInfo> urls = paramDao.findByKeys(pKeyList);
		if(null == urls || urls.size() == 0) {
			return;
		}
		ParamInfo paramInfo = null;
//		List<notify> tasks = new ArrayList<notify>();
		logger.info("异步通知各业务系统...");
		for(Iterator<ParamInfo> it = urls.iterator(); it.hasNext(); ) {
			paramInfo = it.next();
			if(StringUtils.isEmpty(paramInfo.getParamValue())) {
				continue;
			}
//			tasks.add(new notify(param, xmlMap,prefix));
			executor.execute(new NotifyExecutor(paramInfo, xmlMap,prefixStr));
		}
//		if(tasks.size() == 0) {
//			return;
//		}
//		logger.info("异步通知各业务系统...");
//		try {
//			executor.invokeAll(tasks);
//		} catch (InterruptedException e) {
//			logger.error("通知其它系统异常", e);
//		}
	}
	
	
	/**
	 * 类说明：<br>
	 * 退票通知线程
	 * <p>
	 * 详细描述：<br>
	 * </p>
	 * @author sfhq270 周丽佩
	 * CreateDate: 2014-10-10
	 */
	private class NotifyExecutor implements Runnable {
		private String urlStr;
		private String xmlStr;
		private SystemSource source;
		public NotifyExecutor(ParamInfo param, Map<SystemSource, StringBuffer> xmlMap,String keyPrefix) {
			this.urlStr = param.getParamValue();
			this.source = SystemSource.valueOf(param.getParamKey().substring(keyPrefix.length()));
			this.xmlStr = new StringBuffer("result=").append(xmlMap.get(source)).append("</payout-result>").toString();
		}
		@Override
		public void run() {
			try {
				HttpHelper.sendByPost(urlStr, xmlStr, Encoding.UTF_8);
				logger.info(String.format("通知[%s]完成(URL: %s, 报文: %s)", source, urlStr, xmlStr));
			} catch (Exception e) {
				logger.error(String.format("通知[%s]异常(URL: %s, 报文: %s)", source, urlStr, xmlStr), e);
				RepeatInvokeHelper.getInstance().addQueue(new PayoutRespRepeatInvoke(urlStr, xmlStr, source));
			}
		}
	}
	
	
	/**
	 * 类说明：<br>
	 * 付款通知失败时的重复调用尝试实现
	 * 
	 * <p>
	 * 详细描述：<br>
	 * 
	 * </p>
	 * 
	 * @author 329202 符瑜鑫(Ricky Fu)
	 * 
	 * CreateDate: 2013-12-21
	 */
	private  class PayoutRespRepeatInvoke implements IRepeatInvoke {
		private String urlStr;
		private String xmlStr;
		private SystemSource system;
		public PayoutRespRepeatInvoke(String url, String xml, SystemSource src) {
			this.urlStr = url;
			this.xmlStr = xml;
			this.system = src;
		}
		@Override
		public void execute() {
	        for (int idx = 0; idx < 3; idx++) {//遍历次数
	        	try {
	        		Thread.sleep(notifyInterval);// 超时调用遍历间隔时间
	        	} catch (InterruptedException ex) {
	        		logger.error("线程交互异常", ex);
	        		continue;
	        	}
	        	try {
	        		HttpHelper.sendByPost(urlStr, xmlStr, Encoding.UTF_8);
					logger.info(String.format("[第%s次]通知[%s]完成(URL: %s, 报文: %s)", idx+1, system, urlStr, xmlStr));
					break;
				} catch (Exception e) {
					logger.info(String.format("[第%s次]通知[%s]完成(URL: %s, 报文: %s)", idx+1, system, urlStr, xmlStr), e);
				}
	        }
		}
	}
}
