package com.sfpay.acquirer.service.impl;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.dao.IReconBankFileCreateDao;
import com.sfpay.acquirer.domain.BankProperty;
import com.sfpay.acquirer.domain.ReconBankFileCreate;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.service.IReconCheckService;
import com.sfpay.framework.base.exception.ServiceException;


/**
 * 
 * 
 * 类说明：<br>
 * 银行对账文件记录实现类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-4-22
 */
@Deprecated
@Service("reconCheckService")
public class ReconCheckServiceImpl  implements IReconCheckService {
	private static Logger logger = LoggerFactory.getLogger(ReconCheckServiceImpl.class);
	private static final boolean isDebug = logger.isDebugEnabled();
	
	@Resource
	private IReconBankFileCreateDao reconBankFileCreateDao;

	@Override
	public int saveBankFile(ReconBankFileCreate info)
			throws ServiceException {
		if(info.getChannelCode() == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "ChannelCode can't be null");
		}
		if(info.getBankCode() == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "ChannelCode can't be null");
		}
		if(info.getTradeDate() == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "TradeDate can't be null");
		}
		if(info.getFileGetDate() == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "FileGetDate can't be null");
		}
		if(info.getFileGetFlag() == null || "".equals(info.getFileGetFlag().trim())){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "FileGetFlag can't be null");
		}
		if(isDebug){
			logger.debug("生成银行对账文件信息:{}",info.toString());
		}
		
		//查询
		List<ReconBankFileCreate> list = reconBankFileCreateDao.query(info.getBankCode(), info.getChannelCode(), info.getTradeDate());
		if(list ==  null || list.size() == 0){
			info.setFileGetCnt(1);
			//添加对账文件信息
			return reconBankFileCreateDao.save(info);
		}else{
			info.setFileGetCnt(list.get(0).getFileGetCnt()+1);
			//修改对账文件信息
			return reconBankFileCreateDao.update(info);
		}
	}


	@Override
	public boolean isRecon(BankCode bankCode,
			ChannelCode channelCode, Date tradeDate) throws ServiceException {
		if(bankCode == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "ChannelCode can't be null");
		}
		if(channelCode == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "ChannelCode can't be null");
		}
		if(tradeDate == null){
			throw new ServiceException(InfoCode.INPUT_PARAM_IS_NULL, "TradeDate can't be null");
		}
		if(isDebug){
			logger.debug("查询银行对账文件信息条件:银行[{}],渠道[{}],交易日期[{}]",new Object[]{bankCode,channelCode,tradeDate});
		}
		List<ReconBankFileCreate> list = reconBankFileCreateDao.query(bankCode, channelCode, tradeDate);
		ReconBankFileCreate info = null;
		
		if(list == null || list.size() == 0 ){
			return false;
		}else if((info = list.get(0)) == null || "N".equals(info.getFileGetFlag())){
			return false;
		}else{
			return true;
		}
	}

	@Override
	public void checkReconTime(BankProperty property) throws ServiceException {
		String reconTime = property.get("ReconTime") == null ? "" : property.get("ReconTime").trim();
		if(isDebug){
			logger.debug("执行时间范围:{}",reconTime);
		}
		if("".equals(reconTime)){
			logger.info("未配置对账时间范围.");
			return ;
		}
		
		Date firTime = null;
		Date secTime = null;
		try{
			String[] times = reconTime.split("\\|");
			String date = DateUtil.getDateString(new Date(),"yyyyMMdd")+" ";
			firTime = DateUtil.getDateFormatStr(date+times[0], "yyyyMMdd HH:mm");
			secTime = DateUtil.getDateFormatStr(date+times[1], "yyyyMMdd HH:mm");
		}catch(Exception ex){
			throw new ServiceException(InfoCode.RECON_ERROR,"对账时间范围配置有误.",ex);
		}
		if(firTime == null || secTime == null){
			logger.error("对账时间配置有误.");
			throw new ServiceException(InfoCode.RECON_ERROR,"对账时间配置有误.");
		}
		
		Date newDate = new Date();
		if(firTime.before(secTime)){//firTime早于secTime
			if(isDebug){
				logger.debug("对账时间:{} ~~ {}",new Object[]{firTime,secTime});
			}
			if(newDate.before(firTime)){
				throw new ServiceException(InfoCode.RECON_ERROR,"未到对账时间，不能进行对账.");
			}else if(newDate.after(secTime)){
				throw new ServiceException(InfoCode.RECON_ERROR,"已经超过对账时间，不能进行对账.");
			}
		}else{//firTime晚于secTime
			if(isDebug){
				logger.debug("对账时间:{} ~~ {}",new Object[]{secTime,firTime});
			}
			if(newDate.before(secTime)){
				throw new ServiceException(InfoCode.RECON_ERROR,"未到对账时间，不能进行对账.");
			}else if(newDate.after(firTime)){
				throw new ServiceException(InfoCode.RECON_ERROR,"超过对账时间，不能进行对账.");
			}
		}
	}

}
