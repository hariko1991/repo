package com.sfpay.acquirer.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.ReconLog;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
/**
 * 
 * 类说明：
 * 日志维护dao  
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 349508 韦健
 *   
 * CreateDate: 2012-8-28
 */
public interface IReconLogDao {
	
	/**
	 * 插入到日志表中
	 */
	public void insertReconLog(@Param("logLevel") String logLevel,@Param("logContent") String logContent);
    /**
     * 统计对账结算后的成功笔数，失败笔数，丢单笔数，调单笔数，时间性差异笔数
     * @param date
     * @param bankCode
     * @param channelCode
     * @return
     * @throws Exception
     */
	public String totalReconCollectRlt(@Param("nowDate") String strDate ,@Param("bankCode") BankCode bankCode,@Param("channelCode") ChannelCode channelCode);
	/**
	 * 查询对账结果表在对账前的核查统计总条数
	 * @param tradeDate
	 * @param bankCode
	 * @param channelCode
	 * @return
	 * @throws Exception
	 */
	public Long totalReconCollectRltCount(@Param("tradeDate") String tradeDate,@Param("bankCode") BankCode bankCode,@Param("channelCode") ChannelCode channelCode);
	
	
	/**
	 * 方法说明：
	 * 对账日志查询 统计总数
	 * @param createTime
	 * @return
	 */
	public long queryReconLogCount(@Param("createTime") Date createTime);
	
	
	/**
	 * 方法说明：
	 * 对账日志查询 统计每页数
	 * @param createTime
	 * @param start
	 * @param end
	 * @return
	 */
	public List<ReconLog> queryReconLogList(@Param("createTime") Date createTime, @Param("start") int start, @Param("end") int end);
	

}
