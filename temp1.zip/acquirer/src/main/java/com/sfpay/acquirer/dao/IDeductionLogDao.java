package com.sfpay.acquirer.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.acquirer.domain.DeductionLog;
import com.sfpay.acquirer.domain.DeductionQueryParam;
import com.sfpay.acquirer.domain.DeductionQueryRlt;

/**
 * 
 * 
 * 类说明：<br>
 * 抵抗历史
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-12-11
 */
public interface IDeductionLogDao {

	/**
	 * 方法说明：<br>
	 * 保存
	 *
	 * @param log
	 * @throws Exception
	 */
	public void save(DeductionLog log) throws Exception;
	
	/**
	 * 
	 * 方法说明：<br>
	 * 分页查询已抵扣支付明细记录
	 * @param param
	 * @param start
	 * @param end
	 * @return
	 */
	public List<DeductionQueryRlt> queryDeductionInfos(@Param("param") DeductionQueryParam param
			,@Param("start") int start, @Param("end") int end);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 抵扣明细总条数
	 * @param param
	 * @return
	 */
	public Long countDeductionInfos(@Param("param") DeductionQueryParam param);
}
