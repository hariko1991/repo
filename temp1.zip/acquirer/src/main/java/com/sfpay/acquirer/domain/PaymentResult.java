/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.domain;

import com.sfpay.acquirer.enums.CollectStatus;
import com.sfpay.framework.base.entity.BaseEntity;

/**
 * 
 * 
 * 类说明：网银支付返回结果实体bean
 *  
 * 
 * <p>
 * 详细描述：
 *   
 * 
 * @author 312932
 *   
 * CreateDate: 2012-3-27
 */
public class PaymentResult extends BaseEntity {

	private static final long serialVersionUID = -6669126800587439894L;
	
	/**
	 * 收单记录状态 [需要根据各银行返回状态转换]
	 */
	private CollectStatus collectStatus;
	
	/**
	 * 银行返回流水号
	 */
	private String rtnBankSn;
	
	/**
	 * 银行返回码
	 */
	private String rtnBankCode;
	
	/**
	 * 银行返回结果描述 
	 */
	private String rtnBankMsg;
	
	/**
	 * 支付系统返回码
	 */
	private String rtnPayCode;
	
	/**
	 * 备注
	 */
	private String remark;
	
	/**
	 * 前端是否需要输出特定字符.(如:支付宝)
	 */
	private String output;
	
	/**
	 * 忽略银行通知.比如前端通知
	 */
	private boolean ignore;
	
	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public CollectStatus getCollectStatus() {
		return collectStatus;
	}

	public void setCollectStatus(CollectStatus collectStatus) {
		this.collectStatus = collectStatus;
	}

	public String getRtnBankSn() {
		return rtnBankSn;
	}

	public void setRtnBankSn(String rtnBankSn) {
		this.rtnBankSn = rtnBankSn;
	}

	public String getRtnBankCode() {
		return rtnBankCode;
	}

	public void setRtnBankCode(String rtnBankCode) {
		this.rtnBankCode = rtnBankCode;
	}

	public String getRtnBankMsg() {
		return rtnBankMsg;
	}

	public void setRtnBankMsg(String rtnBankMsg) {
		this.rtnBankMsg = rtnBankMsg;
	}

	public String getRtnPayCode() {
		return rtnPayCode;
	}

	public void setRtnPayCode(String rtnPayCode) {
		this.rtnPayCode = rtnPayCode;
	}

	public String getOutput() {
		return output;
	}

	public void setOutput(String output) {
		this.output = output;
	}

	public boolean isIgnore() {
		return ignore;
	}

	public void setIgnore(boolean ignore) {
		this.ignore = ignore;
	}
	
}
