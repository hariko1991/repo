/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.domain;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.enums.BatchStatus;
import com.sfpay.acquirer.enums.PayoutStatus;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.BusBeanBase;
import com.sfpay.acquirer.gate.b2e.domain.TransferInfo;
import com.sfpay.acquirer.gate.b2e.domain.TransferSubInfo;

/**
 * 类说明：<br>
 * 银企直联付款返回结果实体bean
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 329202 <a href="mailto:fuyuxin@sf-express.com">符瑜鑫(Ricky Fu)</a>
 * @author 361424 詹锡宁 2012-10-26
 * 
 *         CreateDate: 2012-9-14
 */
public class PayoutReqResult extends PayoutResult {
	private static ThreadLocal<Integer> local = new ThreadLocal<Integer>();
	private static final long serialVersionUID = 7364001025287307381L;

	public PayoutReqResult() {
		local.set(0);
	}
	
	private BatchStatus status;

	private Date sendTime;

	private List<PayoutInfo> infos;
	
	public List<PayoutInfo> getInfos() {
		return infos;
	}

	public void setInfos(List<PayoutInfo> infos) {
		this.infos = infos;
	}

	public Date getSendTime() {
		return sendTime;
	}

	public void setSendTime(Date sendTime) {
		this.sendTime = sendTime;
	}

	public BatchStatus getStatus() {
		return status;
	}

	public void setStatus(BatchStatus status) {
		this.status = status;
	}

	/**
	 * 提供信息格式的封装类，不同情况有不同的子类，但尽量重用。 应该从源头进行信息的分类处理，避免过多的if else
	 * 耦合。通过子类的继承变化可降低if else 对于 OCP原则的入侵。
	 * 
	 * @return
	 */

	protected void parseMsg(BeanBase respBean) {

		BusBeanBase busDetail = (BusBeanBase) respBean.getBusDetailBeanBase();
		this.setReqBankSn(busDetail.getSerialId());
		this.setRtnBankCode(busDetail.getBankRetCode());
		if (busDetail.getBankRetMsg() == null || "".equals(busDetail.getBankRetMsg())) {
			this.setRtnBankMsg(busDetail.getRetMsg());
		} else {
			this.setRtnBankMsg(busDetail.getBankRetMsg());
		}
		if (!StringUtils.isEmpty(busDetail.getRtnBankSn()))
			this.setRtnBankSn(busDetail.getRtnBankSn());// add by sfhq814
														// 2015-8-5
		setInfos(respBean);
		
		this.setSendTime(DateUtil.getDateFormatStr(respBean.getBusDetailBeanBase().getSendTime(),
				DateUtil.DATA_FORMAT_PATTERN));

	}
	
	private void setInfos(BeanBase respBean) {

		// 对于未知和失败的不需要执行
		if (BatchStatus.convertToBatchStatus(respBean.getBusDetailBeanBase().getRetCode()).equals(BatchStatus.RECEIVED)) {

			TransferInfo transferInfo = (TransferInfo) respBean.getBusDetailBeanBase();
			List<TransferSubInfo> subInfo = transferInfo.getSubInfoList();
			List<PayoutInfo> infos = new ArrayList<PayoutInfo>();
			if (subInfo != null && subInfo.size() > 0) {

				for (TransferSubInfo su : subInfo) {
					infos.add(setPayoutInfo(su, transferInfo));
				}
				
				if (subInfo.size() == local.get()) {
					this.setStatus(BatchStatus.DONE);// 设置批次状态
				} else {
					this.setStatus(BatchStatus.RECEIVED);// 设置批次状态
				}

				this.setInfos(infos);
			}

		}

	}

	private PayoutInfo setPayoutInfo(TransferSubInfo su, TransferInfo transferInfo) {
		PayoutInfo info = new PayoutInfo();
		info.setReqBankSn(su.getSubSerialId());
		info.setBatchCode(transferInfo.getBatchCode());

		if (!StringUtils.isEmpty(su.getBankRetCode())) {
			info.setRtnBankCode(su.getBankRetCode());
		}
		if (!StringUtils.isEmpty(su.getBankRetMsg())) {
			info.setRtnBankMsg(su.getBankRetMsg());
		}
		if (!StringUtils.isEmpty(su.getRtnBankSn())) {
			info.setRtnBankSn(su.getRtnBankSn());
		}

		if (su.getCmdStat() != null) {
			PayoutStatus payoutStatus = PayoutStatus.convertToPayoutStatus(su.getCmdStat());
			info.setStatus(payoutStatus);
			if (payoutStatus.equals(PayoutStatus.FAILURE)) {
				local.set(local.get()+1);
			}
		} else {// 返回只有批次状态没有子状态
			info.setStatus(PayoutStatus.RECEIVED);// 后续是循环更新每笔受理状态
		}

		return info;
	}
}
