/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.dao.IUnkownCollectDao;
import com.sfpay.acquirer.domain.UnkownCollect;
import com.sfpay.acquirer.domain.UnkownCollectParam;
import com.sfpay.acquirer.enums.BankCode;
import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.acquirer.enums.CollectStatus;
import com.sfpay.acquirer.enums.FundWay;
import com.sfpay.acquirer.enums.OrderType;
import com.sfpay.acquirer.service.IReconLogService;
import com.sfpay.acquirer.service.IUnkownCollectService;
import com.sfpay.coreplatform.order.service.IBankPayService;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：
 * 未知收单信息 service 实现 
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-8-10
 */
@Deprecated
@Service("unkownCollectService")
public class UnkownCollectServiceImpl implements IUnkownCollectService {
	
	private static final Logger logger = LoggerFactory.getLogger(UnkownCollectServiceImpl.class);
	
	@Resource
	private IReconLogService reconLogService;
	
	@Resource
	private IUnkownCollectDao ucDao;
	
	@Resource
	private IBankPayService bankPayService;

	@Override
	public void addUnkownCollectFromCollect() {
		ucDao.addUnkownCollectFromCollectInfo(); 
	}

	@Override
	public List<UnkownCollect> queryUnkownCollectList(ChannelCode channelCode, BankCode bankCode, OrderType orderType, FundWay fundWay)throws ServiceException {	
		if(logger.isDebugEnabled()){
			reconLogService.insertReconLog("INFO", "queryUnkownCollectList parameters include[channelCode:"+channelCode+",bankCode:"+bankCode+",orderType:"+orderType+",fundWay:"+fundWay);
			logger.debug("queryUnkownCollectList parameters include[channelCode:"+channelCode+",bankCode:"+bankCode+",orderType:"+orderType+",fundWay:"+fundWay);
		}
		if(channelCode==null){
			reconLogService.insertReconLog("ERROR", "渠道:null,银行:"+bankCode+",未知状态的收单信息定时调度处理 queryUnkownCollectList parameters[channelCode] is null");
			throw new ServiceException(InfoCode.PARAM_INVALID,"queryUnkownCollectList parameters[channelCode] is null");
		}
		if(bankCode==null){
			reconLogService.insertReconLog("ERROR", "渠道:"+channelCode+",银行:null,未知状态的收单信息定时调度处理 queryUnkownCollectList parameters[bankCode] is null");
			throw new ServiceException(InfoCode.PARAM_INVALID,"queryUnkownCollectList parameters[bankCode] is null");
		}
//		需要查询所有未知交易
//		if(orderType==null){
//			if(!ChannelCode.QPAY.equals(channelCode)){
//				reconLogService.insertReconLog("ERROR", "渠道:"+channelCode+",银行:"+bankCode+",未知状态的收单信息定时调度处理 queryUnkownCollectList parameters[orderType] is null");
//				throw new ServiceException(InfoCode.PARAM_INVALID,"queryUnkownCollectList parameters[orderType] is null");
//			}
//		}
		if(fundWay==null){
			reconLogService.insertReconLog("ERROR", "渠道:"+channelCode+",银行:"+bankCode+",未知状态的收单信息定时调度处理 queryUnkownCollectList parameters[fundWay] is null");
			throw new ServiceException(InfoCode.PARAM_INVALID,"queryUnkownCollectList parameters[fundWay] is null");
		}
		return ucDao.queryUnkownCollectList(channelCode, bankCode, orderType, fundWay);
	}

	@Override
	public void updateUnkownCollect(String collectNo, String payNo, String rtnBankCode, String rtnBankMsg, String rtnPayCode, CollectStatus status) {
		if(collectNo==null){
			reconLogService.insertReconLog("ERROR", "未知状态的收单信息定时调度处理 updateUnkownCollect parameters[collectNo] is null");
			throw new ServiceException(InfoCode.PARAM_INVALID,"updateUnkownCollect parameters[collectNo] is null");
		}
		if(logger.isDebugEnabled()){
			reconLogService.insertReconLog("INFO", "未知状态的收单信息定时调度处理 updateUnkownCollect's parameter include collectNo:{"+collectNo+"},rtnBankCode:{"+rtnBankCode+"},rtnBankMsg:{"+rtnBankMsg+"},rtnPayCode:{"+rtnPayCode+"},status:{"+status+"}");
			logger.debug("updateUnkownCollect's parameter include collectNo:{},rtnBankCode:{},rtnBankMsg:{},rtnPayCode:{},status:{}",new Object[]{collectNo,rtnBankCode,rtnBankMsg,rtnPayCode,status});
		}
		UnkownCollectParam param = new UnkownCollectParam();
		param.setCollectNo(collectNo);
		param.setRtnBankCode(rtnBankCode);
		param.setRtnBankMsg(rtnBankMsg);
		param.setRtnPayCode(rtnPayCode);
		param.setStatus(status);
		ucDao.updateUnkownCollect(param);
		if("0000".equals(param.getProRtnCode())){//存储过程返回
			doOrderHandle(payNo, status);//收单的最终状态(成功或失败)需要更新收单状态
		}
	}
	
	/**
	 * 方法说明：
	 * 调用订单更新状态记账
	 * @param payNo
	 * @param status
	 */
	private void doOrderHandle(String payNo, CollectStatus status) {
		boolean rs = false;
		if(CollectStatus.SUCCESS == status) {
			rs = true;
		} else if(CollectStatus.FAILURE == status) {
			rs = false;
		} else {
			logger.info("收单[payNo: {}]状态: {}, 不更新核心订单, 处理结束.", payNo, status);
			return;
		}
		logger.info("调用核心订单更新[{}]状态[{}]", payNo, rs);
		try {
			bankPayService.netBankPayNotifyByAcq(payNo, rs);
		} catch (Exception e) {
			// 不往上报出异常，出现错通过订单与收单对账检查
			logger.error("调用订单更新状态异常(不影响收单,通过订单与收单对账检查)", e);
		}
	}
}
