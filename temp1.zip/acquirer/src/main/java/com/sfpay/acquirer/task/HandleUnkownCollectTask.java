/**
 * 
 */
package com.sfpay.acquirer.task;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.service.IUnkownCollectService;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：
 * 未知状态的收单信息定时调度处理 
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 *   
 * CreateDate: 2012-8-9
 */
@Deprecated
@Service("HandleUnkownCollectTask")
public class HandleUnkownCollectTask {
	
	private static final Logger logger = LoggerFactory.getLogger(HandleUnkownCollectTask.class);
	
	@Resource
	private IUnkownCollectService ucService;
	
	
	/**
	 * 方法说明：
	 * 增加未知状态的收单信息记录
	 */
	public void doAddUnkownCollect()throws ServiceException{
		logger.info("------进入生成未知状态的收单记录任务调度------");
		ucService.addUnkownCollectFromCollect();
		logger.info("------完成生成未知状态的收单记录任务调度------");
	}
		
		
}
