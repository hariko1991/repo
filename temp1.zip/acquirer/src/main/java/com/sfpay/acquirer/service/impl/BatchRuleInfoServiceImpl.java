package com.sfpay.acquirer.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.InfoCode;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.dao.IBatchRuleInfoDao;
import com.sfpay.acquirer.dao.IChannelFieldMappingDAO;
import com.sfpay.acquirer.domain.BatchRuleInfo;
import com.sfpay.acquirer.enums.BatchRuleStatus;
import com.sfpay.acquirer.service.IBatchRuleInfoService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.pagination.IPage;
import com.sfpay.framework.base.pagination.impl.Page;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 类说明：<br>
 * 路由规则维护
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 349508 韦健
 * @author 312932 何国兴
 * @author 329202 符瑜鑫(Ricky Fu)
 * 
 *         CreateDate: 2012-11-9
 */
@Service("batchRuleInfoService")
@HessianExporter
public class BatchRuleInfoServiceImpl implements IBatchRuleInfoService {
	private static final Logger logger = LoggerFactory.getLogger(BatchRuleInfoServiceImpl.class);

	@Resource
	private IBatchRuleInfoDao batchRuleInfoDao;
	@Resource
	IChannelFieldMappingDAO channelFieldMappingDAO;

	/**
	 * 方法说明： 分页查询路由规则信息 当页数据
	 * 
	 * @param map
	 *            查询条件
	 * @return
	 */
	public IPage<BatchRuleInfo> queryBatchRuleInfoPage(BatchRuleInfo param, int pageNo, int pageSize) throws ServiceException {
		// 查询总记录数
		long count = batchRuleInfoDao.queryBatchRuleInfoPageCount(param);
		List<BatchRuleInfo> list = null;
		if (count != 0) {
			if (pageNo <= 0) {
				pageNo = 1;
			}
			int start = (pageNo - 1) * pageSize;
			int end = start + pageSize;
			// 查询当前页记录
			list = batchRuleInfoDao.queryBatchRuleInfoPageList(param, start, end);
		}
		return new Page<BatchRuleInfo>(list, count, pageNo, pageSize);
	}

	/**
	 * 方法说明： 根据主键id查询常用收款单位信息
	 */
	public BatchRuleInfo queryBatchRuleInfoById(long id) throws ServiceException {
		if (id <= 0) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "id can't be null");
		}
		return batchRuleInfoDao.queryBatchRuleInfoById(id);
	}

	public BatchRuleInfo queryBatchRuleInfoByCode(String ruleCode) throws ServiceException {
		if (StringUtils.isEmpty(ruleCode)) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "ruleCode can't be null");
		}
		return batchRuleInfoDao.queryBatchRuleInfoByCode(ruleCode.trim());
	}

	/**
	 * 方法说明： 罗列路由规则所有记录
	 */
	public List<BatchRuleInfo> listAllBatchRuleInfo() throws ServiceException {
		return batchRuleInfoDao.listAllBatchRuleInfo();
	}

	/**
	 * 方法说明： 增加路由规则信息
	 * 
	 * @return
	 */
	public void addBatchRuleInfo(BatchRuleInfo param) throws ServiceException {
		if (param == null) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "param can't be null");
		}
		if (param.getAccountNo() == null) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "account can't be null");
		}
		if (param.getBankCode() == null) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "bankCode can't be null");
		}
		if (param.getBatchMaxSize() == 0) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "BatchMaxSize can't be 0");
		}
		try {
			param.setStatus(BatchRuleStatus.ENABLE);
			batchRuleInfoDao.addBatchRuleInfo(param);
		} catch (Exception e) {
			logger.error("updateBatchRuleInfoById error", e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE, "database error:" + e);
		}

	}

	/**
	 * 方法说明： 修改路由规则信息
	 * 
	 * @return
	 */
	public void updateBatchRuleInfoById(BatchRuleInfo param) throws ServiceException {
		if (param == null) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "param can't be null");
		}
		if (param.getId() <= 0) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "id can't be null");
		}
		if (StringUtils.isEmpty(param.getRuleName())) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "ruleName can't be null");
		}
		if (StringUtils.isEmpty(param.getAccountNo())) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "accountNo can't be null");
		}
		if (param.getBankCode() == null) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "bankCode can't be null");
		}
		try {
			batchRuleInfoDao.updateBatchRuleInfoById(param);
			if (!StringUtils.isEmpty(param.getMappingCode())) {
				BatchRuleInfo info = batchRuleInfoDao.queryBatchRuleInfoById(param.getId());
				info.setMappingCode(param.getMappingCode());
				channelFieldMappingDAO.bindMapping(info);
			}
		} catch (Exception e) {
			logger.error("updateBatchRuleInfoById error", e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE, "database error:" + e);
		}
	}

	/**
	 * 方法说明： 删除路由规则信息
	 * 
	 * @return
	 */
	public void deleteBatchRuleInfo(List<Long> ids) throws ServiceException {
		if (ids == null || ids.size() == 0) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "ids can't be null");
		}
		try {
			batchRuleInfoDao.deleteBatchRuleInfo(ids);
		} catch (Exception e) {
			logger.error("deleteBatchRuleInfo error", e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE, "database error:" + e);
		}
	}

	/**
	 * 
	 * 方法说明：设置是否启用
	 * 
	 * @param id
	 */
	public void isEnAble(Long id, BatchRuleStatus status) throws ServiceException {
		if (id <= 0L) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "bankCode can't be smaller than 0");
		}
		try {
			batchRuleInfoDao.isEnAble(id, status);
		} catch (Exception e) {
			logger.error("deleteBatchRuleInfo error", e);
			throw new ServiceException(InfoCode.DATABASE_FAILURE, "database error:" + e);
		}
	}

}
