/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.acquirer.domain;

import com.sfpay.acquirer.enums.FundWay;


/**
 * 
 * 类说明：对账数据VO类
 *  
 * 
 * <p>
 * 详细描述：
 *   
 * 
 * @author 271762
 *   
 * CreateDate: 2012-4-20
 */
public class RecData {
	/**
	 * 支付订单编号
	 */
	private String paymentOrderNO;

	/**
	 * 金额
	 */
	private long amount;

	/**
	 * 金额类型
	 */
	private String type;
	
	/**
	 * 资金方向 IN收款 OUT出款
	 * <p>
	 * not null
	 */
	private FundWay fundWay;

	public String getPaymentOrderNO() {
		return paymentOrderNO;
	}

	public void setPaymentOrderNO(String paymentOrderNO) {
		this.paymentOrderNO = paymentOrderNO;
	}

	public long getAmount() {
		return amount;
	}

	public void setAmount(long amount) {
		this.amount = amount;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public FundWay getFundWay() {
		return fundWay;
	}

	public void setFundWay(FundWay fundWay) {
		this.fundWay = fundWay;
	}

	@Override
	public String toString() {
		return new StringBuilder().append(paymentOrderNO).append("|")
				.append(type).append("|").append(amount).toString();
	}
}
