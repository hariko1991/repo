package com.sfpay.acquirer.service;

import java.util.Date;

import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 
 * 类说明：<br>
 * 银企付款对账
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 361424 詹锡宁
 * 
 * CreateDate: 2013-8-14
 */
public interface IPayoutReconService {

	/**
	 * 方法说明：<br>
	 * 银企付款对账
	 *
	 * @param tradeDate
	 * @throws ServiceException
	 */
	public void doRecon(Date tradeDate) throws ServiceException;
}
