/**
 * 
 */
package com.sfpay.acquirer.service.impl;

import java.text.DecimalFormat;
import java.util.List;
import javax.annotation.Resource;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.mail.MailSender;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import com.sfpay.acquirer.dao.IAcctNotifyInfoDao;
import com.sfpay.acquirer.dao.IAcctNotifyConfig;
import com.sfpay.acquirer.gate.b2e.domain.AccountNotifyInfo;
import com.sfpay.acquirer.gate.b2e.domain.AccountNotifySubInfo;
import com.sfpay.acquirer.gate.b2e.domain.BeanBase;
import com.sfpay.acquirer.gate.b2e.domain.MailInfo;
import com.sfpay.acquirer.service.IAccountChangeNotifyService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.utils.StringUtils;
import com.sfpay.framework.config.properties.Property;

/**
 * 
 * 类说明：
 * 账户变动 到账通知 
 * 
 * <p/>
 * 详细描述：
 *   
 * 
 * @author 312932 何国兴
 * @author 400928 向鹏  
 * CreateDate: 2012-12-25
 */
@Service("accountChangeNotifyService")
public class AccountChangeNotifyServiceImpl implements
		IAccountChangeNotifyService {
	
	@Resource
	private IAcctNotifyInfoDao accountNoticeInfoDao;
	@Resource
	private IAcctNotifyConfig noticeMailConfigDao;
	@Resource
	private MailSender mailSender;
	@Resource
	private SimpleMailMessage mail;

	
	
	private static Logger logger = LoggerFactory.getLogger(AccountChangeNotifyServiceImpl.class);
	
	@Override
	public void acctChangeNotify(BeanBase bean) throws ServiceException {
	  	AccountNotifyInfo info=(AccountNotifyInfo)bean.getBusDetailBeanBase();
		if(info==null){
			return;
		}
		List<AccountNotifySubInfo> infos=info.getNotifyInfos();
		if(infos==null){
			return;
		}
		logger.info("收到"+infos.size()+"条待处理账通知数据："+bean.toString());
		//写数据库
		accountNoticeInfoDao.addNotifyInfos(infos);
		
		//开始发送邮件
		for(AccountNotifySubInfo tem:infos){
		  try{//
			  if(!"0".equals(tem.getCdSign())){//TODO:0
				  continue;
			  }
			  String accountNo=tem.getAccNo();
				MailInfo mmail=noticeMailConfigDao.getMailInfoByAccountNo(accountNo);
				if(mmail==null){
					logger.info("取不到通知账号:"+accountNo+"的邮件配置信息，系统无法发送邮件！");
					continue;
				} 
			
			//在此实现邮件调用系统
				JavaMailSender sender = (JavaMailSender) mailSender;
				// 发送人从配置文件中读取
				mail.setFrom(mail.getFrom());
				// 接收人
				
				//mail.setTo(mmail.getMainSender());
				
				String toMail=mmail.getMainSender();
				if(!StringUtils.isEmpty(mmail.getDuplicateSender())){
				    toMail=toMail+";"+mmail.getDuplicateSender();
				}
				String [] mails=toMail.split(";");				
				mail.setTo(mails);
				//设置标题
				//mail.setSubject("到账通知提醒");
				//设置通知内容
				String text=Property.getProperty("MAIL_TEXT");
				String subject=Property.getProperty("MAIL_SUBJECT");
				text=new String(text.getBytes("ISO8859-1"),"UTF-8");
				subject=new String(subject.getBytes("ISO8859-1"),"UTF-8");
				text=text.replace("{1}",tem.getAccNo());
				DecimalFormat decf=new DecimalFormat("###0.00");
				double amt=tem.getAmt()/100.00;
				text=text.replace("{2}",decf.format(amt));
				mail.setText(text);
				mail.setSubject(subject);
				sender.send(mail);			
		  }catch(Exception e1){
			  logger.info("到账通知流水号:"+tem.getSerialId()+"发送邮件处理失败!",e1);
		  }
		}	 
	}

}
