/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.constant;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349 
 * 
 * CreateDate: 2016年9月1日
 */
public final class ExcpCnst {
	/**
	 * 送往审核流程
	 */
	public static final String EXCEPTION_ACTION_TYPE_H01 = "H01";
	/**
	 * 送往智能路由
	 */
	public static final String EXCEPTION_ACTION_TYPE_H02 = "H02";
	/**
	 * 调整通道
	 */
	public static final String EXCEPTION_ACTION_TYPE_H03 = "H03";
	/**
	 * 生成批次
	 */
	public static final String EXCEPTION_ACTION_TYPE_H04 = "H04";
	/**
	 * 查询更新
	 */
	public static final String EXCEPTION_ACTION_TYPE_H05 = "H05";
	/**
	 * 重发往银行
	 */
	public static final String EXCEPTION_ACTION_TYPE_H06 = "H06";
	/**
	 * 状态调整
	 */
	public static final String EXCEPTION_ACTION_TYPE_H07 = "H07";
	/**
	 * 拒绝
	 */
	public static final String EXCEPTION_ACTION_TYPE_H08 = "H08";
	/**
	 * 发起付款<br>
	 * 账户异常：人工确认账户类型正确后发起付款
	 */
	public static final String EXCEPTION_ACTION_TYPE_H09 = "H09";
	/**
	 * 异常处理-路由失败-自动路由
	 */
	public static final String EXCEPTION_ACTION_TYPE_H10 = "H10";
	/**
	 * 异常处理-发起付款-商户余额不足
	 */
	public static final String EXCEPTION_ACTION_TYPE_H11 = "H11";
	/**
	 * 异常处理-发起付款-商户未匹配出款卡号
	 */
	public static final String EXCEPTION_ACTION_TYPE_H12 = "H12";
	/**
	 * 无法进入下一级审核
	 */
	public static final String EXCEPTION_CODE_A01 = "A01";
	/**
	 * 交易未生成批次
	 */
	public static final String EXCEPTION_CODE_B01 = "B01";
	/**
	 * 未配置审核流程
	 */
	public static final String EXCEPTION_CODE_E01 = "E01";
	/**
	 * 账户类型异常
	 */
	public static final String EXCEPTION_CODE_E02 = "E02";
	/**
	 * 互金代付：商户余额不足
	 */
	public static final String EXCEPTION_CODE_E03 = "E03";
	/**
	 * 互金代付：未配置付款账号
	 */
	public static final String EXCEPTION_CODE_E04 = "E04";
	/**
	 * 交易长时间处于中间状态(RECEIVED)
	 */
	public static final String EXCEPTION_CODE_P01 = "P01";
	/**
	 * 交易返回失败,需重发
	 */
	public static final String EXCEPTION_CODE_P02 = "P02";
	/**
	 * 交易过长时间处于中间状态
	 */
	public static final String EXCEPTION_CODE_P03 = "P03";
	/**
	 * 交易长时间处于中间状态(SEC_CHECK_PASS)
	 */
	public static final String EXCEPTION_CODE_P04 = "P04";
	/**
	 * 智能路由未收到
	 */
	public static final String EXCEPTION_CODE_R01 = "R01";
	/**
	 * 智能路由未选择到合适通道
	 */
	public static final String EXCEPTION_CODE_R02 = "R02";
	/**
	 * 智能路由余额不足
	 */
	public static final String EXCEPTION_CODE_R03 = "R03";

}
