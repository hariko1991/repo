/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.dto.channel;

import java.math.BigDecimal;

import com.sfpay.ebank.dto.common.EbankBaseDTO;

/**
 * 类说明：<br>
 * 通道费率规则区间规则DTO
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author 840162 王胜军 CreateDate: 2016年7月11日
 */
public class ChannelFeeRangeDTO extends EbankBaseDTO {

	private static final long serialVersionUID = 3747482006653024222L;
	/**
	 * 计费规则ID
	 */
	private String feeRuleId;
	/**
	 * 区间最小值 单位分
	 */
	private Long rangeMin;
	/**
	 * 区间最大值 单位分
	 */
	private Long rangeMax;
	/**
	 * 费率 单位：分/笔 或 百分比
	 */
	private BigDecimal feeValue;

	public String getFeeRuleId() {
		return feeRuleId;
	}

	public void setFeeRuleId(String feeRuleId) {
		this.feeRuleId = feeRuleId;
	}

	public Long getRangeMin() {
		return rangeMin;
	}

	public void setRangeMin(Long rangeMin) {
		this.rangeMin = rangeMin;
	}

	public Long getRangeMax() {
		return rangeMax;
	}

	public void setRangeMax(Long rangeMax) {
		this.rangeMax = rangeMax;
	}

	public BigDecimal getFeeValue() {
		return feeValue;
	}

	public void setFeeValue(BigDecimal feeRate) {
		this.feeValue = feeRate;
	}

}
