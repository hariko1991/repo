/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.constant;

/**
 * 类说明：<br>
 * 编码常量类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * 
 * CreateDate: 2015-11-6
 */
public final class EncodingCnst {
	
	/** GBK 编码 */
	public static final String GBK = "GBK";
	
	/** GB2312 编码 */
	public static final String GB2312 = "GB2312";
	
	/** UTF-8 编码 */
	public static final String UTF_8 = "UTF-8";
	
	/** ISO-8859-1 编码 */
	public static final String ISO_8859_1 = "ISO-8859-1";
}
