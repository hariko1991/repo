/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.dto.business;

import java.util.Date;

import com.sfpay.ebank.dto.common.EbankBaseDTO;

/**
 * 类说明：<br>
 * 审批历史记录表
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 * CreateDate: 2016年9月7日
 */
public class BusinessApproveFlowDTO extends EbankBaseDTO {

	private static final long serialVersionUID = 4710345081565238569L;
	/**
	 *审批时间
	 */
	private Date approveDate; 
	/**
	 *审核人
	 */
	private String approveId;     
	/**
	 *审批信息：通过/拒绝原因
	 */
	private String approveMsg;     
	/**
	 *审核阶段
	 */
	private Integer approvePhase; 
	
	/**
	 * 审批状态:1，通过，2：拒绝
	 */
	private String approveStatus;
	/**
	 *审核次数
	 */
	private Integer approveTimes; 
	/**
	 *付款编号
	 */
	private String payoutNo;
	public Date getApproveDate() {
		return approveDate;
	}
	public String getApproveId() {
		return approveId;
	}
	public String getApproveMsg() {
		return approveMsg;
	}
	public Integer getApprovePhase() {
		return approvePhase;
	}
	public String getApproveStatus() {
		return approveStatus;
	}
	public Integer getApproveTimes() {
		return approveTimes;
	}
	public String getPayoutNo() {
		return payoutNo;
	}
	public void setApproveDate(Date approveDate) {
		this.approveDate = approveDate;
	}
	public void setApproveId(String approveId) {
		this.approveId = approveId;
	}
	public void setApproveMsg(String approveMsg) {
		this.approveMsg = approveMsg;
	}
	public void setApprovePhase(Integer approvePhase) {
		this.approvePhase = approvePhase;
	}
	public void setApproveStatus(String approveStatus) {
		this.approveStatus = approveStatus;
	}
	public void setApproveTimes(Integer approveTimes) {
		this.approveTimes = approveTimes;
	}
	public void setPayoutNo(String payoutNo) {
		this.payoutNo = payoutNo;
	}
}
