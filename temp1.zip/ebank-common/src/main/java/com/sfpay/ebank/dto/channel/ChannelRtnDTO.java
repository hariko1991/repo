/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.dto.channel;

import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.ebank.constant.DateCnst;
import com.sfpay.ebank.constant.SplitCnst;
import com.sfpay.ebank.dto.common.EbankBaseDTO;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 *         CreateDate: 2016年6月1日
 */
public class ChannelRtnDTO extends EbankBaseDTO {

	private static final long serialVersionUID = -4174359971821536678L;
	private static final Logger LOGGER = LoggerFactory.getLogger(ChannelRtnDTO.class);
	/**
	 * 通道编码
	 */
	private String channelCode;
	/**
	 * 付款请求流水号
	 */
	private String reqBankSn;
	/**
	 * 退票日期
	 */
	private Date bounceDate;
	/**
	 * 币种
	 */
	private String ccy;
	/**
	 * 交易金额
	 */
	private Long payAmt;
	/**
	 * 退汇金额
	 */
	private Long returnAmt;
	/**
	 * 对账日期
	 */
	private Date reconDate;
	/**
	 * 清算日期
	 */
	private Date clearDate;
	/**
	 * 交易状态
	 */
	private String status;
	/**
	 * 银行返回扩展状态
	 */
	private String retCode;
	/**
	 * 银行返回信息
	 */
	private String retMsg;

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getReqBankSn() {
		return reqBankSn;
	}

	public void setReqBankSn(String reqBankSn) {
		this.reqBankSn = reqBankSn;
	}

	public Date getBounceDate() {
		return bounceDate;
	}

	public void setBounceDate(Date bounceDate) {
		this.bounceDate = bounceDate;
	}

	public String getCcy() {
		return ccy;
	}

	public void setCcy(String ccy) {
		this.ccy = ccy;
	}

	public Long getPayAmt() {
		return payAmt;
	}

	public void setPayAmt(Long payAmt) {
		this.payAmt = payAmt;
	}

	public Long getReturnAmt() {
		return returnAmt;
	}

	public void setReturnAmt(Long returnAmt) {
		this.returnAmt = returnAmt;
	}

	public Date getReconDate() {
		return reconDate;
	}

	public void setReconDate(Date reconDate) {
		this.reconDate = reconDate;
	}

	public Date getClearDate() {
		return clearDate;
	}

	public void setClearDate(Date clearDate) {
		this.clearDate = clearDate;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRetCode() {
		return retCode;
	}

	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}

	public String getRetMsg() {
		return retMsg;
	}

	public void setRetMsg(String retMsg) {
		this.retMsg = retMsg;
	}
	
	/**
	 * 方法说明：<br>
	 * 格式转换<br>
	 * DTO 转换为 标准退票文件行
	 * 
	 * @return
	 */
	public String dto2line() {
		StringBuffer sb = new StringBuffer();
		sb.append(channelCode == null ? "" : channelCode).append(SplitCnst.COMMA);
		sb.append(reqBankSn == null ? "" : reqBankSn).append(SplitCnst.COMMA);
		sb.append(bounceDate == null ? "" : DateFormatUtils.format(bounceDate, DateCnst.YYYYMMDDHHMMSS))
				.append(SplitCnst.COMMA);
		sb.append(ccy == null ? "" : ccy).append(SplitCnst.COMMA);
		sb.append(payAmt == null ? "" : payAmt).append(SplitCnst.COMMA);
		sb.append(returnAmt == null ? "" : returnAmt).append(SplitCnst.COMMA);
		sb.append(reconDate == null ? "" : DateFormatUtils.format(reconDate, DateCnst.YYYYMMDDHHMMSS))
				.append(SplitCnst.COMMA);
		sb.append(clearDate == null ? "" : DateFormatUtils.format(clearDate, DateCnst.YYYYMMDD))
				.append(SplitCnst.COMMA);
		sb.append(status == null ? "" : status).append(SplitCnst.COMMA);
		sb.append(retCode == null ? "" : retCode).append(SplitCnst.COMMA);
		sb.append(retMsg == null ? "" : retMsg);
		return sb.toString();
	}
	
	/**
	 * 方法说明：<br>
	 * 格式转换<br>
	 * 标准退票文件行 转换为 DTO
	 * @param line
	 */
	public void line2dto(String line) {
		try {
			String[] contents = line.split(SplitCnst.SPLIT_COMMA_SEPARATOR);
			this.channelCode = contents[0];
			this.reqBankSn = contents[1];
			this.bounceDate = StringUtils.isEmpty(contents[2]) ? null
					: DateUtils.parseDate(contents[2], DateCnst.YYYYMMDDHHMMSS);
			this.ccy = contents[3];
			this.payAmt = StringUtils.isEmpty(contents[4]) ? null : Long.valueOf(contents[4]);
			this.returnAmt = StringUtils.isEmpty(contents[5]) ? null : Long.valueOf(contents[5]);
			this.reconDate = StringUtils.isEmpty(contents[6]) ? null
					: DateUtils.parseDate(contents[6], DateCnst.YYYYMMDDHHMMSS);
			this.clearDate = StringUtils.isEmpty(contents[7]) ? null
					: DateUtils.parseDate(contents[7], DateCnst.YYYYMMDD);
			this.status = contents[8];
			this.retCode = contents[9];
			this.retMsg = contents[10];
		} catch (ParseException e) {
			LOGGER.error("对账文件行转换异常--日期转换异常", e);
		} catch (Exception e) {
			LOGGER.error("对账文件行转换异常--其它异常", e);
		}
	}


}
