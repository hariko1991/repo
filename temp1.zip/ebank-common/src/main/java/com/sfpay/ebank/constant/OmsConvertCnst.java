/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.constant;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349 
 * 
 * CreateDate: 2016年11月18日
 */
public final class OmsConvertCnst {
	
	/**
	 * 账户信息
	 */
	public static final String ACCOUNT_INFOS = "accountInfos";
	/**
	 * 账户号码
	 */
	public static final String ACCOUNT_NOS = "accountNos";
	public static final String ACCOUNT_NO = "accountNo";
	public static final String ACCOUNT_NAME = "accountName";
	public static final String PERMITION_LIST = "permitionList";
	public static final String STATUS = "status";
	/**
	 * 开始日期
	 */
	public static final String START_DATE = "startDate";
	/**
	 * 结束日期
	 */
	public static final String END_DATE = "endDate";
	/**
	 * 通道信息list
	 */
	public static final String CHANNEL_INFO_LIST = "channelInfoList";
	/**
	 * 收款方账户类型
	 */
	public static final String PAYEE_ACCT_TYPE_OPTIONS = "payeeAcctTypeOptions";
	public static final String AFFILIATE_BANK_LIST = "affiliateBankList";
	public static final String STATUS_LIST = "statusList";
}
