package com.sfpay.ebank.dto.channel;

import com.sfpay.ebank.dto.common.EbankBaseDTO;

/**
 * 类说明：<br>
 * 通道费率规则表DTO
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author 840162 王胜军 CreateDate: 2016年7月12日
 */
public class ChannelRuleDTO extends EbankBaseDTO {

	private static final long serialVersionUID = -3740736318075252179L;
	
	/**
	 * 通道编码
	 */
	private String channelCode;
	/**
	 * 通道接口名称
	 */
	private String channelRuleName;
	/**
	 * 日累计限额
	 */
	private Long dayMaxAmt;
	/**
	 * 直联标志, Y：直联，N:非直联
	 */
	private String directFlag;
	/**
	 * 单笔限额(最大值),单位分
	 */
	private Long maxSingleAmt;
	/**
	 * 单笔限额(最小值),单位分
	 */
	private Long minSingleAmt;
	/**
	 * 月累计限额
	 */
	private Long monthMaxAmt;
	/**
	 * 收款账户类型
	 */
	private String payeeAcctType;
	/**
	 * 服务结束
	 */
	private String serviceEnd;
	/**
	 * 服务开始
	 */
	private String serviceStart;
	/**
	 *状态
	 */
	private String status;
	/**
	 * 时效 COMMON普通 FAST加急 ALL全部
	 */
	private String timeliness;
	
	/**
	 * 年累计限额
	 */
	private Long yearMaxAmt;

	public String getChannelCode() {
		return channelCode;
	}

	public String getChannelRuleName() {
		return channelRuleName;
	}

	public Long getDayMaxAmt() {
		return dayMaxAmt;
	}

	public String getDirectFlag() {
		return directFlag;
	}

	public Long getMaxSingleAmt() {
		return maxSingleAmt;
	}

	public Long getMinSingleAmt() {
		return minSingleAmt;
	}

	public Long getMonthMaxAmt() {
		return monthMaxAmt;
	}

	public String getPayeeAcctType() {
		return payeeAcctType;
	}

	public String getServiceEnd() {
		return serviceEnd;
	}

	public String getServiceStart() {
		return serviceStart;
	}

	public String getStatus() {
		return status;
	}

	public String getTimeliness() {
		return timeliness;
	}

	public Long getYearMaxAmt() {
		return yearMaxAmt;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public void setChannelRuleName(String channelRuleName) {
		this.channelRuleName = channelRuleName;
	}

	public void setDayMaxAmt(Long dayMaxAmt) {
		this.dayMaxAmt = dayMaxAmt;
	}

	public void setDirectFlag(String directFlag) {
		this.directFlag = directFlag;
	}

	public void setMaxSingleAmt(Long maxSingleAmt) {
		this.maxSingleAmt = maxSingleAmt;
	}

	public void setMinSingleAmt(Long minSingleAmt) {
		this.minSingleAmt = minSingleAmt;
	}

	public void setMonthMaxAmt(Long monthMaxAmt) {
		this.monthMaxAmt = monthMaxAmt;
	}

	public void setPayeeAcctType(String payeeAcctType) {
		this.payeeAcctType = payeeAcctType;
	}

	public void setServiceEnd(String serviceEnd) {
		this.serviceEnd = serviceEnd;
	}

	public void setServiceStart(String serviceStart) {
		this.serviceStart = serviceStart;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setTimeliness(String timeliness) {
		this.timeliness = timeliness;
	}

	public void setYearMaxAmt(Long yearMaxAmt) {
		this.yearMaxAmt = yearMaxAmt;
	}

}
