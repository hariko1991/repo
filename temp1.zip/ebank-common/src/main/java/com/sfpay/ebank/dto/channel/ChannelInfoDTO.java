/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.dto.channel;

import com.sfpay.ebank.dto.common.EbankBaseDTO;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 *         CreateDate: 2016年5月27日
 */
public class ChannelInfoDTO extends EbankBaseDTO {

	private static final long serialVersionUID = -6788270671051738033L;
	/**
	 * 通道编码
	 */
	private String channelCode;
	/**
	 * 通道名子
	 */
	private String channelName;
	/**
	 * 是否需要对账标识状态:Y、需要,N、不需要
	 */
	private String recFlag;
	/**
	 * 是否需要退票标识状态:Y、需要,N、不需要
	 */
	private String rtnFlag;
	/**
	 * 服务启用时间
	 */
	private String serviceOn;
	/**
	 * 服务停服时间
	 */
	private String serviceOff;
	/**
	 * 状态:Y、启用,N、停用
	 */
	private String status;

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public String getRecFlag() {
		return recFlag;
	}

	public void setRecFlag(String recFlag) {
		this.recFlag = recFlag;
	}

	public String getRtnFlag() {
		return rtnFlag;
	}

	public void setRtnFlag(String rtnFlag) {
		this.rtnFlag = rtnFlag;
	}

	public String getServiceOn() {
		return serviceOn;
	}

	public void setServiceOn(String serviceOn) {
		this.serviceOn = serviceOn;
	}

	public String getServiceOff() {
		return serviceOff;
	}

	public void setServiceOff(String serviceOff) {
		this.serviceOff = serviceOff;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
