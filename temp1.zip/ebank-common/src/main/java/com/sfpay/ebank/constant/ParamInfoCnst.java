/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.constant;

import java.util.Arrays;
import java.util.List;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349 
 * 
 * CreateDate: 2016年9月7日
 */
public final class ParamInfoCnst {
	/**
	 * 标识该笔交易手工处理，生成批次，或者出款
	 */
	public static final String PAYOUT_WAY_MANUAL = "HAND";
	/**
	 * 标识该笔交易自动处理，生成批次，或者出款
	 */
	public static final String PAYOUT_WAY_AUTO = "AUTO";
	
	/**
	 * 自动出款开关ON
	 */
	public static final String PAY_BATCH_SWITCH_ON = "ON";

	/**
	 * 自动出款开关OFF
	 */
	public static final String PAY_BATCH_SWITCH_OFF = "OFF";

	/**
	 * 常量文件，本地目录
	 */
	public static final String LOCAL_DIR = "LOCAL_DIR";
	/**
	 * FTP的目录根目录
	 */
	public static final String FTP_DIR = "FTP_DIR";
	/**
	 * FTP服务器IP
	 */
	public static final String FTP_IP = "FTP_IP";
	/**
	 * FTP服务器port
	 */
	public static final String FTP_PORT = "FTP_PORT";
	/**
	 * SFTP服务器用户密码
	 */
	public static final String FTP_PASSWORD = "FTP_PASSWORD";
	/**
	 * SFTP服务器用户户名
	 */
	public static final String FTP_USERNAME = "FTP_USERNAME";
	/**
	 * SFTP服务器的超时时间
	 */
	public static final String FTP_TIMEOUT = "FTP_TIMEOUT";
	/**
	 * SFTP的目录根目录
	 */
	public static final String SFTP_DIR = "SFTP_DIR";
	/**
	 * SFTP服务器IP
	 */
	public static final String SFTP_IP = "SFTP_IP";
	/**
	 * SFTP服务器port
	 */
	public static final String SFTP_PORT = "SFTP_PORT";
	/**
	 * SFTP服务器用户密码
	 */
	public static final String SFTP_PASSWORD = "SFTP_PASSWORD";
	/**
	 * SFTP服务器用户户名
	 */
	public static final String SFTP_USERNAME = "SFTP_USERNAME";
	/**
	 * SFTP服务器的超时时间
	 */
	public static final String SFTP_TIMEOUT = "SFTP_TIMEOUT";
	/**
	 * 初始化sftp参数的数组
	 */
	public static final String[] SFTP_ARRAY = { LOCAL_DIR, SFTP_DIR, SFTP_IP, SFTP_PORT, SFTP_PASSWORD, SFTP_USERNAME,
			SFTP_TIMEOUT };
	/**
	 * 初始化sftp参数的list集合
	 */
	public static final List<String> SFTP_PARAM = Arrays.asList(SFTP_ARRAY);
	
	/**
	 * 一次修改批次最大数
	 */
	public static final Integer UPDATE_BATCH_MAXNUM = 100;

	/**
	 * 模块编号：1业务前置
	 */
	public static final String FILE_MODULENO_GW = "1";
	/**
	 * 模块编号：2 核心
	 */
	public static final String FILE_MODULENO_CORE = "2";
	/**
	 * 模块编号：3 银行前置
	 */
	public static final String FILE_MODULENO_FRONT = "3";
	/**
	 * 传输方向： 1 上传
	 */
	public static final String FILE_DIRECTION_UPLOAD = "1";
	/**
	 * 传输方向： 2 下载
	 */
	public static final String FILE_DIRECTION_DOWNLOAD = "2";
	/**
	 * 文件类型：1 对账文件
	 */
	public static final String FILE_FILETYPE_REC = "1";
	/**
	 * 文件类型：2 退票文件
	 */
	public static final String FILE_FILETYPE_RTN = "2";
	/**
	 * 文件详情写入 -- 每次写入条数
	 */
	public static final int FILE_NUMBER_PER_WRITE = 100;
	/**
	 * 文件详情查询--每页条数
	 */
	public static final int FILE_PAGESIZE = 300;
	
	/**
	 * 退票数据获取类型(文件)
	 */
	public static final String SOURCE_TYPE_FILE = "1";
	
	/**
	 * 退票数据获取类型（流水）
	 */
	public static final String SOURCE_TYPE_RECORD = "2";
	
	/**
	 * 退票数据获取类型（页面录入）
	 */
	public static final String SOURCE_TYPE_WRITE = "3";

	
	
}
