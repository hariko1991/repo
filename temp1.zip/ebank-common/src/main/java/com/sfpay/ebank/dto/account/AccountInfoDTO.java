/**
 */
package com.sfpay.ebank.dto.account;

import com.sfpay.ebank.dto.common.EbankBaseDTO;
import com.sfpay.ebank.dto.print.MaskField;
import com.sfpay.ebank.dto.print.PrintType;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349 
 * 
 * CreateDate: 2016年8月15日
 */
public class AccountInfoDTO extends EbankBaseDTO  {
	private static final long serialVersionUID = 6079295026870210422L;
	/**
	 * 账户名
	 */
	@MaskField(type=PrintType.NAME)
	private String accountName;
	/**
	 * 账户号
	 */
	@MaskField(type=PrintType.CARD_NO)
	private String accountNo;
	/**
	 * 账户类型
	 */
	private String acctType;
	/**
	 *开户行地址
	 */
	private String address;
	/**
	 * 银行编码
	 */
	private String bankCode;
	/**
	 * 银行中文名
	 */
	private String bankName;
	/**
	 * 币种
	 */
	private String ccy;
	/**
	 * 开户行所在城市编码
	 */
	private String city;
	/**
	 * 开户行所在城市名称
	 */
	private String cityName;
	/**
	 * 开户行名
	 */
	private String openBankName;
	/**
	 * 开户行联行号
	 */
	private String openBankNo;
	/**
	 * 开户行所在省份编码
	 */
	private String province;
	/**
	 * 开户行所在省份名称
	 */
	private String provinceName;

	/**
	 * 账户信息查询通知
	 */
	private String qryChnl;
	
	/**
	 * 状态
	 */
	private String status;
	
	/**
	 *总行名称
	 */
	private String unionBankName;
	
	/**
	 *总行联行号
	 */
	private String unionBankNo;
	/**
	 * 用途
	 */
	private String useType;
	/**
	 * 可用余额
	 */
	private Long avlBalance;

	public String getAccountName() {
		return accountName;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public String getAcctType() {
		return acctType;
	}

	public String getAddress() {
		return address;
	}

	public String getBankCode() {
		return bankCode;
	}

	public String getBankName() {
		return bankName;
	}

	public String getCcy() {
		return ccy;
	}

	public String getCity() {
		return city;
	}

	public String getCityName() {
		return cityName;
	}

	public String getOpenBankName() {
		return openBankName;
	}

	public String getOpenBankNo() {
		return openBankNo;
	}

	public String getProvince() {
		return province;
	}

	public String getProvinceName() {
		return provinceName;
	}

	public String getQryChnl() {
		return qryChnl;
	}

	public String getStatus() {
		return status;
	}

	public String getUnionBankName() {
		return unionBankName;
	}

	public String getUnionBankNo() {
		return unionBankNo;
	}

	public String getUseType() {
		return useType;
	}

	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public void setAcctType(String acctType) {
		this.acctType = acctType;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public void setCcy(String ccy) {
		this.ccy = ccy;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public void setOpenBankName(String openBankName) {
		this.openBankName = openBankName;
	}

	public void setOpenBankNo(String openBankNo) {
		this.openBankNo = openBankNo;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public void setProvinceName(String provinceName) {
		this.provinceName = provinceName;
	}

	public void setQryChnl(String qryChnl) {
		this.qryChnl = qryChnl;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setUnionBankName(String unionBankName) {
		this.unionBankName = unionBankName;
	}

	public void setUnionBankNo(String unionBankNo) {
		this.unionBankNo = unionBankNo;
	}

	public void setUseType(String useType) {
		this.useType = useType;
	}

	public Long getAvlBalance() {
		return avlBalance;
	}

	public void setAvlBalance(Long avlBalance) {
		this.avlBalance = avlBalance;
	}

}
