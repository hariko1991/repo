/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.dto.business;

import com.sfpay.ebank.dto.common.EbankBaseDTO;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 * CreateDate: 2017年8月10日
 */
public class BusinessInfoDTO extends EbankBaseDTO {

	private static final long serialVersionUID = 1841674112833026480L;
	
	/**
	 *审批金额:单位分
	 */
	private Long approveAmt;
	/**
	 *审批标志:Y:审批出款,N:自动出款
	 */
	private String approveFlag;
	/**
	 *审批次数
	 */
	private Integer approveTimes;
	/**
	 *商户余额:单位分
	 */
	private Long balance;
	/**
	 *商户业务编号
	 */
	private String businessCode;
	/**
	 *商户业务名称
	 */
	private String businessName;
	/**
	 *商户类型：1：备付金余额代付，2：互金余额代付，3：银行卡代付

	 */
	private String businessType;
	/**
	 *服务结束时间:HHMMSS
	 */
	private String serviceEnd;
	/**
	 *服务开始时间:HHMMSS
	 */
	private String serviceStart;
	/**
	 * 状态
	 */
	private String status;
	public Long getApproveAmt() {
		return approveAmt;
	}
	public String getApproveFlag() {
		return approveFlag;
	}
	public Integer getApproveTimes() {
		return approveTimes;
	}
	public Long getBalance() {
		return balance;
	}
	public String getBusinessCode() {
		return businessCode;
	}
	public String getBusinessName() {
		return businessName;
	}
	public String getBusinessType() {
		return businessType;
	}
	public String getServiceEnd() {
		return serviceEnd;
	}
	public String getServiceStart() {
		return serviceStart;
	}
	public void setApproveAmt(Long approveAmt) {
		this.approveAmt = approveAmt;
	}
	public void setApproveFlag(String approveFlag) {
		this.approveFlag = approveFlag;
	}
	public void setApproveTimes(Integer approveTimes) {
		this.approveTimes = approveTimes;
	}
	public void setBalance(Long balance) {
		this.balance = balance;
	}
	public void setBusinessCode(String businessCode) {
		this.businessCode = businessCode;
	}
	public void setBusinessName(String businessName) {
		this.businessName = businessName;
	}
	public void setBusinessType(String businessType) {
		this.businessType = businessType;
	}
	public void setServiceEnd(String serviceEnd) {
		this.serviceEnd = serviceEnd;
	}
	public void setServiceStart(String serviceStart) {
		this.serviceStart = serviceStart;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
