/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.dto.channel;

import java.util.Date;

import com.sfpay.ebank.dto.common.EbankBaseDTO;

/**
 * 
 * 类说明：<br>
 * 通道黑名单
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author sfhq813 梁承鸿
 * 
 * CreateDate: 2016-8-29
 */
public class ChannelBlacklistDTO extends EbankBaseDTO{
    private static final long serialVersionUID = -4760682590276208549L;

    /**
     * 通道编码
     */
	private String channelCode;

	/**
     * 付款账号: 在该通道备案的号码
     */
	private String payerAcctNo;

	/**
     * 收款方账户号
     */
	private String payeeAcctNo;

	/**
     * 收款方账户名称: （持卡人姓名）
     */
	private String payeeAcctName;

	/**
     * 收款方机构编码: (银行编号)
     */
	private String payeeOrgCode;

	/**
     * 状态：Y 启用，N 停用
     */
	private String status;

	/**
     * 创建时间
     */
	private Date createTime;

	/**
     * 更新时间
     */
	private Date updateTime;

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getPayerAcctNo() {
		return payerAcctNo;
	}

	public void setPayerAcctNo(String payerAcctNo) {
		this.payerAcctNo = payerAcctNo;
	}

	public String getPayeeAcctNo() {
		return payeeAcctNo;
	}

	public void setPayeeAcctNo(String payeeAcctNo) {
		this.payeeAcctNo = payeeAcctNo;
	}

	public String getPayeeAcctName() {
		return payeeAcctName;
	}

	public void setPayeeAcctName(String payeeAcctName) {
		this.payeeAcctName = payeeAcctName;
	}

	public String getPayeeOrgCode() {
		return payeeOrgCode;
	}

	public void setPayeeOrgCode(String payeeOrgCode) {
		this.payeeOrgCode = payeeOrgCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	
}