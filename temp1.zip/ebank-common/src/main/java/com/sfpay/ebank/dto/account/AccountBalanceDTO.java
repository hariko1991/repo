/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.dto.account; 

import java.util.Date;

import com.sfpay.ebank.dto.common.EbankBaseDTO;
import com.sfpay.ebank.dto.print.MaskField;
import com.sfpay.ebank.dto.print.PrintType;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author sfhq814 
 * 
 * CreateDate: 2016年3月24日
 */
public class AccountBalanceDTO extends EbankBaseDTO{

	private static final long serialVersionUID = -7662513370122243590L;
	
	/**
	 * 银行编码
	 */
	private String bankCode;

	/**
	 * 银行账号
	 */
	@MaskField(type=PrintType.NAME)
	private String accountNo;
	/**
	 * 银行名称
	 */
	@MaskField(type=PrintType.CARD_NO)
	private String accountName;

	/**
	 * 币种
	 */
	private String ccy;

	/**
	 * 保留余额
	 */
	private String retainAmt;

	/**
	 * 冻结余额
	 */
	private Long frozenAmt;

	/**
	 * 查询时间
	 */
	private Date queryDate;
	
	/**
	 * 当前余额
	 */
	private Long curbalance;
	/**
	 * 昨日余额
	 */
	private Long accbalance;
	/**
	 * 上次查询余额
	 */
	private Long lastQueryBalance;	
	/**
	 * 可用余额
	 */
	private Long avlbalance;
	
	public String getBankCode() {
		return bankCode;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public String getAccountNo() {
		return accountNo;
	}
	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getCcy() {
		return ccy;
	}
	public void setCcy(String ccy) {
		this.ccy = ccy;
	}
	public String getRetainAmt() {
		return retainAmt;
	}
	public void setRetainAmt(String retainAmt) {
		this.retainAmt = retainAmt;
	}
	public Long getFrozenAmt() {
		return frozenAmt;
	}
	public void setFrozenAmt(Long frozenAmt) {
		this.frozenAmt = frozenAmt;
	}
	public Date getQueryDate() {
		return queryDate;
	}
	public void setQueryDate(Date queryDate) {
		this.queryDate = queryDate;
	}
	public Long getCurbalance() {
		return curbalance;
	}
	public void setCurbalance(Long curbalance) {
		this.curbalance = curbalance;
	}
	public Long getAccbalance() {
		return accbalance;
	}
	public void setAccbalance(Long accbalance) {
		this.accbalance = accbalance;
	}
	public Long getAvlbalance() {
		return avlbalance;
	}
	public void setAvlbalance(Long avlbalance) {
		this.avlbalance = avlbalance;
	}
	public Long getLastQueryBalance() {
		return lastQueryBalance;
	}
	public void setLastQueryBalance(Long lastQueryBalance) {
		this.lastQueryBalance = lastQueryBalance;
	}
	
	

}
