package com.sfpay.ebank.dto.business;

import com.sfpay.ebank.dto.common.EbankBaseDTO;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年8月16日
 */
public class BusinessSupportAccountDTO extends EbankBaseDTO {

	private static final long serialVersionUID = -6441863525564140348L;

	private String businessCode; // 商户编号

	private String accountNo; // 当前付款账户

	private String status;// 状态

	public String getBusinessCode() {
		return businessCode;
	}

	public void setBusinessCode(String businessCode) {
		this.businessCode = businessCode;
	}

	public String getAccountNo() {
		return accountNo;
	}

	public void setAccountNo(String accountNo) {
		this.accountNo = accountNo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
