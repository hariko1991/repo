/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.constant;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author sfhq272
 * 
 *         CreateDate: 2016-1-25
 */
public class BankConstant {
	/**
	 * 银企核心发到银行的消息
	 */
	public static final String EBANK_SEND_TO_BANK_MSG = "EBANK_SEND_TO_BANK_MSG";

	/**
	 * 银企核心发到银行的消息
	 */
	public static final String EBANK_SEND_TO_BANK_OBJ = "EBANK_SEND_TO_BANK_OBJ";

	/**
	 * 银行返回给银企核心的消息
	 */
	public static final String BANK_RET_TO_EBANK_MSG = "BANK_RET_TO_EBANK_MSG";

	/**
	 * 历史交易一次最多请求多少次银行,相当于页数,以后可以根据页数计算一次查询多少笔
	 */
	public static final String EBANK_HISTRAN_QUERY_COUNT = "EBANK_HISTRAN_QUERY_COUNT";

	/**
	 * 历史交易查询下一页标识
	 */
	public static final String EBANK_HISTRAN_QUERY_NEXT_TAG = "EBANK_HISTRAN_QUERY_NEXT_TAG";

	/**
	 * 工行的QHISD
	 */
	public static final String ICBC_EBANK_HISTRAN_QHISD = "QHISD";

	/**
	 * 工行的QBILL
	 */
	public static final String ICBC_EBANK_HISTRAN_QBILL = "QBILL";

	/**
	 * 銀行分配的企业号
	 */
	public static final String BANK_CORP_NO = "CORP_NO";

}
