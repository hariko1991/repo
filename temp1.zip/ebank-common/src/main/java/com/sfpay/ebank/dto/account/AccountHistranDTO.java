/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.dto.account;

import java.util.Date;

import com.sfpay.ebank.dto.common.EbankBaseDTO;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author sfhq272
 * 
 *         CreateDate: 2016-1-26
 */
public class AccountHistranDTO extends EbankBaseDTO {

	private static final long serialVersionUID = -292434832736859227L;
	/**
	 * ACC_NAME N VARCHAR2(100) Y 户名
	 */
	private String accName;
	/**
	 * ACC_NO N VARCHAR2(50) Y 账号
	 */
	private String accNo;
	/**
	 * BALANCE N NUMBER(16) Y 余额，单位分
	 */
	private Long balance;
	/**
	 * BUS_CODE N VARCHAR2(50) Y 业务代码
	 */
	private String busCode;
	/**
	 * BUS_TYPE N VARCHAR2(30) Y 业务种类
	 */
	private String busType;

	/**
	 * CCY N CHAR(3) Y 币种
	 */
	private String ccy;

	/**
	 * DRCRF N CHAR(1) Y 借贷标志:1:借，2:贷
	 */
	private String drCrf;
	/**
	 * OREF N VARCHAR2(50) Y 相关业务编号
	 */
	private String oref;
	/**
	 * RECIP_ACCNO N VARCHAR2(200) Y 对方账号
	 */
	private String recipAccNo;
	/**
	 * RECIP_BKNAME N VARCHAR2(400) Y 对方行名
	 */
	private String recipBkName;
	/**
	 * RECIP_BKNO N VARCHAR2(200) Y 对方行号
	 */
	private String recipBkNo;
	/**
	 * RECIP_NAME N VARCHAR2(400) Y 对方户名
	 */
	private String recipName;
	/**
	 * REF N VARCHAR2(50) Y 业务编号
	 */
	private String ref;
	/**
	 * TRADE_AMT N NUMBER(16) Y 交易金额：单位分
	 */
	private Long tradeAmt;
	/**
	 * TRADE_DATE N DATE Y 交易日期
	 */
	private Date tradeDate;
	/**
	 * TRADE_TIME N TIMESTAMP(6) Y 时间戳
	 */
	private Date tradeTime;
	/**
	 * USECN N VARCHAR2(50) Y 用途
	 */
	private String useCn;
	/**
	 * VOUH_NO N VARCHAR2(20) Y 凭证号
	 */
	private String vouhNo;
	/**
	 * VOUH_TYPE N VARCHAR2(30) Y 凭证种类
	 */
	private String vouhType;

	public String getAccName() {
		return accName;
	}

	public String getAccNo() {
		return accNo;
	}

	public Long getBalance() {
		return balance;
	}

	public String getBusCode() {
		return busCode;
	}

	public String getBusType() {
		return busType;
	}

	public String getCcy() {
		return ccy;
	}

	public String getDrCrf() {
		return drCrf;
	}

	public String getOref() {
		return oref;
	}

	public String getRecipAccNo() {
		return recipAccNo;
	}

	public String getRecipBkName() {
		return recipBkName;
	}

	public String getRecipBkNo() {
		return recipBkNo;
	}

	public String getRecipName() {
		return recipName;
	}

	public String getRef() {
		return ref;
	}

	public Long getTradeAmt() {
		return tradeAmt;
	}

	public Date getTradeDate() {
		return tradeDate;
	}

	public Date getTradeTime() {
		return tradeTime;
	}

	public String getUseCn() {
		return useCn;
	}

	public String getVouhNo() {
		return vouhNo;
	}

	public String getVouhType() {
		return vouhType;
	}

	public void setAccName(String accName) {
		this.accName = accName;
	}

	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}

	public void setBalance(Long balance) {
		this.balance = balance;
	}

	public void setBusCode(String busCode) {
		this.busCode = busCode;
	}

	public void setBusType(String busType) {
		this.busType = busType;
	}

	public void setCcy(String ccy) {
		this.ccy = ccy;
	}

	public void setDrCrf(String drCrf) {
		this.drCrf = drCrf;
	}

	public void setOref(String oref) {
		this.oref = oref;
	}

	public void setRecipAccNo(String recipAccNo) {
		this.recipAccNo = recipAccNo;
	}

	public void setRecipBkName(String recipBkName) {
		this.recipBkName = recipBkName;
	}

	public void setRecipBkNo(String recipBkNo) {
		this.recipBkNo = recipBkNo;
	}

	public void setRecipName(String recipName) {
		this.recipName = recipName;
	}

	public void setRef(String ref) {
		this.ref = ref;
	}

	public void setTradeAmt(Long tradeAmt) {
		this.tradeAmt = tradeAmt;
	}

	public void setTradeDate(Date tradeDate) {
		this.tradeDate = tradeDate;
	}

	public void setTradeTime(Date tradeTime) {
		this.tradeTime = tradeTime;
	}

	public void setUseCn(String useCn) {
		this.useCn = useCn;
	}

	public void setVouhNo(String vouhNo) {
		this.vouhNo = vouhNo;
	}

	public void setVouhType(String vouhType) {
		this.vouhType = vouhType;
	}

}
