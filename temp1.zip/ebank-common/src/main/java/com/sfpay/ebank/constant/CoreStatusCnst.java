/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.constant;

/**
 * 类说明：<br>
 * DM_EBANK.PAYOUT_INFO和DM_EBANK.BATCH_INFO中的状态
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349 
 * 
 * CreateDate: 2016年11月14日
 */
public final class CoreStatusCnst {
	/**
	  *  处理状态: 初始录入0    INIT
	  */
	 public static final String INIT = "INIT";
	 /**
	  * 交易成功1 SUCCESS
	  */
	 public static final String SUCCESS = "SUCCESS";
	 /**
	  * 交易失败2 FAILURE
	  */
	 public static final String FAILURE = "FAILURE";
	 /**
	  * 已受理(正在进行中)3 RECEIVED
	  */
	 public static final String RECEIVED = "RECEIVED";
	 /**
	  * 不明未知4 UNKNOWN
	  */
	 public static final String UNKNOWN = "UNKNOWN";
	 /**
	  * 审批中5 APPROVING
	  */
	 public static final String APPROVING = "APPROVING";
	 /**
	  *  审批通过 6APPROVE_PASS
	  */
	 public static final String APPROVE_PASS = "APPROVE_PASS";
	 /**
	  * 审批拒绝7 APPROVE_REFUSE
	  */
	 public static final String APPROVE_REFUSE = "APPROVE_REFUSE";
	 /**
	  * 路由成功8 ROUTE_SUCCESS
	  */
	 public static final String ROUTE_SUCCESS = "ROUTE_SUCCESS";
	 /**
	  * 路由失败9 ROUTE_FAILURE
	  */
	 public static final String ROUTE_FAILURE = "ROUTE_FAILURE";
	 /**
	  * 生成批次10 BATCH
	  */
	 public static final String BATCH = "BATCH";
	 /**
	  * 发送成功
	  */
	 public static final String SEND_SUCCESS = "SEND_SUCCESS";
	 /**
	  * 发送中
	  */
	 public static final String SENDING = "SENDING";
	 /**
	  * 处理完成12 DONE
	  */
	 public static final String DONE = "DONE";
	 /**
	  * 失败确认13 SURE_FAILURE
	  */
	 public static final String SURE_FAILURE = "SURE_FAILURE";
	 /**
	  * 退票
	  */
	 public static final String BOUNCE = "BOUNCE";
}
