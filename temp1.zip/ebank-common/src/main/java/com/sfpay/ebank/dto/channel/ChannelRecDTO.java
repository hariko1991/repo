/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.dto.channel;

import java.text.ParseException;
import java.util.Date;

import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateFormatUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.ebank.constant.DateCnst;
import com.sfpay.ebank.constant.SplitCnst;
import com.sfpay.ebank.dto.common.EbankBaseDTO;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 *         CreateDate: 2016年6月1日
 */
public class ChannelRecDTO extends EbankBaseDTO {

	private static final long serialVersionUID = 4260243264127959231L;
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ChannelRecDTO.class);
	/**
	 * 通道编码
	 */
	private String channelCode;
	/**
	 * 付款请求流水号
	 */
	private String reqBankSn;
	/**
	 * 对账日期
	 */
	private Date reconDate;
	/**
	 * 清算日期
	 */
	private Date clearDate;
	/**
	 * 币种
	 */
	private String ccy;
	/**
	 * 交易金额
	 */
	private Long payAmt;
	/**
	 * 实际交易金额
	 */
	private Long actAmt;
	/**
	 * 付款行
	 */
	private String payerBankNo;
	/**
	 * 付款账号
	 */
	private String payerAcctNo;
	/**
	 * 付款户名
	 */
	private String payerAcctName;
	/**
	 * 收款行
	 */
	private String payeeBankNo;
	/**
	 * 收款账号
	 */
	private String payeeAcctNo;
	/**
	 * 收款户名
	 */
	private String payeeAcctName;
	/**
	 * 交易状态
	 */
	private String status;
	/**
	 * 银行返回扩展状态
	 */
	private String retCode;
	/**
	 * 银行返回信息
	 */
	private String retMsg;

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getReqBankSn() {
		return reqBankSn;
	}

	public void setReqBankSn(String reqBankSn) {
		this.reqBankSn = reqBankSn;
	}

	public Date getReconDate() {
		return reconDate;
	}

	public void setReconDate(Date reconDate) {
		this.reconDate = reconDate;
	}

	public Date getClearDate() {
		return clearDate;
	}

	public void setClearDate(Date clearDate) {
		this.clearDate = clearDate;
	}

	public String getCcy() {
		return ccy;
	}

	public void setCcy(String ccy) {
		this.ccy = ccy;
	}

	public Long getPayAmt() {
		return payAmt;
	}

	public void setPayAmt(Long payAmt) {
		this.payAmt = payAmt;
	}

	public Long getActAmt() {
		return actAmt;
	}

	public void setActAmt(Long actAmt) {
		this.actAmt = actAmt;
	}

	public String getPayerBankNo() {
		return payerBankNo;
	}

	public void setPayerBankNo(String payerBankNo) {
		this.payerBankNo = payerBankNo;
	}

	public String getPayerAcctNo() {
		return payerAcctNo;
	}

	public void setPayerAcctNo(String payerAcctNo) {
		this.payerAcctNo = payerAcctNo;
	}

	public String getPayerAcctName() {
		return payerAcctName;
	}

	public void setPayerAcctName(String payerAcctName) {
		this.payerAcctName = payerAcctName;
	}

	public String getPayeeBankNo() {
		return payeeBankNo;
	}

	public void setPayeeBankNo(String payeeBankNo) {
		this.payeeBankNo = payeeBankNo;
	}

	public String getPayeeAcctNo() {
		return payeeAcctNo;
	}

	public void setPayeeAcctNo(String payeeAcctNo) {
		this.payeeAcctNo = payeeAcctNo;
	}

	public String getPayeeAcctName() {
		return payeeAcctName;
	}

	public void setPayeeAcctName(String payeeAcctName) {
		this.payeeAcctName = payeeAcctName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRetCode() {
		return retCode;
	}

	public void setRetCode(String retCode) {
		this.retCode = retCode;
	}

	public String getRetMsg() {
		return retMsg;
	}

	public void setRetMsg(String retMsg) {
		this.retMsg = retMsg;
	}
	
	/**
	 * 方法说明：<br>
	 * 格式转换<br>
	 * DTO 转换为 标准对账文件行
	 * 
	 * @return
	 */
	public String dto2line() {
		StringBuffer sb = new StringBuffer();
		sb.append(channelCode == null ? "" : channelCode).append(SplitCnst.COMMA);
		sb.append(reqBankSn == null ? "" : reqBankSn).append(SplitCnst.COMMA);
		sb.append(reconDate == null ? "" : DateFormatUtils.format(reconDate,DateCnst.YYYYMMDDHHMMSS)).append(SplitCnst.COMMA);
		sb.append(clearDate == null ? "" : DateFormatUtils.format(clearDate,DateCnst.YYYYMMDD)).append(SplitCnst.COMMA);
		sb.append(ccy == null ? "" : ccy).append(SplitCnst.COMMA);
		sb.append(payAmt == null ? "" : payAmt).append(SplitCnst.COMMA);
		sb.append(actAmt == null ? "" : actAmt).append(SplitCnst.COMMA);
		sb.append(payerBankNo == null ? "" : payerBankNo).append(SplitCnst.COMMA);
		sb.append(payerAcctNo == null ? "" : payerAcctNo).append(SplitCnst.COMMA);
		sb.append(payerAcctName == null ? "" : payerAcctName).append(SplitCnst.COMMA);
		sb.append(payeeBankNo == null ? "" : payeeBankNo).append(SplitCnst.COMMA);
		sb.append(payeeAcctNo == null ? "" : payeeAcctNo).append(SplitCnst.COMMA);
		sb.append(payeeAcctName == null ? "" : payeeAcctName).append(SplitCnst.COMMA);
		sb.append(status == null ? "" : status).append(SplitCnst.COMMA);
		sb.append(retCode == null ? "" : retCode).append(SplitCnst.COMMA);
		sb.append(retMsg == null ? "" : retMsg);
		return sb.toString();
	}
	
	/**
	 * 方法说明：<br>
	 * 格式转换<br>
	 * 标准对账文件行 转换为 DTO
	 * 
	 * @param line
	 */
	public void line2dto(String line) {
		try {
			String[] contents = line.split(SplitCnst.SPLIT_COMMA_SEPARATOR);
			this.channelCode = contents[0];
			this.reqBankSn = contents[1];
			this.reconDate = StringUtils.isEmpty(contents[2]) ? null
					: DateUtils.parseDate(contents[2], DateCnst.YYYYMMDDHHMMSS);
			this.clearDate = StringUtils.isEmpty(contents[3]) ? null
					: DateUtils.parseDate(contents[3], DateCnst.YYYYMMDD);
			this.ccy = contents[4];
			this.payAmt = StringUtils.isEmpty(contents[5]) ? null : Long.valueOf(contents[5]);
			this.actAmt = StringUtils.isEmpty(contents[6]) ? null : Long.valueOf(contents[6]);
			this.payerBankNo = contents[7];
			this.payerAcctNo = contents[8];
			this.payerAcctName = contents[9];
			this.payeeBankNo = contents[10];
			this.payeeAcctNo = contents[11];
			this.payeeAcctName = contents[12];
			this.status = contents[13];
			this.retCode = contents[14];
			this.retMsg = contents[15];
		} catch (ParseException e) {
			LOGGER.error("对账文件行转换异常--日期转换异常", e);
		} catch (Exception e) {
			LOGGER.error("对账文件行转换异常--其它异常", e);
		}
	}

}
