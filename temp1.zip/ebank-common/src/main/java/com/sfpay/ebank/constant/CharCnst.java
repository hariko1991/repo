/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.constant;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author sfhq272
 * 
 * CreateDate: 2015-11-7
 */
public final class CharCnst {
	/**
	 * 数据校验结果
	 */
	public static final String VALIDATION_RESULET = "validationResult";

	/**
	 * Y
	 */
	public static final String YES_FLAG = "Y";

	/**
	 * N
	 */
	public static final String NO_FLAG = "N";
	
	/**
	 * 空字符串
	 */
	public static final String BLANK_STRING = "";

}
