/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.constant;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349 
 * 
 * CreateDate: 2016年9月21日
 */
public final class JobConfigCnst {
	
	/**
	 * 针对系统中状态为RECEIVED和UNKOWN的状态的任务调度
	 */
	public static final String P01_EXTRACT_EXCP_JOB = "P01_EXTRACT_EXCP_JOB";
	
	/**
	 * 针对系统中状态为FAILURE的状态的任务调度
	 * 银行返回码匹配CHANNEL_RET_CODE_MAPPING的任务调度
	 */
	public static final String P02_EXTRACT_EXCP_JOB = "P02_EXTRACT_EXCP_JOB";
	
	/**
	 * 针对银行返回失败(专指余额不足的情况)
	 */
	public static final String P03_EXTRACT_EXCP_JOB = "P03_EXTRACT_EXCP_JOB";
	
	/**
	 * 针对付款信息长时间处于SEC_CHECK_PASS的状态
	 */
	public static final String P04_EXTRACT_EXCP_JOB = "P04_EXTRACT_EXCP_JOB";
	
	/**
	 * 付款信息长时间处于APPROVE_PASS的状态,没有变成 路由相关状态
	 */
	public static final String R01_EXTRACT_EXCP_JOB = "R01_EXTRACT_EXCP_JOB";
	
	/**
	 * 付款信息长时间处于APPROVE_PASS的状态,没有变成 路由相关状态
	 */
	public static final String R01_HANDLE_EXCP_JOB = "R01_HANDLE_EXCP_JOB";
}
