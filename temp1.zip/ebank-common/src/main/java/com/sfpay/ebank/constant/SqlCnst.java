/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.constant;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2015-12-3
 */
public final class SqlCnst {
	/**
	 * sql语句变量常量："param"
	 */
	public static final String SQL_PARAM = "param";
	/**
	 * sql语句变量常量："id"
	 */
	public static final String SQL_ID = "id";
	/**
	 * sql语句变量常量：start
	 */
	public static final String SQL_START = "start";
	/**
	 * sql语句变量常量：end
	 */
	public static final String SQL_END = "end";
	/**
	 * 数据库唯一约束异常
	 */
	public static final String DATABASE_UNIQUE_EXCEPTION = "ORA-00001";
}
