/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.dto.business;

import com.sfpay.ebank.dto.common.EbankBaseDTO;

/**
 * 
 * 类说明：<br>
 * 业务审批人员配置表
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author sfhq813 梁承鸿
 * 
 * CreateDate: 2016-7-12
 */
public class BusinessApproverDTO extends EbankBaseDTO{
    private static final long serialVersionUID = -9053890698344125117L;

    /**
     * 
     */
    private String businessCode;

    /**
     * 审批阶段
     */
    private Integer approvePhase;

    /**
     * 审批人
     */
    private String approveId;

    /**
     * 状态：Y：启用，N：停用
     */
    private String status;


	public String getBusinessCode() {
		return businessCode;
	}

	public void setBusinessCode(String businessCode) {
		this.businessCode = businessCode;
	}

	public Integer getApprovePhase() {
		return approvePhase;
	}

	public void setApprovePhase(Integer approvePhase) {
		this.approvePhase = approvePhase;
	}

	public String getApproveId() {
        return approveId;
    }

    public void setApproveId(String approveId) {
        this.approveId = approveId;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}