/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.dto.business;

/**
 * 
 * 类说明：<br>
 * 业务退票信息表
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author sfhq813 梁承鸿
 * 
 * CreateDate: 2016-8-8
 */

import java.util.Date;

import com.sfpay.ebank.dto.common.EbankBaseDTO;

public class BusinessRtnDTO extends EbankBaseDTO{
    private static final long serialVersionUID = 4364152966687207159L;

    /**
     * 退票编号:默认RTN+付款编号
     */
    private String rtnNo;

    /**
     * 付款编号:原付款记录编号
     */
    private String payoutNo;

    /**
     * 退票金额:单位分
     */
    private Long rtnAmt;

    /**
     * 退票日期
     */
    private Date rtnDate;

    /**
     * 退票流水号
     */
    private String rtnSn;

    /**
     * 退票返回码
     */
    private String rtnCode;

    /**
     * 退票原因描述
     */
    private String rtnMsg;


    public String getRtnNo() {
        return rtnNo;
    }

    public void setRtnNo(String rtnNo) {
        this.rtnNo = rtnNo;
    }

    public String getPayoutNo() {
        return payoutNo;
    }

    public void setPayoutNo(String payoutNo) {
        this.payoutNo = payoutNo;
    }

    public Long getRtnAmt() {
        return rtnAmt;
    }

    public void setRtnAmt(Long rtnAmt) {
        this.rtnAmt = rtnAmt;
    }

    public Date getRtnDate() {
        return rtnDate;
    }

    public void setRtnDate(Date rtnDate) {
        this.rtnDate = rtnDate;
    }

    public String getRtnSn() {
        return rtnSn;
    }

    public void setRtnSn(String rtnSn) {
        this.rtnSn = rtnSn;
    }

    public String getRtnCode() {
        return rtnCode;
    }

    public void setRtnCode(String rtnCode) {
        this.rtnCode = rtnCode;
    }

    public String getRtnMsg() {
        return rtnMsg;
    }

    public void setRtnMsg(String rtnMsg) {
        this.rtnMsg = rtnMsg;
    }

}