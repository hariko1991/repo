/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.dto.business;

import java.util.Date;

import com.sfpay.ebank.dto.common.EbankBaseDTO;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2016年9月7日
 */
public class BusinessApproveInfoDTO extends EbankBaseDTO {

	private static final long serialVersionUID = -5778221831569246547L;

	/**
	 * 审核开始时间
	 */
	private Date approveBeginDate;
	/**
	 * 审核结束时间
	 */
	private Date approveEndDate;
	/**
	 * 审批阶段
	 */
	private Integer approvePhase;
	/**
	 * 审批批次
	 */
	private Integer approveTimes;
	/**
	 * 付款编号
	 */
	private String payoutNo;
	
	public Date getApproveBeginDate() {
		return approveBeginDate;
	}
	public Date getApproveEndDate() {
		return approveEndDate;
	}
	public Integer getApprovePhase() {
		return approvePhase;
	}
	public Integer getApproveTimes() {
		return approveTimes;
	}
	public String getPayoutNo() {
		return payoutNo;
	}
	public void setApproveBeginDate(Date approveBeginDate) {
		this.approveBeginDate = approveBeginDate;
	}
	public void setApproveEndDate(Date approveEndDate) {
		this.approveEndDate = approveEndDate;
	}
	public void setApprovePhase(Integer approvePhase) {
		this.approvePhase = approvePhase;
	}

	public void setApproveTimes(Integer approveTimes) {
		this.approveTimes = approveTimes;
	}
	public void setPayoutNo(String payoutNo) {
		this.payoutNo = payoutNo;
	}

}
