/**
 * 
 */
package com.sfpay.ebank.dto.channel;

import com.sfpay.ebank.dto.common.EbankBaseDTO;

/**
 * 
 * 类说明：
 * 银行渠道参数配置 
 * 
 * <p/>
 * 详细描述：
 *   
 */
public class ChannelArgDTO extends EbankBaseDTO {

	private static final long serialVersionUID = -2510497596654916293L;

	/**
	 * 渠道编码
	 */
	private String channelCode;
	
	/**
	 * 渠道名称
	 */
	private String channelName;
	
	/**
	 * 银行编号
	 */
	private String bankCode;
	
	/**
	 * 银行名称
	 */
	private String bankName;
	
	/**
	 * 参数名称
	 */
	private String argName;
	
	/**
	 * 参数键
	 */
	private String argKey;
	
	/**
	 * 参数值
	 */
	private String argValue;

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getArgName() {
		return argName;
	}

	public void setArgName(String argName) {
		this.argName = argName;
	}

	public String getArgKey() {
		return argKey;
	}

	public void setArgKey(String argKey) {
		this.argKey = argKey;
	}

	public String getArgValue() {
		return argValue;
	}

	public void setArgValue(String argValue) {
		this.argValue = argValue;
	}
	
}
