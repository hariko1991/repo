/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.constant;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2016年11月11日
 */
public final class SplitCnst {

	/**
	 * 文件列分隔符
	 */
	public static final String SPLIT_VERTICAL_SEPARATOR = "\\|";

	/**
	 * 文件列分隔符
	 */
	public static final String SPLIT_COMMA_SEPARATOR = "\\,";

	/**
	 * 文件列组成分隔符  |@|
	 */
	public static final String ASSEMBLE1_SEPARATOR = "|@|";
	
	/**
	 *文件字段值域分隔符，付款请求字段不能包括正字符 @# 
	 */
	public final static String ASSEMBLE2_SEPARATOR ="@#";

	/**
	 * 文件路径分隔符
	 */
	public static final String FILE_PATH_SEPERATOR = "/";

	/**
	 * 空格
	 */
	public static final String BLANK_SPACE = " ";
	/**
	 * 空格
	 */
	public static final String UNDER_LINE = "_";

	/**
	 * 竖线
	 */
	public static final String VERTICAL = "|";
	/**
	 * 分号
	 */
	public static final String SEMICOLON = ";";

	/**
	 * 逗号
	 */
	public static final String COMMA = ",";
	/**
	 * 井号
	 */
	public static final String WELLNO = "#";
	/**
	 * .号
	 */
	public static final String POINT = ".";
	/**
	 * 冒号
	 */
	public static final String COLON = ":";
	
}
