/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.dto.business;

/**
 * 
 * 类说明：<br>
 * 疑似退票记录表
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author sfhq813 梁承鸿
 * 
 * CreateDate: 2016-8-8
 */

import java.util.Date;

import com.sfpay.ebank.dto.common.EbankBaseDTO;

public class BusinessSuspectRtnDTO extends EbankBaseDTO{
    private static final long serialVersionUID = -6480883557233732290L;

    /**
     * 资金流水的主键:(account_histran的id)
     */
    private String capId;

    /**
     * 付款流水的主键:(payout_info的REQ_BANK_SN)
     */
    private String payReqSn;

    /**
     * 获取类型:1 文件 2 流水 3 页面录入
     */
    private String sourceType;

    /**
     * 对应每次跑批的ID:(BUSINESS_SUSPECT_RTN_STATUS的主键ID
     */
    private String batchId;

    /**
     * 退票返回码
     */
    private String rtnCode;

    /**
     * 退票原因描述
     */
    private String rtnMsg;

    /**
     * 退票处理状态:0 未处理  1 已处理 2 已退票
     */
    private String status;

    /**
     * 退票日期
     */
    private Date rtnDate;

    /**
     * 退票流水号
     */
    private String rtnSn;

    public String getCapId() {
        return capId;
    }

    public void setCapId(String capId) {
        this.capId = capId;
    }

    public String getPayReqSn() {
		return payReqSn;
	}

	public void setPayReqSn(String payReqSn) {
		this.payReqSn = payReqSn;
	}

	public String getSourceType() {
        return sourceType;
    }

    public void setSourceType(String sourceType) {
        this.sourceType = sourceType;
    }

    public String getBatchId() {
        return batchId;
    }

    public void setBatchId(String batchId) {
        this.batchId = batchId;
    }

    public String getRtnCode() {
        return rtnCode;
    }

    public void setRtnCode(String rtnCode) {
        this.rtnCode = rtnCode;
    }

    public String getRtnMsg() {
        return rtnMsg;
    }

    public void setRtnMsg(String rtnMsg) {
        this.rtnMsg = rtnMsg;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getRtnDate() {
        return rtnDate;
    }

    public void setRtnDate(Date rtnDate) {
        this.rtnDate = rtnDate;
    }

    public String getRtnSn() {
        return rtnSn;
    }

    public void setRtnSn(String rtnSn) {
        this.rtnSn = rtnSn;
    }

}