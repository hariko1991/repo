/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.dto.account;

import java.util.Date;

import com.sfpay.ebank.dto.common.EbankBaseDTO;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author sfhq272 
 * 
 * CreateDate: 2016-1-26
 */
public class AccountHistranStatusDTO extends EbankBaseDTO{

	private static final long serialVersionUID = 1805151163270168496L;
	/**
	 * 賬戶編號
	 */
	private String accNo;
	/**
	 * 銀行編號
	 */
	private String bankCode;
	/**
	 * 查询日期
	 */
	private Date queryDate;

	/**
	 * 運行結果信息
	 */
	private String runMsg;
	/**
	 * 運行結果
	 */
	private String runResult;
	/**
	 * 交易类型：1、账户交易明细，2、账户余额
	 */
	private String transType;
	
	public String getAccNo() {
		return accNo;
	}
	public String getBankCode() {
		return bankCode;
	}
	public Date getQueryDate() {
		return queryDate;
	}
	public String getRunMsg() {
		return runMsg;
	}
	public String getRunResult() {
		return runResult;
	}
	public String getTransType() {
		return transType;
	}
	
	
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}
	public void setQueryDate(Date queryDate) {
		this.queryDate = queryDate;
	}
	public void setRunMsg(String runMsg) {
		this.runMsg = runMsg;
	}
	public void setRunResult(String runResult) {
		this.runResult = runResult;
	}
	public void setTransType(String transType) {
		this.transType = transType;
	}
}
