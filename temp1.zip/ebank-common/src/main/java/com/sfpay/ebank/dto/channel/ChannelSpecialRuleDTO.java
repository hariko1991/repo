package com.sfpay.ebank.dto.channel;

import com.sfpay.ebank.dto.common.EbankBaseDTO;


/**
 * channel_special_rule 表所对应的实体
 * @author sfhq272
 */
public class ChannelSpecialRuleDTO extends EbankBaseDTO{

	private static final long serialVersionUID = -8551824517625257855L;

	private String channelRuleId;
	private String key;
	private String clazz;
	private String method;
	private String type;
	private String  value;
	private String status;
	private String dataType;
	
	
	public String getChannelRuleId() {
		return channelRuleId;
	}

	public void setChannelRuleId(String channelRuleId) {
		this.channelRuleId = channelRuleId;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

	public String getClazz() {
		return clazz;
	}

	public void setClazz(String clazz) {
		this.clazz = clazz;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getValue() {
		return value;
	}

	public void setValue(String value) {
		this.value = value;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getDataType() {
		return dataType;
	}

	public void setDataType(String dataType) {
		this.dataType = dataType;
	}



}
