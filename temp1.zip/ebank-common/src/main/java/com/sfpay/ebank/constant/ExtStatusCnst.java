/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.constant;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349 
 * 
 * CreateDate: 2016年8月30日
 */
public class ExtStatusCnst {
	
	/*****************HANDLE_STATUS(处理状态STRING类型)********************/
	/**
	 * 处理状态:初始化
	 */
	public static final String HANDLE_STATUS_INIT = "0";
	/**
	 * 处理状态:成功
	 */
	public static final String HANDLE_STATUS_SUCCESS = "1";
	/**
	 * 处理状态:失败
	 */
	public static final String HANDLE_STATUS_FAILURE = "2";
	/**
	 * 处理状态:正在处理
	 */
	public static final String HANDLE_STATUS_DOING = "3";
	/**
	 * 处理状态:数据已经做过处理
	 */
	public static final String HANDLE_STATUS_DONE = "4";
	
	/*************OMS 页面返回状态*******************************/
	/**
	 * oms后台处理成功
	 */
	public static final String OMS_SUCCESS = "SUCCESS";
	
	
}
