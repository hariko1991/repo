/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.dto.channel;

import java.math.BigDecimal;

import com.sfpay.ebank.dto.common.EbankBaseDTO;

/**
 * 类说明：<br>
 * 通道费率规则DTO
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author 840162 王胜军 CreateDate: 2016年7月11日
 */
public class ChannelFeeRuleDTO extends EbankBaseDTO {

	private static final long serialVersionUID = 8660952421363241860L;
	/**
	 * 地域标识：Y:同城，N:异地, A:全部
	 */
	private String areaFlag;
	/**
	 * 银行标识：Y:同行，N:跨行, A:全部
	 */
	private String bankFlag;
	
	/**
	 * 通道编码
	 */
	private String channelCode;
	/**
	 * 计费方式：T：笔数，M：金额，Y：年费，C：自定义,F: 固定费率
	 * 
	 * {@link com.sfpay.ebank.constant.FeeModeCnst} 
	 */
	private String feeMode;
	/**
	 * 固定费：单位分（区间费率参考区间费率表）
	 */
	private BigDecimal feeValue;
	/**
	 *收款人账户类型：COMPANY：公司，PERSON：个人
	 */
	private String payeeAcctType;

	/**
	 *状态
	 */
	private String status;
	
	/**
	 * 时效：COMMON：普通，FAST：快速，REALTIME：实时, ALL:全部
	 */
	private String timeliness;
	
	 /**
	 *交易金额
	 */
	private Long tradeAmt; 

	public String getAreaFlag() {
		return areaFlag;
	}

	public String getBankFlag() {
		return bankFlag;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public String getFeeMode() {
		return feeMode;
	}

	public BigDecimal getFeeValue() {
		return feeValue;
	}

	public String getPayeeAcctType() {
		return payeeAcctType;
	}

	public String getStatus() {
		return status;
	}

	public String getTimeliness() {
		return timeliness;
	}

	public Long getTradeAmt() {
		return tradeAmt;
	}

	public void setAreaFlag(String areaFlag) {
		this.areaFlag = areaFlag;
	}

	public void setBankFlag(String bankFlag) {
		this.bankFlag = bankFlag;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public void setFeeMode(String feeMode) {
		this.feeMode = feeMode;
	}

	public void setFeeValue(BigDecimal feeValue) {
		this.feeValue = feeValue;
	}

	public void setPayeeAcctType(String payeeAcctType) {
		this.payeeAcctType = payeeAcctType;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public void setTimeliness(String timeliness) {
		this.timeliness = timeliness;
	}

	public void setTradeAmt(Long tradeAmt) {
		this.tradeAmt = tradeAmt;
	}

}
