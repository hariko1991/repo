/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.constant;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349 
 * 
 * CreateDate: 2016年11月11日
 */
public final class EnumInfoCnst {
	/*********************payeeAcctType***************/
	/**
	 * 帐户类型 COMMPANY
	 */
	public static final String ACCTTYPE_COMMPANY = "COMPANY";

	/**
	 * 帐户类型 PERSON
	 */
	public static final String ACCTTYPE_PERSON = "PERSON";

	/**
	 * 帐户类型 ALL
	 */
	public static final String ACCTTYPE_ALL = "ALL";
	/**************************TIMELINESS**************************/
	/**
	 * 快速
	 */
	public static final String TIMELINESS_FAST = "FAST";
	/**
	 * 实时
	 */
	public static final String TIMELINESS_REALTIME = "REALTIME";
	/**
	 * 普通
	 */
	public static final String TIMELINESS_COMMON = "COMMON";
	/**
	 * 全部
	 */
	public static final String TIMELINESS_ALL = "ALL";
}
