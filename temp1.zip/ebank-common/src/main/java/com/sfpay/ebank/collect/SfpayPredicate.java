/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ebank.collect;

import java.util.Map;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.collections4.Predicate;

/**
 * 类说明：<br>
 * 实现apache的断言
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 *         CreateDate: 2016年7月15日
 */
public class SfpayPredicate<T> implements Predicate<T> {
	/**
	 * 目标属性+目标值
	 */
	private Map<String, Object> props;

	public SfpayPredicate(Map<String, Object> props) {
		this.props = props;
	}

	@Override
	public boolean evaluate(T bean) {

		try {
			for (Map.Entry<String, Object> entry : props.entrySet()) {
				String key = entry.getKey();
				Object objValue = entry.getValue();
				Object beanValue = PropertyUtils.getProperty(bean, key);
				if (objValue == null) {
					if (beanValue != null) {
						return false;
					}
				} else {
					if (beanValue == null || !objValue.equals(beanValue)) {
						return false;
					}
				}
			}
		} catch (Exception e) {
			return false;
		}

		return true;

	}

	public Map<String, Object> getProps() {
		return props;
	}

	public void setProps(Map<String, Object> props) {
		this.props = props;
	}

}
