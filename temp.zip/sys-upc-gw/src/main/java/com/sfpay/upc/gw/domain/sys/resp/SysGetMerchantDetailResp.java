package com.sfpay.upc.gw.domain.sys.resp;

import com.sfpay.upc.gw.domain.sys.Resp;

/**
 * 
 * 类说明：<br>
 * 5.商户查询接口：
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月2日
 */
public class SysGetMerchantDetailResp extends Resp {

	private static final long serialVersionUID = 2750801368931185256L;

}
