package com.sfpay.upc.gw.domain.sys.resp;

import com.sfpay.upc.gw.domain.sys.Resp;

/**
 * 
 * 类说明：<br>
 * 10.条码支付接口：
 * 
 * <p>
 * 详细描述：<br>
 * 商家使用扫码枪等条码识别设备扫描用户支付宝、 微信钱包上的条码二维码完成付款，用户
 * 出示付款码，收款操作由商家完成。
 * 1. 用户登录支付宝、 微信钱包，点击首页“付款”，进入付款码界面；
 * 2. 收银员在商家收银系统操作生成订单，用户确认支付金额；
 * 3. 用户出示钱包的“付款码”，收银员用扫码设备来扫描用户手机上的条码/二维码后，商家收银系统提交支付；
 * 4. 付款成功后商家收银系统会拿到支付成功或者失败的结果。
 * 验密支付流程：
 * 场景交互与免密模式相同，不同的是在商户调用【 条码支付接口】发起支付请求之
 * 后， 微信后台提示用户输入密码确认支付，接口同步返回 USERPAYING 状态，商户系统
 * 再轮询调用查询订单接口来确认当前用户是否已经支付成功。
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月5日
 */
public class SysBarcodeResp extends Resp {
	private static final long serialVersionUID = -388327225273269517L;

	/**
	 * 顺手付商户订单号
	 */
	private String mchOrderNo;
	/**
	 * 支付订单号
	 */
	private String payNo;
	/**
	 * 备付金银行编码
	 */
	private String provBankCode;
	
	/**
	 * 备付金银行名称
	 */
	private String provBankName;

	/**
	 * 备付金账号
	 */
	private String provAcctNo;
	/**
	 * 备付金名子
	 */
	private String provAcctName;

	/**
	 * 渠道号 (微信或者支付宝的流水号)
	 */
	private String channelNo;

	/**
	 * 银行返回流水号 (微众或者民生的流水号)
	 */
	private String rtnOrderNo;
	
	/**
	 * 通道编码（WE、微众银行，CMBC、民生银行）
	 */
	private String channelCode;

	public String getMchOrderNo() {
		return mchOrderNo;
	}

	public void setMchOrderNo(String mchOrderNo) {
		this.mchOrderNo = mchOrderNo;
	}

	public String getPayNo() {
		return payNo;
	}

	public void setPayNo(String payNo) {
		this.payNo = payNo;
	}

	public String getProvBankCode() {
		return provBankCode;
	}

	public void setProvBankCode(String provBankCode) {
		this.provBankCode = provBankCode;
	}

	public String getProvAcctNo() {
		return provAcctNo;
	}

	public void setProvAcctNo(String provAcctNo) {
		this.provAcctNo = provAcctNo;
	}

	public String getProvAcctName() {
		return provAcctName;
	}

	public void setProvAcctName(String provAcctName) {
		this.provAcctName = provAcctName;
	}

	public String getChannelNo() {
		return channelNo;
	}

	public void setChannelNo(String channelNo) {
		this.channelNo = channelNo;
	}

	public String getRtnOrderNo() {
		return rtnOrderNo;
	}

	public void setRtnOrderNo(String rtnOrderNo) {
		this.rtnOrderNo = rtnOrderNo;
	}

	public String getProvBankName() {
		return provBankName;
	}

	public void setProvBankName(String provBankName) {
		this.provBankName = provBankName;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}
}
