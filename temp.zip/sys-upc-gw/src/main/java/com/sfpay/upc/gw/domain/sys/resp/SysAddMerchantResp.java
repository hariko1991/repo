package com.sfpay.upc.gw.domain.sys.resp;

import com.sfpay.upc.gw.domain.sys.Resp;

/**
 * 
 * 类说明：<br>
 * 4.商户进件接口：
 * 
 * <p>
 * 详细描述：<br>
 * 示例：
 * {"result":"{"code":"000000","data":{"mid":"000010000000001","encryptId":"xxxx","key":"xxxxx"},
 * "message":"新增商户成功"}","sign":"xxx"}
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月2日
 */
public class SysAddMerchantResp extends Resp {

	private static final long serialVersionUID = -3488063863155204511L;

}
