package com.sfpay.upc.gw.domain.sys.req;

import com.sfpay.upc.gw.domain.sys.Req;

/**
 * 
 * 类说明：<br>
 * 4.查询订单状态接口：
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月2日
 */
public class SysQueryReq extends Req {

	private static final long serialVersionUID = -6536823550176289156L;
	
	/**
	 * 业务交易号（业务系统上送）
	 */
	private String bizTradeNo;
	
	/**
	 * 渠道支付号（UPC 返回的 payNo）
	 */
	private String payNo;
	
	
	public String getBizTradeNo() {
		return bizTradeNo;
	}

	public void setBizTradeNo(String bizTradeNo) {
		this.bizTradeNo = bizTradeNo;
	}

	public String getPayNo() {
		return payNo;
	}

	public void setPayNo(String payNo) {
		this.payNo = payNo;
	}
}
