package com.sfpay.upc.gw.cnst;

public interface UpcPayCodeCnst {
	public static final String PAY_CODE_ALIPAY = "ALIPAY";
	public static final String PAY_CODE_WX = "WXPAY";
}
