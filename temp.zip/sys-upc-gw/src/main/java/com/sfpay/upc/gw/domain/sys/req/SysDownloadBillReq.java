/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.upc.gw.domain.sys.req;

import java.util.Date;

import com.sfpay.upc.gw.domain.sys.Req;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月2日
 */
public class SysDownloadBillReq extends Req {

	private static final long serialVersionUID = 8444317527283027154L;

	private Date reconFileDate;
	
	private boolean isTask;

	public Date getReconFileDate() {
		return reconFileDate;
	}

	public void setReconFileDate(Date reconFileDate) {
		this.reconFileDate = reconFileDate;
	}

	public boolean isTask() {
		return isTask;
	}

	public void setTask(boolean isTask) {
		this.isTask = isTask;
	}

}
