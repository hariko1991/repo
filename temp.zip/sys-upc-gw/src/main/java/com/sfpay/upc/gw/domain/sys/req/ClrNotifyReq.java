/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.upc.gw.domain.sys.req;

import com.sfpay.upc.gw.domain.sys.Req;

/**
 * 
 * 类说明：<br>
 * 清算结果通知
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 830598 wu_jl
 * 
 * CreateDate: 2017年5月10日
 */
public class ClrNotifyReq extends Req {

	private static final long serialVersionUID = -2645207395262889696L;
	private String channelCode;
	/**
	 * 必填 退款成功 "1" 退款失败 "0"
	 */
	private String refundStatus;

	/**
	 * 退款金额 必填
	 */
	private Long refundAmt;

	/**
	 * 原交易金额 必填
	 */
	private Long oriAmt;

	/**
	 * 原上送机构流水号 必填
	 */
	private String oriReqOrderNo;

	/**
	 * 退款请求流水号 必填
	 */
	private String uppOrderNo;

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getRefundStatus() {
		return refundStatus;
	}

	public void setRefundStatus(String refundStatus) {
		this.refundStatus = refundStatus;
	}

	public Long getRefundAmt() {
		return refundAmt;
	}

	public void setRefundAmt(Long refundAmt) {
		this.refundAmt = refundAmt;
	}

	public Long getOriAmt() {
		return oriAmt;
	}

	public void setOriAmt(Long oriAmt) {
		this.oriAmt = oriAmt;
	}

	public String getOriReqOrderNo() {
		return oriReqOrderNo;
	}

	public void setOriReqOrderNo(String oriReqOrderNo) {
		this.oriReqOrderNo = oriReqOrderNo;
	}

	public String getUppOrderNo() {
		return uppOrderNo;
	}

	public void setUppOrderNo(String uppOrderNo) {
		this.uppOrderNo = uppOrderNo;
	}

}
