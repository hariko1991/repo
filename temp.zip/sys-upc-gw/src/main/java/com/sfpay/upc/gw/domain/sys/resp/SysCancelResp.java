package com.sfpay.upc.gw.domain.sys.resp;

import com.sfpay.upc.gw.domain.sys.Resp;

/**
 * 
 * 类说明：<br>
 * 5.撤销订单接口：
 * 
 * <p>
 * 详细描述：<br>
 * 示例：
 * {"result":"{"code":"000000","data":{"bizOrderNumber":"36207213161116131644","walletType":
 * 1},"message":"撤销订单成功"}","sign":"xxx"}
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月2日
 */
public class SysCancelResp extends Resp {

	private static final long serialVersionUID = 108607800685625671L;
}
