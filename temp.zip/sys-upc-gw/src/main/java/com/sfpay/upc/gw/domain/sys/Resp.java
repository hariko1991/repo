package com.sfpay.upc.gw.domain.sys;

public class Resp extends PrintDto {

	private static final long serialVersionUID = -2837132081740662800L;

	/**
	 * 订单状态
	 * INIT:未支付,TRADING交易进行中,SUCCESS交易成功,FAILURE交易失败,CLOSE交易失败
	 */
	private String status;
	/**
	 * 返回码
	 */
	private String rtnCode;
	/**
	 * 返回信息
	 */
	private String rtnMsg;

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRtnCode() {
		return rtnCode;
	}

	public void setRtnCode(String rtnCode) {
		this.rtnCode = rtnCode;
	}

	public String getRtnMsg() {
		return rtnMsg;
	}

	public void setRtnMsg(String rtnMsg) {
		this.rtnMsg = rtnMsg;
	}

}
