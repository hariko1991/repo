package com.sfpay.upc.gw.domain.sys.req;

import com.sfpay.upc.gw.domain.sys.Req;

/**
 * 
 * 类说明：<br>
 * 5.商户查询接口：
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月2日
 */
public class SysGetMerchantDetailReq extends Req {

	private static final long serialVersionUID = -3551266167446535669L;

	// 渠道编码
	private String channelCode;
	// 商户号
	private String mchNo;
	// 支付类型 ALIPAY WXPAY ALL
	private String payCode;
	// 清算模式 ONE一清 TWO二清
	private String clearMode;

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getMchNo() {
		return mchNo;
	}

	public void setMchNo(String mchNo) {
		this.mchNo = mchNo;
	}

	public String getPayCode() {
		return payCode;
	}

	public void setPayCode(String payCode) {
		this.payCode = payCode;
	}

	public String getClearMode() {
		return clearMode;
	}

	public void setClearMode(String clearMode) {
		this.clearMode = clearMode;
	}

}
