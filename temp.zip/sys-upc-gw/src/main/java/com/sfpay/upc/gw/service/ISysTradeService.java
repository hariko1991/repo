package com.sfpay.upc.gw.service;

import com.sfpay.upc.gw.domain.sys.req.SysBarcodeReq;
import com.sfpay.upc.gw.domain.sys.req.SysCancelReq;
import com.sfpay.upc.gw.domain.sys.req.SysJsprecreateReq;
import com.sfpay.upc.gw.domain.sys.req.SysQueryReq;
import com.sfpay.upc.gw.domain.sys.req.SysRefundReq;
import com.sfpay.upc.gw.domain.sys.resp.SysBarcodeResp;
import com.sfpay.upc.gw.domain.sys.resp.SysCancelResp;
import com.sfpay.upc.gw.domain.sys.resp.SysJsprecreateResp;
import com.sfpay.upc.gw.domain.sys.resp.SysQueryResp;
import com.sfpay.upc.gw.domain.sys.resp.SysRefundResp;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月5日
 */
public interface ISysTradeService {

	/**
	 * 订单查询
	 * @param req 
	 * @return OrderQueryResp
	 * @author 700315
	 */
	SysQueryResp query(SysQueryReq req);

	/**
	 * 订单撤销
	 * @param req
	 * @return OrderCancelResp
	 */
	SysCancelResp cancel(SysCancelReq req);

	/**
	 * 退款
	 * @param req
	 * @return RefundResp
	 */
	SysRefundResp refund(SysRefundReq req);

	/**
	 * 一码付预下单
	 * @param req
	 * @return PrecreateResp
	 */
	SysJsprecreateResp jsprecreate(SysJsprecreateReq req);

	/**
	 * 条码支付
	 * @param req
	 * @return PrecreateResp
	 */
	SysBarcodeResp barcode(SysBarcodeReq req);
}
