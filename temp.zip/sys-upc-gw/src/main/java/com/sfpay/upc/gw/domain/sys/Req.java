package com.sfpay.upc.gw.domain.sys;

import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;

public class Req extends PrintDto {
	private static final long serialVersionUID = 5950592134111942023L;
	private static final String EXT_MAP = "extMap";
	private static final String CLAZZ = "class";

	// 备注
	private String remark;
	// 扩展参数集合
	private Map<String, String> extMap;

	@SuppressWarnings("unchecked")
	public Map<String, String> toMap() throws Exception {
		Map<String, String> rtnMap = BeanUtils.describe(this);
		rtnMap.remove(EXT_MAP);
		rtnMap.remove(CLAZZ);
		if (null != extMap) {
			rtnMap.putAll(extMap);
		}
		return rtnMap;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Map<String, String> getExtMap() {
		return extMap;
	}

	public void setExtMap(Map<String, String> extMap) {
		this.extMap = extMap;
	}

}
