package com.sfpay.upc.gw.domain.sys.resp;

import com.sfpay.upc.gw.domain.sys.Resp;

/**
 * 
 * 类说明：<br>
 * 10.一码付预下单接口：
 * 
 * <p>
 * 详细描述：<br>
 * 由于该接口需要配置微信二维码回调地址， 所需要在生产环境进行调试测试
 * 生产请求地址： https://test.njcmbc.com/oss-transaction/gateway/jsprecreate
 * 测试参数请联系对接调试人员
 * 
 * 返回示例：
 * {"result":"{"code":"000000","data":{"bizOrderNumber":"69448892161116132938","qrcode":"htt
 * ps://qr.alipay.com/bax07347b6p0bn5dazcm20fb","timeExpire":"20161116142938","txnStatus":"
 * p","sdkParam":"201611222100100450028335218"},"message":"预下单成功"}","sign":"xxx"}
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月2日
 */
public class SysJsprecreateResp extends Resp {

	private static final long serialVersionUID = 1L;

	/**
	 * 顺手付商户订单号
	 */
	private String mchOrderNo;
	/**
	 * 支付订单号
	 */
	private String payNo;
	/**
	 * 订单过时时间格式为 yyyyMMddHHmmss
	 */
	private String timeExpire;
	/**
	 * 支付宝为 trade_no 微信为 json 格式字符串内容如下,
	 * {"appId":"xxx","nonceStr":"azp1jfVbm0","package":"prepay_id=xxx","paySign":"xxx","signType":"
	 * MD5","timeStamp":"1482812259"},用以调起微信原生 h5 支付
	 */
	private String sdkParam;

	public String getMchOrderNo() {
		return mchOrderNo;
	}

	public void setMchOrderNo(String mchOrderNo) {
		this.mchOrderNo = mchOrderNo;
	}

	public String getPayNo() {
		return payNo;
	}

	public void setPayNo(String payNo) {
		this.payNo = payNo;
	}

	public String getTimeExpire() {
		return timeExpire;
	}

	public void setTimeExpire(String timeExpire) {
		this.timeExpire = timeExpire;
	}

	public String getSdkParam() {
		return sdkParam;
	}

	public void setSdkParam(String sdkParam) {
		this.sdkParam = sdkParam;
	}

}
