package com.sfpay.upc.gw.service;

import com.sfpay.upc.gw.domain.sys.req.SysAddMerchantReq;
import com.sfpay.upc.gw.domain.sys.req.SysGetMerchantDetailReq;
import com.sfpay.upc.gw.domain.sys.req.SysUpdateMerchantReq;
import com.sfpay.upc.gw.domain.sys.resp.SysAddMerchantResp;
import com.sfpay.upc.gw.domain.sys.resp.SysGetMerchantDetailResp;
import com.sfpay.upc.gw.domain.sys.resp.SysUpdateMerchantResp;

public interface ISysMchService {

	/**
	 * 添加商户--到民生银行开通商户
	 * @param req
	 * @return AddMerchantResp
	 */
	SysAddMerchantResp addMerchant(SysAddMerchantReq req);

	/**
	 * 商户信息查询--到民生银行查询
	 * @param req
	 * @return GetMerchantDetailResp
	 */
	SysGetMerchantDetailResp getMerchantDetail(SysGetMerchantDetailReq req);

	/**
	 * 商户信息修改--到民生银行修改
	 * @param req
	 * @return UpdateMerchantResp
	 */
	SysUpdateMerchantResp updateMerchant(SysUpdateMerchantReq req);

}
