package com.sfpay.upc.gw.domain.sys.req;

import com.sfpay.upc.gw.domain.sys.Req;

/**
 * 
 * 类说明：<br>
 * 5.撤销订单接口：
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月2日
 */
public class SysCancelReq extends Req {

	private static final long serialVersionUID = 4754208219903089376L;

	/**
	 * 业务交易号（业务系统上送）
	 */
	private String bizTradeNo;

	public String getBizTradeNo() {
		return bizTradeNo;
	}

	public void setBizTradeNo(String bizTradeNo) {
		this.bizTradeNo = bizTradeNo;
	}
}
