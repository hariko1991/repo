package com.sfpay.upc.gw.domain.sys.req;

import com.sfpay.upc.gw.domain.sys.Req;

/**
 * 
 * 类说明：<br>
 * 6.商户修改接口：
 * 
 * <p>
 * 详细描述：<br>
 * 操作时使用商户的 encryptId 和 key， 商户审核通过前可以修改， 审核通过后则不能修改
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月2日
 */
public class SysUpdateMerchantReq extends Req {
	private static final long serialVersionUID = 9080325183649321775L;
	// 渠道编码
	private String channelCode;
	// 商户号
	private String mchNo;
	// 支付类型 ALIPAY WXPAY ALL
	private String payCode;
	// 清算模式 ONE一清 TWO二清
	private String clearMode;

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getMchNo() {
		return mchNo;
	}

	public void setMchNo(String mchNo) {
		this.mchNo = mchNo;
	}

	public String getPayCode() {
		return payCode;
	}

	public void setPayCode(String payCode) {
		this.payCode = payCode;
	}

	public String getClearMode() {
		return clearMode;
	}

	public void setClearMode(String clearMode) {
		this.clearMode = clearMode;
	}

	/**
	 * 民生银行所需要的(必需说明必需要填)
	 * email String 必须		邮件
	 * name String 必须		商户名称
	 * shortName String 不必须 	商户简称
	 * address String 必须 	地址
	 * alipayCategoryCode String 必须		 支付宝类目
	 * webchatCategoryCode String 	必须 微信类目
	 * legalPerson String 必须 法人或经办人
	 * legalPersonID String 必须 身份证
	 * firstName String 必须 联系人
	 * cellPhone String 必须 联系电话
	 * bankCode String 必须 开户行编号
	 * issuerProvince String 必须 开户行所在省
	 * issuerCity String 必须 开户行所在市
	 * isPrivate String 必须 对公或对私 传 t 或 f
	 * holderName String 必须 开户人姓名
	 * idCard String 必须 开户人身份证号
	 * accountNumber String 必须 银行卡号
	 * alipayFee Double 必须 支付宝交易手续费率，不能小于本代理商成本费率 例如 0.6%时传 0.6
	 * wechatFee Double 必须 微信交易手续费率，不能小于本代理商成本费率 例如 0.6%时传 0.6
	 * bizLicenseCode String 必须 营业执照号
	 * legalPersonID1ImageId String 不必须 法人身份证照片正面 使用图片上传返回的imageId
	 * legalPersonID2ImageId String 不必须 法人身份证照片反面 使用图片上传返回的imageId
	 * bizLicenseImageId String 不必须 营业执照照片 使用图片上传返回的 imageId
	 * bizPlaceSnapshot1ImageId String 不必须 营业场所照片 1 使用图片上传返回的 imageId
	 * bizPlaceSnapshot2ImageId String 不必须 营业场所照片 2 或非法人结算卡授权书使用图片上传返回的 imageId
	 * bizPlaceSnapshot3ImageId String 不必须 营业场所照片 3 或商户协议 使用图片上传返回的 imageId
	 * parentMid String 不必须 使用该商户的交易参数进行交易
	 * otherCertImageId String 不必须 银行卡结算账户照片 使用图片上传返回的imageId
	 */

	/**
	 * 微众银行所需要的(否说明不必须)
	 * 商户法人证件类型 idType String 2   否 	商户法人的证件类型（如：身份证，军人军官证)，请参考数据字典
	 * 商户法人证件号码 idNo String 20  否 	商户法人证件号码
	 * 商户名称 merchantName String 32  是
	 * 法人代表 legalRepresent String 20  否
	 * 营业执照编号 licenceNo String 20  是
	 * 联系人姓名 contactName String 20  否
	 * 联系人电话 contactPhoneNo String 11  否 格式：13912341234
	 * 添加商户类别码 merchantTypeCodeString 4 是 MCC 类别码，请参考数据字典
	 * 商户性质 merchantNature String 1  否 1： 国有企业2：三资企业3：集体企业4：私营企业
	 * 类目 categoryId String 64 是 支付宝对应支付宝类目微信对应微信类目
	 * 商户银行帐号 accountNo String 30  是
	 * 账户开户行号 accountOpbankNo String 12 是
	 * 开户户名 accountName String 14  是
	 * 开户行 accountOpbank String 30  是
	 * 开户支行 accountSubbranchOpbank String 64  否
	 * 开户地址 accountOpbankAddr String 64  否
	 * 账户类型 acctType String 2 是 账户类型：01：对公02：对私
	 * 回佣费率 commissionRate Decimal(5,2) 5  是 回拥费率 代表千分之六）
	 * 客服电话 servicePhone String 64 否
	 * 备注信息 memo String 512 否
	 * 扩展信息 externalInfo String 512 否
	 * 地区号（如深圳：0755） district String 16 否
	 */

}
