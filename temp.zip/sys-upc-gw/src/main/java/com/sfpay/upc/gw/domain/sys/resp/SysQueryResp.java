package com.sfpay.upc.gw.domain.sys.resp;

import com.sfpay.upc.gw.domain.sys.Resp;

/**
 * 
 * 类说明：<br>
 * 4.查询订单状态接口：
 * 
 * <p>
 * 详细描述：<br>
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月2日
 */
public class SysQueryResp extends Resp {

	private static final long serialVersionUID = -4511547298324164082L;

	/**
	 * 业务交易号（业务系统上送）
	 */
	private String bizTradeNo;
	
	/**
	 * 渠道支付号（UPC 返回的 payNo）
	 */
	private String payNo;
	
	/**
	 * 通道编码（如：CMBC , WE）
	 */
	private String channelCode;
	
	/**
	 * 通道名称（如：民生银行 , 微众银行）
	 */
	private String channelName;
	
	/**
	 * 备付金账号
	 */
	private String provAcctNo;
	
	/**
	 * 备付金银行名称
	 */
	private String provAcctName;
	
	/**
	 * 备付金银行编码
	 */
	private String provBankCode;
	
	/**
	 * 备付金银行名称
	 */
	private String provBankName;
	
	/**
	 * 渠道号 (微信或者支付宝的流水号)
	 */
	private String channelNo;
	
	/**
	 * 银行返回流水号 (微众或者民生的流水号)
	 */
	private String rtnOrderNo;

	/**
	 * 交易类型（PAY、支付，PAY_REFUND、退款 ）
	 */
	private String tradeType;

	public String getBizTradeNo() {
		return bizTradeNo;
	}

	public void setBizTradeNo(String bizTradeNo) {
		this.bizTradeNo = bizTradeNo;
	}

	public String getPayNo() {
		return payNo;
	}

	public void setPayNo(String payNo) {
		this.payNo = payNo;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public String getProvAcctName() {
		return provAcctName;
	}

	public void setProvAcctName(String provAcctName) {
		this.provAcctName = provAcctName;
	}

	public String getProvBankCode() {
		return provBankCode;
	}

	public void setProvBankCode(String provBankCode) {
		this.provBankCode = provBankCode;
	}

	public String getProvAcctNo() {
		return provAcctNo;
	}

	public void setProvAcctNo(String provAcctNo) {
		this.provAcctNo = provAcctNo;
	}

	public String getChannelNo() {
		return channelNo;
	}

	public void setChannelNo(String channelNo) {
		this.channelNo = channelNo;
	}

	public String getRtnOrderNo() {
		return rtnOrderNo;
	}

	public void setRtnOrderNo(String rtnOrderNo) {
		this.rtnOrderNo = rtnOrderNo;
	}

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

	public String getProvBankName() {
		return provBankName;
	}

	public void setProvBankName(String provBankName) {
		this.provBankName = provBankName;
	}
	
}
