package com.sfpay.upc.gw.domain.sys.req;

import com.sfpay.upc.gw.domain.sys.Req;

/**
 * 
 * 类说明：<br>
 * 10.一码付预下单接口：
 * 
 * <p>
 * 详细描述：<br>
 * 由于该接口需要配置微信二维码回调地址， 所需要在生产环境进行调试测试
 * 生产请求地址： https://test.njcmbc.com/oss-transaction/gateway/jsprecreate
 * 测试参数请联系对接调试人员
 * 
 * 通知结果：
 * 异步通知已 post 方式发送
 * 参数为 bizOrderNumber， completedTime， mid， srcAmt， sign
 * Sign=md5("bizOrderNumber=bizOrderNumber&completedTime=completedTime&mid=mid&srcA
 * mt=srcAmt&key=key","utf-8")
 * 通知时间为每个 10 分通知 1 次共 5 次， 后每 30 分通知一次， 共 10 次， 后每 1 小时通知一
 * 次， 共 10 次
 * 通知地址返回 success 字符串后后不再通知
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月2日
 */
public class SysBarcodeReq extends Req {
	private static final long serialVersionUID = 5989105866560596671L;
	public static final String YES_FALG = "Y";
	public static final String NO_FALG = "N";
	/**
	 * 必需 商户号
	 */
	private String mchNo;
	
	/**
	 * 渠道编码（如:WX_JS 等）
	 */
	private String channelCode;
	
	/**
	 * 必需 从哪里发起交易 
	 * WXPAY ALIPAY ALL
	 */
	private String payCode;
	/**
	 * 必须  系统来源
	 */
	private String systemSource;
	/**
	 * 必须 顺手付商户订单号
	 */
	private String mchOrderNo;
	/**
	 * 必须 业务流水号
	 */
	private String bizTradeNo;
	/**
	 * 支付授权码 authCode String 32 是 通过扫码枪/声波获取设备获取
	 */
	private String authCode;
	/**
	 * 必须 金额 单位分
	 */
	private Long srcAmt;
	/**
	 * 是否要发票 默认为N
	 */
	private String receipt = "N";
	/**
	 * 不必需  微信
	 */
	private String subAppid;
	/**
	 * 不必需 支付宝
	 */
	private String userId;

	public String getMchNo() {
		return mchNo;
	}

	public void setMchNo(String mchNo) {
		this.mchNo = mchNo;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getPayCode() {
		return payCode;
	}

	public void setPayCode(String payCode) {
		this.payCode = payCode;
	}

	public String getSystemSource() {
		return systemSource;
	}

	public void setSystemSource(String systemSource) {
		this.systemSource = systemSource;
	}

	public String getMchOrderNo() {
		return mchOrderNo;
	}

	public void setMchOrderNo(String mchOrderNo) {
		this.mchOrderNo = mchOrderNo;
	}

	public String getBizTradeNo() {
		return bizTradeNo;
	}

	public void setBizTradeNo(String bizTradeNo) {
		this.bizTradeNo = bizTradeNo;
	}

	public Long getSrcAmt() {
		return srcAmt;
	}

	public void setSrcAmt(Long srcAmt) {
		this.srcAmt = srcAmt;
	}

	public String getReceipt() {
		return receipt;
	}

	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

	public String getAuthCode() {
		return authCode;
	}

	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}

	public String getSubAppid() {
		return subAppid;
	}

	public void setSubAppid(String subAppid) {
		this.subAppid = subAppid;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	/**
	 * 微众银行特殊字段
	 * 订单标题 subject String 127 是 支付宝渠道：显示在用户app 上的订单信息微信渠道： 对应 body 字段
	 * 订单描述 desc String 127  否  对订单的描述
	 * 商户操作员编号 operatorId String 28 否 如员工编号
	 * 商户门店编号 storeId String 32 否 商户的门店编号
	 * 商户机具终端编号 terminalId String 8 否 商户的机具终端编号默认添加 WEB
	 * 商品标记 goodsTag String 32 否 微信渠道可选上送，代金券或立减优惠功能参数，对应微信的 goods_tag 字段支付宝目前用不到该参数。
	 * 支 付 有 效 时间 expireTime String 14 否 指定订单的支付有效时间（分钟数），超过有效时间用户将无法支付。若不指定该参数则系统默认设置 24 小时支付有效时间。参数允许设置范围： 1-1440 区间的整数值，超过 1440 默认设置1440支付宝：用户扫码后开始计算支付有效时间微信：用户下单后开始计算支付有效时间
	 * 附加信息 attach String 127 否 在查询 API 和支付通知中原样返回，该字段主要用于商户携带订单的自定义数据
	 */

}
