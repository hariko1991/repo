package com.sfpay.upc.gw.domain.sys.req;

import com.sfpay.upc.gw.domain.sys.Req;

/**
 * 
 * 类说明：<br>
 * 6.退款接口：
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月2日
 */
public class SysRefundReq extends Req {

	private static final long serialVersionUID = -8868446106295703367L;

	/**
	 * 退款商户订单号（可空，upc会自动生成一个）
	 */
	private String refundMchOrderNo;

	/**
	 * 退款金额
	 */
	private Long refundAmt;

	/**
	 * 原商户订单号
	 */
	private String mchOrderNo;

	/**
	 * 上游业务系统退款交易号
	 */
	private String refundBizTradeNo;

	/**
	 * 上游业务系统原支付交易号
	 */
	private String bizTradeNo;

	/**
	 * upc请求银行的交易号（只用于清算系统，非空，其他，可空）
	 */
	private String channelTradeNo;

	/**
	 * 来源上游业务系统
	 *   true:来源业务系统
	 *   false:来源清算系统
	 */
	private boolean sourceBizSystem = Boolean.TRUE;

	public String getRefundMchOrderNo() {
		return refundMchOrderNo;
	}

	public void setRefundMchOrderNo(String refundMchOrderNo) {
		this.refundMchOrderNo = refundMchOrderNo;
	}

	public Long getRefundAmt() {
		return refundAmt;
	}

	public void setRefundAmt(Long refundAmt) {
		this.refundAmt = refundAmt;
	}

	public String getMchOrderNo() {
		return mchOrderNo;
	}

	public void setMchOrderNo(String mchOrderNo) {
		this.mchOrderNo = mchOrderNo;
	}

	public String getRefundBizTradeNo() {
		return refundBizTradeNo;
	}

	public void setRefundBizTradeNo(String refundBizTradeNo) {
		this.refundBizTradeNo = refundBizTradeNo;
	}

	public String getBizTradeNo() {
		return bizTradeNo;
	}

	public void setBizTradeNo(String bizTradeNo) {
		this.bizTradeNo = bizTradeNo;
	}

	public String getChannelTradeNo() {
		return channelTradeNo;
	}

	public void setChannelTradeNo(String channelTradeNo) {
		this.channelTradeNo = channelTradeNo;
	}

	public boolean isSourceBizSystem() {
		return sourceBizSystem;
	}

	public void setSourceBizSystem(boolean sourceBizSystem) {
		this.sourceBizSystem = sourceBizSystem;
	}

	/**
	 *  民生银行退款业务所需要的(必需说明必需要填)
	 *  属性名（KEY）                                                                     类型                     是否必传               描述
	 *  merchantInput                String   不必须                    设备号
	 *  
	 */

	/**
	 *  微众银行退款业务所需要的(必需说明必需要填)
	 *  属性名（KEY）                                                                     类型                     是否必传               描述
	 *  refundReason                 String   不必须                   退款原因说明
	 *  operatorId                   String   不必须                   如员工编号
	 *  storeId                      String   不必须                   商户的门店编号 商户的门店编号
	 *  terminalId                   String   不必须                   商户的机具终端编号
	 *  
	 */
}
