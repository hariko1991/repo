/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.upc.gw.domain.sys.req;

import com.sfpay.upc.gw.domain.sys.Req;

/**
 * 类说明：<br>
 * 结果通知
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月2日
 */
public class SysNotifyReq extends Req {

	private static final long serialVersionUID = -3836024484231296452L;
	
	/**
	 * 通道编码（如：CMBC , WE）
	 */
	private String channelCode;
	
	/**
	 * 通道名称（如：民生银行 , 微众银行）
	 */
	private String channelName;
	
	/**
	 * 商户号
	 */
	private String mchNo;
	
	/**
	 * 顺手付商户订单号
	 */
	private String mchOrderNo;
	
	/**
	 * 支付订单号(UPC支付号)
	 */
	private String payNo;
	
	/**
	 * 业务流水号（业务系统唯一交易号）
	 */
	private String bizTradeNo;
	
	/**
	 * 银行返回流水号 (微众或者民生的流水号)
	 */
	private String rtnOrderNo;
	
	/**
	 * 通道订单号（请求第三方订单号，如：民生，微众等）
	 */
	private String channelNo;
	
	/**
	 * 备付金账号
	 */
	private String provAcctNo;
	
	/**
	 * 备付金账户名称
	 */
	private String provAcctName;
	
	/**
	 * 备付金银行编码
	 */
	private String provBankCode;
	
	/**
	 * 备付金银行名称
	 */
	private String provBankName;
	
	/**
	 * 交易类型（PAY、支付，PAY_REFUND、退款 ）
	 */
	private String tradeType;
	
	/**
	 * 订单状态
	 */
	private String status;
	/**
	 * 返回码
	 */
	private String rtnCode;
	/**
	 * 返回信息
	 */
	private String rtnMsg;
	public String getChannelCode() {
		return channelCode;
	}
	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}
	public String getChannelName() {
		return channelName;
	}
	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}
	public String getMchNo() {
		return mchNo;
	}
	public void setMchNo(String mchNo) {
		this.mchNo = mchNo;
	}
	public String getMchOrderNo() {
		return mchOrderNo;
	}
	public void setMchOrderNo(String mchOrderNo) {
		this.mchOrderNo = mchOrderNo;
	}
	public String getPayNo() {
		return payNo;
	}
	public void setPayNo(String payNo) {
		this.payNo = payNo;
	}
	public String getBizTradeNo() {
		return bizTradeNo;
	}
	public void setBizTradeNo(String bizTradeNo) {
		this.bizTradeNo = bizTradeNo;
	}

	public String getRtnOrderNo() {
		return rtnOrderNo;
	}
	public void setRtnOrderNo(String rtnOrderNo) {
		this.rtnOrderNo = rtnOrderNo;
	}
	public String getChannelNo() {
		return channelNo;
	}
	public void setChannelNo(String channelNo) {
		this.channelNo = channelNo;
	}
	public String getProvAcctName() {
		return provAcctName;
	}
	public void setProvAcctName(String provAcctName) {
		this.provAcctName = provAcctName;
	}
	public String getProvBankCode() {
		return provBankCode;
	}
	public void setProvBankCode(String provBankCode) {
		this.provBankCode = provBankCode;
	}
	public String getProvAcctNo() {
		return provAcctNo;
	}
	public void setProvAcctNo(String provAcctNo) {
		this.provAcctNo = provAcctNo;
	}
	public String getTradeType() {
		return tradeType;
	}
	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getRtnCode() {
		return rtnCode;
	}
	public void setRtnCode(String rtnCode) {
		this.rtnCode = rtnCode;
	}
	public String getRtnMsg() {
		return rtnMsg;
	}
	public void setRtnMsg(String rtnMsg) {
		this.rtnMsg = rtnMsg;
	}
	public String getProvBankName() {
		return provBankName;
	}
	public void setProvBankName(String provBankName) {
		this.provBankName = provBankName;
	}
}
