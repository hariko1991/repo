package com.sfpay.upc.gw.domain.sys.resp;

import java.util.ArrayList;
import java.util.List;

import com.sfpay.upc.gw.domain.sys.Resp;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01107265
 * 
 * CreateDate: 2017年5月2日
 */
public class ManualNotifyResp extends Resp {
	private static final long serialVersionUID = -5710959228657926193L;
	
	private String message;

	private List<String> noHandleList = new ArrayList<String>();
	
	private List<String> successList = new ArrayList<String>();
	
	private List<String> failedList = new ArrayList<String>();
	
	public ManualNotifyResp() {
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public List<String> getSuccessList() {
		return successList;
	}

	public void setSuccessList(List<String> successList) {
		this.successList = successList;
	}

	public List<String> getFailedList() {
		return failedList;
	}

	public void setFailedList(List<String> failedList) {
		this.failedList = failedList;
	}

	public List<String> getNoHandleList() {
		return noHandleList;
	}

	public void setNoHandleList(List<String> noHandleList) {
		this.noHandleList = noHandleList;
	}
}
