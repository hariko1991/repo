package com.sfpay.alipay.domain;

import com.alipay.api.AlipayResponse;
import com.alipay.api.internal.mapping.ApiField;

/**
 * ALIPAY API: alipay.trade.query response.
 * 
 * @author auto create
 * @since 1.0, 2015-12-04 21:45:51
 */
public class AlipayBuyerInfoResponse extends AlipayResponse {

	private static final long serialVersionUID = 2225387452523525464L;

	/**
	 * 商家订单号
	 */
	@ApiField("user_id")
	private String buyerId;

	/**
	 * 用户状态（Q/T/B/W）。 
		Q代表快速注册用户 
		T代表已认证用户 
		B代表被冻结账户 
		W代表已注册，未激活的账户
	 */
	@ApiField("user_status")
	private String userStatus;

	@ApiField("province")
	private String province;
	
	@ApiField("city")
	private String city;
	
	@ApiField("nick_name")
	private String nickName;

	public String getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getNickName() {
		return nickName;
	}

	public void setNickName(String nickName) {
		this.nickName = nickName;
	}
	
	
}
