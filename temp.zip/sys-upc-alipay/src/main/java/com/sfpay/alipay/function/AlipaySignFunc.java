package com.sfpay.alipay.function;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.alipay.sign.RSA;
import com.sfpay.alipay.util.AlipayFunction;

public class AlipaySignFunc {
	private static final Logger logger = LoggerFactory.getLogger(AlipaySignFunc.class);

	/**
	 * 生成签名结果
	 * 
	 * @param sPara
	 *            要签名的数组
	 * @param privateKey
	 * @return 签名结果字符串
	 */
	public static String buildRequestMysign(Map<String, String> sPara, String privateKey) {
		String prestr = AlipayFunction.createLinkString(sPara); // 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
		String mysign = RSA.sign(prestr, privateKey, AlipayBase.input_charset);
		return mysign;
	}

	/**
	 * 生成要请求给支付宝的参数数组
	 * 
	 * @param sParaTemp
	 *            请求前的参数数组
	 * @param privateKey
	 *            私钥
	 * @return 要请求的参数数组
	 */
	public static Map<String, String> buildRequestPara(Map<String, String> sParaTemp, String privateKey) {
		// 除去数组中的空值和签名参数
		Map<String, String> sPara = AlipayFunction.paraFilter(sParaTemp);
		// 生成签名结果
		String mysign = buildRequestMysign(sPara, privateKey);

		// 签名结果与签名方式加入请求提交参数组中
		sPara.put("sign", mysign);
		sPara.put("sign_type", AlipayBase.sign_type);

		return sPara;
	}

	/**
	 * 生成要请求给支付宝app支付所需数据
	 * 
	 * @param sParaTemp
	 *            请求前的参数数组
	 * @param privateKey
	 *            私钥
	 * @return 要请求的参数数组
	 */
	public static String buildAlipayAppRequestPara(Map<String, String> sParaTemp, String privateKey) {
		// 除去数组中的空值和签名参数
		Map<String, String> sPara = AlipayFunction.paraFilter(sParaTemp);
		// 把数组所有元素，按照“参数=参数值”的模式用“&”字符拼接成字符串
		String prestr = AlipayFunction.createLinkStringWithFH(sPara);
		String mysign = RSA.sign(prestr, privateKey, AlipayBase.input_charset);
		try {
			mysign = URLEncoder.encode(mysign, AlipayBase.input_charset);
		} catch (UnsupportedEncodingException e) {
			logger.error("encode 签名异常", e);
		}
		String result = prestr + "&sign=\"" + mysign + "\"&sign_type=\"RSA\"";

		return result;
	}

}
