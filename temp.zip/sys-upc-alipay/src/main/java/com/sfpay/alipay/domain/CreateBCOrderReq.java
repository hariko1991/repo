package com.sfpay.alipay.domain;

import org.apache.commons.lang.StringUtils;

import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：<br>
 * 支付宝扫码支付下单
 * 
 * </p>
 * 
 * @author 844193 项定友 CreateDate: 2016-4-18
 */
public class CreateBCOrderReq extends BaseReq {

	private static final long serialVersionUID = 5974978544436522454L;
	// 第三方唯一订单号
	private String outTradeNo;
	// 交易金额
	private Long totalAmount;
	// 订单标题
	private String subject;
	// 过期时间
	private String expireTime;
	
	//支付宝扫码支付 对应的场景码:bar_code(默认,扫码支付 ),wave_code:声波支付 
	private String scene = "bar_code";
	
	//支付宝支付的授权码.
	private String authCode;

	public String getOutTradeNo() {
		return outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	public Long getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Long totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getExpireTime() {
		return expireTime;
	}

	public void setExpireTime(String expireTime) {
		this.expireTime = expireTime;
	}

	
	public String getScene() {
		return scene;
	}

	public void setScene(String scene) {
		this.scene = scene;
	}

	public String getAuthCode() {
		return authCode;
	}

	public void setAuthCode(String authCode) {
		this.authCode = authCode;
	}

	@Override
	public void checkArguments() {
		super.checkArguments();
		if (StringUtils.isEmpty(getOutTradeNo())) {
			throw new ServiceException("商户订单号不能为空");
		}
		if (getTotalAmount() == null) {
			throw new ServiceException("金额不能为空");
		}
		if (StringUtils.isEmpty(getSubject())) {
			throw new ServiceException("订单标题不能为空");
		}
		
		if (StringUtils.isEmpty(getAuthCode())) {
			throw new ServiceException("支付授权码为空");
		}
		if (StringUtils.isEmpty(getScene())) {
			throw new ServiceException("场景码不能为空");
		}
	}
	
	
}
