package com.sfpay.alipay.function;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alipay.api.AlipayClient;
import com.sfpay.alipay.util.AlipayClientExt;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.enums.ChannelTradeType;

/**
 * 
 * 类说明：<br>
 * 
 * 调用支付宝基础类
 * <p>
 * 详细描述：<br>
 * 
 * @author dumengchao(896728)
 * @date 2016-6-13
 */
public class AlipayBase {

	private final static Logger logger = LoggerFactory.getLogger(AlipayBase.class);
	// 签名方式
	public static String sign_type = "RSA";

	// 字符编码格式 目前支持utf-8
	public static String input_charset = "utf-8";
	// 支付类型 ，无需修改
	public static String payment_type = "1";
	// 执行重试次数
	public static int RETRY_TIMES = 3;

	/**
	 * 获取私钥
	 * 
	 * @param channelArgs
	 * @return
	 */
	public static String getPrivateKey(ChannelArgs channelArgs) {
		String privateKey = channelArgs.getValueByKey("mch_private_key_new");
		return privateKey;
	}

	/**
	 * 获取支付宝公钥
	 * 
	 * @param channelArgs
	 * 
	 * @return
	 */
	public static String getAlipayPubKey(String channelCode, ChannelArgs channelArgs) {
		if (ChannelTradeType.ALIPAY_APP.name().equals(channelCode)
				|| ChannelTradeType.ALIPAY_WAP.name().equals(channelCode)) {
			return channelArgs.getValueByKey("alipay_cor_key");
		} else {
			return channelArgs.getValueByKey("alipay_unify_key");
		}
	}

	/**
	 * 获取支付宝公钥
	 * 
	 * @param channelArgs
	 * 
	 * @return
	 */
	public static String getAlipayUnifyPubKey(ChannelArgs channelArgs) {
		return channelArgs.getValueByKey("alipay_unify_key");
	}

	/**
	 * 获取支付宝网关
	 * 
	 * @return
	 */
	protected static String getAlipayGateWay() {
		return Property.getProperty("ALIPAY_OPEN_API_DOMAIN");
	}

	protected static AlipayClient getAplipayClient(String channelCode, ChannelArgs channelArgs) {
		String privateKey = getPrivateKey(channelArgs);
		if (StringUtils.isBlank(privateKey)) {
			logger.info("please configure merchant privatekey in constants.properties mch:[{}]",
					channelArgs.getValueByKey("mch_id"));
		}
		String publicKey = getAlipayUnifyPubKey(channelArgs);
		if (StringUtils.isBlank(publicKey)) {
			logger.info("please configure merchant publicKey in constants.properties",
					channelArgs.getValueByKey("mch_id"));
		}

		AlipayClient alipayClient = new AlipayClientExt(getAlipayGateWay(), channelArgs.getValueByKey("app_id"),
				privateKey, "json", "utf-8", publicKey);
		return alipayClient;
	}
	
	protected static AlipayClient getAplipayClientBySfpay(String appId,String privateKey,String publicKey) {
		AlipayClient alipayClient = new AlipayClientExt(getAlipayGateWay(), appId,
				privateKey, "json", "utf-8", publicKey);
		return alipayClient;
	}
}
