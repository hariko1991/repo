package com.sfpay.alipay.domain;

import org.apache.commons.lang.StringUtils;

import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：<br>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-11
 */
public class RevokeReq extends BaseReq {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// 商户订单号
	private String outTradeNo;
	// 商户退款订单号
	private String outRefundNo;
	// 退款金额（分）
	private Long refundFee;

	public String getOutTradeNo() {
		return outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	public String getOutRefundNo() {
		return outRefundNo;
	}

	public void setOutRefundNo(String outRefundNo) {
		this.outRefundNo = outRefundNo;
	}

	public Long getRefundFee() {
		return refundFee;
	}

	public void setRefundFee(Long refundFee) {
		this.refundFee = refundFee;
	}

	@Override
	public void checkArguments() {
		super.checkArguments();
		if (StringUtils.isEmpty(getOutTradeNo())) {
			throw new ServiceException("第三方唯一订单号或微信订单号不能同时为空");
		}
		if (StringUtils.isEmpty(getOutRefundNo())) {
			throw new ServiceException("第三方退款订单号不能为空");
		}
		if (getRefundFee() <= 0) {
			throw new ServiceException("退款金额不合法，请输入大于0的金额");
		}
	}

}
