package com.sfpay.alipay.domain;


/**
 * 
 * 类说明：<br>
 * 微信订单查询响应数据
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-18
 */
public class OrderQueryResp extends BaseResp {

	private static final long serialVersionUID = -175842089869591731L;

	/**
	 * 设备号
	 */
	private String deviceInfo;
	/**
	 * 微信用户唯一标识
	 */
	private String openid;
	/**
	 * 是否关注 Y/N
	 */
	private String isSubscribe;
	/**
	 * 交易类型
	 */
	private String tradeType;
	/**
	 * 交易状态SUCCESS—支付成功 REFUND—转入退款 NOTPAY—未支付 CLOSED—已关闭 REVOKED—已撤销（刷卡支付）
	 * USERPAYING--用户支付中 PAYERROR--支付失败(其他原因，如银行返回失败)
	 */
	private String tradeState;
	/**
	 * 银行类型，采用字符串类型的银行标识
	 */
	private String bankType;
	/**
	 * 订单总金额
	 */
	private Long totalFee;
	/**
	 * 现金金额
	 */
	private Long cashFee;

	/**
	 * 微信支付订单号
	 */
	private String wxOrderNo;
	/**
	 * 统一支付平台订单号
	 */
	private String outTradeNo;
	/**
	 * 支付完成时间
	 */
	private String timeEnd;
	/**
	 * 附件
	 */
	private String attach;

	public String getDeviceInfo() {
		return deviceInfo;
	}

	public void setDeviceInfo(String deviceInfo) {
		this.deviceInfo = deviceInfo;
	}

	public String getOpenid() {
		return openid;
	}

	public void setOpenid(String openid) {
		this.openid = openid;
	}

	public String getIsSubscribe() {
		return isSubscribe;
	}

	public void setIsSubscribe(String isSubscribe) {
		this.isSubscribe = isSubscribe;
	}

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

	public String getTradeState() {
		return tradeState;
	}

	public void setTradeState(String tradeState) {
		this.tradeState = tradeState;
	}

	public String getBankType() {
		return bankType;
	}

	public void setBankType(String bankType) {
		this.bankType = bankType;
	}

	public Long getTotalFee() {
		return totalFee;
	}

	public void setTotalFee(Long totalFee) {
		this.totalFee = totalFee;
	}

	public Long getCashFee() {
		return cashFee;
	}

	public void setCashFee(Long cashFee) {
		this.cashFee = cashFee;
	}

	public String getWxOrderNo() {
		return wxOrderNo;
	}

	public void setWxOrderNo(String wxOrderNo) {
		this.wxOrderNo = wxOrderNo;
	}

	public String getOutTradeNo() {
		return outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	public String getTimeEnd() {
		return timeEnd;
	}

	public void setTimeEnd(String timeEnd) {
		this.timeEnd = timeEnd;
	}

	public String getAttach() {
		return attach;
	}

	public void setAttach(String attach) {
		this.attach = attach;
	}

}
