package com.sfpay.alipay.enums;

import com.sfpay.upc.constant.UpcConstants;

/**
 * 
 * 类说明：<br>
 * 支付宝错误码
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke)
 */
public enum AlipayErrorCode {
	UNKNOW_ERROR("isp.unknow-error", "系统繁忙", UpcConstants.FAILURE_SYS),
	
	SYSTEM_ERROR("aop.ACQ.SYSTEM_ERROR", "系统错误", UpcConstants.FAILURE_SYS),
	
	TRADE_NOT_EXIST("ACQ.TRADE_NOT_EXIST", "交易不存在",UpcConstants.ORDER_NOT_EXISTS),
	
	TRADE_STATUS_ERROR("ACQ.TRADE_STATUS_ERROR", "交易状态不合法","UNKNOWN_ERROR"),
	
	SELLER_BALANCE_NOT_ENOUGH("ACQ.SELLER_BALANCE_NOT_ENOUGH", "卖家余额不足","UNKNOWN_ERROR"),
	
	REASON_TRADE_BEEN_FREEZEN("ACQ.REASON_TRADE_BEEN_FREEZEN", "请求退款的交易被冻结","UNKNOWN_ERROR"),
	
	TRADE_HAS_FINISHED("ACQ.TRADE_HAS_FINISHED", "交易已完成", UpcConstants.ORDER_IS_SUCCESS),
	
	DISCORDANT_REPEAT_REQUEST("ACQ.DISCORDANT_REPEAT_REQUEST", "检查该退款号是否已退过款","UNKNOWN_ERROR"),
	
	TRADE_HAS_SUCCESS("ACQ.TRADE_HAS_SUCCESS", "交易已被支付", UpcConstants.ORDER_IS_SUCCESS),
	
	TRADE_HAS_CLOSE("ACQ.TRADE_HAS_CLOSE", "交易已关闭", UpcConstants.ORDER_IS_CLOSED),
	
	BUYER_SELLER_EQUAL("ACQ.BUYER_SELLER_EQUAL", "买卖家不能相同","UNKNOWN_ERROR"),
	
	TRADE_BUYER_NOT_MATCH("ACQ.TRADE_BUYER_NOT_MATCH", "交易买家不匹配","UNKNOWN_ERROR"),
	
	BUYER_ENABLE_STATUS_FORBID("ACQ.BUYER_ENABLE_STATUS_FORBID", "买家状态非法","UNKNOWN_ERROR"),
	
	BUYER_PAYMENT_AMOUNT_DAY_LIMIT_ERROR("ACQ.BUYER_PAYMENT_AMOUNT_DAY_LIMIT_ERROR", "买家付款日限额超限","UNKNOWN_ERROR"),
	
	BEYOND_PAY_RESTRICTION("ACQ.BEYOND_PAY_RESTRICTION", "商户收款额度超限","UNKNOWN_ERROR"),
	
	BEYOND_PER_RECEIPT_RESTRICTION("ACQ.BEYOND_PER_RECEIPT_RESTRICTION", "商户收款金额超过月限额","UNKNOWN_ERROR"),
	
	BUYER_PAYMENT_AMOUNT_MONTH_LIMIT_ERROR("ACQ.BUYER_PAYMENT_AMOUNT_MONTH_LIMIT_ERROR", "买家付款月额度超限","UNKNOWN_ERROR"),
	
	SELLER_BEEN_BLOCKED("ACQ.SELLER_BEEN_BLOCKED", "商家账号被冻结","UNKNOWN_ERROR"),
	
	ERROR_BUYER_CERTIFY_LEVEL_LIMIT("ACQ.ERROR_BUYER_CERTIFY_LEVEL_LIMIT", "买家未通过人行认证","UNKNOWN_ERROR"),
	
	TOTAL_FEE_EXCEED("ACQ.TOTAL_FEE_EXCEED", "订单总金额超过限额","ALIPAY_TOTAL_FEE_EXCEED")
	;

	private String code;
	private String msg;
	private String upcCode;

	private AlipayErrorCode(String code, String msg, String upcCode) {
		this.code = code;
		this.msg = msg;
		this.upcCode = upcCode;
	}
	
	public String getCode() {
		return code;
	}
	
	public String getMsg() {
		return msg;
	}
	
	public String getUpcCode() {
		return upcCode;
	}

}
