package com.sfpay.alipay.util;

import java.io.IOException;
import java.security.Security;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alipay.api.AlipayApiException;
import com.alipay.api.AlipayClient;
import com.alipay.api.AlipayConstants;
import com.alipay.api.AlipayParser;
import com.alipay.api.AlipayRequest;
import com.alipay.api.AlipayResponse;
import com.alipay.api.SignItem;
import com.alipay.api.internal.parser.json.ObjectJsonParser;
import com.alipay.api.internal.parser.xml.ObjectXmlParser;
import com.alipay.api.internal.util.AlipayHashMap;
import com.alipay.api.internal.util.AlipaySignature;
import com.alipay.api.internal.util.RequestParametersHolder;
import com.alipay.api.internal.util.StringUtils;
import com.alipay.api.internal.util.WebUtils;
import com.sfpay.alipay.http.HttpService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.upc.constant.UpcConstants;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * @author dumengchao(896728)
 * @date 2016-6-14
 */
public class AlipayClientExt implements AlipayClient {
	private final static Logger logger = LoggerFactory.getLogger(AlipayClientExt.class);

	private String serverUrl;
	private String appId;
	private String privateKey;
	private String format = AlipayConstants.FORMAT_JSON;
	private String sign_type = AlipayConstants.SIGN_TYPE_RSA;
	private String alipayPublicKey;
	private String charset;

	static {
		// 清除安全设置
		Security.setProperty("jdk.certpath.disabledAlgorithms", "");
	}

	public AlipayClientExt() {
	}

	public AlipayClientExt(String serverUrl, String appId, String privateKey) {
		this.serverUrl = serverUrl;
		this.appId = appId;
		this.privateKey = privateKey;
		this.alipayPublicKey = null;
	}

	public AlipayClientExt(String serverUrl, String appId, String privateKey, String format) {
		this(serverUrl, appId, privateKey);
		this.format = format;
	}

	public AlipayClientExt(String serverUrl, String appId, String privateKey, String format, String charset) {
		this(serverUrl, appId, privateKey);
		this.format = format;
		this.charset = charset;
	}

	public AlipayClientExt(String serverUrl, String appId, String privateKey, String format, String charset,
			String alipayPulicKey) {
		this(serverUrl, appId, privateKey);
		this.format = format;
		this.charset = charset;
		this.alipayPublicKey = alipayPulicKey;
	}

	public <T extends AlipayResponse> T execute(AlipayRequest<T> request) throws AlipayApiException {
		return execute(request, null);
	}

	public <T extends AlipayResponse> T execute(AlipayRequest<T> request, String accessToken) throws AlipayApiException {

		AlipayParser<T> parser = null;
		if (AlipayConstants.FORMAT_XML.equals(this.format)) {
			parser = new ObjectXmlParser<T>(request.getResponseClass());
		} else {
			parser = new ObjectJsonParser<T>(request.getResponseClass());
		}

		return _execute(request, parser, accessToken);
	}

	private <T extends AlipayResponse> T _execute(AlipayRequest<T> request, AlipayParser<T> parser, String authToken)
			throws AlipayApiException {
		Map<String, Object> rt = doPost(request, authToken);
		if (rt == null) {
			return null;
		}
		String alipayResp = (String) rt.get("rsp");
		logger.info("支付宝响应参数:[{}]", alipayResp);
		T tRsp = null;
		try {
			
			tRsp = parser.parse(alipayResp);
			tRsp.setBody(alipayResp);

			// 针对成功结果且有支付宝公钥的进行验签
			if (!StringUtils.isEmpty(this.alipayPublicKey)) {

				SignItem signItem = parser.getSignItem(request, tRsp);

				if (signItem == null) {

					throw new AlipayApiException("sign check fail: Body is Empty!");
				}

				if (tRsp.isSuccess() || (!tRsp.isSuccess() && !StringUtils.isEmpty(signItem.getSign()))) {

					boolean rsaCheckContent = AlipaySignature.rsaCheckContent(signItem.getSignSourceDate(),
							signItem.getSign(), this.alipayPublicKey, this.charset);

					if (!rsaCheckContent) {

						// 针对JSON \/问题，替换/后再尝试做一次验证
						if (!StringUtils.isEmpty(signItem.getSignSourceDate())
								&& signItem.getSignSourceDate().contains("\\/")) {

							String srouceData = signItem.getSignSourceDate().replace("\\/", "/");

							boolean jsonCheck = AlipaySignature.rsaCheckContent(srouceData, signItem.getSign(),
									this.alipayPublicKey, this.charset);

							if (!jsonCheck) {
								throw new AlipayApiException("sign check fail: check Sign and Data Fail！JSON also！");
							}
						} else {

							throw new AlipayApiException("sign check fail: check Sign and Data Fail!");
						}
					}
				}

			}

		} catch (Exception e) {
			logger.error("请求支付宝运行时系统异常", e);
			throw new ServiceException(UpcConstants.FAILURE_SYS);
		}

		tRsp.setParams((AlipayHashMap) rt.get("textParams"));
		return tRsp;
	}

	/**
	 * 
	 * 
	 * @param request
	 * @param accessToken
	 * @return
	 * @throws AlipayApiException
	 */
	public <T extends AlipayResponse> Map<String, Object> doPost(AlipayRequest<T> request, String accessToken)
			throws AlipayApiException {
		Map<String, Object> result = new HashMap<String, Object>();
		RequestParametersHolder requestHolder = new RequestParametersHolder();
		AlipayHashMap appParams = new AlipayHashMap(request.getTextParams());
		requestHolder.setApplicationParams(appParams);

		if (StringUtils.isEmpty(charset)) {
			charset = AlipayConstants.CHARSET_UTF8;
		}

		AlipayHashMap protocalMustParams = new AlipayHashMap();
		protocalMustParams.put(AlipayConstants.METHOD, request.getApiMethodName());
		protocalMustParams.put(AlipayConstants.VERSION, request.getApiVersion());
		protocalMustParams.put(AlipayConstants.APP_ID, this.appId);
		protocalMustParams.put(AlipayConstants.SIGN_TYPE, this.sign_type);
		protocalMustParams.put(AlipayConstants.TERMINAL_TYPE, request.getTerminalType());
		protocalMustParams.put(AlipayConstants.TERMINAL_INFO, request.getTerminalInfo());
		protocalMustParams.put(AlipayConstants.NOTIFY_URL, request.getNotifyUrl());
		protocalMustParams.put(AlipayConstants.CHARSET, charset);

		Long timestamp = System.currentTimeMillis();
		DateFormat df = new SimpleDateFormat(AlipayConstants.DATE_TIME_FORMAT);
		df.setTimeZone(TimeZone.getTimeZone(AlipayConstants.DATE_TIMEZONE));
		protocalMustParams.put(AlipayConstants.TIMESTAMP, df.format(new Date(timestamp)));
		requestHolder.setProtocalMustParams(protocalMustParams);

		String signContent = AlipaySignature.getSignatureContent(requestHolder);

		protocalMustParams.put(AlipayConstants.SIGN, AlipaySignature.rsaSign(signContent, privateKey, charset));

		StringBuffer urlSb = new StringBuffer(serverUrl);
		try {
			String sysMustQuery = WebUtils.buildQuery(requestHolder.getProtocalMustParams(), charset);
			urlSb.append("?");
			urlSb.append(sysMustQuery);
		} catch (IOException e) {
			throw new AlipayApiException(e);
		}

		String resp = null;
		try {
			String content = WebUtils.buildQuery(appParams, charset);
			logger.info("请求支付宝网关url:[{}], 内容:[{}]", urlSb.toString(), content);
			resp = HttpService.getHttpProxyService().sendByPost(urlSb.toString(), content);
			logger.info("支付宝响应报文密文: [{}]", resp);
		} catch (Exception e) {
			throw new ServiceException(UpcConstants.FAILURE_SYS);
		}
		result.put("rsp", resp);
		result.put("textParams", appParams);
		result.put("protocalMustParams", protocalMustParams);
		result.put("url", urlSb.toString());
		return result;
	}
}
