package com.sfpay.alipay.domain;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public abstract class BaseResp implements java.io.Serializable {

	private static final long serialVersionUID = -6273610720427791418L;

	protected final Logger logger = LoggerFactory.getLogger(getClass());

	/**
	 * 交易状态：WAIT_BUYER_PAY（交易创建，等待买家付款）、TRADE_CLOSED（未付款交易超时关闭，或支付完成后全额退款）、
	 * TRADE_SUCCESS（交易支付成功）、TRADE_FINISHED（交易结束，不可退款）
	 */

	public static final String WAIT_BUYER_PAY = "WAIT_BUYER_PAY";
	public static final String TRADE_CLOSED = "TRADE_CLOSED";
	public static final String TRADE_SUCCESS = "TRADE_SUCCESS";
	public static final String TRADE_FINISHED = "TRADE_FINISHED";
	public static final String SUCESS_CODE = "10000";
	public static final String SUCESS_MSG = "SUCCESS";
	private String code;

	private String msg;

	private String subCode;

	private String subMsg;

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMsg() {
		return msg;
	}

	public void setMsg(String msg) {
		this.msg = msg;
	}

	public String getSubCode() {
		return subCode;
	}

	public void setSubCode(String subCode) {
		this.subCode = subCode;
	}

	public String getSubMsg() {
		return subMsg;
	}

	public void setSubMsg(String subMsg) {
		this.subMsg = subMsg;
	}

	@Override
	public String toString() {
		StringBuilder buf = new StringBuilder();
		Method[] methods = this.getClass().getMethods();
		boolean isFirst = true;
		for (int i = 0, n = methods.length; i < n; i++) {
			try {
				Method method = methods[i];
				if ((method.getModifiers() & Modifier.PUBLIC) == 1 && method.getDeclaringClass() != Object.class
						&& (method.getParameterTypes() == null || method.getParameterTypes().length == 0)) {
					String methodName = method.getName();
					String property = null;
					if (methodName.startsWith("get")) {
						property = methodName.substring(3, 4).toLowerCase() + methodName.substring(4);
					} else if (methodName.startsWith("is")) {
						property = methodName.substring(2, 3).toLowerCase() + methodName.substring(3);
					}
					if (property != null) {
						Object value = method.invoke(this, new Object[0]);
						if (isFirst)
							isFirst = false;
						else
							buf.append(",");
						buf.append(property);
						buf.append(":");
						if (value instanceof String)
							buf.append("\"");
						buf.append(value);
						if (value instanceof String)
							buf.append("\"");
					}
				}
			} catch (Exception e) {
				// ignore
			}
		}
		return "{" + buf.toString() + "}";
	}
}
