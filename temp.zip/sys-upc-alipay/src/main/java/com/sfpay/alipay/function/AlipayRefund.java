package com.sfpay.alipay.function;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alipay.api.AlipayClient;
import com.alipay.api.request.AlipayTradeRefundRequest;
import com.alipay.api.response.AlipayTradeRefundResponse;
import com.sfpay.alipay.domain.RefundReq;
import com.sfpay.alipay.enums.AlipayErrorCode;
import com.sfpay.alipay.util.AlipayUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.common.json.JSONUtils;
import com.sfpay.upc.domain.upc.ChannelArgs;

/**
 * 
 * 类说明：<br>
 * 退款
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-18
 */
public class AlipayRefund extends AlipayBase {

	private static final Logger logger = LoggerFactory.getLogger(AlipayRefund.class);

	public static AlipayTradeRefundResponse doRefund(RefundReq req, ChannelArgs channelArgs) {

		int execTimes = 1;
		AlipayTradeRefundResponse response = null;
		do {
			try {
				logger.info("发起支付宝退款请求{}", req.toString());
				AlipayClient alipayClient = getAplipayClient(req.getChannelCode(), channelArgs);
				AlipayTradeRefundRequest request = buildRefundRequest(req);
				logger.info("发起退款请求 ：{}", request.getBizContent());
				if (execTimes <= RETRY_TIMES) {
					response = alipayClient.execute(request);
				} else {
					break;
				}
			} catch (ServiceException e) {
				logger.error("系统异常 code:[{}], msg:[{}]", e.getCode(), e.getMsg());
				throw new ServiceException(e.getCode(), e.getMsg());
			} catch (Exception e) {
				logger.error(String.format("发起查询[%s]异常", req.toString()), e);
				throw new ServiceException("系统异常");
			}
			execTimes++;
		} while (AlipayErrorCode.SYSTEM_ERROR.getCode().equals(response.getSubCode()));

		return response;
	}

	private static AlipayTradeRefundRequest buildRefundRequest(RefundReq req) {
		AlipayTradeRefundRequest request = new AlipayTradeRefundRequest();

		Map<String, String> paramsMap = new HashMap<String, String>();
		paramsMap.put("out_trade_no", req.getOutTradeNo());
		paramsMap.put("refund_amount", AlipayUtil.changeF2Y(req.getRefundFee()));
		paramsMap.put("out_request_no", req.getOutRefundNo());

		request.setBizContent(JSONUtils.fromObject(paramsMap));
		return request;
	}
}
