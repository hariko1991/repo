package com.sfpay.alipay.domain;

import org.apache.commons.lang.StringUtils;

import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：<br>
 * 交易查询
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-18
 */
public class OrderQueryReq extends BaseReq {

	private static final long serialVersionUID = 5974978544436522454L;
	/**
	 * 第三方唯一订单号
	 */
	private String outTradeNo;

	public String getOutTradeNo() {
		return outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	@Override
	public void checkArguments() {
		super.checkArguments();
		if (StringUtils.isEmpty(getOutTradeNo())) {
			throw new ServiceException("商户订单号不能为空");
		}
	}
}
