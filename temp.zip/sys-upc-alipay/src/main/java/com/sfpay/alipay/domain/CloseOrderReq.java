package com.sfpay.alipay.domain;

import org.apache.commons.lang.StringUtils;

import com.sfpay.framework.base.exception.ServiceException;

public class CloseOrderReq extends BaseReq {

	private static final long serialVersionUID = 1L;
	/**
	 * 统一支付平台外部订单号
	 */
	private String outTradeNo;

	public String getOutTradeNo() {
		return outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	@Override
	public void checkArguments() {
		super.checkArguments();
		if (StringUtils.isEmpty(getOutTradeNo())) {
			throw new ServiceException("商户订单号不能为空");
		}
	}
}
