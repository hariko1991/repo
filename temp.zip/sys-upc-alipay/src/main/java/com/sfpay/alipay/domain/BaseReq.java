package com.sfpay.alipay.domain;

import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.Map;

import org.apache.commons.lang.StringUtils;

import com.sfpay.framework.base.exception.ServiceException;

public abstract class BaseReq implements java.io.Serializable {

	private static final long serialVersionUID = 5950592134111942023L;

	// 支付宝分配给开发者的应用ID
	private String appId;
	// 接口名称
	private String method;
	// 请求使用的编码格式
	private String charset = "utf-8";
	// 签名类型
	private String signType = "RSA";
	// 签名
	private String sign;
	// 发送请求时间
	private String timestamp;
	// 版本
	private String version = "1.0";
	// 通知url
	private String notifyUrl;
	// 渠道编码
	private String channelCode;
	// 请求参数
	private Map<String, String> reqParams;

	public String getAppId() {
		return appId;
	}

	public void setAppId(String appId) {
		this.appId = appId;
	}

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}

	public String getCharset() {
		return charset;
	}

	public void setCharset(String charset) {
		this.charset = charset;
	}

	public String getSignType() {
		return signType;
	}

	public void setSignType(String signType) {
		this.signType = signType;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public Map<String, String> getReqParams() {
		return reqParams;
	}

	public void setReqParams(Map<String, String> reqParams) {
		this.reqParams = reqParams;
	}

	public String getNotifyUrl() {
		return notifyUrl;
	}

	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}

	/**
	 * 检测参数合法性 方法说明：<br>
	 * 
	 */
	public void checkArguments() {
		if (StringUtils.isEmpty(getAppId())) {
			throw new ServiceException("商户id(appId)不能为空");
		}
		if (StringUtils.isEmpty(getMethod())) {
			throw new ServiceException("接口方法名不能为空");
		}
		if (StringUtils.isEmpty(getCharset())) {
			throw new ServiceException("字符编码不能为空");
		}
		if (StringUtils.isEmpty(getSignType())) {
			throw new ServiceException("签名类型不能为空");
		}
		if (StringUtils.isEmpty(getSign())) {
			throw new ServiceException("签名(sign)不能为空");
		}
		if (StringUtils.isEmpty(getTimestamp())) {
			throw new ServiceException("请求时间不能为空");
		}
		if (StringUtils.isEmpty(getVersion())) {
			throw new ServiceException("版本号不能为空");
		}
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	@Override
	public String toString() {
		StringBuilder buf = new StringBuilder();
		Method[] methods = this.getClass().getMethods();
		boolean isFirst = true;
		for (int i = 0, n = methods.length; i < n; i++) {
			try {
				Method method = methods[i];
				if ((method.getModifiers() & Modifier.PUBLIC) == 1 && method.getDeclaringClass() != Object.class
						&& (method.getParameterTypes() == null || method.getParameterTypes().length == 0)) {
					String methodName = method.getName();
					String property = null;
					if (methodName.startsWith("get")) {
						property = methodName.substring(3, 4).toLowerCase() + methodName.substring(4);
					} else if (methodName.startsWith("is")) {
						property = methodName.substring(2, 3).toLowerCase() + methodName.substring(3);
					}
					if (property != null) {
						Object value = method.invoke(this, new Object[0]);
						if (isFirst)
							isFirst = false;
						else
							buf.append(",");
						buf.append(property);
						buf.append(":");
						if (value instanceof String)
							buf.append("\"");
						buf.append(value);
						if (value instanceof String)
							buf.append("\"");
					}
				}
			} catch (Exception e) {
				// ignore
			}
		}
		return "{" + buf.toString() + "}";
	}

}
