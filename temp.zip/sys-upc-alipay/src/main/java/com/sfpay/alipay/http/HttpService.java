package com.sfpay.alipay.http;

import com.sfpay.upc.service.IHttpProxyService;

/**
 * 
 * 类说明：<br>
 * http服务
 * 
 * <p>
 * 详细描述：<br>
 * @author dumengchao(896728)
 * @date 2016-6-16
 */
public class HttpService {

	public static IHttpProxyService httpProxyService;

	public static void setHttpProxyService(IHttpProxyService httpProxyService) {
		HttpService.httpProxyService = httpProxyService;
	}
	
	public static IHttpProxyService getHttpProxyService() {
		return httpProxyService;
	}
}
