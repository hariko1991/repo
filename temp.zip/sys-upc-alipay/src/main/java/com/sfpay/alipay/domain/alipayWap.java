package com.sfpay.alipay.domain;

/**
 * 手机网站支付实体
 * 命名和支付宝保持一致
 * 具体参考网页：
 * https://doc.open.alipay.com/doc2/detail.htm?spm=a219a.7629140.0.0.A8i2ci&treeId=60&articleId=104790&docType=1
 * @author 846306
 *
 */
public class alipayWap extends alipayBase{
	
	/**
	 * 页面跳转同步通知页面路径
	 */
	private String return_url;
	
	
	/**
	 * 商户网站唯一订单号
	 */
	private String out_trade_no;
	
	/**
	 * 商品名称
	 */
	private String subject;
	
	
	/**
	 * 交易金额
	 */
	private String total_fee;
	
	
	/**
	 * 卖家支付宝账号对应的支付宝唯一用户号。
	 * 以2088开头的纯16位数字
	 */
	private String seller_id;
	
	/**
	 * 支付类型。仅支持：1（商品购买）。
	 */
	private String payment_type;
	
	
	/**
	 * 商品展示url
	 */
	private String show_url;
	
	
	/**
	 * 商品描述 可空
	 */
	private String body;
	
	
	/**
	 *超时时间 
	 */
	private String it_b_pay;
	
	/**
	 * 接入极简版wap收银台时支持。
	 * 当商户请求是来自支付宝钱包，在支付宝钱包登录后，
	 * 有生成登录信息token时，使用该参数传入token将可以实现信任登录收银台，不需要再次登录
	 */
	private String extern_token;
	
	/**
	 * 航旅订单其它费用
	 */
	private Long otherfee;
	
	
	/**
	 * 航旅订单金额
	 */
	private String airticket;
	
	/**
	 * 是否发起实名校验
	 * T：发起实名校验；
	 * F：不发起实名校验。
	 */
	private String rn_check;
	
	
	/**
	 * 买家证件号码
	 */
	private String buyer_cert_no;
	
	/**
	 * 买家真实姓名
	 */
	private String buyer_real_name;
	
	/**
	 * 收单场景
	 */
	private String scene;
	
	
	/**
	 * 商品类型
	 * 1：实物类商品
	 * 0：虚拟类商品
	 */
	private String goods_type;


	public String getReturn_url() {
		return return_url;
	}


	public void setReturn_url(String return_url) {
		this.return_url = return_url;
	}


	public String getOut_trade_no() {
		return out_trade_no;
	}


	public void setOut_trade_no(String out_trade_no) {
		this.out_trade_no = out_trade_no;
	}


	public String getSubject() {
		return subject;
	}


	public void setSubject(String subject) {
		this.subject = subject;
	}


	public String getTotal_fee() {
		return total_fee;
	}


	public void setTotal_fee(String total_fee) {
		this.total_fee = total_fee;
	}


	public String getSeller_id() {
		return seller_id;
	}


	public void setSeller_id(String seller_id) {
		this.seller_id = seller_id;
	}


	public String getPayment_type() {
		return payment_type;
	}


	public void setPayment_type(String payment_type) {
		this.payment_type = payment_type;
	}


	public String getShow_url() {
		return show_url;
	}


	public void setShow_url(String show_url) {
		this.show_url = show_url;
	}


	public String getBody() {
		return body;
	}


	public void setBody(String body) {
		this.body = body;
	}


	public String getIt_b_pay() {
		return it_b_pay;
	}


	public void setIt_b_pay(String it_b_pay) {
		this.it_b_pay = it_b_pay;
	}


	public String getExtern_token() {
		return extern_token;
	}


	public void setExtern_token(String extern_token) {
		this.extern_token = extern_token;
	}


	public Long getOtherfee() {
		return otherfee;
	}


	public void setOtherfee(Long otherfee) {
		this.otherfee = otherfee;
	}


	public String getAirticket() {
		return airticket;
	}


	public void setAirticket(String airticket) {
		this.airticket = airticket;
	}


	public String getRn_check() {
		return rn_check;
	}


	public void setRn_check(String rn_check) {
		this.rn_check = rn_check;
	}


	public String getBuyer_cert_no() {
		return buyer_cert_no;
	}


	public void setBuyer_cert_no(String buyer_cert_no) {
		this.buyer_cert_no = buyer_cert_no;
	}


	public String getBuyer_real_name() {
		return buyer_real_name;
	}


	public void setBuyer_real_name(String buyer_real_name) {
		this.buyer_real_name = buyer_real_name;
	}


	public String getScene() {
		return scene;
	}


	public void setScene(String scene) {
		this.scene = scene;
	}


	public String getGoods_type() {
		return goods_type;
	}


	public void setGoods_type(String goods_type) {
		this.goods_type = goods_type;
	}
	
	

}
