package com.sfpay.alipay.function;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alipay.api.AlipayClient;
import com.sfpay.alipay.domain.AlipayTradeCloseRequest;
import com.sfpay.alipay.domain.AlipayTradeCloseResponse;
import com.sfpay.alipay.enums.AlipayErrorCode;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.common.json.JSONUtils;
import com.sfpay.upc.domain.upc.ChannelArgs;

public class AlipayCloseOrder extends AlipayBase {
	private final static Logger logger = LoggerFactory.getLogger(AlipayCloseOrder.class);

	public static AlipayTradeCloseResponse sendCloseOrderReq(String channelCode, String reqBankSn, ChannelArgs channelArgs) {
		
		int execTimes = 1;
		AlipayTradeCloseResponse response = null;
		do {
			try {
				AlipayClient alipayClient = getAplipayClient(channelCode, channelArgs);
				AlipayTradeCloseRequest request = new AlipayTradeCloseRequest();
				Map<String, String> paramsMap = new HashMap<String, String>();
				paramsMap.put("out_trade_no", reqBankSn);
				request.setBizContent(JSONUtils.fromObject(paramsMap));
				logger.info("发起查询请求 ：{}", request.getBizContent());
				if (execTimes <= RETRY_TIMES) {
					response = alipayClient.execute(request);
				} else {
					break;
				}
			}catch (ServiceException e) {
				logger.error("系统异常 code:[{}], msg:[{}]", e.getCode(), e.getMsg());
				throw new ServiceException(e.getCode(), e.getMsg());
			} catch (Exception e) {
				logger.error(String.format("发起关单[%s]异常", reqBankSn), e);
				throw new ServiceException("系统异常");
			}

			execTimes++;
		} while (AlipayErrorCode.SYSTEM_ERROR.getCode().equals(response.getSubCode()));

		return response;
	}

}
