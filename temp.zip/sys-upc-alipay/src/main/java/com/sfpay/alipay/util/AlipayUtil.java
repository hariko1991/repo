package com.sfpay.alipay.util;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.Map;

import com.sfpay.alipay.function.AlipayBase;
import com.sfpay.alipay.sign.RSA;

/**
 * 支付宝各接口请求提交类 构造支付宝各接口表单HTML文本，获取远程HTTP数据
 * 
 * @author 846306
 * 
 */
public class AlipayUtil {

	/**
	 * 将分为单位的转换为元 （除100）
	 * 
	 * @param amount
	 * @return
	 * @throws Exception
	 */
	public static String changeF2Y(Long amount) {
		if (0 == amount || null == amount) {
			return "0.00";
		}
		DecimalFormat df = new DecimalFormat("0.00"); // 保留两位小数
		BigDecimal bd = BigDecimal.valueOf(amount).divide(new BigDecimal(100));
		return df.format(bd);
	}

	/**
	 * 将元为单位的转换为分 （乘100）
	 * 
	 * @param amount
	 * @return
	 */
	public static Long changeY2F(Long amount) {
		if (0 == amount || null == amount) {
			return 0l;
		}
		return BigDecimal.valueOf(amount).multiply(new BigDecimal(100)).longValue();
	}

	
	public static void main(String[] args) {
		System.out.println(changeF2Y(100001L));
	}
}
