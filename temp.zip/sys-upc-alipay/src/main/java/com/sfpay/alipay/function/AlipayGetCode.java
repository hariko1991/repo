package com.sfpay.alipay.function;

import java.net.URLEncoder;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;

public class AlipayGetCode extends AlipayBase {
	private final static Logger logger = LoggerFactory.getLogger(AlipayGetCode.class);

	/**
	 * 
	 * 方法说明：<br>
	 * 获取网页授权url地址
	 * @param appId
	 * @param redirectUrl
	 * @return
	 */
	public static String getOAuthUrl(String redirectUrl) {
		String getCodeUrl = null;
		try {
			logger.info("获取支付宝授权地址 appId:{},redirectUrl:{}", new Object[]{redirectUrl});
			getCodeUrl = buildGetCodeReq(redirectUrl);
		} catch (ServiceException e) {
			logger.error("系统异常 code:[{}], msg:[{}]", e.getCode(), e.getMsg());
			throw new ServiceException(e.getCode(), e.getMsg());
		} catch (Exception e) {
			logger.error(String.format("获取微信授权地异常，appId:{},redirectUrl:{}", new Object[]{redirectUrl}), e);
			throw new ServiceException("FAIL", "系统异常!");
		}

		return getCodeUrl;
	}

	private static String buildGetCodeReq(String callBackUrl) throws Exception {
		
		//如果回调地址不传递，则需要前端自己拼装回调地址
		StringBuffer sb = new StringBuffer();
		sb.append(Property.getProperty("ALIPAY_OAUTH_URL")).append("?")
		.append("app_id=").append(Property.getProperty("ALIPAY_APPID")).append("&")
		.append("redirect_uri=").append(URLEncoder.encode(callBackUrl,"utf-8")).append("&")
		.append("scope=").append("auth_base").append("&")
		.append("state=").append("alipayGetCode");
		
		return sb.toString();
	}
	
}
