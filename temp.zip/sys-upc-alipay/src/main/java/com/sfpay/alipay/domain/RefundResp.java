package com.sfpay.alipay.domain;


/**
 * 
 * 类说明：<br>
 * 退款响应
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-15
 */
public class RefundResp extends BaseResp {

	private static final long serialVersionUID = -175842089869591731L;
	// 支付宝订单号
	private String alipayOrderNo;
	// 商户订单号
	private String outTradeNo;
	// 商户退款订单号
	private String outRefundNo;
	// 支付宝退款订单号
	private String refundId;
	// 退款金额（分）
	private Long refundFee;

	public String getAlipayOrderNo() {
		return alipayOrderNo;
	}

	public void setAlipayOrderNo(String alipayOrderNo) {
		this.alipayOrderNo = alipayOrderNo;
	}

	public String getOutTradeNo() {
		return outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	public String getOutRefundNo() {
		return outRefundNo;
	}

	public void setOutRefundNo(String outRefundNo) {
		this.outRefundNo = outRefundNo;
	}

	public String getRefundId() {
		return refundId;
	}

	public void setRefundId(String refundId) {
		this.refundId = refundId;
	}

	public Long getRefundFee() {
		return refundFee;
	}

	public void setRefundFee(Long refundFee) {
		this.refundFee = refundFee;
	}
}
