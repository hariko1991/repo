package com.sfpay.alipay.domain;

import java.lang.reflect.Field;

import org.apache.commons.lang.builder.ReflectionToStringBuilder;
import org.apache.commons.lang.builder.ToStringStyle;

/**
 * 支付宝支付基础类
 * 含有必传参数
 * 
 * @author 846306
 * 
 */
public class alipayBase {

	/**
	 * 接口名称
	 */
	private String service;

	/**
	 * 签约的支付宝账号对应的支付宝唯一用户号 以2088开头的16位纯数字组成 2088111111111194
	 */
	private String partner;

	/**
	 * 参数编码字符集
	 */
	private String _input_charset;

	/**
	 * 签名方式 DSA、RSA、MD5三个值可选，必须大写。
	 */
	private String sign_type;
	
	/**
	 * 签名
	 */
	private String sign;

	/**
	 * 服务器异步通知页面路径 支付宝服务器主动通知商户网站里指定的页面http路径。
	 */
	private String notify_url;
	
	
	public String getService() {
		return service;
	}


	public void setService(String service) {
		this.service = service;
	}


	public String getPartner() {
		return partner;
	}


	public void setPartner(String partner) {
		this.partner = partner;
	}


	public String get_input_charset() {
		return _input_charset;
	}


	public void set_input_charset(String _input_charset) {
		this._input_charset = _input_charset;
	}




	public String getSign_type() {
		return sign_type;
	}




	public void setSign_type(String sign_type) {
		this.sign_type = sign_type;
	}




	public String getSign() {
		return sign;
	}




	public void setSign(String sign) {
		this.sign = sign;
	}




	public String getNotify_url() {
		return notify_url;
	}




	public void setNotify_url(String notify_url) {
		this.notify_url = notify_url;
	}




	public String toString() {
	    return new ReflectionToStringBuilder(this, ToStringStyle.SHORT_PREFIX_STYLE){
	        @Override
	        protected boolean accept(Field field) {
	            return true;
	        }
	    }.toString();
	}
}
