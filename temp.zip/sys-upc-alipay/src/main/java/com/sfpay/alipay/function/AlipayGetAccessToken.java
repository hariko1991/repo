package com.sfpay.alipay.function;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alipay.api.AlipayClient;
import com.alipay.api.request.AlipaySystemOauthTokenRequest;
import com.alipay.api.response.AlipaySystemOauthTokenResponse;
import com.sfpay.alipay.enums.AlipayErrorCode;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;

public class AlipayGetAccessToken extends AlipayBase {
	private final static Logger logger = LoggerFactory.getLogger(AlipayGetAccessToken.class);

	/**
	 * 
	 * 方法说明：<br>
	 * 获取微信网页授权的accessToken
	 * @param appId
	 * @param appSecret
	 * @param code
	 * @return
	 */
	public static AlipaySystemOauthTokenResponse getOAuthaccessToken(String appId, String priKey,String pubKey ,String code) {
		
		AlipaySystemOauthTokenResponse tokenResp = null;
		int execTimes = 1;

		do {
			try {
				logger.info("发起获取授权accessToken请求 code:{}", code);
				AlipayClient alipayClient = getAplipayClientBySfpay(appId,priKey,pubKey);
				AlipaySystemOauthTokenRequest request = new AlipaySystemOauthTokenRequest();
				request.setCode(code);
				request.setGrantType("authorization_code");
				if (execTimes <= RETRY_TIMES) {
					tokenResp = alipayClient.execute(request);
				} else {
					break;
				}
			} catch (ServiceException e) {
				logger.error("系统异常 code:[{}], msg:[{}]", e.getCode(), e.getMsg());
				throw new ServiceException(e.getCode(), e.getMsg());
			} catch (Exception e) {
				logger.error(String.format("依据code[%s]获取用户ID异常", code), e);
				throw new ServiceException("系统异常");
			}
			execTimes++;
		} while (AlipayErrorCode.SYSTEM_ERROR.name().equals(tokenResp.getSubCode()));

		return tokenResp;

	}
}
