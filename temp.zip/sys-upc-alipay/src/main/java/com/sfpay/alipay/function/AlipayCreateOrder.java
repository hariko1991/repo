package com.sfpay.alipay.function;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alipay.api.AlipayClient;
import com.alipay.api.request.AlipayTradePrecreateRequest;
import com.alipay.api.response.AlipayTradePrecreateResponse;
import com.sfpay.alipay.domain.CreateOrderReq;
import com.sfpay.alipay.enums.AlipayErrorCode;
import com.sfpay.alipay.util.AlipayUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.common.json.JSONUtils;
import com.sfpay.upc.domain.upc.ChannelArgs;

/**
 * 
 * 类说明：<br>
 * 支付宝下单
 * 
 * <p>
 * 详细描述：<br>
 * 
 * @author dumengchao(896728)
 * @date 2016-6-13
 */
public class AlipayCreateOrder extends AlipayBase {
	private static final Logger logger = LoggerFactory.getLogger(AlipayCreateOrder.class);

	public static AlipayTradePrecreateResponse doCreate(CreateOrderReq req, ChannelArgs channelArgs) {
		int execTimes = 1;
		AlipayTradePrecreateResponse response = null;
		do {
			try {
				AlipayClient alipayClient = getAplipayClient(req.getChannelCode(), channelArgs);
				AlipayTradePrecreateRequest request = new AlipayTradePrecreateRequest();
				request.setNotifyUrl(req.getNotifyUrl());
				Map<String, String> paramsMap = new HashMap<String, String>();
				paramsMap.put("out_trade_no", req.getOutTradeNo());
				paramsMap.put("total_amount", AlipayUtil.changeF2Y(req.getTotalAmount()));
				paramsMap.put("subject", req.getSubject());
				
				request.setBizContent(JSONUtils.fromObject(paramsMap));
				logger.info("发起支付宝下单请求 ：{}", request.getBizContent());
				if (execTimes <= RETRY_TIMES) {
					response = alipayClient.execute(request);
				} else {
					break;
				}
			} catch (ServiceException e) {
				logger.error("系统异常 code:[{}], msg:[{}]", e.getCode(), e.getMsg());
				throw new ServiceException(e.getCode(), e.getMsg());
			} catch (Exception e) {
				logger.error(String.format("发起支付宝下单[%s]异常", req.toString()), e);
				throw new ServiceException("系统异常");
			}
			execTimes++;
		} while (AlipayErrorCode.SYSTEM_ERROR.getCode().equals(response.getSubCode()));

		return response;
	}

}
