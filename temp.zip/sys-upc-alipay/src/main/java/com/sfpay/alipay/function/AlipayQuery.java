package com.sfpay.alipay.function;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alipay.api.AlipayClient;
import com.alipay.api.request.AlipayTradeQueryRequest;
import com.alipay.api.response.AlipayTradeQueryResponse;
import com.sfpay.alipay.domain.OrderQueryReq;
import com.sfpay.alipay.enums.AlipayErrorCode;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.common.json.JSONUtils;
import com.sfpay.upc.domain.upc.ChannelArgs;

/**
 * 
 * 类说明：<br>
 * 支付宝查询
 * 
 * <p>
 * 详细描述：<br>
 * 
 * @author dumengchao(896728)
 * @date 2016-6-13
 */
public class AlipayQuery extends AlipayBase {
	private static final Logger logger = LoggerFactory.getLogger(AlipayQuery.class);

	public static AlipayTradeQueryResponse doQuery(OrderQueryReq req, ChannelArgs channelArgs) {
		
		int execTimes = 1;
		AlipayTradeQueryResponse response = null;
		do {
			try {
				AlipayClient alipayClient = getAplipayClient(req.getChannelCode(), channelArgs);
				AlipayTradeQueryRequest request = new AlipayTradeQueryRequest();
				Map<String, String> paramsMap = new HashMap<String, String>();
				paramsMap.put("out_trade_no", req.getOutTradeNo());
				request.setBizContent(JSONUtils.fromObject(paramsMap));
				logger.info("发起查询请求 ：{}", request.getBizContent());
				if (execTimes <= RETRY_TIMES) {
					response = alipayClient.execute(request);
				} else {
					break;
				}
			}catch (ServiceException e) {
				logger.error("系统异常 code:[{}], msg:[{}]", e.getCode(), e.getMsg());
				throw new ServiceException(e.getCode(), e.getMsg());
			} catch (Exception e) {
				logger.error(String.format("发起查询[%s]异常", req.toString()), e);
				throw new ServiceException("系统异常");
			}

			execTimes++;
		} while (AlipayErrorCode.SYSTEM_ERROR.getCode().equals(response.getSubCode()));

		return response;
	}
}
