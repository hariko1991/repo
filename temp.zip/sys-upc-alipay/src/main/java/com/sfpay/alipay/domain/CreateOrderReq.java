package com.sfpay.alipay.domain;

import org.apache.commons.lang.StringUtils;

import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：<br>
 * 支付宝下单
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-18
 */
public class CreateOrderReq extends BaseReq {

	private static final long serialVersionUID = 5974978544436522454L;
	// 第三方唯一订单号
	private String outTradeNo;
	// 交易金额
	private Long totalAmount;
	// 订单标题
	private String subject;
	// 过期时间
	private String expireTime;

	public String getOutTradeNo() {
		return outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	public Long getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(Long totalAmount) {
		this.totalAmount = totalAmount;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getExpireTime() {
		return expireTime;
	}

	public void setExpireTime(String expireTime) {
		this.expireTime = expireTime;
	}

	@Override
	public void checkArguments() {
		super.checkArguments();
		if (StringUtils.isEmpty(getOutTradeNo())) {
			throw new ServiceException("商户订单号不能为空");
		}
		if (getTotalAmount() == null) {
			throw new ServiceException("金额不能为空");
		}
		if (StringUtils.isEmpty(getSubject())) {
			throw new ServiceException("订单标题不能为空");
		}
	}
}
