package com.sfpay.alipay.domain;


public class GetAccessTokenReq extends BaseReq {

	private static final long serialVersionUID = 1L;
	
	/**
	 * 请求url
	 */
	private String reqUrl;

	public String getReqUrl() {
		return reqUrl;
	}

	public void setReqUrl(String reqUrl) {
		this.reqUrl = reqUrl;
	}
	
	
}
