package com.sfpay.alipay.function;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alipay.api.AlipayClient;
import com.alipay.api.request.AlipayTradePayRequest;
import com.alipay.api.response.AlipayTradePayResponse;
import com.sfpay.alipay.domain.CreateBCOrderReq;
import com.sfpay.alipay.enums.AlipayErrorCode;
import com.sfpay.alipay.util.AlipayUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.common.json.JSONUtils;
import com.sfpay.upc.domain.upc.ChannelArgs;

/**
 * 
 * 类说明：<br>
 * 支付宝扫码支付下单
 * 
 * <p>
 * 详细描述：对应支付宝接口是条码支付.<br>
 * 
 * @author 项定友(844193)
 * @date 2016-7-19
 */
public class AlipayCreateBCOrder extends AlipayBase {
	private static final Logger logger = LoggerFactory.getLogger(AlipayCreateBCOrder.class);

	public static AlipayTradePayResponse doCreateAndPay(CreateBCOrderReq req, ChannelArgs channelArgs) {
		int execTimes = 1;
		AlipayTradePayResponse response = null;
		do {
			try {
				AlipayClient alipayClient = getAplipayClient(req.getChannelCode(), channelArgs);
				AlipayTradePayRequest request = new AlipayTradePayRequest();
				request.setNotifyUrl(req.getNotifyUrl());
				Map<String, String> paramsMap = new HashMap<String, String>();
				paramsMap.put("out_trade_no", req.getOutTradeNo());
				paramsMap.put("total_amount", AlipayUtil.changeF2Y(req.getTotalAmount()));
				paramsMap.put("subject", req.getSubject());
				paramsMap.put("scene", req.getScene());
				paramsMap.put("auth_code", req.getAuthCode());
				
				request.setBizContent(JSONUtils.fromObject(paramsMap));
				logger.info("发起支付宝扫码支付下单请求 ：{}", request.getBizContent());
				if (execTimes <= RETRY_TIMES) {
					response = alipayClient.execute(request);
				} else {
					break;
				}
			} catch (ServiceException e) {
				logger.error("系统异常 code:[{}], msg:[{}]", e.getCode(), e.getMsg());
				throw new ServiceException(e.getCode(), e.getMsg());
			} catch (Exception e) {
				logger.error(String.format("发起支付宝扫码支付下单[%s]异常", req.toString()), e);
				throw new ServiceException("系统异常");
			}
			execTimes++;
		} while (AlipayErrorCode.SYSTEM_ERROR.getCode().equals(response.getSubCode()));

		return response;
	}

}
