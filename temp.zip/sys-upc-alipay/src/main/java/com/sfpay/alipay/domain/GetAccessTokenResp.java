package com.sfpay.alipay.domain;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.sfpay.framework.common.json.JSONUtils;
import com.sfpay.upc.domain.upc.ChannelArgs;

public class GetAccessTokenResp extends BaseResp{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 统一支付平台外部订单号
	 */
	private String accessToken;
	
	private String expiresIn;
	
	private String refreshToken;
	
	private String openid;
	
	private String scope;

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getExpiresIn() {
		return expiresIn;
	}

	public void setExpiresIn(String expiresIn) {
		this.expiresIn = expiresIn;
	}

	public String getRefreshToken() {
		return refreshToken;
	}

	public void setRefreshToken(String refreshToken) {
		this.refreshToken = refreshToken;
	}

	public String getOpenid() {
		return openid;
	}

	public void setOpenid(String openid) {
		this.openid = openid;
	}

	public String getScope() {
		return scope;
	}

	public void setScope(String scope) {
		this.scope = scope;
	}

//
//	/**
//	 * 
//	 * 方法说明：<br>
//	 * 响应数据解析
//	 * 
//	 * @param jsonMsg
//	 * @throws Exception
//	 */
//	@Override
//	public void parseByJson(String jsonMsg) throws Exception {
//		Map<String, Object> resultMap = JSONUtils.formJSONStr(jsonMsg, Map.class);
//		String errCode = resultMap.get("errcode") != null ? String.valueOf(resultMap.get("errcode")) : null;
//		String errMsg = resultMap.get("errmsg") != null ? String.valueOf(resultMap.get("errmsg")) : null;
//		
//		if (StringUtils.isBlank(errCode)) {
//			setReturnCode(SUCCESS);
//			setAccessToken(String.valueOf(resultMap.get("access_token")));
//			setExpiresIn(String.valueOf(resultMap.get("expires_in")));
//			setRefreshToken(String.valueOf(resultMap.get("refresh_token")));
//			setOpenid(String.valueOf(resultMap.get("openid")));
//			setScope(String.valueOf(resultMap.get("scope")));
//		} else {
//			setErrCode(errCode);
//			setErrCodeDes(errMsg);
//		}
//	}
//
//	@Override
//	public boolean needValidSign() {
//		return false;
//	}
//
//	@Override
//	public void parseItem(HashMap<String, Object> resultMap,
//			ChannelArgs bankArgs) {
//		
//	}
	
}
