/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.pay.service.hessian;

import java.util.Map;

import javax.annotation.Resource;
import javax.jms.Destination;
import javax.jms.JMSException;
import javax.jms.MapMessage;
import javax.jms.Message;
import javax.jms.Session;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jms.core.JmsTemplate;
import org.springframework.jms.core.MessageCreator;
import org.springframework.stereotype.Service;

import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.upc.service.IMqService;

/**
 * 
 * 类说明：<br>
 * mq 服务
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-5-10
 */
@Service
@HessianExporter("/upc/mqService")
public class MqServiceImpl implements IMqService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	@Resource
	private JmsTemplate jmsTemplate;
	@Resource(name = "tradeNotifyQueue")
	private Destination tradeNotifyQueue;
	@Resource(name = "tradeNotifyQueueNew")
	private Destination tradeNotifyQueueNew;
	@Resource(name="tradeExceptionQueue")
	private Destination tradeExceptionQueue;

	@Override
	public void sendMsg(boolean newVersion, final Map<String, String> msg) {
		logger.info("发送mq消息:[{}]", msg.toString());
		try {

			if (newVersion) {
				sendMessage(msg, null, tradeNotifyQueueNew);
			} else {
				sendMessage(msg, null, tradeNotifyQueue);
			}
		} catch (Exception e) {
			logger.error("发送mq消息异常:[{}]" + msg.toString(), e);
		}
	}

	@Override
	public void sendMsg(final Map<String, String> msg, final Map<String, String> msgProperty) {
		logger.info("发送mq消息:[{}],msgProperty:[{}] ", msg.toString(), msgProperty.toString());
		try {
			sendMessage(msg, msgProperty, tradeExceptionQueue);
		} catch (Exception e) {
			logger.error("发送mq消息异常:[{}]" + msg.toString(), e);
		}
	}

	@Override
	public void sendExceptionMq(final Map<String, String> msg) {
		logger.info("发送异常mq消息:[{}] ", msg.toString());
		try {
			sendMessage(msg, null, tradeExceptionQueue);
		} catch (Exception e) {
			logger.error("发送异常mq消息异常:[{}]" + msg.toString(), e);
		}
	}

	private void sendMessage(final Map<String, String> msg, final Map<String, String> msgProperty,
			Destination destination) {
		jmsTemplate.send(destination, new MessageCreator() {
			@Override
			public Message createMessage(Session session) throws JMSException {
				MapMessage message = session.createMapMessage();

				for (Map.Entry<String, String> entry : msg.entrySet()) {
					message.setString(entry.getKey(), entry.getValue());
				}

				if (msgProperty != null) {
					for (Map.Entry<String, String> entry : msgProperty.entrySet()) {
						message.setStringProperty(entry.getKey(), entry.getValue());
					}
				}
				return message;
			}
		});
	}

}
