package com.sfpay.pay.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.upc.domain.upc.UpcChannelArg;

public interface ChannelArgDao {

	List<UpcChannelArg> queryArgsByChannelCodeAndMchNo(@Param("channelMchParamKey")String channelMchParamKey,
			@Param("mchNo")String mchNo);

	/**
	 * 添加记录
	 * @param upcChannelArg
	 */
	void addUpcChannelArg(UpcChannelArg upcChannelArg);
	
	/**
	 * 修改记录
	 * @param upcChannelArg
	 */
	void updateUpcChannelArg(UpcChannelArg upcChannelArg);
	
	List<UpcChannelArg> queryArgsByChannelCode(@Param("channelCode")String channelCode);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据id更新upc渠道参数配置信息
	 * @param upcChannelArg
	 */
	void updateUpcChannelArgById(UpcChannelArg upcChannelArg);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 统计upc渠道配置数量
	 * @param mchNo
	 * @param channelCode
	 * @return
	 */
	int countUpcArgs(@Param("mchNo")String mchNo, @Param("channelCode")String channelCode);

	/**
	 * 
	 * 方法说明：<br>
	 * 分页查询Upc渠道参数配置
	 * @param mchNo
	 * @param channelCode
	 * @param minPageNo
	 * @param maxPageNo
	 * @return
	 */
	List<UpcChannelArg> selectUpcArgsByPage(@Param("mchNo")String mchNo, @Param("channelCode")String channelCode, 
			@Param("minPageNo")int minPageNo, @Param("maxPageNo")int maxPageNo);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据id查询具体参数配置信息
	 * @param id
	 * @return
	 */
	UpcChannelArg selectArgsByArgId(Long id);
}
