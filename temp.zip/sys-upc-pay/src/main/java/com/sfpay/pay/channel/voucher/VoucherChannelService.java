package com.sfpay.pay.channel.voucher;

import java.net.SocketTimeoutException;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.caucho.hessian.HessianException;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.pay.channel.enums.ExceptionBusiType;
import com.sfpay.pay.channel.enums.ExceptionType;
import com.sfpay.pay.dao.UpcPayInfoDao;
import com.sfpay.pay.service.impl.UpcPayInfoManageService;
import com.sfpay.sypay.voucher.service.IVoucherTradeService;
import com.sfpay.sypay.voucher.valueobject.dto.UserVoucher;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.upc.UpdateUpcPayStatusParam;
import com.sfpay.upc.domain.voucher.CreateVoucherOrderReq;
import com.sfpay.upc.domain.voucher.CreateVoucherOrderResp;
import com.sfpay.upc.domain.voucher.OperatorVoucherReq;
import com.sfpay.upc.domain.voucher.VoucherRefundReq;
import com.sfpay.upc.domain.voucher.VoucherRefundResp;
import com.sfpay.upc.enums.ChannelType;
import com.sfpay.upc.enums.CurrencyType;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.enums.TradeType;
import com.sfpay.upc.exception.UPCServiceException;
import com.sfpay.upc.service.IMqService;

/**
 * 
 * 类说明：<br>
 * 券处理
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke)
 */
@Service
public class VoucherChannelService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	public final static String SOURCE = "UPC";
	public final static String VOUCHER_NOT_VALID = "VOUCHER_NOT_VALID";
	public final static String DB_EXCEPTION = "DB_EXCEPTION";
	public final static String RISK_EXCEPTION = "RISK_EXCEPTION";
	@Resource
	private UpcPayInfoDao upcPayInfoDao;
	@Resource
	private UpcPayInfoManageService payManageInfoService;
	@Resource
	private IVoucherTradeService voucherTradeService;
	@Resource
	protected IMqService mqService;

	public CreateVoucherOrderResp createPayOrder(CreateVoucherOrderReq payReq) throws UPCServiceException {
		logger.info("请求支付 VoucherChannelService.createPayOrder 参数 ：req:{}", payReq.toString());
		UpcPayInfo payInfo = buildUpcPayInfo(payReq);
		// 创建统一支付流水
		payManageInfoService.createPayInfo(payInfo);
		// 组装返回数据
		CreateVoucherOrderResp resp = new CreateVoucherOrderResp(UpcConstants.SUCCESS, null);
		resp.setChannelCode(payReq.getChannelCode());
		resp.setMchNo(payReq.getMchNo());
		resp.setUpcTradeNo(payInfo.getPayNo());
		return resp;

	}

	/**
	 * 冻结券
	 * 
	 * @param req
	 * 
	 * @param payInfo
	 * @return
	 * @throws UPCServiceException
	 */
	public void freezeVoucher(OperatorVoucherReq req, UpcPayInfo payInfo) throws UPCServiceException {
		Long memberNo = payInfo.getMemberNo();
		String voucherCode = payInfo.getVoucherCode();
		Long tradeAmt = payInfo.getTradeAmt();
		String mchNo = payInfo.getMchNo();
		String mchOrderNo = payInfo.getMchOrderNo();
		String payNo = payInfo.getPayNo();
		logger.info("请求券冻结: memberNo:{}, voucherCode:{}, tradeAmt:{}, mchNo:{}, mchOrderNo:{} sourceType:{}, channelId:{}", new Object[] { memberNo,
				voucherCode, tradeAmt, mchNo, mchOrderNo, req.getSourceType(), req.getChannelId() });

		try {
			// 执行券冻结
			voucherTradeService.freezeVoucher(memberNo, null, req.getChannelId(), req.getSourceType(), voucherCode, mchNo, mchOrderNo, tradeAmt);
			logger.info("请求券冻结成功 payNo:{},voucherCode:{}", payNo, voucherCode);

			// 更新券为冻结
			updateUpcOrderStatus(payNo, TradeStatus.INIT, TradeStatus.FREEZE);
		} catch (ServiceException e) {
			logger.error(String.format("冻结券异常: payNo:%s, voucherCode: %s", payNo, voucherCode), e);
			// 异步记录异常数据
			payManageInfoService.asyncRecordError(payNo, e.getCode(), e.getMsg());
			// 冻结券
			if (VOUCHER_NOT_VALID.equals(e.getCode()) || DB_EXCEPTION.equals(e.getCode()) || RISK_EXCEPTION.equals(e.getCode())) {
				//单独券允许切换，不用更改订单状态
				if(!req.isOnlyVoucherPay()){
					updateUpcOrderStatus(payNo, TradeStatus.INIT, TradeStatus.FAILURE);
				}
				throw new ServiceException(RISK_EXCEPTION.equals(e.getCode()) ? UpcConstants.RISK_EXCEPTION : UpcConstants.ORDER_FREEZE_FAIL,
						e.getMsg());
			}

			throw new ServiceException(UpcConstants.FAILURE_SYS, "冻结券失败");

		} catch (Exception e) {
			logger.error(String.format("冻结券异常: payNo:%s, voucherCode: %s", payNo, voucherCode), e);
			if (e instanceof SocketTimeoutException || e instanceof HessianException) {
				// send mq msg
				sendMq(ExceptionBusiType.FreezeVoucher, null, payNo, ExceptionType.HESSIAN, e.getMessage());

			}

			// 异步记录异常数据
			payManageInfoService.asyncRecordError(payNo, UpcConstants.FAILURE_SYS, e.getMessage());
			throw new ServiceException(UpcConstants.FAILURE_SYS, "系统异常");
		}

	}

	/**
	 * 券解冻
	 * 
	 * @param unfreezeType
	 *            解冻类型
	 * 
	 * @param payInfo
	 * @return
	 */
	public void unfreezeVoucher(String unfreezeType, UpcPayInfo payInfo) {
		Long memberNo = payInfo.getMemberNo();
		String voucherCode = payInfo.getVoucherCode();
		String mchOrderNo = payInfo.getMchOrderNo();
		String payNo = payInfo.getPayNo();
		logger.info("请求券系统解冻: memberNo:{}, voucherCode:{},mchOrderNo:{}", new Object[] { memberNo, voucherCode, mchOrderNo });
		try {
			voucherTradeService.thawVoucher(memberNo, null, voucherCode, mchOrderNo);
			logger.info("请求券解冻成功 payNo:{},voucherCode:{}", payNo, voucherCode);

			String remark = "券解冻成功关闭";
			TradeStatus targetStaus = TradeStatus.CLOSE;
			// 关单导致解冻
			if ("CLOSE".equals(unfreezeType)) {
				targetStaus = TradeStatus.INIT;
				remark = "关单解冻导致状态恢复到INIT";
			}
			// 更新券为交易进行中
			updateUpcOrderStatus(payNo, TradeStatus.FREEZE, targetStaus, remark);
		} catch (ServiceException e) {
			logger.error(String.format("解冻券异常: payNo:%s, voucherCode: %s", payNo, voucherCode), e);
			// 异步记录异常数据
			payManageInfoService.asyncRecordError(payNo, e.getCode(), e.getMsg());
			// 解冻失败
			if (VOUCHER_NOT_VALID.equals(e.getCode()) || DB_EXCEPTION.equals(e.getCode())) {
				throw new ServiceException(UpcConstants.ORDER_UNFREEZE_FAIL, e.getMsg());
			}

			throw new ServiceException(UpcConstants.FAILURE_SYS, "系统异常");

		} catch (Exception e) {
			logger.error(String.format("解冻券异常: payNo:%s, voucherCode: %s", payNo, voucherCode), e);
			if (e instanceof SocketTimeoutException || e instanceof HessianException) {
				// send mq msg
				sendMq(ExceptionBusiType.UnFreezeAndUseVoucher, null, payNo, ExceptionType.HESSIAN, e.getMessage());
			}
			// 异步记录异常数据
			payManageInfoService.asyncRecordError(payNo, UpcConstants.FAILURE_SYS, e.getMessage());
			throw new ServiceException(UpcConstants.FAILURE_SYS, "系统异常");

		}
	}

	/**
	 * 券解冻支付
	 * 
	 * @param req
	 * 
	 * @param payInfo
	 * @return
	 * @throws UPCServiceException
	 */
	public void voucherUnfreezeAndPay(OperatorVoucherReq req, UpcPayInfo payInfo) throws UPCServiceException {

		Long memberNo = payInfo.getMemberNo();
		String voucherCode = payInfo.getVoucherCode();
		Long tradeAmt = payInfo.getTradeAmt();
		String mchNo = payInfo.getMchNo();
		String mchOrderNo = payInfo.getMchOrderNo();
		String payNo = payInfo.getPayNo();
		logger.info("请求券系统解冻支付: memberNo:{}, voucherCode:{}, tradeAmt:{}, mchNo:{}, mchOrderNo:{},payNo:{}", new Object[] { memberNo, voucherCode,
				tradeAmt, mchNo, mchOrderNo, payNo });

		try {
			voucherTradeService.tradeVoucher(memberNo, null, voucherCode, mchNo, mchOrderNo, payNo);
			logger.info("请求券解冻支付成功 payNo:{},voucherCode:{}", payNo, voucherCode);
			// 更新状态
			updateUpcOrderStatus(payInfo.getPayNo(), TradeStatus.TRADING, TradeStatus.SUCCESS);
		} catch (ServiceException e) {
			logger.error(String.format("券解冻支付异常: payNo:%s, voucherCode: %s", payNo, voucherCode), e);

			// 异步记录异常数据
			payManageInfoService.asyncRecordError(payNo, e.getCode(), e.getMsg());
			updateUpcOrderStatus(payInfo.getPayNo(), TradeStatus.TRADING, TradeStatus.FREEZE);
			if (VOUCHER_NOT_VALID.equals(e.getCode()) || DB_EXCEPTION.equals(e.getCode())) {
				throw new ServiceException(UpcConstants.ORDER_UNFREEZE_AND_PAY_FAIL, e.getMsg());
			}
			throw new ServiceException(UpcConstants.FAILURE_SYS, "系统异常");
		} catch (Exception e) {
			logger.error(String.format("券解冻支付异常: payNo:%s, voucherCode: %s", payNo, voucherCode), e);
			if (e instanceof SocketTimeoutException || e instanceof HessianException) {
				// send mq msg
				sendMq(ExceptionBusiType.UnFreezeAndUseVoucher, null, payNo, ExceptionType.HESSIAN, e.getMessage());
			}

			// 异步记录异常数据
			payManageInfoService.asyncRecordError(payNo, UpcConstants.FAILURE_SYS, e.getMessage());
			updateUpcOrderStatus(payInfo.getPayNo(), TradeStatus.TRADING, TradeStatus.FREEZE);
			
			throw new ServiceException(UpcConstants.FAILURE_SYS, "系统异常");
		}

	}

	/**
	 * 退款
	 * 
	 * @param req
	 * @param refundPayInfo
	 * @return
	 * @throws UPCServiceException
	 */
	public VoucherRefundResp doRefund(VoucherRefundReq req, UpcPayInfo refundPayInfo) throws UPCServiceException {
		Long memberNo = refundPayInfo.getMemberNo();
		String voucherCode = refundPayInfo.getVoucherCode();
		Long tradeAmt = refundPayInfo.getTradeAmt();
		String mchNo = refundPayInfo.getMchNo();
		String mchOrderNo = refundPayInfo.getMchOrderNo();
		String oldMchOrderNo = refundPayInfo.getOldMchOrderNo();
		String payNo = refundPayInfo.getPayNo();
		logger.info(
				"请求券系统退款: memberNo:{}, voucherCode:{}, tradeAmt:{}, mchNo:{}, mchOrderNo:{},payNo:{},isRefundVoucher:{}  sourceType:{}, channelId:{}",
				new Object[] { memberNo, voucherCode, tradeAmt, mchNo, mchOrderNo, payNo, req.isRefundVoucher(), req.getSourceType(),
						req.getChannelId() });
		try {

			// 执行退款
			voucherTradeService.refundVoucher(memberNo, null, req.getChannelId(), req.getSourceType(), voucherCode, tradeAmt, mchNo, mchOrderNo,
					oldMchOrderNo, payNo, req.isRefundVoucher());

			logger.info("请求券退款成功 payNo:{},voucherCode:{}", payNo, voucherCode);
			// 修改退款流水
			updateUpcOrderStatus(payNo, TradeStatus.REFUND_PROC, TradeStatus.REFUND_SUCC);

			VoucherRefundResp voucherRefundResp = new VoucherRefundResp(UpcConstants.SUCCESS, null);
			voucherRefundResp.setStatus(TradeStatus.SUCCESS.name());
			voucherRefundResp.setUpcRefundNo(payNo);
			return voucherRefundResp;
		} catch (ServiceException e) {
			logger.error(String.format("券退款异常: payNo:%s, voucherCode: %s", payNo, voucherCode), e);

			// 异步记录异常数据
			payManageInfoService.asyncRecordError(payNo, e.getCode(), e.getMsg());
			if (VOUCHER_NOT_VALID.equals(e.getCode()) || DB_EXCEPTION.equals(e.getCode())) {
				updateUpcOrderStatus(payNo, TradeStatus.REFUND_PROC, TradeStatus.REFUND_FAIL);
				VoucherRefundResp voucherRefundResp = new VoucherRefundResp(UpcConstants.SUCCESS, e.getMsg());
				voucherRefundResp.setStatus(TradeStatus.FAILURE.name());
				return voucherRefundResp;
			}

			throw new ServiceException(UpcConstants.FAILURE_SYS, "系统异常");

		} catch (Exception e) {
			logger.error(String.format("券退款异常: payNo:%s, voucherCode: %s", payNo, voucherCode), e);
			if (e instanceof SocketTimeoutException || e instanceof HessianException) {
				// send mq msg
				sendMq(ExceptionBusiType.VoucherRefund, null, payNo, ExceptionType.HESSIAN, e.getMessage());
			}
			// 异步记录异常数据
			payManageInfoService.asyncRecordError(payNo, UpcConstants.FAILURE_SYS, e.getMessage());
			throw new ServiceException(UpcConstants.FAILURE_SYS, "系统异常");
		}
	}

	public UserVoucher queryVoucher(String voucherCode) {
		try {
			return voucherTradeService.queryVoucher(voucherCode);
		} catch (Exception e) {
			throw new ServiceException(UpcConstants.FAILURE_SYS, "系统异常");
		}
	}

	private void sendMq(ExceptionBusiType businessType, String reqUrl, String reqMsg, ExceptionType exceptionType, String exceptionMsg) {

		Map<String, String> mqMap = new HashMap<String, String>();
		mqMap.put("businessCategory", businessType.getCategory());
		mqMap.put("exceptionBusiness", businessType.name());
		mqMap.put("exceptionDetailMsg", exceptionMsg);
		mqMap.put("exceptionType", exceptionType.name());
		mqMap.put("eeqMessage", reqMsg);
		mqMap.put("reqUrl", reqUrl);
		mqMap.put("handleType", "SYSTEM");
		mqMap.put("sysSource", SOURCE);

		mqService.sendExceptionMq(mqMap);
		logger.info("发送异常mq消息成功");
	}

	/**
	 * 组装支付流水
	 * 
	 * @param payReq
	 * @param channelArgs
	 * @return
	 */
	protected UpcPayInfo buildUpcPayInfo(CreateVoucherOrderReq payReq) {
		UpcPayInfo payInfo = new UpcPayInfo();
		payInfo.setPayNo(upcPayInfoDao.getPayNo());
		payInfo.setChannelCategoryCode(ChannelType.VOUCHER.name());
		payInfo.setChannelCode(payReq.getChannelCode());
		payInfo.setMchNo(payReq.getMchNo());
		payInfo.setChannelMchNo(payReq.getMchNo());
		payInfo.setMchOrderNo(payReq.getMchOrderNo());
		payInfo.setUseMchnoReq("Y");
		payInfo.setReqOrderNo(payReq.getMchOrderNo());
		payInfo.setTradeType(TradeType.PAY.name());
		payInfo.setTradeFee(0L);
		payInfo.setTradeAmt(payReq.getTradeAmount());
		payInfo.setSystemSource(payReq.getSystemSource());
		payInfo.setCcy(CurrencyType.RMB.name());
		payInfo.setStatus(TradeStatus.INIT.name());
		payInfo.setProductName(payReq.getProductName());
		payInfo.setProductDesc(payReq.getProductDesc());
		payInfo.setCallbackSfUrl(payReq.getCallbackUrl());
		payInfo.setRemark(payReq.getRemark());
		payInfo.setMemberNo(payReq.getMemberNo());
		payInfo.setUppOrderNo(payReq.getUppOrderNo());
		payInfo.setVoucherCode(payReq.getVoucherCode());

		return payInfo;
	}

	protected void updateUpcOrderStatus(String payNo, TradeStatus originalStatus, TradeStatus targetStatus) throws UPCServiceException {
		updateUpcOrderStatus(payNo, originalStatus, targetStatus, null);
	}

	protected void updateUpcOrderStatus(String payNo, TradeStatus originalStatus, TradeStatus targetStatus, String remark) throws UPCServiceException {
		UpdateUpcPayStatusParam upcParam = new UpdateUpcPayStatusParam();
		upcParam.setPayNo(payNo);
		upcParam.setOriginalStatus(originalStatus.name());
		upcParam.setTargetStatus(targetStatus.name());
		upcParam.setRemark(remark);
		payManageInfoService.updatePayInfoStatus(upcParam);
	}

}
