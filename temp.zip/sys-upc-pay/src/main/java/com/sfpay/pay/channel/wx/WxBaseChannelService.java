package com.sfpay.pay.channel.wx;

import java.text.MessageFormat;
import java.util.Date;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.enums.ChannelCode;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework2.core.util.DateUtil;
import com.sfpay.pay.dao.UpcPayInfoDao;
import com.sfpay.pay.domain.HandleChannelBaseResp;
import com.sfpay.pay.domain.HandleWxUnknownStatusResp;
import com.sfpay.pay.domain.UpcWxExt;
import com.sfpay.pay.service.impl.UpcPayInfoManageService;
import com.sfpay.pay.service.impl.WxExtService;
import com.sfpay.pay.util.UpcWxCodeUtil;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.upc.UpcPayUnknownParam;
import com.sfpay.upc.domain.upc.UpdateUpcPayStatusParam;
import com.sfpay.upc.domain.wx.WXCloseOrderReq;
import com.sfpay.upc.domain.wx.WXCreateOrderReq;
import com.sfpay.upc.domain.wx.WXCreateOrderResp;
import com.sfpay.upc.domain.wx.WXDownloadBillReq;
import com.sfpay.upc.domain.wx.WXDownloadBillResp;
import com.sfpay.upc.domain.wx.WXPayReq;
import com.sfpay.upc.domain.wx.WXPayResp;
import com.sfpay.upc.enums.ChannelType;
import com.sfpay.upc.enums.CurrencyType;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.enums.TradeType;
import com.sfpay.upc.enums.YesOrNo;
import com.sfpay.upc.exception.UPCServiceException;
import com.sfpay.wx.domain.BaseResp;
import com.sfpay.wx.domain.CloseOrderResp;
import com.sfpay.wx.domain.CreateOrderReq;
import com.sfpay.wx.domain.CreateOrderResp;
import com.sfpay.wx.domain.DownloadBillReq;
import com.sfpay.wx.domain.DownloadBillResp;
import com.sfpay.wx.domain.OrderQueryReq;
import com.sfpay.wx.domain.OrderQueryResp;
import com.sfpay.wx.domain.PayReq;
import com.sfpay.wx.domain.PayResp;
import com.sfpay.wx.domain.RefundReq;
import com.sfpay.wx.domain.RefundResp;
import com.sfpay.wx.enums.WxErrorCodeType;
import com.sfpay.wx.function.WXCloseOrder;
import com.sfpay.wx.function.WXCreateOrder;
import com.sfpay.wx.function.WXDownloadBill;
import com.sfpay.wx.function.WXGetCode;
import com.sfpay.wx.function.WXPayment;
import com.sfpay.wx.function.WXQuery;
import com.sfpay.wx.function.WXRefund;

/**
 * 
 * 类说明：<br>
 * 微信渠道基础服务
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-22
 */
@Service
public class WxBaseChannelService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	// 公众号支付
	public static final String TRADE_TYPE_JSAPI = "JSAPI";
	// 公众号支付
	public static final String TRADE_TYPE_JSAPI_PROGRAM = "JSAPI_PROGRAM";
	// WAP支付
	public static final String TRADE_TYPE_WAP = "WAP";

	// APP支付
	public static final String TRADE_TYPE_APP = "APP";
	// 扫码支付 B2C
	public static final String TRADE_TYPE_QR = "NATIVE";

	@Resource
	private UpcPayInfoDao upcPayInfoDao;
	@Resource
	private WxExtService wxExtService;
	@Resource
	private UpcPayInfoManageService payManageInfoService;

	public WXCreateOrderResp createPayOrder(WXCreateOrderReq payReq, ChannelArgs channelArgs) throws UPCServiceException {
		logger.info("请求支付 WxBaseChannelService.createPayOrder 参数 ：req:{}", payReq.toString());
		long startTime = System.currentTimeMillis();
		// 非空校验
		validWxReqArgs(payReq);

		// 不存在创建统一支付流水 否则使用原流水下单

		UpcPayInfo payInfo = buildUpcPayInfo(payReq, channelArgs);
		upcPayInfoDao.createPayInfo(payInfo);
		logger.info("生成payinfo流程成功 payNo:[{}]", payInfo.getPayNo());

		// 下单到第三方 微信支付宝或其他
		CreateOrderReq createOrderReq = buildCreateWxOrderReq(payReq, payInfo);
		CreateOrderResp createOrderResp = WXCreateOrder.doCreateOrder(createOrderReq, channelArgs);
		logger.info("请求微信下单返回数据:[{}]", createOrderResp.toString());

		WXCreateOrderResp resp = handleWxCreateOrderResult(payInfo, createOrderReq, createOrderResp);
		logger.info("请求支付结束 共用时:[{}]秒", System.currentTimeMillis() - startTime);

		return resp;
	}

	/**
	 * 处理重复支付
	 * 
	 * @param existPayInfo
	 * @param channelArgs
	 * @return
	 * @throws UPCServiceException
	 */
	public HandleChannelBaseResp handleRepeatPay(UpcPayInfo existPayInfo, ChannelArgs channelArgs) throws UPCServiceException {

		HandleWxUnknownStatusResp handleResult = new HandleWxUnknownStatusResp();
		handleResult.setOrderExpire(isUpcPayInfoExpire(existPayInfo));
		return handleResult;
	}

	// 校验微信参数
	protected void validWxReqArgs(WXCreateOrderReq payReq) {
	}

	// 组装下单数据
	protected CreateOrderReq buildCreateWxOrderReq(WXCreateOrderReq payReq, UpcPayInfo payInfo) {
		return null;
	}

	protected void saveWxExtData(CreateOrderReq orderReq, UpcPayInfo payInfo, CreateOrderResp createOrderResp) {
		UpcWxExt wxext = new UpcWxExt();
		wxext.setMchOrderNo(payInfo.getMchOrderNo());
		wxext.setOpenId(orderReq.getOpenid());
		wxext.setPayNo(payInfo.getPayNo());

		wxext.setReqWxSn(orderReq.getOutTradeNo());

		wxext.setPrepayId(createOrderResp.getPrepayId());
		wxext.setRemark(createOrderResp.getCodeUrl());
		//如果是WAP支付，则保存对应的URL， 同一个订单在微信那不可能既是H5支付又是NATIVE支付
		if (StringUtils.isNotBlank(createOrderResp.getMwebUrl())) {
			wxext.setRemark(createOrderResp.getMwebUrl());
		}
		wxExtService.saveWxExtData(wxext);
	}

	protected WXCreateOrderResp handleWxCreateOrderResult(UpcPayInfo payInfo, CreateOrderReq createOrderReq, CreateOrderResp createOrderResp)
			throws UPCServiceException {
		WXCreateOrderResp resp = new WXCreateOrderResp();
		if (BaseResp.SUCCESS.equals(createOrderResp.getReturnCode()) && BaseResp.SUCCESS.equals(createOrderResp.getResultCode())) {
			// 更新订单状态为交易进行中
			UpdateUpcPayStatusParam upcParam = new UpdateUpcPayStatusParam();
			upcParam.setPayNo(payInfo.getPayNo());
			upcParam.setOriginalStatus(TradeStatus.INIT.name());
			upcParam.setTargetStatus(TradeStatus.TRADING.name());
			payManageInfoService.updatePayInfoStatus(upcParam);
			// 保存微信业务数据

			saveWxExtData(createOrderReq, payInfo, createOrderResp);
			resp.setRltCode(BaseResp.SUCCESS);
			resp.setWxPrepayId(createOrderResp.getPrepayId());
			resp.setCodeUrl(createOrderResp.getCodeUrl());
			resp.setUpcTradeNo(payInfo.getPayNo());
			resp.setMwebUrl(createOrderResp.getMwebUrl());
		} else {
			String wxErrorCode = StringUtils.isNotEmpty(createOrderResp.getErrCode()) ? createOrderResp.getErrCode() : createOrderResp
					.getReturnCode();
			// 转换微信错误码
			String upcErrorCode = UpcWxCodeUtil.transferWxErrorCode(wxErrorCode);
			String errorMsg = StringUtils.isNotEmpty(createOrderResp.getErrCodeDes()) ? createOrderResp.getErrCodeDes() : createOrderResp
					.getReturnMsg();
			resp.setRltCodeAndMsg(upcErrorCode, errorMsg);
			recordError(payInfo.getPayNo(), createOrderResp);
		}
		return resp;
	}

	private void recordError(String payNo, BaseResp createOrderResp) {
		String wxErrorCode = StringUtils.isNotEmpty(createOrderResp.getErrCode()) ? createOrderResp.getErrCode() : createOrderResp.getReturnCode();
		String wxErrorMsg = StringUtils.isNotEmpty(createOrderResp.getErrCodeDes()) ? createOrderResp.getErrCodeDes() : createOrderResp
				.getReturnMsg();
		// 记录错误

		payManageInfoService.asyncRecordError(payNo, wxErrorCode, wxErrorMsg);
	}

	public WXPayResp packagePayData(WXPayReq req, ChannelArgs channelArgs) {
		PayReq payReq = new PayReq();
		payReq.setChannelNo(req.getChannelCode());
		payReq.setPrepayId(req.getWxPrepayId());
		
		PayResp payResp = WXPayment.buildPayData(payReq, channelArgs);
		if (payResp == null) {
			return null;
		}

		WXPayResp wxPayResp = new WXPayResp();
		wxPayResp.setRltCode(BaseResp.SUCCESS);
		wxPayResp.setAppId(payResp.getAppId());
		wxPayResp.setChannelCode(req.getChannelCode());
		wxPayResp.setNonceStr(payResp.getNonceStr());
		wxPayResp.setPackageValue(payResp.getPackageValue());
		wxPayResp.setPaySign(payResp.getPaySign());
		wxPayResp.setSignType(payResp.getSignType());
		wxPayResp.setTimeStamp(payResp.getTimeStamp());
		wxPayResp.setWxWapPayStr(payResp.getWxWapPayStr());
		wxPayResp.setWxAppPayStr(payResp.getWxAppPayStr());
		return wxPayResp;
	}

	public WXPayResp packagePayCertificate(UpcPayInfo payInfo, ChannelArgs channelArgs) {
		UpcWxExt wxExt = wxExtService.queryWxExt(payInfo.getPayNo());

		WXPayReq req = new WXPayReq();
		req.setChannelCode(payInfo.getChannelCode());
		req.setWxPrepayId(wxExt.getPrepayId());
		return packagePayData(req, channelArgs);
	}

	public CloseOrderResp closeOrder(WXCloseOrderReq req, ChannelArgs channelArgs) {
		String reqWXSn = StringUtils.isEmpty(req.getMchOrderNo()) ? req.getWxOrderNo() : req.getMchOrderNo();
		CloseOrderResp closeOrderResp = WXCloseOrder.sendCloseOrderReq(reqWXSn,req.getChannelCode(), channelArgs);
		return closeOrderResp;
	}

	public RefundResp refund(UpcPayInfo formerPayInfo, UpcPayInfo refundPayInfo, ChannelArgs channelArgs) {
		RefundReq wxRefundReq = new RefundReq();
		wxRefundReq.setOutTradeNo(formerPayInfo.getMchOrderNo());
		wxRefundReq.setOutRefundNo(refundPayInfo.getMchOrderNo());
		wxRefundReq.setTotalFee(formerPayInfo.getTradeAmt().intValue());
		wxRefundReq.setRefundFee(refundPayInfo.getTradeAmt().intValue());
		wxRefundReq.setOpUserId(formerPayInfo.getChannelMchNo());
		wxRefundReq.setChannelCode(formerPayInfo.getChannelCode());
		return WXRefund.doWXRefund(wxRefundReq, channelArgs);
	}

	public WXDownloadBillResp downloadBill(WXDownloadBillReq req, ChannelArgs channelArgs) {
		DownloadBillReq downloadBill = new DownloadBillReq();
		downloadBill.setBillDate(req.getBillDate());
		downloadBill.setBillType(req.getBillType());
		DownloadBillResp billResp = WXDownloadBill.doDownloadBill(downloadBill, channelArgs);

		WXDownloadBillResp resultResp = new WXDownloadBillResp();

		if (BaseResp.SUCCESS.equals(billResp.getReturnCode()) && BaseResp.SUCCESS.equals(billResp.getResultCode())) {
			resultResp.setRltCode(BaseResp.SUCCESS);
			resultResp.setBillData(billResp.getBillData());
			resultResp.setBillDate(req.getBillDate());
			resultResp.setBillType(req.getBillType());
		} else {
			resultResp.setRltCode(billResp.getErrCode());
			resultResp.setRltMsg(billResp.getErrCodeDes());
		}

		return resultResp;
	}

	/**
	 * 处理交易流水未知未知
	 * 
	 * @param existPayInfo
	 * @param channelArgs
	 * @throws UPCServiceException
	 */
	public HandleWxUnknownStatusResp handleTradeUnknown(UpcPayInfo existPayInfo, ChannelArgs channelArgs) throws UPCServiceException {
		OrderQueryReq req = new OrderQueryReq();
		req.setOutTradeNo(existPayInfo.getReqOrderNo());
		req.setChannelNo(existPayInfo.getChannelCode());
		OrderQueryResp queryResp = WXQuery.doWXQuery(req, channelArgs);
		logger.info("调度查询微信响应数据:{}", queryResp.toString());
		String tradeStatus = TradeStatus.TRADING.name();
		String errorCode = null;
		String errorMsg = null;
		HandleWxUnknownStatusResp handleResult = new HandleWxUnknownStatusResp();
		if (BaseResp.SUCCESS.equals(queryResp.getReturnCode()) && BaseResp.SUCCESS.equals(queryResp.getResultCode())) {
			// 成功
			if (BaseResp.SUCCESS.equals(queryResp.getTradeState())) {
				tradeStatus = TradeStatus.SUCCESS.name();
			}
			// 已关闭
			else if (BaseResp.CLOSED.equals(queryResp.getTradeState())) {
				tradeStatus = TradeStatus.CLOSE.name();
			}
			// 未付款
			else if (BaseResp.NOTPAY.equals(queryResp.getTradeState())) {
				// 未支付且已失效执行关闭
				if (isUpcPayInfoExpire(existPayInfo)) {
					tradeStatus = TradeStatus.CLOSE.name();
					handleResult.setOrderExpire(true);
				} else {
					tradeStatus = TradeStatus.NOT_PAY.name();
				}

			}
			// 正在支付
			else if (BaseResp.USERPAYING.equals(queryResp.getTradeState())) {
				tradeStatus = TradeStatus.PAYING.name();

			}
			// 存在退款
			else if (BaseResp.REFUND.equals(queryResp.getTradeState())) {
				tradeStatus = TradeStatus.HAS_REFUND.name();
			}
			// 支付失败
			else if (BaseResp.PAYERROR.equals(queryResp.getTradeState())) {
				tradeStatus = TradeStatus.FAILURE.name();
			}
		} else if (WxErrorCodeType.ORDERNOTEXIST.name().equals(queryResp.getErrCode())) {
			tradeStatus = TradeStatus.CLOSE.name();
		}

		errorCode = StringUtils.isNotEmpty(queryResp.getErrCode()) ? queryResp.getErrCode() : queryResp.getReturnCode();
		errorMsg = StringUtils.isNotEmpty(queryResp.getErrCodeDes()) ? queryResp.getErrCodeDes() : queryResp.getReturnMsg();

		if (TradeStatus.CLOSE.name().equals(tradeStatus)) {
			errorCode = null;
			errorMsg = null;
		}

		// 更新统一支付渠道状态
		if (TradeStatus.SUCCESS.name().equals(tradeStatus) || TradeStatus.FAILURE.name().equals(tradeStatus)
				|| TradeStatus.CLOSE.name().equals(tradeStatus)) {
			UpcPayUnknownParam upcParam = new UpcPayUnknownParam();
			upcParam.setMchNo(existPayInfo.getMchNo());
			upcParam.setPayNo(existPayInfo.getPayNo());
			upcParam.setOriginalStatus(TradeStatus.TRADING.name());
			upcParam.setTargetStatus(tradeStatus);
			upcParam.setPayBankCode(queryResp.getBankType());
			upcParam.setRtnOrderNo(queryResp.getWxOrderNo());
			upcParam.setRtnBankCode(errorCode);
			upcParam.setRtnBankMsg(errorMsg);
			payManageInfoService.updateUpcPayUnknown(upcParam);
			handleResult.setBankType(queryResp.getBankType());
			handleResult.setWxOrderNo(queryResp.getWxOrderNo());

		}
		handleResult.setRltCode(errorCode);
		handleResult.setRltMsg(errorMsg);
		handleResult.setTradeStatus(tradeStatus);
		return handleResult;

	}

	/**
	 * 处理交易流水未知 紧急版本，和上面方法区别在于 未更新数据库数据的状态
	 * 
	 * @param existPayInfo
	 * @param channelArgs
	 * @throws UPCServiceException
	 */
	public HandleWxUnknownStatusResp handleTradeUnknownUrgency(UpcPayInfo existPayInfo, ChannelArgs channelArgs) throws UPCServiceException {
		OrderQueryReq req = new OrderQueryReq();
		req.setOutTradeNo(existPayInfo.getReqOrderNo());
		req.setChannelNo(existPayInfo.getChannelCode());
		OrderQueryResp queryResp = WXQuery.doWXQuery(req, channelArgs);
		logger.info("调度查询微信响应数据:{}", queryResp.toString());
		String tradeStatus = TradeStatus.TRADING.name();
		String errorCode = null;
		String errorMsg = null;
		HandleWxUnknownStatusResp handleResult = new HandleWxUnknownStatusResp();
		if (BaseResp.SUCCESS.equals(queryResp.getReturnCode()) && BaseResp.SUCCESS.equals(queryResp.getResultCode())) {
			// 成功
			if (BaseResp.SUCCESS.equals(queryResp.getTradeState())) {
				tradeStatus = TradeStatus.SUCCESS.name();
			}
			// 已关闭
			else if (BaseResp.CLOSED.equals(queryResp.getTradeState())) {
				tradeStatus = TradeStatus.CLOSE.name();
			}
			// 未付款
			else if (BaseResp.NOTPAY.equals(queryResp.getTradeState())) {
				// 未支付且已失效执行关闭
				if (isUpcPayInfoExpire(existPayInfo)) {
					tradeStatus = TradeStatus.CLOSE.name();
					handleResult.setOrderExpire(true);
				} else {
					tradeStatus = TradeStatus.NOT_PAY.name();
				}

			}
			// 正在支付
			else if (BaseResp.USERPAYING.equals(queryResp.getTradeState())) {
				tradeStatus = TradeStatus.PAYING.name();

			}
			// 存在退款
			else if (BaseResp.REFUND.equals(queryResp.getTradeState())) {
				tradeStatus = TradeStatus.HAS_REFUND.name();
			}
			// 支付失败
			else if (BaseResp.PAYERROR.equals(queryResp.getTradeState())) {
				tradeStatus = TradeStatus.FAILURE.name();
			}
		} else if (WxErrorCodeType.ORDERNOTEXIST.name().equals(queryResp.getErrCode())) {
			tradeStatus = TradeStatus.CLOSE.name();
		}

		errorCode = StringUtils.isNotEmpty(queryResp.getErrCode()) ? queryResp.getErrCode() : queryResp.getReturnCode();
		errorMsg = StringUtils.isNotEmpty(queryResp.getErrCodeDes()) ? queryResp.getErrCodeDes() : queryResp.getReturnMsg();

		handleResult.setRltCode(errorCode);
		handleResult.setRltMsg(errorMsg);
		handleResult.setTradeStatus(tradeStatus);
		return handleResult;

	}

	public boolean isUpcPayInfoExpire(UpcPayInfo existPayInfo) throws UPCServiceException {
		Date tradeBeginTime = existPayInfo.getBeginTime();
		long configureExpireTime = Long.valueOf(Property.getProperty("WX_ORDER_EXPIRE_TIME"));
		int intervalTime = payManageInfoService.getDBInterval(DateUtil.format(tradeBeginTime, DateUtil.YYYY_MM_DD_HH_MM_SS));
		logger.info("生成订单时间：[{}], 配置过期分钟:[{}], 日期间隔:[{}]", new Object[] { tradeBeginTime.getTime(), configureExpireTime, intervalTime });

		return intervalTime > configureExpireTime;
	}

	/**
	 * 组装支付流水
	 * 
	 * @param payReq
	 * @param channelArgs
	 * @return
	 */
	protected UpcPayInfo buildUpcPayInfo(WXCreateOrderReq payReq, ChannelArgs channelArgs) {
		UpcPayInfo payInfo = new UpcPayInfo();
		payInfo.setPayNo(upcPayInfoDao.getPayNo());
		payInfo.setChannelCategoryCode(ChannelType.WX.name());
		payInfo.setChannelCode(payReq.getChannelCode());
		payInfo.setMchNo(payReq.getMchNo());
		
		if("WX_JS_PROGRAM".equals(payReq.getChannelCode()))
		{
			payInfo.setChannelMchNo(channelArgs.getValueByKey("program_mch_id"));
		}
		else
		{
			payInfo.setChannelMchNo(channelArgs.getValueByKey("mch_id"));
		}
		payInfo.setMchOrderNo(payReq.getMchOrderNo());
		payInfo.setUseMchnoReq(payReq.isUseMchOrderNo() ? "Y" : "N");

		payInfo.setReqOrderNo(payReq.isUseMchOrderNo() ? payReq.getMchOrderNo() : payInfo.getPayNo());
		payInfo.setTradeType(TradeType.PAY.name());
		payInfo.setTradeFee(0L);
		payInfo.setTradeAmt(payReq.getTradeAmount());
		payInfo.setSystemSource(payReq.getSystemSource());
		payInfo.setCcy(CurrencyType.RMB.name());
		payInfo.setStatus(TradeStatus.INIT.name());
		payInfo.setProductName(payReq.getProductName());
		payInfo.setProductDesc(payReq.getProductDesc());

		payInfo.setUppOrderNo(payReq.getUppOrderNo());
		// 设置通知地址
		String notifyUrl = String.format("%s/upc/{0}/notify", Property.getProperty("OUT_SYF_UPC_URI"));
		payInfo.setMchNotifyUrl(new MessageFormat(notifyUrl).format(new Object[] { payInfo.getPayNo() }));
		payInfo.setRemark(payReq.getRemark());
		
		//微信支付增加是否开发票
		payInfo.setReceipt(payReq.isReceipt() ? YesOrNo.Y.name() : YesOrNo.N.name());

		return payInfo;
	}

	/**
	 * 组装下单请求数据
	 * 
	 * @param tradeType
	 * @param payReq
	 * @param payInfo
	 * @return
	 */
	protected CreateOrderReq buildCreateOrderReq(String tradeType, WXCreateOrderReq payReq, UpcPayInfo payInfo) {
		CreateOrderReq req = new CreateOrderReq();
		req.setBody(payReq.getProductName());
		req.setDetail(payReq.getProductDesc());
		req.setChannelNo(payReq.getChannelCode());
		req.setNotifyUrl(payInfo.getMchNotifyUrl());
		req.setOpenid(payReq.getOpenid());
		req.setOutTradeNo(payInfo.getReqOrderNo());
		req.setSpbillCreateIp(payReq.getRequestIp());
		req.setTotalFee(payReq.getTradeAmount().intValue());
		req.setTradeType(tradeType);
		req.setDeviceInfo(payReq.getTerminalNo());
		req.setLimitPay(payReq.getLimitPay());
		req.setTimeExpire(payReq.getExpireTime() == null ? null : DateUtil.format(payReq.getExpireTime(), "yyyyMMddHHmmss"));
		req.setAttach(payReq.getRemark());
		req.setReceipt(payReq.isReceipt() ? YesOrNo.Y.name() : YesOrNo.N.name());
		return req;
	}
	
}
