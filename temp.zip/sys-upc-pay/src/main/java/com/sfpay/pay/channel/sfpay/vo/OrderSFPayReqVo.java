/**
 * =================================================================
 * 版权所有 2011-2020 顺丰恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.pay.channel.sfpay.vo;

public class OrderSFPayReqVo extends SfPayBaseProtocal {
	private static final long serialVersionUID = -2047332193329585399L;

	/**
	 * 商户号
	 */
	private String merchantId;

	/**
	 * 商户订单号
	 */
	private String orderId;

	/**
	 * 订单金额，单位：分
	 */
	private Long amt;

	/**
	 * 币种，默认是RMB
	 */
	private String ccy;

	/**
	 * 订单开始时间，格式：yyyyMMddHHmmss
	 */
	private String orderBeginTime;

	/**
	 * 商品名称
	 */
	private String goodsName;

	/**
	 * 商品描述
	 */
	private String goodsDesc;

	/**
	 * 商品对应链接地址
	 */
	private String goodsUrl;

	/**
	 * 商户业务类型
	 */
	private String merBusinessType;

	/**
	 * 商户附加信息
	 */
	private String reserved;

	/**
	 * 商户异步通知地址
	 */
	private String notifyUrl;

	/**
	 * 客户端Ip
	 */
	private String clientIp;

	/**
	 * 扩展参数1
	 */
	private String ext1;

	/**
	 * 扩展参数2
	 */
	private String ext2;

	/**
	 * 扩展参数1
	 */
	private String ext3;

	/**
	 * 订单过期时间，时间格式：yyyyMMddHHmmss
	 */
	private String orderExpDate;
	/**
	 * 交易场景码
	 */
	private String tradeScene;
	/**
	 * 会员号
	 */
	private String memberNo;

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getOrderId() {
		return orderId;
	}

	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}

	public Long getAmt() {
		return amt;
	}

	public void setAmt(Long amt) {
		this.amt = amt;
	}

	public String getCcy() {
		return ccy;
	}

	public void setCcy(String ccy) {
		this.ccy = ccy;
	}

	public String getOrderBeginTime() {
		return orderBeginTime;
	}

	public void setOrderBeginTime(String orderBeginTime) {
		this.orderBeginTime = orderBeginTime;
	}

	public String getGoodsName() {
		return goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

	public String getGoodsDesc() {
		return goodsDesc;
	}

	public void setGoodsDesc(String goodsDesc) {
		this.goodsDesc = goodsDesc;
	}

	public String getGoodsUrl() {
		return goodsUrl;
	}

	public void setGoodsUrl(String goodsUrl) {
		this.goodsUrl = goodsUrl;
	}

	public String getMerBusinessType() {
		return merBusinessType;
	}

	public void setMerBusinessType(String merBusinessType) {
		this.merBusinessType = merBusinessType;
	}

	public String getReserved() {
		return reserved;
	}

	public void setReserved(String reserved) {
		this.reserved = reserved;
	}

	public String getNotifyUrl() {
		return notifyUrl;
	}

	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}

	public String getClientIp() {
		return clientIp;
	}

	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}

	public String getExt1() {
		return ext1;
	}

	public void setExt1(String ext1) {
		this.ext1 = ext1;
	}

	public String getExt2() {
		return ext2;
	}

	public void setExt2(String ext2) {
		this.ext2 = ext2;
	}

	public String getExt3() {
		return ext3;
	}

	public void setExt3(String ext3) {
		this.ext3 = ext3;
	}

	public String getOrderExpDate() {
		return orderExpDate;
	}

	public void setOrderExpDate(String orderExpDate) {
		this.orderExpDate = orderExpDate;
	}

	public String getTradeScene() {
		return tradeScene;
	}

	public void setTradeScene(String tradeScene) {
		this.tradeScene = tradeScene;
	}

	public String getMemberNo() {
		return memberNo;
	}

	public void setMemberNo(String memberNo) {
		this.memberNo = memberNo;
	}

}
