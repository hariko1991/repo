package com.sfpay.pay.channel;

import com.sfpay.upc.domain.alipay.AlipayCreateOrderReq;
import com.sfpay.upc.domain.alipay.AlipayCreateOrderResp;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.exception.UPCServiceException;

/**
 * 
 * 类说明：<br>
 * 支付宝渠道服务
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-18
 */
public interface IAlipayChannelService extends IBaseChannelService {

	/**
	 * 下单
	 * 
	 * @param req
	 * @param isOrderExpire
	 * @param existPayInfo
	 * @param channelArgs
	 * @return
	 * @throws UPCServiceException
	 */
	public AlipayCreateOrderResp createPayOrder(AlipayCreateOrderReq req, ChannelArgs channelArgs)
			throws UPCServiceException;

	/**
	 * 扫码支付下单(支付宝条码支付)
	 * 
	 * @param req
	 * @param isOrderExpire
	 * @param existPayInfo
	 * @param channelArgs
	 * @return
	 * @throws UPCServiceException
	 */
	public AlipayCreateOrderResp createBCOrder(AlipayCreateOrderReq req, ChannelArgs channelArgs)
			throws UPCServiceException;

}
