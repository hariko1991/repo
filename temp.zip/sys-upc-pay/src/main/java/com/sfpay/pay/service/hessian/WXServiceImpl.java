package com.sfpay.pay.service.hessian;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.alipay.enums.AlipayErrorCode;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.core.util.JsonUtil;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.pay.channel.IWXChannelService;
import com.sfpay.pay.channel.wx.WxBaseChannelService;
import com.sfpay.pay.domain.HandleRepeatPay;
import com.sfpay.pay.domain.UpcRequestContext;
import com.sfpay.pay.domain.UpcWxExt;
import com.sfpay.pay.domain.UpdateUpcPayInfoParam;
import com.sfpay.pay.factory.PayChannelFactory;
import com.sfpay.pay.service.impl.UpcPayInfoManageService;
import com.sfpay.pay.service.impl.WxExtService;
import com.sfpay.pay.util.UpcWxCodeUtil;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.upc.QueryUpcPayParam;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.upc.UpcPayUnknownParam;
import com.sfpay.upc.domain.upc.UpcRefundQueryReq;
import com.sfpay.upc.domain.upc.UpdateUpcPayStatusParam;
import com.sfpay.upc.domain.wx.UpcWXOpenIdReq;
import com.sfpay.upc.domain.wx.UpcWXOpenIdResp;
import com.sfpay.upc.domain.wx.WXCloseOrderReq;
import com.sfpay.upc.domain.wx.WXCloseOrderResp;
import com.sfpay.upc.domain.wx.WXCreateOrderReq;
import com.sfpay.upc.domain.wx.WXCreateOrderResp;
import com.sfpay.upc.domain.wx.WXDownloadBillReq;
import com.sfpay.upc.domain.wx.WXDownloadBillResp;
import com.sfpay.upc.domain.wx.WXGetAccessTokenResp;
import com.sfpay.upc.domain.wx.WXMchInfoResp;
import com.sfpay.upc.domain.wx.WXOrderQueryReq;
import com.sfpay.upc.domain.wx.WXOrderQueryResp;
import com.sfpay.upc.domain.wx.WXPayReq;
import com.sfpay.upc.domain.wx.WXPayResp;
import com.sfpay.upc.domain.wx.WXRefundQueryReq;
import com.sfpay.upc.domain.wx.WXRefundQueryResp;
import com.sfpay.upc.domain.wx.WXRefundReq;
import com.sfpay.upc.domain.wx.WXRefundResp;
import com.sfpay.upc.domain.wx.WxRefundDetail;
import com.sfpay.upc.enums.ChannelType;
import com.sfpay.upc.enums.CurrencyType;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.enums.TradeType;
import com.sfpay.upc.exception.UPCServiceException;
import com.sfpay.upc.service.IWXService;
import com.sfpay.wx.domain.BaseResp;
import com.sfpay.wx.domain.CloseOrderResp;
import com.sfpay.wx.domain.GetAccessTokenResp;
import com.sfpay.wx.domain.OrderQueryReq;
import com.sfpay.wx.domain.OrderQueryResp;
import com.sfpay.wx.domain.RefundResp;
import com.sfpay.wx.function.WXGetAccessToken;
import com.sfpay.wx.function.WXGetCode;
import com.sfpay.wx.function.WXQuery;
import com.sfpay.wx.util.ConfigKeyUtils;

/**
 * 
 * 类说明：<br>
 * 微信
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-18
 */
@Service
@HessianExporter("/upc/wxService")
public class WXServiceImpl extends BasePayChannelService implements IWXService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	@Resource
	private WxBaseChannelService wxBaseChannelService;
	@Resource
	private WxExtService wxExtService;
	@Resource
	private UpcPayInfoManageService payManageInfoService;

	@Override
	public WXCreateOrderResp createPayOrder(WXCreateOrderReq req) {
		logger.info("微信支付下单请求参数:{}", req.toString());
		try {
			// 校验下单参数
			validCreateWxOrderReqArgs(req);

			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());
			// 非空校验
			IWXChannelService wxChannelService = PayChannelFactory.getWechatTradeChannel(req.getChannelCode());
			if (wxChannelService == null) {
				throw new ServiceException(UpcConstants.INVALID_CHANNEL_CODE, "渠道编码不合法，渠道编码：" + req.getChannelCode());
			}
			// 查询本地流水状态

			UpcPayInfo existPayInfo = getUpcPayInfo(null, ChannelType.WX.name(), req.getMchNo(), req.getMchOrderNo());

			// 成功 失败 退款 不能重新下单
			if (existPayInfo != null) {

				// 处理重复支付
				HandleRepeatPay repeatPay = handleChannelRepeatPay(req.getChannelCode(), context, existPayInfo);
				return repeatPay.getWxCreateOrderResp();
			}

			WXCreateOrderResp createOrderResp = wxChannelService.createPayOrder(req, context.getChannelArgs());
			logger.info("微信支付下单返回数据:[{}]", createOrderResp.toString());
			return createOrderResp;

		} catch (ServiceException e) {
			logger.error("微信支付下单异常 req:" + req.toString(), e);
			return new WXCreateOrderResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("微信支付下单异常req:" + req.toString(), e);
			return new WXCreateOrderResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public WXPayResp packagePayData(WXPayReq req) {
		logger.info("微信支付组装支付凭证请求参数:{}", req.toString());
		if (req == null || StringUtils.isEmpty(req.getWxPrepayId()) || StringUtils.isEmpty(req.getChannelCode())) {
			return new WXPayResp(UpcConstants.PARAM_NULL, "wxprepayId 或渠道编号不能为空");
		}

		try {
			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());
			WXPayResp payData = wxBaseChannelService.packagePayData(req, context.getChannelArgs());
			logger.info("微信支付组装支付凭证请求参数:{}", payData.toString());
			return payData;
		} catch (ServiceException e) {
			logger.error("微信组装支付凭证异常 req:" + req.toString(), e);
			return new WXPayResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("组装微信数据下单异常 req:" + req.toString(), e);
			return new WXPayResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public WXOrderQueryResp orderQuery(WXOrderQueryReq req) {

		logger.info("微信支付订单查询请求参数:{}", req.toString());
		// 验证参数
		if (StringUtils.isEmpty(req.getMchOrderNo()) && StringUtils.isEmpty(req.getWxOrderNo())) {
			return new WXOrderQueryResp(UpcConstants.PARAM_NULL, "商户订单和微信订单不能同时为空");
		}
		try {
			getRequestContext(req.getMchNo(), req.getChannelCode());
			// 查询流水状态
			UpcPayInfo payInfo = getUpcPayInfo(req.getChannelCode(), req.getMchNo(), req.getMchOrderNo());
			if (payInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}

			UpcWxExt wxExt = wxExtService.queryWxExt(payInfo.getPayNo());
			WXOrderQueryResp resp = buildOrderQueryResp(req, payInfo, wxExt);
			logger.info("微信支付订单查询响应参数:{}", resp.toString());
			return resp;
		} catch (ServiceException e) {
			logger.error("订单查询异常 req:" + req.toString(), e);
			return new WXOrderQueryResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("订单查询异常 req:" + req.toString(), e);
			return new WXOrderQueryResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public WXOrderQueryResp orderQueryThirdPay(WXOrderQueryReq req) {
		// 验证参数
		if (StringUtils.isEmpty(req.getMchOrderNo()) && StringUtils.isEmpty(req.getWxOrderNo())) {
			return new WXOrderQueryResp(UpcConstants.PARAM_NULL, "商户订单和微信订单不能同时为空");
		}
		try {
			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());
			UpcPayInfo payInfo = getUpcPayInfo(req.getChannelCode(), req.getMchNo(), req.getMchOrderNo());
			if (payInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}

			OrderQueryReq reqWx = new OrderQueryReq();
			reqWx.setOutTradeNo(payInfo.getReqOrderNo());
			reqWx.setChannelNo(payInfo.getChannelCode());
			OrderQueryResp result = WXQuery.doWXQuery(reqWx, context.getChannelArgs());
			WXOrderQueryResp resp = buildWxResp(result, payInfo);

			return resp;
		} catch (ServiceException e) {
			logger.error("订单查询第三方异常 req:" + req.toString(), e);
			return new WXOrderQueryResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("订单查询第三方异常 req:" + req.toString(), e);
			return new WXOrderQueryResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public WXCloseOrderResp closeOrder(WXCloseOrderReq req) {
		logger.info("微信关单请求参数:[{}]", req.toString());
		try {

			validCloseOrderReqParams(req);

			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());
			// 查询本地流水状态
			UpcPayInfo payInfo = getUpcPayInfo(req.getChannelCode(), req.getMchNo(), req.getMchOrderNo());
			if (payInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}
			validateCloseOrderStatus(payInfo);
			
			// 已经关闭提示关单成功
			if (TradeStatus.CLOSE.name().equals(payInfo.getStatus())) {
				return new WXCloseOrderResp(UpcConstants.SUCCESS, "关单成功");
			}
			
			CloseOrderResp closeOrderResp = wxBaseChannelService.closeOrder(req, context.getChannelArgs());
			// 关单成功
			WXCloseOrderResp resultResp = new WXCloseOrderResp();

			if ((BaseResp.SUCCESS.equals(closeOrderResp.getReturnCode()) && BaseResp.SUCCESS.equals(closeOrderResp.getResultCode()))
					|| orderNotExistsAndExpres(closeOrderResp.getErrCode(), payInfo)) {
				// 修改订单状态
				UpdateUpcPayStatusParam updateOrderStatusReq = new UpdateUpcPayStatusParam();
				updateOrderStatusReq.setPayNo(payInfo.getPayNo());
				updateOrderStatusReq.setMchNo(payInfo.getMchNo());
				updateOrderStatusReq.setOriginalStatus(TradeStatus.TRADING.name());
				updateOrderStatusReq.setTargetStatus(TradeStatus.CLOSE.name());

				payManageInfoService.updatePayInfoStatus(updateOrderStatusReq);
				logger.info("修改支付流水状态为关闭成功");
				resultResp.setRltCode(UpcConstants.SUCCESS);
			} else {

				String upcErrorCode = UpcWxCodeUtil.transferWxErrorCode(StringUtils.isNotEmpty(closeOrderResp.getErrCode()) ? closeOrderResp
						.getErrCode() : "FAIL");
				String errorMsg = StringUtils.isNotEmpty(closeOrderResp.getErrCodeDes()) ? closeOrderResp.getErrCodeDes() : closeOrderResp
						.getReturnMsg();
				resultResp.setRltCode(upcErrorCode);
				resultResp.setRltMsg(errorMsg);
				// 记录错误
				recordWxError(payInfo.getPayNo(), closeOrderResp);
			}
			logger.info("微信关单响应参数:[{}]", resultResp.toString());

			return resultResp;

		} catch (ServiceException e) {
			logger.error("关闭订单异常req:" + req.toString(), e);
			return new WXCloseOrderResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("关闭订单异常req:" + req.toString(), e);
			return new WXCloseOrderResp(e.getCode(), e.getMsg());
		}
	}

	private boolean orderNotExistsAndExpres(String errorCode, UpcPayInfo existPayInfo) {
		try {

			if (AlipayErrorCode.TRADE_NOT_EXIST.getCode().equals(errorCode) && wxBaseChannelService.isUpcPayInfoExpire(existPayInfo)) {
				return true;
			}
		} catch (UPCServiceException e) {
		}
		return false;
	}

	@Override
	public WXRefundResp refund(WXRefundReq req) {

		logger.info("微信退款请求参数:[{}]", req.toString());
		try {
			validWxRefundReqArgs(req);

			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());
			// 验证商户退款流水
			WXRefundResp wxRefundResp = validateMchRefundWater(req);
			if (wxRefundResp != null)
				return wxRefundResp;
			// 1.查询本地流水状态
			UpcPayInfo formerPayInfo = getUpcPayInfo(req.getChannelCode(), req.getMchNo(), req.getMchOrderNo());
			if (formerPayInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}

			// 只有支付成功的才可以退款
			if (!UpcConstants.SUCCESS.equals(formerPayInfo.getStatus())) {
				return new WXRefundResp(UpcConstants.ONLY_SUCC_ORDER_CAN_REFUND, "只有交易成功才可以退款");
			}

			if (req.getRefundFee().longValue() > formerPayInfo.getTradeAmt().longValue()) {
				return new WXRefundResp(UpcConstants.REFUND_AMOUNT_GT_TRADE_AMOUNT, "退款金额大于支付总金额");
			}

			// 2.查询已退款的流水记录
			UpcRefundQueryReq refundQueryReq = new UpcRefundQueryReq();
			refundQueryReq.setMchNo(req.getMchNo());
			refundQueryReq.setOldPayNo(formerPayInfo.getPayNo());
			List<UpcPayInfo> refundPayInfoList = payManageInfoService.queryRefundPayInfo(refundQueryReq);

			// 3. 校验已退款金额
			if (refundPayInfoList != null && !refundPayInfoList.isEmpty()) {

				long totalPayAmount = formerPayInfo.getTradeAmt().longValue();
				long haveRefundAmount = 0; // 已退款金额
				for (UpcPayInfo p : refundPayInfoList) {

					haveRefundAmount += p.getTradeAmt().longValue();
				}

				if (req.getRefundFee().longValue() + haveRefundAmount > totalPayAmount) {
					logger.error("已退款金额大于支付总金额 总金额:[{}], 已退款:[{}] ", totalPayAmount, haveRefundAmount);
					return new WXRefundResp(UpcConstants.REFUND_AMOUNT_GT_TRADE_AMOUNT, "已退款金额大于支付总金额");
				}
			}

			// 3. 生成退款流水
			UpcPayInfo refundPayInfo = buildRefundPayInfo(req, formerPayInfo, context);
			logger.info("开始生成支付流水...");
			payManageInfoService.createPayInfo(refundPayInfo);
			logger.info("结束生成支付流水:payNo:[{}]...", refundPayInfo.getPayNo());
			// 4. 调用微信退款
			RefundResp refundResp = wxBaseChannelService.refund(formerPayInfo, refundPayInfo, context.getChannelArgs());
			// 5.退款处理
			UpdateUpcPayInfoParam updatePayReq = buildUpdateRefundData(refundPayInfo, refundResp);

			payManageInfoService.updatePayInfo(updatePayReq);
			logger.info("修改支付流水状态为退款进行中");
			WXRefundResp resultResp = new WXRefundResp();

			if (TradeStatus.REFUND_ACCEPTED.name().equals(updatePayReq.getTargetStatus())) {
				resultResp.setRltCode(UpcConstants.SUCCESS);
				resultResp.setWxOrderNo(formerPayInfo.getRtnOrderNo());
				resultResp.setMchOrderNo(formerPayInfo.getMchOrderNo());
				resultResp.setMchRefundNo(refundPayInfo.getMchOrderNo());
				resultResp.setWxRefundId(refundResp.getRefundId());
				resultResp.setTradeAmount(formerPayInfo.getTradeAmt());
				resultResp.setRefundFee(refundPayInfo.getTradeAmt());
				resultResp.setStatus(TradeStatus.REFUND_ACCEPTED.name());
			} else {
				String upcErrorCode = UpcWxCodeUtil.transferWxErrorCode(updatePayReq.getRtnCode());
				String errorMsg = updatePayReq.getRtnMsg();
				resultResp.setRltCode(upcErrorCode);
				resultResp.setRltMsg(errorMsg);
				resultResp.setStatus(TradeStatus.REFUND_FAIL.name());

				// 记录错误
				recordWxError(refundPayInfo.getPayNo(), refundResp);
				// 发送失败mq
				sendMqAndRecordToUpp(refundPayInfo, TradeStatus.REFUND_FAIL, upcErrorCode, errorMsg);
			}
			logger.info("退款响应结果:[{}]", resultResp.toString());
			return resultResp;

		} catch (ServiceException e) {
			logger.error("退款异常 req:" + req.toString(), e);
			return new WXRefundResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("退款异常 req:" + req.toString(), e);
			return new WXRefundResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public void handleWxNotify(UpcPayUnknownParam upcParam) throws UPCServiceException {

		payManageInfoService.updateUpcPayUnknown(upcParam);
		logger.error("更新支付流水成功payNo:{}", upcParam.getPayNo());

		wxExtService.updateOpenidToWxExt(upcParam.getPayNo(), upcParam.getOpenid());

	}

	private WXRefundResp validateMchRefundWater(WXRefundReq req) throws UPCServiceException {
		QueryUpcPayParam payParam = new QueryUpcPayParam();
		payParam.setChannelCode(req.getChannelCode());
		payParam.setMchNo(req.getMchNo());
		payParam.setMchOrderNo(req.getMchRefundNo());
		UpcPayInfo payInfo = payManageInfoService.queryPayInfo(payParam);
		WXRefundResp refundResp = null;
		if (payInfo != null) {
			refundResp = new WXRefundResp();

			String errorCode = null;
			String errorMsg = null;
			if (TradeStatus.REFUND_ACCEPTED.name().equals(payInfo.getStatus())) {
				errorCode = UpcConstants.ORDER_IS_REFUND_PROC;
				errorMsg = "该订单退款已受理,无需再次退款";
			} else if (TradeStatus.REFUND_SUCC.name().equals(payInfo.getStatus())) {
				errorCode = UpcConstants.ORDER_IS_REFUND_SUCC;
				errorMsg = "该订单退款已成功";
			} else if (TradeStatus.REFUND_FAIL.name().equals(payInfo.getStatus())) {
				errorCode = UpcConstants.ORDER_IS_REFUND_FAIL;
				errorMsg = "该订单退款已失败";
			}
			refundResp.setRltCode(errorCode);
			refundResp.setRltMsg(errorMsg);
			refundResp.setStatus(payInfo.getStatus());
			refundResp.setWxRefundId(payInfo.getRtnOrderNo());
		}
		return refundResp;

	}

	@Override
	public WXRefundQueryResp refundQuery(WXRefundQueryReq req) {

		logger.info("退款查询请求参数:[{}]", req.toString());

		if (StringUtils.isEmpty(req.getMchOrderNo()) && StringUtils.isEmpty(req.getMchRefundNo()) && StringUtils.isEmpty(req.getWxOrderNo())
				&& StringUtils.isEmpty(req.getWxRefundId())) {
			return new WXRefundQueryResp(UpcConstants.PARAM_NULL, "必填字段不能为空");
		}

		try {
			getRequestContext(req.getMchNo(), req.getChannelCode());

			UpcRefundQueryReq refundQueryReq = new UpcRefundQueryReq();
			refundQueryReq.setMchNo(req.getMchNo());
			refundQueryReq.setMchOrderNo(req.getMchOrderNo());
			List<UpcPayInfo> refundList = payManageInfoService.queryRefundPayInfo(refundQueryReq);

			WXRefundQueryResp refundResp = new WXRefundQueryResp();
			List<WxRefundDetail> wxRefundDetailList = new ArrayList<WxRefundDetail>();

			// 退款为空
			if (refundList == null || refundList.isEmpty()) {
				if (StringUtils.isNotEmpty(req.getMchOrderNo()) || StringUtils.isNotEmpty(req.getWxOrderNo())) {
					QueryUpcPayParam payParam = new QueryUpcPayParam();
					payParam.setMchNo(req.getMchNo());
					payParam.setChannelCode(req.getChannelCode());
					payParam.setMchOrderNo(req.getMchOrderNo());
					payParam.setRtnOrderNo(req.getWxOrderNo());
					UpcPayInfo formerPayInfo = payManageInfoService.queryPayInfo(payParam);
					if (formerPayInfo == null) {
						return new WXRefundQueryResp(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
					}

					refundResp.setRltCode(UpcConstants.SUCCESS);
					refundResp.setMchOrderNo(formerPayInfo.getMchOrderNo());
					refundResp.setRefundCount(0);
					refundResp.setTradeAmount(formerPayInfo.getTradeAmt());
					refundResp.setWxOrderNo(formerPayInfo.getRtnOrderNo());
					refundResp.setWxRefundDetailList(wxRefundDetailList);
				}
			} else {
				WxRefundDetail refundDetail = null;
				for (UpcPayInfo pi : refundList) {
					refundDetail = new WxRefundDetail();
					refundDetail.setMchRefundNo(pi.getMchOrderNo());
					refundDetail.setRefundFee(pi.getTradeAmt());
					refundDetail.setRefundStatus(pi.getStatus());
					refundDetail.setWxRefundId(pi.getRtnOrderNo());
					wxRefundDetailList.add(refundDetail);
				}
				QueryUpcPayParam queryReq = new QueryUpcPayParam();
				queryReq.setMchOrderNo(refundList.get(0).getOldMchOrderNo());
				// 查询本地流水状态
				UpcPayInfo payInfo = payManageInfoService.queryPayInfo(queryReq);
				if (payInfo == null) {
					return new WXRefundQueryResp(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
				}
				refundResp.setRltCode(UpcConstants.SUCCESS);
				refundResp.setMchOrderNo(payInfo.getMchOrderNo());
				refundResp.setTradeAmount(payInfo.getTradeAmt());
				refundResp.setWxOrderNo(payInfo.getRtnOrderNo());
				refundResp.setWxRefundDetailList(wxRefundDetailList);
				refundResp.setRefundCount(refundList.size());
			}
			return refundResp;
		} catch (ServiceException e) {
			logger.error("退款查询异常 req:" + req.toString(), e);
			return new WXRefundQueryResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("退款查询 req:" + req.toString(), e);
			return new WXRefundQueryResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public WXDownloadBillResp downloadBill(WXDownloadBillReq req) {
		try {
			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());
			return wxBaseChannelService.downloadBill(req, context.getChannelArgs());
		} catch (ServiceException e) {
			logger.error("下载对账单查询", e);
			return new WXDownloadBillResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("下载对账单查询", e);
			return new WXDownloadBillResp(e.getCode(), e.getMsg());
		}
	}

	private WXOrderQueryResp buildWxResp(OrderQueryResp queryResp, UpcPayInfo payInfo) {
		logger.info("调度查询微信响应数据:{}", queryResp.toString());
		WXOrderQueryResp resp = new WXOrderQueryResp();
		if (BaseResp.SUCCESS.equals(queryResp.getReturnCode()) && BaseResp.SUCCESS.equals(queryResp.getResultCode())) {
			resp.setRltCode(UpcConstants.SUCCESS);
			resp.setChannelCode(payInfo.getChannelCode());
			resp.setBankType(queryResp.getBankType());
			resp.setTradeStatus(queryResp.getTradeState());
			resp.setTradeAmount(payInfo.getTradeAmt());
			resp.setWxOrderNo(queryResp.getWxOrderNo());
			resp.setMchOrderNo(payInfo.getMchOrderNo());
			resp.setRemark(payInfo.getRemark());
		} else {
			resp.setRltCode(StringUtils.isNotBlank(queryResp.getErrCode()) ? queryResp.getErrCode() : "FAIL");

			resp.setRltMsg(StringUtils.isNotBlank(queryResp.getErrCodeDes()) ? queryResp.getErrCodeDes() : queryResp.getReturnMsg());
		}

		return resp;
	}

	private WXOrderQueryResp buildOrderQueryResp(WXOrderQueryReq req, UpcPayInfo payInfo, UpcWxExt wxExt) {
		WXOrderQueryResp resp = new WXOrderQueryResp();
		if (wxExt != null) {
			resp.setOpenid(wxExt.getOpenId());
			resp.setWxPrepayId(wxExt.getPrepayId());
		}
		resp.setRltCode(UpcConstants.SUCCESS);
		resp.setChannelCode(req.getChannelCode());
		resp.setBankType(payInfo.getPayBankType());
		resp.setTradeStatus(payInfo.getStatus());
		resp.setTradeAmount(payInfo.getTradeAmt());
		resp.setWxOrderNo(payInfo.getRtnOrderNo());
		resp.setMchOrderNo(payInfo.getMchOrderNo());
		resp.setTimeEnd(payInfo.getEndTime());
		resp.setRemark(payInfo.getRemark());
		return resp;
	}

	private UpcPayInfo buildRefundPayInfo(WXRefundReq req, UpcPayInfo formerPayInfo, UpcRequestContext context) {
		UpcPayInfo payInfo = new UpcPayInfo();
		payInfo.setChannelCode(req.getChannelCode());
		payInfo.setMchNo(req.getMchNo());
		payInfo.setPayNo(payManageInfoService.getPayNo());
		payInfo.setChannelMchNo(context.getMchMap().getChannelMchNo());
		payInfo.setMchOrderNo(req.getMchRefundNo());
		payInfo.setUseMchnoReq("Y");
		payInfo.setReqOrderNo(req.getMchRefundNo());
		payInfo.setTradeType(TradeType.PAY_REFUND.name());
		payInfo.setTradeFee(0L);
		payInfo.setTradeAmt(req.getRefundFee());
		payInfo.setSystemSource(formerPayInfo.getSystemSource());
		payInfo.setCcy(CurrencyType.RMB.name());
		payInfo.setStatus(TradeStatus.REFUND_PROC.name());
		payInfo.setMchNotifyUrl(formerPayInfo.getMchNotifyUrl());
		payInfo.setUppOrderNo(req.getUppRefundNo());
		payInfo.setOldUppOrderNo(formerPayInfo.getUppOrderNo());
		payInfo.setOldPayNo(formerPayInfo.getPayNo());
		payInfo.setOldMchOrderNo(formerPayInfo.getMchOrderNo());
		payInfo.setOldRtnOrderNo(formerPayInfo.getRtnOrderNo());
		return payInfo;
	}

	private void validCreateWxOrderReqArgs(WXCreateOrderReq payReq) {

		if (payReq == null) {
			throw new ServiceException(UpcConstants.PARAM_NULL);
		}

		if (StringUtils.isEmpty(payReq.getMchNo())) {
			throw new ServiceException(UpcConstants.MCH_NO_IS_NULL, "商户号为空");
		} else if (StringUtils.isEmpty(payReq.getChannelCode())) {
			throw new ServiceException(UpcConstants.CHANNEL_CODE_IS_NULL, "支付渠道编号为空");
		} else if (StringUtils.isEmpty(payReq.getMchOrderNo())) {
			throw new ServiceException(UpcConstants.MCH_ORDER_NO_IS_NULL, "商户订单号为空");
		} else if (StringUtils.isEmpty(payReq.getProductName())) {
			throw new ServiceException(UpcConstants.MCH_PRODUCT_NAME_IS_NULL, "商品名为空");

		} else if (payReq.getTradeAmount() == null || payReq.getTradeAmount().longValue() <= 0) {
			throw new ServiceException(UpcConstants.TRADE_AMOUNT_IS_NULL, "交易金额为空或不合法");
		} else if (StringUtils.isEmpty(payReq.getRequestIp())) {

			throw new ServiceException(UpcConstants.REQUEST_IP_IS_NULL, "客户端请求ip为空");
		} else if (StringUtils.isEmpty(payReq.getSystemSource())) {
			throw new ServiceException(UpcConstants.SYSTEM_SOURCE_IS_NULL, "系统来源为空");
		}
	}

	private void validWxRefundReqArgs(WXRefundReq req) {
		if (req == null) {
			throw new ServiceException(UpcConstants.PARAM_NULL);
		}

		if (StringUtils.isEmpty(req.getMchNo())) {
			throw new ServiceException(UpcConstants.MCH_NO_IS_NULL, "商户号为空");
		} else if (StringUtils.isEmpty(req.getChannelCode())) {
			throw new ServiceException(UpcConstants.CHANNEL_CODE_IS_NULL, "支付渠道编号为空");
		} else if (StringUtils.isEmpty(req.getMchRefundNo())) {
			throw new ServiceException(UpcConstants.MCH_REFUND_ORDER_NO_IS_NULL, "商户退款订单号为空");

		} else if (req.getRefundFee() == null || req.getRefundFee().longValue() <= 0) {
			throw new ServiceException(UpcConstants.INVALID_REFUND_AMOUNT, "退款金额无效");
		} else if (StringUtils.isEmpty(req.getMchOrderNo()) && StringUtils.isEmpty(req.getWxOrderNo())) {
			throw new ServiceException(UpcConstants.MCH_ORDER_NO_IS_NULL, "商户订单号或微信订单号为空");
		}
	}

	private void validCloseOrderReqParams(WXCloseOrderReq req) {
		if (req == null) {
			throw new ServiceException(UpcConstants.PARAM_NULL);
		}

		if (StringUtils.isEmpty(req.getMchNo())) {
			throw new ServiceException(UpcConstants.MCH_NO_IS_NULL, "商户号为空");
		} else if (StringUtils.isEmpty(req.getMchOrderNo()) && StringUtils.isEmpty(req.getWxOrderNo())) {
			throw new ServiceException(UpcConstants.MCH_ORDER_NO_IS_NULL, "商户订单号为空");
		}
	}

	private UpdateUpcPayInfoParam buildUpdateRefundData(UpcPayInfo refundPayInfo, RefundResp refundResp) {
		UpdateUpcPayInfoParam updatePayReq = new UpdateUpcPayInfoParam();
		updatePayReq.setPayNo(refundPayInfo.getPayNo());
		updatePayReq.setOriginalStatus(TradeStatus.REFUND_PROC.name());
		updatePayReq.setRtnOrderNo(refundResp.getRefundId());

		if (UpcConstants.SUCCESS.equals(refundResp.getReturnCode()) && UpcConstants.SUCCESS.equals(refundResp.getResultCode())) {
			// 修改退款流水状态为退款受理
			updatePayReq.setTargetStatus(TradeStatus.REFUND_ACCEPTED.name());
		} else {
			// 退款流水退款失败
			updatePayReq.setTargetStatus(TradeStatus.REFUND_FAIL.name());

			updatePayReq.setRtnCode(StringUtils.isNotBlank(refundResp.getErrCode()) ? refundResp.getErrCode() : refundResp.getReturnCode());
			updatePayReq.setRtnMsg(StringUtils.isNotBlank(refundResp.getErrCodeDes()) ? refundResp.getErrCodeDes() : refundResp.getReturnMsg());
		}
		return updatePayReq;
	}
	
	@Override
	public String getWXOauthUrl(String thirdAppId, String redirectUrl) {
		String url = WXGetCode.getOAuthUrl(thirdAppId, redirectUrl);
		return url;
	}
	
	@Override
	public UpcWXOpenIdResp getWXOpenId(UpcWXOpenIdReq req) {
		logger.info("method:getWXOpenId，请求参数：{}", req);
		UpcWXOpenIdResp upcResp = new UpcWXOpenIdResp();
		upcResp.setRltCode(UpcConstants.SUCCESS);
		
		WXGetAccessTokenResp resp = getOAuthAccessToken(req.getAppId(), req.getAppSecret(), req.getCode());
		
		if (resp == null || StringUtils.isBlank(resp.getOpenid())) {
			upcResp.setRltCode(UpcConstants.FAILURE_SYS);
			upcResp.setRltMsg("获取微信用户信息失败");
			return upcResp;
		}
		
		upcResp.setOpenId(resp.getOpenid());
		if (StringUtils.isNotBlank(req.getAppId())) {
			upcResp.setAppId(req.getAppId());
		} else {
			upcResp.setAppId(ConfigKeyUtils.getSFPayWXAppId());
		}
		
		return upcResp;
	}
	
	@Override
	public WXGetAccessTokenResp  getOAuthAccessToken(String appId, String appSecret, String code) {
		if (StringUtils.isBlank(code)) {
			return null;
		}
		GetAccessTokenResp resp = WXGetAccessToken.getOAuthaccessToken(appId, appSecret, code);
		logger.info(String.format("获取accessToken是：[%s]", JsonUtil.toJSONString(resp)));
		
		WXGetAccessTokenResp re = new WXGetAccessTokenResp();
		try {
			BeanUtils.copyProperties(re, resp);
		} catch (Exception e) {
			logger.error("method:getAccessToken（BeanUtils.copyProperties）出现异常，code:{}", code, e);
		}
		return re;
	}
	
	@Override
	public WXMchInfoResp getWXMchInfo(String mchNo) {
		logger.info("method:getWXMchInfo，请求参数：{}", mchNo);
		WXMchInfoResp upcResp = new WXMchInfoResp();
		upcResp.setRltCode(UpcConstants.SUCCESS);
		
		if (StringUtils.isBlank(mchNo)) {
			upcResp.setRltCode(UpcConstants.MCH_NO_IS_NULL);
			upcResp.setRltMsg("商户号不能为空");
			return upcResp;
		}
		
		UpcRequestContext context = null;
		try {
			context = getRequestContext(mchNo, "WX");
		} catch (ServiceException e) {
			logger.error("method:getWXMchInfo获取商户渠道配置信息出现异常(ServiceException)，商户号：{}", mchNo, e);
			upcResp.setRltCode(e.getCode());
			upcResp.setRltMsg(e.getMsg());
			return upcResp;
		} catch (UPCServiceException e) {
			logger.error("method:getWXMchInfo获取商户渠道配置信息出现异常(UPCServiceException)，商户号：{}", mchNo, e);
			upcResp.setRltCode(e.getCode());
			upcResp.setRltMsg(e.getMsg());
			return upcResp;
		}
		
		upcResp.setAppId(context.getChannelArgs().getValueByKey("app_id"));
		upcResp.setAppSecret(context.getChannelArgs().getValueByKey("mch_key"));
		upcResp.setWxMchNo(context.getChannelArgs().getValueByKey("mch_id"));
		return upcResp;
	}
}
