package com.sfpay.pay.task;

import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.framework2.context.configuration.ConfigurerHolder;
import com.sfpay.framework2.core.util.DateUtil;
import com.sfpay.pay.enums.ConfigKeyEnum;

public class BaseTask {

	private final Logger logger = LoggerFactory.getLogger(BaseTask.class);

	public final String UPP_SYS_SOURCE = "UPP";
	// 默认每页处理条数
	public int execItemsPerPage = 500;
	
	public int getExecItemsPerPage() {
		String taskExecItemsPerTimes;
		try {
			taskExecItemsPerTimes = ConfigurerHolder.get(ConfigKeyEnum.UPC_TASK_EXEC_ITEMS_PER_TIMES);
			logger.info("获取配置中心每页处理条数:{} 条", taskExecItemsPerTimes);
			if (StringUtils.isNotEmpty(taskExecItemsPerTimes)) {
				execItemsPerPage = Integer.parseInt(taskExecItemsPerTimes);
			}
			
		} catch (Exception e) {
			logger.error("获取配置中心参数异常", e);
		}

		return execItemsPerPage;
	}

	public int getDayNum(int dayNum) {
		int rsDayNum = 0;
		try {
			String rsDayNumStr = ConfigurerHolder.get(ConfigKeyEnum.UPC_TASK_EXEC_ITEMS_ERR_QUERY_DAY);
			logger.info("获取配置中心每次查询的天数:{} 天", rsDayNumStr);
			if (StringUtils.isNotEmpty(rsDayNumStr)) {
				rsDayNum = Integer.parseInt(rsDayNumStr);
				if(rsDayNum <= dayNum){
					rsDayNum = dayNum;
				}
			}else{
				rsDayNum = dayNum;
			}
		} catch (Exception e) {
			logger.error("获取配置中心参数异常", e);
			rsDayNum = dayNum;
		}
		return rsDayNum;
	}
	
	public String getBeginTime(Date date , int dayNum){
		Calendar calendar = Calendar.getInstance();
		calendar.setTime(date);
		calendar.add(Calendar.DAY_OF_MONTH, - dayNum);
		calendar.set(Calendar.HOUR_OF_DAY, 0);
		calendar.set(Calendar.MINUTE, 0);
		calendar.set(Calendar.SECOND, 0);
		calendar.set(Calendar.MILLISECOND, 0);
		return DateUtil.formatDate(calendar.getTime(), DateUtil.YYYY_MM_DD_HH_MM_SS);
	}
}
