package com.sfpay.pay.cache;

import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.pay.service.impl.UpcMerchantMapService;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.UpcMerchantMap;
import com.sfpay.upc.service.IChannelArgService;

/**
 * 
 * 类说明：<br>
 * upc渠道参数容器
 * 
 * <p>
 * 详细描述：<br>
 * 
 * @author dumengchao(896728)
 * @date 2016-6-22
 */
public class UpcChannelContainer implements Runnable {

	private final static Logger logger = LoggerFactory.getLogger(UpcChannelContainer.class);

	// 容器
	private static Map<String, ChannelArgs> channelArgsContainer = new ConcurrentHashMap<String, ChannelArgs>();
	private static Map<String, UpcMerchantMap> merchantMapContainer = new ConcurrentHashMap<String, UpcMerchantMap>();

	private static UpcMerchantMapService merchantMapService;

	private static IChannelArgService channelArg;

	@Override
	public void run() {
		long startTime = System.currentTimeMillis();
		try {
			// 清空
			merchantMapContainer.clear();
			channelArgsContainer.clear();
			// 初始化商户映射
			initUpcMerchantMap();
			// 初始化商户参数
			initUpcChannelArgs();
		} catch (Exception e) {
			logger.error("初始化UpcChannelArgs数据异常", e);
		}
		logger.info("初始化UpcChannelArgs结束 共用时:[{}] 毫秒...........", System.currentTimeMillis() - startTime);
	}

	/**
	 * 初始化UpcMerchantMap容器
	 */
	private void initUpcMerchantMap() {
		logger.info("初始化UpcMerchantMap开始...........");
		List<UpcMerchantMap> mchMapList = merchantMapService.queryMerchantMapList();

		if (mchMapList == null || mchMapList.isEmpty()) {
			return;
		}
		for (UpcMerchantMap mchMap : mchMapList) {
			merchantMapContainer.put(mchMap.getMchNo() + mchMap.getChannelCode(), mchMap);
		}
		logger.info("初始化UpcMerchantMap结束 共缓存:[{}] 条...........", mchMapList.size());
	}

	/**
	 * 初始化UpcChannelArgs容器
	 */
	public void initUpcChannelArgs() {

		logger.info("初始化UpcChannelArgs开始...........");
		List<UpcMerchantMap> mchMapList = merchantMapService.queryMerchantMapList();

		if (mchMapList == null || mchMapList.isEmpty()) {
			return;
		}
		ChannelArgs channelArgs = null;
		for (UpcMerchantMap mchMap : mchMapList) {
			channelArgs = channelArg.getChannelArgsForInit(mchMap.getChannelCode(), mchMap.getChannelMchParamKey(),mchMap.getMchNo());
			if (channelArgs == null)
				continue;
			channelArgsContainer.put(mchMap.getMchNo() + mchMap.getChannelMchParamKey(), channelArgs);
		}
		logger.info("初始化UpcChannelArgs结束 ...........");
	}

	/**
	 * 查询商户映射
	 * 
	 * @param mchNo
	 * @param channelCode
	 * @return
	 */
	public static UpcMerchantMap getMerchantMap(String mchNo, String channelCode) {

		if (StringUtils.isEmpty(mchNo) || StringUtils.isEmpty(channelCode)) {
			logger.info("渠道编码或商户号为空");
			return null;
		}

		if (channelCode.contains("_")) {
			channelCode = channelCode.split("_")[0];
		}

		return merchantMapContainer.get(mchNo + channelCode);
	}

	/**
	 * 查询渠道数据
	 * 
	 * @param mchNo
	 * @param channelMchParamKey
	 * @return
	 */
	public static ChannelArgs getChannelArgs(String mchNo, String channelMchParamKey) {

		if (StringUtils.isEmpty(mchNo) || StringUtils.isEmpty(channelMchParamKey)) {
			logger.info("渠道编码或商户号为空");
			return null;
		}

		return channelArgsContainer.get(mchNo + channelMchParamKey);
	}

	public static void setChannelArg(IChannelArgService channelArg) {
		UpcChannelContainer.channelArg = channelArg;
	}

	public static void setMerchantMapService(UpcMerchantMapService merchantMapService) {
		UpcChannelContainer.merchantMapService = merchantMapService;
	}
}
