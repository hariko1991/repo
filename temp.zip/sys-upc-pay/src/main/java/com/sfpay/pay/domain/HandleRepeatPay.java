package com.sfpay.pay.domain;

import com.sfpay.upc.domain.alipay.AlipayCreateOrderResp;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.wx.WXCreateOrderResp;

/**
 * 
 * 类说明：<br>
 * 
 * 处理重复支付
 * <p>
 * 详细描述：<br>
 * 
 * @author dumengchao(896728)
 * @date 2016-6-13
 */
public class HandleRepeatPay {
	public UpcPayInfo payInfo;
	public AlipayCreateOrderResp alipayCreateOrderResp;
	public WXCreateOrderResp wxCreateOrderResp;

	public UpcPayInfo getPayInfo() {
		return payInfo;
	}

	public void setPayInfo(UpcPayInfo payInfo) {
		this.payInfo = payInfo;
	}

	public AlipayCreateOrderResp getAlipayCreateOrderResp() {
		return alipayCreateOrderResp;
	}

	public void setAlipayCreateOrderResp(AlipayCreateOrderResp alipayCreateOrderResp) {
		this.alipayCreateOrderResp = alipayCreateOrderResp;
	}

	public WXCreateOrderResp getWxCreateOrderResp() {
		return wxCreateOrderResp;
	}

	public void setWxCreateOrderResp(WXCreateOrderResp wxCreateOrderResp) {
		this.wxCreateOrderResp = wxCreateOrderResp;
	}

}
