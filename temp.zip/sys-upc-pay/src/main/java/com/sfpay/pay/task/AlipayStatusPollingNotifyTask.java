package com.sfpay.pay.task;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.alipay.function.AlipayCloseOrder;
import com.sfpay.framework2.core.util.DateUtil;
import com.sfpay.pay.channel.alipay.AlipayBaseChannelService;
import com.sfpay.pay.domain.HandleAlipayUnknownStatusResp;
import com.sfpay.pay.service.impl.AlipayExtService;
import com.sfpay.pay.service.impl.UpcPayInfoManageService;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.UpcHandleAlipayParam;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.upc.UpcPayUnknownParam;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.exception.UPCServiceException;
import com.sfpay.upc.service.IChannelArgService;
import com.sfpay.upc.service.IMqService;

/**
 * 支付宝状态轮训通知
 * 
 * @author 846306
 * 
 */
@Service
public class AlipayStatusPollingNotifyTask extends BaseTask {

	private final Logger logger = LoggerFactory.getLogger(AlipayStatusPollingNotifyTask.class);

	@Resource
	private UpcPayInfoManageService payInfoService;
	@Resource
	private IChannelArgService channelArgService;
	@Resource
	private IMqService mqService;
	@Resource
	private AlipayBaseChannelService alipayBaseChannelService;
	@Resource
	private AlipayExtService alipayExtService;

	/**
	 * 查询支付宝支付状态调度
	 */
	public final void doQueryPayStatusTask() {
		try {
			logger.info("查询支付宝支付状态调度 [开始]");
			long startTime = System.currentTimeMillis();
			doPayPolling("ALL");
			logger.info("轮询支付宝支付结果[结束] 共用时:{} 毫秒", System.currentTimeMillis() - startTime);
		} catch (Exception e) {
			logger.error("查询支付宝支付状态轮询处理调度任务执行异常：\n", e);
		}
	}

	public final void doQueryBCPayStatusTask() {
		try {
			logger.info("查询支付宝支付状态调度 [开始]");
			long startTime = System.currentTimeMillis();
			doPayPolling("ALIPAY_BC");
			logger.info("查询支付宝支付状态调度 [结束] 共用时:{} 毫秒", System.currentTimeMillis() - startTime);
		} catch (Exception e) {
			logger.error("查询支付宝支付状态轮询处理调度任务执行异常：\n", e);
		}
	}

	private void doPayPolling(String channelType) throws UPCServiceException {

		String handleType = "ALIPAY";
		if ("ALIPAY_BC".equals(channelType)) {
			handleType = "ALIPAY_BC";
		}
		Date curDate = new Date();
		String beginTime = this.getBeginTime(curDate , this.getDayNum(2)); 
		String endTime = DateUtil.formatDate(curDate, DateUtil.YYYY_MM_DD_HH_MM_SS);
		
		int totalRows = payInfoService.queryTotalRows(handleType, TradeStatus.TRADING.name() , beginTime , beginTime);
		logger.info("轮询支付宝支付结果 处理类型:{}, 共处理：{} 条", handleType, totalRows);
		if (totalRows == 0) {
			return;
		}

		int execItemsPerPage = getExecItemsPerPage();
		// 大于默认处理条数，分页处理
		if (totalRows > execItemsPerPage) {
			// 计算处理页数
			int page = totalRows / execItemsPerPage + 1;
			for (int count = 0; count < page; count++) {
				handleAlipayPayResult(handleType, execItemsPerPage, beginTime , endTime);
			}
		} else {
			// 处理结果集
			handleAlipayPayResult(handleType, execItemsPerPage, beginTime , endTime);
		}
	}

	private void handleAlipayPayResult(String handleType, int execItemsPerPage  , String beginTime , String endTime) throws UPCServiceException {
		// 查询list<主键>
		List<String> payNoList = payInfoService.queryPayNoList(handleType, TradeStatus.TRADING.name(), execItemsPerPage , beginTime , endTime);

		List<UpcPayInfo> upcPayInfoList = payInfoService.queryPayUnknownRecords(payNoList);

		ChannelArgs channelArgs = null;
		for (UpcPayInfo payInfo : upcPayInfoList) {
			try {
				String tradeStatus = TradeStatus.TRADING.name();
				channelArgs = channelArgService.getChannelArgs(payInfo.getChannelCode(), payInfo.getMchNo());
				HandleAlipayUnknownStatusResp handleResult = alipayBaseChannelService.handleTradeUnknown(payInfo, channelArgs);

				if (handleResult == null) {
					continue;
				}
				logger.info("处理交易响应数据:{}", handleResult.toString());

				tradeStatus = handleResult.getTradeStatus();

				if (TradeStatus.NOT_EXISTS.name().equals(tradeStatus) && handleResult.isOrderExpire()) {
					// 交易不存在或未支付 且过期则关闭
					tradeStatus = TradeStatus.CLOSE.name();
				} else if (TradeStatus.NOT_PAY.name().equals(tradeStatus) && handleResult.isOrderExpire()) {
					// 交易不存在或未支付 且过期则关闭
					tradeStatus = TradeStatus.CLOSE.name();
					AlipayCloseOrder.sendCloseOrderReq(payInfo.getChannelCode(), payInfo.getReqOrderNo(), channelArgs);
				}

				if (TradeStatus.SUCCESS.name().equals(tradeStatus) || TradeStatus.FAILURE.name().equals(tradeStatus)
						|| TradeStatus.CLOSE.name().equals(tradeStatus)) {
					// 更新统一支付渠道状态
					UpcPayUnknownParam upcParam = new UpcPayUnknownParam();
					upcParam.setMchNo(payInfo.getMchNo());
					upcParam.setPayNo(payInfo.getPayNo());
					upcParam.setRtnOrderNo(handleResult.getAlipayOrderNo());
					upcParam.setOriginalStatus(TradeStatus.TRADING.name());
					upcParam.setTargetStatus(tradeStatus);
					if(TradeStatus.SUCCESS.name().equals(handleResult.getTradeStatus())) {
						upcParam.setRtnBankCode(handleResult.getRltCode());
						upcParam.setRtnBankMsg(handleResult.getRltMsg());
					}
					payInfoService.updateUpcPayUnknown(upcParam);
					logger.info("更新支付宝订单:payNo:[{}], status:[{}]", payInfo.getPayNo(), tradeStatus);
					if (TradeStatus.SUCCESS.name().equals(tradeStatus)) {// 更新支付宝拓展数据
						UpcHandleAlipayParam reqParam = new UpcHandleAlipayParam();
						reqParam.setPayNo(payInfo.getPayNo());
						reqParam.setSellerId(handleResult.getSellerId());
						reqParam.setSellerAccount(handleResult.getSellerAccount());
						reqParam.setBuyerId(handleResult.getBuyerId());
						reqParam.setBuyerAccount(handleResult.getBuyerAccount());
						alipayExtService.updateUpcAlipayExt(reqParam);
					}
				}

				if (UPP_SYS_SOURCE.equals(payInfo.getSystemSource())
						&& (TradeStatus.SUCCESS.name().equals(tradeStatus) || TradeStatus.FAILURE.name().equals(tradeStatus))) {

					Map<String, String> mapMsg = new HashMap<String, String>();
					mapMsg.put("tradeType", "PAYMENT");
					mapMsg.put("channelCode", payInfo.getChannelCode());
					mapMsg.put("mchNo", payInfo.getMchNo());
					mapMsg.put("uppChannelTradeNo", payInfo.getUppOrderNo());
					mapMsg.put("mchOrderNo", payInfo.getMchOrderNo());
					mapMsg.put("rtnOrderNo", handleResult.getAlipayOrderNo());
					mapMsg.put("tradeAmt", String.valueOf(payInfo.getTradeAmt()));
					mapMsg.put("tradeFee", String.valueOf(payInfo.getTradeFee() == null ? 0L : payInfo.getTradeFee()));
					mapMsg.put("ccy", payInfo.getCcy());
					mapMsg.put("status", handleResult.getTradeStatus());
					mapMsg.put("payBankType", "");
					mapMsg.put("beginTime", DateUtil.format(payInfo.getBeginTime(), DateUtil.YYYY_MM_DD_HH_MM_SS));
					mapMsg.put("endTime", DateUtil.format(new Date(), DateUtil.YYYY_MM_DD_HH_MM_SS));
					mapMsg.put("errorCode", handleResult.getRltCode());
					mapMsg.put("errorMsg", handleResult.getRltMsg());
					boolean newVersion = false;
					if (StringUtils.isNotEmpty(payInfo.getUppOrderNo())) {
						newVersion = true;
					}
					logger.info("支付宝调度通知聚合支付版本:[{}], mq支付消息:[{}]", newVersion, mapMsg.toString());

					mqService.sendMsg(newVersion, mapMsg);
					// 更新通知状态
					payInfoService.updateNotifyFlag(payInfo.getPayNo(), "Y");
				}

			} catch (Exception e) {
				logger.error("后台调度支付宝支付状态查询接口，订单号:+" + payInfo.getMchOrderNo() + "+处理支付流水异常", e);
			}

		}
	}

}
