package com.sfpay.pay.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.framework2.exception.ServiceException;
import com.sfpay.pay.cache.UpcChannelContainer;
import com.sfpay.pay.dao.UpcMerchantMapDao;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.upc.UpcMerchantMap;
import com.sfpay.upc.exception.UPCServiceException;

/**
 * 
 * 类说明：<br>
 * 统一支付流水管理
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-18
 */
@Service("upcMerchantMapService")
public class UpcMerchantMapService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private UpcMerchantMapDao upcMerchantMapDao;

	public UpcMerchantMap queryMerchantMap(String mchNo, String channelCode) throws UPCServiceException {
		try {
			if (channelCode.contains("_")) {
				channelCode = channelCode.split("_")[0];
			}
			
			UpcMerchantMap mchMap = UpcChannelContainer.getMerchantMap(mchNo, channelCode);

			return mchMap != null ? mchMap : upcMerchantMapDao.queryMerchantMap(mchNo, channelCode);
		} catch (Exception e) {
			logger.error("查询商户映射异常", e);
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}
	}

	public List<UpcMerchantMap> queryMerchantMapList() {
		return upcMerchantMapDao.queryMerchantMapList();
	}

	/**
	 * 添加记录
	 */
	public void saveUpcMerchantMap(UpcMerchantMap upcMerchantMap) {
		if (upcMerchantMap == null || StringUtils.isEmpty(upcMerchantMap.getMchNo())
				|| StringUtils.isEmpty(upcMerchantMap.getChannelCode())) {
			throw new ServiceException(UpcConstants.PARAM_NULL, "必要参数为空");
		}
		try {
			upcMerchantMapDao.addUpcMerchantMap(upcMerchantMap);
		} catch (Exception e) {
			logger.error(String.format("添加[%s]对应的映射关系异常", upcMerchantMap.getMchNo()), e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "查询异常");
		}
	}

	/**
	 * 
	 * @param upcMerchantMap
	 */
	public void updateUpcMerchantMapById(UpcMerchantMap upcMerchantMap) {

		if (upcMerchantMap == null || StringUtils.isEmpty(upcMerchantMap.getMchNo())) {
			throw new ServiceException(UpcConstants.PARAM_NULL, "必要参数为空");
		}
		try {
			upcMerchantMapDao.updateUpcMerchantMapById(upcMerchantMap);
		} catch (Exception e) {
			logger.error(String.format("修改[%s]对应的映射关系异常", upcMerchantMap.getMchNo()), e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "查询异常");
		}

	}

	/**
	 * 根据渠道编码、渠道商户号、商户号 查询商户映射信息--不受状态限制
	 * @param channelCode
	 * @param channelMchNo
	 * @param mchNo
	 * @return
	 * @throws ServiceException
	 */
	public UpcMerchantMap getUpcMchMap(String channelCode, String channelMchNo, String mchNo) throws ServiceException {
		logger.info(String.format("根据渠道商户号查询商户映射配置，渠道编码：%s，渠道商户号：%s，商户号：%s", channelCode, channelMchNo, mchNo));
		if (StringUtils.isBlank(channelCode) || StringUtils.isBlank(mchNo)) {
			throw new ServiceException(UpcConstants.PARAM_NULL, "参数不能为空");
		}
		try {
			List<UpcMerchantMap> mchMapList = upcMerchantMapDao.queryUpcMchMap(channelCode, channelMchNo, mchNo);
			if (mchMapList == null || mchMapList.size() == 0) {
				return null;
			}
			return mchMapList.get(0);
		} catch (Exception e) {
			logger.error(String.format("查询渠道配置映射失败，渠道编码：%s，渠道商户号：%s", channelCode, channelMchNo), e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "数据库查询出错");
		}
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 统计总的记录数
	 * @param mchNo 精确匹配的商户号
	 * @param channelMchNo 渠道商户号
	 * @param channelCode 渠道编码(分类编码)
	 * @return
	 * @throws ServiceException
	 */
	public int countUpcMchMaps(String mchNo, String channelMchNo, String channelCode) throws ServiceException {
		logger.info("method:countUpcMchMaps 请求参数：mchNo={},channelMchNo={}, channelCode={}", new Object[]{mchNo, channelMchNo, channelCode});
		try {
			return upcMerchantMapDao.countAllUpcMchMaps(mchNo, channelMchNo, channelCode);
		} catch (Exception e) {
			logger.error("method:countUpcMchMaps error,mchNo={},channelMchNo={}, channelCode={}", new Object[]{mchNo, channelMchNo, channelCode}, e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "数据库查询出错");
		}
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 分页查询upc商户映射配置信息，主要用于页面oms查询
	 * @param mchNo 精确匹配的商户号
	 * @param channelMchNo 渠道商户号
	 * @param channelCode 渠道编码(分类编码)
	 * @param minPageNo
	 * @param maxPageNo
	 * @return
	 * @throws ServiceException
	 */
	public List<UpcMerchantMap> listAllUpcMchMaps(String mchNo, String channelMchNo, String channelCode, 
			int minPageNo, int maxPageNo) throws ServiceException {
		logger.info("分页查询upc商户映射配置，请求参数：mchNo={},channelMchNo={}, channelCode={}, minPageNo={}, maxPageNo={}", 
				new Object[]{mchNo, channelMchNo, channelCode, minPageNo, maxPageNo});
		if (minPageNo < 0 || maxPageNo < 0) {
			throw new ServiceException(UpcConstants.PARAM_NULL, "参数不能为空");
		}
		try {
			return upcMerchantMapDao.selectAllUpcMchMaps(mchNo, channelMchNo, channelCode, minPageNo, maxPageNo);
		} catch (Exception e) {
			logger.error("查询渠道配置映射失败，mchNo={},channelMchNo={}, channelCode={}, minPageNo={}, maxPageNo={}", 
				new Object[]{mchNo, channelMchNo, channelCode, minPageNo, maxPageNo}, e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "数据库查询出错");
		}
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据商户号查询商户配置
	 * @param mchNo
	 * @return
	 * @throws ServiceException
	 */
	public List<UpcMerchantMap> getUpcMchMapsByMchNo(String mchNo, String channelMchNo, String channelCode) throws ServiceException {
		logger.info("根据商户号查询upc商户映射配置，请求参数：mchNo={},channelMchNo={},channelCode={}", new Object[]{mchNo, channelMchNo, channelCode});
		if (StringUtils.isBlank(mchNo)) {
			throw new ServiceException(UpcConstants.PARAM_NULL, "参数不能为空");
		}
		try {
			return upcMerchantMapDao.selectUpcMchMapsByMchNo(mchNo, channelMchNo, channelCode);
		} catch (Exception e) {
			logger.error("根据商户号查询渠道配置映射失败，mchNo={},channelMchNo={},channelCode={}", new Object[]{mchNo, channelMchNo, channelCode}, e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "数据库查询出错");
		}
	}
	
	public UpcMerchantMap getUpcMchMapsById(Long id) throws ServiceException {
		logger.info("根据ID查询upc商户映射配置，请求参数：id={}", id);
		if (id == null || id <= 0) {
			throw new ServiceException(UpcConstants.PARAM_NULL, "参数不能为空");
		}
		try {
			return upcMerchantMapDao.selectUpcMchMapById(id);
		} catch (Exception e) {
			logger.error("根据ID查询渠道配置映射失败，id={}", new Object[]{id}, e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "数据库查询出错");
		}
	}
}
