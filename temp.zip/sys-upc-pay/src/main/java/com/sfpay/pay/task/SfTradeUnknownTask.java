package com.sfpay.pay.task;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.framework2.core.util.DateUtil;
import com.sfpay.pay.channel.sfpay.SFPayBaseChannelService;
import com.sfpay.pay.domain.HandleChannelBaseResp;
import com.sfpay.pay.service.impl.UpcPayInfoManageService;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.exception.UPCServiceException;
import com.sfpay.upc.service.IChannelArgService;
import com.sfpay.upc.service.IMqService;

/**
 * 
 * 类说明：<br>
 * 查询交易未知调度
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-5-10
 */
@Service("SfTradeUnknownTask")
public class SfTradeUnknownTask extends BaseTask {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private UpcPayInfoManageService payInfoService;
	@Resource
	private IChannelArgService channelArgService;
	@Resource
	private IMqService mqService;
	@Resource
	private SFPayBaseChannelService sfPayBaseChannelService;

	/**
	 * 查询支付调度
	 */
	public final void doQueryPayTask() {
		try {
			logger.info("顺手付渠道 查询支付调度 [开始]");
			long startTime = System.currentTimeMillis();
			String handleType = "SFPAY";
			Date curDate = new Date();
			String beginTime = this.getBeginTime(curDate , this.getDayNum(2)); 
			String endTime = DateUtil.formatDate(curDate, DateUtil.YYYY_MM_DD_HH_MM_SS);
			int totalRows = payInfoService.queryTotalRows(handleType, TradeStatus.TRADING.name() , beginTime , endTime);
			logger.info("轮询顺手付支付结果 处理类型:{}, 共处理：{} 条", handleType, totalRows);
			if (totalRows == 0) {
				return;
			}
			int execItemsPerPage = getExecItemsPerPage();
			// 大于默认处理条数，分页处理
			if (totalRows > execItemsPerPage) {
				// 计算处理页数
				int page = totalRows / execItemsPerPage + 1;
				for (int count = 0; count < page; count++) {
					handleSfPayResult(handleType, execItemsPerPage , beginTime , endTime);
				}
			} else {
				// 处理结果集
				handleSfPayResult(handleType, execItemsPerPage, beginTime , endTime);
			}
			logger.info("顺手付渠道 查询支付调度 [结束] 共用时:{} 毫秒", System.currentTimeMillis() - startTime);
		} catch (Exception e) {
			logger.error("对[顺手付]未知状态记录进行轮询处理调度任务执行异常：\n", e);
		}
	}

	private void handleSfPayResult(String handleType, int execItemsPerPage , String beginTime , String endTime) throws UPCServiceException {

		// 查询list<主键>
		List<String> payNoList = payInfoService.queryPayNoList(handleType, TradeStatus.TRADING.name(), execItemsPerPage , beginTime , endTime);

		List<UpcPayInfo> upcPayInfoList = payInfoService.queryPayUnknownRecords(payNoList);
		
		for (UpcPayInfo payInfo : upcPayInfoList) {
			try {
				
				HandleChannelBaseResp handleResult = sfPayBaseChannelService.handleSfPayOrderResult(payInfo);

				logger.info("处理交易位置响应数据:{}", handleResult.toString());

				if (UPP_SYS_SOURCE.equals(payInfo.getSystemSource())
						&& (TradeStatus.SUCCESS.name().equals(handleResult.getTradeStatus()) || TradeStatus.FAILURE.name().equals(
								handleResult.getTradeStatus()))) {

					Map<String, String> mapMsg = new HashMap<String, String>();
					mapMsg.put("tradeType", "PAYMENT");
					mapMsg.put("channelCode", payInfo.getChannelCode());
					mapMsg.put("mchNo", payInfo.getMchNo());
					mapMsg.put("uppChannelTradeNo", payInfo.getUppOrderNo());
					mapMsg.put("mchOrderNo", payInfo.getMchOrderNo());
					mapMsg.put("rtnOrderNo", payInfo.getRtnOrderNo());
					mapMsg.put("tradeAmt", String.valueOf(payInfo.getTradeAmt()));
					mapMsg.put("tradeFee", String.valueOf(payInfo.getTradeFee() == null ? 0L : payInfo.getTradeFee()));
					mapMsg.put("ccy", payInfo.getCcy());
					mapMsg.put("status", handleResult.getTradeStatus());
					mapMsg.put("payBankType", "");
					mapMsg.put("beginTime", DateUtil.format(payInfo.getBeginTime(), DateUtil.YYYY_MM_DD_HH_MM_SS));
					mapMsg.put("endTime", DateUtil.format(new Date(), DateUtil.YYYY_MM_DD_HH_MM_SS));
					if(TradeStatus.FAILURE.name().equals(handleResult.getTradeStatus())) {
						mapMsg.put("errorCode", handleResult.getRltCode());
						mapMsg.put("errorMsg", handleResult.getRltMsg());
					}

					boolean newVersion = false;
					if (StringUtils.isNotEmpty(payInfo.getUppOrderNo())) {
						newVersion = true;
					}
					logger.info("顺手付支付调度通知聚合支付版本:[{}], mq支付消息:[{}]", newVersion, mapMsg.toString());
					mqService.sendMsg(newVersion, mapMsg);

					// 更新通知状态
					payInfoService.updateNotifyFlag(payInfo.getPayNo(), "Y");
				}

			} catch (Exception e) {
				logger.error("后台调度查询顺手付查询接口处理支付流水异常 商户订单号:" + payInfo.getMchOrderNo() + ", payNo:" + payInfo.getPayNo(), e);
			}

		}
	}

}
