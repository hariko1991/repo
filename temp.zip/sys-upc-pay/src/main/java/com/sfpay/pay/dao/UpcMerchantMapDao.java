package com.sfpay.pay.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.upc.domain.upc.UpcMerchantMap;

/**
 * 
 * @Description: 商户映射服务类
 * @date 2016-04-27 17:17:29
 * @version V1.0
 * @author 896728
 */
public interface UpcMerchantMapDao {

	/**
	 * 查询商户映射
	 * @param mchNo
	 * @param channelCode
	 * @return
	 */
	UpcMerchantMap queryMerchantMap(@Param("mchNo") String mchNo, @Param("channelCode") String channelCode);

	/**
	 * 查询商户映射列表
	 * @return
	 */
	List<UpcMerchantMap> queryMerchantMapList();

	/**
	 * 根据商户号查询列表--不限制状态
	 * @param channelCode
	 * @param channelMchNo
	 * @param mchNo
	 * @return
	 */
	List<UpcMerchantMap> queryUpcMchMap(@Param("channelCode") String channelCode,
			@Param("channelMchNo") String channelMchNo, @Param("mchNo") String mchNo);

	/**
	 * 保存记录
	 * @param upcMerchantMap
	 */
	void addUpcMerchantMap(@Param("merchantMap")UpcMerchantMap upcMerchantMap);

	/**
	 * 修改记录
	 * @param upcMerchantMap
	 */
	void updateUpcMerchantMapById(@Param("merchantMap")UpcMerchantMap upcMerchantMap);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 统计所有的商户映射记录数
	 * @param mchNo 精确匹配的商户号
	 * @param channelMchNo 渠道商户号
	 * @param channelCode 渠道编码(分类编码)
	 * @return
	 * Anthor:jiangxl 江小林
	 */
	int countAllUpcMchMaps(@Param("mchNo")String mchNo, 
			@Param("channelMchNo")String channelMchNo, 
			@Param("channelCode")String channelCode);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 分页查询upc商户映射配置
	 * @param mchNo 精确匹配的商户号
	 * @param channelMchNo 渠道商户号
	 * @param channelCode 渠道编码(分类编码)
	 * @param minPageNo
	 * @param maxPageNo
	 * @return
	 */
	List<UpcMerchantMap> selectAllUpcMchMaps(@Param("mchNo")String mchNo, 
			@Param("channelMchNo")String channelMchNo, 
			@Param("channelCode")String channelCode, 
			@Param("minPageNo")int minPageNo, 
			@Param("maxPageNo")int maxPageNo);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据商户号查询upc商户映射配置
	 * @param mchNo 精确匹配的商户号
	 * @param channelMchNo 渠道商户号
	 * @param channelCode渠道编码
	 * @return
	 */
	List<UpcMerchantMap> selectUpcMchMapsByMchNo(@Param("mchNo")String mchNo, 
			@Param("channelMchNo")String channelMchNo, 
			@Param("channelCode")String channelCode);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据id查询upc商户映射信息
	 * @param id
	 * @return
	 */
	UpcMerchantMap selectUpcMchMapById(@Param("id") Long id);
}
