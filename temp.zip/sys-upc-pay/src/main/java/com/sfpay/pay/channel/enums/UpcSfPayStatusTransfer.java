/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.pay.channel.enums;

import com.sfpay.upc.enums.TradeStatus;

/**
 * 状态转换
 * 
 * @author 896728
 * @date 2016年9月22日
 *
 */
public enum UpcSfPayStatusTransfer {

	SUCCESS(TradeStatus.SUCCESS.name()), FAILURE(TradeStatus.FAILURE.name()), CLOSED(TradeStatus.CLOSE.name()), INIT(
			TradeStatus.INIT.name()), PROCESSING(TradeStatus.TRADING.name());

	private String targetStatus;

	private UpcSfPayStatusTransfer(String targetStatus) {
		this.targetStatus = targetStatus;
	}

	public String getTargetStatus() {
		return targetStatus;
	}

	public static boolean isFinishStatus(String status) {
		if (UpcSfPayStatusTransfer.SUCCESS.name().equals(status)
				|| UpcSfPayStatusTransfer.FAILURE.name().equals(status)
				|| UpcSfPayStatusTransfer.CLOSED.name().equals(status)) {
			return true;
		}
		return false;
	}

}
