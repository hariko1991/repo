package com.sfpay.pay.domain;

public class HandleAlipayUnknownStatusResp extends HandleChannelBaseResp {
	private static final long serialVersionUID = 5834288523565999082L;
	// 支付宝交易号
	private String alipayOrderNo;
	// 卖家支付宝用户号
	private String sellerId;
	// 卖家支付宝账号
	private String sellerAccount;
	// 卖家支付宝用户号
	private String buyerId;
	// 买家支付宝账号
	private String buyerAccount;

	public String getAlipayOrderNo() {
		return alipayOrderNo;
	}

	public void setAlipayOrderNo(String alipayOrderNo) {
		this.alipayOrderNo = alipayOrderNo;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getSellerAccount() {
		return sellerAccount;
	}

	public void setSellerAccount(String sellerAccount) {
		this.sellerAccount = sellerAccount;
	}

	public String getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}

	public String getBuyerAccount() {
		return buyerAccount;
	}

	public void setBuyerAccount(String buyerAccount) {
		this.buyerAccount = buyerAccount;
	}

}
