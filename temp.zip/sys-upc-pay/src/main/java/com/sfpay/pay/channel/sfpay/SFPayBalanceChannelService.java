package com.sfpay.pay.channel.sfpay;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.pay.channel.ISFPayChannelService;
import com.sfpay.pay.channel.enums.ExceptionBusiType;
import com.sfpay.pay.channel.enums.UpcSfPayErrorCode;
import com.sfpay.pay.channel.enums.UpcSfPayStatusTransfer;
import com.sfpay.pay.channel.sfpay.vo.OperatorSFPayBalanceRespVo;
import com.sfpay.pay.channel.sfpay.vo.OrderSFPayReqVo;
import com.sfpay.pay.channel.sfpay.vo.SFPaySignQueryRespVo;
import com.sfpay.pay.domain.HandleChannelBaseResp;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.sfpay.OperatorBalanceResp;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.exception.UPCServiceException;

/**
 * 
 * 类说明：<br>
 * 顺手付余额
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-22
 */
public class SFPayBalanceChannelService extends SFPayBaseChannelService implements ISFPayChannelService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	/**
	 * 冻结余额
	 * 
	 * @param payInfo
	 * @return
	 */
	public void freezeSFPAYBalance(UpcPayInfo payInfo) throws UPCServiceException {

		// 查询顺手付签约数据
		SFPaySignQueryRespVo signQueryResp = querySfPaySignNo(payInfo);

		String operatorBalanceReqUrl = Property.getProperty("SFPAY_GATPRX_URL") + Property.getProperty("SFPAY_BALANCE_FREEZE");
		String operatorBalanceReqMsg = buildOperatorBalanceMsg(payInfo, "AUTH_BALANCE_FREEZE", signQueryResp.getContractNo());
		// 冻结请求
		OperatorSFPayBalanceRespVo operatorSfpayBalanceResp = (OperatorSFPayBalanceRespVo) httpSfPay(ExceptionBusiType.FreezeBalance,
				operatorBalanceReqUrl, operatorBalanceReqMsg, OperatorSFPayBalanceRespVo.class);

		if (SFPAY_SUCCESS_REQ.equals(operatorSfpayBalanceResp.getRltCode())) {
			// 验签
			validateSign(operatorSfpayBalanceResp.getSign(), operatorSfpayBalanceResp, operatorSfpayBalanceResp.getResponseTime(), "status");

			if (SFPAY_SUCCESS_STATUS.equals(operatorSfpayBalanceResp.getStatus())) {
				// 修改数据状态
				updateUpcOrderStatus(payInfo.getPayNo(), TradeStatus.INIT, TradeStatus.FREEZE);
			} else {
				recordErrorInfo(payInfo.getPayNo(), operatorSfpayBalanceResp.getRltCode(), operatorSfpayBalanceResp.getStatus());
				throw new ServiceException(UpcConstants.ORDER_FREEZE_FAIL, "冻结失败");
			}
		} else {
			recordErrorInfo(payInfo.getPayNo(), operatorSfpayBalanceResp.getRltCode(), operatorSfpayBalanceResp.getRltMsg());
			String upcErrorCode = null;
			try {
				upcErrorCode = UpcSfPayErrorCode.valueOf(UpcSfPayErrorCode.prefix + operatorSfpayBalanceResp.getRltCode()).getUpcErrorCode();
			} catch (Exception e) {
				logger.error("无法识别错误码" + operatorSfpayBalanceResp.getRltCode(), e);
				upcErrorCode = UpcConstants.ORDER_FREEZE_FAIL;
			}
			throw new ServiceException(upcErrorCode, operatorSfpayBalanceResp.getRltMsg());

		}

	}

	/**
	 * 解冻余额
	 * 
	 * @param unfreezeType
	 * 
	 * @param payInfo
	 * @return
	 * @throws UPCServiceException
	 */
	public void unfreezeSFPAYBalance(String unfreezeType, UpcPayInfo payInfo) throws UPCServiceException {
		// 查询顺手付签约数据
		SFPaySignQueryRespVo signQueryResp = querySfPaySignNo(payInfo);

		String operatorBalanceReqUrl = Property.getProperty("SFPAY_GATPRX_URL") + Property.getProperty("SFPAY_BALANCE_UNFREEZE");
		String operatorBalanceReqMsg = buildOperatorBalanceMsg(payInfo, "AUTH_BALANCE_UNFREEZE", signQueryResp.getContractNo());
		// 冻结请求
		OperatorSFPayBalanceRespVo operatorSfpayBalanceResp = (OperatorSFPayBalanceRespVo) httpSfPay(ExceptionBusiType.UnFreezeBalance,
				operatorBalanceReqUrl, operatorBalanceReqMsg, OperatorSFPayBalanceRespVo.class);

		if (SFPAY_SUCCESS_REQ.equals(operatorSfpayBalanceResp.getRltCode())) {
			// 验签
			validateSign(operatorSfpayBalanceResp.getSign(), operatorSfpayBalanceResp, operatorSfpayBalanceResp.getResponseTime(), "status");
			if (SFPAY_SUCCESS_STATUS.equals(operatorSfpayBalanceResp.getStatus())) {
				String remark = "余额解冻成功关闭";
				TradeStatus targetStaus = TradeStatus.CLOSE;
				// 关单导致解冻
				if ("CLOSE".equals(unfreezeType)) {
					targetStaus = TradeStatus.INIT;
					remark = "关单解冻导致状态恢复到INIT";
				}
				// 修改数据状态
				updateUpcOrderStatus(payInfo.getPayNo(), TradeStatus.FREEZE, targetStaus, remark);

			} else {
				recordErrorInfo(payInfo.getPayNo(), operatorSfpayBalanceResp.getRltCode(), operatorSfpayBalanceResp.getStatus());
				throw new ServiceException(UpcConstants.ORDER_UNFREEZE_FAIL, "余额解结失败");
			}

		} else {
			recordErrorInfo(payInfo.getPayNo(), operatorSfpayBalanceResp.getRltCode(), operatorSfpayBalanceResp.getRltMsg());
			// 系统异常
			if (SFPAY_SYSTEM_EXCEPTION.equals(operatorSfpayBalanceResp.getRltCode())) {
				throw new ServiceException(UpcConstants.FAILURE_SYS, operatorSfpayBalanceResp.getRltMsg());
			}

			throw new ServiceException(UpcConstants.ORDER_UNFREEZE_FAIL, operatorSfpayBalanceResp.getRltMsg());
		}
	}
	
	/**
	 * 余额解冻支付
	 * @param payInfo
	 * @return
	 * @throws UPCServiceException
	 */
	public OperatorBalanceResp balanceUnfreezeAndPay(UpcPayInfo payInfo) throws UPCServiceException {
		// 查询顺手付签约数据
		SFPaySignQueryRespVo signQueryResp = querySfPaySignNo(payInfo);

		String operatorBalanceReqUrl = Property.getProperty("SFPAY_GATPRX_URL") + Property.getProperty("SFPAY_BALANCE_UNFREEZEPAY");
		String operatorBalanceReqMsg = buildOperatorBalanceMsg(payInfo, "AUTH_BALANCE_UNFREEZE_PAY", signQueryResp.getContractNo());
		// 解冻并支付请求
		OperatorSFPayBalanceRespVo opratorBalResp = null;
		try {
			opratorBalResp = (OperatorSFPayBalanceRespVo) httpSfPay(ExceptionBusiType.UnFreezeAndUseBalance, operatorBalanceReqUrl,
					operatorBalanceReqMsg, OperatorSFPayBalanceRespVo.class);
		} catch (ServiceException e) {
			// 超时处理
			if (UpcConstants.SOCKET_TIMEOUT.equals(e.getCode())) {
				HandleChannelBaseResp queryResult = orderQuery(payInfo);
				String upcStatus = handleBalancePayResult(payInfo, queryResult.getChannelStatus(), queryResult.getRltCode(), queryResult.getRltMsg());
				// 组装返回数据
				return new OperatorBalanceResp(UpcConstants.SUCCESS, null, upcStatus);
			} else {
				throw new ServiceException(e.getCode(), e.getMsg());
			}
		}

		if (SFPAY_SUCCESS_REQ.equals(opratorBalResp.getRltCode())) {
			// 验签
			validateSign(opratorBalResp.getSign(), opratorBalResp, opratorBalResp.getResponseTime(), "status");

			String upcStatus = handleBalancePayResult(payInfo, opratorBalResp.getStatus(), opratorBalResp.getRltCode(), opratorBalResp.getRltMsg());
			// 组装返回数据
			return new OperatorBalanceResp(UpcConstants.SUCCESS, null, upcStatus);
		} else {
			// 无法识别错误码
			recordErrorInfo(payInfo.getPayNo(), opratorBalResp.getRltCode(), opratorBalResp.getRltMsg());

			HandleChannelBaseResp queryResult = orderQuery(payInfo);
			String upcStatus = handleBalancePayResult(payInfo, queryResult.getChannelStatus(), queryResult.getRltCode(), queryResult.getRltMsg());
			// 组装返回数据
			return new OperatorBalanceResp(UpcConstants.SUCCESS, null, upcStatus);
		}

	}

	private String handleBalancePayResult(UpcPayInfo payInfo, String channelStatus, String rltCode, String rltMsg) throws UPCServiceException {
		String upcStatus = UpcSfPayStatusTransfer.valueOf(channelStatus).getTargetStatus();
		if (TradeStatus.SUCCESS.name().equals(upcStatus)) {
			// 修改数据状态
			updateUpcOrderStatus(payInfo.getPayNo(), TradeStatus.TRADING, TradeStatus.SUCCESS);
			// 发送mq通知
			sendMqAndRecordToUpp(payInfo, TradeStatus.SUCCESS, null, null);

		} else if (TradeStatus.FAILURE.name().equals(upcStatus)) {

			recordErrorInfo(payInfo.getPayNo(), rltCode, rltMsg);
			// 回滚状态
			updateUpcOrderStatus(payInfo.getPayNo(), TradeStatus.TRADING, TradeStatus.FREEZE);
			// 发送mq通知
			sendMqAndRecordToUpp(payInfo, TradeStatus.FAILURE, rltCode, rltMsg);
		} else if (TradeStatus.TRADING.name().equals(upcStatus)) {
			// 不处理
		} else if (TradeStatus.INIT.name().equals(upcStatus)) {
			// 不处理
		} else {
			throw new ServiceException(UpcConstants.FAILURE_SYS, rltMsg);
		}
		return upcStatus;
	}

}
