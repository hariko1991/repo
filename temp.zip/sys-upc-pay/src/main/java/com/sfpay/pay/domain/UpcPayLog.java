package com.sfpay.pay.domain;

import java.util.Date;

import com.sfpay.sypay.common.BaseEntity;

/**
 * 
 * @Description: 统一支付日志
 * @date 2016-04-21 18:37:51
 * @version V1.0
 * @author 896728
 */

public class UpcPayLog extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** id */
	private Long id;
	/** 引用id upp_order 或upp_pay_info id */
	private String referenceId;
	/** 商户号 */
	private String mchNo;
	/**
	 * 交易渠道类型（WX_JS：微信公众号支付 WX_APP：微信APP支付, WX_NATIVE：微信原生扫码支付 WX_H5:微信H5支付）
	 */
	private String tradeChannel;
	/** PAY(支付), REFUND(退款) */
	private String payType;
	/** 业务交易类型：SD:散单 COD：代收货款 MLJ:满立减 */
	private String bizTradeType;
	/** 状态: INIT未支付、PROCESSING交易进行中、SUCCESS成功、FAILURE失败、CLOSE:关闭 */
	private String payStatus;
	/** 返回码 */
	private String rtnCode;
	/** 返回信息 */
	private String rtnMsg;
	/** 交易时间 */
	private Date tradeTime;
	/** 交易金额 */
	private Long tradeAmount;
	/** 手续费 */
	private Long serviceFee;
	/** discountCode */
	private String discountCode;
	/** discountAmount */
	private Long discountAmount;
	/** 商户订单号 */
	private String mchOrderNo;
	/** 商户会员号 */
	private String mchMemberNo;
	/** 备注 */
	private String remark;
	/** 更新时间 */
	private Date createTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getReferenceId() {
		return referenceId;
	}

	public void setReferenceId(String referenceId) {
		this.referenceId = referenceId;
	}

	public String getMchNo() {
		return mchNo;
	}

	public void setMchNo(String mchNo) {
		this.mchNo = mchNo;
	}

	public String getTradeChannel() {
		return tradeChannel;
	}

	public void setTradeChannel(String tradeChannel) {
		this.tradeChannel = tradeChannel;
	}

	public String getPayType() {
		return payType;
	}

	public void setPayType(String payType) {
		this.payType = payType;
	}

	public String getBizTradeType() {
		return bizTradeType;
	}

	public void setBizTradeType(String bizTradeType) {
		this.bizTradeType = bizTradeType;
	}

	public String getPayStatus() {
		return payStatus;
	}

	public void setPayStatus(String payStatus) {
		this.payStatus = payStatus;
	}

	public String getRtnCode() {
		return rtnCode;
	}

	public void setRtnCode(String rtnCode) {
		this.rtnCode = rtnCode;
	}

	public String getRtnMsg() {
		return rtnMsg;
	}

	public void setRtnMsg(String rtnMsg) {
		this.rtnMsg = rtnMsg;
	}

	public Date getTradeTime() {
		return tradeTime;
	}

	public void setTradeTime(Date tradeTime) {
		this.tradeTime = tradeTime;
	}

	public Long getTradeAmount() {
		return tradeAmount;
	}

	public void setTradeAmount(Long tradeAmount) {
		this.tradeAmount = tradeAmount;
	}

	public Long getServiceFee() {
		return serviceFee;
	}

	public void setServiceFee(Long serviceFee) {
		this.serviceFee = serviceFee;
	}

	public String getDiscountCode() {
		return discountCode;
	}

	public void setDiscountCode(String discountCode) {
		this.discountCode = discountCode;
	}

	public Long getDiscountAmount() {
		return discountAmount;
	}

	public void setDiscountAmount(Long discountAmount) {
		this.discountAmount = discountAmount;
	}

	public String getMchOrderNo() {
		return mchOrderNo;
	}

	public void setMchOrderNo(String mchOrderNo) {
		this.mchOrderNo = mchOrderNo;
	}

	public String getMchMemberNo() {
		return mchMemberNo;
	}

	public void setMchMemberNo(String mchMemberNo) {
		this.mchMemberNo = mchMemberNo;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
}
