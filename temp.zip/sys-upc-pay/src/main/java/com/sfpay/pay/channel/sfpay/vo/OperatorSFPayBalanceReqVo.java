/**
 * =================================================================
 * 版权所有 2011-2020 顺丰恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.pay.channel.sfpay.vo;

public class OperatorSFPayBalanceReqVo extends SfPayBaseProtocal {
	private static final long serialVersionUID = -2047332193329585399L;

	/**
	 * 商户号
	 */
	private String merchantId;

	/**
	 * 签约号
	 */
	private String contractNo;

	public String getMerchantId() {
		return merchantId;
	}

	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}

	public String getContractNo() {
		return contractNo;
	}

	public void setContractNo(String contractNo) {
		this.contractNo = contractNo;
	}

}
