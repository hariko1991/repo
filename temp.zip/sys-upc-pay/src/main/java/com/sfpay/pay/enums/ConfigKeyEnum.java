package com.sfpay.pay.enums;

import com.sfpay.framework2.context.configuration.ConfigKey;

/**
 * 
 * @author 896728
 * @date 2016年10月5日 配置中心配置key
 */
public enum ConfigKeyEnum implements ConfigKey {
	// upc调度每次执行条数
	UPC_TASK_EXEC_ITEMS_PER_TIMES("UPC_TASK_EXEC_ITEMS_PER_TIMES"),
	/**支付宝失败错误码，多个以英文逗号分隔*/
	UPC_ALIPAY_FAIL_ERR_CODE("UPC_ALIPAY_FAIL_ERR_CODE"),
	/**每次轮询查询的天数**/
	UPC_TASK_EXEC_ITEMS_ERR_QUERY_DAY("UPC_TASK_EXEC_ITEMS_ERR_QUERY_DAY");

	private ConfigKeyEnum(String key) {
		this.key = key;
	}

	private String key;

	@Override
	public String getKey() {
		return key;
	}
}
