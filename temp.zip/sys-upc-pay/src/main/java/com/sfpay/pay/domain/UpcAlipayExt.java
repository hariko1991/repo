package com.sfpay.pay.domain;

import java.util.Date;

/**
 * 
 * @Description: 支付宝扩展数据
 * @date 2016-06-12 17:54:21
 * @version V1.0
 * @author 896728
 */

public class UpcAlipayExt {

	/** ID SEQ_UPC_ALIPAY_EXT */
	private Long id;
	/** 支付流水号 年月日+10位SEQ_PAY_NO */
	private String payNo;
	/** 订单编号 系统来源+订单编号 唯一 */
	private String mchOrderNo;
	/** 请求支付宝流水号 */
	private String reqAlipaySn;
	/** 卖家支付宝用户号 */
	private String sellerId;
	/** 卖家支付宝账号 */
	private String sellerAccount;
	/** 卖家支付宝用户号 */
	private String buyerId;
	/** 买家支付宝账号 */
	private String buyerAccount;
	/** 支付报文 */
	private String payMessage;
	/** 创建日期 */
	private Date createDate;
	/** 更新日期 */
	private Date updateDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPayNo() {
		return payNo;
	}

	public void setPayNo(String payNo) {
		this.payNo = payNo;
	}

	public String getPayMessage() {
		return payMessage;
	}

	public void setPayMessage(String payMessage) {
		this.payMessage = payMessage;
	}

	public String getMchOrderNo() {
		return mchOrderNo;
	}

	public void setMchOrderNo(String mchOrderNo) {
		this.mchOrderNo = mchOrderNo;
	}

	public String getReqAlipaySn() {
		return reqAlipaySn;
	}

	public void setReqAlipaySn(String reqAlipaySn) {
		this.reqAlipaySn = reqAlipaySn;
	}

	public String getSellerId() {
		return sellerId;
	}

	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}

	public String getSellerAccount() {
		return sellerAccount;
	}

	public void setSellerAccount(String sellerAccount) {
		this.sellerAccount = sellerAccount;
	}

	public String getBuyerId() {
		return buyerId;
	}

	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}

	public String getBuyerAccount() {
		return buyerAccount;
	}

	public void setBuyerAccount(String buyerAccount) {
		this.buyerAccount = buyerAccount;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
}
