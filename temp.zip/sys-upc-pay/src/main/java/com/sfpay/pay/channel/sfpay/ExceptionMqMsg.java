package com.sfpay.pay.channel.sfpay;

/**
 * 异常mq消息
 * 
 * @author 896728
 * @date 2016年9月21日
 *
 */
public class ExceptionMqMsg {
	private String businessCategory;
	private String exceptionBusiness;
	private String exceptionType;
	private String exceptionDetailMsg;
	private String reqUrl;
	private String reqMessage;
	private String handleType = "SYSTEM";
	private String sysSource = "UPC";

	public String getBusinessCategory() {
		return businessCategory;
	}

	public void setBusinessCategory(String businessCategory) {
		this.businessCategory = businessCategory;
	}

	public String getExceptionBusiness() {
		return exceptionBusiness;
	}

	public void setExceptionBusiness(String exceptionBusiness) {
		this.exceptionBusiness = exceptionBusiness;
	}

	public String getExceptionType() {
		return exceptionType;
	}

	public void setExceptionType(String exceptionType) {
		this.exceptionType = exceptionType;
	}

	public String getExceptionDetailMsg() {
		return exceptionDetailMsg;
	}

	public void setExceptionDetailMsg(String exceptionDetailMsg) {
		this.exceptionDetailMsg = exceptionDetailMsg;
	}

	public String getReqUrl() {
		return reqUrl;
	}

	public void setReqUrl(String reqUrl) {
		this.reqUrl = reqUrl;
	}

	public String getReqMessage() {
		return reqMessage;
	}

	public void setReqMessage(String reqMessage) {
		this.reqMessage = reqMessage;
	}

	public String getHandleType() {
		return handleType;
	}

	public void setHandleType(String handleType) {
		this.handleType = handleType;
	}

	public String getSysSource() {
		return sysSource;
	}

	public void setSysSource(String sysSource) {
		this.sysSource = sysSource;
	}

}
