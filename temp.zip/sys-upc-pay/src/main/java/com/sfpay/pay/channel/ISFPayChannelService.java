package com.sfpay.pay.channel;

import com.sfpay.upc.domain.sfpay.SfPayCreateOrderReq;
import com.sfpay.upc.domain.sfpay.SfPayCreateOrderResp;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.exception.UPCServiceException;

/**
 * 
 * 类说明：<br>
 * 顺手付渠道服务
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-18
 */
public interface ISFPayChannelService extends IBaseChannelService {

	/**
	 * 下单
	 * 
	 * @param req
	 * @return
	 * @throws UPCServiceException
	 */
	public SfPayCreateOrderResp createPayOrder(SfPayCreateOrderReq req) throws UPCServiceException;

	/**
	 * 关闭订单
	 * 
	 * @param payInfo
	 * @param orginalStatus 
	 */
	public void closeSfPayOrder(UpcPayInfo payInfo, TradeStatus orginalStatus) throws UPCServiceException;

}
