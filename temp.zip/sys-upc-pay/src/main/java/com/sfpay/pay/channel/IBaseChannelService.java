package com.sfpay.pay.channel;

import com.sfpay.pay.domain.HandleChannelBaseResp;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.exception.UPCServiceException;

/**
 * 处理重复支付
 * 
 * @author 896728
 *
 */
public interface IBaseChannelService {

	HandleChannelBaseResp handleRepeatPay(UpcPayInfo existPayInfo, ChannelArgs channelArgs) throws UPCServiceException;
}
