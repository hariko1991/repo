package com.sfpay.pay.service.hessian;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alipay.api.AlipayResponse;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.core.util.DateUtil;
import com.sfpay.pay.channel.IBaseChannelService;
import com.sfpay.pay.channel.alipay.AlipayBaseChannelService;
import com.sfpay.pay.domain.HandleAlipayUnknownStatusResp;
import com.sfpay.pay.domain.HandleChannelBaseResp;
import com.sfpay.pay.domain.HandleRepeatPay;
import com.sfpay.pay.domain.HandleWxUnknownStatusResp;
import com.sfpay.pay.domain.UpcRequestContext;
import com.sfpay.pay.domain.UpcWxExt;
import com.sfpay.pay.factory.PayChannelFactory;
import com.sfpay.pay.service.impl.UpcMerchantMapService;
import com.sfpay.pay.service.impl.UpcPayInfoManageService;
import com.sfpay.pay.service.impl.WxExtService;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.alipay.AlipayCreateOrderResp;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.QueryUpcPayParam;
import com.sfpay.upc.domain.upc.UpcMerchantMap;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.wx.WXCreateOrderResp;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.exception.UPCServiceException;
import com.sfpay.upc.service.IChannelArgService;
import com.sfpay.upc.service.IMqService;
import com.sfpay.wx.domain.BaseResp;

/**
 * 
 * 类说明：<br>
 * 微信
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-18
 */
@Service
public class BasePayChannelService {

	private final Logger logger = LoggerFactory.getLogger(getClass());
	@Resource
	private IChannelArgService channelArg;
	@Resource
	private UpcMerchantMapService merchantMapService;
	@Resource
	private UpcPayInfoManageService payManageInfoService;
	@Resource
	private AlipayBaseChannelService alipayBaseChannelService;
	@Resource
	private WxExtService wxExtService;
	@Resource
	protected IMqService mqService;

	protected ChannelArgs getChannelArg(String channelCode, String mchNo) {
		return channelArg.getChannelArgs(channelCode, mchNo);
	}

	/**
	 * 
	 * @param channelCode
	 *            渠道编码
	 * @param mchNo
	 *            商户号
	 * @param mchOrderNo
	 *            商户订单号
	 * @return
	 * @throws UPCServiceException
	 */
	protected UpcPayInfo getUpcPayInfo(String channelCode, String mchNo, String mchOrderNo) throws UPCServiceException {
		return getUpcPayInfo(channelCode, null, mchNo, mchOrderNo);
	}

	/**
	 * 
	 * @param channelCode
	 *            渠道编码
	 * @param channelCategoryCode
	 *            渠道分类
	 * @param mchNo
	 *            商户号
	 * @param mchOrderNo
	 *            商户订单号
	 * @return
	 * @throws UPCServiceException
	 */
	protected UpcPayInfo getUpcPayInfo(String channelCode, String channelCategoryCode, String mchNo, String mchOrderNo) throws UPCServiceException {
		QueryUpcPayParam payParam = new QueryUpcPayParam();
		payParam.setMchNo(mchNo);
		payParam.setMchOrderNo(mchOrderNo);
		payParam.setChannelCode(channelCode);

		payParam.setChannelCategoryCode(channelCategoryCode);
		return payManageInfoService.queryPayInfo(payParam);
	}

	/**
	 * 获取请求上下文
	 * 
	 * @param
	 * @return
	 * @throws UPCServiceException
	 */
	protected UpcRequestContext getRequestContext(String mchNo, String channelCode) throws UPCServiceException {
		UpcRequestContext context = new UpcRequestContext();

		if (StringUtils.isEmpty(mchNo)) {
			throw new ServiceException(UpcConstants.MCH_NO_IS_NULL, "商户号为空");
		} else if (StringUtils.isEmpty(channelCode)) {
			throw new ServiceException(UpcConstants.CHANNEL_CODE_IS_NULL, "渠道编号为空");
		}
		// 查询商户映射
		UpcMerchantMap mchMap = merchantMapService.queryMerchantMap(mchNo, channelCode);
		if (mchMap == null) {
			throw new ServiceException(UpcConstants.INVALID_MCH_NO, "商户映射不存在， 请配置upc_merchant_map表 商户号:" + mchNo);
		}
		context.setMchMap(mchMap);
		// 查询商户信息

		ChannelArgs channelArgs = getChannelArg(mchMap.getChannelCode(), mchMap.getMchNo());
		if (channelArgs == null) {
			throw new ServiceException(UpcConstants.INVALID_MCH_NO, "商户配置不存在， 请配置upc_channel_args表商户数据 商户号:" + mchNo);
		}
		context.setChannelArgs(channelArgs);

		return context;
	}

	/**
	 * 处理渠道重复支付
	 * 
	 * @param reqChannelCode
	 * @param context
	 * @param existPayInfo
	 * @return
	 * @throws UPCServiceException
	 */
	protected HandleRepeatPay handleChannelRepeatPay(String reqChannelCode, UpcRequestContext context, UpcPayInfo existPayInfo)
			throws UPCServiceException {

		// 状态校验
		validateExistPayInfoStatus(existPayInfo);

		// 渠道不同
		if (!reqChannelCode.equals(existPayInfo.getChannelCode())) {
			throw new ServiceException(UpcConstants.ORDER_IS_EXISTS, "订单已存在");
		}
		HandleRepeatPay repeatPay = new HandleRepeatPay();
		// 交易进行中查询支付数据
		if (TradeStatus.TRADING.name().equals(existPayInfo.getStatus())) {
			repeatPay = invokeTradeChannel(context.getChannelArgs(), existPayInfo);
		}
		return repeatPay;
	}

	/**
	 * 
	 * @param channelArgs
	 * @param existPayInfo
	 * @return
	 * @throws UPCServiceException
	 */
	private HandleRepeatPay invokeTradeChannel(ChannelArgs channelArgs, UpcPayInfo existPayInfo) throws UPCServiceException {

		IBaseChannelService tradeChannel = PayChannelFactory.getTradeChannel(existPayInfo.getChannelCode());
		HandleChannelBaseResp handleResult = tradeChannel.handleRepeatPay(existPayInfo, channelArgs);

		// 处理结果为空或订单过期
		if (handleResult == null || handleResult.isOrderExpire()) {
			throw new ServiceException(UpcConstants.ORDER_IS_EXPIRE, "订单已过期，不能重新下单");
		}

		HandleRepeatPay repeatPay = new HandleRepeatPay();
		// 微信状态判断
		if (handleResult instanceof HandleWxUnknownStatusResp) {
			// 未支付取原数据
			WXCreateOrderResp wxCreateOrderResp = returnExistData(existPayInfo);
			repeatPay.setWxCreateOrderResp(wxCreateOrderResp);
		}
		// 支付宝状态判断
		else if (handleResult instanceof HandleAlipayUnknownStatusResp) {
			// 未支付不存在返回原始加密数据
			AlipayCreateOrderResp existsResp = alipayBaseChannelService.returnPayData(existPayInfo);
			repeatPay.setAlipayCreateOrderResp(existsResp);
		}

		return repeatPay;
	}

	private WXCreateOrderResp returnExistData(UpcPayInfo existPayInfo) {
		UpcWxExt wxExt = wxExtService.queryWxExt(existPayInfo.getPayNo());
		WXCreateOrderResp resp = new WXCreateOrderResp();
		resp.setRltCode(BaseResp.SUCCESS);
		resp.setMchNo(existPayInfo.getMchNo());
		resp.setWxPrepayId(wxExt.getPrepayId());
		//resp.setCodeUrl(wxExt.getRemark());
		resp.setUpcTradeNo(wxExt.getPayNo());
		//resp.setMwebUrl(wxExt.getRemark());
		if (StringUtils.equals(existPayInfo.getChannelCode(), "WX_WAP")) {
			resp.setMwebUrl(wxExt.getRemark());
		} else {
			resp.setCodeUrl(wxExt.getRemark());
		}
		return resp;
	}

	protected void validateExistPayInfoStatus(UpcPayInfo existPayInfo) {
		if (TradeStatus.SUCCESS.name().equals(existPayInfo.getStatus())) {
			throw new ServiceException(UpcConstants.ORDER_IS_SUCCESS, "订单成功，不能重新下单");
		} else if (TradeStatus.FAILURE.name().equals(existPayInfo.getStatus())) {
			throw new ServiceException(UpcConstants.ORDER_IS_FAIL, "订单失败，不能重新下单");
		} else if (TradeStatus.REFUND_SUCC.name().equals(existPayInfo.getStatus())
				|| TradeStatus.REFUND_ACCEPTED.name().equals(existPayInfo.getStatus())) {
			throw new ServiceException(UpcConstants.ORDER_IS_REFUND_SUCC, "订单已退款成功，不能重新下单");
		}
	}

	protected void validateCloseOrderStatus(UpcPayInfo payInfo) {
		if (TradeStatus.SUCCESS.name().equals(payInfo.getStatus())) {
			throw new ServiceException(UpcConstants.ORDER_IS_SUCCESS, "订单成功,不能关单");
		} else if (TradeStatus.FAILURE.name().equals(payInfo.getStatus())) {
			throw new ServiceException(UpcConstants.ORDER_IS_FAIL, "订单失败,不能关单");
		} else if (TradeStatus.REFUND_SUCC.name().equals(payInfo.getStatus())) {
			throw new ServiceException(UpcConstants.ORDER_IS_REFUND_SUCC, "订单退款成功,不能关单");
		} else if (TradeStatus.REFUND_FAIL.name().equals(payInfo.getStatus())) {
			throw new ServiceException(UpcConstants.ORDER_IS_REFUND_FAIL, "订单退款失败,不能关单");
		} 
	}

	protected void recordWxError(String payNo, BaseResp createOrderResp) {

		String wxErrorCode = StringUtils.isNotEmpty(createOrderResp.getErrCode()) ? createOrderResp.getErrCode() : createOrderResp.getReturnCode();
		String wxErrorMsg = StringUtils.isNotEmpty(createOrderResp.getErrCodeDes()) ? createOrderResp.getErrCodeDes() : createOrderResp
				.getReturnMsg();
		// 记录错误

		payManageInfoService.asyncRecordError(payNo, wxErrorCode, wxErrorMsg);
	}

	protected void recordAlipayError(String payNo, AlipayResponse alipayResp) {

		String alipayErrorCode = StringUtils.isNotEmpty(alipayResp.getSubCode()) ? alipayResp.getSubCode() : alipayResp.getCode();
		String alipayErrorMsg = StringUtils.isNotEmpty(alipayResp.getSubMsg()) ? alipayResp.getSubMsg() : alipayResp.getMsg();
		// 记录错误

		payManageInfoService.asyncRecordError(payNo, alipayErrorCode, alipayErrorMsg);
	}

	/**
	 * 发送mq
	 * 
	 * @param payInfo
	 * @param upcTradeStatus
	 * @param errorCode
	 * @param errorMsg
	 */
	protected void sendMqAndRecordToUpp(UpcPayInfo payInfo, TradeStatus upcTradeStatus, String errorCode, String errorMsg) {
		Map<String, String> mapMsg = new HashMap<String, String>();
		mapMsg.put("tradeType", "PAY".equals(payInfo.getTradeType()) ? "PAYMENT" : "REFUND");
		mapMsg.put("channelCode", payInfo.getChannelCode());
		mapMsg.put("mchNo", payInfo.getMchNo());
		mapMsg.put("uppChannelTradeNo", payInfo.getUppOrderNo());
		mapMsg.put("mchOrderNo", payInfo.getMchOrderNo());
		mapMsg.put("rtnOrderNo", payInfo.getRtnOrderNo());
		mapMsg.put("tradeAmt", String.valueOf(payInfo.getTradeAmt()));
		mapMsg.put("tradeFee", String.valueOf(payInfo.getTradeFee() == null ? 0L : payInfo.getTradeFee()));
		mapMsg.put("ccy", payInfo.getCcy());
		mapMsg.put("status", upcTradeStatus.name());
		mapMsg.put("beginTime", DateUtil.format(payInfo.getBeginTime() == null ? new Date() : payInfo.getBeginTime(), DateUtil.YYYY_MM_DD_HH_MM_SS));
		mapMsg.put("endTime", DateUtil.format(new Date(), DateUtil.YYYY_MM_DD_HH_MM_SS));
		mapMsg.put("errorCode", errorCode);
		mapMsg.put("errorMsg", errorMsg);
		logger.info("sys-upc 通知聚合支付mq消息 :[{}]", mapMsg.toString());
		boolean newVersion = false;
		if (StringUtils.isNotEmpty(payInfo.getUppOrderNo())) {
			newVersion = true;
		}
		try {
			mqService.sendMsg(newVersion, mapMsg);
			payManageInfoService.updateNotifyFlag(payInfo.getPayNo(), "Y");
		} catch (UPCServiceException e) {
			logger.error("sys-upc 记录通知结果异常", e);
		}
	}
}
