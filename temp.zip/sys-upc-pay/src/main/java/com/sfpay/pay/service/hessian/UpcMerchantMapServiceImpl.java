/**
 * =================================================================
 * 版权所有 2011-2020 顺丰恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.pay.service.hessian;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.framework2.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.pay.service.impl.UpcMerchantMapService;
import com.sfpay.upc.domain.upc.UpcMerchantMap;
import com.sfpay.upc.service.IUpcMerchantMapService;

/**
 * 类说明：<br>
 * upc商户映射配置服务实现类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * 
 * CreateDate: 2017-7-18
 */
@Service("upcMchMapService")
@HessianExporter("/upc/upcMchMapService")
public class UpcMerchantMapServiceImpl implements IUpcMerchantMapService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private UpcMerchantMapService upcMerchantMapService;
	
	@Override
	public void saveUpcMerchantMap(List<UpcMerchantMap> upcMchMapList)
			throws ServiceException {
		if (upcMchMapList == null || upcMchMapList.size() <= 0) {
			return;
		}
		for (UpcMerchantMap map : upcMchMapList) {
			if (map != null && StringUtils.isBlank(map.getStatus())) {
				map.setStatus("ENABLED");
			}
			try {
				upcMerchantMapService.saveUpcMerchantMap(map);
			} catch (Exception e) {
				logger.error("保存upc商户配置失败，商户号：{}，渠道商户号：{}，渠道编码：{}", new Object[]{map.getMchNo(), map.getChannelMchNo(), map.getChannelCode()}, e);
			}
		}
	}

	@Override
	public void modifyUpcMerchantMap(UpcMerchantMap upcMchMap)
			throws ServiceException {
		upcMerchantMapService.updateUpcMerchantMapById(upcMchMap);
	}
	
	@Override
	public int countMchMaps(String mchNo, String channelMchNo, String channelCode) throws ServiceException {
		return upcMerchantMapService.countUpcMchMaps(mchNo, channelMchNo, channelCode);
	}
	
	@Override
	public List<UpcMerchantMap> listAllUpcMchMaps(String mchNo, String channelMchNo, String channelCode, int minPageNo, int maxPageNo)
			throws ServiceException {
		return upcMerchantMapService.listAllUpcMchMaps(mchNo, channelMchNo, channelCode, minPageNo, maxPageNo);
	}

	@Override
	public List<UpcMerchantMap> getUpcMchMapsByMchNo(String mchNo, String channelMchNo, String channelCode)
			throws ServiceException {
		return upcMerchantMapService.getUpcMchMapsByMchNo(mchNo, channelMchNo, channelCode);
	}
	
	@Override
	public UpcMerchantMap getUpcMchMapById(Long id) throws ServiceException {
		return upcMerchantMapService.getUpcMchMapsById(id);
	}
}
