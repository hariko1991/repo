package com.sfpay.pay.service.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.pay.dao.AlipayExtDao;
import com.sfpay.pay.domain.UpcAlipayExt;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.upc.UpcHandleAlipayParam;
import com.sfpay.upc.exception.UPCServiceException;

/**
 * 
 * @Description: 支付宝业务数据服务类
 * @date 2016-04-22 12:50:35
 * @version V1.0
 * @author 896728
 */
@Service
public class AlipayExtService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	@Resource
	private AlipayExtDao alipayExtDao;

	public void updateUpcAlipayExt(UpcHandleAlipayParam req) {
		try {
			alipayExtDao.updateUpcAlipayExt(req);
		} catch (Exception e) {
			logger.error("保存支付宝拓展数据异常 异常", e);
		}
	}

	public void saveUpcAlipayExt(UpcAlipayExt upcAlipayExt) throws UPCServiceException {
		try {
			alipayExtDao.saveUpcAlipayExt(upcAlipayExt);
		} catch (Exception e) {
			logger.error("保存支付宝拓展数据异常", e);
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}
	}
	
	public UpcAlipayExt getAlipayExtByPayNo(String payNo) throws UPCServiceException {
		try {
			return alipayExtDao.getAlipayExtByPayNo(payNo);
		} catch (Exception e) {
			logger.error("查询支付宝拓展数据异常", e);
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}
	}

}
