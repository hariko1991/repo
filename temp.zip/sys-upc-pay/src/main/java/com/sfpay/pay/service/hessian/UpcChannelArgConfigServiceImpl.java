/**
 * =================================================================
 * 版权所有 2011-2020 顺丰恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.pay.service.hessian;

import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.pay.dao.ChannelArgDao;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.upc.UpcChannelArg;
import com.sfpay.upc.service.IUpcChannelArgConfigService;

/**
 * 类说明：<br>
 * upc渠道参数配置服务实现
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * 
 * CreateDate: 2017-7-18
 */
@Service("upcChannelArgConfigService")
@HessianExporter("/upc/upcChannelArgConfigService")
public class UpcChannelArgConfigServiceImpl implements
		IUpcChannelArgConfigService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private ChannelArgDao channelArgDao;
	
	@Override
	public void saveChannelArgs(List<UpcChannelArg> args)
			throws ServiceException {
		logger.info("method:UpcChannelArgConfigServiceImpl.saveChannelArgs请求参数：{}", args);
		if (args == null || args.size() <= 0) {
			return;
		}
		for (UpcChannelArg arg : args) {
			try {
				channelArgDao.addUpcChannelArg(arg);
			} catch (Exception e) {
				logger.error("新增Upc渠道配置失败，商户号：{}，渠道编码：{}, 参数Key：{}", new Object[]{arg.getMchNo(), arg.getChannelCode(), arg.getArgKey()}, e);
			}
		}
	}

	@Override
	public void modifyChannelArg(UpcChannelArg arg) throws ServiceException {
		logger.info("method:UpcChannelArgConfigServiceImpl.modifyChannelArg请求参数：{}", arg);
		if (arg == null || arg.getId() == null || arg.getId() <= 0) {
			return;
		}
		try {
			channelArgDao.updateUpcChannelArgById(arg);
		} catch (Exception e) {
			logger.error("更新upc渠道信息失败，id={}", arg.getId(), e);
		}
	}

	@Override
	public UpcChannelArg getChannelArgById(Long id) throws ServiceException {
		logger.info("method:UpcChannelArgConfigServiceImpl.getChannelArgById请求参数：id={}", id);
		if (id == null || id <= 0) {
			return null;
		}
		try {
			return channelArgDao.selectArgsByArgId(id);
		} catch (Exception e) {
			logger.error("channelArgDao.selectArgsByArgId调用失败，id={}", id, e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "数据库查询失败");
		}
	}

	@Override
	public int countChannelArgs(String mchNo, String channelCode)
			throws ServiceException {
		logger.info("method:UpcChannelArgConfigServiceImpl.countChannelArgs请求参数：mchNo={},channelCode={}", new Object[]{mchNo, channelCode});
		try {
			return channelArgDao.countUpcArgs(mchNo, channelCode);
		} catch (Exception e) {
			logger.error("channelArgDao.countUpcArgs调用失败，mchNo={},channelCode={}", new Object[]{mchNo, channelCode}, e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "数据库查询失败");
		}
	}

	@Override
	public List<UpcChannelArg> listChannelArgs(String mchNo,
			String channelCode, int minPageNo, int maxPageNo)
			throws ServiceException {
		logger.info("method:UpcChannelArgConfigServiceImpl.listChannelArgs请求参数：mchNo={},channelCode={}, minPageNo={}, maxPageNo={}", 
				new Object[]{mchNo, channelCode, minPageNo, maxPageNo});
		try {
			return channelArgDao.selectUpcArgsByPage(mchNo, channelCode, minPageNo, maxPageNo);
		} catch (Exception e) {
			logger.error("channelArgDao.countUpcArgs调用失败，mchNo={},channelCode={}, minPageNo={}, maxPageNo={}", new Object[]{mchNo, channelCode, 
					minPageNo, maxPageNo}, e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "数据库查询失败");
		}
	}

}
