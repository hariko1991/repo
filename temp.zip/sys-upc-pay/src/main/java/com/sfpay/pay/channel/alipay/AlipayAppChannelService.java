package com.sfpay.pay.channel.alipay;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.alipay.function.AlipayBase;
import com.sfpay.alipay.function.AlipaySignFunc;
import com.sfpay.alipay.util.AlipayUtil;
import com.sfpay.pay.channel.IAlipayChannelService;
import com.sfpay.upc.domain.alipay.AlipayCreateOrderReq;
import com.sfpay.upc.domain.alipay.AlipayCreateOrderResp;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.UpcPayInfo;

/**
 * 
 * 类说明：<br>
 * 创建支付宝APP支付订单
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-22
 */
@Service
public class AlipayAppChannelService extends AlipayBaseChannelService implements IAlipayChannelService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	public static final String APP_PAY_SERVICE = "mobile.securitypay.pay";

	@Override
	protected AlipayCreateOrderResp buildAlipayCreateOrderResp(AlipayCreateOrderReq payReq, UpcPayInfo payInfo, ChannelArgs channelArgs) {
		AlipayCreateOrderResp resp = new AlipayCreateOrderResp();

		Map<String, String> sParaTemp = buildReqMap(payReq, payInfo, channelArgs);

		String privateKeyStr = AlipayBase.getPrivateKey(channelArgs);
		logger.info(privateKeyStr != null ? "获取到私钥" : "私钥为空");
		resp.setAlipayPayStr(AlipaySignFunc.buildAlipayAppRequestPara(sParaTemp, privateKeyStr));
		return resp;
	}

	private Map<String, String> buildReqMap(AlipayCreateOrderReq payReq, UpcPayInfo payInfo, ChannelArgs channelArgs) {
		Map<String, String> reqMap = new HashMap<String, String>();
		String partner = channelArgs.getValueByKey("mch_id");
		reqMap.put("service", APP_PAY_SERVICE);
		reqMap.put("partner", partner);
		reqMap.put("_input_charset", AlipayBase.input_charset);
		reqMap.put("sign_type", AlipayBase.sign_type);
		reqMap.put("notify_url", payInfo.getMchNotifyUrl());
		reqMap.put("out_trade_no", payInfo.getReqOrderNo());
		reqMap.put("subject", payReq.getProductName());
		reqMap.put("payment_type", AlipayBase.payment_type);
		reqMap.put("seller_id", partner);
		reqMap.put("total_fee", AlipayUtil.changeF2Y(payInfo.getTradeAmt()));
		reqMap.put("body", payReq.getProductName());
		return reqMap;
	}

}
