/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.pay.channel.enums;

/**
 * 异常业务类型
 * @author 896728
 * @date 2016年9月21日
 *
 */
public enum ExceptionBusiType {

	/**
	 * 优惠券
	 */
	FreezeVoucher("Voucher",false),
	UnFreezeVoucher("Voucher",true),
	UnFreezeAndUseVoucher("Voucher",true),
	VoucherRefund("Voucher",true),
	/**
	 * 余额
	 */
	FreezeBalance("Balance",true),
	UnFreezeBalance("Balance", true),
	UnFreezeAndUseBalance("Balance", true),
	/**
	 * 银行卡
	 */
	BankPay("BankCard", true),
	/**
	 * 顺手付下单
	 */
	SFPAY_ORDER("SFPAY", true),
	SFPAY_ORDER_QUERY("SFPAY", true),
	SFPAY_CLOSE_ORDER("SFPAY", true),
	SFPAY_REFUND("SFPAY", true);

	private String category;

	/**
	 * 
	 * @param category 
	 * @param needHandle 是否需要处理
	 */
	private ExceptionBusiType(String category, boolean needHandle) {
		this.category = category;
	}
	
	public String getCategory() {
		return category;
	}
}
