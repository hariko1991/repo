package com.sfpay.pay.service.hessian;

import java.text.MessageFormat;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alipay.api.AlipayResponse;
import com.alipay.api.response.AlipayTradeRefundResponse;
import com.sfpay.alipay.constant.AlipayConstants;
import com.sfpay.alipay.enums.AlipayErrorCode;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.pay.channel.IBaseChannelService;
import com.sfpay.pay.channel.alipay.AlipayBaseChannelService;
import com.sfpay.pay.channel.wx.WxBaseChannelService;
import com.sfpay.pay.domain.HandleAlipayUnknownStatusResp;
import com.sfpay.pay.domain.HandleChannelBaseResp;
import com.sfpay.pay.domain.HandleRepeatPay;
import com.sfpay.pay.domain.HandleWxUnknownStatusResp;
import com.sfpay.pay.domain.UpcRequestContext;
import com.sfpay.pay.domain.UpcWxExt;
import com.sfpay.pay.domain.UpdateUpcPayInfoParam;
import com.sfpay.pay.factory.PayChannelFactory;
import com.sfpay.pay.service.impl.UpcMerchantMapService;
import com.sfpay.pay.service.impl.UpcPayInfoManageService;
import com.sfpay.pay.service.impl.WxExtService;
import com.sfpay.pay.util.ReflectUtils;
import com.sfpay.sypay.voucher.valueobject.dto.UserVoucher;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.alipay.AlipayCloseOrderReq;
import com.sfpay.upc.domain.alipay.AlipayCreateOrderReq;
import com.sfpay.upc.domain.alipay.AlipayCreateOrderResp;
import com.sfpay.upc.domain.alipay.AlipayOrderQueryReq;
import com.sfpay.upc.domain.alipay.AlipayOrderQueryResp;
import com.sfpay.upc.domain.alipay.AlipayRefundReq;
import com.sfpay.upc.domain.sfpay.SfPayRefundReq;
import com.sfpay.upc.domain.sfpay.SfPayRefundResp;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.QueryUpcPayParam;
import com.sfpay.upc.domain.upc.UpcBaseReq;
import com.sfpay.upc.domain.upc.UpcBaseResp;
import com.sfpay.upc.domain.upc.UpcMerchantMap;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.upc.UpdateUpcPayStatusParam;
import com.sfpay.upc.domain.voucher.VoucherInfo;
import com.sfpay.upc.domain.voucher.VoucherRefundReq;
import com.sfpay.upc.domain.wx.WXCloseOrderReq;
import com.sfpay.upc.domain.wx.WXCreateOrderReq;
import com.sfpay.upc.domain.wx.WXCreateOrderResp;
import com.sfpay.upc.domain.wx.WXOrderQueryReq;
import com.sfpay.upc.domain.wx.WXOrderQueryResp;
import com.sfpay.upc.domain.wx.WXRefundReq;
import com.sfpay.upc.domain.wx.WXRefundResp;
import com.sfpay.upc.enums.CurrencyType;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.enums.TradeType;
import com.sfpay.upc.exception.UPCServiceException;
import com.sfpay.upc.service.IChannelArgService;
import com.sfpay.wx.domain.BaseResp;
import com.sfpay.wx.domain.OrderQueryResp;
import com.sfpay.wx.domain.RefundResp;

@Service
public class BaseEntryService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	@Resource
	private IChannelArgService channelArg;
	@Resource
	protected UpcMerchantMapService merchantMapService;
	@Resource
	protected UpcPayInfoManageService payManageInfoService;
	@Resource
	protected WxBaseChannelService wxBaseChannelService;
	@Resource
	protected AlipayBaseChannelService alipayBaseChannelService;
	@Resource
	protected WxExtService wxExtService;

	protected UpcBaseResp checkReqParam(UpcBaseReq req, String... fieldNames) {
		if (fieldNames == null || fieldNames.length == 0) {
			return null;
		}
		for (String field : fieldNames) {
			try {
				Object val = ReflectUtils.getValueByFieldName(req, field);
				if (val == null || StringUtils.isEmpty(val.toString())) {
					logger.error(String.format("参数非空校验不通过，code:[%s], msg:[%s]", UpcConstants.PARAM_NULL, "参数" + field + "不能为空"));
					return new UpcBaseResp(UpcConstants.PARAM_NULL, "参数" + field + "不能为空");
				}
			} catch (Exception e) {
			}
		}
		return null;
	}

	protected ChannelArgs getChannelArg(String channelCode, String mchNo) {
		return channelArg.getChannelArgs(channelCode, mchNo);
	}

	protected UpcPayInfo getUpcPayInfo(String mchNo, String channelCode, String uppOrderNo) throws UPCServiceException {
		return getUpcPayInfo(mchNo, null, channelCode, uppOrderNo);
	}

	protected UpcPayInfo getUpcPayInfo(String mchNo, String channelCategoryCode, String channelCode, String uppOrderNo) throws UPCServiceException {
		QueryUpcPayParam payParam = new QueryUpcPayParam();
		payParam.setMchNo(mchNo);
		payParam.setUppOrderNo(uppOrderNo);
		payParam.setChannelCode(channelCode);
		payParam.setChannelCategoryCode(channelCategoryCode);
		return payManageInfoService.queryPayInfo(payParam);
	}

	/**
	 * 获取请求上下文
	 * 
	 * @param
	 * @return
	 * @throws UPCServiceException
	 */
	protected UpcRequestContext getRequestContext(String mchNo, String channelCode) throws UPCServiceException {
		UpcRequestContext context = new UpcRequestContext();

		// 查询商户映射
		UpcMerchantMap mchMap = merchantMapService.queryMerchantMap(mchNo, channelCode);
		if (mchMap == null) {
			throw new ServiceException(UpcConstants.INVALID_MCH_NO, "商户映射不存在， 请配置upc_merchant_map表 商户号:" + mchNo);
		}
		context.setMchMap(mchMap);
		// 查询商户信息

		ChannelArgs channelArgs = getChannelArg(channelCode, mchNo);
		if (channelArgs == null) {
			throw new ServiceException(UpcConstants.INVALID_MCH_NO, "商户配置不存在， 请配置upc_channel_args表商户数据 商户号:" + mchNo);
		}
		context.setChannelArgs(channelArgs);

		return context;
	}

	protected void updateStatusByUppOrderNo(String uppOrderNo, TradeStatus originalStatus, TradeStatus targetStatus) throws UPCServiceException {
		UpdateUpcPayStatusParam upcParam = new UpdateUpcPayStatusParam();
		upcParam.setUppOrderNo(uppOrderNo);
		upcParam.setOriginalStatus(originalStatus.name());
		upcParam.setTargetStatus(targetStatus.name());
		payManageInfoService.updatePayInfoStatus(upcParam);
	}

	protected void updateStatusByUpcPayNo(String payNo, TradeStatus originalStatus, TradeStatus targetStatus) throws UPCServiceException {
		UpdateUpcPayStatusParam upcParam = new UpdateUpcPayStatusParam();
		upcParam.setPayNo(payNo);
		upcParam.setOriginalStatus(originalStatus.name());
		upcParam.setTargetStatus(targetStatus.name());
		payManageInfoService.updatePayInfoStatus(upcParam);
	}

	/**
	 * 处理渠道重复支付
	 * 
	 * @param reqChannelCode
	 * @param context
	 * @param existPayInfo
	 * @return
	 * @throws UPCServiceException
	 */
	protected HandleRepeatPay handleChannelRepeatPay(String reqChannelCode, UpcRequestContext context, UpcPayInfo existPayInfo)
			throws UPCServiceException {

		// 状态校验
		validateExistPayInfoStatus(existPayInfo);

		// 渠道不同
		if (!reqChannelCode.equals(existPayInfo.getChannelCode())) {
			throw new ServiceException(UpcConstants.ORDER_IS_EXISTS, "订单已存在");
		}
		HandleRepeatPay repeatPay = new HandleRepeatPay();
		// 交易进行中查询支付数据
		if (TradeStatus.TRADING.name().equals(existPayInfo.getStatus())) {
			repeatPay = invokeTradeChannel(context.getChannelArgs(), existPayInfo);
		}
		return repeatPay;
	}

	/**
	 * 
	 * @param channelArgs
	 * @param existPayInfo
	 * @return
	 * @throws UPCServiceException
	 */
	private HandleRepeatPay invokeTradeChannel(ChannelArgs channelArgs, UpcPayInfo existPayInfo) throws UPCServiceException {

		IBaseChannelService tradeChannel = PayChannelFactory.getTradeChannel(existPayInfo.getChannelCode());
		HandleChannelBaseResp handleResult = tradeChannel.handleRepeatPay(existPayInfo, channelArgs);

		// 处理结果为空或订单过期
		if (handleResult == null || handleResult.isOrderExpire()) {
			throw new ServiceException(UpcConstants.ORDER_IS_EXPIRE, "订单已过期，不能重新下单");
		}

		HandleRepeatPay repeatPay = new HandleRepeatPay();
		// 微信状态判断
		if (handleResult instanceof HandleWxUnknownStatusResp) {
			// 未支付取原数据
			WXCreateOrderResp wxCreateOrderResp = returnExistData(existPayInfo);
			repeatPay.setWxCreateOrderResp(wxCreateOrderResp);
		}
		// 支付宝状态判断
		else if (handleResult instanceof HandleAlipayUnknownStatusResp) {
			// 未支付不存在返回原始加密数据
			AlipayCreateOrderResp existsResp = alipayBaseChannelService.returnPayData(existPayInfo);
			repeatPay.setAlipayCreateOrderResp(existsResp);
		}

		return repeatPay;
	}

	protected SfPayRefundResp validateMchRefundWater(String mchNo, String channelCode, String uppRefundNo) throws ServiceException, UPCServiceException {
		QueryUpcPayParam payParam = new QueryUpcPayParam();
		payParam.setMchNo(mchNo);
		payParam.setChannelCode(channelCode);
		payParam.setUppOrderNo(uppRefundNo);
		UpcPayInfo payInfo = payManageInfoService.queryPayInfo(payParam);
		
		SfPayRefundResp resp = null;
		if (payInfo != null) {
			if (TradeStatus.REFUND_ACCEPTED.name().equals(payInfo.getStatus())) {
				throw new ServiceException(UpcConstants.ORDER_IS_REFUND_PROC, "该订单退款已受理,无需再次退款");
			} else if (TradeStatus.REFUND_SUCC.name().equals(payInfo.getStatus())) {
				throw new ServiceException(UpcConstants.ORDER_IS_REFUND_SUCC, "该订单退款已成功");
			} else if (TradeStatus.REFUND_FAIL.name().equals(payInfo.getStatus())) {
				throw new ServiceException(UpcConstants.ORDER_IS_REFUND_FAIL, "该订单退款已失败");
			} else if (TradeStatus.REFUND_PROC.name().equals(payInfo.getStatus())) {
				resp = new SfPayRefundResp(UpcConstants.SUCCESS, "正在处理");
				resp.setStatus(TradeStatus.REFUND_PROC.name());
				resp.setUpcRefundNo(payInfo.getPayNo());
				resp.setChannelRtnRefundNo(payInfo.getRtnOrderNo());
			}
		}

		return resp;
	}

	// ************************微信******************************

	private WXCreateOrderResp returnExistData(UpcPayInfo existPayInfo) {
		UpcWxExt wxExt = wxExtService.queryWxExt(existPayInfo.getPayNo());
		WXCreateOrderResp resp = new WXCreateOrderResp();
		resp.setRltCode(BaseResp.SUCCESS);
		resp.setMchNo(existPayInfo.getMchNo());
		resp.setWxPrepayId(wxExt.getPrepayId());
		resp.setCodeUrl(wxExt.getRemark());
		return resp;
	}

	protected void validateExistPayInfoStatus(UpcPayInfo existPayInfo) {
		if (TradeStatus.SUCCESS.name().equals(existPayInfo.getStatus())) {
			throw new ServiceException(UpcConstants.ORDER_IS_SUCCESS, "订单成功，不能重新下单");
		} else if (TradeStatus.FAILURE.name().equals(existPayInfo.getStatus())) {
			throw new ServiceException(UpcConstants.ORDER_IS_FAIL, "订单失败，不能重新下单");
		} else if (TradeStatus.REFUND_SUCC.name().equals(existPayInfo.getStatus())
				|| TradeStatus.REFUND_ACCEPTED.name().equals(existPayInfo.getStatus())) {
			throw new ServiceException(UpcConstants.ORDER_IS_REFUND_SUCC, "订单已退款成功，不能重新下单");
		}
	}

	protected void validateOrderFinishStatus(String status) {
		if (TradeStatus.SUCCESS.name().equals(status)) {
			throw new ServiceException(UpcConstants.ORDER_IS_SUCCESS, "订单已成功");
		} else if (TradeStatus.FAILURE.name().equals(status)) {
			throw new ServiceException(UpcConstants.ORDER_IS_FAIL, "订单已失败");
		} else if (TradeStatus.REFUND_SUCC.name().equals(status)) {
			throw new ServiceException(UpcConstants.ORDER_IS_REFUND_SUCC, "订单已退款成功");
		} else if (TradeStatus.REFUND_FAIL.name().equals(status)) {
			throw new ServiceException(UpcConstants.ORDER_IS_REFUND_FAIL, "订单已退款失败");
		} else if (TradeStatus.CLOSE.name().equals(status)) {
			throw new ServiceException(UpcConstants.ORDER_IS_CLOSED, "订单已关闭");
		}
	}

	protected void recordWxError(String payNo, BaseResp createOrderResp) {
		String wxErrorCode = StringUtils.isNotEmpty(createOrderResp.getErrCode()) ? createOrderResp.getErrCode() : createOrderResp.getReturnCode();
		String wxErrorMsg = StringUtils.isNotEmpty(createOrderResp.getErrCodeDes()) ? createOrderResp.getErrCodeDes() : createOrderResp
				.getReturnMsg();
		// 记录错误
		payManageInfoService.asyncRecordError(payNo, wxErrorCode, wxErrorMsg);
	}

	protected void recordAlipayError(String payNo, AlipayResponse alipayResp) {
		String alipayErrorCode = StringUtils.isNotEmpty(alipayResp.getSubCode()) ? alipayResp.getSubCode() : alipayResp.getCode();
		String alipayErrorMsg = StringUtils.isNotEmpty(alipayResp.getSubMsg()) ? alipayResp.getSubMsg() : alipayResp.getMsg();
		// 记录错误
		payManageInfoService.asyncRecordError(payNo, alipayErrorCode, alipayErrorMsg);
	}

	protected void recordSfPayError(String payNo, SfPayRefundResp resp) {
		// 记录错误
		payManageInfoService.asyncRecordError(payNo, resp.getRltCode(), resp.getRltMsg());
	}

	protected boolean orderNotExistsAndExpres(String errorCode, UpcPayInfo existPayInfo) {
		try {
			if (AlipayErrorCode.TRADE_NOT_EXIST.getCode().equals(errorCode) && wxBaseChannelService.isUpcPayInfoExpire(existPayInfo)) {
				return true;
			}
		} catch (UPCServiceException e) {
		}
		return false;
	}

	protected void validWxRefundReqArgs(WXRefundReq req) {
		if (req == null) {
			throw new ServiceException(UpcConstants.PARAM_NULL);
		}

		if (StringUtils.isEmpty(req.getMchNo())) {
			throw new ServiceException(UpcConstants.MCH_NO_IS_NULL, "商户号为空");
		} else if (StringUtils.isEmpty(req.getChannelCode())) {
			throw new ServiceException(UpcConstants.CHANNEL_CODE_IS_NULL, "支付渠道编号为空");
		} else if (StringUtils.isEmpty(req.getMchRefundNo())) {
			throw new ServiceException(UpcConstants.MCH_REFUND_ORDER_NO_IS_NULL, "商户退款订单号为空");
		} else if (req.getRefundFee() == null || req.getRefundFee().longValue() <= 0) {
			throw new ServiceException(UpcConstants.INVALID_REFUND_AMOUNT, "退款金额无效");
		} else if (StringUtils.isEmpty(req.getMchOrderNo()) && StringUtils.isEmpty(req.getWxOrderNo())) {
			throw new ServiceException(UpcConstants.MCH_ORDER_NO_IS_NULL, "商户订单号或微信订单号为空");
		}
	}

	protected WXOrderQueryResp buildWxResp(OrderQueryResp queryResp, UpcPayInfo payInfo) {
		logger.info("调度查询微信响应数据:{}", queryResp.toString());
		WXOrderQueryResp resp = new WXOrderQueryResp();
		if (BaseResp.SUCCESS.equals(queryResp.getReturnCode()) && BaseResp.SUCCESS.equals(queryResp.getResultCode())) {
			resp.setRltCode(UpcConstants.SUCCESS);
			resp.setChannelCode(payInfo.getChannelCode());
			resp.setBankType(queryResp.getBankType());
			resp.setTradeStatus(queryResp.getTradeState());
			resp.setTradeAmount(payInfo.getTradeAmt());
			resp.setWxOrderNo(queryResp.getWxOrderNo());
			resp.setMchOrderNo(payInfo.getMchOrderNo());
			resp.setRemark(payInfo.getRemark());
		} else {
			resp.setRltCode(StringUtils.isNotBlank(queryResp.getErrCode()) ? queryResp.getErrCode() : "FAIL");
			resp.setRltMsg(StringUtils.isNotBlank(queryResp.getErrCodeDes()) ? queryResp.getErrCodeDes() : queryResp.getReturnMsg());
		}

		return resp;
	}

	protected WXOrderQueryResp buildOrderQueryResp(WXOrderQueryReq req, UpcPayInfo payInfo, UpcWxExt wxExt) {
		WXOrderQueryResp resp = new WXOrderQueryResp();
		if (wxExt != null) {
			resp.setOpenid(wxExt.getOpenId());
			resp.setWxPrepayId(wxExt.getPrepayId());
		}
		resp.setRltCode(UpcConstants.SUCCESS);
		resp.setChannelCode(req.getChannelCode());
		resp.setBankType(payInfo.getPayBankType());
		resp.setTradeStatus(payInfo.getStatus());
		resp.setTradeAmount(payInfo.getTradeAmt());
		resp.setWxOrderNo(payInfo.getRtnOrderNo());
		resp.setMchOrderNo(payInfo.getMchOrderNo());
		resp.setTimeEnd(payInfo.getEndTime());
		resp.setRemark(payInfo.getRemark());
		return resp;
	}

	protected UpcPayInfo buildRefundPayInfo(UpcBaseReq req, UpcPayInfo formerPayInfo, UpcRequestContext context) {

		UpcPayInfo payInfo = new UpcPayInfo();
		payInfo.setChannelCategoryCode(formerPayInfo.getChannelCategoryCode());
		payInfo.setChannelCode(req.getChannelCode());
		payInfo.setMchNo(req.getMchNo());
		payInfo.setPayNo(payManageInfoService.getPayNo());
		if (context != null) {
			payInfo.setChannelMchNo(context.getMchMap().getChannelMchNo());
		}

		String reqChannelRefundNo = null;
		String mchRefundNo = null;
		Long refundFee = null;
		String uppRefundNo = null;
		String useMchnoReq = "Y";
		if (req instanceof SfPayRefundReq) {
			SfPayRefundReq refundReq = (SfPayRefundReq) req;
			reqChannelRefundNo = payInfo.getPayNo();
			mchRefundNo = refundReq.getMchRefundNo();
			refundFee = refundReq.getRefundFee() == null ? formerPayInfo.getTradeAmt() : refundReq.getRefundFee();
			uppRefundNo = refundReq.getUppRefundNo();
			useMchnoReq = "N";
		} else if (req instanceof VoucherRefundReq) {
			VoucherRefundReq refundReq = (VoucherRefundReq) req;
			reqChannelRefundNo = payInfo.getPayNo();
			mchRefundNo = refundReq.getMchRefundNo();
			refundFee = formerPayInfo.getTradeAmt();
			uppRefundNo = refundReq.getUppRefundNo();
		} else if (req instanceof WXRefundReq) {
			WXRefundReq refundReq = (WXRefundReq) req;
			reqChannelRefundNo = refundReq.getMchRefundNo();
			mchRefundNo = refundReq.getMchRefundNo();
			refundFee = refundReq.getRefundFee() == null ? formerPayInfo.getTradeAmt() : refundReq.getRefundFee();
			uppRefundNo = refundReq.getUppRefundNo();
		} else if (req instanceof AlipayRefundReq) {
			AlipayRefundReq refundReq = (AlipayRefundReq) req;
			reqChannelRefundNo = refundReq.getMchRefundNo();
			mchRefundNo = refundReq.getMchRefundNo();
			refundFee = refundReq.getRefundFee() == null ? formerPayInfo.getTradeAmt() : refundReq.getRefundFee();
			uppRefundNo = refundReq.getUppRefundNo();
		}

		payInfo.setMchOrderNo(mchRefundNo);
		payInfo.setReqOrderNo(reqChannelRefundNo);
		payInfo.setChannelMchNo(formerPayInfo.getChannelMchNo());
		payInfo.setUseMchnoReq(useMchnoReq);
		payInfo.setSystemSource(formerPayInfo.getSystemSource());
		payInfo.setTradeType(TradeType.PAY_REFUND.name());
		payInfo.setTradeFee(0L);
		payInfo.setTradeAmt(refundFee);
		payInfo.setCcy(CurrencyType.RMB.name());
		payInfo.setStatus(TradeStatus.REFUND_PROC.name());
		payInfo.setProductName(formerPayInfo.getProductName());
		payInfo.setUppOrderNo(uppRefundNo);
		payInfo.setMemberNo(formerPayInfo.getMemberNo());
		payInfo.setVoucherCode(formerPayInfo.getVoucherCode());

		payInfo.setOldPayNo(formerPayInfo.getPayNo());
		payInfo.setOldRtnOrderNo(formerPayInfo.getRtnOrderNo());
		payInfo.setOldMchOrderNo(formerPayInfo.getMchOrderNo());
		payInfo.setOldUppOrderNo(formerPayInfo.getUppOrderNo());

		// 设置通知地址
		String notifyUrl = String.format("%s/upc/{0}/notify", Property.getProperty("OUT_SYF_UPC_URI"));
		payInfo.setMchNotifyUrl(new MessageFormat(notifyUrl).format(new Object[] { payInfo.getPayNo() }));
		return payInfo;
	}

	/**
	 * 设置券信息
	 * 
	 * @param voucher
	 * @return
	 */
	protected VoucherInfo setVoucherInfo(UserVoucher voucher) {
		VoucherInfo voucherInfo = new VoucherInfo();
		voucherInfo.setRltCode(UpcConstants.SUCCESS);
		voucherInfo.setActId(voucher.getActId());
		voucherInfo.setActName(voucher.getActName());
		voucherInfo.setAmt(voucher.getAmt());
		voucherInfo.setAmtSrt(voucher.getAmtSrt());
		voucherInfo.setCreateTime(voucher.getCreateTime());
		voucherInfo.setCutType(voucher.getCutType());
		voucherInfo.setEndTime(voucher.getEndTime());
		voucherInfo.setEndTimeStr(voucher.getEndTimeStr());
		voucherInfo.setFullCut(voucher.getFullCut());
		voucherInfo.setFullCutStr(voucher.getFullCutStr());
		voucherInfo.setGetChanel(voucher.getGetChanel());
		voucherInfo.setGetType(voucher.getGetType().name());
		voucherInfo.setGiveSystem(voucher.getGiveSystem());
		voucherInfo.setIsCurrency(voucher.getIsCurrency());
		voucherInfo.setMemberNo(voucher.getMemberNo());
		voucherInfo.setMerchantMemNo(voucher.getMerchantMemNo());
		voucherInfo.setMerchantNo(voucher.getMerchantNo());
		voucherInfo.setMobile(voucher.getMobile());
		voucherInfo.setName(voucher.getName());
		voucherInfo.setOperatorId(voucher.getOperatorId());
		voucherInfo.setOrgCode(voucher.getOrgCode());
		voucherInfo.setProjectCode(voucher.getProjectCode());
		voucherInfo.setRemark(voucher.getRemark());
		voucherInfo.setStartTime(voucher.getStartTime());
		voucherInfo.setTypeCode(voucher.getTypeCode());
		voucherInfo.setUpdateTime(voucher.getUpdateTime());
		voucherInfo.setUseChanel(voucher.getUseChanel());
		voucherInfo.setUseStatus(voucher.getUseStatus().name());
		voucherInfo.setVoucherId(voucher.getVoucherId());
		return voucherInfo;
	}

	protected void validCreateWxOrderReqArgs(WXCreateOrderReq payReq) {

		if (payReq == null) {
			throw new ServiceException(UpcConstants.PARAM_NULL);
		}

		if (StringUtils.isEmpty(payReq.getMchNo())) {
			throw new ServiceException(UpcConstants.MCH_NO_IS_NULL, "商户号为空");
		} else if (StringUtils.isEmpty(payReq.getChannelCode())) {
			throw new ServiceException(UpcConstants.CHANNEL_CODE_IS_NULL, "支付渠道编号为空");
		} else if (StringUtils.isEmpty(payReq.getMchOrderNo())) {
			throw new ServiceException(UpcConstants.MCH_ORDER_NO_IS_NULL, "商户订单号为空");
		} else if (StringUtils.isEmpty(payReq.getProductName())) {
			throw new ServiceException(UpcConstants.MCH_PRODUCT_NAME_IS_NULL, "商品名为空");
		} else if (payReq.getTradeAmount() == null || payReq.getTradeAmount().longValue() <= 0) {
			throw new ServiceException(UpcConstants.TRADE_AMOUNT_IS_NULL, "交易金额为空或不合法");
		} else if (StringUtils.isEmpty(payReq.getRequestIp())) {
			throw new ServiceException(UpcConstants.REQUEST_IP_IS_NULL, "客户端请求ip为空");
		} else if (StringUtils.isEmpty(payReq.getSystemSource())) {
			throw new ServiceException(UpcConstants.SYSTEM_SOURCE_IS_NULL, "系统来源为空");
		}
	}

	protected void validCloseOrderReqParams(WXCloseOrderReq req) {
		if (req == null) {
			throw new ServiceException(UpcConstants.PARAM_NULL);
		}

		if (StringUtils.isEmpty(req.getMchNo())) {
			throw new ServiceException(UpcConstants.MCH_NO_IS_NULL, "商户号为空");
		} else if (StringUtils.isEmpty(req.getMchOrderNo()) && StringUtils.isEmpty(req.getWxOrderNo())) {
			throw new ServiceException(UpcConstants.MCH_ORDER_NO_IS_NULL, "商户订单号为空");
		}
	}

	protected UpdateUpcPayInfoParam buildUpdateRefundData(UpcPayInfo refundPayInfo, RefundResp refundResp) {
		UpdateUpcPayInfoParam updatePayReq = new UpdateUpcPayInfoParam();
		updatePayReq.setPayNo(refundPayInfo.getPayNo());
		updatePayReq.setOriginalStatus(TradeStatus.REFUND_PROC.name());
		updatePayReq.setRtnOrderNo(refundResp.getRefundId());

		if (UpcConstants.SUCCESS.equals(refundResp.getReturnCode()) && UpcConstants.SUCCESS.equals(refundResp.getResultCode())) {
			// 修改退款流水状态为退款受理
			updatePayReq.setTargetStatus(TradeStatus.REFUND_ACCEPTED.name());
		} else {
			// 退款流水退款失败
			updatePayReq.setTargetStatus(TradeStatus.REFUND_FAIL.name());
			updatePayReq.setRtnCode(StringUtils.isNotBlank(refundResp.getErrCode()) ? refundResp.getErrCode() : refundResp.getReturnCode());
			updatePayReq.setRtnMsg(StringUtils.isNotBlank(refundResp.getErrCodeDes()) ? refundResp.getErrCodeDes() : refundResp.getReturnMsg());
		}
		return updatePayReq;
	}

	protected WXRefundResp validateMchRefundWater(WXRefundReq req) throws UPCServiceException {
		QueryUpcPayParam payParam = new QueryUpcPayParam();
		payParam.setChannelCode(req.getChannelCode());
		payParam.setMchNo(req.getMchNo());
		payParam.setUppOrderNo(req.getUppRefundNo());
		UpcPayInfo payInfo = payManageInfoService.queryPayInfo(payParam);
		WXRefundResp refundResp = null;
		if (payInfo != null) {
			refundResp = new WXRefundResp();

			String errorCode = null;
			String errorMsg = null;
			if (TradeStatus.REFUND_ACCEPTED.name().equals(payInfo.getStatus())) {
				errorCode = UpcConstants.ORDER_IS_REFUND_PROC;
				errorMsg = "该订单退款已受理,无需再次退款";
			} else if (TradeStatus.REFUND_SUCC.name().equals(payInfo.getStatus())) {
				errorCode = UpcConstants.ORDER_IS_REFUND_SUCC;
				errorMsg = "该订单退款已成功";
			} else if (TradeStatus.REFUND_FAIL.name().equals(payInfo.getStatus())) {
				errorCode = UpcConstants.ORDER_IS_REFUND_FAIL;
				errorMsg = "该订单退款已失败";
			}
			refundResp.setRltCode(errorCode);
			refundResp.setRltMsg(errorMsg);
			refundResp.setStatus(payInfo.getStatus());
			refundResp.setWxRefundId(payInfo.getRtnOrderNo());
		}
		return refundResp;

	}

	// ************************微信******************************

	// ************************支付宝******************************

	protected AlipayOrderQueryResp buildOrderQueryResp(AlipayOrderQueryReq req, UpcPayInfo payInfo) {
		AlipayOrderQueryResp resp = new AlipayOrderQueryResp();
		resp.setRltCode(UpcConstants.SUCCESS);
		resp.setChannelCode(req.getChannelCode());
		resp.setTradeStatus(payInfo.getStatus());
		resp.setTradeAmount(payInfo.getTradeAmt());
		resp.setMchOrderNo(payInfo.getMchOrderNo());
		resp.setTimeEnd(payInfo.getEndTime());
		resp.setRemark(payInfo.getRemark());
		return resp;
	}

	protected void validCreateAlipayOrderReqArgs(AlipayCreateOrderReq payReq) {

		if (payReq == null) {
			throw new ServiceException(UpcConstants.PARAM_NULL);
		}

		if (StringUtils.isEmpty(payReq.getMchNo())) {
			throw new ServiceException(UpcConstants.MCH_NO_IS_NULL, "商户号为空");
		} else if (StringUtils.isEmpty(payReq.getChannelCode())) {
			throw new ServiceException(UpcConstants.CHANNEL_CODE_IS_NULL, "支付渠道编号为空");
		} else if (StringUtils.isEmpty(payReq.getMchOrderNo())) {
			throw new ServiceException(UpcConstants.MCH_ORDER_NO_IS_NULL, "商户订单号为空");
		} else if (StringUtils.isEmpty(payReq.getProductName())) {
			throw new ServiceException(UpcConstants.MCH_PRODUCT_NAME_IS_NULL, "商品名为空");
		} else if (payReq.getTradeAmount() == null || payReq.getTradeAmount().longValue() <= 0) {
			throw new ServiceException(UpcConstants.TRADE_AMOUNT_IS_NULL, "交易金额为空或不合法");
		} else if (StringUtils.isEmpty(payReq.getSystemSource())) {
			throw new ServiceException(UpcConstants.SYSTEM_SOURCE_IS_NULL, "系统来源为空");
		}
	}

	protected void validAlipayRefundReqArgs(AlipayRefundReq req) {
		if (req == null) {
			throw new ServiceException(UpcConstants.PARAM_NULL);
		}

		if (StringUtils.isEmpty(req.getMchNo())) {
			throw new ServiceException(UpcConstants.MCH_NO_IS_NULL, "商户号为空");
		} else if (StringUtils.isEmpty(req.getChannelCode())) {
			throw new ServiceException(UpcConstants.CHANNEL_CODE_IS_NULL, "支付渠道编号为空");
		} else if (StringUtils.isEmpty(req.getMchRefundNo())) {
			throw new ServiceException(UpcConstants.MCH_REFUND_ORDER_NO_IS_NULL, "商户退款订单号为空");
		} else if (req.getRefundFee() == null || req.getRefundFee().longValue() <= 0) {
			throw new ServiceException(UpcConstants.INVALID_REFUND_AMOUNT, "退款金额无效");
		} else if (StringUtils.isEmpty(req.getMchOrderNo())) {
			throw new ServiceException(UpcConstants.MCH_ORDER_NO_IS_NULL, "商户订单号为空");
		}
	}

	protected void validCloseOrderReqParams(AlipayCloseOrderReq req) {
		if (req == null) {
			throw new ServiceException(UpcConstants.PARAM_NULL);
		}

		if (StringUtils.isEmpty(req.getMchNo())) {
			throw new ServiceException(UpcConstants.MCH_NO_IS_NULL, "商户号为空");
		} else if (StringUtils.isEmpty(req.getUppOrderNo())) {
			throw new ServiceException(UpcConstants.PARAM_NULL, "UPP订单号为空");
		}
	}

	protected UpdateUpcPayInfoParam buildUpdateRefundData(UpcPayInfo refundPayInfo, AlipayTradeRefundResponse refundResp) {
		UpdateUpcPayInfoParam updatePayReq = new UpdateUpcPayInfoParam();
		updatePayReq.setPayNo(refundPayInfo.getPayNo());
		updatePayReq.setOriginalStatus(TradeStatus.REFUND_PROC.name());

		// 返回码成功且资金发生变化
		if (refundResp != null && AlipayConstants.SUCCESS.equals(refundResp.getCode()) && "Y".equals(refundResp.getFundChange())) {
			// 修改退款流水状态为退款成功
			updatePayReq.setTargetStatus(TradeStatus.REFUND_SUCC.name());

		} else if (refundResp == null || AlipayConstants.ERROR.equals(refundResp.getCode())) {
			// 未知
		} else {
			// 退款流水退款失败
			updatePayReq.setTargetStatus(TradeStatus.REFUND_FAIL.name());
		}

		updatePayReq.setRtnCode(refundResp.getSubCode());
		updatePayReq.setRtnMsg(refundResp.getSubMsg());

		return updatePayReq;
	}

	// 更新原订单状态为退款成功
	protected void updateOriginalOrderToRefundSucc(UpcPayInfo existsPayInfo) throws UPCServiceException {
		UpdateUpcPayInfoParam updatePayReq = new UpdateUpcPayInfoParam();
		updatePayReq.setPayNo(existsPayInfo.getPayNo());
		updatePayReq.setRtnOrderNo(existsPayInfo.getRtnOrderNo());
		updatePayReq.setOriginalStatus(TradeStatus.SUCCESS.name());
		updatePayReq.setTargetStatus(TradeStatus.REFUND_SUCC.name());
		payManageInfoService.updatePayInfo(updatePayReq);

		logger.info("更新原订单为成功  商户号:[{}] 订单号:[{}]", existsPayInfo.getMchNo(), existsPayInfo.getMchOrderNo());
	}

	// ************************支付宝******************************
}
