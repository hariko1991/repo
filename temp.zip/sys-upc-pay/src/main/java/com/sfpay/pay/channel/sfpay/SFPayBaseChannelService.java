package com.sfpay.pay.channel.sfpay;

import java.net.SocketTimeoutException;
import java.text.MessageFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.httpclient.ConnectTimeoutException;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.common.json.JSONUtils;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework2.core.util.DateUtil;
import com.sfpay.pay.channel.enums.ExceptionBusiType;
import com.sfpay.pay.channel.enums.ExceptionType;
import com.sfpay.pay.channel.enums.UpcSfPayErrorCode;
import com.sfpay.pay.channel.enums.UpcSfPayStatusTransfer;
import com.sfpay.pay.channel.sfpay.vo.CloseSFPayOrderReqVo;
import com.sfpay.pay.channel.sfpay.vo.CloseSFPayOrderRespVo;
import com.sfpay.pay.channel.sfpay.vo.OperatorSFPayBalanceReqVo;
import com.sfpay.pay.channel.sfpay.vo.OrderSFPayReqVo;
import com.sfpay.pay.channel.sfpay.vo.OrderSFPayRespVo;
import com.sfpay.pay.channel.sfpay.vo.QuerySFPayOrderRespVo;
import com.sfpay.pay.channel.sfpay.vo.SFPayRefundReqVo;
import com.sfpay.pay.channel.sfpay.vo.SFPayRefundRespVo;
import com.sfpay.pay.channel.sfpay.vo.SFPaySignQueryReqVo;
import com.sfpay.pay.channel.sfpay.vo.SFPaySignQueryRespVo;
import com.sfpay.pay.channel.sfpay.vo.SfPayBaseProtocal;
import com.sfpay.pay.dao.UpcPayInfoDao;
import com.sfpay.pay.domain.HandleChannelBaseResp;
import com.sfpay.pay.domain.UpdateUpcPayInfoParam;
import com.sfpay.pay.service.impl.UpcPayInfoManageService;
import com.sfpay.pay.util.DateUtils;
import com.sfpay.pay.util.MD5Util;
import com.sfpay.pay.util.ReflectUtils;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.sfpay.SfPayCreateOrderReq;
import com.sfpay.upc.domain.sfpay.SfPayCreateOrderResp;
import com.sfpay.upc.domain.sfpay.SfPayRefundResp;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.upc.UpcPayUnknownParam;
import com.sfpay.upc.domain.upc.UpdateUpcPayStatusParam;
import com.sfpay.upc.enums.ChannelTradeType;
import com.sfpay.upc.enums.ChannelType;
import com.sfpay.upc.enums.CurrencyType;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.enums.TradeType;
import com.sfpay.upc.exception.UPCServiceException;
import com.sfpay.upc.service.IHttpProxyService;
import com.sfpay.upc.service.IMqService;
import com.sfpay.upc.service.IUpcPayInfoService;

/**
 * 
 * 类说明：<br>
 * 顺手付渠道基础服务
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-22
 */
@Service("sfPayBaseChannelService")
public class SFPayBaseChannelService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	protected UpcPayInfoDao upcPayInfoDao;
	@Resource
	protected UpcPayInfoManageService payManageInfoService;
	@Resource
	protected IUpcPayInfoService upcPayInfoService;
	@Resource
	protected IHttpProxyService httpProxyService;
	@Resource
	protected IMqService mqService;
	// 顺手付请求成功
	protected static final String SFPAY_SUCCESS_REQ = "00";
	// 顺手付成功状态
	protected static final String SFPAY_SUCCESS_STATUS = "SUCCESS";
	// 顺手付失败状态
	protected static final String SFPAY_FAILURE_STATUS = "FAILURE";
	// 顺手付系统异常
	protected static final String SFPAY_SYSTEM_EXCEPTION = "990006";
	// 顺手付重复提交
	protected static final String SFPAY_REPEAT_SUBMIT = "990019";

	public SfPayCreateOrderResp createPayOrder(SfPayCreateOrderReq payReq) throws UPCServiceException {
		logger.info("请求支付 SFPayBaseChannelService.createPayOrder 参数 ：req:{}", payReq.toString());
		long startTime = System.currentTimeMillis();
		UpcPayInfo payInfo = buildUpcPayInfo(payReq);
		// 创建统一支付流水
		payManageInfoService.createPayInfo(payInfo);

		// 组装请求顺手付网关数据
		String reqUrl = Property.getProperty("SFPAY_GATPRX_URL") + Property.getProperty("SFPAY_ORDER");
		String reqMsg = packOrderSfpayReqMsg(payReq.getSceneCode(), payInfo);

		// 请求顺手付
		OrderSFPayRespVo orderSFPayResp = (OrderSFPayRespVo) httpSfPay(ExceptionBusiType.SFPAY_ORDER, reqUrl, reqMsg, OrderSFPayRespVo.class);

		if (orderSFPayResp == null || !SFPAY_SUCCESS_REQ.equals(orderSFPayResp.getRltCode())) {

			updateUpcOrderStatus(payInfo.getPayNo(), TradeStatus.INIT, TradeStatus.FAILURE);

			recordErrorInfo(payInfo.getPayNo(), orderSFPayResp.getRltCode(), orderSFPayResp.getRltMsg());
			// 错误码转换
			throw new ServiceException(UpcConstants.FAILURE_SYS, orderSFPayResp.getRltMsg());
		}
		// 验证签名
		validateSign(orderSFPayResp.getSign(), orderSFPayResp, orderSFPayResp.getResponseTime(), "gatewayNo");
		// 更新网关流水号到upc
		UpdateUpcPayInfoParam updatePayReq = new UpdateUpcPayInfoParam();
		updatePayReq.setPayNo(payInfo.getPayNo());
		updatePayReq.setRtnOrderNo(orderSFPayResp.getGatewayNo());
		payManageInfoService.updatePayInfo(updatePayReq);

		// 组装返回数据
		SfPayCreateOrderResp resp = new SfPayCreateOrderResp(UpcConstants.SUCCESS, null);
		resp.setMchNo(payReq.getMchNo());
		resp.setChannelCode(payReq.getChannelCode());
		resp.setUpcTradeNo(payInfo.getPayNo());
		resp.setChannelRtnNo(orderSFPayResp.getGatewayNo());
		logger.info("请求支付 SFPayBaseChannelService.createPayOrder 返回结果 ：resp:{}", resp.toString());

		logger.info("请求支付结束 共用时:[{}]秒", System.currentTimeMillis() - startTime);

		return resp;
	}

	/**
	 * 关闭顺手付订单
	 * 
	 * @param payInfo
	 * @throws UPCServiceException
	 */
	public void closeSfPayOrder(UpcPayInfo payInfo, TradeStatus orginalStatus) throws UPCServiceException {

		// 组装请求顺手付网关数据
		String reqUrl = Property.getProperty("SFPAY_GATPRX_URL") + Property.getProperty("SFPAY_ORDER_CANCEL");
		String reqMsg = packCloseOrderReqMsg(payInfo);

		// 请求顺手付
		CloseSFPayOrderRespVo orderSFPayResp = (CloseSFPayOrderRespVo) httpSfPay(ExceptionBusiType.SFPAY_CLOSE_ORDER, reqUrl, reqMsg,
				CloseSFPayOrderRespVo.class);

		if (SFPAY_SUCCESS_REQ.equals(orderSFPayResp.getRltCode())) {

			validateSign(orderSFPayResp.getSign(), orderSFPayResp, orderSFPayResp.getResponseTime(), "status");

			if (!SFPAY_SUCCESS_STATUS.equals(orderSFPayResp.getStatus())) {

				recordErrorInfo(payInfo.getPayNo(), orderSFPayResp.getRltCode(), orderSFPayResp.getStatus());
				throw new ServiceException(UpcConstants.ORDER_CLOSE_FAIL, "渠道关单失败");
			}

			updateUpcOrderStatus(payInfo.getPayNo(), orginalStatus, TradeStatus.CLOSE);

		} else {

			recordErrorInfo(payInfo.getPayNo(), orderSFPayResp.getRltCode(), orderSFPayResp.getRltMsg());

			String upcErrorCode = null;
			try {
				upcErrorCode = UpcSfPayErrorCode.valueOf(UpcSfPayErrorCode.prefix + orderSFPayResp.getRltCode()).getUpcErrorCode();
			} catch (Exception e) {
				logger.error("无法识别错误码" + orderSFPayResp.getRltCode(), e);
				// 错误码转换
				throw new ServiceException(UpcConstants.ORDER_CLOSE_FAIL, orderSFPayResp.getRltMsg());
			}
			throw new ServiceException(upcErrorCode, orderSFPayResp.getRltMsg());

		}

	}

	/**
	 * 顺手付退款
	 * 
	 * @param refundPayInfo
	 * @return
	 * @throws UPCServiceException
	 */
	public SfPayRefundResp sfPayRefund(UpcPayInfo refundPayInfo) throws UPCServiceException {

		// 组装请求顺手付网关数据
		String reqUrl = Property.getProperty("SFPAY_GATPRX_URL") + Property.getProperty("SFPAY_PAY_REFUND");
		String reqMsg = packRefundReqMsg(refundPayInfo);

		// 请求顺手付
		SFPayRefundRespVo sfPayRefundResp = null;
		try {
			sfPayRefundResp = (SFPayRefundRespVo) httpSfPay(ExceptionBusiType.SFPAY_REFUND, reqUrl, reqMsg, SFPayRefundRespVo.class);
		} catch (ServiceException e) {
			// 超时处理
			if (UpcConstants.SOCKET_TIMEOUT.equals(e.getCode())) {
				return handleSfpayRefundException(refundPayInfo);
			}
			throw new ServiceException(e.getCode(), e.getMsg());
		}
		// 交易成功或处理中认为成功
		if (SFPAY_SUCCESS_REQ.equals(sfPayRefundResp.getRltCode())) {
			// 验证签名
			validateSign(sfPayRefundResp.getSign(), sfPayRefundResp, sfPayRefundResp.getResponseTime(), "status", "refundBusinessNo");
			return handleSfPayRefund(refundPayInfo, sfPayRefundResp);
		}
		else {
			logger.info("顺手付退款失败 refundPayNo:{}", refundPayInfo.getPayNo());
			recordErrorInfo(refundPayInfo.getPayNo(), sfPayRefundResp.getRltCode(), sfPayRefundResp.getRltMsg());
			return handleSfpayRefundException(refundPayInfo);
		}

	}

	private SfPayRefundResp handleSfPayRefund(UpcPayInfo refundPayInfo, SFPayRefundRespVo sfPayRefundResp) throws UPCServiceException {
		TradeStatus respStatus = null;
		if (SFPAY_SUCCESS_STATUS.equals(sfPayRefundResp.getStatus())) {
			logger.info("请求退款结束 refundPayNo:{}", refundPayInfo.getPayNo());
			respStatus = TradeStatus.REFUND_SUCC;
			updateUpcRefundStatus(refundPayInfo, respStatus, sfPayRefundResp.getRefundBusinessNo());

			refundPayInfo.setRtnOrderNo(sfPayRefundResp.getRefundBusinessNo());
			// 发送mq
			sendMqAndRecordToUpp(refundPayInfo, respStatus, null, null);
		} else if (SFPAY_FAILURE_STATUS.equals(sfPayRefundResp.getStatus())) {
			respStatus = TradeStatus.REFUND_FAIL;
			updateUpcRefundStatus(refundPayInfo, respStatus, sfPayRefundResp.getRefundBusinessNo());

			refundPayInfo.setRtnOrderNo(sfPayRefundResp.getRefundBusinessNo());
			// 发送mq
			sendMqAndRecordToUpp(refundPayInfo, respStatus, sfPayRefundResp.getRltCode(), sfPayRefundResp.getRltMsg());

		} else if ("PROCESSING".equals(sfPayRefundResp.getStatus())) {
			respStatus = TradeStatus.TRADING;
		} else if ("INIT".equals(sfPayRefundResp.getStatus())){
			respStatus = TradeStatus.INIT;
		} else {
			throw new ServiceException(UpcConstants.FAILURE_SYS, sfPayRefundResp.getRltMsg());
		}

		SfPayRefundResp refundResp = new SfPayRefundResp(UpcConstants.SUCCESS, null);
		refundResp.setStatus(respStatus.name());
		refundResp.setUpcRefundNo(refundPayInfo.getPayNo());
		refundResp.setChannelRtnRefundNo(sfPayRefundResp.getRefundBusinessNo());
		return refundResp;
	}

	private void updateUpcRefundStatus(UpcPayInfo refundPayInfo, TradeStatus tradeStatus, String rtnOrderNo) throws UPCServiceException {
		UpcPayUnknownParam upcParam = new UpcPayUnknownParam();
		upcParam.setPayNo(refundPayInfo.getPayNo());
		upcParam.setOriginalStatus(TradeStatus.REFUND_PROC.name());
		upcParam.setTargetStatus(tradeStatus.name());
		upcParam.setRtnOrderNo(rtnOrderNo);
		// 更新状态
		upcPayInfoService.updateUpcPayUnknown(upcParam);
	}


	private SfPayRefundResp handleSfpayRefundException(UpcPayInfo refundPayInfo) throws UPCServiceException {
		// 查询结果
		HandleChannelBaseResp queryResult = orderQuery(refundPayInfo);
		
		SFPayRefundRespVo sfPayRefundResp = new SFPayRefundRespVo();
		sfPayRefundResp.setRefundBusinessNo(queryResult.getGatewayNo());
		sfPayRefundResp.setRltCode(queryResult.getRltCode());
		sfPayRefundResp.setRltMsg(queryResult.getRltMsg());
		sfPayRefundResp.setStatus(queryResult.getChannelStatus());
		
		return handleSfPayRefund(refundPayInfo, sfPayRefundResp);
	}

	private String packRefundReqMsg(UpcPayInfo refundPayInfo) {
		SFPayRefundReqVo refundReq = new SFPayRefundReqVo();
		setProtocal(refundReq, "PAY_REFUND");

		refundReq.setMerchantId(refundPayInfo.getMchNo());
		refundReq.setOrderId(refundPayInfo.getOldPayNo());
		refundReq.setRefundId(refundPayInfo.getPayNo());
		refundReq.setAmt(String.valueOf(refundPayInfo.getTradeAmt()));
		refundReq.setOrderBeginTime(DateUtils.formatDate(new Date(), "yyyyMMddHHmmss"));
		refundReq.setNotifyUrl(refundPayInfo.getMchNotifyUrl());
		// 生成签名
		String sign = packSign(refundReq, refundReq.getRequestTime(), "amt", "merchantId", "orderId", "refundId");
		refundReq.setSign(sign);

		// 生成请求字符串
		String reqformData = packSfpayFormData(refundReq, "serviceName", "serviceVersion", "charset", "signType", "requestTime", "amt", "merchantId",
				"refundId", "orderId", "notifyUrl", "sign");

		return reqformData;
	}

	/**
	 * 顺手付订单查询
	 * 
	 * @param payInfo
	 * @return
	 * @throws UPCServiceException
	 */
	public HandleChannelBaseResp handleSfPayOrderResult(UpcPayInfo payInfo) throws UPCServiceException {

		HandleChannelBaseResp queryResult = orderQuery(payInfo);

		TradeStatus tradeStatus = TradeStatus.valueOf(queryResult.getTradeStatus());
		
		// 余额且失败不处理状态
		if(ChannelTradeType.SFPAY_BALANCE.name().equals(payInfo.getChannelCode()) && TradeStatus.FAILURE == tradeStatus) {
			return queryResult;
		}
		
		if (TradeStatus.SUCCESS == tradeStatus || TradeStatus.FAILURE == tradeStatus || TradeStatus.CLOSE == tradeStatus) {
			// 终态更新
			updateUpcOrderStatus(payInfo.getPayNo(), TradeStatus.TRADING, tradeStatus);
		}
		return queryResult;

	}

	/**
	 * 顺手付订单查询
	 * 
	 * @param payInfo
	 * @return
	 * @throws UPCServiceException
	 */
	public HandleChannelBaseResp orderQuery(UpcPayInfo payInfo) throws UPCServiceException {

		// 组装请求顺手付网关数据
		String reqUrl = Property.getProperty("SFPAY_GATPRX_URL") + Property.getProperty("SFPAY_ORDER_QUERY");
		String reqMsg = packOrderQueryReqMsg(payInfo.getMchNo(), payInfo.getPayNo());

		// 请求顺手付
		QuerySFPayOrderRespVo querySFOrderResp = (QuerySFPayOrderRespVo) httpSfPay(ExceptionBusiType.SFPAY_ORDER_QUERY, reqUrl, reqMsg,
				QuerySFPayOrderRespVo.class);

		if (SFPAY_SUCCESS_REQ.equals(querySFOrderResp.getRltCode())) {
			UpcSfPayStatusTransfer sfOrderStatus = null;
			try {
				sfOrderStatus = UpcSfPayStatusTransfer.valueOf(querySFOrderResp.getStatus());
			} catch (Exception e) {
				logger.info("订单查询返回状态非法：{}", querySFOrderResp.toString());
				throw new ServiceException(UpcConstants.FAILURE_SYS, "系统异常");
			}

			validateSign(querySFOrderResp.getSign(), querySFOrderResp, querySFOrderResp.getResponseTime(), "merchantId", "orderId", "gatewayNo",
					"sfBusinessNo", "status", "amt");

			HandleChannelBaseResp resp = new HandleChannelBaseResp();
			resp.setRltCode(UpcConstants.SUCCESS);
			resp.setTradeStatus(sfOrderStatus.getTargetStatus());
			resp.setChannelStatus(querySFOrderResp.getStatus());
			resp.setGatewayNo(querySFOrderResp.getGatewayNo());
			resp.setSfBusinessNo(querySFOrderResp.getSfBusinessNo());
			return resp;

		} else {

			recordErrorInfo(payInfo.getPayNo(), querySFOrderResp.getRltCode(), querySFOrderResp.getRltMsg());
			// 错误码转换
			throw new ServiceException(UpcConstants.FAILURE_SYS, querySFOrderResp.getRltMsg());

		}

	}

	/**
	 * 查询签约数据
	 * 
	 * @param payInfo
	 * @return
	 * @throws UPCServiceException
	 */
	protected SFPaySignQueryRespVo querySfPaySignNo(UpcPayInfo payInfo) throws UPCServiceException {

		String signQueryReqUrl = Property.getProperty("SFPAY_GATPRX_URL") + Property.getProperty("SFPAY_SIGN_QUERY");
		String signQueryReqMsg = buildSignQueryMsg(payInfo);

		// 获取授权签约号
		SFPaySignQueryRespVo signQueryResp = (SFPaySignQueryRespVo) httpSfPay(ExceptionBusiType.SFPAY_ORDER_QUERY, signQueryReqUrl, signQueryReqMsg,
				SFPaySignQueryRespVo.class);

		if (SFPAY_SUCCESS_REQ.equals(signQueryResp.getRltCode())) {

			// 验签
			validateSign(signQueryResp.getSign(), signQueryResp, signQueryResp.getResponseTime(), "contractNo", "status");
			if (!SFPAY_SUCCESS_STATUS.equals(signQueryResp.getStatus())) {
				recordErrorInfo(payInfo.getPayNo(), signQueryResp.getRltCode(), signQueryResp.getStatus());
				throw new ServiceException(UpcConstants.QUERY_SIGNNO_FAIL, "EXPIRE".equals(signQueryResp.getStatus()) ? "签约已过期" : "查询签约号失败");
			}

		} else {
			recordErrorInfo(payInfo.getPayNo(), signQueryResp.getRltCode(), signQueryResp.getRltMsg());
			throw new ServiceException(UpcConstants.QUERY_SIGNNO_FAIL, signQueryResp.getRltMsg());
		}

		logger.info("查询签约号 payNo:{}, contractNo:{}", payInfo.getPayNo(), signQueryResp.getContractNo());
		return signQueryResp;
	}

	/**
	 * 记录异常信息
	 * 
	 * @param payNo
	 * @param errorCode
	 * @param errorMsg
	 * @throws UPCServiceException
	 */
	protected void recordErrorInfo(String payNo, String errorCode, String errorMsg) throws UPCServiceException {

		payManageInfoService.asyncRecordError(payNo, errorCode, errorMsg);
	}

	/**
	 * 
	 * @param businessType
	 * @param reqUrl
	 * @param reqMsg
	 * @param clazz
	 *            转成目标类
	 * @return
	 */
	protected Object httpSfPay(ExceptionBusiType businessType, String reqUrl, String reqMsg, Class<?> clazz) {
		logger.info("请求顺手付 type:{}, :url：{}, 请求信息:{}", new Object[] { businessType.name(), reqUrl, reqMsg });
		String sfPayOrderResult = null;
		try {
			sfPayOrderResult = httpProxyService.sendByPostNoProxy(reqUrl, reqMsg);
		} catch (Exception e) {
			logger.error(String.format("请求顺手付下单异常:type:%s, url:%s, 报文:%s", businessType.name(), reqUrl, reqMsg), e);

			ExceptionType exceptionType = ExceptionType.HTTP;
			String errorCode = UpcConstants.FAILURE_SYS;
			String errorMsg = "系统异常";
			if (e instanceof SocketTimeoutException) {
				exceptionType = ExceptionType.HTTP;
				errorCode = UpcConstants.SOCKET_TIMEOUT;
				errorMsg = "超时异常";
			} else if (e instanceof ConnectTimeoutException) {
				exceptionType = ExceptionType.CONNECTION_REFUSE;
				errorMsg = "连接拒绝";
			} else {
				exceptionType = ExceptionType.OTHER;
			}
			sendMq(businessType, reqUrl, reqMsg, exceptionType, e.getMessage());

			throw new ServiceException(errorCode, errorMsg);
		}
		logger.info("请求顺手付 type:{} 响应参数:resp:{}", businessType.name(), sfPayOrderResult);

		if (StringUtils.isBlank(sfPayOrderResult)) {
			throw new ServiceException(UpcConstants.FAILURE_SYS, "系统异常");
		}

		// json 转对象
		Object resultObj = null;
		try {
			resultObj = JSONUtils.formJSONStr(sfPayOrderResult, clazz);
		} catch (Exception e) {
			logger.error("请求渠道返回数据转json异常", e);
		}

		if (resultObj == null) {
			throw new ServiceException(UpcConstants.FAILURE_SYS, "系统异常");
		}
		return resultObj;
	}

	private void sendMq(ExceptionBusiType businessType, String reqUrl, String reqMsg, ExceptionType exceptionType, String exceptionMsg) {

		Map<String, String> mqMap = new HashMap<String, String>();
		mqMap.put("businessCategory", businessType.getCategory());
		mqMap.put("exceptionBusiness", businessType.name());
		mqMap.put("exceptionDetailMsg", exceptionMsg);
		mqMap.put("exceptionType", exceptionType.name());
		mqMap.put("reqMessage", reqMsg);
		mqMap.put("reqUrl", reqUrl);
		mqMap.put("handleType", "SYSTEM");
		mqMap.put("sysSource", "UPC");

		mqService.sendExceptionMq(mqMap);
		logger.info("发送异常mq消息成功");
	}

	public HandleChannelBaseResp handleRepeatPay(UpcPayInfo existPayInfo, ChannelArgs channelArgs) throws UPCServiceException {
		return null;
	}

	protected String packOrderSfpayReqMsg(String sceneCode, UpcPayInfo payInfo) {
		OrderSFPayReqVo orderReq = new OrderSFPayReqVo();
		setProtocal(orderReq, "SFP_B2C_CREATE_ORDER");

		orderReq.setMerchantId(payInfo.getMchNo());
		orderReq.setOrderId(payInfo.getPayNo());
		orderReq.setAmt(payInfo.getTradeAmt());
		orderReq.setCcy("RMB");
		orderReq.setNotifyUrl(payInfo.getMchNotifyUrl());
		orderReq.setMemberNo(String.valueOf(payInfo.getMemberNo()));

		orderReq.setTradeScene(sceneCode);
		orderReq.setMerBusinessType(payInfo.getChannelCode());
		orderReq.setGoodsName(payInfo.getProductName());
		// 生成签名
		String sign = packSign(orderReq, orderReq.getRequestTime(), "merchantId", "orderId", "amt", "ccy", "notifyUrl");
		orderReq.setSign(sign);

		// 生成请求字符串
		String reqformData = packSfpayFormData(orderReq, "serviceName", "serviceVersion", "charset", "signType", "requestTime", "amt", "merchantId",
				"notifyUrl", "orderId", "tradeScene", "ccy", "memberNo", "goodsName", "merBusinessType", "sign");

		return reqformData;
	}

	protected String packCloseOrderReqMsg(UpcPayInfo payInfo) {
		CloseSFPayOrderReqVo closeOrderReq = new CloseSFPayOrderReqVo();
		setProtocal(closeOrderReq, "ORDER_CANCEL");

		closeOrderReq.setMerchantId(payInfo.getMchNo());
		closeOrderReq.setOrderId(payInfo.getPayNo());

		// 生成签名
		String sign = packSign(closeOrderReq, closeOrderReq.getRequestTime(), "merchantId", "orderId");
		closeOrderReq.setSign(sign);

		// 生成请求字符串
		String reqformData = packSfpayFormData(closeOrderReq, "serviceName", "serviceVersion", "charset", "signType", "requestTime", "merchantId",
				"orderId", "sign");

		return reqformData;
	}

	private String buildSignQueryMsg(UpcPayInfo payInfo) {
		SFPaySignQueryReqVo req = new SFPaySignQueryReqVo();
		setProtocal(req, "SIGN_QUERY");

		req.setMerchantId(payInfo.getMchNo());
		req.setOrderId(payInfo.getPayNo());
		req.setAmt(payInfo.getTradeAmt());
		String sign = packSign(req, req.getRequestTime(), "merchantId", "orderId", "amt");
		req.setSign(sign);

		// 生成请求字符串
		String reqformData = packSfpayFormData(req, "serviceName", "serviceVersion", "charset", "signType", "requestTime", "amt", "merchantId",
				"orderId", "sign");

		return reqformData;
	}

	protected String buildOperatorBalanceMsg(UpcPayInfo payInfo, String serviceName, String contractNo) {
		OperatorSFPayBalanceReqVo req = new OperatorSFPayBalanceReqVo();
		setProtocal(req, serviceName);

		req.setMerchantId(payInfo.getMchNo());
		req.setContractNo(contractNo);
		String sign = packSign(req, req.getRequestTime(), "merchantId", "contractNo");
		req.setSign(sign);

		// 生成请求字符串
		String reqformData = packSfpayFormData(req, "serviceName", "serviceVersion", "charset", "signType", "requestTime", "merchantId",
				"contractNo", "sign");

		return reqformData;
	}

	private String packOrderQueryReqMsg(String merchantId, String upcPayNo) {
		SFPaySignQueryReqVo req = new SFPaySignQueryReqVo();
		setProtocal(req, "ORDER_QUERY");

		req.setMerchantId(merchantId);
		req.setOrderId(upcPayNo);
		String sign = packSign(req, req.getRequestTime(), "merchantId", "orderId");
		req.setSign(sign);

		// 生成请求字符串
		String reqformData = packSfpayFormData(req, "serviceName", "serviceVersion", "charset", "signType", "requestTime", "merchantId", "orderId",
				"sign");

		return reqformData;
	}

	protected void setProtocal(SfPayBaseProtocal req, String serviceName) {
		req.setServiceName(serviceName);
		req.setServiceVersion("V1.0.0");
		req.setCharset("UTF-8");
		req.setSignType("MD5");
		req.setRequestTime(DateUtils.formatDate(new Date(), "yyyyMMddhhmmssSSS"));
	}

	/**
	 * 组装支付流水
	 * 
	 * @param payReq
	 * @param channelArgs
	 * @return
	 */
	protected UpcPayInfo buildUpcPayInfo(SfPayCreateOrderReq payReq) {
		UpcPayInfo payInfo = new UpcPayInfo();
		payInfo.setPayNo(upcPayInfoDao.getPayNo());
		payInfo.setChannelCategoryCode(ChannelType.SFPAY.name());
		payInfo.setChannelCode(payReq.getChannelCode());
		payInfo.setMchNo(payReq.getMchNo());
		payInfo.setChannelMchNo(payReq.getMchNo());
		payInfo.setMchOrderNo(payReq.getMchOrderNo());
		payInfo.setUseMchnoReq("N");
		payInfo.setReqOrderNo(payInfo.getPayNo());
		payInfo.setTradeType(TradeType.PAY.name());
		payInfo.setTradeFee(0L);
		payInfo.setTradeAmt(payReq.getTradeAmount());
		payInfo.setSystemSource(payReq.getSystemSource());
		payInfo.setCcy(CurrencyType.RMB.name());
		if (ChannelTradeType.SFPAY_APP.name().equals(payReq.getChannelCode())) {
			payInfo.setStatus(TradeStatus.TRADING.name());
		} else {
			payInfo.setStatus(TradeStatus.INIT.name());
		}
		payInfo.setProductName(payReq.getProductName());
		payInfo.setProductDesc(payReq.getProductDesc());
		payInfo.setCallbackSfUrl(payReq.getCallbackUrl());
		payInfo.setRemark(payReq.getRemark());
		payInfo.setMemberNo(payReq.getMemberNo());
		payInfo.setUppOrderNo(payReq.getUppOrderNo());

		// 设置通知地址
		String notifyUrl = String.format("%s/upc/{0}/notify", Property.getProperty("OUT_SYF_UPC_URI"));
		payInfo.setMchNotifyUrl(new MessageFormat(notifyUrl).format(new Object[] { payInfo.getPayNo() }));

		return payInfo;
	}

	private String getMD5(String data, String key) {
		String md5Str = "";
		try {
			if (StringUtils.isEmpty(key)) {
				md5Str = MD5Util.md5Hex(data);
			} else {
				md5Str = MD5Util.md5Hex(data, key);
			}
		} catch (Exception e) {
			logger.error(String.format("MD5加密失败，加密数据：[%s]，秘钥：[%s]", data, key), e);
		}
		return md5Str;
	}

	/**
	 * 组装&格式数据
	 * 
	 * @param oldSign
	 * @param obj
	 * @param requestTime
	 * @param fieldNames
	 * @return
	 */
	public String packSfpayFormData(Object obj, String... fieldNames) {
		if (fieldNames == null || fieldNames.length == 0) {
			return null;
		}

		StringBuffer sb = new StringBuffer();// 存放签名参数
		Object val = null;
		for (String field : fieldNames) {
			try {
				val = ReflectUtils.getValueByFieldName(obj, field);
			} catch (Exception e) {
				e.printStackTrace();
			}
			if (val != null) {
				sb.append(field + "=" + val).append("&");
			}
		}
		sb.setLength(sb.length() - 1);
		return sb.toString();
	}

	/**
	 * 组装签名数据
	 * 
	 * @param oldSign
	 * @param obj
	 * @param requestTime
	 * @param fieldNames
	 * @return
	 */
	public String packSign(Object obj, String requestTime, String... fieldNames) {
		if (fieldNames == null || fieldNames.length == 0) {
			return null;
		}

		StringBuffer sb = new StringBuffer();// 存放签名参数
		Object val = null;
		for (String field : fieldNames) {
			try {
				val = ReflectUtils.getValueByFieldName(obj, field);
			} catch (Exception e) {
				e.printStackTrace();
			}
			sb.append(field + "=" + val).append("&");
		}
		// 获取签名秘钥
		String key = getMD5(requestTime, null);
		// sb.setLength(sb.length() - 1);
		logger.info(String.format("签名原字符串：%s", sb.toString()));
		String newSign = getMD5(sb.toString(), key);
		return newSign;
	}

	/**
	 * 验证签名
	 * 
	 * @param oldSign
	 * @param obj
	 * @param requestTime
	 * @param fieldNames
	 * @return
	 */
	public void validateSign(String oldSign, Object obj, String responseTime, String... fieldNames) {

		StringBuffer sb = new StringBuffer();// 存放签名参数
		Object val = null;
		for (String field : fieldNames) {
			try {
				val = ReflectUtils.getValueByFieldName(obj, field);
			} catch (Exception e) {
				e.printStackTrace();
			}
			sb.append(field + "=" + val).append("&");
		}
		// 获取签名秘钥
		String key = getMD5(responseTime, null);
		// sb.setLength(sb.length() - 1);
		logger.info(String.format("签名原字符串：%s", sb.toString()));
		String newSign = getMD5(sb.toString(), key);
		logger.info(String.format("签名秘钥：[*********]，原来签名：[%s]，新签名：[%s]", oldSign, newSign));
		boolean isValidSign = newSign.equals(oldSign) ? true : false;
		if (!isValidSign) {
			throw new ServiceException(UpcConstants.INVALID_SIGN, "签名不正确");
		}
	}

	protected void updateUpcOrderStatus(String payNo, TradeStatus originalStatus, TradeStatus targetStatus) throws UPCServiceException {
		updateUpcOrderStatus(payNo, originalStatus, targetStatus, null);
	}

	protected void updateUpcOrderStatus(String payNo, TradeStatus originalStatus, TradeStatus targetStatus, String remark) throws UPCServiceException {
		UpdateUpcPayStatusParam upcParam = new UpdateUpcPayStatusParam();
		upcParam.setPayNo(payNo);
		upcParam.setOriginalStatus(originalStatus.name());
		upcParam.setTargetStatus(targetStatus.name());
		upcParam.setRemark(remark);
		payManageInfoService.updatePayInfoStatus(upcParam);
	}

	/**
	 * 发送mq
	 * 
	 * @param payInfo
	 * @param upcTradeStatus
	 * @param errorCode
	 * @param errorMsg
	 */
	protected void sendMqAndRecordToUpp(UpcPayInfo payInfo, TradeStatus upcTradeStatus, String errorCode, String errorMsg) {
		Map<String, String> mapMsg = new HashMap<String, String>();
		mapMsg.put("tradeType", "PAY".equals(payInfo.getTradeType()) ? "PAYMENT" : "REFUND");
		mapMsg.put("channelCode", payInfo.getChannelCode());
		mapMsg.put("mchNo", payInfo.getMchNo());
		mapMsg.put("uppChannelTradeNo", payInfo.getUppOrderNo());
		mapMsg.put("mchOrderNo", payInfo.getMchOrderNo());
		mapMsg.put("rtnOrderNo", payInfo.getRtnOrderNo());
		mapMsg.put("tradeAmt", String.valueOf(payInfo.getTradeAmt()));
		mapMsg.put("tradeFee", String.valueOf(payInfo.getTradeFee() == null ? 0L : payInfo.getTradeFee()));
		mapMsg.put("ccy", payInfo.getCcy());
		mapMsg.put("status", upcTradeStatus.name());
		mapMsg.put("beginTime", DateUtil.format(payInfo.getBeginTime() == null ? new Date() : payInfo.getBeginTime(), DateUtil.YYYY_MM_DD_HH_MM_SS));
		mapMsg.put("endTime", DateUtil.format(new Date(), DateUtil.YYYY_MM_DD_HH_MM_SS));
		mapMsg.put("errorCode", errorCode);
		mapMsg.put("errorMsg", errorMsg);
		logger.info("sys-upc 通知聚合支付mq消息 :[{}]", mapMsg.toString());
		try {
			mqService.sendMsg(true, mapMsg);
			payManageInfoService.updateNotifyFlag(payInfo.getPayNo(), "Y");
		} catch (UPCServiceException e) {
			logger.error("sys-upc 记录通知结果异常", e);
		}
	}
}
