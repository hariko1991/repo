package com.sfpay.pay.service.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.sfpay.pay.dao.UpcPayLogDao;
import com.sfpay.pay.domain.UpcPayLog;

/**
 * 
 * @Description: 统一支付日志服务类
 * @date 2016-04-21 18:37:51
 * @version V1.0
 * @author 896728
 */
@Service
public class UpcPayLogService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private UpcPayLogDao upcPayLogDao;
	
	/**
	 * 异步记录日志
	 */
	@Async
	public void recordLog(UpcPayLog payLog) {
		
		/**try {
			upcPayLogDao.createLog(payLog);
		} catch (Exception e) {
			logger.error("保存日志信息异常", e);
		}
		*/
	}
	
}
