package com.sfpay.pay.service.hessian;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.pay.service.impl.UpcPayInfoManageService;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.upc.QueryUpcPayParam;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.upc.UpcPayUnknownParam;
import com.sfpay.upc.exception.UPCServiceException;
import com.sfpay.upc.service.IUpcPayInfoService;

/**
 * 
 * 类说明：<br>
 * 统一支付流水服务
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-18
 */
@Service
@HessianExporter("/upc/payInfoService")
public class UpcPayInfoServiceImpl implements IUpcPayInfoService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private UpcPayInfoManageService payManageInfoService;

	@Override
	public UpcPayInfo queryPayInfo(QueryUpcPayParam payParam) throws UPCServiceException {
		if (payParam.getId() == null && StringUtils.isBlank(payParam.getPayNo())
				&& StringUtils.isBlank(payParam.getMchOrderNo()) && StringUtils.isBlank(payParam.getReqOrderNo())
				&& StringUtils.isBlank(payParam.getRtnOrderNo())) {
			logger.error("关键数据不能同时为空 :{}", payParam.toString());
			throw new ServiceException(UpcConstants.PARAM_NULL);
		}
		try {
			return payManageInfoService.queryPayInfo(payParam);
		} catch (Exception e) {
			logger.error("查询统一支付流水异常 请求信息：[{}],{}", payParam.toString(), e);
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}
	}

	@Override
	public void updateUpcPayUnknown(UpcPayUnknownParam uppParam) throws UPCServiceException {
		if (StringUtils.isBlank(uppParam.getPayNo()) && StringUtils.isBlank(uppParam.getMchOrderNo())
				&& StringUtils.isBlank(uppParam.getRtnOrderNo())) {
			logger.error("关键数据不能同时为空 :{}", uppParam.toString());
			throw new ServiceException(UpcConstants.PARAM_NULL);
		}

		if (StringUtils.isBlank(uppParam.getTargetStatus())) {
			logger.error("目标状态不能为空");
			throw new ServiceException(UpcConstants.PARAM_NULL, "目标状态不能为空");
		}
		try {
			payManageInfoService.updateUpcPayUnknown(uppParam);
		} catch (Exception e) {
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}
	}

	@Override
	public void updateNotifyFlag(String payNo, String notifyType) throws UPCServiceException {
		payManageInfoService.updateNotifyFlag(payNo, notifyType);
	}

	/**
	 * upc创建订单
	 * 
	 * @param upcPayInfo
	 * @throws UPCServiceException
	 */
	public void createPayInfo(UpcPayInfo upcPayInfo) throws UPCServiceException {
		payManageInfoService.createPayInfo(upcPayInfo);
	}

	
}
