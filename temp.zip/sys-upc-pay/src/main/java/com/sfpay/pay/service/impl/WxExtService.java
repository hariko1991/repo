package com.sfpay.pay.service.impl;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.pay.dao.WxExtDao;
import com.sfpay.pay.domain.UpcWxExt;

/**
 * 
 * @Description: 微信业务数据服务类
 * @date 2016-04-22 12:50:35
 * @version V1.0	
 * @author 896728
 */
@Service
public class WxExtService  {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private WxExtDao wxExtDao;

	public void saveWxExtData(UpcWxExt wxExt) throws ServiceException {
		try {
			wxExtDao.saveUpcWxExt(wxExt);
		} catch (Exception e) {
			logger.error("保存微信拓展数据异常 保存数据：{} 异常:{}", wxExt.toString(), e);
		}
	}

	public UpcWxExt queryWxExt(String payNo) {
		return wxExtDao.queryWxExt(payNo);
	}
	
	@Async
	public void updateOpenidToWxExt(String payNo, String openid) {
		try {
			wxExtDao.updateOpenidToWxExt(payNo, openid);
		} catch (Exception e) {
			logger.error("更新微信openid到拓展数据异常 payNo：{} ", payNo, e);
		}
	}

}
