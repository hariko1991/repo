package com.sfpay.pay.dao;

import com.sfpay.pay.domain.UpcPayLog;

public interface UpcPayLogDao {

	/**
	 * 生成日志
	 * 
	 * @param payLog
	 */
	void createLog(UpcPayLog payLog);

}
