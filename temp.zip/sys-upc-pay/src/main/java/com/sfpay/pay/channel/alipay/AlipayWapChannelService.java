package com.sfpay.pay.channel.alipay;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang.StringUtils;
import org.springframework.stereotype.Service;

import com.sfpay.alipay.function.AlipayBase;
import com.sfpay.alipay.function.AlipaySignFunc;
import com.sfpay.alipay.util.AlipayUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.common.json.JSONUtils;
import com.sfpay.pay.channel.IAlipayChannelService;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.alipay.AlipayCreateOrderReq;
import com.sfpay.upc.domain.alipay.AlipayCreateOrderResp;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.UpcPayInfo;

/**
 * 
 * 类说明：<br>
 * 创建支付宝WAP支付
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-22
 */
@Service
public class AlipayWapChannelService extends AlipayBaseChannelService implements IAlipayChannelService {

	// 校验基本参数
	protected void validAlipayReqArgs(AlipayCreateOrderReq payReq) {
		if (StringUtils.isEmpty(payReq.getMchOrderNo())) {// 商户订单号
			throw new ServiceException(UpcConstants.MCH_REFUND_ORDER_NO_IS_NULL, "支付宝商户订单号不能为空");
		}
		if (StringUtils.isEmpty(payReq.getProductName())) { // 商品名称
			throw new ServiceException(UpcConstants.MCH_PRODUCT_NAME_IS_NULL, "支付宝商品名称不能为空");
		}
		if (StringUtils.isEmpty(payReq.getProductUrl())) {// 商品展示地址
			throw new ServiceException(UpcConstants.MCH_PRODUCT_URL_IS_NULL, "支付宝商品展示地址不能为空");
		}
	}

	// 组装返回结果

	protected AlipayCreateOrderResp buildAlipayCreateOrderResp(AlipayCreateOrderReq payReq, UpcPayInfo payInfo, ChannelArgs channelArgs) {
		AlipayCreateOrderResp alipayResp = new AlipayCreateOrderResp();
		alipayResp.setAlipayPayStr(assemblyParameters(payReq, payInfo, channelArgs));

		return alipayResp;
	}

	// 组装支付宝业务数据
	private String assemblyParameters(AlipayCreateOrderReq payReq, UpcPayInfo payInfo, ChannelArgs channelArgs) {

		// 把请求参数打包成数组
		Map<String, String> sParaTemp = new HashMap<String, String>();
		sParaTemp.put("service", "alipay.wap.create.direct.pay.by.user");
		String partner = channelArgs.getValueByKey("mch_id");
		sParaTemp.put("partner", partner);
		sParaTemp.put("seller_id", partner);
		sParaTemp.put("_input_charset", AlipayBase.input_charset);
		sParaTemp.put("payment_type", AlipayBase.payment_type);
		sParaTemp.put("notify_url", payInfo.getMchNotifyUrl());
		// sParaTemp.put("return_url",
		// Property.getProperty("CASHIER_RETURN_URL"));
		// wap支付修改为跳转至cashier做转发到商户地址
		sParaTemp.put("return_url", payReq.getCallbackUrl());
		sParaTemp.put("out_trade_no", payReq.getMchOrderNo());
		sParaTemp.put("subject", payReq.getProductName());
		sParaTemp.put("total_fee", AlipayUtil.changeF2Y(payInfo.getTradeAmt()));
		sParaTemp.put("show_url", payReq.getProductUrl());
		sParaTemp.put("body", payReq.getProductDesc());

		String privateKeyStr = AlipayBase.getPrivateKey(channelArgs);
		String result = JSONUtils.fromObject(AlipaySignFunc.buildRequestPara(sParaTemp, privateKeyStr));

		return result;

	}

}
