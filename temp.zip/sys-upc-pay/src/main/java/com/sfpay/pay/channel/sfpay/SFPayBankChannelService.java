package com.sfpay.pay.channel.sfpay;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.pay.channel.ISFPayChannelService;
import com.sfpay.pay.channel.enums.ExceptionBusiType;
import com.sfpay.pay.channel.enums.UpcSfPayStatusTransfer;
import com.sfpay.pay.channel.sfpay.vo.OperatorSFPayBalanceRespVo;
import com.sfpay.pay.channel.sfpay.vo.SFPaySignQueryRespVo;
import com.sfpay.pay.domain.HandleChannelBaseResp;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.sfpay.SfBankPayResp;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.exception.UPCServiceException;

/**
 * 
 * 类说明：<br>
 * 顺手付银行卡支付
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-22
 */
public class SFPayBankChannelService extends SFPayBaseChannelService implements ISFPayChannelService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	public SfBankPayResp sfPayBankPay(UpcPayInfo payInfo) throws UPCServiceException {
		// 查询顺手付签约数据
		SFPaySignQueryRespVo signQueryResp = querySfPaySignNo(payInfo);

		String operatorBankReqUrl = Property.getProperty("SFPAY_GATPRX_URL") + Property.getProperty("SFPAY_BANK_PAY");
		String operatorBalanceReqMsg = buildOperatorBalanceMsg(payInfo, "AUTH_BANK_PAY", signQueryResp.getContractNo());
		OperatorSFPayBalanceRespVo sfpayBankPayResp = null;
		try {
			// 银行卡支付
			sfpayBankPayResp = (OperatorSFPayBalanceRespVo) httpSfPay(ExceptionBusiType.BankPay, operatorBankReqUrl, operatorBalanceReqMsg,
					OperatorSFPayBalanceRespVo.class);
		} catch (ServiceException e) {
			// 超时处理
			if (UpcConstants.SOCKET_TIMEOUT.equals(e.getCode())) {
				HandleChannelBaseResp queryResult = orderQuery(payInfo);
				String upcStatus = handleSfPayBankPayResult(payInfo, queryResult.getChannelStatus(), queryResult.getRltCode(),
						queryResult.getRltMsg());
				// 组装返回数据
				return new SfBankPayResp(UpcConstants.SUCCESS, null, upcStatus);

			} else {
				throw new ServiceException(e.getCode(), e.getMsg());
			}
		}

		if (SFPAY_SUCCESS_REQ.equals(sfpayBankPayResp.getRltCode())) {
			// 验签
			validateSign(sfpayBankPayResp.getSign(), sfpayBankPayResp, sfpayBankPayResp.getResponseTime(), "status");

			String sfOrderStatus = handleSfPayBankPayResult(payInfo, sfpayBankPayResp.getStatus(), sfpayBankPayResp.getRltCode(),
					sfpayBankPayResp.getRltMsg());
			return new SfBankPayResp(UpcConstants.SUCCESS, null, sfOrderStatus);
		} else {
			recordErrorInfo(payInfo.getPayNo(), sfpayBankPayResp.getRltCode(), sfpayBankPayResp.getRltMsg());

			HandleChannelBaseResp queryResult = orderQuery(payInfo);
			String upcStatus = handleSfPayBankPayResult(payInfo, queryResult.getChannelStatus(), queryResult.getRltCode(), queryResult.getRltMsg());
			// 组装返回数据
			return new SfBankPayResp(UpcConstants.SUCCESS, null, upcStatus);
		}

	}

	private String handleSfPayBankPayResult(UpcPayInfo payInfo, String channelStatus, String rltCode, String rltMsg) throws UPCServiceException {
		String upcStatus = UpcSfPayStatusTransfer.valueOf(channelStatus).getTargetStatus();
		if (TradeStatus.SUCCESS.name().equals(upcStatus)) {

			updateUpcOrderStatus(payInfo.getPayNo(), TradeStatus.TRADING, TradeStatus.SUCCESS);
			sendMqAndRecordToUpp(payInfo, TradeStatus.SUCCESS, null, null);

		} else if (TradeStatus.FAILURE.name().equals(upcStatus)) {

			recordErrorInfo(payInfo.getPayNo(), rltCode, rltMsg);
			updateUpcOrderStatus(payInfo.getPayNo(), TradeStatus.TRADING, TradeStatus.FAILURE);
			sendMqAndRecordToUpp(payInfo, TradeStatus.FAILURE, rltCode, rltMsg);

		} else if (TradeStatus.TRADING.name().equals(upcStatus)) {
			// 不处理
		} else if (TradeStatus.INIT.name().equals(upcStatus)) {
			// 不处理
		} else {
			throw new ServiceException(UpcConstants.FAILURE_SYS, rltMsg);
		}
		return upcStatus;
	}
}
