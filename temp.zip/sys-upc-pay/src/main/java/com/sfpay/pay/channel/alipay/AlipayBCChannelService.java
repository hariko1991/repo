package com.sfpay.pay.channel.alipay;

import org.springframework.stereotype.Service;

import com.sfpay.pay.channel.IAlipayChannelService;

/**
 * 
 * 类说明：<br>
 * 创建支付宝扫码付订单
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-22
 */
@Service
public class AlipayBCChannelService extends AlipayBaseChannelService implements IAlipayChannelService {

}
