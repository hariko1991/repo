/**
 * =================================================================
 * 版权所有 2011-2020 顺丰恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.pay.channel.sfpay.vo;


public class SfPayBaseProtocal extends SfPayBaseVo {
	private static final long serialVersionUID = -3415849753444769171L;
	/**
	 * 服务名称
	 */
	private String serviceName;

	/**
	 * 版本号
	 */
	private String serviceVersion;

	/**
	 * 编码，一般是UTF-8
	 */
	private String charset;

	/**
	 * 签名类型，MD5或者RSA
	 */
	private String signType;

	/**
	 * 签名结果
	 */
	private String sign;

	/**
	 * 请求时间戳
	 */
	private String requestTime;

	public String getServiceName() {
		return serviceName;
	}

	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}

	public String getServiceVersion() {
		return serviceVersion;
	}

	public void setServiceVersion(String serviceVersion) {
		this.serviceVersion = serviceVersion;
	}

	public String getCharset() {
		return charset;
	}

	public void setCharset(String charset) {
		this.charset = charset;
	}

	public String getSignType() {
		return signType;
	}

	public void setSignType(String signType) {
		this.signType = signType;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getRequestTime() {
		return requestTime;
	}

	public void setRequestTime(String requestTime) {
		this.requestTime = requestTime;
	}

}
