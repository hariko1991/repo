package com.sfpay.pay.task;

import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.pay.cache.UpcChannelContainer;

public class TimerToExecuteInitChannel {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	// 定时执行分钟数 默认120分钟
	private static long execPeriodTime = 120;
	private static final long initialDelay = 0;

	public final void execute() {
		logger.info("获取token定时任务启动...");
		try {
			ScheduledExecutorService ses = Executors.newScheduledThreadPool(1);
			ses.scheduleAtFixedRate(new UpcChannelContainer(), initialDelay, execPeriodTime, TimeUnit.MINUTES);
		} catch (Throwable t) {
			logger.error("获取token定时任务异常", t);
		}
	}

	public void setExecPeriodTime(String execPeriodTime) {

		if (StringUtils.isNotBlank(execPeriodTime)) {
			TimerToExecuteInitChannel.execPeriodTime = Integer.parseInt(execPeriodTime);
		}
	}

}
