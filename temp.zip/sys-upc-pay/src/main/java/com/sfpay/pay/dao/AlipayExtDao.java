package com.sfpay.pay.dao;

import org.apache.ibatis.annotations.Param;

import com.sfpay.pay.domain.UpcAlipayExt;
import com.sfpay.upc.domain.upc.UpcHandleAlipayParam;

/**
 * 
 * @Description: 支付宝扩展数据DAO
 * @date 2016-06-12 17:54:22
 * @version V1.0
 * @author 896728
 */
public interface AlipayExtDao {

	/**
	 * 更新对象
	 * 
	 * @param model
	 */
	void updateUpcAlipayExt(UpcHandleAlipayParam req);

	/**
	 * 保存对象
	 * 
	 * @param model
	 */
	void saveUpcAlipayExt(UpcAlipayExt upcAlipayExt);

	UpcAlipayExt getAlipayExtByPayNo(@Param("payNo") String payNo);

}
