package com.sfpay.pay.domain;

import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.UpcMerchantMap;

/**
 * 
 * 类说明：<br>
 * 微信请求上下文
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-5-9
 */
public class UpcRequestContext {
	private UpcMerchantMap mchMap;
	private ChannelArgs channelArgs;

	public UpcMerchantMap getMchMap() {
		return mchMap;
	}

	public void setMchMap(UpcMerchantMap mchMap) {
		this.mchMap = mchMap;
	}

	public ChannelArgs getChannelArgs() {
		return channelArgs;
	}

	public void setChannelArgs(ChannelArgs channelArgs) {
		this.channelArgs = channelArgs;
	}

}
