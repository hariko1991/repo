/**
 * =================================================================
 * 版权所有 2011-2014 深圳市泰海网络科技服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.pay.domain;

import com.sfpay.sypay.common.BaseEntity;

public class UpdateUpcPayInfoParam extends BaseEntity {
	private static final long serialVersionUID = 5834288523565999082L;
	/** 商户号非渠道商户号 */
	private String mchNo;
	/** 支付流水号 年月日+10位SEQ_PAY_NO */
	private String payNo;
	/** 商户订单编号 */
	private String mchOrderNo;
	/** 请求第三方订单号 */
	private String reqOrderNo;
	/** 第三方响应订单号 */
	private String rtnOrderNo;
	/** PAY:支付，PAY_REFUND:退款 */
	private String tradeType;
	/** 原状态: INIT未支付、PROCESSING交易进行中、SUCCESS成功、FAILURE失败、CLOSE:关闭 */
	private String originalStatus;
	/** 目标状态: INIT未支付、PROCESSING交易进行中、SUCCESS成功、FAILURE失败、CLOSE:关闭 */
	private String targetStatus;
	// 错误编码
	private String rtnCode;
	// 错误信息
	private String rtnMsg;
	//券编码
	private String voucherCode;
	
	//交易金额
	private Long tradeAmt;
	
	/**
	 * APPEND_BUS_TYPE  附加业务类型 RESUPPLY补单 REFUND退款 默认为 NORMAL 无附加业务类型
	 */
	private String  appendBusType = "NORMAL";
	
	/**
	 * 通知状态
	 */
	private String  notifyFlag;

	public String getMchNo() {
		return mchNo;
	}

	public void setMchNo(String mchNo) {
		this.mchNo = mchNo;
	}

	public String getPayNo() {
		return payNo;
	}

	public void setPayNo(String payNo) {
		this.payNo = payNo;
	}

	public String getMchOrderNo() {
		return mchOrderNo;
	}

	public void setMchOrderNo(String mchOrderNo) {
		this.mchOrderNo = mchOrderNo;
	}

	public String getReqOrderNo() {
		return reqOrderNo;
	}

	public void setReqOrderNo(String reqOrderNo) {
		this.reqOrderNo = reqOrderNo;
	}

	public String getRtnOrderNo() {
		return rtnOrderNo;
	}

	public void setRtnOrderNo(String rtnOrderNo) {
		this.rtnOrderNo = rtnOrderNo;
	}

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

	public String getOriginalStatus() {
		return originalStatus;
	}

	public void setOriginalStatus(String originalStatus) {
		this.originalStatus = originalStatus;
	}

	public String getTargetStatus() {
		return targetStatus;
	}

	public void setTargetStatus(String targetStatus) {
		this.targetStatus = targetStatus;
	}

	public String getRtnCode() {
		return rtnCode;
	}

	public void setRtnCode(String rtnCode) {
		this.rtnCode = rtnCode;
	}

	public String getRtnMsg() {
		return rtnMsg;
	}

	public void setRtnMsg(String rtnMsg) {
		this.rtnMsg = rtnMsg;
	}

	public String getVoucherCode() {
		return voucherCode;
	}

	public void setVoucherCode(String voucherCode) {
		this.voucherCode = voucherCode;
	}

	public Long getTradeAmt() {
		return tradeAmt;
	}

	public void setTradeAmt(Long tradeAmt) {
		this.tradeAmt = tradeAmt;
	}

	public String getAppendBusType() {
		return appendBusType;
	}

	public void setAppendBusType(String appendBusType) {
		this.appendBusType = appendBusType;
	}

	public String getNotifyFlag() {
		return notifyFlag;
	}

	public void setNotifyFlag(String notifyFlag) {
		this.notifyFlag = notifyFlag;
	}
}
