package com.sfpay.pay.domain;

public class HandleWxUnknownStatusResp extends HandleChannelBaseResp {
	private static final long serialVersionUID = 5834288523565999082L;

	// 返回银行编码信息
	private String bankType;
	// 微信订单号
	private String wxOrderNo;

	public String getBankType() {
		return bankType;
	}

	public void setBankType(String bankType) {
		this.bankType = bankType;
	}

	public String getWxOrderNo() {
		return wxOrderNo;
	}

	public void setWxOrderNo(String wxOrderNo) {
		this.wxOrderNo = wxOrderNo;
	}

}
