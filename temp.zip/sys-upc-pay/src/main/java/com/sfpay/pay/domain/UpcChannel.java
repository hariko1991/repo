package com.sfpay.pay.domain;

import java.util.Date;

import com.sfpay.sypay.common.BaseEntity;

/**
 * 
 * @Description: 统一支付渠道
 * @date 2016-04-27 17:20:05
 * @version V1.0
 * @author 896728
 */

public class UpcChannel extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** id */
	private Long id;
	/** 渠道编码 */
	private String channelCode;
	/** 渠道名称 */
	private String channelName;
	/** 创建时间 */
	private Date createDate;
	/** 更新时间 */
	private Date updateDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}
}
