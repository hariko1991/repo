package com.sfpay.pay.channel.wx;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.pay.channel.IWXChannelService;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.wx.WXCreateOrderReq;
import com.sfpay.wx.domain.CreateOrderReq;

/**
 * 微信扫码付 B2C
 * 
 * @author 896728
 * @date 2016年8月30日
 *
 */
public class WXQrcodeChannelService extends WxBaseChannelService implements IWXChannelService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Override
	protected CreateOrderReq buildCreateWxOrderReq(WXCreateOrderReq payReq, UpcPayInfo payInfo) {
		return buildCreateOrderReq(TRADE_TYPE_QR, payReq, payInfo);
	}

}
