package com.sfpay.pay.channel.wx;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.pay.channel.IWXChannelService;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.wx.WXCreateOrderReq;
import com.sfpay.wx.domain.CreateOrderReq;

/**
 * 
 * 类说明：<br>
 * 创建微信JSAPI订单
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-22
 */
public class WXJsApiProgramChannelService extends WxBaseChannelService implements IWXChannelService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Override
	protected void validWxReqArgs(WXCreateOrderReq payReq) {

		if (StringUtils.isEmpty(payReq.getOpenid())) {
			throw new ServiceException(UpcConstants.WX_OPEN_ID_IS_NULL, "微信openid不能为空");
		}

	}

	@Override
	protected CreateOrderReq buildCreateWxOrderReq(WXCreateOrderReq payReq, UpcPayInfo payInfo) {
		return buildCreateOrderReq(TRADE_TYPE_JSAPI_PROGRAM, payReq, payInfo);
	}

}
