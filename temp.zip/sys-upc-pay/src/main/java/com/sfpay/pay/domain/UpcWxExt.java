package com.sfpay.pay.domain;

import java.util.Date;

import com.sfpay.sypay.common.BaseEntity;

/**
 * 
 * @Description: 微信业务数据
 * @date 2016-05-04 09:27:30
 * @version V1.0
 * @author 896728
 */

public class UpcWxExt extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	/** ID SEQ_UPC_WX_EXT */
	private Long id;
	/** 支付流水号 */
	private String payNo;
	/** 商户订单号 */
	private String mchOrderNo;
	/** 请求微信流水号 */
	private String reqWxSn;
	/** 微信openId */
	private String openId;
	/** 微信预支付ID */
	private String prepayId;
	/** 备注 */
	private String remark;
	/** 创建日期 */
	private Date createDate;
	/** 更新日期 */
	private Date updateDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getPayNo() {
		return payNo;
	}

	public void setPayNo(String payNo) {
		this.payNo = payNo;
	}

	public String getMchOrderNo() {
		return mchOrderNo;
	}

	public void setMchOrderNo(String mchOrderNo) {
		this.mchOrderNo = mchOrderNo;
	}

	public String getReqWxSn() {
		return reqWxSn;
	}

	public void setReqWxSn(String reqWxSn) {
		this.reqWxSn = reqWxSn;
	}

	public String getOpenId() {
		return openId;
	}

	public void setOpenId(String openId) {
		this.openId = openId;
	}

	public String getPrepayId() {
		return prepayId;
	}

	public void setPrepayId(String prepayId) {
		this.prepayId = prepayId;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

}
