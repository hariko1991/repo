package com.sfpay.pay.task;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.framework2.core.util.DateUtil;
import com.sfpay.pay.channel.wx.WxBaseChannelService;
import com.sfpay.pay.domain.HandleWxUnknownStatusResp;
import com.sfpay.pay.domain.UpdateUpcPayInfoParam;
import com.sfpay.pay.service.impl.UpcPayInfoManageService;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.QueryUpcPayParam;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.upc.UpcPayUnknownParam;
import com.sfpay.upc.domain.upc.UpcRefundQueryReq;
import com.sfpay.upc.domain.wx.WxRefundDetail;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.exception.UPCServiceException;
import com.sfpay.upc.service.IChannelArgService;
import com.sfpay.upc.service.IMqService;
import com.sfpay.wx.domain.BaseResp;
import com.sfpay.wx.domain.CloseOrderResp;
import com.sfpay.wx.domain.RefundQueryReq;
import com.sfpay.wx.domain.RefundQueryResp;
import com.sfpay.wx.enums.WxErrorCodeType;
import com.sfpay.wx.function.WXCloseOrder;
import com.sfpay.wx.function.WXRefundQuery;

/**
 * 
 * 类说明：<br>
 * 查询交易未知调度
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-5-10
 */
@Service("WXQueryUnknownTask")
public class WXQueryUnknownTask extends BaseTask {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private UpcPayInfoManageService payInfoService;
	@Resource
	private IChannelArgService channelArgService;
	@Resource
	private IMqService mqService;
	@Resource
	private WxBaseChannelService wxBaseChannelService;

	/**
	 * 查询支付调度
	 */
	public final void doQueryPayTask() {
		try {
			logger.info("微信渠道 查询支付调度 [开始]");
			long startTime = System.currentTimeMillis();
			String handleType = "WX";
			Date curDate = new Date();
			String beginTime = this.getBeginTime(curDate , this.getDayNum(2)); 
			String endTime = DateUtil.formatDate(curDate, DateUtil.YYYY_MM_DD_HH_MM_SS); 
			int totalRows = payInfoService.queryTotalRows(handleType, TradeStatus.TRADING.name() , 
					beginTime ,endTime);
			logger.info("轮询微信支付结果 处理类型:{}, 共处理：{} 条", handleType, totalRows);
			if (totalRows == 0) {
				return;
			}
			int execItemsPerPage = getExecItemsPerPage();
			// 大于默认处理条数，分页处理
			if (totalRows > execItemsPerPage) {
				// 计算处理页数
				int page = totalRows / execItemsPerPage + 1;
				for (int count = 0; count < page; count++) {
					handleWXPayResult(handleType, execItemsPerPage , beginTime ,endTime);
				}
			} else {
				// 处理结果集
				handleWXPayResult(handleType, execItemsPerPage , beginTime ,endTime);
			}
			logger.info("微信渠道 查询支付调度 [结束] 共用时:{} 毫秒", System.currentTimeMillis() - startTime);
		} catch (Exception e) {
			logger.error("对[微信]未知状态支付记录进行轮询处理调度任务执行异常：\n", e);
		}
	}

	/**
	 * 查询退款调度
	 */
	public final void doQueryRefundTask() {
		try {
			logger.info("微信渠道 查询退款调度[开始]");
			long startTime = System.currentTimeMillis();
			String handleType = "WX";
			Date curDate = new Date();
			String beginTime = this.getBeginTime(curDate , this.getDayNum(5)); 
			String endTime = DateUtil.formatDate(curDate, DateUtil.YYYY_MM_DD_HH_MM_SS);
			int totalRows = payInfoService.queryTotalRows(handleType, TradeStatus.REFUND_ACCEPTED.name() , 
					beginTime , endTime);
			logger.info("轮询微信退款结果 处理类型:{}, 共处理：{} 条", handleType, totalRows);
			if (totalRows == 0) {
				return;
			}
			int execItemsPerPage = getExecItemsPerPage();
			// 大于默认处理条数，分页处理
			if (totalRows > execItemsPerPage) {
				// 计算处理页数
				int page = totalRows / execItemsPerPage + 1;
				for (int count = 0; count < page; count++) {
					handleWXRefundResult(handleType, execItemsPerPage ,beginTime , endTime);
				}
			} else {
				// 处理退款
				handleWXRefundResult(handleType, execItemsPerPage,beginTime , endTime);
			}
			logger.info("微信渠道 查询退款调度[结束] 共用时:{} 毫秒", System.currentTimeMillis() - startTime);
		} catch (Exception e) {
			logger.error("对[微信]未知状态银行支付记录进行轮询处理调度任务执行异常：\n", e);
		}
	}

	private void handleWXPayResult(String handleType, int execItemsPerPage , String beginTime , String endTime) throws UPCServiceException {

		// 查询list<主键>
		List<String> payNoList = payInfoService.queryPayNoList(handleType, TradeStatus.TRADING.name(), execItemsPerPage , 
				beginTime , endTime);

		List<UpcPayInfo> upcPayInfoList = payInfoService.queryPayUnknownRecords(payNoList);

		ChannelArgs channelArgs = null;
		for (UpcPayInfo payInfo : upcPayInfoList) {
			try {
				channelArgs = channelArgService.getChannelArgs(payInfo.getChannelCode(), payInfo.getMchNo());
				HandleWxUnknownStatusResp handleResult = wxBaseChannelService.handleTradeUnknown(payInfo, channelArgs);

				logger.info("处理交易位置响应数据:{}", handleResult.toString());

				if (TradeStatus.CLOSE.name().equals(handleResult.getTradeStatus())
						&& !WxErrorCodeType.ORDERNOTEXIST.name().equals(handleResult.getRltCode())) {
					try {
						execCloseOrder(channelArgs, payInfo);
					} catch (Exception e) {
						logger.error("微信关单失败", e);
					}
				}

				if (UPP_SYS_SOURCE.equals(payInfo.getSystemSource())
						&& (TradeStatus.SUCCESS.name().equals(handleResult.getTradeStatus()) || TradeStatus.FAILURE.name().equals(
								handleResult.getTradeStatus()))) {

					Map<String, String> mapMsg = new HashMap<String, String>();
					mapMsg.put("tradeType", "PAYMENT");
					mapMsg.put("channelCode", payInfo.getChannelCode());
					mapMsg.put("mchNo", payInfo.getMchNo());
					mapMsg.put("uppChannelTradeNo", payInfo.getUppOrderNo());
					mapMsg.put("mchOrderNo", payInfo.getMchOrderNo());
					mapMsg.put("rtnOrderNo", handleResult.getWxOrderNo());
					mapMsg.put("tradeAmt", String.valueOf(payInfo.getTradeAmt()));
					mapMsg.put("tradeFee", String.valueOf(payInfo.getTradeFee() == null ? 0L : payInfo.getTradeFee()));
					mapMsg.put("ccy", payInfo.getCcy());
					mapMsg.put("status", handleResult.getTradeStatus());
					mapMsg.put("payBankType", handleResult.getBankType());
					mapMsg.put("beginTime", DateUtil.format(payInfo.getBeginTime(), DateUtil.YYYY_MM_DD_HH_MM_SS));
					mapMsg.put("endTime", DateUtil.format(new Date(), DateUtil.YYYY_MM_DD_HH_MM_SS));
					if(TradeStatus.FAILURE.name().equals(handleResult.getTradeStatus())) {
						mapMsg.put("errorCode", handleResult.getRltCode());
						mapMsg.put("errorMsg", handleResult.getRltMsg());
					}

					boolean newVersion = false;
					if (StringUtils.isNotEmpty(payInfo.getUppOrderNo())) {
						newVersion = true;
					}
					logger.info("微信支付调度通知聚合支付版本:[{}], mq支付消息:[{}]", newVersion, mapMsg.toString());
					mqService.sendMsg(newVersion, mapMsg);

					// 更新通知状态
					payInfoService.updateNotifyFlag(payInfo.getPayNo(), "Y");
				}

			} catch (Exception e) {
				logger.error("后台调度查询微信查询接口处理支付流水异常 商户订单号:" + payInfo.getMchOrderNo() + ", payNo:" + payInfo.getPayNo(), e);
			}

		}
	}

	private void execCloseOrder(ChannelArgs channelArgs, UpcPayInfo payInfo) {
		CloseOrderResp closeOrderResp = WXCloseOrder.sendCloseOrderReq(payInfo.getReqOrderNo(),payInfo.getChannelCode(), channelArgs);
		if (BaseResp.SUCCESS.equals(closeOrderResp.getReturnCode()) && BaseResp.SUCCESS.equals(closeOrderResp.getResultCode())) {
			logger.info("执行关单成功 outOrderNo:[{}]", payInfo.getReqOrderNo());
		} else {
			logger.info("关单失败outOrderNo:[{}]", payInfo.getReqOrderNo());
		}
	}

	private void handleWXRefundResult(String handleType, int execItemsPerPage , String beginTime , String endTime) throws UPCServiceException {

		// 查询list<主键>
		List<String> payNoList = payInfoService.queryPayNoList(handleType, TradeStatus.REFUND_ACCEPTED.name(), execItemsPerPage , beginTime , endTime);

		List<UpcPayInfo> upcPayInfoList = payInfoService.queryPayUnknownRecords(payNoList);

		RefundQueryReq refundReq = null;
		ChannelArgs channelArgs = null;
		RefundQueryResp refundQueryResp = null;

		for (UpcPayInfo refundPayInfo : upcPayInfoList) {
			try {
				String tradeStatus = TradeStatus.REFUND_ACCEPTED.name();
				refundReq = new RefundQueryReq();
				refundReq.setOutRefundNo(refundPayInfo.getMchOrderNo());
				refundReq.setChannelNo(refundPayInfo.getChannelCode());
				channelArgs = channelArgService.getChannelArgs(refundPayInfo.getChannelCode(), refundPayInfo.getMchNo());
				refundQueryResp = WXRefundQuery.doWXRefundQuery(refundReq, channelArgs);
				logger.info("调度查询微信响应数据:{}", refundQueryResp.toString());
				if (BaseResp.SUCCESS.equals(refundQueryResp.getReturnCode()) && BaseResp.SUCCESS.equals(refundQueryResp.getResultCode())) {
					for (WxRefundDetail detail : refundQueryResp.getWxRefundDetailList()) {
						if (BaseResp.SUCCESS.equals(detail.getRefundStatus())) {
							tradeStatus = TradeStatus.REFUND_SUCC.name();
						} else if (BaseResp.FAIL.equals(detail.getRefundStatus())) {
							tradeStatus = TradeStatus.REFUND_FAIL.name();
						}
					}
				}

				// 查询原商户订单号
				QueryUpcPayParam payParam = new QueryUpcPayParam();
				payParam.setPayNo(refundPayInfo.getOldPayNo());
				UpcPayInfo formerPayInfo = payInfoService.queryPayInfo(payParam);
				if (formerPayInfo == null) {
					logger.error("订单不存在 : mchOrderNO:[{}]", refundPayInfo.getOldMchOrderNo());
					continue;
				}

				// 更新统一支付渠道状态
				UpcPayUnknownParam upcParam = new UpcPayUnknownParam();
				upcParam.setMchNo(refundPayInfo.getMchNo());
				upcParam.setPayNo(refundPayInfo.getPayNo());
				upcParam.setOriginalStatus(TradeStatus.REFUND_ACCEPTED.name());
				upcParam.setTargetStatus(tradeStatus);
				upcParam.setRtnBankCode(refundQueryResp.getErrCode());
				upcParam.setRtnBankMsg(refundQueryResp.getErrCodeDes());
				payInfoService.updateUpcPayUnknown(upcParam);
				// 处理全额退款
//				if (TradeStatus.REFUND_SUCC.name().equals(tradeStatus)) {
//					handleFullRefund(formerPayInfo, refundPayInfo);
//				}
				// 成功或失败通知第三方
				if (UPP_SYS_SOURCE.equals(refundPayInfo.getSystemSource())
						&& (TradeStatus.REFUND_SUCC.name().equals(tradeStatus) || TradeStatus.REFUND_FAIL.name().equals(tradeStatus))) {

					Map<String, String> mapMsg = new HashMap<String, String>();
					mapMsg.put("tradeType", "REFUND");
					mapMsg.put("channelCode", refundPayInfo.getChannelCode());
					mapMsg.put("mchNo", refundPayInfo.getMchNo());
					mapMsg.put("uppChannelTradeNo", refundPayInfo.getUppOrderNo());
					mapMsg.put("mchOrderNo", refundPayInfo.getMchOrderNo());
					mapMsg.put("rtnOrderNo", refundPayInfo.getRtnOrderNo());
					mapMsg.put("tradeAmt", String.valueOf(refundPayInfo.getTradeAmt()));
					mapMsg.put("tradeFee", String.valueOf(refundPayInfo.getTradeFee() == null ? 0L : refundPayInfo.getTradeFee()));
					mapMsg.put("ccy", refundPayInfo.getCcy());
					mapMsg.put("status", tradeStatus);
					mapMsg.put("payBankType", refundPayInfo.getPayBankType());
					mapMsg.put("beginTime", DateUtil.format(refundPayInfo.getBeginTime(), DateUtil.YYYY_MM_DD_HH_MM_SS));
					mapMsg.put("endTime", DateUtil.format(new Date(), DateUtil.YYYY_MM_DD_HH_MM_SS));
					mapMsg.put("errorCode", refundQueryResp.getErrCode());
					mapMsg.put("errorMsg", refundQueryResp.getErrCodeDes());

					boolean newVersion = false;
					if (StringUtils.isNotEmpty(refundPayInfo.getUppOrderNo())) {
						newVersion = true;
					}

					logger.info("微信退款调度通知聚合支付版本:[{}], mq支付消息:[{}]", newVersion, mapMsg.toString());
					mqService.sendMsg(newVersion, mapMsg);
					// 更新通知状态
					payInfoService.updateNotifyFlag(refundPayInfo.getPayNo(), "Y");
				}

			} catch (Exception e) {
				logger.error("后台调度查询微信查询接口处理支付流水异常 商户订单号:" + refundPayInfo.getMchOrderNo() + ", payNo:" + refundPayInfo.getPayNo(), e);
			}

		}
	}

	/**
	 * 处理全额退款
	 * 
	 * @param formerPayInfo
	 * @param refundPayInfo
	 * @throws UPCServiceException
	 */
	private void handleFullRefund(UpcPayInfo formerPayInfo, UpcPayInfo refundPayInfo) throws UPCServiceException {
		long totalPayAmount = formerPayInfo.getTradeAmt().longValue();
		long refundAmount = refundPayInfo.getTradeAmt().longValue();
		// 处理全额退款
		if (totalPayAmount == refundAmount) {
			updateOriginalOrderToRefundSucc(formerPayInfo);
			return;
		}

		// 查询已退款的流水记录
		UpcRefundQueryReq refundQueryReq = new UpcRefundQueryReq();
		refundQueryReq.setMchNo(refundPayInfo.getMchNo());
		refundQueryReq.setMchOrderNo(refundPayInfo.getOldMchOrderNo());

		List<UpcPayInfo> refundPayInfoList = payInfoService.queryRefundPayInfo(refundQueryReq);

		if (refundPayInfoList == null || refundPayInfoList.isEmpty()) {
			return;
		}

		long haveRefundAmount = 0; // 已退款金额
		for (UpcPayInfo p : refundPayInfoList) {
			haveRefundAmount += p.getTradeAmt().longValue();
		}
		// 处理全额退款
		if (haveRefundAmount == totalPayAmount) {
			updateOriginalOrderToRefundSucc(formerPayInfo);
		}
	}

	private void updateOriginalOrderToRefundSucc(UpcPayInfo formerPayInfo) throws UPCServiceException {
		UpdateUpcPayInfoParam updatePayReq = new UpdateUpcPayInfoParam();
		updatePayReq.setPayNo(formerPayInfo.getPayNo());
		updatePayReq.setRtnOrderNo(formerPayInfo.getRtnOrderNo());
		updatePayReq.setOriginalStatus(TradeStatus.SUCCESS.name());
		updatePayReq.setTargetStatus(TradeStatus.REFUND_SUCC.name());
		payInfoService.updatePayInfo(updatePayReq);

		logger.info("更新原订单为成功  商户号:[{}] 订单号:[{}]", formerPayInfo.getMchNo(), formerPayInfo.getMchOrderNo());
	}

}
