package com.sfpay.pay.channel.sfpay;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.pay.channel.ISFPayChannelService;

/**
 * 
 * 类说明：<br>
 * 创建支付宝APP支付订单
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-22
 */
public class SFPayChannelService extends SFPayBaseChannelService implements ISFPayChannelService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

}
