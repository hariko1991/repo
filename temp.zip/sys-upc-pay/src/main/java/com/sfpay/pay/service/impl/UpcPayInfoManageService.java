package com.sfpay.pay.service.impl;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataAccessException;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.pay.dao.UpcPayInfoDao;
import com.sfpay.pay.domain.UpdateUpcPayInfoParam;
import com.sfpay.sypay.common.util.DateUtil;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.upc.QueryUpcPayParam;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.upc.UpcPayUnknownParam;
import com.sfpay.upc.domain.upc.UpcRefundQueryReq;
import com.sfpay.upc.domain.upc.UpdateUpcPayStatusParam;
import com.sfpay.upc.exception.UPCServiceException;

/**
 * 
 * 类说明：<br>
 * 统一支付流水管理
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-18
 */
@Service
public class UpcPayInfoManageService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private UpcPayInfoDao upcPayInfoDao;

	public Map<String, UpcPayInfo> createBatchPayInfo(List<UpcPayInfo> uppPayInfoList) throws UPCServiceException {
		// 参数校验
		Map<String, UpcPayInfo> payNoMap = new HashMap<String, UpcPayInfo>();

		for (UpcPayInfo payInfo : uppPayInfoList) {
			createPayInfo(payInfo);
			payNoMap.put(payInfo.getCcy(), payInfo);
		}

		return payNoMap;

	}

	public void createPayInfo(UpcPayInfo upcPayInfo) throws UPCServiceException {
		try {
			upcPayInfoDao.createPayInfo(upcPayInfo);
		} catch (Exception e) {
			logger.error("异常", e);
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}

	}

	public UpcPayInfo queryPayInfo(QueryUpcPayParam payParam) throws UPCServiceException {
		try {
			return upcPayInfoDao.queryPayInfo(payParam);
		} catch (Exception e) {
			logger.error("查询统一支付流水异常 请求信息：[{}],{}", payParam.toString(), e);
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}
	}

	public List<UpcPayInfo> queryRefundPayInfo(UpcRefundQueryReq req) throws UPCServiceException {

		if (StringUtils.isBlank(req.getOldPayNo()) && StringUtils.isBlank(req.getMchOrderNo())
				&& StringUtils.isBlank(req.getMchRefundNo())) {
			logger.error("查询退款关键字段不能为空 :{}", req.toString());
			throw new ServiceException(UpcConstants.PARAM_NULL);
		}
		try {
			return upcPayInfoDao.queryRefundPayInfo(req);
		} catch (Exception e) {
			logger.error("查询统一支付流水异常 ", e);
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}
	}

	public void updatePayInfoStatus(UpdateUpcPayStatusParam upcParam) throws UPCServiceException {
		try {
			int rows = upcPayInfoDao.updateUppPayInfoStatus(upcParam);
			if (rows < 1) {
				throw new UPCServiceException(UpcConstants.FAILURE_SYS);
			}
		} catch (DataAccessException e) {
			logger.error("异常", e);
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}
	}

	public void updateUpcPayUnknown(UpcPayUnknownParam uppParam) throws UPCServiceException {
		try {
			int rows = upcPayInfoDao.updateUppPayUnknown(uppParam);
			if (rows < 1) {
				throw new UPCServiceException(UpcConstants.FAILURE_SYS);
			}
		} catch (DataAccessException e) {
			logger.error("异常", e);
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}
	}

	public void updatePayInfo(UpdateUpcPayInfoParam updatePayReq) throws UPCServiceException {
		try {
			int rows = upcPayInfoDao.updateUppPayInfo(updatePayReq);
			if (rows < 1) {
				throw new UPCServiceException(UpcConstants.FAILURE_SYS);
			}
		} catch (DataAccessException e) {
			logger.error("异常", e);
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}

	}

	public int getDBInterval(String tradeBeginTime) throws UPCServiceException {

		try {
			return upcPayInfoDao.getDBInterval(tradeBeginTime);
		} catch (Exception e) {
			logger.error("异常", e);
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}
	}

	public void updateNotifyFlag(String payNo, String notifyType) throws UPCServiceException {

		if (StringUtils.isEmpty(payNo) || StringUtils.isEmpty(notifyType)) {
			logger.error("更新通知标识, payNo 和notifyType不能为空");
			throw new ServiceException(UpcConstants.PARAM_NULL);
		}
		try {
			int rows = upcPayInfoDao.updateNotifyFlag(payNo, notifyType);
			if (rows < 1) {
				throw new UPCServiceException(UpcConstants.FAILURE_SYS);
			}
		} catch (DataAccessException e) {
			logger.error("异常", e);
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}

	}

	public String getPayNo() {
		return upcPayInfoDao.getPayNo();
	}

	public List<UpcPayInfo> queryNotifyFailToUppList(int handlePerPage) throws UPCServiceException {
		try {
			return upcPayInfoDao.queryNotifyFailToUppList(handlePerPage);
		} catch (Exception e) {
			logger.error("异常", e);
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}
	}

	@Async
	public void asyncRecordError(String payNo, String errorCode, String errorMsg) {
		String strDate = DateUtil.getDateStr(new Date(), "yyMMddHHmmss");
		StringBuilder sb = new StringBuilder();
		sb.append("T:").append(strDate).append("-").append(errorCode).append(":").append(errorMsg);
		try {
			upcPayInfoDao.recordError(payNo, sb.toString());
		} catch (Exception e) {
			logger.error(String.format("记录异常信息错误 errorMsg:%s", sb.toString()), e);
		}
	}

	/**
	 * 查询总个数
	 * @param handleType
	 * @param status
	 * @return
	 * @throws UPCServiceException 
	 */
	public int queryTotalRows(String handleType, String status ,String beginTime , String endTime) throws UPCServiceException {
		try {
			return upcPayInfoDao.queryTotalRows(handleType, status, beginTime, endTime);
		} catch (Exception e) {
			logger.error("异常", e);
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}
	}
	
	/**
	 * 查询payno列表
	 * @param handleType
	 * @param name
	 * @param defaultPerpageNumber
	 * @return
	 * @throws UPCServiceException 
	 */
	public List<String> queryPayNoList(String handleType, String status, int defaultPerpageNumber ,String beginTime , String endTime) throws UPCServiceException {
		try {
			return upcPayInfoDao.queryPayNoList(handleType, status, defaultPerpageNumber, beginTime, endTime);
		} catch (Exception e) {
			logger.error("异常", e);
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}
	}

	public List<UpcPayInfo> queryPayUnknownRecords(List<String> payNoList) throws UPCServiceException {
		try {
			return upcPayInfoDao.queryPayUnknownRecords(payNoList);
		} catch (Exception e) {
			logger.error("异常", e);
			throw new UPCServiceException(UpcConstants.FAILURE_DB);
		}
	}
}
