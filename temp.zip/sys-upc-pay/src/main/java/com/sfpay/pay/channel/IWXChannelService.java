package com.sfpay.pay.channel;

import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.wx.WXCreateOrderReq;
import com.sfpay.upc.domain.wx.WXCreateOrderResp;
import com.sfpay.upc.domain.wx.WXPayResp;
import com.sfpay.upc.exception.UPCServiceException;

/**
 * 
 * 类说明：<br>
 * 微信支付服务
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-18
 */
public interface IWXChannelService extends IBaseChannelService {

	/**
	 * 下单
	 * 
	 * @param req
	 * @param isOrderExpire
	 * @param existPayInfo
	 * @param channelArgs
	 * @return
	 * @throws UPCServiceException
	 */
	public WXCreateOrderResp createPayOrder(WXCreateOrderReq req, ChannelArgs channelArgs) throws UPCServiceException;

	/**
	 * 组装支付凭证
	 * 
	 * @param payInfo
	 * @param channelArgs
	 * @return
	 */
	public WXPayResp packagePayCertificate(UpcPayInfo payInfo, ChannelArgs channelArgs);

}
