/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.pay.channel.enums;

import com.sfpay.upc.constant.UpcConstants;

/**
 * 顺手付错误码
 * @author 896728
 * @date 2016年10月2日
 *
 */
public enum UpcSfPayErrorCode {

	sf_00(UpcConstants.SUCCESS),
	sf_990006(UpcConstants.FAILURE_SYS),
	sf_990019(UpcConstants.REPEAT_SUBMIT),
	sf_990020(UpcConstants.ORDER_IS_SUCCESS),
	sf_990021(UpcConstants.ORDER_IS_FAIL)
	;

	public static final String prefix = "sf_";
	
	private String upcErrorCode;

	private UpcSfPayErrorCode(String upcErrorCode) {
		this.upcErrorCode = upcErrorCode;
	}

	public String getUpcErrorCode() {
		return upcErrorCode;
	}

}
