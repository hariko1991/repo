/**
 * =================================================================
 * 版权所有 2011-2020 顺丰恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.pay.channel.sfpay.vo;

import com.sfpay.upc.domain.upc.UpcBaseResp;

public class SFPayRefundRespVo extends UpcBaseResp {
	private static final long serialVersionUID = -2047332193329585399L;
	
	/**
	 * 响应时间
	 */
	private String responseTime;

	/**
	 * 签名类型
	 */
	private String signType;

	/**
	 * 签名
	 */
	private String sign;

	/**
	 * 状态 SUCCESS:撤销成功 FAILURE：撤销失败
	 */
	private String status;
	/**
	 */
	private String refundBusinessNo;

	
	public SFPayRefundRespVo() {
	}
	
	public SFPayRefundRespVo(String rltCode, String rltMsg) {
		setRltCode(rltCode);
		setRltMsg(rltMsg);
	}
	
	
	public String getResponseTime() {
		return responseTime;
	}

	public void setResponseTime(String responseTime) {
		this.responseTime = responseTime;
	}

	public String getSignType() {
		return signType;
	}

	public void setSignType(String signType) {
		this.signType = signType;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRefundBusinessNo() {
		return refundBusinessNo;
	}

	public void setRefundBusinessNo(String refundBusinessNo) {
		this.refundBusinessNo = refundBusinessNo;
	}

}
