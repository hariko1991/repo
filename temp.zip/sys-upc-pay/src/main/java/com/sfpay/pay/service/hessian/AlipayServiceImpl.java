package com.sfpay.pay.service.hessian;

import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alipay.api.response.AlipaySystemOauthTokenResponse;
import com.alipay.api.response.AlipayTradeRefundResponse;
import com.sfpay.alipay.constant.AlipayConstants;
import com.sfpay.alipay.domain.AlipayTradeCloseResponse;
import com.sfpay.alipay.enums.AlipayErrorCode;
import com.sfpay.alipay.function.AlipayBase;
import com.sfpay.alipay.function.AlipayGetAccessToken;
import com.sfpay.alipay.function.AlipayGetCode;
import com.sfpay.alipay.function.AlipayNotify;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework2.core.util.JsonUtil;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.pay.channel.IAlipayChannelService;
import com.sfpay.pay.channel.alipay.AlipayBaseChannelService;
import com.sfpay.pay.domain.HandleRepeatPay;
import com.sfpay.pay.domain.UpcRequestContext;
import com.sfpay.pay.domain.UpdateUpcPayInfoParam;
import com.sfpay.pay.factory.PayChannelFactory;
import com.sfpay.pay.service.impl.AlipayExtService;
import com.sfpay.pay.service.impl.UpcPayInfoManageService;
import com.sfpay.pay.util.ConfigKeyUtils;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.alipay.AlipayCloseOrderReq;
import com.sfpay.upc.domain.alipay.AlipayCloseOrderResp;
import com.sfpay.upc.domain.alipay.AlipayCreateOrderReq;
import com.sfpay.upc.domain.alipay.AlipayCreateOrderResp;
import com.sfpay.upc.domain.alipay.AlipayGetAccessTokenResp;
import com.sfpay.upc.domain.alipay.AlipayOrderQueryReq;
import com.sfpay.upc.domain.alipay.AlipayOrderQueryResp;
import com.sfpay.upc.domain.alipay.AlipayRefundReq;
import com.sfpay.upc.domain.alipay.AlipayRefundResp;
import com.sfpay.upc.domain.alipay.UpcAlipayBuyerIdReq;
import com.sfpay.upc.domain.alipay.UpcAlipayBuyerIdResp;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.QueryUpcPayParam;
import com.sfpay.upc.domain.upc.UpcBaseReq;
import com.sfpay.upc.domain.upc.UpcHandleAlipayParam;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.upc.UpcPayUnknownParam;
import com.sfpay.upc.domain.upc.UpcRefundQueryReq;
import com.sfpay.upc.domain.upc.UpdateUpcPayStatusParam;
import com.sfpay.upc.enums.ChannelType;
import com.sfpay.upc.enums.CurrencyType;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.enums.TradeType;
import com.sfpay.upc.exception.UPCServiceException;
import com.sfpay.upc.service.IAlipayService;

/**
 * 
 * 类说明：<br>
 * 支付宝服务
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-18
 */
@Service
@HessianExporter("/upc/alipayService")
public class AlipayServiceImpl extends BasePayChannelService implements IAlipayService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	@Resource
	private AlipayBaseChannelService alipayBaseChannelService;
	@Resource
	private UpcPayInfoManageService payManageInfoService;
	@Resource
	private AlipayExtService alipayExtService;

	@Override
	public AlipayCreateOrderResp createPayOrder(AlipayCreateOrderReq req) {
		logger.info("支付宝下单请求参数:{}", req.toString());
		try {
			// 校验下单参数
			validCreateAlipayOrderReqArgs(req);

			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());
			// 非空校验
			IAlipayChannelService alipayChannelService = PayChannelFactory.getAlipayTradeChannel(req.getChannelCode());
			if (alipayChannelService == null) {
				throw new ServiceException(UpcConstants.INVALID_CHANNEL_CODE, "渠道编码不合法，渠道编码：" + req.getChannelCode());
			}
			// 查询本地流水状态
			UpcPayInfo existPayInfo = getUpcPayInfo(null, ChannelType.ALIPAY.name(), req.getMchNo(), req.getMchOrderNo());

			// 成功 失败 退款 不能重新下单
			if (existPayInfo != null) {
				// 处理重复支付
				HandleRepeatPay repeatPay = handleChannelRepeatPay(req.getChannelCode(), context, existPayInfo);
				return repeatPay.getAlipayCreateOrderResp();
			}
			// 执行下单
			AlipayCreateOrderResp createOrderResp = alipayChannelService.createPayOrder(req, context.getChannelArgs());
			logger.info("支付宝下单返回数据:[{}]", createOrderResp.toString());
			return createOrderResp;
		} catch (ServiceException e) {
			logger.error("支付宝下单异常 req:" + req.toString(), e);
			return new AlipayCreateOrderResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("支付宝下单异常req:" + req.toString(), e);
			return new AlipayCreateOrderResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public AlipayOrderQueryResp orderQuery(AlipayOrderQueryReq req) {
		logger.info("支付宝订单查询请求参数:{}", req.toString());
		// 验证参数
		if (StringUtils.isEmpty(req.getMchOrderNo())) {
			return new AlipayOrderQueryResp(UpcConstants.PARAM_NULL, "商户订单不能为空");
		}
		try {
			getRequestContext(req.getMchNo(), req.getChannelCode());
			// 查询流水状态
			UpcPayInfo payInfo = getUpcPayInfo(req.getChannelCode(), req.getMchNo(), req.getMchOrderNo());
			if (payInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}

			AlipayOrderQueryResp resp = buildOrderQueryResp(req, payInfo);
			logger.info("支付宝订单查询响应参数:{}", resp.toString());
			return resp;
		} catch (ServiceException e) {
			logger.error("订单查询异常req:" + req.toString(), e);
			return new AlipayOrderQueryResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("订单查询异常req:" + req.toString(), e);
			return new AlipayOrderQueryResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public AlipayCloseOrderResp closeOrder(AlipayCloseOrderReq req) {
		logger.info("支付宝关单请求参数:[{}]", req.toString());
		try {

			validCloseOrderReqParams(req);

			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());

			// 查询本地流水状态
			UpcPayInfo payInfo = getUpcPayInfo(req.getChannelCode(), req.getMchNo(), req.getMchOrderNo());
			if (payInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}

			validateCloseOrderStatus(payInfo);

			// 已经关闭提示关单成功
			if (TradeStatus.CLOSE.name().equals(payInfo.getStatus())) {
				return new AlipayCloseOrderResp(UpcConstants.SUCCESS, "关单成功");
			}

			AlipayTradeCloseResponse closeOrderResp = alipayBaseChannelService.closeOrder(req, context.getChannelArgs());
			logger.info("关单响应参数:[{}]", closeOrderResp.getBody());
			AlipayCloseOrderResp resultResp = new AlipayCloseOrderResp();

			// 关单成功
			if (closeOrderResp != null
					&& (AlipayConstants.SUCCESS.equals(closeOrderResp.getCode()) || orderNotExistsAndExpres(closeOrderResp.getSubCode(), payInfo))) {
				// 修改订单状态
				UpdateUpcPayStatusParam updateOrderStatusReq = new UpdateUpcPayStatusParam();
				updateOrderStatusReq.setPayNo(payInfo.getPayNo());
				updateOrderStatusReq.setMchNo(payInfo.getMchNo());
				updateOrderStatusReq.setOriginalStatus(TradeStatus.TRADING.name());
				updateOrderStatusReq.setTargetStatus(TradeStatus.CLOSE.name());

				payManageInfoService.updatePayInfoStatus(updateOrderStatusReq);
				logger.info("修改支付流水状态为关闭成功");
				resultResp.setRltCode(UpcConstants.SUCCESS);

			} else {
				if (AlipayErrorCode.TRADE_STATUS_ERROR.getCode().equals(closeOrderResp.getSubCode())) {
					// 关单失败
					resultResp.setRltCode(UpcConstants.ORDER_STATUS_ILLEGAL);
					resultResp.setRltMsg("只有等待买家付款状态可以关单");
				} else {
					resultResp.setRltCode(UpcConstants.FAILURE_SYS);
					resultResp.setRltMsg("系统异常");
				}
			}

			logger.info("支付宝关单响应参数:[{}]", resultResp.toString());

			return resultResp;

		} catch (ServiceException e) {
			logger.error("关闭订单异常req:" + req.toString(), e);
			return new AlipayCloseOrderResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("关闭订单异常req:" + req.toString(), e);
			return new AlipayCloseOrderResp(e.getCode(), e.getMsg());
		}
	}

	private boolean orderNotExistsAndExpres(String errorCode, UpcPayInfo existPayInfo) {
		try {

			if (AlipayErrorCode.TRADE_NOT_EXIST.getCode().equals(errorCode) && alipayBaseChannelService.isUpcPayInfoExpire(existPayInfo)) {
				return true;
			}
		} catch (UPCServiceException e) {
		}
		return false;
	}

	@Override
	public AlipayRefundResp refund(AlipayRefundReq req) {

		logger.info("支付宝退款请求参数:[{}]", req.toString());
		try {
			validAlipayRefundReqArgs(req);

			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());
			// 验证商户退款流水
			AlipayRefundResp wxRefundResp = validateMchRefundWater(req);
			if (wxRefundResp != null)
				return wxRefundResp;
			// 1.查询本地流水状态
			UpcPayInfo existsPayInfo = getUpcPayInfo(req.getChannelCode(), req.getMchNo(), req.getMchOrderNo());
			if (existsPayInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}

			// 只有支付成功的才可以退款
			if (!UpcConstants.SUCCESS.equals(existsPayInfo.getStatus())) {
				return new AlipayRefundResp(UpcConstants.ONLY_SUCC_ORDER_CAN_REFUND, "只有交易成功才可以退款");
			}

			if (req.getRefundFee().longValue() > existsPayInfo.getTradeAmt().longValue()) {
				return new AlipayRefundResp(UpcConstants.REFUND_AMOUNT_GT_TRADE_AMOUNT, "退款金额大于支付总金额");
			}

			// 2.查询已退款的流水记录
			UpcRefundQueryReq refundQueryReq = new UpcRefundQueryReq();
			refundQueryReq.setMchNo(req.getMchNo());
			refundQueryReq.setOldPayNo(existsPayInfo.getPayNo());
			List<UpcPayInfo> refundPayInfoList = payManageInfoService.queryRefundPayInfo(refundQueryReq);

			// 3. 校验已退款金额

			long haveRefundAmount = 0; // 已退款金额
			if (refundPayInfoList != null && !refundPayInfoList.isEmpty()) {

				long totalPayAmount = existsPayInfo.getTradeAmt().longValue();
				for (UpcPayInfo p : refundPayInfoList) {

					haveRefundAmount += p.getTradeAmt().longValue();
				}
				if (req.getRefundFee() + haveRefundAmount > totalPayAmount) {
					logger.error("已退款金额大于支付总金额 总金额:[{}], 已退款:[{}] ", totalPayAmount, haveRefundAmount);
					return new AlipayRefundResp(UpcConstants.REFUND_AMOUNT_GT_TRADE_AMOUNT, "已退款金额大于支付总金额");
				}
			}

			// 3. 生成退款流水
			UpcPayInfo refundPayInfo = buildRefundPayInfo(req, existsPayInfo, context);
			logger.info("开始生成支付流水...");
			payManageInfoService.createPayInfo(refundPayInfo);
			logger.info("结束生成支付流水:payNo:[{}]...", refundPayInfo.getPayNo());
			// 4. 调用支付宝退款

			AlipayTradeRefundResponse refundResp = alipayBaseChannelService.refund(existsPayInfo, refundPayInfo, context.getChannelArgs());
			logger.info("payNo:[{}]退款响应数据： :[{}]", refundPayInfo.getPayNo(), refundResp.getBody());
			// 5.退款处理
			UpdateUpcPayInfoParam updatePayReq = buildUpdateRefundData(refundPayInfo, refundResp);

			payManageInfoService.updatePayInfo(updatePayReq);

			AlipayRefundResp resultResp = new AlipayRefundResp();
			if (TradeStatus.REFUND_SUCC.name().equals(updatePayReq.getTargetStatus())) {
				resultResp.setRltCode(UpcConstants.SUCCESS);
				resultResp.setAlipayOrderNo(existsPayInfo.getRtnOrderNo());
				resultResp.setMchOrderNo(existsPayInfo.getMchOrderNo());
				resultResp.setMchRefundNo(refundPayInfo.getMchOrderNo());
				// 支付宝退款不会返回退款订单号 凡是支付宝退款一律返回upc的流水号(payNo)
				resultResp.setAlipayRefundId(refundPayInfo.getPayNo());
				resultResp.setTradeAmount(existsPayInfo.getTradeAmt());
				resultResp.setRefundFee(refundPayInfo.getTradeAmt());
				resultResp.setStatus(TradeStatus.REFUND_SUCC.name());
				
				sendMqAndRecordToUpp(refundPayInfo, TradeStatus.REFUND_SUCC, null, null);
			} else {
				// 转换支付宝错误码
				if (StringUtils.isNotBlank(refundResp.getSubCode())) {
					try {
						AlipayErrorCode result = AlipayErrorCode.valueOf(refundResp.getSubCode());
						resultResp.setRltCode(result.getUpcCode());
						resultResp.setRltMsg(result.getMsg());
						resultResp.setStatus(TradeStatus.REFUND_FAIL.name());

						// 发送mq
						sendMqAndRecordToUpp(refundPayInfo, TradeStatus.REFUND_FAIL, resultResp.getRltCode(), resultResp.getRltMsg());
					} catch (Exception e) {
						logger.error("不存在编码:[{}]", refundResp.getSubCode());
					}
				}

				if (StringUtils.isEmpty(resultResp.getRltCode())) {
					resultResp.setRltCode(UpcConstants.FAILURE_SYS);
					resultResp.setRltMsg("系统异常");
					resultResp.setStatus(TradeStatus.REFUND_FAIL.name());
				}
			}
			logger.info("退款响应结果:[{}]", resultResp.toString());
			return resultResp;

		} catch (ServiceException e) {
			logger.error("退款异常req:" + req.toString(), e);
			return new AlipayRefundResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("退款异常req:" + req.toString(), e);
			return new AlipayRefundResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public boolean verifyAlipayNotify(UpcBaseReq req, Map<String, String> params) {
		ChannelArgs channelArgs = getChannelArg(req.getChannelCode(), req.getMchNo());
		if (channelArgs == null) {

			throw new ServiceException(UpcConstants.INVALID_MCH_NO, "商户配置不存在， 请配置upc_channel_args表商户数据 商户号:" + req.getMchNo());
		}

		String channelMchNo = channelArgs.getValueByKey("mch_id");
		String alipayPubkey = AlipayBase.getAlipayPubKey(req.getChannelCode(), channelArgs);
		return AlipayNotify.verify(channelMchNo, alipayPubkey, params);
	}

	@Override
	public void handleAlipayNotify(UpcHandleAlipayParam reqParam) {
		UpcPayUnknownParam upcParam = new UpcPayUnknownParam();
		upcParam.setMchNo(reqParam.getMchNo());
		upcParam.setPayNo(reqParam.getPayNo());
		upcParam.setRtnOrderNo(reqParam.getRtnOrderNo());
		upcParam.setOriginalStatus(TradeStatus.TRADING.name());
		upcParam.setTargetStatus(reqParam.getTargetStatus());
		// 更新支付流水

		try {

			payManageInfoService.updateUpcPayUnknown(upcParam);
		} catch (UPCServiceException e) {
			logger.error("更新支付流水异常", e);

		}

		// 更新支付宝拓展数据
		alipayExtService.updateUpcAlipayExt(reqParam);

	}

	private AlipayRefundResp validateMchRefundWater(AlipayRefundReq req) throws UPCServiceException {
		QueryUpcPayParam payParam = new QueryUpcPayParam();
		payParam.setMchNo(req.getMchNo());
		payParam.setChannelCode(req.getChannelCode());
		payParam.setMchOrderNo(req.getMchRefundNo());
		UpcPayInfo payInfo = payManageInfoService.queryPayInfo(payParam);
		AlipayRefundResp refundResp = null;
		if (payInfo != null) {
			refundResp = new AlipayRefundResp();

			String errorCode = null;
			String errorMsg = null;
			if (TradeStatus.REFUND_ACCEPTED.name().equals(payInfo.getStatus())) {
				errorCode = UpcConstants.ORDER_IS_REFUND_PROC;
				errorMsg = "该订单退款已受理,无需再次退款";
			} else if (TradeStatus.REFUND_SUCC.name().equals(payInfo.getStatus())) {
				errorCode = UpcConstants.ORDER_IS_REFUND_SUCC;
				errorMsg = "该订单退款已成功";
			} else if (TradeStatus.REFUND_FAIL.name().equals(payInfo.getStatus())) {
				errorCode = UpcConstants.ORDER_IS_REFUND_FAIL;
				errorMsg = "该订单退款已失败";
			}
			refundResp.setRltCode(errorCode);
			refundResp.setRltMsg(errorMsg);
			refundResp.setStatus(payInfo.getStatus());
			refundResp.setAlipayRefundId(payInfo.getRtnOrderNo());
		}
		return refundResp;

	}

	private AlipayOrderQueryResp buildOrderQueryResp(AlipayOrderQueryReq req, UpcPayInfo payInfo) {
		AlipayOrderQueryResp resp = new AlipayOrderQueryResp();
		resp.setRltCode(UpcConstants.SUCCESS);
		resp.setChannelCode(req.getChannelCode());
		resp.setTradeStatus(payInfo.getStatus());
		resp.setTradeAmount(payInfo.getTradeAmt());
		resp.setMchOrderNo(payInfo.getMchOrderNo());
		resp.setTimeEnd(payInfo.getEndTime());
		resp.setRemark(payInfo.getRemark());
		return resp;
	}

	private UpcPayInfo buildRefundPayInfo(AlipayRefundReq req, UpcPayInfo formerPayInfo, UpcRequestContext context) {
		UpcPayInfo payInfo = new UpcPayInfo();
		payInfo.setChannelCode(req.getChannelCode());
		payInfo.setMchNo(req.getMchNo());
		payInfo.setPayNo(payManageInfoService.getPayNo());
		payInfo.setChannelMchNo(context.getMchMap().getChannelMchNo());
		payInfo.setMchOrderNo(req.getMchRefundNo());
		payInfo.setUseMchnoReq("Y");
		payInfo.setReqOrderNo(req.getMchRefundNo());
		payInfo.setTradeType(TradeType.PAY_REFUND.name());
		payInfo.setTradeFee(0L);
		payInfo.setTradeAmt(req.getRefundFee());
		payInfo.setSystemSource(formerPayInfo.getSystemSource());
		payInfo.setCcy(CurrencyType.RMB.name());
		payInfo.setStatus(TradeStatus.REFUND_PROC.name());
		payInfo.setMchNotifyUrl(formerPayInfo.getMchNotifyUrl());
		payInfo.setUppOrderNo(req.getUppRefundNo());
		payInfo.setOldUppOrderNo(formerPayInfo.getUppOrderNo());
		payInfo.setOldPayNo(formerPayInfo.getPayNo());
		payInfo.setOldMchOrderNo(formerPayInfo.getMchOrderNo());
		payInfo.setOldRtnOrderNo(formerPayInfo.getRtnOrderNo());
		return payInfo;
	}

	private void validCreateAlipayOrderReqArgs(AlipayCreateOrderReq payReq) {

		if (payReq == null) {
			throw new ServiceException(UpcConstants.PARAM_NULL);
		}

		if (StringUtils.isEmpty(payReq.getMchNo())) {
			throw new ServiceException(UpcConstants.MCH_NO_IS_NULL, "商户号为空");
		} else if (StringUtils.isEmpty(payReq.getChannelCode())) {
			throw new ServiceException(UpcConstants.CHANNEL_CODE_IS_NULL, "支付渠道编号为空");
		} else if (StringUtils.isEmpty(payReq.getMchOrderNo())) {
			throw new ServiceException(UpcConstants.MCH_ORDER_NO_IS_NULL, "商户订单号为空");
		} else if (StringUtils.isEmpty(payReq.getProductName())) {
			throw new ServiceException(UpcConstants.MCH_PRODUCT_NAME_IS_NULL, "商品名为空");

		} else if (payReq.getTradeAmount() == null || payReq.getTradeAmount().longValue() <= 0) {
			throw new ServiceException(UpcConstants.TRADE_AMOUNT_IS_NULL, "交易金额为空或不合法");
		} else if (StringUtils.isEmpty(payReq.getSystemSource())) {
			throw new ServiceException(UpcConstants.SYSTEM_SOURCE_IS_NULL, "系统来源为空");
		}
	}

	private void validAlipayRefundReqArgs(AlipayRefundReq req) {
		if (req == null) {
			throw new ServiceException(UpcConstants.PARAM_NULL);
		}

		if (StringUtils.isEmpty(req.getMchNo())) {
			throw new ServiceException(UpcConstants.MCH_NO_IS_NULL, "商户号为空");
		} else if (StringUtils.isEmpty(req.getChannelCode())) {
			throw new ServiceException(UpcConstants.CHANNEL_CODE_IS_NULL, "支付渠道编号为空");
		} else if (StringUtils.isEmpty(req.getMchRefundNo())) {
			throw new ServiceException(UpcConstants.MCH_REFUND_ORDER_NO_IS_NULL, "商户退款订单号为空");

		} else if (req.getRefundFee() == null || req.getRefundFee().longValue() <= 0) {
			throw new ServiceException(UpcConstants.INVALID_REFUND_AMOUNT, "退款金额无效");
		} else if (StringUtils.isEmpty(req.getMchOrderNo())) {
			throw new ServiceException(UpcConstants.MCH_ORDER_NO_IS_NULL, "商户订单号为空");
		}
	}

	private void validCloseOrderReqParams(AlipayCloseOrderReq req) {
		if (req == null) {
			throw new ServiceException(UpcConstants.PARAM_NULL);
		}

		if (StringUtils.isEmpty(req.getMchNo())) {
			throw new ServiceException(UpcConstants.MCH_NO_IS_NULL, "商户号为空");
		} else if (StringUtils.isEmpty(req.getMchOrderNo())) {
			throw new ServiceException(UpcConstants.MCH_ORDER_NO_IS_NULL, "商户订单号为空");
		}
	}

	private UpdateUpcPayInfoParam buildUpdateRefundData(UpcPayInfo refundPayInfo, AlipayTradeRefundResponse refundResp) {
		UpdateUpcPayInfoParam updatePayReq = new UpdateUpcPayInfoParam();
		updatePayReq.setPayNo(refundPayInfo.getPayNo());
		updatePayReq.setOriginalStatus(TradeStatus.REFUND_PROC.name());

		// 返回码成功且资金发生变化

		if (refundResp != null && AlipayConstants.SUCCESS.equals(refundResp.getCode()) && "Y".equals(refundResp.getFundChange())) {
			// 修改退款流水状态为退款成功
			updatePayReq.setTargetStatus(TradeStatus.REFUND_SUCC.name());

		} else if (refundResp == null || AlipayConstants.ERROR.equals(refundResp.getCode())) {
			// 未知
		} else {
			// 退款流水退款失败
			updatePayReq.setTargetStatus(TradeStatus.REFUND_FAIL.name());
		}
		
		//对于特殊的错误码直接转换成失败
		String subErrCode = refundResp.getSubCode();
		if (StringUtils.isNotBlank(subErrCode) && ConfigKeyUtils.alipayRefundFail(subErrCode)) {
			// 退款流水退款失败
			updatePayReq.setTargetStatus(TradeStatus.REFUND_FAIL.name());
		}

		updatePayReq.setRtnCode(refundResp.getSubCode());
		updatePayReq.setRtnMsg(refundResp.getSubMsg());

		return updatePayReq;
	}

	// 更新原订单状态为退款成功
	private void updateOriginalOrderToRefundSucc(UpcPayInfo existsPayInfo) throws UPCServiceException {
		UpdateUpcPayInfoParam updatePayReq = new UpdateUpcPayInfoParam();
		updatePayReq.setPayNo(existsPayInfo.getPayNo());
		updatePayReq.setRtnOrderNo(existsPayInfo.getRtnOrderNo());
		updatePayReq.setOriginalStatus(TradeStatus.SUCCESS.name());
		updatePayReq.setTargetStatus(TradeStatus.REFUND_SUCC.name());
		payManageInfoService.updatePayInfo(updatePayReq);

		logger.info("更新原订单为成功  商户号:[{}] 订单号:[{}]", existsPayInfo.getMchNo(), existsPayInfo.getMchOrderNo());
	}

	@Override
	public AlipayCreateOrderResp createBCOrder(AlipayCreateOrderReq req) {
		logger.info("支付宝下单请求参数:{}", req.toString());
		try {
			// 校验下单参数
			validCreateAlipayOrderReqArgs(req);

			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());
			// 非空校验
			IAlipayChannelService alipayChannelService = PayChannelFactory.getAlipayTradeChannel(req.getChannelCode());
			if (alipayChannelService == null) {
				throw new ServiceException(UpcConstants.INVALID_CHANNEL_CODE, "渠道编码不合法，渠道编码：" + req.getChannelCode());
			}

			// 查询本地流水状态
			QueryUpcPayParam payParam = new QueryUpcPayParam();
			payParam.setMchNo(req.getMchNo());
			payParam.setMchOrderNo(req.getMchOrderNo());
			UpcPayInfo existPayInfo = payManageInfoService.queryPayInfo(payParam);

			// 成功 失败 退款 不能重新下单
			if (existPayInfo != null) {
				validateExistPayInfoStatus(existPayInfo);
			}

			// 执行下单

			AlipayCreateOrderResp createOrderResp = alipayChannelService.createBCOrder(req, context.getChannelArgs());
			logger.info("支付宝下单返回数据:[{}]", createOrderResp.toString());
			return createOrderResp;

		} catch (ServiceException e) {
			logger.error("支付宝下单异常 req:" + req.toString(), e);
			return new AlipayCreateOrderResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("支付宝下单异常req:" + req.toString(), e);
			return new AlipayCreateOrderResp(e.getCode(), e.getMsg());
		}
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 获取ali用户信息授权信息地址
	 * @param thirdAppId 第三方应用ID，如果没有传，则用顺手付的APPID
	 * @param redirectUrl 授权完成回调地址
	 * @return
	 */
	@Override
	public String getAlipayOauthUrl(String redirectUrl)
	{
		String url = AlipayGetCode.getOAuthUrl(redirectUrl);
		return url;
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据ali授权码获取用户ID
	 * @param appId 应用ID，如果为空则使用顺手付自己的
	 * @param appSecret 应用秘钥，如果为空则使用顺手付自己的
	 * @param code 授权码
	 * @return
	 */
	public UpcAlipayBuyerIdResp getAlipayBuyerId(UpcAlipayBuyerIdReq req)
	{

		logger.info("method:getWXOpenId，请求参数：{}", req);
		UpcAlipayBuyerIdResp upcResp = new UpcAlipayBuyerIdResp();
		upcResp.setRltCode(UpcConstants.SUCCESS);
		
		AlipayGetAccessTokenResp resp = getOAuthAccessToken(req.getCode());
		
		if (resp == null || StringUtils.isBlank(resp.getUserId())) {
			upcResp.setRltCode(UpcConstants.FAILURE_SYS);
			upcResp.setRltMsg("获取微信用户信息失败");
			return upcResp;
		}
		
		upcResp.setBuyerId(resp.getUserId());
		upcResp.setAppId(Property.getProperty("ALIPAY_APPID"));
		
		return upcResp;
	
	}
	
	@Override
	public AlipayGetAccessTokenResp  getOAuthAccessToken(String code) {
		if (StringUtils.isBlank(code)) {
			return null;
		}
		
		//顺手付APPID
		String appId=Property.getProperty("ALIPAY_APPID");
		String priKey = Property.getProperty("ALIPAY_APP_PRI_KEY");
		String pubKey=Property.getProperty("ALIPAY_PUB_KEY");
		
		AlipaySystemOauthTokenResponse resp = AlipayGetAccessToken.getOAuthaccessToken(appId, priKey,pubKey, code);
		logger.info(String.format("获取accessToken是：[%s]", JsonUtil.toJSONString(resp)));
		
		AlipayGetAccessTokenResp re = new AlipayGetAccessTokenResp();
		try {
			BeanUtils.copyProperties(re, resp);
		} catch (Exception e) {
			logger.error("method:getAccessToken（BeanUtils.copyProperties）出现异常，code:{}", code, e);
		}
		return re;
	}

}
