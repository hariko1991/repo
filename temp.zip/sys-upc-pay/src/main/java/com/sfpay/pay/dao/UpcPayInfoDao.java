package com.sfpay.pay.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.pay.domain.UpdateUpcPayInfoParam;
import com.sfpay.upc.domain.upc.QueryUpcPayParam;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.upc.UpcPayUnknownParam;
import com.sfpay.upc.domain.upc.UpcRefundQueryReq;
import com.sfpay.upc.domain.upc.UpdateUpcPayStatusParam;

public interface UpcPayInfoDao {

	/**
	 * 生成流水
	 * 
	 * @param payInfo
	 */
	void createPayInfo(UpcPayInfo payInfo);

	/**
	 * 修改交易未知
	 * 
	 * @param uppParam
	 * @return
	 */
	int updateUppPayUnknown(UpcPayUnknownParam uppParam);

	/**
	 * 查询支付流水
	 * 
	 * @param payParam
	 * @return
	 */
	UpcPayInfo queryPayInfo(QueryUpcPayParam payParam);

	/**
	 * 查询退款流水列表
	 * 
	 * @param req
	 * @return
	 */
	List<UpcPayInfo> queryRefundPayInfo(UpcRefundQueryReq req);

	/**
	 * 获取流水号
	 * 
	 * @return
	 */
	String getReqSn();

	/**
	 * 获取payNo
	 * 
	 * @return
	 */
	String getPayNo();

	/**
	 * 获取时间时间
	 * 
	 * @param tradeBeginTime
	 * @return
	 */
	int getDBInterval(@Param("tradeBeginTime") String tradeBeginTime);

	/**
	 * 更新支付状态
	 * 
	 * @param upcParam
	 * @return
	 */
	int updateUppPayInfoStatus(UpdateUpcPayStatusParam upcParam);

	/**
	 * 更新支付信息
	 * 
	 * @param upcParam
	 * @return
	 */
	int updateUppPayInfo(UpdateUpcPayInfoParam upcParam);

	/**
	 * 
	 * @param payNo
	 * @param notifyType
	 * @return
	 */
	int updateNotifyFlag(@Param("payNo") String payNo, @Param("notifyType") String notifyType);

	/**
	 * 更新二维码字段到upc
	 * 
	 * @param payNo
	 * @param qrCode
	 */
	void updateQrcodeToUpc(@Param("payNo") String payNo, @Param("qrCode") String qrCode);

	List<UpcPayInfo> queryNotifyFailToUppList(@Param("handlePerPage") int handlePerPage);

	/**
	 * 记录异常
	 * 
	 * @param payNo
	 * @param errorMsg
	 */
	void recordError(@Param("payNo") String payNo, @Param("errorMsg") String errorMsg);

	int queryTotalRows(@Param("handleType") String handleType, @Param("status") String status , @Param("beginTime") String beginTime , @Param("endTime") String endTime);

	List<String> queryPayNoList(@Param("handleType") String handleType, @Param("status") String status,
			@Param("pageSize") int pageSize , @Param("beginTime") String beginTime , @Param("endTime") String endTime);

	List<UpcPayInfo> queryPayUnknownRecords(@Param("payNoList")List<String> payNoList);
}
