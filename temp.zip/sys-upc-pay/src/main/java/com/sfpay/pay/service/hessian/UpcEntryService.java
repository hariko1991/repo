package com.sfpay.pay.service.hessian;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alipay.api.response.AlipayTradeRefundResponse;
import com.sfpay.alipay.constant.AlipayConstants;
import com.sfpay.alipay.domain.AlipayTradeCloseResponse;
import com.sfpay.alipay.enums.AlipayErrorCode;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.core.util.StringUtil;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.pay.channel.IAlipayChannelService;
import com.sfpay.pay.channel.ISFPayChannelService;
import com.sfpay.pay.channel.IWXChannelService;
import com.sfpay.pay.channel.sfpay.SFPayBalanceChannelService;
import com.sfpay.pay.channel.sfpay.SFPayBankChannelService;
import com.sfpay.pay.channel.sfpay.SFPayBaseChannelService;
import com.sfpay.pay.channel.voucher.VoucherChannelService;
import com.sfpay.pay.domain.HandleRepeatPay;
import com.sfpay.pay.domain.UpcRequestContext;
import com.sfpay.pay.domain.UpdateUpcPayInfoParam;
import com.sfpay.pay.factory.PayChannelFactory;
import com.sfpay.pay.util.UpcWxCodeUtil;
import com.sfpay.sypay.voucher.valueobject.dto.UserVoucher;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.alipay.AlipayCloseOrderReq;
import com.sfpay.upc.domain.alipay.AlipayCloseOrderResp;
import com.sfpay.upc.domain.alipay.AlipayCreateOrderReq;
import com.sfpay.upc.domain.alipay.AlipayCreateOrderResp;
import com.sfpay.upc.domain.alipay.AlipayRefundReq;
import com.sfpay.upc.domain.alipay.AlipayRefundResp;
import com.sfpay.upc.domain.alipay.PackAlipayMsgReq;
import com.sfpay.upc.domain.alipay.PackAlipayMsgResp;
import com.sfpay.upc.domain.sfpay.OperatorBalanceReq;
import com.sfpay.upc.domain.sfpay.OperatorBalanceResp;
import com.sfpay.upc.domain.sfpay.SfBankPayReq;
import com.sfpay.upc.domain.sfpay.SfBankPayResp;
import com.sfpay.upc.domain.sfpay.SfPayCloseOrderReq;
import com.sfpay.upc.domain.sfpay.SfPayCloseOrderResp;
import com.sfpay.upc.domain.sfpay.SfPayCreateOrderReq;
import com.sfpay.upc.domain.sfpay.SfPayCreateOrderResp;
import com.sfpay.upc.domain.sfpay.SfPayRefundReq;
import com.sfpay.upc.domain.sfpay.SfPayRefundResp;
import com.sfpay.upc.domain.upc.UpcBaseResp;
import com.sfpay.upc.domain.upc.UpcOrderQueryReq;
import com.sfpay.upc.domain.upc.UpcOrderQueryResp;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.upc.UpcRefundQueryReq;
import com.sfpay.upc.domain.upc.UpdateUpcPayStatusParam;
import com.sfpay.upc.domain.voucher.CreateVoucherOrderReq;
import com.sfpay.upc.domain.voucher.CreateVoucherOrderResp;
import com.sfpay.upc.domain.voucher.OperatorVoucherReq;
import com.sfpay.upc.domain.voucher.OperatorVoucherResp;
import com.sfpay.upc.domain.voucher.VoucherInfo;
import com.sfpay.upc.domain.voucher.VoucherRefundReq;
import com.sfpay.upc.domain.voucher.VoucherRefundResp;
import com.sfpay.upc.domain.wx.WXCloseOrderReq;
import com.sfpay.upc.domain.wx.WXCloseOrderResp;
import com.sfpay.upc.domain.wx.WXCreateOrderReq;
import com.sfpay.upc.domain.wx.WXCreateOrderResp;
import com.sfpay.upc.domain.wx.WXPayReq;
import com.sfpay.upc.domain.wx.WXPayResp;
import com.sfpay.upc.domain.wx.WXRefundReq;
import com.sfpay.upc.domain.wx.WXRefundResp;
import com.sfpay.upc.enums.ChannelTradeType;
import com.sfpay.upc.enums.ChannelType;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.exception.UPCServiceException;
import com.sfpay.upc.service.IUpcEntryService;
import com.sfpay.wx.domain.BaseResp;
import com.sfpay.wx.domain.CloseOrderResp;
import com.sfpay.wx.domain.RefundResp;

/**
 * upc新入口
 * 
 * @author 896728
 * @date 2016年9月20日
 *
 */
@Service
@HessianExporter("/upc/upcEntryService")
public class UpcEntryService extends BaseEntryService implements IUpcEntryService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private VoucherChannelService voucherChannelService;
	@Resource
	private SFPayBalanceChannelService balanceChannelService;
	@Resource
	private SFPayBankChannelService sfPayBankChannelService;
	@Resource
	private SFPayBaseChannelService sfPayBaseChannelService;

	/**
	 * 下单
	 * 
	 * @param req
	 * @return
	 */
	@Override
	public WXCreateOrderResp createWxOrder(WXCreateOrderReq req) {
		logger.info("微信支付下单请求参数:{}", req.toString());

		UpcBaseResp resp = checkReqParam(req, "mchNo", "channelCode", "uppOrderNo", "mchOrderNo", "productName", "tradeAmount", "requestIp",
				"systemSource");
		if (resp != null) {
			return new WXCreateOrderResp(resp.getRltCode(), resp.getRltMsg());
		}

		try {
			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());
			// 非空校验
			IWXChannelService wxChannelService = PayChannelFactory.getWechatTradeChannel(req.getChannelCode());
			if (wxChannelService == null) {
				throw new ServiceException(UpcConstants.INVALID_CHANNEL_CODE, "渠道编码不合法，渠道编码：" + req.getChannelCode());
			}
			// 查询本地流水状态
			UpcPayInfo existPayInfo = getUpcPayInfo(req.getMchNo(), ChannelType.WX.name(), null, req.getUppOrderNo());

			if (existPayInfo != null) {
				// 处理重复支付
				HandleRepeatPay repeatPay = handleChannelRepeatPay(req.getChannelCode(), context, existPayInfo);
				return repeatPay.getWxCreateOrderResp();
			}

			// 执行下单
			WXCreateOrderResp createOrderResp = wxChannelService.createPayOrder(req, context.getChannelArgs());
			logger.info("微信支付下单返回数据:[{}]", createOrderResp.toString());
			return createOrderResp;

		} catch (ServiceException e) {
			logger.error("微信支付下单异常 req:" + req.toString(), e);
			return new WXCreateOrderResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("微信支付下单异常req:" + req.toString(), e);
			return new WXCreateOrderResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public WXPayResp packageWxData(WXPayReq req) {
		logger.info("微信支付组装支付凭证请求参数:{}", req.toString());
		if (req == null || StringUtils.isEmpty(req.getUppOrderNo()) || StringUtils.isEmpty(req.getChannelCode())) {
			return new WXPayResp(UpcConstants.PARAM_NULL, "wxprepayId 或渠道编号不能为空");
		}
		try {
			UpcPayInfo payInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getUppOrderNo());

			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());
			WXPayResp payData = wxBaseChannelService.packagePayCertificate(payInfo, context.getChannelArgs());
			logger.info("微信支付组装支付凭证请求参数:{}", payData.toString());
			return payData;
		} catch (ServiceException e) {
			logger.error("微信组装支付凭证异常 req:" + req.toString(), e);
			return new WXPayResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("组装微信数据下单异常 req:" + req.toString(), e);
			return new WXPayResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public WXCloseOrderResp closeWxOrder(WXCloseOrderReq req) {
		logger.info("微信关单请求参数:[{}]", req.toString());
		// 验证参数
		if (StringUtils.isEmpty(req.getUppOrderNo())) {
			return new WXCloseOrderResp(UpcConstants.PARAM_NULL, "UPP订单号不能同时为空");
		}
		try {

			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());
			// 查询本地流水状态
			UpcPayInfo payInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getUppOrderNo());
			if (payInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}
			CloseOrderResp closeOrderResp = wxBaseChannelService.closeOrder(req, context.getChannelArgs());
			// 关单成功
			WXCloseOrderResp resultResp = new WXCloseOrderResp();
			if ((BaseResp.SUCCESS.equals(closeOrderResp.getReturnCode()) && BaseResp.SUCCESS.equals(closeOrderResp.getResultCode()))
					|| orderNotExistsAndExpres(closeOrderResp.getErrCode(), payInfo)) {
				// 修改订单状态
				UpdateUpcPayStatusParam updateOrderStatusReq = new UpdateUpcPayStatusParam();
				updateOrderStatusReq.setPayNo(payInfo.getPayNo());
				updateOrderStatusReq.setMchNo(payInfo.getMchNo());
				updateOrderStatusReq.setOriginalStatus(TradeStatus.TRADING.name());
				updateOrderStatusReq.setTargetStatus(TradeStatus.CLOSE.name());
				payManageInfoService.updatePayInfoStatus(updateOrderStatusReq);
				logger.info("修改支付流水状态为关闭成功");
				resultResp.setRltCode(UpcConstants.SUCCESS);
			} else {

				String upcErrorCode = UpcWxCodeUtil.transferWxErrorCode(StringUtils.isNotEmpty(closeOrderResp.getErrCode()) ? closeOrderResp
						.getErrCode() : "FAIL");
				String errorMsg = StringUtils.isNotEmpty(closeOrderResp.getErrCodeDes()) ? closeOrderResp.getErrCodeDes() : closeOrderResp
						.getReturnMsg();
				resultResp.setRltCode(upcErrorCode);
				resultResp.setRltMsg(errorMsg);
				// 记录错误
				recordWxError(payInfo.getPayNo(), closeOrderResp);
			}
			logger.info("微信关单响应参数:[{}]", resultResp.toString());

			return resultResp;

		} catch (ServiceException e) {
			logger.error("关闭订单异常req:" + req.toString(), e);
			return new WXCloseOrderResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("关闭订单异常req:" + req.toString(), e);
			return new WXCloseOrderResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public WXRefundResp wxRefund(WXRefundReq req) {

		logger.info("微信退款请求参数:[{}]", req.toString());
		UpcBaseResp resp = checkReqParam(req, "mchNo", "channelCode", "uppOrderNo", "uppRefundNo", "mchRefundNo");
		if (resp != null) {
			return new WXRefundResp(resp.getRltCode(), resp.getRltMsg());
		}

		try {
			if (req.getRefundFee() != null && req.getRefundFee().longValue() <= 0) {
				throw new ServiceException(UpcConstants.INVALID_REFUND_AMOUNT, "退款金额无效");
			}

			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());
			// 验证商户退款流水
			validateMchRefundWater(req.getMchNo(), req.getChannelCode(), req.getUppRefundNo());
			// 1.查询本地流水状态
			UpcPayInfo formerPayInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getUppOrderNo());
			if (formerPayInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}

			// 只有支付成功的才可以退款
			if (!UpcConstants.SUCCESS.equals(formerPayInfo.getStatus())) {
				return new WXRefundResp(UpcConstants.ONLY_SUCC_ORDER_CAN_REFUND, "只有交易成功才可以退款");
			}

			if (req.getRefundFee().longValue() > formerPayInfo.getTradeAmt().longValue()) {
				return new WXRefundResp(UpcConstants.REFUND_AMOUNT_GT_TRADE_AMOUNT, "退款金额大于支付总金额");
			}

			// 2.查询已退款的流水记录
			UpcRefundQueryReq refundQueryReq = new UpcRefundQueryReq();
			refundQueryReq.setMchNo(req.getMchNo());
			refundQueryReq.setOldPayNo(formerPayInfo.getPayNo());
			List<UpcPayInfo> refundPayInfoList = payManageInfoService.queryRefundPayInfo(refundQueryReq);

			// 3. 校验已退款金额
			if (refundPayInfoList != null && !refundPayInfoList.isEmpty()) {
				long totalPayAmount = formerPayInfo.getTradeAmt().longValue();
				long haveRefundAmount = 0; // 已退款金额
				for (UpcPayInfo p : refundPayInfoList) {
					haveRefundAmount += p.getTradeAmt().longValue();
				}
				if (req.getRefundFee().longValue() + haveRefundAmount > totalPayAmount) {
					logger.error("已退款金额大于支付总金额 总金额:[{}], 已退款:[{}] ", totalPayAmount, haveRefundAmount);
					return new WXRefundResp(UpcConstants.REFUND_AMOUNT_GT_TRADE_AMOUNT, "已退款金额大于支付总金额");
				}
			}

			// 3. 生成退款流水
			UpcPayInfo refundPayInfo = buildRefundPayInfo(req, formerPayInfo, context);
			logger.info("开始生成支付流水...");
			payManageInfoService.createPayInfo(refundPayInfo);
			logger.info("结束生成支付流水:payNo:[{}]...", refundPayInfo.getPayNo());
			// 4. 调用微信退款
			RefundResp refundResp = wxBaseChannelService.refund(formerPayInfo, refundPayInfo, context.getChannelArgs());
			// 5.退款处理
			UpdateUpcPayInfoParam updatePayReq = buildUpdateRefundData(refundPayInfo, refundResp);
			payManageInfoService.updatePayInfo(updatePayReq);
			logger.info("修改支付流水状态为退款进行中");
			WXRefundResp resultResp = new WXRefundResp();

			if (TradeStatus.REFUND_ACCEPTED.name().equals(updatePayReq.getTargetStatus())) {
				resultResp.setRltCode(UpcConstants.SUCCESS);
				resultResp.setWxOrderNo(formerPayInfo.getRtnOrderNo());
				resultResp.setMchOrderNo(formerPayInfo.getMchOrderNo());
				resultResp.setMchRefundNo(refundPayInfo.getMchOrderNo());
				resultResp.setWxRefundId(refundResp.getRefundId());
				resultResp.setTradeAmount(formerPayInfo.getTradeAmt());
				resultResp.setRefundFee(refundPayInfo.getTradeAmt());
				resultResp.setStatus(TradeStatus.REFUND_ACCEPTED.name());
			} else {
				String upcErrorCode = UpcWxCodeUtil.transferWxErrorCode(updatePayReq.getRtnCode());
				String errorMsg = updatePayReq.getRtnMsg();
				resultResp.setRltCode(upcErrorCode);
				resultResp.setRltMsg(errorMsg);
				resultResp.setStatus(TradeStatus.REFUND_FAIL.name());

				// 记录错误
				recordWxError(refundPayInfo.getPayNo(), refundResp);
			}
			logger.info("退款响应结果:[{}]", resultResp.toString());
			return resultResp;

		} catch (ServiceException e) {
			logger.error("退款异常 req:" + req.toString(), e);
			return new WXRefundResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("退款异常 req:" + req.toString(), e);
			return new WXRefundResp(e.getCode(), e.getMsg());
		}
	}

	/**
	 * upc订单查询
	 */
	@Override
	public UpcOrderQueryResp upcOrderQuery(UpcOrderQueryReq req) {

		logger.info("订单查询请求参数:{}", req.toString());
		// 验证参数
		if (StringUtils.isEmpty(req.getUppOrderNo())) {
			return new UpcOrderQueryResp(UpcConstants.PARAM_NULL, "UPP订单号不能为空");
		}
		try {
			// 查询流水状态
			UpcPayInfo payInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getUppOrderNo());
			if (payInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}
			UpcOrderQueryResp target = new UpcOrderQueryResp();
			PropertyUtils.copyProperties(target, payInfo);
			target.setRltCode(UpcConstants.SUCCESS);
			return target;
		} catch (ServiceException e) {
			logger.error("订单查询异常 req:" + req.toString(), e);
			return new UpcOrderQueryResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("订单查询异常 req:" + req.toString(), e);
			return new UpcOrderQueryResp(e.getCode(), e.getMsg());
		} catch (Exception e) {
			logger.error("订单查询异常 req:" + req.toString(), e);
			return new UpcOrderQueryResp(UpcConstants.FAILURE_SYS, "系统异常");
		}
	}

	/**
	 * 创建支付宝订单
	 */
	@Override
	public AlipayCreateOrderResp createAlipayOrder(AlipayCreateOrderReq req) {
		logger.info("支付宝下单请求参数:{}", req.toString());
		try {
			// 校验下单参数
			validCreateAlipayOrderReqArgs(req);

			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());
			// 非空校验
			IAlipayChannelService alipayChannelService = PayChannelFactory.getAlipayTradeChannel(req.getChannelCode());
			if (alipayChannelService == null) {
				throw new ServiceException(UpcConstants.INVALID_CHANNEL_CODE, "渠道编码不合法，渠道编码：" + req.getChannelCode());
			}
			// 查询本地流水状态
			UpcPayInfo existPayInfo = getUpcPayInfo(req.getMchNo(), ChannelType.ALIPAY.name(), null, req.getUppOrderNo());

			// 成功 失败 退款 不能重新下单
			if (existPayInfo != null) {
				// 处理重复支付
				HandleRepeatPay repeatPay = handleChannelRepeatPay(req.getChannelCode(), context, existPayInfo);
				return repeatPay.getAlipayCreateOrderResp();
			}

			// 执行下单
			AlipayCreateOrderResp createOrderResp = alipayChannelService.createPayOrder(req, context.getChannelArgs());
			logger.info("支付宝下单返回数据:[{}]", createOrderResp.toString());
			return createOrderResp;

		} catch (ServiceException e) {
			logger.error("支付宝下单异常 req:" + req.toString(), e);
			return new AlipayCreateOrderResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("支付宝下单异常req:" + req.toString(), e);
			return new AlipayCreateOrderResp(e.getCode(), e.getMsg());
		}
	}

	/**
	 * 关闭支付宝订单
	 * 
	 * @param req
	 * @return
	 */
	@Override
	public AlipayCloseOrderResp closeAlipayOrder(AlipayCloseOrderReq req) {
		logger.info("支付宝关单请求参数:[{}]", req.toString());
		try {

			validCloseOrderReqParams(req);

			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());

			// 查询本地流水状态
			UpcPayInfo payInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getUppOrderNo());
			if (payInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}

			validateOrderFinishStatus(payInfo.getStatus());

			AlipayTradeCloseResponse closeOrderResp = alipayBaseChannelService.closeOrder(req, context.getChannelArgs());
			logger.info("关单响应参数:[{}]", closeOrderResp.getBody());
			AlipayCloseOrderResp resultResp = new AlipayCloseOrderResp();

			// 关单成功
			if (closeOrderResp != null
					&& (AlipayConstants.SUCCESS.equals(closeOrderResp.getCode()) || orderNotExistsAndExpres(closeOrderResp.getSubCode(), payInfo))) {
				// 修改订单状态
				UpdateUpcPayStatusParam updateOrderStatusReq = new UpdateUpcPayStatusParam();
				updateOrderStatusReq.setPayNo(payInfo.getPayNo());
				updateOrderStatusReq.setMchNo(payInfo.getMchNo());
				updateOrderStatusReq.setOriginalStatus(TradeStatus.TRADING.name());
				updateOrderStatusReq.setTargetStatus(TradeStatus.CLOSE.name());
				payManageInfoService.updatePayInfoStatus(updateOrderStatusReq);
				logger.info("修改支付流水状态为关闭成功");
				resultResp.setRltCode(UpcConstants.SUCCESS);

			} else {
				if (AlipayErrorCode.TRADE_STATUS_ERROR.getCode().equals(closeOrderResp.getSubCode())) {
					// 关单失败
					resultResp.setRltCode(UpcConstants.ORDER_STATUS_ILLEGAL);
					resultResp.setRltMsg("只有等待买家付款状态可以关单");
				} else {
					resultResp.setRltCode(UpcConstants.FAILURE_SYS);
					resultResp.setRltMsg("系统异常");
				}
			}

			logger.info("支付宝关单响应参数:[{}]", resultResp.toString());

			return resultResp;

		} catch (ServiceException e) {
			logger.error("关闭订单异常req:" + req.toString(), e);
			return new AlipayCloseOrderResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("关闭订单异常req:" + req.toString(), e);
			return new AlipayCloseOrderResp(e.getCode(), e.getMsg());
		}
	}

	/**
	 * 支付宝退款
	 */
	@Override
	public AlipayRefundResp alipayRefund(AlipayRefundReq req) {

		logger.info("支付宝退款请求参数:[{}]", req.toString());
		try {
			validAlipayRefundReqArgs(req);

			UpcRequestContext context = getRequestContext(req.getMchNo(), req.getChannelCode());
			// 验证商户退款流水
			validateMchRefundWater(req.getMchNo(), req.getChannelCode(), req.getUppRefundNo());
			// 1.查询本地流水状态
			UpcPayInfo existsPayInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getUppOrderNo());
			if (existsPayInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}

			// 只有支付成功的才可以退款
			if (!UpcConstants.SUCCESS.equals(existsPayInfo.getStatus())) {
				return new AlipayRefundResp(UpcConstants.ONLY_SUCC_ORDER_CAN_REFUND, "只有交易成功才可以退款");
			}

			if (req.getRefundFee().longValue() > existsPayInfo.getTradeAmt().longValue()) {
				return new AlipayRefundResp(UpcConstants.REFUND_AMOUNT_GT_TRADE_AMOUNT, "退款金额大于支付总金额");
			}

			// 2.查询已退款的流水记录
			UpcRefundQueryReq refundQueryReq = new UpcRefundQueryReq();
			refundQueryReq.setMchNo(req.getMchNo());
			refundQueryReq.setOldPayNo(existsPayInfo.getPayNo());
			List<UpcPayInfo> refundPayInfoList = payManageInfoService.queryRefundPayInfo(refundQueryReq);

			// 3. 校验已退款金额
			long haveRefundAmount = 0; // 已退款金额
			if (refundPayInfoList != null && !refundPayInfoList.isEmpty()) {
				long totalPayAmount = existsPayInfo.getTradeAmt().longValue();
				for (UpcPayInfo p : refundPayInfoList) {
					haveRefundAmount += p.getTradeAmt().longValue();
				}
				if (req.getRefundFee() + haveRefundAmount > totalPayAmount) {
					logger.error("已退款金额大于支付总金额 总金额:[{}], 已退款:[{}] ", totalPayAmount, haveRefundAmount);
					return new AlipayRefundResp(UpcConstants.REFUND_AMOUNT_GT_TRADE_AMOUNT, "已退款金额大于支付总金额");
				}
			}

			// 3. 生成退款流水
			UpcPayInfo refundPayInfo = buildRefundPayInfo(req, existsPayInfo, context);
			logger.info("开始生成支付流水...");
			payManageInfoService.createPayInfo(refundPayInfo);
			logger.info("结束生成支付流水:payNo:[{}]...", refundPayInfo.getPayNo());
			// 4. 调用支付宝退款
			AlipayTradeRefundResponse refundResp = alipayBaseChannelService.refund(existsPayInfo, refundPayInfo, context.getChannelArgs());
			logger.info("payNo:[{}]退款响应数据： :[{}]", refundPayInfo.getPayNo(), refundResp.getBody());
			// 5.退款处理
			UpdateUpcPayInfoParam updatePayReq = buildUpdateRefundData(refundPayInfo, refundResp);
			payManageInfoService.updatePayInfo(updatePayReq);
			logger.info("修改支付流水状态");

			// 6. 处理全额退款
			if (existsPayInfo.getTradeAmt().longValue() == (haveRefundAmount + req.getRefundFee().longValue())) {
				updateOriginalOrderToRefundSucc(existsPayInfo);
			}

			AlipayRefundResp resultResp = new AlipayRefundResp();

			if (TradeStatus.REFUND_SUCC.name().equals(updatePayReq.getTargetStatus())) {
				resultResp.setRltCode(UpcConstants.SUCCESS);
				resultResp.setAlipayOrderNo(existsPayInfo.getRtnOrderNo());
				resultResp.setMchOrderNo(existsPayInfo.getMchOrderNo());
				resultResp.setMchRefundNo(refundPayInfo.getMchOrderNo());
				// 支付宝退款不会返回退款订单号 凡是支付宝退款一律返回upc的流水号(payNo)
				resultResp.setAlipayRefundId(refundPayInfo.getPayNo());
				resultResp.setTradeAmount(existsPayInfo.getTradeAmt());
				resultResp.setRefundFee(refundPayInfo.getTradeAmt());
				resultResp.setUpcRefundNo(refundPayInfo.getPayNo());
				resultResp.setStatus(TradeStatus.REFUND_SUCC.name());
			} else {
				// 转换支付宝错误码
				if (StringUtils.isNotBlank(refundResp.getSubCode())) {
					try {
						AlipayErrorCode result = AlipayErrorCode.valueOf(refundResp.getSubCode());
						resultResp.setRltCode(result.getUpcCode());
						resultResp.setRltMsg(result.getMsg());
						resultResp.setStatus(TradeStatus.REFUND_FAIL.name());
					} catch (Exception e) {
						logger.error("不存在编码:[{}]", refundResp.getSubCode());
					}
				}

				if (StringUtils.isEmpty(resultResp.getRltCode())) {
					resultResp.setRltCode(UpcConstants.FAILURE_SYS);
					resultResp.setRltMsg("系统异常");
					resultResp.setStatus(TradeStatus.REFUND_FAIL.name());
				}
			}
			logger.info("退款响应结果:[{}]", resultResp.toString());
			return resultResp;

		} catch (ServiceException e) {
			logger.error("退款异常req:" + req.toString(), e);
			return new AlipayRefundResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("退款异常req:" + req.toString(), e);
			return new AlipayRefundResp(e.getCode(), e.getMsg());
		}
	}

	/**
	 * 组装支付宝数据
	 */
	@Override
	public PackAlipayMsgResp packageAlipayData(PackAlipayMsgReq req) {
		logger.info("组装支付宝数据请求参数:{}", req.toString());
		try {
			UpcPayInfo payInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getUppOrderNo());
			if (payInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}
			AlipayCreateOrderResp createOrderResp = alipayBaseChannelService.returnPayData(payInfo);
			PackAlipayMsgResp resp = new PackAlipayMsgResp();

			resp.setRltCode(UpcConstants.SUCCESS);
			resp.setChannelCode(req.getChannelCode());
			resp.setPayMessage(createOrderResp.getAlipayPayStr());

			logger.info("组装支付宝数据响应参数:{}", resp.toString());
			return resp;
		} catch (ServiceException e) {
			logger.error("组装支付宝报文异常req:" + req.toString(), e);
			return new PackAlipayMsgResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("组装支付宝报文异常req:" + req.toString(), e);
			return new PackAlipayMsgResp(e.getCode(), e.getMsg());
		}
	}

	/**
	 * 券下单
	 */
	@Override
	public CreateVoucherOrderResp orderVoucher(CreateVoucherOrderReq req) {
		logger.info("券下单请求参数:{}", req.toString());

		//1220版本需求,微信支付没有"memberNo",
		UpcBaseResp validReq = checkReqParam(req, "mchNo", "channelCode", "uppOrderNo", "voucherCode", "mchOrderNo", "productName",
				"tradeAmount", "systemSource");
		if (validReq != null) {
			return new CreateVoucherOrderResp(validReq.getRltCode(), validReq.getRltMsg());
		}

		try {
			if (!ChannelTradeType.SFPAY_VOUCHER.name().equals(req.getChannelCode())) {
				return new CreateVoucherOrderResp(UpcConstants.VOUCHER_IS_NOT_RIGHT, "券类型不正确");
			}

			// 查询本地流水状态
			UpcPayInfo existPayInfo = getUpcPayInfo(req.getMchNo(), ChannelType.VOUCHER.name(), null, req.getUppOrderNo());

			// 成功 失败 退款 不能重新下单
			if (existPayInfo != null) {
				// 状态校验
				validateExistPayInfoStatus(existPayInfo);
				//更新券编码，单独券允许切换
				if(!StringUtil.equal(req.getVoucherCode(), existPayInfo.getVoucherCode())){
					UpdateUpcPayInfoParam updatePayReq = new UpdateUpcPayInfoParam();
					updatePayReq.setPayNo(existPayInfo.getPayNo());
					updatePayReq.setVoucherCode(req.getVoucherCode());
					updatePayReq.setTradeAmt(req.getTradeAmount());
					payManageInfoService.updatePayInfo(updatePayReq);
				}
				// 组装返回数据
				CreateVoucherOrderResp resp = new CreateVoucherOrderResp(UpcConstants.SUCCESS, null);
				resp.setChannelCode(req.getChannelCode());
				resp.setMchNo(req.getMchNo());
				resp.setUpcTradeNo(existPayInfo.getPayNo());
				return resp;
			}
			

			// 执行下单
			CreateVoucherOrderResp createOrderResp = voucherChannelService.createPayOrder(req);
			logger.info("券下单返回数据:[{}]", createOrderResp.toString());
			return createOrderResp;

		} catch (ServiceException e) {
			logger.error("券下单异常 req:" + req.toString(), e);
			return new CreateVoucherOrderResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("券下单异常req:" + req.toString(), e);
			return new CreateVoucherOrderResp(e.getCode(), e.getMsg());
		}
	}

	/**
	 * 券查询
	 */
	@Override
	public VoucherInfo queryVoucher(String voucherCode) {
		logger.info("券查询请求参数:{}", voucherCode);

		if (StringUtils.isEmpty(voucherCode)) {
			return new VoucherInfo(UpcConstants.PARAM_NULL, "券编码不能为空");
		}

		try {
			UserVoucher voucher = voucherChannelService.queryVoucher(voucherCode);
			logger.info("券查询返回数据:[{}]", voucher);
			if (voucher == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}
			VoucherInfo voucherInfo = setVoucherInfo(voucher);

			return voucherInfo;

		} catch (ServiceException e) {
			logger.error("券查询异常 :" + voucherCode, e);
			return new VoucherInfo(e.getCode(), e.getMsg());
		} catch (Exception e) {
			logger.error("券查询异常:" + voucherCode, e);
			return new VoucherInfo(UpcConstants.FAILURE_SYS, "系统异常");
		}
	}

	/**
	 * 券冻结
	 */
	@Override
	public OperatorVoucherResp freezeVoucher(OperatorVoucherReq req) {
		logger.info("券冻结请求参数:{}", req.toString());
		UpcBaseResp validReq = checkReqParam(req, "mchNo", "channelCode", "uppOrderNo", "sourceType", "channelId");
		if (validReq != null) {
			return new OperatorVoucherResp(validReq.getRltCode(), validReq.getRltMsg());
		}
		try {
			// 查询券订单判断是否已冻结
			UpcPayInfo payInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getUppOrderNo());
			if (payInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}

			// 已冻结提示冻结成功
			if (TradeStatus.FREEZE.name().equals(payInfo.getStatus())) {
				OperatorVoucherResp resp = new OperatorVoucherResp(UpcConstants.SUCCESS, null);
				resp.setStatus(TradeStatus.SUCCESS.name());
				return resp;
			}

			// 执行冻结
			voucherChannelService.freezeVoucher(req, payInfo);
			// 组装返回数据
			OperatorVoucherResp resp = new OperatorVoucherResp(UpcConstants.SUCCESS, null);
			resp.setStatus(TradeStatus.SUCCESS.name());
			logger.info("券冻结响应参数:{}", resp.toString());
			return resp;
		} catch (ServiceException e) {
			logger.error("券冻结异常 req:" + req.toString(), e);
			return new OperatorVoucherResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("券冻结异常req:" + req.toString(), e);
			return new OperatorVoucherResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public OperatorVoucherResp unfreezeVoucher(OperatorVoucherReq req) {
		logger.info("券解冻请求参数:{}", req.toString());

		UpcBaseResp validReq = checkReqParam(req, "mchNo", "channelCode", "uppOrderNo", "unfrezzeType");
		if (validReq != null) {
			return new OperatorVoucherResp(validReq.getRltCode(), validReq.getRltMsg());
		}
		try {
			// 查询券订单判断是否已冻结 非冻结状态直接返回
			UpcPayInfo payInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getUppOrderNo());
			if (payInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}

			if (!TradeStatus.FREEZE.name().equals(payInfo.getStatus())) {
				throw new ServiceException(UpcConstants.ORDER_STATUS_ILLEGAL, "订单状态非法");
			}
			// 执行解冻
			voucherChannelService.unfreezeVoucher(req.getUnfrezzeType(), payInfo);

			// 组装返回数据
			OperatorVoucherResp resp = new OperatorVoucherResp(UpcConstants.SUCCESS, null);
			resp.setStatus(TradeStatus.SUCCESS.name());

			logger.info("券解冻响应参数:{}", resp.toString());
			return resp;
		} catch (ServiceException e) {
			logger.error("券解冻异常 req:" + req.toString(), e);
			return new OperatorVoucherResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("券解冻异常req:" + req.toString(), e);
			return new OperatorVoucherResp(e.getCode(), e.getMsg());
		}

	}

	@Override
	public OperatorVoucherResp voucherUnfreezeAndPay(OperatorVoucherReq req) {
		logger.info("券解冻支付请求参数:{}", req.toString());

		UpcBaseResp validReq = checkReqParam(req, "mchNo", "channelCode", "uppOrderNo");
		if (validReq != null) {
			return new OperatorVoucherResp(validReq.getRltCode(), validReq.getRltMsg());
		}
		try {
			// 更新为处理中
			updateStatusByUppOrderNo(req.getUppOrderNo(), TradeStatus.FREEZE, TradeStatus.TRADING);

			UpcPayInfo payInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getUppOrderNo());

			// 执行解冻支付
			voucherChannelService.voucherUnfreezeAndPay(req, payInfo);

			// 组装返回数据
			OperatorVoucherResp resp = new OperatorVoucherResp(UpcConstants.SUCCESS, null);
			resp.setStatus(TradeStatus.SUCCESS.name());

			logger.info("券解冻支付响应参数:{}", resp.toString());
			return resp;
		} catch (ServiceException e) {
			logger.error("券解冻异常 req:" + req.toString(), e);
			return new OperatorVoucherResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("券解冻异常req:" + req.toString(), e);
			return new OperatorVoucherResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public OperatorVoucherResp voucherClose(OperatorVoucherReq req) {

		logger.info("券关闭请求参数:{}", req.toString());
		UpcBaseResp validReq = checkReqParam(req, "mchNo", "channelCode", "uppOrderNo");
		if (validReq != null) {
			return new OperatorVoucherResp(validReq.getRltCode(), validReq.getRltMsg());
		}
		try {

			UpcPayInfo payInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getUppOrderNo());
			if (payInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}

			if (TradeStatus.CLOSE.name().equals(payInfo.getStatus())) {
				OperatorVoucherResp resp = new OperatorVoucherResp(UpcConstants.SUCCESS, null);
				resp.setStatus(TradeStatus.SUCCESS.name());
				return resp;
			}

			if (!TradeStatus.INIT.name().equals(payInfo.getStatus())) {
				throw new ServiceException(UpcConstants.ORDER_STATUS_ILLEGAL, "订单状态不合法");
			}

			// 更新状态
			updateStatusByUpcPayNo(payInfo.getPayNo(), TradeStatus.INIT, TradeStatus.CLOSE);

			// 组装返回数据
			OperatorVoucherResp resp = new OperatorVoucherResp(UpcConstants.SUCCESS, null);
			resp.setStatus(TradeStatus.SUCCESS.name());
			logger.info("券关闭响应参数:{}", resp.toString());
			return resp;
		} catch (ServiceException e) {
			logger.error("券关单异常 req:" + req.toString(), e);
			return new OperatorVoucherResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("券关单异常req:" + req.toString(), e);
			return new OperatorVoucherResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public VoucherRefundResp voucherRefund(VoucherRefundReq req) {
		logger.info("券退款请求参数:{}", req.toString());
		UpcBaseResp resp = checkReqParam(req, "mchNo", "channelCode", "formerUppOrderNo", "uppRefundNo", "mchRefundNo");
		if (resp != null) {
			return new VoucherRefundResp(resp.getRltCode(), resp.getRltMsg());
		}

		try {
			// 验证商户退款流水
			validateMchRefundWater(req.getMchNo(), req.getChannelCode(), req.getUppRefundNo());
			// 查询本地流水状态
			UpcPayInfo formerPayInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getFormerUppOrderNo());
			if (formerPayInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}

			// 只有支付成功的才可以退款
			if (!UpcConstants.SUCCESS.equals(formerPayInfo.getStatus())) {
				return new VoucherRefundResp(UpcConstants.ONLY_SUCC_ORDER_CAN_REFUND, "只有交易成功才可以退款");
			}

			// 生成退款流水
			UpcPayInfo refundPayInfo = buildRefundPayInfo(req, formerPayInfo, null);
			logger.info("开始生成支付流水...");
			payManageInfoService.createPayInfo(refundPayInfo);
			logger.info("结束生成支付流水:payNo:[{}]...", refundPayInfo.getPayNo());
			// 调用退款
			VoucherRefundResp refundResp = voucherChannelService.doRefund(req, refundPayInfo);
			logger.info("券退款响应结果:[{}]", refundResp.toString());
			return refundResp;

		} catch (ServiceException e) {
			logger.error("券退款异常 req:" + req.toString(), e);
			return new VoucherRefundResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("券退款异常 req:" + req.toString(), e);
			return new VoucherRefundResp(e.getCode(), e.getMsg());
		}
	}

	/**
	 * 下单到顺手付
	 */
	@Override
	public SfPayCreateOrderResp orderSFPAY(SfPayCreateOrderReq req) {
		logger.info("顺手付下单请求参数:{}", req.toString());
		UpcBaseResp resp = checkReqParam(req, "mchNo", "channelCode", "memberNo", "sceneCode", "uppOrderNo", "mchOrderNo", "productName",
				"tradeAmount", "systemSource");
		if (resp != null) {
			return new SfPayCreateOrderResp(resp.getRltCode(), resp.getRltMsg());
		}
		try {
			if (req.getTradeAmount() == null || req.getTradeAmount().longValue() <= 0) {
				throw new ServiceException(UpcConstants.TRADE_AMOUNT_IS_NULL, "交易金额为空或不合法");
			}

			// 非空校验
			ISFPayChannelService sfPayChannelService = PayChannelFactory.getSfPayTradeChannel(req.getChannelCode());
			if (sfPayChannelService == null) {
				throw new ServiceException(UpcConstants.INVALID_CHANNEL_CODE, "渠道编码不合法，渠道编码：" + req.getChannelCode());
			}
			// 查询本地流水状态
			UpcPayInfo existPayInfo = getUpcPayInfo(req.getMchNo(), null, req.getChannelCode(), req.getUppOrderNo());

			// 成功 失败 退款
			if (existPayInfo != null) {

				// 状态校验
				validateExistPayInfoStatus(existPayInfo);
				SfPayCreateOrderResp sfpayResp = new SfPayCreateOrderResp(UpcConstants.SUCCESS, null);
				sfpayResp.setMchNo(req.getMchNo());
				sfpayResp.setChannelCode(req.getChannelCode());
				sfpayResp.setChannelRtnNo(existPayInfo.getRtnOrderNo());
				sfpayResp.setUpcTradeNo(existPayInfo.getPayNo());
				return sfpayResp;
			}

			// 执行下单
			SfPayCreateOrderResp createOrderResp = sfPayChannelService.createPayOrder(req);
			logger.info("顺手付下单返回数据:[{}]", createOrderResp.toString());
			return createOrderResp;

		} catch (ServiceException e) {
			logger.error("顺手付下单异常 req:" + req.toString(), e);
			return new SfPayCreateOrderResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("顺手付下单异常req:" + req.toString(), e);
			return new SfPayCreateOrderResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public OperatorBalanceResp freezeSFPAYBalance(OperatorBalanceReq req) {

		logger.info("余额冻结请求参数:{}", req.toString());
		UpcBaseResp validReq = checkReqParam(req, "mchNo", "channelCode", "uppOrderNo");
		if (validReq != null) {
			return new OperatorBalanceResp(validReq.getRltCode(), validReq.getRltMsg());
		}
		try {
			// 查询订单判断是否已冻结
			UpcPayInfo payInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getUppOrderNo());
			if (payInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}
			if (TradeStatus.FREEZE.name().equals(payInfo.getStatus())) {
				OperatorBalanceResp resp = new OperatorBalanceResp(UpcConstants.SUCCESS, null);
				resp.setStatus(TradeStatus.SUCCESS.name());
				return resp;
			}
			// 执行冻结
			balanceChannelService.freezeSFPAYBalance(payInfo);

			// 组装返回数据
			OperatorBalanceResp resp = new OperatorBalanceResp(UpcConstants.SUCCESS, null);
			resp.setStatus(TradeStatus.SUCCESS.name());
			logger.info("余额冻结响应参数:{}", resp.toString());
			return resp;
		} catch (ServiceException e) {
			logger.error("余额冻结异常 req:" + req.toString(), e);
			return new OperatorBalanceResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("余额冻结异常req:" + req.toString(), e);
			return new OperatorBalanceResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public OperatorBalanceResp unfreezeSFPAYBalance(OperatorBalanceReq req) {
		logger.info("余额解冻请求参数:{}", req.toString());
		UpcBaseResp validReq = checkReqParam(req, "mchNo", "channelCode", "uppOrderNo", "unfrezzeType");
		if (validReq != null) {
			return new OperatorBalanceResp(validReq.getRltCode(), validReq.getRltMsg());
		}
		try {
			// 查询订单判断是否已冻结 非冻结状态直接返回
			UpcPayInfo payInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getUppOrderNo());
			if (payInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}

			if (!TradeStatus.FREEZE.name().equals(payInfo.getStatus())) {
				throw new ServiceException(UpcConstants.ORDER_STATUS_ILLEGAL, "订单状态非法");
			}

			// 执行解冻
			balanceChannelService.unfreezeSFPAYBalance(req.getUnfrezzeType(), payInfo);

			// 组装返回数据
			OperatorBalanceResp resp = new OperatorBalanceResp(UpcConstants.SUCCESS, null);
			resp.setStatus(TradeStatus.SUCCESS.name());
			logger.info("余额解冻请求参数:{}", req.toString());
			return resp;
		} catch (ServiceException e) {
			logger.error("余额解冻异常 req:" + req.toString(), e);
			return new OperatorBalanceResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("余额解冻异常req:" + req.toString(), e);
			return new OperatorBalanceResp(e.getCode(), e.getMsg());
		}
	}

	/**
	 * 余额解冻支付
	 */
	@Override
	public OperatorBalanceResp balanceUnfreezeAndPay(OperatorBalanceReq req) {
		logger.info("余额解冻支付请求参数:{}", req.toString());

		UpcBaseResp validReq = checkReqParam(req, "mchNo", "channelCode", "uppOrderNo");
		if (validReq != null) {
			return new OperatorBalanceResp(validReq.getRltCode(), validReq.getRltMsg());
		}
		try {
			// 更新为处理中
			updateStatusByUppOrderNo(req.getUppOrderNo(), TradeStatus.FREEZE, TradeStatus.TRADING);

			UpcPayInfo payInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getUppOrderNo());
			if (payInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}
			// 验证是否是中态
			validateOrderFinishStatus(payInfo.getStatus());

			// 执行解冻支付
			OperatorBalanceResp resp = balanceChannelService.balanceUnfreezeAndPay(payInfo);

			logger.info("余额解冻支付响应参数:{}", resp.toString());
			return resp;
		} catch (ServiceException e) {
			logger.error("余额解冻支付异常 req:" + req.toString(), e);
			return new OperatorBalanceResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("余额解冻支付异常req:" + req.toString(), e);
			return new OperatorBalanceResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public SfBankPayResp sfPayBankPay(SfBankPayReq req) {
		logger.info("银行卡支付请求参数:{}", req.toString());
		UpcBaseResp validReq = checkReqParam(req, "mchNo", "channelCode", "uppOrderNo");
		if (validReq != null) {
			return new SfBankPayResp(validReq.getRltCode(), validReq.getRltMsg());
		}
		try {
			// 更新为处理中
			updateStatusByUppOrderNo(req.getUppOrderNo(), TradeStatus.INIT, TradeStatus.TRADING);

			UpcPayInfo payInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getUppOrderNo());
			// 验证是否是终态
			validateOrderFinishStatus(payInfo.getStatus());

			// 执行支付
			SfBankPayResp resp = sfPayBankChannelService.sfPayBankPay(payInfo);
			logger.info("银行卡支付响应参数:{}", resp.toString());
			return resp;
		} catch (ServiceException e) {
			logger.error("银行卡支付异常 req:" + req.toString(), e);
			return new SfBankPayResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("银行卡支付异常req:" + req.toString(), e);
			return new SfBankPayResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public SfPayRefundResp sfPayRefund(SfPayRefundReq req) {
		logger.info("顺手付退款请求参数:{}", req.toString());
		UpcBaseResp resp = checkReqParam(req, "mchNo", "channelCode", "formerUppOrderNo", "uppRefundNo", "mchRefundNo");
		if (resp != null) {
			return new SfPayRefundResp(resp.getRltCode(), resp.getRltMsg());
		}

		try {
			if (req.getRefundFee() != null && req.getRefundFee().longValue() <= 0) {
				throw new ServiceException(UpcConstants.INVALID_REFUND_AMOUNT, "退款金额无效");
			}

			// 验证商户退款流水
			SfPayRefundResp refundValidResp = validateMchRefundWater(req.getMchNo(), req.getChannelCode(), req.getUppRefundNo());
			if(refundValidResp != null)
				return refundValidResp;
			
			// 1.查询本地流水状态
			UpcPayInfo formerPayInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getFormerUppOrderNo());
			if (formerPayInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}

			// 只有支付成功的才可以退款
			if (!UpcConstants.SUCCESS.equals(formerPayInfo.getStatus())) {
				return new SfPayRefundResp(UpcConstants.ONLY_SUCC_ORDER_CAN_REFUND, "只有交易成功才可以退款");
			}

			if (req.getRefundFee() != null) {
				if (req.getRefundFee().longValue() > formerPayInfo.getTradeAmt().longValue()) {
					return new SfPayRefundResp(UpcConstants.REFUND_AMOUNT_GT_TRADE_AMOUNT, "退款金额大于支付总金额");
				}
			}

			// 2.查询已退款的流水记录
			UpcRefundQueryReq refundQueryReq = new UpcRefundQueryReq();
			refundQueryReq.setMchNo(req.getMchNo());
			refundQueryReq.setOldPayNo(formerPayInfo.getPayNo());
			List<UpcPayInfo> refundPayInfoList = payManageInfoService.queryRefundPayInfo(refundQueryReq);

			// 3. 校验已退款金额
			if (refundPayInfoList != null && !refundPayInfoList.isEmpty()) {
				long totalPayAmount = formerPayInfo.getTradeAmt().longValue();
				long haveRefundAmount = 0; // 已退款金额
				for (UpcPayInfo p : refundPayInfoList) {
					haveRefundAmount += p.getTradeAmt().longValue();
				}
				if (req.getRefundFee().longValue() + haveRefundAmount > totalPayAmount) {
					logger.error("已退款金额大于支付总金额 总金额:[{}], 已退款:[{}] ", totalPayAmount, haveRefundAmount);
					return new SfPayRefundResp(UpcConstants.REFUND_AMOUNT_GT_TRADE_AMOUNT, "已退款金额大于支付总金额");
				}
			}

			// 3. 生成退款流水
			UpcPayInfo refundPayInfo = buildRefundPayInfo(req, formerPayInfo, null);
			payManageInfoService.createPayInfo(refundPayInfo);
			logger.info("结束生成支付流水:payNo:[{}]...", refundPayInfo.getPayNo());
			// 4. 调用顺手付退款
			SfPayRefundResp refundResp = sfPayBaseChannelService.sfPayRefund(refundPayInfo);
			// 5.退款处理
			logger.info("顺手付退款响应结果:[{}]", refundResp.toString());
			return refundResp;

		} catch (ServiceException e) {
			logger.error("顺手付退款异常 req:" + req.toString(), e);
			return new SfPayRefundResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("顺手付退款异常 req:" + req.toString(), e);
			return new SfPayRefundResp(e.getCode(), e.getMsg());
		}
	}

	@Override
	public SfPayCloseOrderResp closeSfPayOrder(SfPayCloseOrderReq req) {
		logger.info("顺手付关单请求参数:{}", req.toString());
		try {
			UpcPayInfo payInfo = getUpcPayInfo(req.getMchNo(), req.getChannelCode(), req.getUppOrderNo());
			if (payInfo == null) {
				throw new ServiceException(UpcConstants.ORDER_NOT_EXISTS, "订单不存在");
			}

			if (TradeStatus.CLOSE.name().equals(payInfo.getStatus())) {
				return new SfPayCloseOrderResp(UpcConstants.SUCCESS, null);
			}
			
			TradeStatus orginalStatus = TradeStatus.INIT;
			// 验证状态
			if (ChannelTradeType.SFPAY_APP.name().equals(req.getChannelCode())) {
				if (!TradeStatus.TRADING.name().equals(payInfo.getStatus())) {
					throw new ServiceException(UpcConstants.ORDER_STATUS_ILLEGAL, "订单状态不合法");
				}
				orginalStatus = TradeStatus.TRADING;
			} else if (!TradeStatus.INIT.name().equals(payInfo.getStatus())) {
				throw new ServiceException(UpcConstants.ORDER_STATUS_ILLEGAL, "订单状态不合法");
			}

			// 非空校验
			ISFPayChannelService sfPayChannelService = PayChannelFactory.getSfPayTradeChannel(req.getChannelCode());
			if (sfPayChannelService == null) {
				throw new ServiceException(UpcConstants.INVALID_CHANNEL_CODE, "渠道编码不合法，渠道编码：" + req.getChannelCode());
			}

			sfPayChannelService.closeSfPayOrder(payInfo, orginalStatus);
			SfPayCloseOrderResp resp = new SfPayCloseOrderResp(UpcConstants.SUCCESS, null);
			logger.info("顺手付关单响应参数:{}", resp.toString());
			return resp;
		} catch (ServiceException e) {
			logger.error("顺手付关单异常 req:" + req.toString(), e);
			return new SfPayCloseOrderResp(e.getCode(), e.getMsg());
		} catch (UPCServiceException e) {
			logger.error("顺手付关单异常req:" + req.toString(), e);
			return new SfPayCloseOrderResp(e.getCode(), e.getMsg());
		}
	}

}
