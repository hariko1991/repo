package com.sfpay.pay.channel.alipay;

import java.text.MessageFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alipay.api.AlipayResponse;
import com.alipay.api.response.AlipayTradePayResponse;
import com.alipay.api.response.AlipayTradeQueryResponse;
import com.alipay.api.response.AlipayTradeRefundResponse;
import com.sfpay.alipay.constant.AlipayConstants;
import com.sfpay.alipay.domain.AlipayTradeCloseResponse;
import com.sfpay.alipay.domain.CreateBCOrderReq;
import com.sfpay.alipay.domain.OrderQueryReq;
import com.sfpay.alipay.domain.RefundReq;
import com.sfpay.alipay.enums.AlipayErrorCode;
import com.sfpay.alipay.function.AlipayCloseOrder;
import com.sfpay.alipay.function.AlipayCreateBCOrder;
import com.sfpay.alipay.function.AlipayQuery;
import com.sfpay.alipay.function.AlipayRefund;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework2.core.util.DateUtil;
import com.sfpay.pay.dao.UpcPayInfoDao;
import com.sfpay.pay.domain.HandleAlipayUnknownStatusResp;
import com.sfpay.pay.domain.HandleChannelBaseResp;
import com.sfpay.pay.domain.UpcAlipayExt;
import com.sfpay.pay.service.impl.AlipayExtService;
import com.sfpay.pay.service.impl.UpcPayInfoManageService;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.alipay.AlipayCloseOrderReq;
import com.sfpay.upc.domain.alipay.AlipayCreateOrderReq;
import com.sfpay.upc.domain.alipay.AlipayCreateOrderResp;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.upc.UpcPayUnknownParam;
import com.sfpay.upc.domain.wx.WXCreateOrderReq;
import com.sfpay.upc.enums.ChannelTradeType;
import com.sfpay.upc.enums.ChannelType;
import com.sfpay.upc.enums.CurrencyType;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.enums.TradeType;
import com.sfpay.upc.exception.UPCServiceException;
import com.sfpay.upc.service.IMqService;
import com.sfpay.wx.domain.CreateOrderReq;

/**
 * 
 * 类说明：<br>
 * 支付宝渠道基础服务
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-22
 */
@Service
public class AlipayBaseChannelService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private UpcPayInfoDao upcPayInfoDao;
	@Resource
	private AlipayExtService alipayExtService;
	@Resource
	private UpcPayInfoManageService payManageInfoService;
	@Resource
	private IMqService mqService;

	public AlipayCreateOrderResp createPayOrder(AlipayCreateOrderReq payReq, ChannelArgs channelArgs) throws UPCServiceException {
		logger.info("请求支付 AlipayBaseChannelService.createPayOrder 参数 ：req:{}", payReq.toString());
		long startTime = System.currentTimeMillis();
		// 非空校验
		validAlipayReqArgs(payReq);

		// 创建统一支付流水
		UpcPayInfo payInfo = buildUpcPayInfo(payReq, channelArgs);
		upcPayInfoDao.createPayInfo(payInfo);
		// 记录日志
		logger.info("创建upc_pay_info流水成功 payno:[{}] 商户订单号:[{}]", payInfo.getPayNo(), payReq.getMchOrderNo());
		// 组装返回数据
		AlipayCreateOrderResp resp = buildCreateOrderResp(payReq, payInfo, channelArgs);
		// 保存支付宝拓展数据
		saveAlipayExtData(payInfo, resp);

		logger.info("请求支付 AlipayBaseChannelService.createPayOrder 返回结果 ：resp:{}", resp.toString());

		logger.info("请求支付结束 共用时:[{}]秒", System.currentTimeMillis() - startTime);

		return resp;
	}

	/**
	 * 处理重复支付
	 * 
	 * @param existPayInfo
	 * @param channelArgs
	 * @return
	 * @throws UPCServiceException
	 */
	public HandleChannelBaseResp handleRepeatPay(UpcPayInfo existPayInfo, ChannelArgs channelArgs) throws UPCServiceException {
		HandleAlipayUnknownStatusResp handleResult = new HandleAlipayUnknownStatusResp();
		handleResult.setOrderExpire(isUpcPayInfoExpire(existPayInfo));
		return handleResult;
	}

	protected AlipayCreateOrderResp buildCreateOrderResp(AlipayCreateOrderReq payReq, UpcPayInfo payInfo, ChannelArgs channelArgs) {

		AlipayCreateOrderResp resp = buildAlipayCreateOrderResp(payReq, payInfo, channelArgs);

		resp.setRltCode(UpcConstants.SUCCESS);
		resp.setMchNo(payInfo.getMchNo());
		resp.setChannelCode(payInfo.getChannelCode());
		resp.setUpcTradeNo(payInfo.getPayNo());
		return resp;
	}

	protected AlipayCreateOrderResp buildAlipayCreateOrderResp(AlipayCreateOrderReq payReq, UpcPayInfo payInfo, ChannelArgs channelArgs) {
		return null;
	}

	// 校验支付宝参数
	protected void validAlipayReqArgs(AlipayCreateOrderReq payReq) {

	}

	protected void saveAlipayExtData(UpcPayInfo payInfo, AlipayCreateOrderResp resp) throws UPCServiceException {
		UpcAlipayExt alipayext = new UpcAlipayExt();
		alipayext.setMchOrderNo(payInfo.getMchOrderNo());
		alipayext.setPayNo(payInfo.getPayNo());
		alipayext.setReqAlipaySn(payInfo.getReqOrderNo());
		alipayext.setPayMessage(resp.getAlipayPayStr());
		alipayExtService.saveUpcAlipayExt(alipayext);
	}

	public AlipayTradeCloseResponse closeOrder(AlipayCloseOrderReq req, ChannelArgs channelArgs) {
		return AlipayCloseOrder.sendCloseOrderReq(req.getChannelCode(), req.getMchOrderNo(), channelArgs);
	}

	public AlipayTradeRefundResponse refund(UpcPayInfo formerPayInfo, UpcPayInfo refundPayInfo, ChannelArgs channelArgs) {
		RefundReq alipayRefundReq = new RefundReq();
		alipayRefundReq.setChannelCode(formerPayInfo.getChannelCode());
		alipayRefundReq.setOutTradeNo(formerPayInfo.getMchOrderNo());
		alipayRefundReq.setOutRefundNo(refundPayInfo.getMchOrderNo());
		alipayRefundReq.setRefundFee(refundPayInfo.getTradeAmt());
		AlipayTradeRefundResponse response = AlipayRefund.doRefund(alipayRefundReq, channelArgs);

		return response;
	}

	/**
	 * 处理交易流水未知未知
	 * 
	 * @param existPayInfo
	 * @param channelArgs
	 * @throws UPCServiceException
	 */
	public HandleAlipayUnknownStatusResp handleTradeUnknown(UpcPayInfo existPayInfo, ChannelArgs channelArgs) throws UPCServiceException {
		OrderQueryReq req = new OrderQueryReq();
		req.setChannelCode(existPayInfo.getChannelCode());
		req.setOutTradeNo(existPayInfo.getReqOrderNo());
		AlipayTradeQueryResponse response = AlipayQuery.doQuery(req, channelArgs);
		logger.info("调度查询支付宝响应数据:{}", response == null ? null : response.getBody());

		if (response == null) {
			return null;
		}

		String tradeStatus = TradeStatus.TRADING.name();
		HandleAlipayUnknownStatusResp handleResult = new HandleAlipayUnknownStatusResp();

		if (AlipayErrorCode.TRADE_NOT_EXIST.getCode().equals(response.getSubCode())) {
			// 订单不存在
			tradeStatus = TradeStatus.NOT_EXISTS.name();
		} else if (querySuccess(response)) {
			// 查询返回该订单交易支付成功
			tradeStatus = TradeStatus.SUCCESS.name();

		} else if (tradeClose(response)) {
			// 交易关闭
			tradeStatus = TradeStatus.CLOSE.name();

		} else if (tradeWaitToPay(response)) {
			// 查询发生异常，交易状态未知
			tradeStatus = TradeStatus.NOT_PAY.name();
		} else if (AlipayErrorCode.UNKNOW_ERROR.getCode().equals(response.getSubCode())) {
			// 其他情况均表明该订单号交易失败
			tradeStatus = TradeStatus.UNKNOW.name();
		} else {
			// 其他情况均表明该订单号交易失败
			tradeStatus = TradeStatus.FAILURE.name();
		}

		handleResult.setRltCode(response.getSubCode());
		handleResult.setRltMsg(response.getSubMsg());
		handleResult.setTradeStatus(tradeStatus);
		handleResult.setOrderExpire(isUpcPayInfoExpire(existPayInfo));
		handleResult.setAlipayOrderNo(response.getTradeNo());
		handleResult.setBuyerId(response.getBuyerUserId());
		handleResult.setBuyerAccount(response.getBuyerLogonId());
		return handleResult;

	}

	// 查询返回“支付成功”
	protected static boolean querySuccess(AlipayTradeQueryResponse response) {
		return AlipayConstants.SUCCESS.equals(response.getCode())
				&& ("TRADE_SUCCESS".equals(response.getTradeStatus()) || "TRADE_FINISHED".equals(response.getTradeStatus()));
	}

	// 交易异常，或发生系统错误
	protected static boolean tradeError(AlipayResponse response) {
		return AlipayConstants.ERROR.equals(response.getCode());
	}

	// 交易关闭
	protected static boolean tradeClose(AlipayTradeQueryResponse response) {
		return AlipayConstants.SUCCESS.equals(response.getCode()) && ("TRADE_CLOSED".equals(response.getTradeStatus()));
	}

	// 交易未支付
	protected static boolean tradeWaitToPay(AlipayTradeQueryResponse response) {
		return AlipayConstants.SUCCESS.equals(response.getCode()) && "WAIT_BUYER_PAY".equals(response.getTradeStatus());
	}

	public boolean isUpcPayInfoExpire(UpcPayInfo existPayInfo) throws UPCServiceException {
		Date tradeBeginTime = existPayInfo.getBeginTime();
		long configureExpireTime = Long.valueOf(Property.getProperty("ALIPAY_ORDER_EXPIRE_TIME"));
		int intervalTime = payManageInfoService.getDBInterval(DateUtil.format(tradeBeginTime, DateUtil.YYYY_MM_DD_HH_MM_SS));
		logger.info("生成订单时间：[{}], 配置过期分钟:[{}], 日期间隔:[{}]", new Object[] { tradeBeginTime.getTime(), configureExpireTime, intervalTime });

		return intervalTime > configureExpireTime;
	}

	/**
	 * 计算订单过期时间
	 * 
	 * @param mchInputTime
	 * @return
	 */
	public String calculateExpireTime(String mchInputTime) {
		// 分钟
		String defaultExpireTime = Property.getProperty("ALIPAY_ORDER_EXPIRE_TIME");
		if (StringUtils.isEmpty(mchInputTime)) {
			return defaultExpireTime;
		}

		SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
		try {
			Date inputTime = format.parse(mchInputTime);
			long expireTime = (inputTime.getTime() - new Date().getTime()) / (1000 * 60);
			return String.valueOf(expireTime) + "m";
		} catch (Exception e) {
			return defaultExpireTime;
		}
	}

	/**
	 * 组装支付流水
	 * 
	 * @param payReq
	 * @param channelArgs
	 * @return
	 */
	protected UpcPayInfo buildUpcPayInfo(AlipayCreateOrderReq payReq, ChannelArgs channelArgs) {
		UpcPayInfo payInfo = new UpcPayInfo();
		payInfo.setPayNo(upcPayInfoDao.getPayNo());
		payInfo.setChannelCategoryCode(ChannelType.ALIPAY.name());
		payInfo.setChannelCode(payReq.getChannelCode());
		payInfo.setMchNo(payReq.getMchNo());
		payInfo.setChannelMchNo(channelArgs.getValueByKey("mch_id"));
		payInfo.setMchOrderNo(payReq.getMchOrderNo());
		payInfo.setUseMchnoReq(payReq.isUseMchOrderNo() ? "Y" : "N");

		payInfo.setReqOrderNo(payReq.isUseMchOrderNo() ? payReq.getMchOrderNo() : payInfo.getPayNo());
		payInfo.setTradeType(TradeType.PAY.name());
		payInfo.setTradeFee(0L);
		payInfo.setTradeAmt(payReq.getTradeAmount());
		payInfo.setSystemSource(payReq.getSystemSource());
		payInfo.setCcy(CurrencyType.RMB.name());
		payInfo.setStatus(TradeStatus.TRADING.name());
		payInfo.setProductName(payReq.getProductName());
		payInfo.setProductDesc(payReq.getProductDesc());
		payInfo.setProductUrl(payReq.getProductUrl());
		payInfo.setCallbackSfUrl(payReq.getCallbackUrl());
		payInfo.setUppOrderNo(payReq.getUppOrderNo());
		// 设置通知地址
		String notifyUrl = String.format("%s/upc/{0}/notify", Property.getProperty("OUT_SYF_UPC_URI"));
		payInfo.setMchNotifyUrl(new MessageFormat(notifyUrl).format(new Object[] { payInfo.getPayNo() }));
		payInfo.setRemark(payReq.getRemark());

		return payInfo;
	}

	/**
	 * 组装下单请求数据
	 * 
	 * @param tradeType
	 * @param payReq
	 * @param payInfo
	 * @return
	 */
	protected CreateOrderReq buildCreateOrderReq(String tradeType, WXCreateOrderReq payReq, UpcPayInfo payInfo) {
		CreateOrderReq req = new CreateOrderReq();
		req.setBody(payReq.getProductName());
		req.setDetail(payReq.getProductDesc());
		req.setChannelNo(payReq.getChannelCode());
		req.setNotifyUrl(payInfo.getMchNotifyUrl());
		req.setOpenid(payReq.getOpenid());
		req.setOutTradeNo(payInfo.getReqOrderNo());
		req.setSpbillCreateIp(payReq.getRequestIp());
		req.setTotalFee(payReq.getTradeAmount().intValue());
		req.setTradeType(tradeType);
		req.setDeviceInfo(payReq.getTerminalNo());
		req.setLimitPay(payReq.getLimitPay());

		req.setAttach(payReq.getRemark());
		return req;
	}

	/**
	 * 返回支付报文
	 * 
	 * @param req
	 * @param existPayInfo
	 * @return
	 * @throws UPCServiceException
	 */
	public AlipayCreateOrderResp returnPayData(UpcPayInfo existPayInfo) throws UPCServiceException {

		String alipayPayStr = null;
		if (ChannelTradeType.ALIPAY_QR.name().equals(existPayInfo.getChannelCode())) {
			alipayPayStr = existPayInfo.getQrCode();
		} else {
			UpcAlipayExt alipayExt = alipayExtService.getAlipayExtByPayNo(existPayInfo.getPayNo());
			if (alipayExt == null) {
				logger.error("没有查到支付宝拓展数据: payNo:[{}]", existPayInfo.getPayNo());
				throw new ServiceException(UpcConstants.FAILURE_SYS);
			}
			alipayPayStr = alipayExt.getPayMessage();
		}
		AlipayCreateOrderResp resp = new AlipayCreateOrderResp();
		resp.setAlipayPayStr(alipayPayStr);
		resp.setChannelCode(existPayInfo.getChannelCode());
		resp.setMchNo(existPayInfo.getMchNo());
		resp.setRltCode(UpcConstants.SUCCESS);
		return resp;
	}

	/**
	 * 扫码支付下单(支付宝条码支付)
	 * 
	 * @param req
	 * @param isOrderExpire
	 * @param existPayInfo
	 * @param channelArgs
	 * @return
	 * @throws UPCServiceException
	 */

	public AlipayCreateOrderResp createBCOrder(AlipayCreateOrderReq req, ChannelArgs channelArgs) throws UPCServiceException {
		logger.info("请求支付 AlipayBaseChannelService.createQRPayOrder 参数 ：req:{}", req.toString());
		long startTime = System.currentTimeMillis();
		// 非空校验
		validAlipayReqArgs(req);

		// 创建统一支付流水
		UpcPayInfo payInfo = buildUpcPayInfo(req, channelArgs);
		upcPayInfoDao.createPayInfo(payInfo);
		// 记录日志
		logger.info("创建upc_pay_info流水成功 payno:[{}] 商户订单号:[{}]", payInfo.getPayNo(), req.getMchOrderNo());

		// 去支付宝下单支付.
		// 从req复制给CreateQRPayOrderReq.(默认条码支付)
		CreateBCOrderReq cqor = new CreateBCOrderReq();
		cqor.setAuthCode(req.getAuthCode());
		cqor.setOutTradeNo(req.getMchOrderNo());
		cqor.setTotalAmount(req.getTradeAmount());
		cqor.setSubject(req.getProductName());

		cqor.setExpireTime(req.getExpireTime() == null ? "" : DateUtil.format(req.getExpireTime()));
		cqor.setNotifyUrl(payInfo.getMchNotifyUrl());

		AlipayTradePayResponse atp = AlipayCreateBCOrder.doCreateAndPay(cqor, channelArgs);
		logger.info("支付宝扫码支付请求的结果是:" + atp == null ? "" : atp.getBody());

		// 记录异常信息

		if (!AlipayConstants.SUCCESS.equals(atp.getCode())) {
			recordAlipayError(payInfo.getPayNo(), atp);
		}
		// 支付宝支付成功后组装返回数据
		AlipayCreateOrderResp resp = buildAlipayCreateQRPayOrderResp(req, atp, channelArgs);

		// 更新UPC
		updateUPC(payInfo, atp);

		// 处理中不用通知给UPP
		if (resp.getRltCode().equals(UpcConstants.SUCCESS) || resp.getRltCode().equals(UpcConstants.ORDER_IS_FAIL)) {
			// 通知给UPP
			notifyUPP(payInfo, atp);
		}

		// 保存支付宝拓展数据
		saveAlipayExtData(payInfo, resp);

		resp.setAlipayPayStr(atp.getBody());

		logger.info("请求支付 AlipayBaseChannelService.createPayOrder 返回结果 ：resp:{}", resp.toString());

		logger.info("请求支付结束 共用时:[{}]秒", System.currentTimeMillis() - startTime);

		return resp;

	}

	private AlipayCreateOrderResp buildAlipayCreateQRPayOrderResp(AlipayCreateOrderReq payReq, AlipayTradePayResponse alipayResponse,
			ChannelArgs channelArgs) {
		AlipayCreateOrderResp resp = new AlipayCreateOrderResp();
		
		//将错误码直接返回出去，不做处理。
		tranfAliCodeToUppCode(alipayResponse,resp);

		// 转换状态信息.
		resp.setMchNo(payReq.getMchNo());
		resp.setChannelCode(payReq.getChannelCode());
		return resp;
	}

	/**
	 * 更新UPC的的状态.
	 * 
	 * @param payInfo
	 * @param alipayResponse
	 */

	public void updateUPC(UpcPayInfo payInfo, AlipayTradePayResponse alipayResponse) {
		UpcPayUnknownParam upcParam = new UpcPayUnknownParam();
		upcParam.setMchNo(payInfo.getMchNo());
		upcParam.setPayNo(payInfo.getPayNo());
		upcParam.setRtnOrderNo(alipayResponse.getTradeNo());
		upcParam.setOriginalStatus(TradeStatus.TRADING.name());
		upcParam.setTargetStatus(tranfUPCToDbStatus(tranfAliCodeToUppCode(alipayResponse)));
		// 更新支付流水
		try {
			payManageInfoService.updateUpcPayUnknown(upcParam);
		} catch (UPCServiceException e) {
			logger.error("更新支付流水异常", e);
		}
	}

	/**
	 * 更新UPP,并发送MQ消息出去.
	 * 
	 * @param payInfo
	 * @param alipayResponse
	 */

	public void notifyUPP(UpcPayInfo payInfo, AlipayTradePayResponse alipayResponse) {
		Map<String, String> mapMsg = new HashMap<String, String>();
		mapMsg.put("tradeType", "PAYMENT");
		mapMsg.put("channelCode", payInfo.getChannelCode());
		mapMsg.put("mchNo", payInfo.getMchNo());
		mapMsg.put("uppChannelTradeNo", payInfo.getUppOrderNo());
		mapMsg.put("mchOrderNo", payInfo.getMchOrderNo());
		mapMsg.put("rtnOrderNo", alipayResponse.getTradeNo());
		mapMsg.put("tradeAmt", String.valueOf(payInfo.getTradeAmt()));

		mapMsg.put("tradeFee", String.valueOf(payInfo.getTradeFee() == null ? 0L : payInfo.getTradeFee()));
		mapMsg.put("ccy", payInfo.getCcy());
		mapMsg.put("status", tranfAliCodeToUppCode(alipayResponse));
		mapMsg.put("payBankType", "");
		mapMsg.put("beginTime", payInfo.getBeginTime() == null ? "" : DateUtil.format(payInfo.getBeginTime(), DateUtil.YYYY_MM_DD_HH_MM_SS));
		mapMsg.put("endTime", DateUtil.format(new Date(), DateUtil.YYYY_MM_DD_HH_MM_SS));
		mapMsg.put("errorCode", alipayResponse.getCode());
		mapMsg.put("errorMsg", alipayResponse.getMsg());

		logger.info("调度通知聚合支付mq 支付消息:[{}]", mapMsg.toString());
		boolean newVersion = false;
		if (StringUtils.isNotEmpty(payInfo.getUppOrderNo())) {
			newVersion = true;
		}
		mqService.sendMsg(newVersion, mapMsg);

		// 更新通知状态
		try {
			payManageInfoService.updateNotifyFlag(payInfo.getPayNo(), "Y");
		} catch (UPCServiceException e) {
			logger.error("后台调度支付宝支付状态查询接口，订单号:+" + payInfo.getMchOrderNo() + "+处理支付流水异常", e);
		}
	}

	/**
	 * 将支付宝的返回码转换成统一收银台的码.
	 * 
	 * @return
	 */

	private String tranfAliCodeToUppCode(AlipayTradePayResponse alipayResponse) {
		// 10000:表示业务处理成功,40004:表示业务处理失败,10003:表示业务处理中,20000:业务出现未知问题或是系统异常.
		String flag = "";

		if (null != alipayResponse) {
			String aliCode = alipayResponse.getCode();

			if ("10000".equals(aliCode)) {
				flag = UpcConstants.SUCCESS;

			} else if ("10003".equals(aliCode)) {
				flag = UpcConstants.ORDER_IS_PAYING;

			} else if ("40004".equals(aliCode)) {
				flag = UpcConstants.ORDER_IS_FAIL;
				
			} else {
				flag = UpcConstants.FAILURE_SYS;
			}

		} else {
			return UpcConstants.FAILURE_SYS;
		}

		return flag;
	}
	
	/**
	 * 将支付宝的返回码转换成统一收银台的码.
	 * 
	 * @return
	 */

	private void tranfAliCodeToUppCode(AlipayTradePayResponse alipayResponse,AlipayCreateOrderResp resp) {
		// 10000:表示业务处理成功,40004:表示业务处理失败,10003:表示业务处理中,20000:业务出现未知问题或是系统异常.
		String flag = "";

		if (null != alipayResponse) {
			String aliCode = alipayResponse.getCode();

			if ("10000".equals(aliCode)) {
				flag = UpcConstants.SUCCESS;

			} else if ("10003".equals(aliCode)) {
				flag = UpcConstants.ORDER_IS_PAYING;

			} else if ("40004".equals(aliCode)) {
				flag = UpcConstants.ORDER_IS_FAIL;
			} else {
				flag = UpcConstants.FAILURE_SYS;
			}

		} else {
			flag = UpcConstants.FAILURE_SYS;
			
		}

		resp.setRltCode(flag);
		resp.setSubRltCode(alipayResponse.getSubCode());
		resp.setSubRltMsg(alipayResponse.getSubMsg());
	}

	private String tranfAliBySubCode(String subCode)
	{
		StringBuffer flag = new StringBuffer();
		if(StringUtils.isNotBlank(subCode))
		{
			String temp = subCode.substring(subCode.indexOf(".") +1 ,subCode.length());
			flag.append("Alipay.").append(temp);
		}
		
		
		return flag.toString();
	}
	
	/**
	 * 把UPC的状态转换成数据库的状态
	 * 
	 * @param status
	 * @return
	 */

	private String tranfUPCToDbStatus(String status) {
		String flag = "";

		if (null != status) {
			if (UpcConstants.SUCCESS.equals(status)) {
				flag = TradeStatus.SUCCESS.name();

			} else if (UpcConstants.ORDER_IS_FAIL.equals(status)) {
				flag = TradeStatus.FAILURE.name();
			}
		}

		return flag;
	}

	protected void recordAlipayError(String payNo, AlipayResponse alipayResp) {

		String alipayErrorCode = StringUtils.isNotEmpty(alipayResp.getSubCode()) ? alipayResp.getSubCode() : alipayResp.getCode();
		String alipayErrorMsg = StringUtils.isNotEmpty(alipayResp.getSubMsg()) ? alipayResp.getSubMsg() : alipayResp.getMsg();
		// 记录错误
		payManageInfoService.asyncRecordError(payNo, alipayErrorCode, alipayErrorMsg);
	}
	
}
