package com.sfpay.pay.channel.alipay;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alipay.api.response.AlipayTradePrecreateResponse;
import com.sfpay.alipay.constant.AlipayConstants;
import com.sfpay.alipay.domain.CreateOrderReq;
import com.sfpay.alipay.enums.AlipayErrorCode;
import com.sfpay.alipay.function.AlipayCreateOrder;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.pay.channel.IAlipayChannelService;
import com.sfpay.pay.dao.UpcPayInfoDao;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.alipay.AlipayCreateOrderReq;
import com.sfpay.upc.domain.alipay.AlipayCreateOrderResp;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.exception.UPCServiceException;

/**
 * 
 * 类说明：<br>
 * 创建支付宝扫码付订单
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-22
 */
@Service
public class AlipayQRChannelService extends AlipayBaseChannelService implements IAlipayChannelService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	@Resource
	private UpcPayInfoDao upcPayInfoDao;

	@Override
	public AlipayCreateOrderResp createPayOrder(AlipayCreateOrderReq payReq, ChannelArgs channelArgs) throws UPCServiceException {
		logger.info("扫码付请求支付 AlipayQRChannelService.createPayOrder 参数 ：req:{}", payReq.toString());
		long startTime = System.currentTimeMillis();

		// 不存在创建统一支付流水 否则使用原流水下单

		UpcPayInfo payInfo = buildUpcPayInfo(payReq, channelArgs);
		upcPayInfoDao.createPayInfo(payInfo);
		// 记录日志
		logger.info("创建upc_pay_info流水成功 payno:[{}] 商户订单号:[{}]", payInfo.getPayNo(), payReq.getMchOrderNo());

		// 下单到支付宝
		CreateOrderReq alipayReq = new CreateOrderReq();
		alipayReq.setNotifyUrl(payInfo.getMchNotifyUrl());
		alipayReq.setChannelCode(payReq.getChannelCode());
		alipayReq.setOutTradeNo(payInfo.getReqOrderNo());
		alipayReq.setTotalAmount(payInfo.getTradeAmt());
		alipayReq.setSubject(payInfo.getProductName());
		AlipayTradePrecreateResponse alipayResponse = AlipayCreateOrder.doCreate(alipayReq, channelArgs);
		logger.info(alipayResponse == null ? "生成支付宝扫码二维码异常" : "生成支付宝扫码二维码响应数据:[{}]" + alipayResponse.getBody());
		if (alipayResponse == null) {
			throw new ServiceException(UpcConstants.FAILURE_SYS, "系统异常");
		}

		// 异常

		if (!AlipayConstants.SUCCESS.equals(alipayResponse.getCode()) || StringUtils.isEmpty(alipayResponse.getQrCode())) {

			// record error
			recordAlipayError(payInfo.getPayNo(), alipayResponse);
			AlipayErrorCode result = null;
			try {
				String subCode = alipayResponse.getSubCode();
				subCode = subCode.startsWith("ACQ.") ? subCode.substring(4) : subCode;
				result = AlipayErrorCode.valueOf(subCode);
			} catch (Exception e) {
				throw new ServiceException(UpcConstants.FAILURE_SYS, "系统异常");
			}

			if (result != null) {
				throw new ServiceException(result.getUpcCode(), result.getMsg());
			}
		}

		// 更新二维码信息到upc
		upcPayInfoDao.updateQrcodeToUpc(payInfo.getPayNo(), alipayResponse.getQrCode());
		// 组装返回数据
		AlipayCreateOrderResp resp = buildAlipayCreateOrderResp(payReq, alipayResponse, channelArgs);
		// 保存支付宝拓展数据
		saveAlipayExtData(payInfo, resp);
		logger.info("请求支付 AlipayQRChannelService.createPayOrder 返回结果 ：resp:{}", resp.toString());

		logger.info("请求支付结束 共用时:[{}]秒", System.currentTimeMillis() - startTime);

		return resp;
	}

	private AlipayCreateOrderResp buildAlipayCreateOrderResp(AlipayCreateOrderReq payReq, AlipayTradePrecreateResponse alipayResponse,
			ChannelArgs channelArgs) {
		AlipayCreateOrderResp resp = new AlipayCreateOrderResp();
		resp.setRltCode(UpcConstants.SUCCESS);
		resp.setMchNo(payReq.getMchNo());
		resp.setChannelCode(payReq.getChannelCode());
		resp.setAlipayPayStr(alipayResponse.getQrCode());
		return resp;
	}

}
