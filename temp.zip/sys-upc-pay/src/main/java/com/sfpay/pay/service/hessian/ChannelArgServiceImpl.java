/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.pay.service.hessian;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.pay.cache.UpcChannelContainer;
import com.sfpay.pay.dao.ChannelArgDao;
import com.sfpay.pay.dao.UpcMerchantMapDao;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.UpcChannelArg;
import com.sfpay.upc.domain.upc.UpcMerchantMap;
import com.sfpay.upc.service.IChannelArgService;

/**
 * 
 * 类说明：<br>
 * 渠道参数服务
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-27
 */
@Service("channelArgService")
@HessianExporter("/upc/channelArgService")
public class ChannelArgServiceImpl implements IChannelArgService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private ChannelArgDao dao;
	@Resource
	private UpcMerchantMapDao mchDao;

	@Override
	public ChannelArgs getChannelArgs(String channelCode, String mchNo) throws ServiceException {
		if (StringUtils.isEmpty(channelCode) || StringUtils.isEmpty(mchNo)) {
			throw new ServiceException(UpcConstants.PARAM_NULL, "参数不能为空");
		}

		UpcMerchantMap merchantMap = UpcChannelContainer.getMerchantMap(mchNo, channelCode);
		if (merchantMap == null) {
			if (channelCode.contains("_")) {
				channelCode = channelCode.split("_")[0];
			}
			merchantMap = mchDao.queryMerchantMap(mchNo, channelCode);
		}
		ChannelArgs channelArgs = UpcChannelContainer.getChannelArgs(merchantMap.getMchNo(),
				merchantMap.getChannelMchParamKey());
		
		if (channelArgs != null) {
			return channelArgs;
		}

		return getChannelArgsForInit(merchantMap.getChannelCode(), merchantMap.getChannelMchParamKey(), mchNo);
	}

	@Override
	public ChannelArgs getChannelArgsForInit(String channelCode, String channelMchParamKey, String mchNo) {
		List<UpcChannelArg> ls = null;
		try {
			ls = dao.queryArgsByChannelCodeAndMchNo(channelMchParamKey,mchNo);
		} catch (Exception e) {
			logger.error(String.format("查询[%s]对应的银行配置参数异常", channelMchParamKey), e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "查询异常");
		}
		Map<String, String> map = new HashMap<String, String>();
		for (UpcChannelArg bca : ls) {
			map.put(bca.getArgKey(), bca.getArgValue());
		}
		ChannelArgs arg = new ChannelArgs(map);
		arg.setChannelCode(channelCode);
		return arg;
	}

	/**
	 * 添加记录
	 * @param upcChannelArg
	 */
	public void saveChannelArgs(UpcChannelArg upcChannelArg) {

		if (upcChannelArg == null || StringUtils.isEmpty(upcChannelArg.getArgKey())
				|| StringUtils.isEmpty(upcChannelArg.getArgValue())
				|| StringUtils.isEmpty(upcChannelArg.getChannelCode()) || StringUtils.isEmpty(upcChannelArg.getMchNo())
				|| StringUtils.isEmpty(upcChannelArg.getChannelMchParamKey())) {
			throw new ServiceException(UpcConstants.PARAM_NULL, "必要参数为空");
		}
		try {
			dao.addUpcChannelArg(upcChannelArg);
		} catch (Exception e) {
			logger.error(String.format("添加[%s]对应的参数异常", upcChannelArg.getMchNo()), e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "查询异常");
		}
	}

	/**
	 * 修改信息
	 * @param upcChannelArg
	 */
	public void updateChannelArgs(UpcChannelArg upcChannelArg) {

		if (upcChannelArg == null || StringUtils.isEmpty(upcChannelArg.getMchNo())) {
			throw new ServiceException(UpcConstants.PARAM_NULL, "必要参数为空");
		}
		try {
			dao.updateUpcChannelArg(upcChannelArg);
		} catch (Exception e) {
			logger.error(String.format("修改[%s]对应的参数异常", upcChannelArg.getMchNo()), e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "查询异常");
		}
	}

}
