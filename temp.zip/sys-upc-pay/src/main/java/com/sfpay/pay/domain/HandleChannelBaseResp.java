package com.sfpay.pay.domain;

import com.sfpay.sypay.common.BaseEntity;

public class HandleChannelBaseResp extends BaseEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// 错误编码
	private String rltCode;
	// 错误信息
	private String rltMsg;
	// 顺手付网关单号
	private String gatewayNo;
	// 顺手付支付单号
	private String sfBusinessNo;
	// 交易状态
	private String tradeStatus;
	// 渠道状态
	private String channelStatus;
	// 订单是否过期
	private boolean isOrderExpire;

	public String getRltCode() {
		return rltCode;
	}

	public void setRltCode(String rltCode) {
		this.rltCode = rltCode;
	}

	public String getRltMsg() {
		return rltMsg;
	}

	public void setRltMsg(String rltMsg) {
		this.rltMsg = rltMsg;
	}

	public String getTradeStatus() {
		return tradeStatus;
	}

	public void setTradeStatus(String tradeStatus) {
		this.tradeStatus = tradeStatus;
	}

	public String getGatewayNo() {
		return gatewayNo;
	}

	public void setGatewayNo(String gatewayNo) {
		this.gatewayNo = gatewayNo;
	}

	public String getSfBusinessNo() {
		return sfBusinessNo;
	}

	public void setSfBusinessNo(String sfBusinessNo) {
		this.sfBusinessNo = sfBusinessNo;
	}

	public boolean isOrderExpire() {
		return isOrderExpire;
	}

	public void setOrderExpire(boolean isOrderExpire) {
		this.isOrderExpire = isOrderExpire;
	}

	public String getChannelStatus() {
		return channelStatus;
	}

	public void setChannelStatus(String channelStatus) {
		this.channelStatus = channelStatus;
	}

}
