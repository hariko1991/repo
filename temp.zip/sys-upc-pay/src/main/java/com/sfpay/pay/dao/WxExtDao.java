package com.sfpay.pay.dao;

import org.apache.ibatis.annotations.Param;

import com.sfpay.pay.domain.UpcWxExt;

public interface WxExtDao {

	void saveUpcWxExt(UpcWxExt wxExt) throws Exception;

	UpcWxExt queryWxExt(@Param("payNo") String payNo);

	void updateOpenidToWxExt(@Param("payNo") String payNo, @Param("openid") String openid);

}
