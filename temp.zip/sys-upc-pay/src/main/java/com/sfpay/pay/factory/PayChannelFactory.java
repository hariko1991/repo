package com.sfpay.pay.factory;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


import com.sfpay.pay.channel.IAlipayChannelService;
import com.sfpay.pay.channel.IBaseChannelService;
import com.sfpay.pay.channel.ISFPayChannelService;
import com.sfpay.pay.channel.IWXChannelService;

/**
 * 
 * 类说明：<br>
 * 支付渠道工厂
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-5
 */
public class PayChannelFactory {

	private static Logger logger = LoggerFactory.getLogger(PayChannelFactory.class);
	// 微信支付渠道map
	public static Map<String, IWXChannelService> wechatChannelMap = new HashMap<String, IWXChannelService>();
	// 支付宝支付渠道
	public static Map<String, IAlipayChannelService> alipayChannelMap = new HashMap<String, IAlipayChannelService>();
	// 支付宝支付渠道
	public static Map<String, ISFPayChannelService> sfPayChannelMap = new HashMap<String, ISFPayChannelService>();

	public static IWXChannelService getWechatTradeChannel(String channelCode) {
		logger.debug("查询支付渠道channelCode:[{}]", channelCode);

		return wechatChannelMap.get(channelCode);
	}

	public static IAlipayChannelService getAlipayTradeChannel(String channelCode) {
		logger.debug("查询支付渠道channelCode:[{}]", channelCode);

		return alipayChannelMap.get(channelCode);
	}

	public static ISFPayChannelService getSfPayTradeChannel(String channelCode) {
		logger.debug("查询支付渠道channelCode:[{}]", channelCode);

		return sfPayChannelMap.get(channelCode);
	}

	public static IBaseChannelService getTradeChannel(String channelCode) {
		logger.debug("查询支付渠道channelCode:[{}]", channelCode);

		if (getWechatTradeChannel(channelCode) != null) {
			return getWechatTradeChannel(channelCode);
		} else if (getAlipayTradeChannel(channelCode) != null) {
			return getAlipayTradeChannel(channelCode);
		} else {
			return getSfPayTradeChannel(channelCode);
		}

	}

	public static void setWechatChannelMap(Map<String, IWXChannelService> wechatChannelMap) {
		PayChannelFactory.wechatChannelMap = wechatChannelMap;
	}

	public static void setAlipayChannelMap(Map<String, IAlipayChannelService> alipayChannelMap) {
		PayChannelFactory.alipayChannelMap = alipayChannelMap;
	}

	public static void setSfPayChannelMap(Map<String, ISFPayChannelService> sfPayChannelMap) {
		PayChannelFactory.sfPayChannelMap = sfPayChannelMap;
	}

}
