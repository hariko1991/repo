/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.front.util;

import java.io.BufferedOutputStream;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.nio.charset.Charset;
import java.util.Collection;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月16日
 */
public class SfpayFileUtils {
	public static final String LINE_SEPARATOR;
	static {
		// avoid security issues
		SfpayStringBuilderWriter buf = new SfpayStringBuilderWriter(4);
		PrintWriter out = new PrintWriter(buf);
		out.println();
		LINE_SEPARATOR = buf.toString();
		out.close();
	}

	public static SfpayLineIterator lineIterator(File file, String encoding) throws IOException {
		InputStream input = null;
		try {
			input = openInputStream(file);

			Charset charset = encoding == null ? Charset.defaultCharset() : Charset.forName(encoding);

			return new SfpayLineIterator(new InputStreamReader(input, charset));
		} catch (IOException ex) {
			closeQuietly(input);
			throw ex;
		} catch (RuntimeException ex) {
			closeQuietly(input);
			throw ex;
		}
	}

	public static FileInputStream openInputStream(File file) throws IOException {
		if (file.exists()) {
			if (file.isDirectory()) {
				throw new IOException("File '" + file + "' exists but is a directory");
			}
			if (file.canRead() == false) {
				throw new IOException("File '" + file + "' cannot be read");
			}
		} else {
			throw new FileNotFoundException("File '" + file + "' does not exist");
		}
		return new FileInputStream(file);
	}

	public static void writeLines(File file, String encoding, Collection<?> lines, boolean append) throws IOException {
		FileOutputStream out = null;
		try {
			out = openOutputStream(file, append);
			final BufferedOutputStream buffer = new BufferedOutputStream(out);

			Charset charset = encoding == null ? Charset.defaultCharset() : Charset.forName(encoding);

			writeLines(lines, null, buffer, charset);
			buffer.flush();
			out.close(); // don't swallow close Exception if copy completes
							// normally
		} finally {
			closeQuietly(out);
		}
	}

	public static FileOutputStream openOutputStream(File file, boolean append) throws IOException {
		if (file.exists()) {
			if (file.isDirectory()) {
				throw new IOException("File '" + file + "' exists but is a directory");
			}
			if (file.canWrite() == false) {
				throw new IOException("File '" + file + "' cannot be written to");
			}
		} else {
			File parent = file.getParentFile();
			if (parent != null) {
				if (!parent.mkdirs() && !parent.isDirectory()) {
					throw new IOException("Directory '" + parent + "' could not be created");
				}
			}
		}
		return new FileOutputStream(file, append);
	}

	public static void writeLines(Collection<?> lines, String lineEnding, OutputStream output, Charset charset)
			throws IOException {
		if (lines == null || lines.isEmpty()) {
			return;
		}
		if (lineEnding == null) {
			lineEnding = LINE_SEPARATOR;
		}

		for (Object line : lines) {
			if (line != null) {
				output.write(line.toString().getBytes(charset));
			}
			output.write(lineEnding.getBytes(charset));
		}
	}

	public static void closeQuietly(Closeable closeable) {
		try {
			if (closeable != null) {
				closeable.close();
			}
		} catch (IOException ioe) {
			// ignore
		}
	}

	public static void forceDelete(File file) throws IOException {
		boolean filePresent = file.exists();
		if (!file.delete()) {
			if (!filePresent) {
				throw new FileNotFoundException("File does not exist: " + file);
			}
			String message = "Unable to delete file: " + file;
			throw new IOException(message);
		}
	}
}
