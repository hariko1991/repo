package com.sfpay.front.cnst;

public final class LimitPayCnst {
	public static final String DEPOSIT_CARD = "DEPOSIT,DEBIT";
	public static final String CREDIT_CARD = "CREDIT";
}
