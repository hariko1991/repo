/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.front.cnst;

/**
 * 类说明：<br>
 * 日期常量类
 * 
 * <p>
 * 详细描述：<br>
 * 日期常量类用于将所有的日期常量都汇总在一起，减少重复代码量
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2015-11-6
 */
public class DateCnst {
    
    /**
     * 日期格式：年月日时分秒 yyyy-MM-dd HH:mm:ss
     */
    public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    
    /**
     * 日期格式：年月日时分秒（缩写）yyyyMMddHHmmss
     */
    public static final String YYYYMMDDHHMMSS = "yyyyMMddHHmmss";
    
    /**
     * 日期格式：年月日时分秒精确到毫秒yyyyMMddHHmmssSSS
     */
    public static final String YYYYMMDDHHMMSSSSS = "yyyyMMddHHmmssSSS";
    /**
     * 日期格式：年月日时分秒精确到毫秒yyyyMMddHHmmssSSSSSS
     */
    public static final String YYYYMMDDHHMMSSSSSSSS = "yyyyMMddHHmmssSSSSSS";
    
    /**
     * 日期格式：年月日时分秒精确到毫秒yyyyMMddHHmmssS
     */
    public static final String YYYYMMDDHHMMSSS = "yyyyMMddHHmmssS";
    
    /**
     * 日期格式：年月日 yyyyMMdd
     */
    public static final String YYYYMMDD = "yyyyMMdd";
    
    /**
     * 日期格式：年月日 yyMMdd
     */
    public static final String YYMMDD = "yyMMdd";
    
    /**
     * 日期格式：年月日yyyy-MM-dd
     */
    public static final String YYYY_MM_DD = "yyyy-MM-dd";
    
    /**
     * 日期格式：年月 yyyyMM
     */
    public static final String YYYYMM = "yyyyMM";
    
    /**
     * 日期格式：时分秒 HHmmss
     */
    public static final String HH24_MM_SS = "HHmmss";
    
    /**
     * 日期格式：时分秒 HHmmssSSSSSS
     */
    public static final String HH24_MM_SS_SSSSSS = "HHmmssSSSSSS";
    /**
     * 日期格式：时分秒 yyyy-MM-dd-HH.mm.ss.SSSSSS
     */
    public static final String YYYY_MM_DD_HH24_MM_SS_SSSSSS = "yyyy-MM-dd-HH.mm.ss.SSSSSS";
    
    /**
     * 日期格式：时分 HHmm
     */
    public static final String HH_MM = "HHmm";
    
    /**
     * 日期格式：年yyyy
     */
    public static final String YYYY = "yyyy";
    
    /**
     * 日期格式：年 MM
     */
    public static final String MM = "MM";
    
    /**
     * 日期格式：日dd
     */
    public static final String DD = "dd";
    
    /**
     * 日期格式：时HH
     */
    public static final String HH = "HH";
    
    /**
     * 日期格式：分 mm
     */
    public static final String MI = "mm";
    
}
