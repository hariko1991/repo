/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.front.cnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月6日
 */
public final class ReconCnst {
	public static final String CHANNEL_CODE = "channelCode";
	public static final String PAY_CODE = "payCode";
	public static final String BILL_MCH_NO = "billMchNo";
	public static final String FILE_DATE = "fileDate";
	public static final String EXT_ARG = "extArg";
	public static final String FILE_NAME = "fileName";
	public static final String DATA_ROWS = "dataRows";
	public static final String BANK_FILE_NAME = "bankFileName";
	/**
	 * 该通道下每个商户独立下载
	 */
	public static final String RECON_ALONE_YES = "ALONE_YES";
	public static final String RECON_ALONE_NO = "ALONE_NO";
	/**
	 * 该通道下所有商户一起下载
	 */
	public static final String RECON_WHOLE_YES = "WHOLE_YES";
	public static final String RECON_WHOLE_NO = "WHOLE_NO";
	/**
	 * 该通道由银行来通知
	 */
	public static final String RECON_BANK = "BANK";

	public static final String RECON_STATUS_INIT = "INIT";
	public static final String RECON_STATUS_LOADING = "LOADING";
	public static final String RECON_STATUS_DOWNLOAD = "DOWNLOAD";
	public static final String RECON_STATUS_ANALYSIS = "ANALYSIS";
	public static final String RECON_STATUS_SUCCESS = "SUCCESS";
	public static final String RECON_STATUS_FAILURE = "FAILURE";

	public static final String SFTP_IP = "SFTP_IP";
	public static final String SFTP_PORT = "SFTP_PORT";
	public static final String SFTP_USER = "SFTP_USER";
	public static final String SFTP_PASS = "SFTP_PASS";
	public static final String SFTP_PATH = "SFTP_PATH";
	public static final String LOCAL_PATH = "LOCAL_PATH";
	public static final String CLR_NOTIFY_TIME = "CLR_NOTIFY_TIME";

	public static final String SPLIT_COMMA_SEPARATOR = "\\,";
	public static final String VERTICAL_SEPARATOR = "\\|";
	public static final int FILE_NUMBER_PER_WRITE = 1000;

	public static final String TRADE_TYPE_REFUND = "REFUND";
	public static final String TRADE_TYPE_PAYMENT = "PAYMENT";
	
	public static final String LINE_SEPARATOR = "-";
	public static final String LINE_BREAK_SEPARATOR = "\n";
	public static final String ACCENT_SEPARATOR = "`";
}
