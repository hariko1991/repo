/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.front.cnst;

/**
 * 类说明：<br>
 * 用于更新数据库变量
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月25日
 */
public final class SqlCnst {
	public static final String PAY_NO = "payNo";
	public static final String PAY_CODE = "payCode";
	public static final String MCH_NO = "mchNo";
	public static final String MCH_REG_NO = "mchRegNo";
	public static final String MCH_ORDER_NO = "mchOrderNo";
	public static final String BIZ_TRADE_NO = "bizTradeNo";
	public static final String RECEIPT = "receipt";
	public static final String SRC_AMT = "srcAmt";
	public static final String SYSTEM_SOURCE = "systemSource";

	public static final String CHANNEL_NO = "channelNo";
	public static final String CHANNEL_MCH_NO = "channelMchNo";
	public static final String SUB_MCH_NO = "subMchNo";
	public static final String RTN_CODE = "rtnCode";
	public static final String RTN_MSG = "rtnMsg";
	public static final String STATUS = "status";
	public static final String RTN_INFO = "rtnInfo";

	/**
	 * 前置与核心转换状态,返回给业务系统
	 */
	public static final String CORE_STATUS = "coreStatus";
	/**
	 * 目标状态,更新数据库记录为什么状态
	 */
	public static final String TARGET_STATUS = "targetStatus";
	public static final String ORIGINAL_STATUS = "originalStatus";
	public static final String CHANNEL_PAY_CODE = "channelPayCode";
	/**
	 * 银行返回流水号
	 */
	public static final String RTN_ORDER_NO = "rtnOrderNo";
	/**
	 * 请求银行流水号
	 */
	public static final String REQ_BANK_SN = "reqBankSn";
	/**
	 * 支付时间
	 */
	public static final String PAY_TIME = "payTime";

	public static final String START_TIME = "startTime";
	public static final String END_TIME = "endTime";
	public static final String TRADE_TYPE = "tradeType";

	public static final String UPP_ORDER_NO = "uppOrderNo";
	public static final String APPEND_BUS_TYPE = "appendBusType";
	public static final String REQ_ORDER_NO = "reqOrderNo";
	public static final String CHANNEL_CODE = "channelCode";
	public static final String OLD_UPP_ORDER_NO = "oldUppOrderNo";

	public static final String CHANNEL_CODE_LIST = "channelCodeList";
	public static final String STATUS_LIST = "statusList";
	public static final String NOTIFY_FLAG = "notifyFlag";

	public static final String REMARK = "remark";
	public static final String BANK_CHANNEL_CODE = "bankChannelCode";
	
	public static final String EXT_TAB_OPENID = "openId";
	public static final String EXT_TAB_PREPAYID = "prepayId";
	public static final String EXT_TAB_REMARK = "remark";
	public static final String EXT_TAB_SELLERID = "sellerId";
	public static final String EXT_TAB_SELLERACCOUNT = "sellerAccount";
	public static final String EXT_TAB_BUYERID = "buyerId";
	public static final String EXT_TAB_BUYERACCOUNT = "buyerAccount";
	public static final String EXT_TAB_DISCOUNT = "discount";
	public static final String EXT_TAB_PAYMESSAGE = "payMessage";
}
