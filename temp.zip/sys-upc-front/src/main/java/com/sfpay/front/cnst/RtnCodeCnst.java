/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.front.cnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月26日
 */
public final class RtnCodeCnst {
	/**
	 * 无效请求
	 */
	public static final String ILLEGAL_REQ = "ILLEGAL_REQ";
	public static final String NOT_SUPPORT_FUNCTION = "NOT_SUPPORT_FUNCTION";
	public static final String SIGN_NOT_PASS = "SIGN_NOT_PASS";
	public static final String SECRET_IS_NOT_VALID = "SECRET_IS_NOT_VALID";
	public static final String RTN_CODE_IS_NOT_SUCCESS = "RTN_CODE_IS_NOT_SUCCESS";
	public static final String TOKEN_OR_TICKET_IS_EXPIRE = "TOKEN_OR_TICKET_IS_EXPIRE";
	public static final String TOKEN_IS_NOT_VALID = "TOKEN_IS_NOT_VALID";
	public static final String TICKET_IS_NOT_VALID = "TICKET_IS_NOT_VALID";
	public static final String SIGN_FAIL = "SIGN_FAIL";

	/**
	 * 商户号不存在
	 */
	public static final String MCH_NO_IS_EXISTS = "MCH_NO_IS_EXISTS";
	/**
	 * 商户号无效
	 */
	public static final String INVALID_MCH_NO = "INVALID_MCH_NO";
	/**
	 * 商户状态无效
	 */
	public static final String INVALID_MCH_STATUS = "INVALID_MCH_STATUS";
	/**
	 * 商户对应参数为空
	 */
	public static final String MCH_OF_ARG_IS_NULL = "MCH_OF_ARG_IS_NULL";
	/**
	 * 代理商户为空
	 */
	public static final String AID_MCH_NO_IS_NULL = "AID_MCH_NO_IS_NULL";
	public static final String CHANNEL_ARG_IS_NULL = "CHANNEL_ARG_IS_NULL";
	public static final String CHANNEL_INFO_IS_NULL = "CHANNEL_INFO_IS_NULL";
	/**
	 * 系统错误
	 */
	public static final String FAILURE_SYS = "FAILURE_SYS";
	public static final String DOWNLOAD_FILE_FAIL = "DOWNLOAD_FILE_FAIL";

	/**
	 * 通道不支持商户进件
	 */
	public static final String NOT_SUPPORT_MCH_FORMAT = "NOT_SUPPORT_MCH_FORMAT";

	public static final String NETWORK_EXCHANGE_EXCEPTION = "NETWORK_EXCHANGE_EXCEPTION";

	public static final String PROV_ACCT_NOT_INIT = "PROV_ACCT_NOT_INIT";
	public static final String SUCCESS = "SUCCESS";
	public static final String FAILURE = "FAILURE";
	public static final String SUCCESS_MSG = "成功";
	public static final String FAILURE_MSG = "失败";

	public static final String ONLY_TRADING_ORDER_CAN_CANCEL = "ONLY_TRADING_ORDER_CAN_CANCEL";

	// 银行通道返回撤销失败
	public static final String BANK_RTN_CANCEL_FAILURE = "BANK_RTN_CANCEL_FAILURE";

	public static final String ORDER_NOT_EXISTS = "ORDER_NOT_EXISTS";
	public static final String FAILURE_DB = "FAILURE_DB";
	public static final String ORDER_IS_REFUND_PROC = "ORDER_IS_REFUND_PROC";
	public static final String ORDER_IS_REFUND_SUCC = "ORDER_IS_REFUND_SUCC";
	public static final String ORDER_IS_REFUND_FAIL = "ORDER_IS_REFUND_FAIL";
	public static final String ONLY_SUCC_ORDER_CAN_REFUND = "ONLY_SUCC_ORDER_CAN_REFUND";
	public static final String REFUND_AMOUNT_GT_TRADE_AMOUNT = "REFUND_AMOUNT_GT_TRADE_AMOUNT";

}
