/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.front.util;

import java.math.BigDecimal;

public class CurrencyUtil {
	/**
	 * 单位：百(100L)
	 */
	private static final Long HUNDRED = 100L;

	private CurrencyUtil() {
	}

	/**
	 * 方法说明： 将以分为单位的金额转换为以元为单位的金额
	 * 
	 * @param fen 以分为单位的金额
	 * @return
	 */
	public static String fen2Yuan(Long fen) {
		if (fen == null) {
			return "";
		}
		BigDecimal bd = BigDecimal.valueOf(fen);
		return bd.divide(BigDecimal.valueOf(HUNDRED), 2, BigDecimal.ROUND_UP).toString();
	}

	/**
	 * 方法说明： 将以元为单位的金额转换为以分为单位的金额
	 * 
	 * @param yuan 以元为单位的金额
	 * @return 元转分,空对象或者非数字字符串，返回为空
	 */
	public static Long yuan2Fen(String yuan) {
		if (null == yuan || "".equals(yuan)) {
			return null;
		}
		try {
			yuan = yuan.replaceAll(",", "");
			BigDecimal bd = new BigDecimal(yuan);
			return bd.multiply(BigDecimal.valueOf(HUNDRED)).longValue();
		} catch (NumberFormatException e) {
			return null;
		}
	}
}
