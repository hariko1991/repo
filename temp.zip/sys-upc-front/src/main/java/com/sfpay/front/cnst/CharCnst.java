/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.front.cnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月24日
 */
public final class CharCnst {
	public static final String YES_FLAG = "Y";

	public static final String NO_FLAG = "N";

	public static final int NUMBER_ONE = 1;

	public static final String UNDER_LINE_FOR = "_FOR_";

	public static final String UNDER_LINE = "_";

	public static final String EXCHANGE_TYPE_GET = "get";

	public static final String EXCHANGE_TYPE_POST = "post";

	public static final int NUMBER_TEN = 10;

	public static final int NUMBER_TWENTY = 20;

	public static final int NUMBER_ZERO = 0;

	public static final int NUMBER_TWO = 2;

	public static final String EMPTY_STR = "";

	public static final String CLEAR_MODE_ONE = "ONE";
	public static final String CLEAR_MODE_TWO = "TWO";
	
	public static final int LENGTH_NUM = 18;
	public static final int LENGTH_NUM_6 = 6;
}
