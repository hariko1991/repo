/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.front.cnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月25日
 */
public final class MapCnst {

	public static final String REQ_ORDER_NO = "reqOrderNo";
	public static final String CHANNEL_MCH_NO = "channelMchNo";
	public static final String ENCRYPT_ID = "encryptId";
	public static final String PUBLIC_KEY = "publicKey";
	public static final String MCH_PUBLIC_KEY = "mchPublicKey";
	public static final String CHANNEL_CODE = "channelCode";
	public static final String CHANNEL_NAME = "channelName";
	public static final String FUNCTION_NAME = "functionName";
	public static final String PRODUCT_TYPE = "productType";
	public static final String PAY_CODE = "payCode";
	public static final String CHANNEL_PAY_CODE = "channelPayCode";
	public static final String MCH_NO = "mchNo";
	public static final String MCH_REG_NO = "mchRegNo";
	public static final String MCH_REG_STATUS = "mchRegStatus";

	public static final String NOTIFY_URL = "notifyUrl";

	public static final String RTN_CODE = "rtnCode";
	public static final String RTN_MSG = "rtnMsg";
	public static final String AID = "aid";

	public static final String APP_ID = "appId";
	public static final String SECRET_KEY = "secretKey";
	public static final String ACCESS_TOKEN = "accessToken";
	public static final String API_TICKET = "apiTicket";
	public static final String OLD_API_TICKET = "oldApiTicket";
	public static final String PAY_JSON = "payJson";
	public final static String SRC_AMT = "srcAmt";
	public final static String BILL_MCH_NO = "billMchNo";

	public static final String REFUND_NO = "refundNo";
	public static final String REFUND_AMT = "refundAmt";

	public static final String PROV_ACCT_NAME = "provAcctName";
	public static final String PROV_ACCT_NO = "provAcctNo";
	public static final String PROV_BANK_CODE = "provBankCode";
	public static final String PROV_BANK_NAME = "provBankName";

	public static final String TRADE_TYPE = "tradeType";

	public static final String NOTIFY_NONCE_STR = "nonceStr";
	public static final String NOTIFY_TIMESTAMP = "timestamp";
	public static final String NOTIFY_SIGN = "sign";
	public static final String NOTIFY_DATA = "data";

	public static final String BIZ_ORDER_NUMBER = "bizOrderNumber";
	public static final String COMPLETED_TIME = "completedTime";
	public static final String MID = "mid";

	public static final String CANCEL_NO = "cancelNo";

	public static final String OLD_REQ_ORDER_NO = "oldReqOrderNo";

	public static final String RECEIPT = "receipt";

	public static final String CLEAR_MODE = "clearMode";
	public static final String ORDER_ID = "orderId";
	public static final String BANK_CHANNEL_CODE = "bankChannelCode";
	public static final String PAY_MODE = "payMode";
	public static final String SUCCESS = "SUCCESS";
	
	public static final String POS_ID = "posId";
	public static final String BRANCH_ID = "branchId";
	public static final String PAY_NO_LENGTH_NUM = "lengthNum";
}
