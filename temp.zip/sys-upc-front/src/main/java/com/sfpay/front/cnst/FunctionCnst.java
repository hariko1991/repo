/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.front.cnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月24日
 */
public final class FunctionCnst {
	public static final String ADD_MERCHANT_FUNCTION = "addMerchant";

	public static final String CANCEL_FUNCTION = "cancel";

	public static final String DOWNLOAD_BILL_FUNCTION = "downloadbill";

	public static final String GET_MERCHANT_DETAIL_FUNCTION = "getMerchantDetail";

	public static final String QUERY_FUNCTION = "query";

	public static final String REFUND_FUNCTION = "refund";

	public static final String UPDATE_MERCHANT_FUNCTION = "updateMerchant";

	public static final String ADD_SUB_DEV_CONFIG_FUNCTION = "addSubDevConfig";

	/**
	 * 一码付
	 */
	public static final String JSPRECREATE_FUNCTION = "jsprecreate";

	/**
	 * 条码支付
	 */
	public static final String BARCODE_FUNCTION = "barcode";

	/**
	 * 退款查询
	 */
	public static final String REFUND_QUERY_FUNCTION = "queryrefund";

	public static final String REFRESH_TOKEN_FUNCTION = "refreshToken";

	/**
	 * 支付通知验证签名
	 */
	public static final String NOTIFY_VALIDATE_SIGN = "validateSign";
}
