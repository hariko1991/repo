/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.front.cnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月24日
 */
public final class StatusCnst {
	/**
	 * INIT("初始插入"),
	 */
	public static final String INIT = "INIT";
	/**
	 * TRADING("交易进行中"),
	 */
	public static final String TRADING = "TRADING";
	/**
	 * SUCCESS("交易成功"),
	 */
	public static final String SUCCESS = "SUCCESS";
	/**
	 * FAILURE("交易失败"),
	 */
	public static final String FAILURE = "FAILURE";
	/**
	 * CLOSE("交易关闭"),
	 */
	public static final String CLOSE = "CLOSE";
	/**
	 * REFUND_PROC("退款处理中"),
	 */
	public static final String REFUND_PROC = "REFUND_PROC";
	/**
	 * REFUND_ACCEPTED("退款已受理"),
	 */
	public static final String REFUND_ACCEPTED = "REFUND_ACCEPTED";
	/**
	 * REFUND_SUCC("退款成功"),
	 */
	public static final String REFUND_SUCC = "REFUND_SUCC";
	/**
	 * REFUND_FAIL("退款失败"),
	 */
	public static final String REFUND_FAIL = "REFUND_FAIL";
	/**
	 * HAS_REFUND("存在退款"),
	 */
	public static final String HAS_REFUND = "HAS_REFUND";
	/**
	 * NOT_PAY("未支付"),
	 */
	public static final String NOT_PAY = "NOT_PAY";
	/**
	 * NOT_EXISTS("不存在"),
	 */
	public static final String NOT_EXISTS = "NOT_EXISTS";
	/**
	 * UNKNOW("未知"),
	 */
	public static final String UNKNOW = "UNKNOW";
	/**
	 * PAYING("正在支付"),
	 */
	public static final String PAYING = "PAYING";
	/**
	 * FREEZE("冻结"),
	 */
	public static final String FREEZE = "FREEZE";
	/**
	 * ENABLE("启用"),
	 */
	public static final String ENABLE = "ENABLE";
	/**
	 * APPLY("启用"),
	 */
	public static final String APPLY = "APPLY";
	/**
	 * DISABLE("禁用"),
	 */
	public static final String DISABLE = "DISABLE";
}
