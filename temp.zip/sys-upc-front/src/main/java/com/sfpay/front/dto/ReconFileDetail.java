/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.front.dto;

import java.io.Serializable;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月8日
 */
public class ReconFileDetail implements Serializable {
	private static final long serialVersionUID = 2246114736218766695L;
	private static final String SPLIT_COMMA_SEPARATOR = ",";

	/**商户订单号*/
	private String merOrderNo;
	/**组织机构号*/
	private String channelOrgCode;
	/**商户号*/
	private String channelOrgMerNo;
	/**交易流水号*/
	private String tradeSn;
	/**消费时间*/
	private String tradeTime;
	/**消费状态*/
	private String tradeStatus;
	/**消费类型*/
	private String tradeType;
	/**订单金额*/
	private Long orderAmt;
	/**商户实收*/
	private Long merAmt;
	/**其它手续费*/
	private Long otherFee;
	/**手续费*/
	private Long fee;
	/**收单设备*/
	private String orderEqu;

	public String getMerOrderNo() {
		return merOrderNo;
	}

	public void setMerOrderNo(String merOrderNo) {
		this.merOrderNo = merOrderNo;
	}

	public String getChannelOrgCode() {
		return channelOrgCode;
	}

	public void setChannelOrgCode(String channelOrgCode) {
		this.channelOrgCode = channelOrgCode;
	}

	public String getChannelOrgMerNo() {
		return channelOrgMerNo;
	}

	public void setChannelOrgMerNo(String channelOrgMerNo) {
		this.channelOrgMerNo = channelOrgMerNo;
	}

	public String getTradeSn() {
		return tradeSn;
	}

	public void setTradeSn(String tradeSn) {
		this.tradeSn = tradeSn;
	}

	public String getTradeTime() {
		return tradeTime;
	}

	public void setTradeTime(String tradeTime) {
		this.tradeTime = tradeTime;
	}

	public String getTradeStatus() {
		return tradeStatus;
	}

	public void setTradeStatus(String tradeStatus) {
		this.tradeStatus = tradeStatus;
	}

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

	public Long getOrderAmt() {
		return orderAmt;
	}

	public void setOrderAmt(Long orderAmt) {
		this.orderAmt = orderAmt;
	}

	public Long getMerAmt() {
		return merAmt;
	}

	public void setMerAmt(Long merAmt) {
		this.merAmt = merAmt;
	}

	public Long getOtherFee() {
		return otherFee;
	}

	public void setOtherFee(Long otherFee) {
		this.otherFee = otherFee;
	}

	public Long getFee() {
		return fee;
	}

	public void setFee(Long fee) {
		this.fee = fee;
	}

	public String getOrderEqu() {
		return orderEqu;
	}

	public void setOrderEqu(String orderEqu) {
		this.orderEqu = orderEqu;
	}

	public String toReconStr() {
		return new StringBuffer("").append(tradeTime).append(SPLIT_COMMA_SEPARATOR)
				.append(null == merOrderNo ? "" : merOrderNo).append(SPLIT_COMMA_SEPARATOR)
				.append(null == tradeSn ? "" : tradeSn).append(SPLIT_COMMA_SEPARATOR)
				.append(null == tradeType ? "" : tradeType).append(SPLIT_COMMA_SEPARATOR)
				.append(null == tradeStatus ? "" : tradeStatus).append(SPLIT_COMMA_SEPARATOR)
				.append(null == orderAmt ? "" : orderAmt).append(SPLIT_COMMA_SEPARATOR)
				.append(null == merAmt ? "" : merAmt).append(SPLIT_COMMA_SEPARATOR).append(null == fee ? "" : fee)
				.append(SPLIT_COMMA_SEPARATOR).append(null == otherFee ? "" : otherFee).toString();
	}

}
