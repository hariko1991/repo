/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.front.function;

import java.util.Map;

/**
 * 类说明：<br>
 * 访问银行基类,通过此扩展
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月25日
 */
public abstract class Function {
	/**
	 * 方法说明：<br>
	 * 传入相应参数,获取相应结果
	 * @param uqNo 商户为商户号,交易为payNo
	 * @param function 产品类型
	 * @param reqMap   请求对象
	 * @param extMap   扩展信息
	 * @return Map<String, String>
	 */
	public abstract Map<String, String> getResp(String uqNo, String function, Map<String, String> reqMap,
			Map<String, String> extMap);
	
}
