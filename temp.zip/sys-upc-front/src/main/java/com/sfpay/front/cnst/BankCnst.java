/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.front.cnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月26日
 */
public final class BankCnst {
	public static final String CONN_TIME_OUT = "connTimeOut";
	public static final String READ_TIME_OUT = "readTimeOut";
	public static final String PATH = "path";
	public static final String P12_NAME = "p12";
	public static final String PASS = "pass";
	public static final String JKS = "jks";
	public static final String TRUST = "trust";
	public static final String KEY = "key";
	public static final String CRT = "crt";
	public static final String CLIENT_PASS = "clientPass";
	public static final String SERVER_PASS = "serverPass";
	public static final String EXCHANGE_TYPE = "exchangeType";
	public static final String SHELL_SCRIPT = "shellScript";
	public static final String NETWORK_URL = "networkUrl";
	public static final String ACTUAL_NETWORK_URL = "actualNetworkUrl";
	public static final String ENV = "env";

	public static final String ENV_TEST = "test";
	public static final String BIN_ENV = "binEnv";
	public static final String WX_ENCODING = "wxEncoding";
	public static final String ALIPAY_ENCODING = "alipayEncoding";
	
	public static final String BANK_SFTP_IP = "sftpIp";
	public static final String BANK_SFTP_PORT = "sftpPort";
	public static final String BANK_SFTP_URL = "sftpUrl";
	public static final String BANK_SFTP_USER = "sftpUser";
	public static final String BANK_SFTP_PWD = "sftpPwd";
}
