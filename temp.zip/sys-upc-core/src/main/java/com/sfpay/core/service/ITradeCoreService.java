package com.sfpay.core.service;

import java.util.Map;

import com.sfpay.core.dto.UpcPayInfoDto;
import com.sfpay.upc.gw.domain.sys.req.SysBarcodeReq;
import com.sfpay.upc.gw.domain.sys.req.SysCancelReq;
import com.sfpay.upc.gw.domain.sys.req.SysJsprecreateReq;
import com.sfpay.upc.gw.domain.sys.req.SysRefundReq;
import com.sfpay.upc.gw.domain.sys.resp.SysBarcodeResp;
import com.sfpay.upc.gw.domain.sys.resp.SysCancelResp;
import com.sfpay.upc.gw.domain.sys.resp.SysJsprecreateResp;
import com.sfpay.upc.gw.domain.sys.resp.SysRefundResp;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月24日
 */
public interface ITradeCoreService {

	/**
	 * 一码付预下单
	 * @param req
	 * @param merMap
	 * @return  SysJsprecreateResp
	 */
	SysJsprecreateResp jsprecreate(SysJsprecreateReq req);

	/**
	 * 关单（撤销）
	 * @param req
	 * @param existPayInfo
	 * @return
	 */
	SysCancelResp cancel(SysCancelReq req);

	/**
	 * 退款
	 * @param req
	 * @return
	 */
	SysRefundResp refund(SysRefundReq req);

	/**
	 * 方法说明：<br>
	 * 
	 * @param req
	 * @return
	 */
	SysBarcodeResp barcode(SysBarcodeReq req);
	
	/**
	 * 退款查询
	 * @param req
	 * @return
	 */
	UpcPayInfoDto refundQuery(UpcPayInfoDto req);
	
	/**
	 * 支付查询
	 * @param req
	 * @return
	 */
	UpcPayInfoDto payQuery(UpcPayInfoDto req);
	
	/**
	 * 支付通知结果
	 * @param reqMap
	 * @return
	 */
	UpcPayInfoDto notifyResult(Map<String, String> reqMap);
	
	/**
	 * 对退款失败的订单，重新发起退款
	 * @param reqMap
	 * @return
	 */
	UpcPayInfoDto reRefund(Map<String, String> reqMap);
	
	/**
	 * 通知秘钥改变
	 * @param reqMap
	 */
	void notifySecretKeyChange(Map<String, String> reqMap);
}
