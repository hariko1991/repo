/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service.thread;

import java.util.Arrays;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.core.dto.UpcPayInfoDto;
import com.sfpay.core.service.INotifyResultService;
import com.sfpay.core.service.ITradeCoreService;
import com.sfpay.core.util.SpringContextHolder;
import com.sfpay.front.cnst.StatusCnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月15日
 */
public class PayQueryAndNotifyThread implements Runnable {
	private static final Logger LOGGER = LoggerFactory.getLogger(PayQueryAndNotifyThread.class);
	private static final String TRADE_CORE_SERVICE = "tradeCoreService";
	private static final String NOTIFY_RESULT_SERVICE = "notifyResultService";
	private static final List<String> STATUS_LIST = Arrays
			.asList(new String[] { StatusCnst.SUCCESS, StatusCnst.FAILURE });

	private List<UpcPayInfoDto> payInfoList;

	/**
	 * 循环次数
	 */
	private int forTimes;

	private ITradeCoreService tradeCoreService;

	private INotifyResultService notifyResultService;

	public PayQueryAndNotifyThread(List<UpcPayInfoDto> payInfoList, int forTimes) {
		this.payInfoList = payInfoList;
		if (forTimes < 1) {
			forTimes = 1;
		} else {
			this.forTimes = forTimes;
		}
		this.tradeCoreService = SpringContextHolder.getBean(TRADE_CORE_SERVICE);
		this.notifyResultService = SpringContextHolder.getBean(NOTIFY_RESULT_SERVICE);
	}

	@Override
	public void run() {
		UpcPayInfoDto resultPayInfo = null;
		for (UpcPayInfoDto payInfo : payInfoList) {
			// 1、支付查询
			String logMsg = String.format("查询支付交易状态支付编号[%s]", payInfo.getPayNo());
			resultPayInfo = this.payQuery(payInfo, logMsg);
			try {
				// 2、通知业务
				notifyResultService.notifyResult(resultPayInfo);
			} catch (Exception e) {
				LOGGER.error("{}通知业务系统异常", logMsg, e);
			}
		}
	}

	private UpcPayInfoDto payQuery(UpcPayInfoDto payInfo, String logMsg) {
		UpcPayInfoDto resultPayInfo = null;
		for (int i = 0; i < forTimes; i++) {// 遍历次数
			try {
				resultPayInfo = tradeCoreService.payQuery(payInfo);
				LOGGER.info("{}查询银行返回状态为[{}]", logMsg, resultPayInfo.getStatus());
			} catch (Exception e) {
				LOGGER.error("{}异常", logMsg, e);
			}
			// 1、查询结果,并处理
			if (null != resultPayInfo && STATUS_LIST.contains(resultPayInfo.getStatus())) {
				break;
			} else {
				if (forTimes > 1) {
					try {
						Thread.sleep(5000);
					} catch (InterruptedException e) {
						LOGGER.info("{},银行返回非支付完成状态,需要等待5s再去查询", logMsg, e);
					} // 超时调用遍历间隔时间
				}
			}
		}
		return resultPayInfo;
	}

}
