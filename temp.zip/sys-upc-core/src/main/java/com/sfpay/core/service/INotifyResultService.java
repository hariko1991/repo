package com.sfpay.core.service;

import com.sfpay.core.dto.UpcPayInfoDto;

/**
 * 通知结果
 * @author 719811
 *
 */
public interface INotifyResultService {
	void notifyResult(UpcPayInfoDto payInfo);
}
