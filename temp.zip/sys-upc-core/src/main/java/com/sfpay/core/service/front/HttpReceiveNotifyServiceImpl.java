package com.sfpay.core.service.front;

import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.dto.UpcPayInfoDto;
import com.sfpay.core.service.INotifyResultService;
import com.sfpay.core.service.ITradeCoreService;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.service.IHttpReceiveNotifyService;

@HessianExporter
@Service("httpReceiveNotifyService")
public class HttpReceiveNotifyServiceImpl implements IHttpReceiveNotifyService {

	private static final Logger LOGGER = LoggerFactory.getLogger(HttpReceiveNotifyServiceImpl.class);
	
	@Resource
	ITradeCoreService tradeCoreService;
	
	@Resource
	INotifyResultService notifyResultService;
	
	@Override
	public boolean notifyResult(String logMsg, Map<String, String> reqMap) {
		LOGGER.info("{},通知结果,请求参数{}", logMsg, reqMap);
		UpcPayInfoDto upcPayInfoDto = null;
		try{
			//外部通知upc
			upcPayInfoDto = tradeCoreService.notifyResult(reqMap);
			if(upcPayInfoDto != null && CharCnst.NO_FLAG.equals(upcPayInfoDto.getNotifyFlag())){
				//通知业务系统
				notifyResultService.notifyResult(upcPayInfoDto);
			}
			return true;
		}catch (Exception e) {
			LOGGER.error("支付通知回调处理异常 , 请求体{}" , reqMap , e);
		}
		return false;
	}

	@Override
	public boolean notifySecretKeyChange(String logMsg,
			Map<String, String> reqMap) {
		LOGGER.info("{},通知密码改变结果,请求参数{}", logMsg, reqMap);
		tradeCoreService.notifySecretKeyChange(reqMap);
		return true;
	}

}
