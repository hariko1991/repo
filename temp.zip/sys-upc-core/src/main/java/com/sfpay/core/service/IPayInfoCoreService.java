/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service;

import java.util.Date;
import java.util.List;
import java.util.Map;

import com.sfpay.core.dto.UpcPayInfoDto;
import com.sfpay.upc.gw.domain.sys.req.SysRefundReq;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月24日
 */
public interface IPayInfoCoreService {

	/**
	 * 方法说明：<br>
	 * 请求信息插入数据库
	 * @param req
	 * @param extMap
	 * @return UpcPayInfoDto
	 */
	UpcPayInfoDto createUpcPayInfo(String logMsg, Map<String, String> req, Map<String, String> extMap);

	/**
	 * 方法说明：<br>
	 * 根据指定参数更新upc_pay_info
	 * @param respMap
	 * @param updateMap
	 * @return int
	 */
	int updateUpcPayInfo(Map<String, String> respMap, Map<String, String> updateMap);
	
	/**
	 * 需要更新扩展表
	 * @param respMap
	 * @param updateMap
	 * @param isUpdateExt
	 * @param payCode
	 * @return
	 */
	int updateUpcPayInfo(Map<String, String> respMap, Map<String, String> updateMap , 
			boolean isUpdateExt , String payCode);

	/**
	 * 根据请求查询支付信息
	 * @param queryMap
	 * @return UpcPayInfo
	 */
	UpcPayInfoDto queryPayInfo(Map<String, Object> queryMap);

	/**
	 * 根据请求查询支付信息列表
	 * @param queryMap
	 * @return List<UpcPayInfo>
	 */
	List<UpcPayInfoDto> queryPayInfoList(Map<String, Object> queryMap);

	/**
	 * 创建退款信息
	 * @param payReq  payReq
	 * @param upcPayInfo upcPayInfo
	 * @param extMap extMap
	 * @return
	 */
	UpcPayInfoDto createRefundInfo(SysRefundReq payReq, UpcPayInfoDto upcPayInfo, Map<String, String> extMap);

	List<UpcPayInfoDto> querySpecifyPayInfoList(Date endTime, Map<String, String> reqMap, List<String> channelCodeList);

}
