/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.task;

import java.util.Calendar;
import java.util.Date;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.service.IChannelReconService;
import com.sfpay.core.util.DateUtils;
import com.sfpay.front.cnst.CharCnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月6日
 */
@Service("createReconFileTask")
public class CreateReconFileTask {
	private static final Logger LOGGER = LoggerFactory.getLogger(CreateReconFileTask.class);

	@Resource
	private IChannelReconService channelReconService;

	public void execute() {
		long start = 0L;
		try {
			start = System.currentTimeMillis();
			Date fileDate = DateUtils.getReconDate(new Date(), Calendar.DAY_OF_MONTH, CharCnst.NUMBER_ONE);
			LOGGER.info("createReconFileTask——>start随机号[{}],对账时间[{}]", start, fileDate);
			
			channelReconService.initChannelReconFile(start + "", fileDate);
			channelReconService.downloadReconFile(start + "", fileDate);
			
		} finally {
			LOGGER.info("createReconFileTask——>end,随机号[{}]耗时[{}]", start, (System.currentTimeMillis() - start));
		}
	}
}
