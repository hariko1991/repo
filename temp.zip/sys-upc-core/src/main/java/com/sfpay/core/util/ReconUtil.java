/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.util;

import java.util.Calendar;
import java.util.Date;

import com.sfpay.core.dto.ChannelReconFileDto;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.cnst.DateCnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月6日
 */
public final class ReconUtil {
	public static final String FILE_SEPERATOR = "_";
	public static final String FILE_SUFFIX = ".txt";

	public static void getReconFileName(ChannelReconFileDto reconFile, String channelCode) {
		Date fileDate = DateUtils.getReconDate(new Date(), Calendar.DAY_OF_MONTH, CharCnst.NUMBER_ONE);
		String dateStr = DateUtils.format(fileDate, DateCnst.YYYYMMDD);
		StringBuilder fileName = new StringBuilder().append(channelCode).append(FILE_SEPERATOR)
				.append(reconFile.getPayCode()).append(FILE_SEPERATOR).append(reconFile.getBillMchNo())
				.append(FILE_SEPERATOR).append(dateStr).append(FILE_SUFFIX);
		reconFile.setFileDate(fileDate);
		reconFile.setFileName(fileName.toString());
	}

}
