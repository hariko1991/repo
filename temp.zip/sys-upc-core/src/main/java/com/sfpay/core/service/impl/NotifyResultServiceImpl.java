package com.sfpay.core.service.impl;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.cnst.AppendBusTypeCnst;
import com.sfpay.core.dto.ChannelInfoDto;
import com.sfpay.core.dto.UpcPayInfoDto;
import com.sfpay.core.service.IClrNotifyService;
import com.sfpay.core.service.IMerchantInfoService;
import com.sfpay.core.service.INotifyResultService;
import com.sfpay.core.service.IPayInfoCoreService;
import com.sfpay.core.util.LoadStaticDataUtil;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.cnst.TradeTypeCnst;
import com.sfpay.upc.gw.domain.sys.req.ClrNotifyReq;
import com.sfpay.upc.gw.domain.sys.req.SysNotifyReq;
import com.sfpay.upc.gw.domain.sys.resp.SysNotifyResp;
import com.sfpay.upc.gw.service.ISysNotifyService;

@Service("notifyResultService")
public class NotifyResultServiceImpl implements INotifyResultService {

	private static final Logger LOGGER = LoggerFactory.getLogger(NotifyResultServiceImpl.class);

	private static Set<String> statusSet = new HashSet<String>();

	@Resource
	ISysNotifyService sysNotifyService;

	@Resource
	IClrNotifyService clrNotifyService;

	@Resource
	IPayInfoCoreService payInfoCoreService;

	@Resource
	LoadStaticDataUtil loadStaticDataUtil;

	@Resource
	IMerchantInfoService merchantInfoService;

	static {
		statusSet.add(StatusCnst.SUCCESS);
		statusSet.add(StatusCnst.FAILURE);
		statusSet.add(StatusCnst.CLOSE);
		statusSet.add(StatusCnst.REFUND_SUCC);
		statusSet.add(StatusCnst.REFUND_FAIL);
	}

	@Override
	public void notifyResult(UpcPayInfoDto payInfo) {
		String logMsg = String.format("通知请求 payNo[%s],tradeType[%s],appendBusType[%s],mchNo[%s]", payInfo.getPayNo(),
				payInfo.getTradeType(), payInfo.getAppendBusType(), payInfo.getMchNo());
		if (!statusSet.contains(payInfo.getStatus())) {
			LOGGER.error("status:{},不允许通知业务系统,需要通知支付号:{}", payInfo.getStatus(), payInfo.getPayNo());
			return;
		}
		SysNotifyResp resp = null;
		LOGGER.info("{},需要通知的信息PayNo:{}", logMsg, payInfo.getPayNo());
		// 清算退款
		if (TradeTypeCnst.TRADE_TYPE_REFUND.equals(payInfo.getTradeType())
				&& AppendBusTypeCnst.APPEND_BUS_TYPE_REFUND.equals(payInfo.getAppendBusType())) {
			resp = this.notifyClsResult(payInfo);
		} else {
			// 业务支付及退款
			resp = this.notifySypayResult(payInfo);
		}
		LOGGER.info("{},通知响应结果:{}", logMsg, resp);
		if (resp != null && resp.isResult()) {
			Map<String, String> updateMap = new HashMap<String, String>();
			updateMap.put(SqlCnst.NOTIFY_FLAG, CharCnst.YES_FLAG);
			updateMap.put(SqlCnst.PAY_NO, payInfo.getPayNo());
			try {
				payInfoCoreService.updateUpcPayInfo(null, updateMap);
			} catch (Exception e) {
				LOGGER.error("更新通知状态异常  , 参数对象:{}", updateMap, e);
			}
		}

	}

	private SysNotifyResp notifySypayResult(UpcPayInfoDto payInfo) {
		SysNotifyResp notifyResp = new SysNotifyResp();
		try {
			ChannelInfoDto ChannelInfoDto = loadStaticDataUtil.getChannelInfo(payInfo.getBankChannelCode() , false);
			SysNotifyReq notifyReq = new SysNotifyReq();
			notifyReq.setChannelName(ChannelInfoDto.getChannelName());
			notifyReq.setChannelCode(payInfo.getBankChannelCode());
			notifyReq.setMchNo(payInfo.getMchNo());
			notifyReq.setMchOrderNo(payInfo.getMchOrderNo());
			notifyReq.setPayNo(payInfo.getPayNo());
			notifyReq.setBizTradeNo(payInfo.getUppOrderNo());
			notifyReq.setRtnOrderNo(payInfo.getRtnOrderNo());
			notifyReq.setChannelNo(payInfo.getChannelNo());
			Map<String, String> provAcctMap = loadStaticDataUtil.initProvAcctMap(payInfo.getBankChannelCode(),
					payInfo.getPayCode());
			notifyReq.setProvBankCode(provAcctMap.get(MapCnst.PROV_BANK_CODE));
			notifyReq.setProvBankName(provAcctMap.get(MapCnst.PROV_BANK_NAME));
			notifyReq.setProvAcctName(provAcctMap.get(MapCnst.PROV_ACCT_NAME));
			notifyReq.setProvAcctNo(provAcctMap.get(MapCnst.PROV_ACCT_NO));
			notifyReq.setTradeType(payInfo.getTradeType());
			notifyReq.setRtnCode((StatusCnst.SUCCESS.equals(payInfo.getStatus()) ||
					StatusCnst.REFUND_SUCC.equals(payInfo.getStatus())) ? RtnCodeCnst.SUCCESS
					: RtnCodeCnst.FAILURE);
			notifyReq.setRtnMsg(payInfo.getRtnMsg());
			notifyReq.setStatus(payInfo.getStatus());
			// 业务系统要求，将close状态转化为FAILURE状态返回
			if (StatusCnst.CLOSE.equals(notifyReq.getStatus())) {
				notifyReq.setStatus(StatusCnst.FAILURE);
			}
			LOGGER.info("通知顺手富请求参数:{}", notifyReq);
			
			long startTime = System.currentTimeMillis();
			notifyResp = sysNotifyService.notifySypayResult(notifyReq);
			LOGGER.info("通知顺手富,耗时:{} 毫秒", (System.currentTimeMillis() - startTime));
		} catch (Exception e) {
			LOGGER.error("通知清算系统异常，notifyResp : {}", notifyResp, e);
			notifyResp.setResult(false);
		}
		return notifyResp;
	}

	private SysNotifyResp notifyClsResult(UpcPayInfoDto refundPayInfo) {
		ClrNotifyReq notifyReq = new ClrNotifyReq();
		SysNotifyResp notifyResp = new SysNotifyResp();
		try {
			Map<String, Object> queryMap = new HashMap<String, Object>();
			queryMap.put(SqlCnst.UPP_ORDER_NO, refundPayInfo.getOldUppOrderNo());
			queryMap.put(SqlCnst.APPEND_BUS_TYPE, AppendBusTypeCnst.APPEND_BUS_TYPE_NORMAL);
			UpcPayInfoDto payInfo = payInfoCoreService.queryPayInfo(queryMap);

			notifyReq.setChannelCode(refundPayInfo.getBankChannelCode());
			notifyReq.setRefundStatus(StatusCnst.REFUND_SUCC.equals(refundPayInfo.getStatus())
					? String.valueOf(CharCnst.NUMBER_ONE) : String.valueOf(CharCnst.NUMBER_ZERO));
			notifyReq.setRefundAmt(refundPayInfo.getTradeAmt());
			notifyReq.setOriAmt(payInfo.getTradeAmt());
			notifyReq.setOriReqOrderNo(payInfo.getReqOrderNo());
			notifyReq.setUppOrderNo(refundPayInfo.getUppOrderNo());

			LOGGER.info("通知清算请求参数:{}", notifyReq);
			long startTime = System.currentTimeMillis();
			clrNotifyService.notifyClrRefund(notifyReq);
			LOGGER.info("通知清算,耗时:{} 毫秒", (System.currentTimeMillis() - startTime));
			notifyResp.setResult(true);
		} catch (Exception e) {
			LOGGER.error("通知清算系统异常，refundPayInfo : {}", refundPayInfo, e);
			notifyResp.setResult(false);
		}
		return notifyResp;
	}

	public void notifyClsResult(ClrNotifyReq notifyReq) {
		LOGGER.info("通知业务系统, 系统编码 : CLS , 请求参数  : {}", notifyReq);
		clrNotifyService.notifyClrRefund(notifyReq);
	}
}
