/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.core.dto.ChannelPayDto;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月22日
 */
public interface IChannelPayDao {

	List<ChannelPayDto> queryAllChannelPay();

	ChannelPayDto queryChannelPayByChnlCode(@Param("channelCode") String channelCode);

	ChannelPayDto queryChannelPay(@Param("channelPayCode") String channelPayCode);
}
