/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service;

import java.util.Date;
import java.util.List;

import com.sfpay.core.dto.ClrChnlInfo;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：<br>
 * 清算通道接口
 * 
 * <p>
 * 详细描述：<br>
 * 通道交易数据生产 for 清算
 * 
 * </p>
 * 
 * @author 830598 wu_jl
 * 
 * CreateDate: 2017年5月2日
 */
public interface IChannel4CLRService {
	/***
	 * 
	 * @param tradeDate 交易日期 如:2015-12-30
	 * @param channelTypeCode 通道类型编码<a style="color:red">UPC</a>
	 * @param channelOrgCode  通道机构编码,如:CMBC
	 * @throws ServiceException
	 */
	public void synchChannelData(Date tradeDate, String channelTypeCode, String channelOrgCode, String channelOrgMchNo)
			throws ServiceException;

	/**
	 * 方法说明：<br>
	 * 查询可用的银行，剔除了ALIPAY、WX, for clr
	 * 
	 * @return
	 */
	public List<ClrChnlInfo> findClrChnlList() throws ServiceException;
}
