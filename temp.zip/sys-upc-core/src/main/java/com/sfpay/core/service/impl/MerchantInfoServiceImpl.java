/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.dao.IMerchantInfoDao;
import com.sfpay.core.dto.MerchantInfoDto;
import com.sfpay.core.service.IMerchantInfoService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.gw.domain.sys.req.SysAddMerchantReq;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月22日
 */
@Service("merchantInfoService")
public class MerchantInfoServiceImpl implements IMerchantInfoService {
	private static final Logger LOGGER = LoggerFactory.getLogger(MerchantInfoServiceImpl.class);
	@Resource
	private IMerchantInfoDao merchantInfoDao;
	private static final String AGENCY_ID = "AgencyId";
	private static final String BY_SELF = "bySelf";

	@Override
	public Map<String, MerchantInfoDto> queryAllMerchantInfo() {
		List<MerchantInfoDto> merchantInfos = merchantInfoDao.queryAllMerchantInfo();
		Map<String, MerchantInfoDto> merchantInfoMap = new HashMap<String, MerchantInfoDto>();

		if (CollectionUtils.isNotEmpty(merchantInfos)) {
			LOGGER.info("数据库中有商户相关信息[{}]条", merchantInfos.size());
			for (MerchantInfoDto merchantInfo : merchantInfos) {
				merchantInfoMap.put(merchantInfo.getChannelCode() + CharCnst.UNDER_LINE + merchantInfo.getPayCode()
						+ CharCnst.UNDER_LINE + merchantInfo.getMchNo(), merchantInfo);
			}
			LOGGER.info("组装商户映射完成,结果为[{}]", merchantInfoMap);
		} else {
			LOGGER.info("数据库中有商户相关信息[0]条");
		}
		return merchantInfoMap;
	}

	@Override
	public MerchantInfoDto createMerchantInfo(String logMsg, SysAddMerchantReq req, Map<String, String> extMap) {
		MerchantInfoDto merchantInfo = new MerchantInfoDto();
		String mapKey = new StringBuffer("").append(req.getPayCode().toLowerCase()).append(AGENCY_ID)
				.append(StringUtils.left(req.getClearMode(), CharCnst.NUMBER_ONE))
				.append(StringUtils.right(req.getClearMode(), CharCnst.NUMBER_TWO).toLowerCase()).toString();
		LOGGER.info("{}获取组装mapKey为[{}],对应值为[{}]", new Object[] { logMsg, mapKey, extMap.get(mapKey) });

		if (BY_SELF.equals(extMap.get(mapKey))) {
			merchantInfo.setBillMchNo(extMap.get(SqlCnst.CHANNEL_MCH_NO));
		} else {
			merchantInfo.setBillMchNo(extMap.get(mapKey));
		}
		merchantInfo.setChannelCode(req.getChannelCode());
		merchantInfo.setPayCode(req.getPayCode());
		merchantInfo.setMchNo(req.getMchNo());
		merchantInfo.setMchName(req.getMchName());
		merchantInfo.setStatus(extMap.get(SqlCnst.STATUS));
		merchantInfo.setSubMchNo(extMap.get(SqlCnst.SUB_MCH_NO));
		merchantInfo.setChannelMchNo(extMap.get(SqlCnst.CHANNEL_MCH_NO));
		int count = merchantInfoDao.createMerchantInfo(merchantInfo);

		if (CharCnst.NUMBER_ONE != count) {
			throw new ServiceException(UpcConstants.FAILURE_DB, "商户信息插入数据库结果不是1条");
		}
		return merchantInfo;
	}

	@Override
	public int updateMerchantInfo(Map<String, String> respMap, Map<String, String> updateMap) {
		updateMap.putAll(respMap);
		int count = merchantInfoDao.updateMerchantInfo(updateMap);
		if (CharCnst.NUMBER_ONE != count) {
			throw new ServiceException(UpcConstants.FAILURE_DB, "商户信息更新结果不是1条");
		}
		return count;
	}

	public MerchantInfoDto queryMerchantInfo(String mchNo, String channelCode, String payCode) {
		return merchantInfoDao.queryMerchantInfo(mchNo, channelCode, payCode);
	}

}
