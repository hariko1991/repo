/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service;

import com.sfpay.upc.gw.domain.sys.req.ClrNotifyReq;

/**
 * 
 * 类说明：<br>
 * 清算系统通知类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 830598 wu_jl
 * 
 * CreateDate: 2017年5月10日
 */
public interface IClrNotifyService {
	
	/**
	 * 方法说明：<br>
	 * 通知清算系统退款结果
	 * @param notifyReq
	 * @return NotifyResp
	 */
	void notifyClrRefund(ClrNotifyReq notifyReq);
}
