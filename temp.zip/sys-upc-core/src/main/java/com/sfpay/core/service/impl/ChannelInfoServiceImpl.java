/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.dao.IChannelInfoDao;
import com.sfpay.core.dto.ChannelInfoDto;
import com.sfpay.core.service.IChannelInfoService;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月22日
 */
@Service("channelInfoService")
public class ChannelInfoServiceImpl implements IChannelInfoService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ChannelInfoServiceImpl.class);

	@Resource
	private IChannelInfoDao channelInfoDao;

	@Override
	public Map<String, ChannelInfoDto> queryAllChannelInfo() {
		List<ChannelInfoDto> channelInfos = channelInfoDao.queryAllChannelInfo();
		Map<String, ChannelInfoDto> channelInfoMap = new HashMap<String, ChannelInfoDto>();

		if (CollectionUtils.isNotEmpty(channelInfos)) {
			LOGGER.info("数据库中有通道相关信息[{}]条", channelInfos.size());
			for (ChannelInfoDto channelInfo : channelInfos) {
				channelInfoMap.put(channelInfo.getChannelCode(), channelInfo);
			}
			LOGGER.info("组装通道映射完成,结果为[{}]", channelInfoMap);
		} else {
			LOGGER.info("数据库中有通道相关信息[0]条");
		}

		return channelInfoMap;
	}

	@Override
	public ChannelInfoDto queryChannelInfo(String channelCode) {
		return channelInfoDao.queryChannelInfo(channelCode);
	}

	@Override
	public List<String> queryChannelCodeList() {
		return channelInfoDao.queryChannelCodeList();
	}

}
