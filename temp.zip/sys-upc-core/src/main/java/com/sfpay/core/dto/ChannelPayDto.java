/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.dto;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月22日
 */
public class ChannelPayDto extends BaseDto {

	private static final long serialVersionUID = 2562165027859403360L;

	private String channelPayCode;
	private String channelCode;
	private String payCode;
	private String provBankCode;
	private String provBankName;
	private String provAcctNo;
	private String provAcctName;
	private Long votePriority;
	private String status;
	private String mtStartTime;
	private String mtEndTime;
	
	public String getChannelPayCode() {
		return channelPayCode;
	}

	public void setChannelPayCode(String channelPayCode) {
		this.channelPayCode = channelPayCode;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getPayCode() {
		return payCode;
	}

	public void setPayCode(String payCode) {
		this.payCode = payCode;
	}

	public String getProvBankCode() {
		return provBankCode;
	}

	public void setProvBankCode(String provBankCode) {
		this.provBankCode = provBankCode;
	}

	public String getProvBankName() {
		return provBankName;
	}

	public void setProvBankName(String provBankName) {
		this.provBankName = provBankName;
	}

	public String getProvAcctNo() {
		return provAcctNo;
	}

	public void setProvAcctNo(String provAcctNo) {
		this.provAcctNo = provAcctNo;
	}

	public String getProvAcctName() {
		return provAcctName;
	}

	public void setProvAcctName(String provAcctName) {
		this.provAcctName = provAcctName;
	}

	public Long getVotePriority() {
		return votePriority;
	}

	public void setVotePriority(Long votePriority) {
		this.votePriority = votePriority;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMtStartTime() {
		return mtStartTime;
	}

	public void setMtStartTime(String mtStartTime) {
		this.mtStartTime = mtStartTime;
	}

	public String getMtEndTime() {
		return mtEndTime;
	}

	public void setMtEndTime(String mtEndTime) {
		this.mtEndTime = mtEndTime;
	}

}
