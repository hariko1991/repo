package com.sfpay.core.service.clr;

import java.util.Date;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Isolation;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.core.cnst.ClearingDataStatus;
import com.sfpay.core.cnst.InfoCode;
import com.sfpay.core.dao.IBankBillDownloadDao;
import com.sfpay.core.dao.IBankRecon4CLRDao;
import com.sfpay.core.dao.IChannelInfoDao;
import com.sfpay.core.dao.IChannelPayDao;
import com.sfpay.core.dto.AccountRef4CLR;
import com.sfpay.core.dto.BankRecon4CLR;
import com.sfpay.core.dto.BankReconDataStatus;
import com.sfpay.core.dto.ChannelInfoDto;
import com.sfpay.core.dto.ChannelPayDto;
import com.sfpay.core.service.IClrBankReconService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 
 * 类说明：<br>
 * 清算系统：抽取银行对账数据
 * 
 * </p>
 * 
 * @author 875504 CreateDate: 2017-05-02
 */
@Service
@HessianExporter("/clrBankReconService")
public class ClrBankReconServiceImpl implements IClrBankReconService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	private static final String CHANNEL_TYPE_CODE = "UPC";

	@Resource
	private IBankBillDownloadDao bankBillDownloadDao;

	@Resource
	private IBankRecon4CLRDao bankRecon4CLRDao;

	@Resource
	private IChannelInfoDao channelInfoDao;
	@Resource
	private IChannelPayDao channelPayDao;

	/**
	 * 方法说明：<br>
	 * 将银行对账文件数据抽取到对应的库表
	 * 
	 * @param bankRecon4CLR  银行对账实体
	 */
	@Override
	public String extractData4CLR(Date tradeDate, String bankCode, String channelOrgMerNo, String flag) {

		// ----start 清算系统添加-状态控制为单独事务，防止重对账并发
		ChannelInfoDto chnlInfo = null;
		try {
			chnlInfo = channelInfoDao.queryChannelInfo(bankCode);
			if (null == chnlInfo) {
				logger.error(String.format("查无可用的[%s]银行配置", bankCode));
				throw new ServiceException(InfoCode.NO_RECORD, "查无可用的银行配置：" + bankCode);
			}
			String rltStr = dealBankReconDataStatus(CHANNEL_TYPE_CODE, bankCode, channelOrgMerNo, tradeDate);
			if (!(StringUtils.isEmpty(rltStr))) {
				logger.warn(rltStr);
				return rltStr;
			}
		} catch (Exception e) {
			logger.error(String.format("插入状态表记录[%s]异常"), e);
			throw new ServiceException(InfoCode.FAILURE, "插入状态表记录异常");
		}

		BankRecon4CLR bankRecon4CLR = buildBankRecon4CLR(tradeDate, bankCode, channelOrgMerNo);
		String channelTypeCode = bankRecon4CLR.getChannelTypeCode();
		String channelOrgCode = bankRecon4CLR.getChannelOrgCode();
		Date reconFileDate = bankRecon4CLR.getReconFileDate();
		String rfd = DateUtil.getDateString(reconFileDate, DateUtil.DATA_FORMAT_PATTERN_2);
		BankReconDataStatus bankReconDataStatus = new BankReconDataStatus();
		bankReconDataStatus.setReconFileDate(reconFileDate);
		bankReconDataStatus.setChannelTypeCode(channelTypeCode);
		bankReconDataStatus.setChannelOrgCode(channelOrgCode);
		bankReconDataStatus.setChannelOrgMerNo(channelOrgMerNo);
		bankReconDataStatus.setReconFileName(bankRecon4CLR.getReconFileName());
		try {
			// 针对空文件进行处理
			Long countBankBill = bankBillDownloadDao.countBankBillDownList(reconFileDate, channelOrgCode,
					channelOrgMerNo);
			if ("except".equals(flag)) {
				bankReconDataStatus.setStatus(ClearingDataStatus.FAILURE.getStatus());// "1"-已完成
				bankReconDataStatus.setDataRows(0L);
				// 更新状态表数据
				updateBankReconDataStatus(bankReconDataStatus);
				// 删除银行接口表数据
				deleteBankReconDataInterface(channelTypeCode, channelOrgCode, reconFileDate, channelOrgMerNo);

				String ret = String.format("[%s-%s]-[%s]日下载异常记录", channelTypeCode, channelOrgCode, rfd);
				logger.warn(ret);
				return ret;
			}
			if ((null == countBankBill || countBankBill == 0) && "common".equals(flag)) {
				// 文件若无交易数据，更新状态表数据（状态为“1[已完成]”，条数为“0”），并删除银行接口表数据
				bankReconDataStatus.setStatus(ClearingDataStatus.SUCCESS.getStatus());// "1"-已完成
				bankReconDataStatus.setDataRows(0L);
				// 更新状态表数据
				updateBankReconDataStatus(bankReconDataStatus);
				// 删除银行接口表数据
				deleteBankReconDataInterface(channelTypeCode, channelOrgCode, reconFileDate, channelOrgMerNo);

				String ret = String.format("[%s-%s]-[%s]日无交易记录", channelTypeCode, channelOrgCode, rfd);
				logger.warn(ret);
				return ret;
			}

			AccountRef4CLR account = findAccountRef4CLR(channelOrgCode);
			if (null == account) {
				String ret = String.format("[%s-%s]未配置结算账号或备付金账号信息,请先配置！", channelTypeCode, channelOrgCode);
				logger.error(ret);
				return ret;
			}

			boolean checkTime = findBankReconDataStatus(channelTypeCode, channelOrgCode, channelOrgMerNo,
					reconFileDate);
			if (checkTime) {
				// 日常记载：删除T-1的数据
				Date reconFileDateBefore = DateUtil.getBeforeDate(reconFileDate, 1);
				deleteBankReconDataInterface(channelTypeCode, bankReconDataStatus.getChannelOrgCode(),
						reconFileDateBefore, channelOrgMerNo);
			} else {
				// 重新加载：删除T日的数据
				deleteBankReconDataInterface(channelTypeCode, bankReconDataStatus.getChannelOrgCode(), reconFileDate,
						channelOrgMerNo);
			}
			// 执行接口数据插入
			try {
				bankRecon4CLRDao.buildBankReconDataInterface2(bankRecon4CLR, account);

			} catch (Exception e) {
				String ret = String.format("生成[%s-%s]-[%s]日银行对账数据接口表记录异常", channelTypeCode, channelOrgCode, rfd);
				logger.error(ret, e);
				bankReconDataStatus.setStatus(ClearingDataStatus.FAILURE.getStatus());// "0"-加载失败
				bankReconDataStatus.setDataRows(0L);
				updateBankReconDataStatus(bankReconDataStatus);
				return "";
			}
			bankReconDataStatus.setStatus(ClearingDataStatus.SUCCESS.getStatus());// "1"-已完成
			bankReconDataStatus.setDataRows(countBankBill);
			updateBankReconDataStatus(bankReconDataStatus);
			return "";
		} catch (Exception e) {
			logger.error("extractData4CLR---exception", e);
			bankReconDataStatus.setStatus(ClearingDataStatus.FAILURE.getStatus());// "0"-加载失败
			bankReconDataStatus.setDataRows(0L);
			updateBankReconDataStatus(bankReconDataStatus);
			return "";
		}
	}

	private BankRecon4CLR buildBankRecon4CLR(Date tradeDate, String bankCode, String channelOrgMerNo) {

		String td = DateUtil.getDateString(tradeDate, DateUtil.DATA_FORMAT_PATTERN_2);
		BankRecon4CLR bankRecon4CLR = new BankRecon4CLR();
		String channelTypeCode = CHANNEL_TYPE_CODE;// ????????????????
		String channelOrgCode = bankCode;
		String reconFileName = new StringBuilder(100).append(channelTypeCode).append("_").append(channelOrgCode)
				.append("_").append(td).toString();
		logger.info(String.format("开始抽取[%s]-[%s]日内部对账文件[%s]的数据到清算库表...", channelTypeCode, channelOrgCode, td));
		bankRecon4CLR.setChannelTypeCode(channelTypeCode);
		bankRecon4CLR.setChannelOrgCode(channelOrgCode);
		bankRecon4CLR.setChannelOrgMerNo(channelOrgMerNo);
		bankRecon4CLR.setCustomerBankCardType("");
		bankRecon4CLR.setReconFileDate(tradeDate);
		bankRecon4CLR.setReconFileName(reconFileName);
		return bankRecon4CLR;
	}

	/**
	 * 方法说明：<br>
	 * 判断是true第一次加载还是false重抽
	 */
	private boolean findBankReconDataStatus(String channelTypeCode, String channelOrgCode, String channelOrgMerNo,
			Date reconFileDate) {
		BankReconDataStatus brds = bankRecon4CLRDao.findBankReconDataStatus(channelTypeCode, channelOrgCode,
				reconFileDate, channelOrgMerNo);
		if (null == brds) {
			return true;
		}
		return false;
	}

	/**
	 * 方法说明：<br>
	 * 更新对应的银行对账状态数据
	 * 
	 * @param brds
	 */
	private void updateBankReconDataStatus(BankReconDataStatus brds) {
		String rfd = DateUtil.getDateString(brds.getReconFileDate(), DateUtil.DATA_FORMAT_PATTERN_2);
		logger.info(String.format("更新[%s-%s]-[%s]日银行对账数据状态为[%s]...", brds.getChannelTypeCode(),
				brds.getChannelOrgCode(), rfd, brds.getStatus()));
		try {
			bankRecon4CLRDao.updateBankReconDataStatus(brds);
		} catch (Exception e) {
			logger.error(String.format("更新[%s-%s]-[%s]日银行对账数据状态记录异常", brds.getChannelTypeCode(),
					brds.getChannelOrgCode(), rfd), e);
		}
	}

	/**
	 * 方法说明：<br>
	 * 	删除对应的银行对账接口数据记录
	 * 
	 * @param channelTypeCode
	 * @param channelOrgCode
	 * @param reconFileDate
	 */
	private void deleteBankReconDataInterface(String channelTypeCode, String channelOrgCode, Date reconFileDate,
			String channelOrgMerNo) {
		String rfd = DateUtil.getDateString(reconFileDate, DateUtil.DATA_FORMAT_PATTERN_2);
		logger.info(String.format("删除[%s-%s]-[%s]日银行对账接口数据记录...", channelTypeCode, channelOrgCode, rfd));
		try {
			bankRecon4CLRDao.deleteBankReconDataInterface(channelTypeCode, channelOrgCode, reconFileDate,
					channelOrgMerNo);
		} catch (Exception e) {
			logger.error(String.format("删除[%s-%s]-[%s]日银行对账接口数据记录异常", channelTypeCode, channelOrgCode, rfd), e);
		}
	}

	/**
	 * 方法说明：<br>
	 * 	 查找结算账号和备付金账号信息
	 * @param bankCode
	 * @param cardType
	 * @return
	 */
	private AccountRef4CLR findAccountRef4CLR(String bankCode) {
		logger.info(String.format("查询[%s]备付金账号和结算账号信息...", bankCode));
		AccountRef4CLR account = new AccountRef4CLR();
		ChannelPayDto chnlPay = null;
		try {
			chnlPay = channelPayDao.queryChannelPayByChnlCode(bankCode);
			if (null == chnlPay) {
				logger.error(String.format("查无可用的[%s]银行配置", bankCode));
				throw new ServiceException(InfoCode.NO_RECORD, "查无可用的银行配置：" + bankCode);
			}
		} catch (Exception e) {
			logger.error(String.format("查询[%s]备付金账号和结算账号信息异常", bankCode), e);
		}
		account.setProvBankCode(chnlPay.getProvBankCode());
		account.setProvBankAccountNo(chnlPay.getProvAcctNo());
		account.setSettlBankCode(chnlPay.getProvBankCode());
		account.setSettlBankAccountNo(chnlPay.getProvAcctNo());
		return account;
	}

	@Override
	@Transactional(isolation = Isolation.READ_COMMITTED, propagation = Propagation.REQUIRES_NEW, rollbackFor = Exception.class)
	public String dealBankReconDataStatus(String channelTypeCode, String channelOrgCode, String channelOrgMerNo,
			Date reconFileDate) throws ServiceException {
		String td = DateUtil.getDateString(reconFileDate, DateUtil.DATA_FORMAT_PATTERN_2);
		String reconFileName = new StringBuilder(100).append(channelTypeCode).append("_").append(channelOrgCode)
				.append("_").append(td).toString();
		// 根据条件查询到状态表数据,查询不到则插入;查询到了判断状态是否可进行对账操作
		BankReconDataStatus brds = findBankReconDataStatus(channelTypeCode, channelOrgCode, reconFileDate,
				channelOrgMerNo);
		if (brds == null) {
			// 插入状态表数据
			BankReconDataStatus bankReconDataStatus = new BankReconDataStatus();
			bankReconDataStatus.setReconFileDate(reconFileDate);
			bankReconDataStatus.setChannelTypeCode(channelTypeCode);
			bankReconDataStatus.setChannelOrgCode(channelOrgCode);
			bankReconDataStatus.setChannelOrgMerNo(channelOrgMerNo);
			bankReconDataStatus.setReconFileName(reconFileName);
			// if(checkTime){
			bankReconDataStatus.setStatus(ClearingDataStatus.DOING.getStatus());// "2"-加载中
			// }else{
			// bankReconDataStatus.setStatus(ClearingDataStatus.AGAINDO.getStatus());//"3"-重新加载
			// }
			bankReconDataStatus.setDataRows(0L);
			createBankReconDataStatus(bankReconDataStatus);
		} else {
			if (ClearingDataStatus.DOING.getStatus().equals(brds.getStatus())
					|| ClearingDataStatus.AGAINDO.getStatus().equals(brds.getStatus())) {
				String ret = String.format("正在加载[%s-%s-%s]-[%s]日的银行对账数据，请稍后再试！", channelTypeCode, channelOrgCode,
						channelOrgMerNo, reconFileDate);
				return ret;
			}
		}
		return null;
	}

	/**
	 * 方法说明：<br>
	 * 查找对应的银行对账状态数据
	 * 
	 * @param channelTypeCode
	 * @param channelOrgCode
	 * @param reconFileDate
	 * @return
	 */
	private BankReconDataStatus findBankReconDataStatus(String channelTypeCode, String channelOrgCode,
			Date reconFileDate, String channelOrgMerNo) {
		String rfd = DateUtil.getDateString(reconFileDate, DateUtil.DATA_FORMAT_PATTERN_2);
		logger.info(String.format("查询[%s-%s-%s]-[%s]日银行对账数据状态记录...", channelTypeCode, channelOrgCode, channelOrgMerNo,
				rfd));
		BankReconDataStatus brds = null;
		try {
			brds = bankRecon4CLRDao.findBankReconDataStatus(channelTypeCode, channelOrgCode, reconFileDate,
					channelOrgMerNo);
		} catch (Exception e) {
			logger.error(String.format("查询[%s-%s-%s]-[%s]日银行对账数据状态记录异常", channelTypeCode, channelOrgCode,
					channelOrgMerNo, rfd), e);
		}
		return brds;
	}

	/**
	 * 方法说明：<br>
	 * 插入对应的银行对账状态数据
	 * 
	 * @param brds 
	 */
	private void createBankReconDataStatus(BankReconDataStatus brds) {
		String rfd = DateUtil.getDateString(brds.getReconFileDate(), DateUtil.DATA_FORMAT_PATTERN_2);
		logger.info(String.format("插入[%s-%s-%s]-[%s]日银行对账数据状态记录...", brds.getChannelTypeCode(),
				brds.getChannelOrgCode(), brds.getChannelOrgMerNo(), rfd));
		try {
			bankRecon4CLRDao.buildBankReconDataStatus(brds);
		} catch (Exception e) {
			logger.error(String.format("插入[%s-%s-%s]-[%s]日银行对账数据状态记录异常", brds.getChannelTypeCode(),
					brds.getChannelOrgCode(), brds.getChannelOrgMerNo(), rfd), e);
		}
	}

}
