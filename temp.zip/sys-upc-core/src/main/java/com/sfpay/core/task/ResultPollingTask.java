package com.sfpay.core.task;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.cnst.ConfigKeyEnum;
import com.sfpay.core.dto.UpcPayInfoDto;
import com.sfpay.core.service.IChannelInfoService;
import com.sfpay.core.service.IPayInfoCoreService;
import com.sfpay.core.service.thread.PayQueryAndNotifyThread;
import com.sfpay.core.service.thread.RefundQueryAndNotifyThread;
import com.sfpay.core.util.ConfigKeyUtils;
import com.sfpay.core.util.DateUtils;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.cnst.TradeTypeCnst;

/**
 * 请求结果状态轮询任务（支付结果 和 退款结果）
 * 
 * @author 719811
 * 
 */
@Service("resultPollingTask")
public class ResultPollingTask {
	private static final Logger LOGGER = LoggerFactory.getLogger(ResultPollingTask.class);

	private static final String RESULT_POLLING_WHEN_LONG = "120";

	private ExecutorService executor = Executors.newCachedThreadPool();

	@Resource
	IPayInfoCoreService payInfoCoreService;

	@Resource
	private IChannelInfoService channelInfoService;

	private Map<String, Object> getPayQueryParam(List<String> channelCodeList, Date startTime, Date endTime) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put(SqlCnst.START_TIME, DateUtils.format(startTime));
		paramMap.put(SqlCnst.END_TIME, DateUtils.format(endTime));
		paramMap.put(SqlCnst.TARGET_STATUS, StatusCnst.TRADING);
		paramMap.put(SqlCnst.TRADE_TYPE, TradeTypeCnst.TRADE_TYPE_PAY);

		paramMap.put(SqlCnst.CHANNEL_CODE_LIST, channelCodeList);
		return paramMap;
	}

	private Map<String, Object> getRefundQueryParam(List<String> channelCodeList, Date startTime, Date endTime) {
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put(SqlCnst.START_TIME, DateUtils.format(startTime));
		paramMap.put(SqlCnst.END_TIME, DateUtils.format(endTime));
		paramMap.put(SqlCnst.TARGET_STATUS, StatusCnst.REFUND_PROC);
		paramMap.put(SqlCnst.TRADE_TYPE, TradeTypeCnst.TRADE_TYPE_REFUND);
		paramMap.put(SqlCnst.CHANNEL_CODE_LIST, channelCodeList);
		return paramMap;
	}

	public final void execute() {
		try {
			LOGGER.info("开始执行轮询请求结果任务");
			List<String> channelCodeList = channelInfoService.queryChannelCodeList();
			Date nowTime = new Date();
			int minute = ConfigKeyUtils.getConfigKeyParam(ConfigKeyEnum.REQ_RESULT_POLLING_WHEN_LONG,
					RESULT_POLLING_WHEN_LONG);
			Date startTime = ConfigKeyUtils.getQueryTime(nowTime, minute);
			Date endTime = ConfigKeyUtils.getQueryTime(nowTime, 2);
			try {
				// 支付信息
				List<UpcPayInfoDto> payInfoList = payInfoCoreService
						.queryPayInfoList(getPayQueryParam(channelCodeList, startTime, endTime));
				LOGGER.info("execute() ,要处理的轮询银行结果的支付条数:{}", payInfoList.size());
				if (CollectionUtils.isNotEmpty(payInfoList)) {
					executor.execute(new PayQueryAndNotifyThread(payInfoList, 1));
				}
			} catch (Exception e) {
				LOGGER.error("执行支付结果轮询异常 .", e);
			}

			try {
				// 支付信息
				List<UpcPayInfoDto> payInfoList = payInfoCoreService
						.queryPayInfoList(getRefundQueryParam(channelCodeList, startTime, endTime));
				LOGGER.info("execute() ,要处理的轮询银行结果的退款条数:{}", payInfoList.size());
				if (CollectionUtils.isNotEmpty(payInfoList)) {
					executor.execute(new RefundQueryAndNotifyThread(payInfoList, 1));
				}
			} catch (Exception e) {
				LOGGER.error("执行退款结果轮询异常 .", e);
			}

			LOGGER.info("结束执行轮询请求结果任务");
		} catch (Exception e) {
			LOGGER.error("进行轮询请求结果任务异常", e);
		}
	}

}
