/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.stereotype.Component;

/**
 * 类说明：<br>
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2016-9-19
 */
@Component
public class SpringContextHolder implements ApplicationContextAware, DisposableBean {

	private static ApplicationContext applicationContext;

	private static Logger LOGGER = LoggerFactory.getLogger(SpringContextHolder.class);

	public static ApplicationContext getApplicationContext() {
		assertContextInjected();
		return applicationContext;
	}

	@SuppressWarnings("unchecked")
	public static <T> T getBean(String name) {
		assertContextInjected();
		return (T) applicationContext.getBean(name);
	}

	public static <T> T getBean(Class<T> requiredType) {
		assertContextInjected();
		return applicationContext.getBean(requiredType);
	}

	public static void clearHolder() {
		LOGGER.debug("clear SpringContextHolder ApplicationContext:" + applicationContext);
		applicationContext = null;
	}

	@Override
	public void setApplicationContext(ApplicationContext applicationContext) {
		LOGGER.debug("Inject applicationContext to SpringContextHolder:{}", applicationContext);

		if (SpringContextHolder.applicationContext != null) {
			LOGGER.warn("replace the applicationContext,the old applicationContext is:"
					+ SpringContextHolder.applicationContext);
		} else {
			SpringContextHolder.applicationContext = applicationContext;
		}

	}

	@Override
	public void destroy() throws Exception {
		SpringContextHolder.clearHolder();
	}

	private static void assertContextInjected() {
		if (applicationContext == null) {
			throw new IllegalStateException("applicationContext have not injected, please define it");
		}
	}
}