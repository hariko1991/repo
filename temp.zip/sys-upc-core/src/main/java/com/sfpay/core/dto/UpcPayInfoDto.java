package com.sfpay.core.dto;

import java.io.Serializable;
import java.util.Date;

import com.sfpay.front.cnst.CharCnst;

public class UpcPayInfoDto implements Serializable {

	private static final long serialVersionUID = -2747125981968550768L;
	/** ID SEQ_UPC_PAY_INFO */
	private Long id;
	/** 支付渠道类别编码 */
	private String channelCategoryCode;
	/** 支付渠道编码 */
	private String channelCode;
	/** 商户号 */
	private String mchNo;
	/** 渠道商户号 */
	private String channelMchNo;
	/** 支付流水号 年月日+10位SEQ_PAY_NO */
	private String payNo;
	/** 商户订单号 */
	private String mchOrderNo;
	/** 请求第三方订单号 */
	private String reqOrderNo;
	/** 第三方响应订单号 */
	private String rtnOrderNo;
	/** 是否使用商户号请求你第三方 Y:是N：否 */
	private String useMchnoReq;
	/** 系统来源 HHT：巴枪 JHPAY：聚合支付 */
	private String systemSource;
	/** PAY:支付，PAY_REFUND:退款 */
	private String tradeType;
	/** 交易金额单位（分） */
	private Long tradeAmt;
	/** 交易手续费, 单位:分 */
	private Long tradeFee;
	/** RMB：人民币(分) */
	private String ccy;
	/** 交易开始时间 */
	private Date beginTime;
	/** 交易结束时间 */
	private Date endTime;
	/**
	 * 状态 INIT未支付、TRADING交易进行中、SUCCESS交易成功、FAILURE交易失败、CLOSE交易关闭
	 * REFUND_PROC：退款处理中 REFUND_SUCC:退款成功
	 */
	private String status;
	/** 支付银行类型编码 */
	private String payBankType;
	/** 通知顺手付后台地址 */
	private String mchNotifyUrl;
	/** 回调顺手付前台地址 */
	private String callbackSfUrl;
	/** 原支付流水号 撤消、退款时用 */
	private String oldPayNo;
	/** 原第三方订单号 */
	private String oldRtnOrderNo;
	/** 原商户订单号 */
	private String oldMchOrderNo;
	/** 返回错误码 */
	private String rtnCode;
	/** 错误信息 */
	private String rtnMsg;
	/** 备注 */
	private String remark;
	/** 创建日期 */
	private Date createTime;
	/** 更新日期 */
	private Date updateTime;
	/** MQ通知状态 Y:已通知：N:未通知 */
	private String notifyFlag;
	/** 支付商品展示url，对应支付宝showurl */
	private String productUrl;
	/** 商品名称 */
	private String productName;
	/** 商品描述 */
	private String productDesc;
	/** 二维码地址 */
	private String qrCode;
	/** upp订单号 */
	private String uppOrderNo;
	/** old upp订单号 */
	private String oldUppOrderNo;
	/** 券编码 */
	private String voucherCode;
	/** 会员号*/
	private Long memberNo;
	/**是否开发票，Y：开发票*/
	private String receipt = CharCnst.NO_FLAG;
	/**
	 * APPEND_BUS_TYPE  附加业务类型 RESUPPLY补单 REFUND退款 默认为 NORMAL 无附加业务类型
	 */
	private String appendBusType = "NORMAL";
	/**原请求订单号 */
	private String oldReqOrderNo;
	/**银行对应的渠道订单号：微信渠道交易订单号，支付宝渠道交易订单号 */
	private String channelNo;
	/**支付渠道编码:ALIPAY,WX**/
	private String payCode;
	/**
	 * 银行渠道编码（WE、微众银行，CMBC、民生银行  等等）
	 */
	private String bankChannelCode;
	
	/**
	 * 支付方式:JSPRECREATE一码付（公众号）支付,BARCODE付款码（条码付）支付,SCANCODE扫码付支付,APP应用APP支付等
	 */
	private String payMode;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getMchNo() {
		return mchNo;
	}

	public void setMchNo(String mchNo) {
		this.mchNo = mchNo;
	}

	public String getChannelMchNo() {
		return channelMchNo;
	}

	public void setChannelMchNo(String channelMchNo) {
		this.channelMchNo = channelMchNo;
	}

	public String getPayNo() {
		return payNo;
	}

	public void setPayNo(String payNo) {
		this.payNo = payNo;
	}

	public String getMchOrderNo() {
		return mchOrderNo;
	}

	public void setMchOrderNo(String mchOrderNo) {
		this.mchOrderNo = mchOrderNo;
	}

	public String getReqOrderNo() {
		return reqOrderNo;
	}

	public void setReqOrderNo(String reqOrderNo) {
		this.reqOrderNo = reqOrderNo;
	}

	public String getRtnOrderNo() {
		return rtnOrderNo;
	}

	public void setRtnOrderNo(String rtnOrderNo) {
		this.rtnOrderNo = rtnOrderNo;
	}

	public String getUseMchnoReq() {
		return useMchnoReq;
	}

	public void setUseMchnoReq(String useMchnoReq) {
		this.useMchnoReq = useMchnoReq;
	}

	public String getSystemSource() {
		return systemSource;
	}

	public void setSystemSource(String systemSource) {
		this.systemSource = systemSource;
	}

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

	public Long getMemberNo() {
		return memberNo;
	}

	public void setMemberNo(Long memberNo) {
		this.memberNo = memberNo;
	}

	public Long getTradeAmt() {
		return tradeAmt;
	}

	public void setTradeAmt(Long tradeAmt) {
		this.tradeAmt = tradeAmt;
	}

	public Long getTradeFee() {
		return tradeFee;
	}

	public void setTradeFee(Long tradeFee) {
		this.tradeFee = tradeFee;
	}

	public String getCcy() {
		return ccy;
	}

	public void setCcy(String ccy) {
		this.ccy = ccy;
	}

	public Date getBeginTime() {
		return beginTime;
	}

	public void setBeginTime(Date beginTime) {
		this.beginTime = beginTime;
	}

	public Date getEndTime() {
		return endTime;
	}

	public void setEndTime(Date endTime) {
		this.endTime = endTime;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getPayBankType() {
		return payBankType;
	}

	public void setPayBankType(String payBankType) {
		this.payBankType = payBankType;
	}

	public String getMchNotifyUrl() {
		return mchNotifyUrl;
	}

	public void setMchNotifyUrl(String mchNotifyUrl) {
		this.mchNotifyUrl = mchNotifyUrl;
	}

	public String getCallbackSfUrl() {
		return callbackSfUrl;
	}

	public void setCallbackSfUrl(String callbackSfUrl) {
		this.callbackSfUrl = callbackSfUrl;
	}

	public String getOldPayNo() {
		return oldPayNo;
	}

	public void setOldPayNo(String oldPayNo) {
		this.oldPayNo = oldPayNo;
	}

	public String getOldRtnOrderNo() {
		return oldRtnOrderNo;
	}

	public void setOldRtnOrderNo(String oldRtnOrderNo) {
		this.oldRtnOrderNo = oldRtnOrderNo;
	}

	public String getOldMchOrderNo() {
		return oldMchOrderNo;
	}

	public void setOldMchOrderNo(String oldMchOrderNo) {
		this.oldMchOrderNo = oldMchOrderNo;
	}

	public String getRtnCode() {
		return rtnCode;
	}

	public void setRtnCode(String rtnCode) {
		this.rtnCode = rtnCode;
	}

	public String getRtnMsg() {
		return rtnMsg;
	}

	public void setRtnMsg(String rtnMsg) {
		this.rtnMsg = rtnMsg;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public String getNotifyFlag() {
		return notifyFlag;
	}

	public void setNotifyFlag(String notifyFlag) {
		this.notifyFlag = notifyFlag;
	}

	public String getProductUrl() {
		return productUrl;
	}

	public void setProductUrl(String productUrl) {
		this.productUrl = productUrl;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDesc() {
		return productDesc;
	}

	public void setProductDesc(String productDesc) {
		this.productDesc = productDesc;
	}

	public String getQrCode() {
		return qrCode;
	}

	public void setQrCode(String qrCode) {
		this.qrCode = qrCode;
	}

	public String getChannelCategoryCode() {
		return channelCategoryCode;
	}

	public void setChannelCategoryCode(String channelCategoryCode) {
		this.channelCategoryCode = channelCategoryCode;
	}

	public String getUppOrderNo() {
		return uppOrderNo;
	}

	public void setUppOrderNo(String uppOrderNo) {
		this.uppOrderNo = uppOrderNo;
	}

	public String getOldUppOrderNo() {
		return oldUppOrderNo;
	}

	public void setOldUppOrderNo(String oldUppOrderNo) {
		this.oldUppOrderNo = oldUppOrderNo;
	}

	public String getVoucherCode() {
		return voucherCode;
	}

	public void setVoucherCode(String voucherCode) {
		this.voucherCode = voucherCode;
	}

	public String getReceipt() {
		return receipt;
	}

	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

	public String getAppendBusType() {
		return appendBusType;
	}

	public void setAppendBusType(String appendBusType) {
		this.appendBusType = appendBusType;
	}

	public String getOldReqOrderNo() {
		return oldReqOrderNo;
	}

	public void setOldReqOrderNo(String oldReqOrderNo) {
		this.oldReqOrderNo = oldReqOrderNo;
	}

	public String getChannelNo() {
		return channelNo;
	}

	public void setChannelNo(String channelNo) {
		this.channelNo = channelNo;
	}

	public String getPayCode() {
		return payCode;
	}

	public void setPayCode(String payCode) {
		this.payCode = payCode;
	}

	public String getBankChannelCode() {
		return bankChannelCode;
	}

	public void setBankChannelCode(String bankChannelCode) {
		this.bankChannelCode = bankChannelCode;
	}

	public String getPayMode() {
		return payMode;
	}

	public void setPayMode(String payMode) {
		this.payMode = payMode;
	}
}
