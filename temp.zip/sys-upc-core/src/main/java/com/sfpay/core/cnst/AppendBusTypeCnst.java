package com.sfpay.core.cnst;

public class AppendBusTypeCnst {
	/**
	 * 退款类型
	 */
	public static final String APPEND_BUS_TYPE_REFUND = "REFUND";
	/**
	 * 正常
	 */
	public static final String APPEND_BUS_TYPE_NORMAL = "NORMAL";
	/**
	 * 补单类型
	 */
	public static final String APPEND_BUS_TYPE_RESUPPLY = "RESUPPLY";
}
