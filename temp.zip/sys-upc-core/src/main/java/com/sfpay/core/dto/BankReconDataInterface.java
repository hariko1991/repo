/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.dto;

import java.util.Date;

/**
 * 类说明：<br>
 * <p>银行对账数据接口
 * 详细描述：<br>
 * </p>
 * 创建人：sfhq636 谢志宏   2015-12-25<br>
 * update by 837782 刘为  2015-12-26
 */
public class BankReconDataInterface extends ClrBaseField{
	private static final long serialVersionUID = -7984459141316428354L;
	/**
	 * 对账流水号 和银行/银联/第三方支付机构交互时请求的流水号
	 */
	private String reconSn;
	/**
	 * 交易时间 格式yyyymmddhh24miss
	 */
	private Date tradeTime;
	/**
	 * 备付金银行编号,收款/付款使用备付金账号所属的银行英文名称缩写,如:ICBC
	 */
	private String provBankCode;
	/**
	 * 备付金账号
	 */
	private String provBankAccountNo; 
	/**
	 * 客户银行账号   
	 */
	private String customerBankAccountNo;
	/**
	 * 客户银行卡类型
	 */
	private String customerBankCardType;
	/**
	 * 通道机构号机构号 
	 */
	private String channelOrgNo;
	/**
	 * 通道机构商户号
	 */
	private String channelOrgMerNo;
	/**
	 * 结算银行账号
	 */
	private String settlBankAccountNo;
	/**
	 * 结算银行编码
	 */
	private String settlBankCode;
	/**
	 * 交易类型  支付:PAYMENT/退款:REFUND/冲正:CORRECT/代扣DEBIT/撤销 CANCEL
	 */
	private String tradeType;
	/**
	 * 币种
	 */
	private String ccy;
	/**
	 * 交易金额
	 */
	private Long tradeAmt;
	/**
	 * 手续费
	 */
	private Long fee;
	/**
	 * 对账文件名称
	 */
	private String reconFileName;
	/**
	 * 对账文件日期
	 */
	private Date reconFileDate;
	
	public String getReconSn() {
		return reconSn;
	}
	public void setReconSn(String reconSn) {
		this.reconSn = reconSn;
	}
	public Date getTradeTime() {
		return tradeTime;
	}
	public void setTradeTime(Date tradeTime) {
		this.tradeTime = tradeTime;
	}
	public String getCustomerBankAccountNo() {
		return customerBankAccountNo;
	}
	public void setCustomerBankAccountNo(String customerBankAccountNo) {
		this.customerBankAccountNo = customerBankAccountNo;
	}
	public String getCustomerBankCardType() {
		return customerBankCardType;
	}
	public void setCustomerBankCardType(String customerBankCardType) {
		this.customerBankCardType = customerBankCardType;
	}
	public String getChannelOrgNo() {
		return channelOrgNo;
	}
	public void setChannelOrgNo(String channelOrgNo) {
		this.channelOrgNo = channelOrgNo;
	}
	public String getChannelOrgMerNo() {
		return channelOrgMerNo;
	}
	public void setChannelOrgMerNo(String channelOrgMerNo) {
		this.channelOrgMerNo = channelOrgMerNo;
	}
	public String getTradeType() {
		return tradeType;
	}
	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}
	public String getCcy() {
		return ccy;
	}
	public void setCcy(String ccy) {
		this.ccy = ccy;
	}
	public Long getTradeAmt() {
		return tradeAmt;
	}
	public void setTradeAmt(Long tradeAmt) {
		this.tradeAmt = tradeAmt;
	}
	public Long getFee() {
		return fee;
	}
	public void setFee(Long fee) {
		this.fee = fee;
	}
	public String getReconFileName() {
		return reconFileName;
	}
	public void setReconFileName(String reconFileName) {
		this.reconFileName = reconFileName;
	}
	public Date getReconFileDate() {
		return reconFileDate;
	}
	public void setReconFileDate(Date reconFileDate) {
		this.reconFileDate = reconFileDate;
	}
	public String getProvBankCode() {
		return provBankCode;
	}
	public void setProvBankCode(String provBankCode) {
		this.provBankCode = provBankCode;
	}
	public String getProvBankAccountNo() {
		return provBankAccountNo;
	}
	public void setProvBankAccountNo(String provBankAccountNo) {
		this.provBankAccountNo = provBankAccountNo;
	}
	public String getSettlBankAccountNo() {
		return settlBankAccountNo;
	}
	public void setSettlBankAccountNo(String settlBankAccountNo) {
		this.settlBankAccountNo = settlBankAccountNo;
	}
	public String getSettlBankCode() {
		return settlBankCode;
	}
	public void setSettlBankCode(String settlBankCode) {
		this.settlBankCode = settlBankCode;
	}
}
