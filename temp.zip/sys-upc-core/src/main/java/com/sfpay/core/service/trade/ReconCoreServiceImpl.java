/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service.trade;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.dao.IBankBillDownloadDao;
import com.sfpay.core.dao.IChannelReconFileDao;
import com.sfpay.core.dao.IMerchantInfoDao;
import com.sfpay.core.dto.BankBillDownloadInt;
import com.sfpay.core.dto.ChannelReconFileDto;
import com.sfpay.core.dto.MerchantInfoDto;
import com.sfpay.core.service.IClrBankReconService;
import com.sfpay.core.service.IReconCoreService;
import com.sfpay.core.util.DateUtils;
import com.sfpay.core.util.LoadStaticDataUtil;
import com.sfpay.core.util.SFTPUtils;
import com.sfpay.core.util.SpringContextHolder;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework2.exception.ServiceException;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.cnst.DateCnst;
import com.sfpay.front.cnst.EncodingCnst;
import com.sfpay.front.cnst.FunctionCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.ReconCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.function.Function;
import com.sfpay.front.util.SfpayFileUtils;
import com.sfpay.front.util.SfpayLineIterator;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月7日
 */
@Service("reconCoreService")
public class ReconCoreServiceImpl implements IReconCoreService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ReconCoreServiceImpl.class);
	private static final String FLAG_COMMON = "common";
	private static final String FLAG_EXCEPT = "except";

	@Resource
	private LoadStaticDataUtil loadStaticDataUtil;
	@Resource
	private IMerchantInfoDao merchantInfoDao;
	@Resource
	private IChannelReconFileDao channelReconFileDao;
	@Resource
	private IBankBillDownloadDao bankBillDownLoadDao;
	@Resource
	private IClrBankReconService clrBankReconService;

	@Override
	public void downloadReconFile(String uqNo, ChannelReconFileDto reconFile) {
		String logMsg = String.format("[%s]通道编码[%s],商户号[%s],对账日期[%s],所属[%s]下载对账文件", uqNo, reconFile.getChannelCode(),
				reconFile.getBillMchNo(), reconFile.getFileDate(), reconFile.getPayCode());
		LOGGER.info("{}下载对账文件", logMsg);

		Map<String, String> reqMap = new HashMap<String, String>();
		Map<String, String> updateMap = new HashMap<String, String>();
		updateMap.put(ReconCnst.BILL_MCH_NO, reconFile.getBillMchNo());
		updateMap.put(SqlCnst.CHANNEL_CODE, reconFile.getChannelCode());
		updateMap.put(SqlCnst.PAY_CODE, reconFile.getPayCode());
		reqMap.put(ReconCnst.BILL_MCH_NO, reconFile.getBillMchNo());
		reqMap.put(ReconCnst.CHANNEL_CODE, reconFile.getChannelCode());
		reqMap.put(ReconCnst.PAY_CODE, reconFile.getPayCode());
		reqMap.put(ReconCnst.FILE_DATE, DateUtils.format(reconFile.getFileDate(), DateCnst.YYYYMMDD));
		reqMap.put(ReconCnst.EXT_ARG, reconFile.getExtArg());
		reqMap.put(ReconCnst.FILE_NAME, reconFile.getFileName());

		if (ReconCnst.RECON_STATUS_FAILURE.equals(reconFile.getStatus())) {
			updateMap.put(SqlCnst.ORIGINAL_STATUS, ReconCnst.RECON_STATUS_FAILURE);
			updateMap.put(SqlCnst.TARGET_STATUS, ReconCnst.RECON_STATUS_INIT);
			int count = channelReconFileDao.updateReconFile(updateMap, reconFile.getFileDate());
			LOGGER.info("{}由于数据库状态为失败,需要更新为初始,更新条数[{}]", logMsg, count);
		}

		MerchantInfoDto merchantInfo = merchantInfoDao.queryUniqueMerchantInfo(reqMap);
		Map<String, String> extMap = loadStaticDataUtil.initCommonExtMap(reqMap.get(MapCnst.CHANNEL_CODE));
		if (null != merchantInfo) {
			extMap.put(MapCnst.ENCRYPT_ID, merchantInfo.getEncryptId());
			extMap.put(MapCnst.PUBLIC_KEY, merchantInfo.getPublicKey());
		}

		String functionName = extMap.get(MapCnst.FUNCTION_NAME);
		boolean update = false;
		try {
			Map<String, String> respMap = ((Function) SpringContextHolder.getBean(functionName)).getResp(uqNo,
					FunctionCnst.DOWNLOAD_BILL_FUNCTION, reqMap, extMap);
			LOGGER.info("{}返回内容[{}]", logMsg, respMap);
			if (StatusCnst.SUCCESS.equals(respMap.get(MapCnst.RTN_CODE))) {

			} else {
				update = true;
				updateMap.put(SqlCnst.TARGET_STATUS, ReconCnst.RECON_STATUS_FAILURE);
				updateMap.put(SqlCnst.REMARK, respMap.get(SqlCnst.REMARK));
			}
		} catch (Exception e) {
			LOGGER.error("{}异常", logMsg, e);
			update = true;
			updateMap.put(SqlCnst.TARGET_STATUS, ReconCnst.RECON_STATUS_FAILURE);
		}

		updateMap.put(SqlCnst.ORIGINAL_STATUS, ReconCnst.RECON_STATUS_INIT);

		if (update) {
			int count = channelReconFileDao.updateReconFile(updateMap, reconFile.getFileDate());
			LOGGER.info("{}更新数据库记录条数[{}]", logMsg, count);
		}
		LOGGER.info("{}下载完成", logMsg);

	}

	@Override
	public void analysisReconFile(String uqNo, ChannelReconFileDto reconFile) {
		String logMsg = String.format("[%s]通道编码[%s],商户号[%s],对账日期[%s],所属[%s]下载对账文件", uqNo, reconFile.getChannelCode(),
				reconFile.getBillMchNo(), reconFile.getFileDate(), reconFile.getPayCode());
		LOGGER.info("{}解析对账文件", logMsg);
		Map<String, String> updateMap = new HashMap<String, String>();
		updateMap.put(ReconCnst.BILL_MCH_NO, reconFile.getBillMchNo());
		updateMap.put(SqlCnst.CHANNEL_CODE, reconFile.getChannelCode());
		updateMap.put(SqlCnst.PAY_CODE, reconFile.getPayCode());

		SfpayLineIterator lineIterator = null;
		int dataRows = 0;
		String localFullName = null;
		try {
			int deleteCount = bankBillDownLoadDao.deleteBankBillDetail(updateMap, reconFile.getFileDate());
			LOGGER.info("{}解析对账文件前删除相同数据条数[{}]", logMsg, deleteCount);
			String remoteSftpPath = Property.getProperty(ReconCnst.SFTP_PATH) + reconFile.getChannelCode() + "/";
			SFTPUtils sftpClient = new SFTPUtils(Property.getProperty(ReconCnst.SFTP_IP),
					Integer.parseInt(Property.getProperty(ReconCnst.SFTP_PORT)),
					Property.getProperty(ReconCnst.SFTP_USER), Property.getProperty(ReconCnst.SFTP_PASS), 0);

			localFullName = Property.getProperty(ReconCnst.LOCAL_PATH) + reconFile.getChannelCode() + "/"
					+ reconFile.getFileName();
			sftpClient.download(remoteSftpPath, reconFile.getFileName(), localFullName);
			lineIterator = SfpayFileUtils.lineIterator(new File(localFullName), EncodingCnst.UTF_8);

			List<BankBillDownloadInt> bills = new ArrayList<BankBillDownloadInt>();
			String remoteLine = "";
			while (lineIterator.hasNext()) {
				dataRows++;
				remoteLine = lineIterator.nextLine();
				bills.add(convertLine(remoteLine, reconFile));
				if (bills.size()
						% (ReconCnst.FILE_NUMBER_PER_WRITE + CharCnst.NUMBER_ONE) == ReconCnst.FILE_NUMBER_PER_WRITE) {
					bankBillDownLoadDao.addBankBillDetailList(bills);
					bills = new ArrayList<BankBillDownloadInt>();
				}
			}
			if (CollectionUtils.isNotEmpty(bills)) {
				bankBillDownLoadDao.addBankBillDetailList(bills);
			}
			updateMap.put(ReconCnst.DATA_ROWS, String.valueOf(dataRows));
			updateMap.put(SqlCnst.TARGET_STATUS, ReconCnst.RECON_STATUS_ANALYSIS);
		} catch (Exception e) {
			updateMap.put(SqlCnst.TARGET_STATUS, ReconCnst.RECON_STATUS_FAILURE);
			updateMap.put(SqlCnst.REMARK, e.getMessage());
			LOGGER.error("{}解析对账文件异常", logMsg, e);
		} finally {
			SfpayLineIterator.closeQuietly(lineIterator);
			try {
				SfpayFileUtils.forceDelete(new File(localFullName));
			} catch (IOException e) {
				// ignore
			}
		}

		updateMap.put(SqlCnst.ORIGINAL_STATUS, ReconCnst.RECON_STATUS_DOWNLOAD);
		int count = channelReconFileDao.updateReconFile(updateMap, reconFile.getFileDate());
		LOGGER.info("{}更新数据库记录条数[{}]", logMsg, count);
	}

	private BankBillDownloadInt convertLine(String line, ChannelReconFileDto reconFile) throws Exception {
		String[] detail = line.split(ReconCnst.SPLIT_COMMA_SEPARATOR);
		BankBillDownloadInt bill = new BankBillDownloadInt();
		bill.setChannelOrgCode(reconFile.getChannelCode());
		bill.setChannelOrgMerNo(reconFile.getBillMchNo());
		bill.setTradeTime(DateUtils.parse(detail[0], DateCnst.YYYYMMDDHHMMSS));
		bill.setMerOrderNo(detail[1]);
		bill.setTradeSn(detail[2]);
		bill.setTradeType(detail[3]);
		bill.setTradeStatus(detail[4]);
		bill.setOrderAmt(Long.valueOf(detail[5]));
		bill.setMerAmt(Long.valueOf(detail[6]));
		bill.setFee(Long.valueOf(detail[7]));
		bill.setOtherFee(Long.valueOf(detail[8]));
		bill.setReconFileDate(reconFile.getFileDate());
		bill.setClrMchNo(reconFile.getPayCode());
		return bill;
	}

	@Override
	public void syncReconFile(String uqNo, ChannelReconFileDto reconFile) {
		String logMsg = String.format("[%s]通道编码[%s],商户号[%s],对账日期[%s],所属[%s]下载对账文件", uqNo, reconFile.getChannelCode(),
				reconFile.getBillMchNo(), reconFile.getFileDate(), reconFile.getPayCode());
		LOGGER.info("{}同步对账文件到清算", logMsg);
		int jugdgeCount = channelReconFileDao.judgeReconFile(reconFile.getChannelCode(), reconFile.getFileDate(),
				reconFile.getPayCode());
		LOGGER.info("{}同步对账文件到清算,非成功条数[{}]", logMsg, jugdgeCount);
		if (CharCnst.NUMBER_ZERO == jugdgeCount) {
			Map<String, String> updateMap = new HashMap<String, String>();
			updateMap.put(SqlCnst.CHANNEL_CODE, reconFile.getChannelCode());
			updateMap.put(SqlCnst.PAY_CODE, reconFile.getPayCode());
			updateMap.put(SqlCnst.TARGET_STATUS, ReconCnst.RECON_STATUS_SUCCESS);
			updateMap.put(SqlCnst.ORIGINAL_STATUS, ReconCnst.RECON_STATUS_ANALYSIS);
			try {
				clrBankReconService.extractData4CLR(reconFile.getFileDate(), reconFile.getChannelCode(),
						reconFile.getPayCode(), FLAG_COMMON);
				int count = channelReconFileDao.updateReconFile(updateMap, reconFile.getFileDate());
				LOGGER.info("{}同步对账文件到清算,更新为同步成功条数[{}]", logMsg, count);
			} catch (Exception e) {
				LOGGER.error("{}同步对账文件到清算异常", logMsg, e);
			}
		} else {
			String hour = Property.getProperty(ReconCnst.CLR_NOTIFY_TIME);
			String curHour = DateUtils.format(new Date(), DateCnst.HH);
			if (Long.valueOf(curHour) > Long.valueOf(hour)) {
				LOGGER.info("{}同步对账文件到清算指定时间,配置时间[{}],当前时间[{}]", new Object[] { logMsg, hour, curHour });
				try {
					clrBankReconService.extractData4CLR(reconFile.getFileDate(), reconFile.getChannelCode(),
							reconFile.getPayCode(), FLAG_EXCEPT);
					LOGGER.info("{}同步对账文件到清算指定时间,通知清算异常处理", logMsg);
				} catch (ServiceException e) {
					LOGGER.info("{}同步对账文件到清算指定时间,通知清算异常处理异常", logMsg, e);
				}
			} else {
				LOGGER.info("{}同步对账文件到清算,存在不成功的,不予以同步", logMsg);
			}
		}
	}

}
