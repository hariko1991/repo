/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.dao.IChannelPayDao;
import com.sfpay.core.dto.ChannelPayDto;
import com.sfpay.core.service.IChannelPayService;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月26日
 */
@Service("channelPayService")
public class ChannelPayServiceImpl implements IChannelPayService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ChannelPayServiceImpl.class);
	@Resource
	private IChannelPayDao channelPayDao;

	@Override
	public Map<String, ChannelPayDto> queryAllChannelPay() {
		List<ChannelPayDto> channelPays = channelPayDao.queryAllChannelPay();
		Map<String, ChannelPayDto> channelPayMap = new HashMap<String, ChannelPayDto>();

		if (CollectionUtils.isNotEmpty(channelPays)) {
			LOGGER.info("数据库中有道支持的支付渠道(例如:支付宝,微信)相关信息[{}]条", channelPays.size());
			for (ChannelPayDto channelPayDto : channelPays) {
				channelPayMap.put(channelPayDto.getChannelPayCode(), channelPayDto);
			}
			LOGGER.info("组装道支持的支付渠道(例如:支付宝,微信)映射完成,结果为[{}]", channelPayMap);
		} else {
			LOGGER.info("数据库中有道支持的支付渠道(例如:支付宝,微信)相关信息[0]条");
		}
		return channelPayMap;
	}

	@Override
	public ChannelPayDto queryChannelPay(String channelPayCode) {
		return channelPayDao.queryChannelPay(channelPayCode);
	}

}
