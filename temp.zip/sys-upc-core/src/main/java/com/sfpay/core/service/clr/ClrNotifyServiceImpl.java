/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service.clr;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.sfpay.clr.gw.sao.IClrReconNotifyService;
import com.sfpay.clr.gw.sao.domain.clr.ClrRefundReq;
import com.sfpay.core.cnst.ClrCnst;
import com.sfpay.core.service.IClrNotifyService;
import com.sfpay.core.util.HessianHelper;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.upc.gw.domain.sys.req.ClrNotifyReq;

/**
 * 类说明：<br>
 * 清算通知实现类
 * 
 * <p>
 * 详细描述：<br>
 * 退款结果通知
 * 
 * </p>
 * 
 * @author 830598 wu_jl
 * 
 *         CreateDate: 2017年5月10日
 */
@Service
@HessianExporter("/clrNotifyService")
public class ClrNotifyServiceImpl implements IClrNotifyService {

	private static final Logger logger = LoggerFactory.getLogger(ClrNotifyServiceImpl.class);

	@Value("${NOTIFY_CLR_REFUND_URL}")
	private String notifyRefundUrl;
	
	private ExecutorService executor = Executors.newCachedThreadPool();

	@Override
	public void notifyClrRefund(ClrNotifyReq notifyReq) {
		executor.execute(new AsynRefundNotify4Clear(notifyReq));
	}

	private class AsynRefundNotify4Clear implements Runnable {
		private ClrNotifyReq notifyReq;

		public AsynRefundNotify4Clear(ClrNotifyReq notifyReq) {
			this.notifyReq = notifyReq;
		}

		@Override
		public void run() {
			try {
				Thread.sleep(10000);
				execNotifyRefund4Clear(notifyReq);
			} catch (Exception e) {
				logger.error(String.format("通知清算系统退款结果异常"), e);
			}
		}

		private void execNotifyRefund4Clear(ClrNotifyReq notifyReq) {
			//String url = clrChannelDao.getParamVal(notifyReq.getChannelCode(), ClrCnst.CLEAR_REFUND_NOTIFY_URL);
			logger.info("通知清算平台退款结果[Hessian模式url:{}]...", notifyRefundUrl);
			try {
				IClrReconNotifyService service = HessianHelper.getHessian(IClrReconNotifyService.class, notifyRefundUrl, 5000,
						10000);
				ClrRefundReq req = new ClrRefundReq();
				req.setReturnCode(notifyReq.getRefundStatus());
				req.setChannelTypeCode(ClrCnst.CHNL_TYPE_CODE);
				req.setChannelOrgCode(notifyReq.getChannelCode());
				req.setAmt(notifyReq.getRefundAmt());
				req.setOriginalAmt(notifyReq.getOriAmt());
				req.setOriginalOrgSn(notifyReq.getOriReqOrderNo());
				req.setRefundSn(notifyReq.getUppOrderNo());
				service.notifyClrRefund(req);
				logger.info("通知清算平台退款结果:[{}]...", req);
			} catch (Exception e) {
				logger.error(String.format("通知清算平台退款结果异常[URL: %s]", notifyRefundUrl), e);
			}
		}
	}

}
