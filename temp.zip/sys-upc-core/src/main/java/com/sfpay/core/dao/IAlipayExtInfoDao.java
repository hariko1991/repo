package com.sfpay.core.dao;

import java.util.Map;

import com.sfpay.core.dto.UpcAlipayExt;

public interface IAlipayExtInfoDao {
	int saveUpcAlipayExt(UpcAlipayExt upcAlipayExt);
	int updateUpcAlipayExt(Map<String, String> paramMap);
}
