package com.sfpay.core.util;

import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.core.cnst.ConfigKeyEnum;
import com.sfpay.framework2.context.configuration.ConfigurerHolder;

public class ConfigKeyUtils {
	private static final Logger LOGGER = LoggerFactory.getLogger(ConfigKeyUtils.class);
	
	/**
	 * 获取配置中心的配置参数
	 * @param configKeyEnum  配置key
	 * @param defaultValue  默认值（必传 ， 切数字）
	 * @return
	 */
	public static int getConfigKeyParam(ConfigKeyEnum configKeyEnum , String defaultValue){
		//分钟
		int whenLong = Integer.parseInt(defaultValue);
		String configParam;
		try {
			configParam = ConfigurerHolder.get(configKeyEnum , defaultValue);
			LOGGER.info("获取配置中心每页处理条数:{} 条", configParam);
			if (StringUtils.isNotEmpty(configParam)) {
				whenLong = Integer.parseInt(configParam);
			}
		} catch (Exception e) {
			LOGGER.error("获取配置中心参数异常", e);
		}
		return whenLong;
	}
	
	/**
	 * 获取配置中心的配置参数
	 * @param configKeyEnum  配置key
	 * @param defaultValue  默认值（必传 ， 切数字）
	 * @return
	 */
	public static String getStringConfigKeyParam(ConfigKeyEnum configKeyEnum , String defaultValue){
		String configParam = defaultValue;
		try {
			configParam = ConfigurerHolder.get(configKeyEnum , defaultValue);
			LOGGER.info("获取配置中心配置参数值:{}", configParam);
		} catch (Exception e) {
			LOGGER.error("获取配置中心参数异常", e);
		}
		return configParam;
	}
	
	@SuppressWarnings("static-access")
	public static Date getQueryTime(Date nowTime , int minute) {
		Calendar calendar = new GregorianCalendar();
		calendar.setTime(nowTime);
		calendar.add(calendar.MINUTE, - minute);
		return calendar.getTime();
	}
}
