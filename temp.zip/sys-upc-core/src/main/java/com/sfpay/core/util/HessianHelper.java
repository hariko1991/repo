/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.core.cnst.InfoCode;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.client.SfpayHessianProxyFactory;

/**
 * 
 * 类说明：<br>
 * Hessian辅助类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 830598 wu_jl
 * 
 * CreateDate: 2017年5月9日
 */
public final class HessianHelper {
	private static final Logger logger = LoggerFactory.getLogger(HessianHelper.class);
	
	private HessianHelper() {
	}
	
	/**
	 * 方法说明：<br>
	 * 获取Hessian接口
	 * 
	 * @param clazz 服务接口
	 * @param url Hessian地址
	 */
	@SuppressWarnings("unchecked")
	public static <T> T getHessian(Class<T> clazz, String url, long conn, long read) throws Exception {
		if(null == clazz || StringUtils.isEmpty(url)) {
			throw new ServiceException(InfoCode.PARAM_NULL, "参数不能为空");
		}
		logger.info("Hessian URL: {}", url);
//		return (T)new HessianProxyFactory().create(clazz, url);
		SfpayHessianProxyFactory factory = new SfpayHessianProxyFactory();
		factory.setAppName("sys-upc-core");
		factory.setUseConnPool(false);
		factory.setConnectTimeout(conn);
		factory.setReadTimeout(read);
		return (T)factory.create(clazz, url);
	}
}
