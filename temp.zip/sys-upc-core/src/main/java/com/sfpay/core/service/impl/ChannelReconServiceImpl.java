/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service.impl;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.dao.IChannelReconFileDao;
import com.sfpay.core.dto.ChannelReconFileDto;
import com.sfpay.core.service.IChannelReconService;
import com.sfpay.core.service.IReconCoreService;
import com.sfpay.core.util.ReconUtil;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.front.cnst.ReconCnst;
import com.sfpay.front.cnst.SqlCnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月6日
 */
@Service("channelReconService")
public class ChannelReconServiceImpl implements IChannelReconService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ChannelReconServiceImpl.class);
	private static final List<String> DOWNLOAD_STATUS_LIST = Arrays
			.asList(new String[] { ReconCnst.RECON_STATUS_INIT, ReconCnst.RECON_STATUS_FAILURE });
	private static final List<String> ANALYSIS_STATUS_LIST = Arrays
			.asList(new String[] { ReconCnst.RECON_STATUS_DOWNLOAD });
	private static final List<String> RE_DOWNLOAD_STATUS_LIST = Arrays
			.asList(new String[] { ReconCnst.RECON_STATUS_INIT, ReconCnst.RECON_STATUS_FAILURE });
	private static final String NO_NEED_EXT_ARG = "NO NEED";
	private static final String NEED_EXT_ARG = "NEED";
	private static final String NEED_ARG_SUFFIX = "_NEED_ARG";

	@Resource
	private IChannelReconFileDao channelReconFileDao;
	@Resource
	private IReconCoreService reconCoreService;

	@Override
	public void initChannelReconFile(String uqNo, Date fileDate) {
		List<ChannelReconFileDto> reconFileList = channelReconFileDao.queryNeedInitReconFile(fileDate);
		LOGGER.info("[{}]准备初始化对账文件记录条数[{}]", uqNo, reconFileList.size());

		if (CollectionUtils.isEmpty(reconFileList)) {
			return;
		}

		for (ChannelReconFileDto reconFile : reconFileList) {
			ReconUtil.getReconFileName(reconFile, reconFile.getChannelCode());
			reconFile.setStatus(ReconCnst.RECON_STATUS_INIT);
			if (!NEED_EXT_ARG.equals(Property.getProperty(reconFile.getChannelCode() + NEED_ARG_SUFFIX))) {
				reconFile.setExtArg(NO_NEED_EXT_ARG);
			}
			LOGGER.info("[{}]初始化对账文件记录{}", uqNo, reconFile);
		}

		if (CollectionUtils.isNotEmpty(reconFileList)) {
			int count = channelReconFileDao.createChannelReconFile(reconFileList);
			LOGGER.info("[{}]初始化对账文件记录条数[{}]", uqNo, count);
		} else {
			LOGGER.info("[{}]初始化对账文件记录条数[{}],没有需要初始化的", uqNo);
		}
	}

	@Override
	public void downloadReconFile(String uqNo, Date fileDate) {
		List<ChannelReconFileDto> reconFileList = channelReconFileDao.queryAllReconFile(null, fileDate,
				DOWNLOAD_STATUS_LIST);
		LOGGER.info("[{}]准备下载对账文件记录条数[{}]", uqNo, reconFileList.size());
		for (ChannelReconFileDto reconFile : reconFileList) {
			if (StringUtils.isNotEmpty(reconFile.getExtArg())) {
				reconCoreService.downloadReconFile(uqNo, reconFile);
			} else {
				LOGGER.error("[{}]通道[{}]日期[{}]扩展参数为空,不予处理",
						new Object[] { uqNo, reconFile.getChannelCode(), reconFile.getFileDate() });
			}
		}
		LOGGER.info("[{}]准备下载对账文件完成", uqNo);
	}

	@Override
	public void analysisReconFile(String uqNo, Date fileDate) {
		List<ChannelReconFileDto> reconFileList = channelReconFileDao.queryAllReconFile(null, fileDate,
				ANALYSIS_STATUS_LIST);
		LOGGER.info("[{}]准备解析对账文件记录条数[{}]", uqNo, reconFileList.size());
		for (ChannelReconFileDto channelReconFile : reconFileList) {
			reconCoreService.analysisReconFile(uqNo, channelReconFile);
		}
		LOGGER.info("[{}]准备解析对账文件完成", uqNo);
	}

	@Override
	public void syncReconFile(String uqNo, Date fileDate) {
		List<ChannelReconFileDto> reconFileList = channelReconFileDao.queryNeedSynReconFile(fileDate);
		LOGGER.info("[{}]准备同步对账文件记录条数[{}]", uqNo, reconFileList.size());
		for (ChannelReconFileDto channelReconFile : reconFileList) {
			reconCoreService.syncReconFile(uqNo, channelReconFile);
		}
		LOGGER.info("[{}]准备同步对账文件完成", uqNo);
	}

	@Override
	public void reDownloadReconFile(String uqNo, ChannelReconFileDto reconFile) {
		String logMsg = String.format("[%s]通道编码[%s],对账日期[%s],商户号[%s]下载对账文件", uqNo, reconFile.getChannelCode(),
				reconFile.getFileDate(), reconFile.getPayCode());
		Map<String, String> updateMap = new HashMap<String, String>();
		updateMap.put(SqlCnst.CHANNEL_CODE, reconFile.getChannelCode());
		updateMap.put(SqlCnst.TARGET_STATUS, ReconCnst.RECON_STATUS_INIT);
		updateMap.put(SqlCnst.PAY_CODE, reconFile.getPayCode());
		int count = channelReconFileDao.updateReconFile(updateMap, reconFile.getFileDate());
		LOGGER.info("{}重新下载对账文件,初始化条数[{}]", logMsg, count);

		List<ChannelReconFileDto> reconFileList = channelReconFileDao.queryAllReconFile(updateMap,
				reconFile.getFileDate(), RE_DOWNLOAD_STATUS_LIST);
		LOGGER.info("[{}]准备下载对账文件记录条数[{}]", uqNo, reconFileList.size());
		for (ChannelReconFileDto channelReconFile : reconFileList) {
			reconCoreService.downloadReconFile(uqNo, channelReconFile);
		}
		LOGGER.info("[{}]准备下载对账文件完成", uqNo);
	}
}
