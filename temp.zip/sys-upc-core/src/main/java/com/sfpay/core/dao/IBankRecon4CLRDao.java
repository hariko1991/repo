/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.dao;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.core.dto.AccountRef4CLR;
import com.sfpay.core.dto.BankRecon4CLR;
import com.sfpay.core.dto.BankReconDataInterface;
import com.sfpay.core.dto.BankReconDataStatus;


/**
 * 类说明：<br>
 * 银行对账数据DAO接口
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author 875504  CreateDate: 2017-05-02
 * 
 */
public interface IBankRecon4CLRDao {
	
	/**
	 * 方法说明：<br>
	 * 生成银行对账数据状态记录
	 * 
	 * @param brds 
	 */
	public void buildBankReconDataStatus(BankReconDataStatus brds);
	
	/**
	 * 方法说明：<br>
	 * 	根据通道机构编码、通道类型编码、对账文件日期、渠道机构商户号  查找银行对账数据状态
	 * 
	 * @param channelTypeCode 通道类型编码
	 * @param channelOrgCode 通道机构编号
	 * @param reconFileDate 对账日期
	 * @param channelOrgMerNo 渠道机构商户号
	 * @return
	 */
	public BankReconDataStatus findBankReconDataStatus(@Param("channelTypeCode") String channelTypeCode, 
			@Param("channelOrgCode") String channelOrgCode, 
			@Param("reconFileDate") Date reconFileDate,
			@Param("channelOrgMerNo")String channelOrgMerNo);
	
	/**
	 * 方法说明：<br>
	 * 更新银行对账数据状态
	 * 
	 * @param brds 
	 */
	public void updateBankReconDataStatus(@Param("brds") BankReconDataStatus brds);
	/**
	 * 方法说明：<br>
	 * 更新银行对账数据状态[重置STATUS(2,3)>>0]
	 * 
	 * @param brds 
	 */
	public void updateBankReconDataStatus4Postern(@Param("brds") BankReconDataStatus brds);
	/**
	 * 方法说明：<br>
	 * 批量插入银行对账数据接口表 
	 *
	 * @param ls
	 */
	public void buildBankReconDataInterface(List<BankReconDataInterface> ls);
	
	/**
	 * 方法说明：<br>
	 * 批量插入银行对账数据接口表2 
	 *
	 * @param ls
	 */
	public void buildBankReconDataInterface2(@Param("bankRecon4CLR") BankRecon4CLR bankRecon4CLR,@Param("account")AccountRef4CLR account);
	/**
	 * 方法说明：<br>
	 * 删除银行对账数据接口表 (根据通道机构编码、通道类型编码、对账文件日期、渠道机构商户号删除)
	 * 
	 * @param brds 
	 */
	public void deleteBankReconDataInterface(@Param("channelTypeCode") String channelTypeCode, 
			@Param("channelOrgCode") String channelOrgCode, 
			@Param("reconFileDate") Date reconFileDate,
			@Param("channelOrgMerNo")String channelOrgMerNo);
	
	/**
	 * 方法说明：<br>
	 * 	根据银行编码、卡类型 查找账号信息（备付金账号和结算账号）
	 * @param bankCode
	 * @param cardType
	 * @return
	 */
	public String findAccountRef4CLRCode(@Param("bankCode") String bankCode);
	public String findAccountRef4CLRNo(@Param("bankCode") String bankCode);
	/**
	 * 查询商户号
	 * @param bankCode
	 * @return
	 */
	public String findChnlTypeMerNoFromArgConfig(@Param("bankCode") String bankCode);
}
