package com.sfpay.core.dto;


/**
 * 
 * @Description: 支付宝扩展数据
 * @date 2016-06-12 17:54:21
 * @version V1.0
 * @author 896728
 */

public class OtherPayExt extends BaseDto {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = -6842082215883947506L;
	private String payNo;
	private String mchOrderNo;
	private String channelCode;
	private String buyerId;
	private String buyerAccount;
	private String reqChannelSn;
	private String payMessage;
	public String getPayNo() {
		return payNo;
	}
	public void setPayNo(String payNo) {
		this.payNo = payNo;
	}
	public String getMchOrderNo() {
		return mchOrderNo;
	}
	public void setMchOrderNo(String mchOrderNo) {
		this.mchOrderNo = mchOrderNo;
	}
	public String getChannelCode() {
		return channelCode;
	}
	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}
	public String getBuyerId() {
		return buyerId;
	}
	public void setBuyerId(String buyerId) {
		this.buyerId = buyerId;
	}
	public String getBuyerAccount() {
		return buyerAccount;
	}
	public void setBuyerAccount(String buyerAccount) {
		this.buyerAccount = buyerAccount;
	}
	public String getReqChannelSn() {
		return reqChannelSn;
	}
	public void setReqChannelSn(String reqChannelSn) {
		this.reqChannelSn = reqChannelSn;
	}
	public String getPayMessage() {
		return payMessage;
	}
	public void setPayMessage(String payMessage) {
		this.payMessage = payMessage;
	}
}
