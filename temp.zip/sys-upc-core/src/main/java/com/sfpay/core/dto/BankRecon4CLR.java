package com.sfpay.core.dto;
import java.util.Date;
import java.util.List;

import com.sfpay.sypay.common.BaseEntity;

/**
 * 
 * @Description: 银行对账单下载
 * @date 2017-05-02 10:42:50
 * @version V1.0
 * @author 875504
 */

public class BankRecon4CLR extends BaseEntity {

	
	/**
	 * 
	 */
	private static final long serialVersionUID = 4287437592436513696L;
	/**
	 * 通道类型编码  快捷支付、网银支付、POS等（QPAY_DEBIT 快捷借/QPAY_CREDIT快捷贷)
	 */
	private String channelTypeCode;
	/**
	 * 通道机构编码 如ICBC
	 */
	private String channelOrgCode;
	/**
	 * 通道机构商户号
	 */
	private String channelOrgMerNo;
	/**
	 * 通道机构号机构号 
	 */
	private String channelOrgNo;
	
	/**
	 * 客户银行卡类型
	 */
	private String customerBankCardType;
	/**
	 * 对账文件日期
	 */
	private Date reconFileDate;
	/**
	 * 对账文件名称
	 */
	private String reconFileName;
	/**
	 * 银行对账文件数据
	 */
	List<BankBillDownloadInt> rs;
	
	public List<BankBillDownloadInt> getRs() {
		return rs;
	}
	public void setRs(List<BankBillDownloadInt> rs) {
		this.rs = rs;
	}
	public String getChannelTypeCode() {
		return channelTypeCode;
	}
	public void setChannelTypeCode(String channelTypeCode) {
		this.channelTypeCode = channelTypeCode;
	}
	public String getChannelOrgCode() {
		return channelOrgCode;
	}
	public void setChannelOrgCode(String channelOrgCode) {
		this.channelOrgCode = channelOrgCode;
	}
	public String getChannelOrgMerNo() {
		return channelOrgMerNo;
	}
	public void setChannelOrgMerNo(String channelOrgMerNo) {
		this.channelOrgMerNo = channelOrgMerNo;
	}
	public String getChannelOrgNo() {
		return channelOrgNo;
	}
	public void setChannelOrgNo(String channelOrgNo) {
		this.channelOrgNo = channelOrgNo;
	}
	public String getCustomerBankCardType() {
		return customerBankCardType;
	}
	public void setCustomerBankCardType(String customerBankCardType) {
		this.customerBankCardType = customerBankCardType;
	}
	public Date getReconFileDate() {
		return reconFileDate;
	}
	public void setReconFileDate(Date reconFileDate) {
		this.reconFileDate = reconFileDate;
	}
	public String getReconFileName() {
		return reconFileName;
	}
	public void setReconFileName(String reconFileName) {
		this.reconFileName = reconFileName;
	}

	
}
