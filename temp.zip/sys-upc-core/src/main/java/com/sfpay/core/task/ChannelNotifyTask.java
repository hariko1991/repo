package com.sfpay.core.task;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.cnst.AppendBusTypeCnst;
import com.sfpay.core.cnst.ConfigKeyEnum;
import com.sfpay.core.dto.UpcPayInfoDto;
import com.sfpay.core.service.IChannelInfoService;
import com.sfpay.core.service.INotifyResultService;
import com.sfpay.core.service.IPayInfoCoreService;
import com.sfpay.core.service.ITradeCoreService;
import com.sfpay.core.util.ConfigKeyUtils;
import com.sfpay.core.util.DateUtils;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.cnst.TradeTypeCnst;

/**
 * 通道补偿通知任务
 * @author 719811
 *
 */
@Service("channelNotifyTask")
public class ChannelNotifyTask {
	private static final Logger LOGGER = LoggerFactory.getLogger(ChannelNotifyTask.class);

	private static final String COMPENSATE_WHEN_LONG_120 = "120";

	private ExecutorService executor = Executors.newCachedThreadPool();

	@Resource
	IPayInfoCoreService payInfoCoreService;

	@Resource
	private IChannelInfoService channelInfoService;

	@Resource
	ITradeCoreService tradeCoreService;

	@Resource
	INotifyResultService notifyResultService;

	public final void execute() {
		try {
			LOGGER.info("开始执行补偿通知任务");
			Date nowTime = new Date();
			int minute = ConfigKeyUtils.getConfigKeyParam(ConfigKeyEnum.CHANNEL_COMPENSATE_NOTIFY_WHEN_LONG,
					COMPENSATE_WHEN_LONG_120);
			Date startTime = ConfigKeyUtils.getQueryTime(nowTime, minute);
			Date endTime = ConfigKeyUtils.getQueryTime(nowTime, 3);
			executor.execute(new PayNotify(startTime, endTime));
			executor.execute(new RefundNotify(startTime, endTime));
			LOGGER.info("结束执行补偿通知任务");
		} catch (Exception e) {
			LOGGER.error("进行补偿通知任务异常", e);
		}
	}

	private class PayNotify implements Runnable {

		private final Logger logger = LoggerFactory.getLogger(PayNotify.class);

		private Date startTime;
		private Date endTime;

		public PayNotify(Date startTime, Date endTime) {
			this.startTime = startTime;
			this.endTime = endTime;
		}

		@Override
		public void run() {
			LOGGER.info("开始执行支付补偿通知");
			List<UpcPayInfoDto> payInfoList = null;
			try {
				// 支付信息
				payInfoList = payInfoCoreService.queryPayInfoList(getQueryParam());
			} catch (Exception e) {
				logger.error("查询未通知的支付信息异常", e);
			}
			if (payInfoList != null && !payInfoList.isEmpty()) {
				logger.info("执行支付补偿通知数据 , 要处理的数据量 , payInfoList.size() : {} ", payInfoList.size());
				for (UpcPayInfoDto payInfo : payInfoList) {
					try {
						// 清算补单的数据不处理
						if (AppendBusTypeCnst.APPEND_BUS_TYPE_RESUPPLY.equals(payInfo.getAppendBusType())) {
							continue;
						}
						notifyResultService.notifyResult(payInfo);
					} catch (Exception e) {
						logger.error("执行支付结果轮询异常 , payNo : {} ", payInfo.getPayNo(), e);
					}
				}
			}
			LOGGER.info("结束执行支付补偿通知");
		}

		private Map<String, Object> getQueryParam() {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put(SqlCnst.START_TIME, DateUtils.format(startTime));
			paramMap.put(SqlCnst.END_TIME, DateUtils.format(endTime));
			paramMap.put(SqlCnst.TRADE_TYPE, TradeTypeCnst.TRADE_TYPE_PAY);
			List<String> channelCodeList = channelInfoService.queryChannelCodeList();
			paramMap.put(SqlCnst.CHANNEL_CODE_LIST, channelCodeList);
			List<String> statusList = new ArrayList<String>();
			statusList.add(StatusCnst.SUCCESS);
			statusList.add(StatusCnst.CLOSE);
			statusList.add(StatusCnst.FAILURE);
			paramMap.put(SqlCnst.STATUS_LIST, statusList);
			paramMap.put(SqlCnst.NOTIFY_FLAG, CharCnst.NO_FLAG);
			return paramMap;
		}
	}

	private class RefundNotify implements Runnable {

		private final Logger logger = LoggerFactory.getLogger(RefundNotify.class);

		private Date startTime;
		private Date endTime;

		public RefundNotify(Date startTime, Date endTime) {
			this.startTime = startTime;
			this.endTime = endTime;
		}

		@Override
		public void run() {
			LOGGER.info("开始执行退款补偿通知");
			List<UpcPayInfoDto> refundInfoList = null;
			try {
				// 退款信息
				refundInfoList = payInfoCoreService.queryPayInfoList(getQueryParam());
			} catch (Exception e) {
				logger.error("查询未通知的退款信息异常", e);
			}
			if (refundInfoList != null && !refundInfoList.isEmpty()) {
				logger.info("执行退款补偿通知数据 , 要处理的数据量 , refundInfoList.size() : {} ", refundInfoList.size());
				for (UpcPayInfoDto payInfo : refundInfoList) {
					try {
						if(!StatusCnst.REFUND_PROC.equals(payInfo.getStatus())){
							notifyResultService.notifyResult(payInfo);
						}
//						if(StatusCnst.REFUND_SUCC.equals(payInfo.getStatus())){
//							notifyResultService.notifyResult(payInfo);
//						}
//						if(AppendBusTypeCnst.APPEND_BUS_TYPE_REFUND.equals(payInfo.getAppendBusType())
//								&& StatusCnst.REFUND_FAIL.equals(payInfo.getStatus())){
//							notifyResultService.notifyResult(payInfo);
//						}
					} catch (Exception e) {
						logger.error("执行退款补偿通知异常 , payNo : {} ", payInfo.getPayNo(), e);
					}
				}
			}
			LOGGER.info("结束执行退款补偿通知");
		}

		private Map<String, Object> getQueryParam() {
			Map<String, Object> paramMap = new HashMap<String, Object>();
			paramMap.put(SqlCnst.START_TIME, DateUtils.format(startTime));
			paramMap.put(SqlCnst.END_TIME, DateUtils.format(endTime));
			paramMap.put(SqlCnst.TRADE_TYPE, TradeTypeCnst.TRADE_TYPE_REFUND);
			List<String> channelCodeList = channelInfoService.queryChannelCodeList();
			paramMap.put(SqlCnst.CHANNEL_CODE_LIST, channelCodeList);
			List<String> statusList = new ArrayList<String>();
			statusList.add(StatusCnst.REFUND_SUCC);
//			statusList.add(StatusCnst.CLOSE);
			statusList.add(StatusCnst.REFUND_FAIL);
			paramMap.put(SqlCnst.STATUS_LIST, statusList);
			paramMap.put(SqlCnst.NOTIFY_FLAG, CharCnst.NO_FLAG);
			return paramMap;
		}
	}
}
