/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service.hessian;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;

import org.apache.shiro.util.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.sfpay.core.cnst.AppendBusTypeCnst;
import com.sfpay.core.dto.UpcPayInfoDto;
import com.sfpay.core.service.INotifyResultService;
import com.sfpay.core.service.IPayInfoCoreService;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.upc.gw.domain.sys.req.ManualNotifyReq;
import com.sfpay.upc.gw.domain.sys.resp.ManualNotifyResp;
import com.sfpay.upc.gw.service.IManualNotifyService;
/**
 * 类说明：<br>
 * 补单通知服务类
 * 
 * <p>
 * 详细描述：<br>
 * 补单通知服务类
 * 
 * </p>
 * 
 * @author 01107265
 * 
 * CreateDate: 2017.09.11
 */
@HessianExporter
@Service("manualNotifyService")
public class ManualNotifyServiceImpl implements IManualNotifyService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ManualNotifyServiceImpl.class);
	@Resource
	private IPayInfoCoreService payInfoCoreService;
	
	@Resource
	private INotifyResultService notifyResultService;
	
	private static Set<String> statusSet = new HashSet<String>();
	
	public ManualNotifyServiceImpl() {
		statusSet.add(StatusCnst.SUCCESS);
		statusSet.add(StatusCnst.FAILURE);
		statusSet.add(StatusCnst.CLOSE);
		statusSet.add(StatusCnst.REFUND_SUCC);
		statusSet.add(StatusCnst.REFUND_FAIL);
	}
	
	private List<UpcPayInfoDto> queryPayInfoList(Map<String, Object> queryMap) {
		return payInfoCoreService.queryPayInfoList(queryMap);
	}
	
	@Override
	public ManualNotifyResp notifyResult(ManualNotifyReq req) {
		LOGGER.info("notifyResult entry!");
		ManualNotifyResp resp = new ManualNotifyResp();
		if (CollectionUtils.isEmpty(req.getUppOrderNos())) {
			LOGGER.info("notifyResult list emtpy!");
			resp.setMessage("通知的业务订单号集合是空");
			return resp;
		}
		Map<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put("uppOrderNoList", req.getUppOrderNos());
		List<UpcPayInfoDto> payInfos = queryPayInfoList(queryMap);
		if (payInfos == null || req.getUppOrderNos().size() != payInfos.size()) {
			resp.setMessage("存在不存在的业务订单号,请校验订单号!");
			return resp;			
		}
		List<UpcPayInfoDto> opInfos = Lists.newArrayList(); 
		for (UpcPayInfoDto payInfo : payInfos) {
			if (!statusSet.contains(payInfo.getStatus())) {
				LOGGER.error("status:{},不允许通知业务系统,需要通知支付号:{}", payInfo.getStatus(), payInfo.getPayNo());
				resp.setMessage(String.format("通知的业务订单状态不正确[%s]", payInfo.getUppOrderNo()) );
				return resp;
			}			
			if(!(StatusCnst.SUCCESS.equals(payInfo.getStatus()) ||
					StatusCnst.FAILURE.equals(payInfo.getStatus())||
					StatusCnst.REFUND_SUCC.equals(payInfo.getStatus())||
					(AppendBusTypeCnst.APPEND_BUS_TYPE_REFUND.equals(payInfo.getAppendBusType())
							&& StatusCnst.REFUND_FAIL.equals(payInfo.getStatus()))) ) {
				resp.getNoHandleList().add(payInfo.getUppOrderNo());//无需发起补偿通知
				continue;
			}
			opInfos.add(payInfo);
		}	
		for (UpcPayInfoDto payInfo : opInfos) {
			try {
				LOGGER.info("人工对交易中的订单重新发起查询,业务订单号{},支付信息处理前状态:{}", payInfo.getUppOrderNo(), payInfo.getStatus());
				notifyResultService.notifyResult(payInfo);
				resp.getSuccessList().add(payInfo.getUppOrderNo());
			} catch (Exception e) {
				LOGGER.error("通知发生异常  , 参数对象:{}", payInfo.getUppOrderNo(), e);
				resp.getFailedList().add(payInfo.getUppOrderNo());
			}
		}
		LOGGER.info("notifyResult exit!");
		return resp;
	}
}
