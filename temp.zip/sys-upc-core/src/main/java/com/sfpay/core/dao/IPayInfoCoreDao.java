/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sfpay.core.dto.UpcPayInfoDto;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月24日
 */
public interface IPayInfoCoreDao {
	/**
	 * 方法说明：<br>
	 * 保存支付信息到upc_pay_info表中
	 * @param payInfo
	 * @return int
	 */
	int createPayInfo(UpcPayInfoDto payInfo);

	/**
	 * 方法说明：<br>
	 * 获取付款编号
	 * @return String
	 */
	String getPayNo();
	
	/**
	 * 方法说明：<br>
	 * 获取付款编号
	 * @return String
	 */
	String getDynamicLengthPayNo(@Param("lengthNum") int lengthNum);
	
	/**
	 * 方法说明：<br>
	 * 根据参数信息更新upc_pay_info表
	 * @param paramMap
	 * @return int
	 */
	int updatePayInfo(Map<String, String> paramMap);
	
	/**
	 * 根据请求查询支付信息
	 * @param queryMap
	 * @return UpcPayInfo
	 */
	UpcPayInfoDto queryPayInfo(Map<String, Object> queryMap);
	
	/**
	 * 根据请求查询支付信息列表
	 * @param queryMap
	 * @return List<UpcPayInfo>
	 */
	List<UpcPayInfoDto> queryPayInfoList(Map<String, Object> queryMap);
	
	/**
	 * 方法说明：<br>
	 * 清算交易查询
	 * 
	 * @param chnlOrgCode
	 * @param chnlMerNo
	 * @param reconSn
	 * @return
	 */
	List<UpcPayInfoDto> queryUpcPayInfo4Clr(@Param("chnlOrgCode") String chnlOrgCode, @Param("chnlMerNo") String chnlMerNo, @Param("reconSn") String reconSn);

	/**
	 * 方法说明：<br>
	 * 清算补单
	 * 
	 * @param reconSn
	 * @param chnlOrgCode
	 * @param chnlMerNo
	 * @param databaseTime
	 * @return
	 */
	int buildClearResupply(@Param("reconSn")String reconSn, @Param("chnlOrgCode") String chnlOrgCode, @Param("databaseTime")Date databaseTime);
	
	
	List<UpcPayInfoDto> querySpecifyPayInfoList(@Param("endTime") Date endTime,
			@Param("reqMap") Map<String, String> reqMap, @Param("channelCodeList") List<String> channelCodeList);
}
