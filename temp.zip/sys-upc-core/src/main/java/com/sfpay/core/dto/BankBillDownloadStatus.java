package com.sfpay.core.dto;
import java.util.Date;

import com.sfpay.sypay.common.BaseEntity;

/**
 * 
 * 类说明：<br>
 * 银行对账单下载接口
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 875504 zhangnannan
 * 
 * CreateDate: 2017-5-3
 */

public class BankBillDownloadStatus extends BaseEntity {

	private static final long serialVersionUID = 9032379187261016703L;

	/**下载日期*/
	private Date reconFileDate;	
	/**组织机构号*/
	private String channelOrgCode;
	/**商户号*/
	private String channelOrgMerNo;
	/**总条数*/
	private Long dataRows;
	/**当前状态*/
	private String status;
	
	private String remark;

	private Date createTime;
	
	private Date updateTime;

	public Date getReconFileDate() {
		return reconFileDate;
	}

	public void setReconFileDate(Date reconFileDate) {
		this.reconFileDate = reconFileDate;
	}

	public String getChannelOrgCode() {
		return channelOrgCode;
	}

	public void setChannelOrgCode(String channelOrgCode) {
		this.channelOrgCode = channelOrgCode;
	}

	public String getChannelOrgMerNo() {
		return channelOrgMerNo;
	}

	public void setChannelOrgMerNo(String channelOrgMerNo) {
		this.channelOrgMerNo = channelOrgMerNo;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getDataRows() {
		return dataRows;
	}

	public void setDataRows(Long dataRows) {
		this.dataRows = dataRows;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	
}
