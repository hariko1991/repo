package com.sfpay.core.dto;

import com.sfpay.sypay.common.BaseEntity;

/**
 * 类说明：<br>
 * 账户实体（清算系统用）
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 * @author 875504 张男男
 * 
 * CreateDate: 2017-05-03
 */
public class AccountRef4CLR extends BaseEntity{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -8569321636825149975L;
	/**
	 * 通道机构编码 如ICBC
	 */
	private String channelOrgCode;
	/**
	 * 备付金银行编号,收款/付款使用备付金账号所属的银行英文名称缩写,如:ICBC
	 */
	private String provBankCode;
	/**
	 * 备付金账号
	 */
	private String provBankAccountNo; 
	/**
	 * 结算银行编码
	 */
	private String settlBankCode;
	/**
	 * 结算银行账号
	 */
	private String settlBankAccountNo;
	
	public String getChannelOrgCode() {
		return channelOrgCode;
	}
	public void setChannelOrgCode(String channelOrgCode) {
		this.channelOrgCode = channelOrgCode;
	}
	public String getProvBankCode() {
		return provBankCode;
	}
	public void setProvBankCode(String provBankCode) {
		this.provBankCode = provBankCode;
	}
	public String getProvBankAccountNo() {
		return provBankAccountNo;
	}
	public void setProvBankAccountNo(String provBankAccountNo) {
		this.provBankAccountNo = provBankAccountNo;
	}
	public String getSettlBankCode() {
		return settlBankCode;
	}
	public void setSettlBankCode(String settlBankCode) {
		this.settlBankCode = settlBankCode;
	}
	public String getSettlBankAccountNo() {
		return settlBankAccountNo;
	}
	public void setSettlBankAccountNo(String settlBankAccountNo) {
		this.settlBankAccountNo = settlBankAccountNo;
	}
	
}
