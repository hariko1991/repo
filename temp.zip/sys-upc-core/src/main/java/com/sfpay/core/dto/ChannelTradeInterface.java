/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.dto;

import java.util.Date;

/**
 * 
 * 类说明：<br>
 * 通道交易接口 详细描述
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 830598 wu_jl
 * 
 * CreateDate: 2017年5月2日
 */
public class ChannelTradeInterface extends ClrBaseField {

	private static final long serialVersionUID = -2787438300276983953L;
	/**
	 * 对账流水号 和银行/银联/第三方支付机构交互时请求的流水号
	 */
	private String reconSn;
	/**
	 * 交易时间 格式yyyymmddhh24miss
	 */
	private Date tradeTime;
	/**
	 * 备付金银行编号,收款/付款使用备付金账号所属的银行英文名称缩写,如:ICBC
	 */
	private String provBankCode;
	/**
	 * 备付金账号
	 */
	private String provBankAccountNo;
	/**
	 * 客户银行账号
	 */
	private String customerBankAccountNo;

	/**
	 * 客户银行卡类型 借记DEBIT/贷记CREDIT
	 */
	private String customerBankCardType;
	/**
	 * 通道机构号 金融机构分配给恒通的机构号
	 */
	private String channelOrgNo;
	/**
	 * 业务流水号
	 */
	private String bizSn;
	/**
	 * 原业务流水号
	 */
	private String oriBizSn;
	/**
	 * 上送机构流水号
	 */
	private String sendOrgSn;
	/**
	 * 原上送机构流水号 用于冲正
	 */
	private String oriSendOrgSn;
	/**
	 * 机构返回流水号
	 */
	private String orgBackSn;
	/**
	 * 原机构返回流水号 用于冲正
	 */
	private String oriOrgBackSn;
	/**
	 * 业务系统来源
	 */
	private String bizSysSrc;
	/**
	 * 通道交易类型 支付PAYMENT、退款REFUND
	 */
	private String channelTradeType;
	/**
	 * 币种
	 */
	private String ccy;
	/**
	 * 交易金额
	 */
	private Long tradeAmt;
	/**
	 * 交易状态 SUCCESS-成功 FAILURE-失败
	 */
	private String status;
	/**
	 * 结算银行账号
	 */
	private String settlBankAccountNo;
	/**
	 * 结算银行编码
	 */
	private String settlBankCode;

	public String getSettlBankCode() {
		return settlBankCode;
	}

	public void setSettlBankCode(String settlBankCode) {
		this.settlBankCode = settlBankCode;
	}

	public String getReconSn() {
		return reconSn;
	}

	public void setReconSn(String reconSn) {
		this.reconSn = reconSn;
	}

	public String getCustomerBankCardType() {
		return customerBankCardType;
	}

	public void setCustomerBankCardType(String customerBankCardType) {
		this.customerBankCardType = customerBankCardType;
	}

	public String getChannelOrgNo() {
		return channelOrgNo;
	}

	public void setChannelOrgNo(String channelOrgNo) {
		this.channelOrgNo = channelOrgNo;
	}

	public String getOriBizSn() {
		return oriBizSn;
	}

	public void setOriBizSn(String oriBizSn) {
		this.oriBizSn = oriBizSn;
	}

	public String getSendOrgSn() {
		return sendOrgSn;
	}

	public void setSendOrgSn(String sendOrgSn) {
		this.sendOrgSn = sendOrgSn;
	}

	public String getOriSendOrgSn() {
		return oriSendOrgSn;
	}

	public void setOriSendOrgSn(String oriSendOrgSn) {
		this.oriSendOrgSn = oriSendOrgSn;
	}

	public String getOrgBackSn() {
		return orgBackSn;
	}

	public void setOrgBackSn(String orgBackSn) {
		this.orgBackSn = orgBackSn;
	}

	public String getOriOrgBackSn() {
		return oriOrgBackSn;
	}

	public void setOriOrgBackSn(String oriOrgBackSn) {
		this.oriOrgBackSn = oriOrgBackSn;
	}

	public Date getTradeTime() {
		return tradeTime;
	}

	public void setTradeTime(Date tradeTime) {
		this.tradeTime = tradeTime;
	}

	public String getProvBankCode() {
		return provBankCode;
	}

	public void setProvBankCode(String provBankCode) {
		this.provBankCode = provBankCode;
	}

	public String getProvBankAccountNo() {
		return provBankAccountNo;
	}

	public void setProvBankAccountNo(String provBankAccountNo) {
		this.provBankAccountNo = provBankAccountNo;
	}

	public String getCustomerBankAccountNo() {
		return customerBankAccountNo;
	}

	public void setCustomerBankAccountNo(String customerBankAccountNo) {
		this.customerBankAccountNo = customerBankAccountNo;
	}

	public String getBizSn() {
		return bizSn;
	}

	public void setBizSn(String bizSn) {
		this.bizSn = bizSn;
	}

	public String getBizSysSrc() {
		return bizSysSrc;
	}

	public void setBizSysSrc(String bizSysSrc) {
		this.bizSysSrc = bizSysSrc;
	}

	public String getChannelTradeType() {
		return channelTradeType;
	}

	public void setChannelTradeType(String channelTradeType) {
		this.channelTradeType = channelTradeType;
	}

	public String getCcy() {
		return ccy;
	}

	public void setCcy(String ccy) {
		this.ccy = ccy;
	}

	public Long getTradeAmt() {
		return tradeAmt;
	}

	public void setTradeAmt(Long tradeAmt) {
		this.tradeAmt = tradeAmt;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSettlBankAccountNo() {
		return settlBankAccountNo;
	}

	public void setSettlBankAccountNo(String settlBankAccountNo) {
		this.settlBankAccountNo = settlBankAccountNo;
	}
}
