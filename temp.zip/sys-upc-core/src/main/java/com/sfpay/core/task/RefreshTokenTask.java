/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.task;

import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.util.LoadStaticDataUtil;
import com.sfpay.core.util.SpringContextHolder;
import com.sfpay.front.cnst.ChannelCnst;
import com.sfpay.front.cnst.FunctionCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.function.Function;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月16日
 */
@Service("refreshTokenTask")
public class RefreshTokenTask {
	private static final Logger LOGGER = LoggerFactory.getLogger(RefreshTokenTask.class);

	@Resource
	private LoadStaticDataUtil loadStaticDataUtil;

	public void execute() {
		long start = 0L;
		try {
			start = System.currentTimeMillis();
			LOGGER.info("refreshTokenTask——>start开始时间[{}]", start);
			Map<String, String> extMap = loadStaticDataUtil.initCommonExtMap(ChannelCnst.CHANNEL_WE);
			Map<String, String> respMap = ((Function) SpringContextHolder.getBean(extMap.get(MapCnst.FUNCTION_NAME)))
					.getResp(start + "", FunctionCnst.REFRESH_TOKEN_FUNCTION, null, extMap);
			LOGGER.info("refreshTokenTask返回结果{}", respMap);
		} catch (Exception e) {
			LOGGER.error("refreshTokenTask执行过程中异常", e);
		} finally {
			LOGGER.info("refreshTokenTask——>end,随机号[{}]耗时[{}]", start, (System.currentTimeMillis() - start));
		}
	}
}
