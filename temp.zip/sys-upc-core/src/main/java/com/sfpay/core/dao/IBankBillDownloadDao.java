package com.sfpay.core.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sfpay.core.dto.BankBillDownloadInt;

public interface IBankBillDownloadDao {

	int addBankBillDetailList(@Param("list") List<BankBillDownloadInt> list);

	int deleteBankBillDetail(@Param("reqMap") Map<String, String> reqMap, @Param("fileDate") Date fileDate);

	Long countBankBillDownList(@Param("reconFileDate") Date reconFileDate,
			@Param("channelOrgCode") String channelOrgCode, @Param("channelOrgMerNo") String channelOrgMerNo);
}
