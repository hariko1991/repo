package com.sfpay.core.dto;

import java.io.Serializable;
import java.util.Date;

public class UpcMonitorDto implements Serializable  {

	/**
	 * serialVersionUID
	 */
	private static final long serialVersionUID = 6600465048277949936L;
	
	private String channelCode;
	/**
	 * 类型：1、成功的，2、进行中的，3、失败的
	 */
	private int type ;
	private Date reqTime;
	
	public UpcMonitorDto(){}
	
	public UpcMonitorDto(String channelCode,Date reqTime){
		this.channelCode = channelCode;
		this.reqTime = reqTime;
	}
	
	public String getChannelCode() {
		return channelCode;
	}
	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public Date getReqTime() {
		return reqTime;
	}
	public void setReqTime(Date reqTime) {
		this.reqTime = reqTime;
	}
}
