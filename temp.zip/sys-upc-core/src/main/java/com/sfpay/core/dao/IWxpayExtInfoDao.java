package com.sfpay.core.dao;

import java.util.Map;

import com.sfpay.core.dto.UpcWxExt;

public interface IWxpayExtInfoDao {
	int saveUpcWxExt(UpcWxExt upcWxExt);
	int updateWxExt(Map<String, String> paramMap);
}
