/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.dto;

import java.util.Date;

/**
 * 类说明：<br>
 * <p>银行对账数据状态
 * 详细描述：<br>
 * </p>
 * 创建人：sfhq636 谢志宏   2015-12-25<br>
 * update by 837782 刘为  2015-12-26
 */
public class BankReconDataStatus extends ClrBaseField{

	private static final long serialVersionUID = -4275595782849333956L;
	/**
	 * 对账文件日期
	 */
	private Date reconFileDate;
	/**
	 * 对账文件编号
	 */
	private String reconFileName;
	/**
	 * 数据条数 
	 */
	private Long dataRows;
	/**
	 * 数据准备状态:加载失败0,已完成1，加载中2,重新加载 3
	 */
	private String status;
	
	public Date getReconFileDate() {
		return reconFileDate;
	}
	public void setReconFileDate(Date reconFileDate) {
		this.reconFileDate = reconFileDate;
	}
	public String getReconFileName() {
		return reconFileName;
	}
	public void setReconFileName(String reconFileName) {
		this.reconFileName = reconFileName;
	}
	public Long getDataRows() {
		return dataRows;
	}
	public void setDataRows(Long dataRows) {
		this.dataRows = dataRows;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
}
