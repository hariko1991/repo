/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.task;

import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.core.cnst.ClrCnst;
import com.sfpay.core.dao.IMerchantInfoDao;
import com.sfpay.core.dto.MerchantInfoDto;
import com.sfpay.core.service.IChannel4CLRService;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：<br>
 * 通道数据抽取到清算平台调度
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 830598 wu_jl
 * 
 * CreateDate: 2017年5月3日
 */
@Service("channel4CLRTask")
public class Channel4CLRTask {
	private static final Logger logger = LoggerFactory.getLogger(Channel4CLRTask.class);

	@Resource
	private IChannel4CLRService channel4ClrService;

	@Resource
	private IMerchantInfoDao merchantInfoDao;

	private ExecutorService executor = Executors.newCachedThreadPool();

	public void execute() throws ServiceException {
		Date tradeDate = DateUtil.getBeforeDate(new Date(), 1);
		try {
			List<MerchantInfoDto> merchantInfoList = merchantInfoDao.queryMerchantInfo4Clr();
			if (CollectionUtils.isEmpty(merchantInfoList)) {
				logger.error("查无可用银行列表");
				return;
			}
			logger.info("[{}]通道数据抽取到清算平台调度开始!", DateUtil.getDateString(tradeDate, DateUtil.DATA_FORMAT_PATTERN_2));

			for (MerchantInfoDto merchantInfo : merchantInfoList) {
				executor.execute(new AsynSend(tradeDate, merchantInfo.getChannelCode(), ClrCnst.CHNL_TYPE_CODE,
						merchantInfo.getPayCode()));
			}
			logger.info("[{}]通道数据抽取到清算平台调度结束!", DateUtil.getDateString(tradeDate, DateUtil.DATA_FORMAT_PATTERN_2));
		} catch (Exception e) {
			logger.error(String.format("查询平台可用银行列表异常"), e);
		}
	}

	private class AsynSend implements Runnable {
		private final Logger logger = LoggerFactory.getLogger(AsynSend.class);
		private Date tradeDate;
		private String chnlTypeCode;
		private String chnlOrgMchNo;
		private String bank;

		public AsynSend(Date tradeDate, String bank, String chnlTypeCode, String chnlOrgMchNo) {
			this.tradeDate = tradeDate;
			this.bank = bank;
			this.chnlTypeCode = chnlTypeCode;
			this.chnlOrgMchNo = chnlOrgMchNo;
		}

		@Override
		public void run() {
			try {
				channel4ClrService.synchChannelData(tradeDate, chnlTypeCode, bank, chnlOrgMchNo);
			} catch (Exception e) {
				String ret = String.format("通道数据抽取异常, 日期:[%s], 通道机构:[%s]",
						DateUtil.getDateString(tradeDate, DateUtil.DATA_FORMAT_PATTERN_2), bank);
				logger.error(ret, e);
			}
		}
	}

}
