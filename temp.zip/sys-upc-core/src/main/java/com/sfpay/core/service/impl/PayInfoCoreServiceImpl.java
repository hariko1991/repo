/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service.impl;

import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.dao.IAlipayExtInfoDao;
import com.sfpay.core.dao.IOtherPayExtInfoDao;
import com.sfpay.core.dao.IPayInfoCoreDao;
import com.sfpay.core.dao.IWxpayExtInfoDao;
import com.sfpay.core.dto.OtherPayExt;
import com.sfpay.core.dto.UpcAlipayExt;
import com.sfpay.core.dto.UpcPayInfoDto;
import com.sfpay.core.dto.UpcWxExt;
import com.sfpay.core.service.IPayInfoCoreService;
import com.sfpay.framework2.core.util.StringUtil;
import com.sfpay.framework2.exception.ServiceException;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.cnst.CurrencyTypeCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.PayCodeCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.cnst.TradeTypeCnst;
import com.sfpay.upc.enums.CurrencyType;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.enums.TradeType;
import com.sfpay.upc.gw.domain.sys.req.SysRefundReq;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月24日
 */
@Service("payInfoCoreService")
public class PayInfoCoreServiceImpl implements IPayInfoCoreService {
	private final Logger LOGGER = LoggerFactory.getLogger(PayInfoCoreServiceImpl.class);
	@Resource
	private IPayInfoCoreDao payInfoCoreDao;
	@Resource
	private IAlipayExtInfoDao alipayExtInfoDao;
	@Resource
	private IWxpayExtInfoDao wxpayExtInfoDao;
	@Resource
	private IOtherPayExtInfoDao otherPayExtInfoDao;

	@Override
	public UpcPayInfoDto createUpcPayInfo(String logMsg, Map<String, String> reqMap, Map<String, String> extMap) {
		LOGGER.info("{}保存数据库,请求参数:{}", logMsg, reqMap);

		UpcPayInfoDto payInfo = new UpcPayInfoDto();
		payInfo.setPayNo(payInfoCoreDao.getPayNo());
		payInfo.setChannelCategoryCode(reqMap.get(SqlCnst.PAY_CODE));
		payInfo.setChannelCode(StringUtil.isNullOrEmpty(reqMap.get(MapCnst.CHANNEL_CODE))
				? reqMap.get(MapCnst.BANK_CHANNEL_CODE) : reqMap.get(MapCnst.CHANNEL_CODE));
		payInfo.setMchNo(reqMap.get(SqlCnst.MCH_NO));
		payInfo.setChannelMchNo(extMap.get(MapCnst.CHANNEL_MCH_NO));
		payInfo.setMchOrderNo(reqMap.get(SqlCnst.MCH_ORDER_NO));
		payInfo.setUseMchnoReq(CharCnst.YES_FLAG);

		payInfo.setReqOrderNo(payInfo.getPayNo());

		payInfo.setTradeType(TradeTypeCnst.TRADE_TYPE_PAY);
		payInfo.setTradeFee(0L);
		payInfo.setTradeAmt(Long.valueOf(reqMap.get(SqlCnst.SRC_AMT)));
		payInfo.setSystemSource(reqMap.get(SqlCnst.SYSTEM_SOURCE));
		payInfo.setCcy(CurrencyTypeCnst.RMB);
		payInfo.setStatus(StatusCnst.INIT);

		payInfo.setUppOrderNo(reqMap.get(SqlCnst.BIZ_TRADE_NO));

		payInfo.setReceipt(reqMap.get(SqlCnst.RECEIPT));
		payInfo.setPayCode(reqMap.get(SqlCnst.PAY_CODE));
		payInfo.setBankChannelCode(reqMap.get(MapCnst.BANK_CHANNEL_CODE));
		payInfo.setPayMode(reqMap.get(MapCnst.PAY_MODE));
		int count = payInfoCoreDao.createPayInfo(payInfo);
		LOGGER.info("保存数据库{},结果:{}", logMsg, count);
		if (CharCnst.NUMBER_ONE != count) {
			LOGGER.error("保存数据库{},结果:{}", logMsg, count);
			throw new ServiceException(RtnCodeCnst.FAILURE_DB, "支付信息插入数据库结果不是1条");
		}

		this.initExInfo(payInfo);
		
		return payInfo;
	}

	private void initExInfo(UpcPayInfoDto payInfo){
		try{
			if(PayCodeCnst.PAY_CODE_ALIPAY.equals(payInfo.getPayCode())){
				UpcAlipayExt upcAlipayExt = new UpcAlipayExt();
				upcAlipayExt.setPayNo(payInfo.getPayNo());
				upcAlipayExt.setMchOrderNo(payInfo.getMchOrderNo());
				upcAlipayExt.setReqChannelSn(payInfo.getReqOrderNo());
				alipayExtInfoDao.saveUpcAlipayExt(upcAlipayExt);
			}else if(PayCodeCnst.PAY_CODE_WX.equals(payInfo.getPayCode())){
				UpcWxExt upcWxExt = new UpcWxExt();
				upcWxExt.setPayNo(payInfo.getPayNo());
				upcWxExt.setMchOrderNo(payInfo.getMchOrderNo());
				upcWxExt.setReqChannelSn(payInfo.getReqOrderNo());
				wxpayExtInfoDao.saveUpcWxExt(upcWxExt);
			}else{
				OtherPayExt otherPayExt = new OtherPayExt();
				otherPayExt.setPayNo(payInfo.getPayNo());
				otherPayExt.setMchOrderNo(payInfo.getMchOrderNo());
				otherPayExt.setReqChannelSn(payInfo.getReqOrderNo());
				otherPayExt.setChannelCode(payInfo.getBankChannelCode());
				otherPayExtInfoDao.saveOtherPayExt(otherPayExt);
			}
		}catch (Exception e) {
			LOGGER.error("保存扩展信息到数据库失败,payNo:{}", payInfo.getPayNo() , e);
		}
	}
	@Override
	public int updateUpcPayInfo(Map<String, String> respMap, Map<String, String> updateMap) {
		if (respMap != null && !respMap.isEmpty()) {
			updateMap.putAll(respMap);
		}
		int count = payInfoCoreDao.updatePayInfo(updateMap);
		if (CharCnst.NUMBER_ONE != count) {
			throw new ServiceException(RtnCodeCnst.FAILURE_DB, "支付信息更新结果不是1条");
		}
		return count;
	}

	@Override
	public UpcPayInfoDto queryPayInfo(Map<String, Object> queryMap) {
		return payInfoCoreDao.queryPayInfo(queryMap);
	}

	@Override
	public List<UpcPayInfoDto> queryPayInfoList(Map<String, Object> queryMap) {
		return payInfoCoreDao.queryPayInfoList(queryMap);
	}

	@Override
	public UpcPayInfoDto createRefundInfo(SysRefundReq payReq, UpcPayInfoDto upcPayInfo, Map<String, String> extMap) {

		UpcPayInfoDto payInfo = new UpcPayInfoDto();
		payInfo.setChannelCode(upcPayInfo.getChannelCode());
		payInfo.setMchNo(upcPayInfo.getMchNo());
		int lengthNum = StringUtil.isNullOrEmpty(extMap.get(MapCnst.PAY_NO_LENGTH_NUM))? 
				CharCnst.LENGTH_NUM : Integer.parseInt(extMap.get(MapCnst.PAY_NO_LENGTH_NUM));
		if(lengthNum == CharCnst.LENGTH_NUM){
			payInfo.setPayNo(payInfoCoreDao.getPayNo());
		}else{
			payInfo.setPayNo(payInfoCoreDao.getDynamicLengthPayNo((lengthNum-CharCnst.LENGTH_NUM_6)));
		}
		payInfo.setChannelMchNo(upcPayInfo.getChannelMchNo());
		payInfo.setMchOrderNo(StringUtil.isNullOrEmpty(payReq.getRefundMchOrderNo()) ? payInfo.getPayNo()
				: payReq.getRefundMchOrderNo());

		// 如果上游未上送退款商户订单号，通道自己生成一个，返回
		if (StringUtil.isNullOrEmpty(payReq.getRefundMchOrderNo())) {
			payReq.setRefundMchOrderNo(payInfo.getMchOrderNo());
		}

		payInfo.setUseMchnoReq("Y");
		payInfo.setReqOrderNo(payInfo.getPayNo());
		payInfo.setTradeType(TradeType.PAY_REFUND.name());
		payInfo.setTradeFee(0L);
		payInfo.setTradeAmt(payReq.getRefundAmt());
		payInfo.setSystemSource(upcPayInfo.getSystemSource());
		payInfo.setCcy(CurrencyType.RMB.name());
		payInfo.setStatus(TradeStatus.REFUND_PROC.name());
		payInfo.setMchNotifyUrl(upcPayInfo.getMchNotifyUrl());
		payInfo.setChannelCategoryCode(upcPayInfo.getChannelCategoryCode());
		payInfo.setUppOrderNo(payReq.getRefundBizTradeNo());
		payInfo.setOldUppOrderNo(upcPayInfo.getUppOrderNo());
		payInfo.setOldPayNo(upcPayInfo.getPayNo());
		payInfo.setOldMchOrderNo(upcPayInfo.getMchOrderNo());
		payInfo.setOldRtnOrderNo(upcPayInfo.getRtnOrderNo());
		payInfo.setAppendBusType(payReq.isSourceBizSystem() ? "NORMAL" : "REFUND");
		payInfo.setOldReqOrderNo(upcPayInfo.getReqOrderNo());
		payInfo.setPayCode(upcPayInfo.getPayCode());
		payInfo.setBankChannelCode(upcPayInfo.getBankChannelCode());
		payInfo.setPayMode(upcPayInfo.getPayMode());
		int count = payInfoCoreDao.createPayInfo(payInfo);
		LOGGER.info("退款信息保存数据库,结果:{}", count);
		if (CharCnst.NUMBER_ONE != count) {
			throw new ServiceException(RtnCodeCnst.FAILURE_DB, "支付信息插入数据库结果不是1条");
		}

		return payInfo;
	}

	@Override
	public List<UpcPayInfoDto> querySpecifyPayInfoList(Date endTime, Map<String, String> reqMap,
			List<String> channelCodeList) {
		return payInfoCoreDao.querySpecifyPayInfoList(endTime, reqMap, channelCodeList);
	}

	@Override
	public int updateUpcPayInfo(Map<String, String> respMap,
			Map<String, String> updateMap, boolean isUpdateExt, String payCode) {
		int count = this.updateUpcPayInfo(respMap, updateMap);
		if(isUpdateExt && StatusCnst.SUCCESS.equals(respMap.get(SqlCnst.TARGET_STATUS))){
			try{
				respMap.put(SqlCnst.PAY_NO, updateMap.get(SqlCnst.PAY_NO));
				if(PayCodeCnst.PAY_CODE_ALIPAY.equals(payCode)){
					alipayExtInfoDao.updateUpcAlipayExt(respMap);
				}else if(PayCodeCnst.PAY_CODE_WX.equals(payCode)){
					wxpayExtInfoDao.updateWxExt(respMap);
				}else {
					otherPayExtInfoDao.updateOtherPayExt(respMap);
				}
			}catch (Exception e) {
				LOGGER.error("更新扩展信息到数据库失败,payNo:{}", updateMap.get(SqlCnst.PAY_NO), e);
			}
		}
		return count;
	}

}
