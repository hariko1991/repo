package com.sfpay.core.service;

import com.sfpay.upc.gw.domain.sys.req.SysAddMerchantReq;
import com.sfpay.upc.gw.domain.sys.req.SysGetMerchantDetailReq;
import com.sfpay.upc.gw.domain.sys.req.SysUpdateMerchantReq;
import com.sfpay.upc.gw.domain.sys.resp.SysAddMerchantResp;
import com.sfpay.upc.gw.domain.sys.resp.SysGetMerchantDetailResp;
import com.sfpay.upc.gw.domain.sys.resp.SysUpdateMerchantResp;

public interface IMchCoreService {

	/**
	 * 民生通道--商户进件
	 * @param req
	 * @return AddMerchantResp
	 */
	public SysAddMerchantResp addMerchant(SysAddMerchantReq req);

	/**
	 * 查询民生通道商户信息
	 * @param req
	 * @return GetMerchantDetailResp
	 */
	public SysGetMerchantDetailResp getMerchantDetail(SysGetMerchantDetailReq req);

	/**
	 * 商户信息修改
	 * @param req
	 * @return UpdateMerchantResp
	 */
	public SysUpdateMerchantResp updateMerchant(SysUpdateMerchantReq req);

}
