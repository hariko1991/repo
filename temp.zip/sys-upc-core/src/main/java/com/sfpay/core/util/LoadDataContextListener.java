package com.sfpay.core.util;

import java.util.Date;

import javax.servlet.ServletContextEvent;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.web.context.ContextLoaderListener;

import com.sfpay.front.cnst.DateCnst;

/**
 * 
 * 类说明：<br>
 * spring容器启动完成后,加载数据
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年3月7日
 */
public class LoadDataContextListener extends ContextLoaderListener {

	private static final Logger LOGGER = LoggerFactory.getLogger(LoadDataContextListener.class);

	public void contextInitialized(ServletContextEvent event) {
		super.contextInitialized(event);
		LOGGER.info("加载spring容器完成" + DateUtils.format(new Date(), DateCnst.YYYY_MM_DD_HH24_MM_SS_SSSSSS));
		publishLoadDataEven();
	}

	private void publishLoadDataEven() {
		getCurrentWebApplicationContext().publishEvent(new LoadDataApplicationEvent(this));
	}
}
