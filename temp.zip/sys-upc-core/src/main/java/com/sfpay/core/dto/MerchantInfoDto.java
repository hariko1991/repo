/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.dto;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月22日
 */
public class MerchantInfoDto extends BaseDto {

	private static final long serialVersionUID = -3416539232470959172L;

	private String channelCode;

	private String payCode;

	private String mchNo;

	private String mchName;

	private String channelMchNo;

	private String subMchNo;

	private String billMchNo;

	private String encryptId;

	private String publicKey;

	private String status;

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getPayCode() {
		return payCode;
	}

	public void setPayCode(String payCode) {
		this.payCode = payCode;
	}

	public String getMchNo() {
		return mchNo;
	}

	public void setMchNo(String mchNo) {
		this.mchNo = mchNo;
	}

	public String getMchName() {
		return mchName;
	}

	public void setMchName(String mchName) {
		this.mchName = mchName;
	}

	public String getChannelMchNo() {
		return channelMchNo;
	}

	public void setChannelMchNo(String channelMchNo) {
		this.channelMchNo = channelMchNo;
	}

	public String getSubMchNo() {
		return subMchNo;
	}

	public void setSubMchNo(String subMchNo) {
		this.subMchNo = subMchNo;
	}

	public String getBillMchNo() {
		return billMchNo;
	}

	public void setBillMchNo(String billMchNo) {
		this.billMchNo = billMchNo;
	}

	public String getEncryptId() {
		return encryptId;
	}

	public void setEncryptId(String encryptId) {
		this.encryptId = encryptId;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
