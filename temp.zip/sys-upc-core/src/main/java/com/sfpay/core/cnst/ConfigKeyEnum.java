package com.sfpay.core.cnst;

import com.sfpay.framework2.context.configuration.ConfigKey;

public enum ConfigKeyEnum implements ConfigKey {

	// 请求民生银行是否传入商户订单号
	REQ_CMBC_IS_AFFERENT_MCH_ORDER_NO("REQ_CMBC_IS_AFFERENT_MCH_ORDER_NO"),
	
	/**
	 * 请求结果轮询时长（处理 近多长时间的）
	 */
	REQ_RESULT_POLLING_WHEN_LONG("REQ_RESULT_POLLING_WHEN_LONG"),
	
	/**
	 * 渠道补偿通知时长（处理 近多长时间的）
	 */
	CHANNEL_COMPENSATE_NOTIFY_WHEN_LONG("CHANNEL_COMPENSATE_NOTIFY_WHEN_LONG"),
	
	/**
	 * 条码付输入支付密码结果查询调度任务（处理 近多长时间的）
	 */
	REAL_TIME_POLLING_TASK_WHEN_LONG("REAL_TIME_POLLING_TASK_WHEN_LONG"),
	
	/**
	 * upc监控开关（ON:开启，OFF:关闭）
	 */
	UPC_MONITOR_ON_OFF("UPC_MONITOR_ON_OFF"),
	/**
	 * upc监控配置参数{"NETWORK_URL":"http://localhost:8080/upc-mon/notify/result","READ_TIME_OUT":"200","CONN_TIME_OUT":"200"}
	 */
	UPC_MONITOR_CONFIG_PARAM("UPC_MONITOR_CONFIG_PARAM");
	

	private ConfigKeyEnum(String key) {
		this.key = key;
	}

	private String key;

	@Override
	public String getKey() {
		return key;
	}
}
