package com.sfpay.core.dao;

import java.util.Map;

import com.sfpay.core.dto.OtherPayExt;

public interface IOtherPayExtInfoDao {
	int saveOtherPayExt(OtherPayExt otherPayExt);
	int updateOtherPayExt(Map<String, String> paramMap);
}
