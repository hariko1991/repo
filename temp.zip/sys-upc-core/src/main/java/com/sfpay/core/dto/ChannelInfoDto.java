/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.dto;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月22日
 */
public class ChannelInfoDto extends BaseDto {

	private static final long serialVersionUID = -457830871379388797L;

	private String channelCode;
	private String channelName;
	private String functionName;
	private Long votePriority;
	private String recType;
	private String status;
	private String mtStartTime;
	private String mtEndTime;
	
	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getChannelName() {
		return channelName;
	}

	public void setChannelName(String channelName) {
		this.channelName = channelName;
	}

	public String getFunctionName() {
		return functionName;
	}

	public void setFunctionName(String functionName) {
		this.functionName = functionName;
	}

	public Long getVotePriority() {
		return votePriority;
	}

	public void setVotePriority(Long votePriority) {
		this.votePriority = votePriority;
	}

	public String getRecType() {
		return recType;
	}

	public void setRecType(String recType) {
		this.recType = recType;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getMtStartTime() {
		return mtStartTime;
	}

	public void setMtStartTime(String mtStartTime) {
		this.mtStartTime = mtStartTime;
	}

	public String getMtEndTime() {
		return mtEndTime;
	}

	public void setMtEndTime(String mtEndTime) {
		this.mtEndTime = mtEndTime;
	}
}
