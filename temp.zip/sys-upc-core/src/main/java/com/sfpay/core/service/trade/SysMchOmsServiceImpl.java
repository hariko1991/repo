/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service.trade;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.dao.IChannelInfoDao;
import com.sfpay.core.dao.IMchRegConfDao;
import com.sfpay.core.dao.IMchRegInfoDao;
import com.sfpay.core.dto.ChannelInfoDto;
import com.sfpay.core.dto.MchRegConfDto;
import com.sfpay.core.dto.MchRegInfoDto;
import com.sfpay.core.service.IChannelArgCoreService;
import com.sfpay.core.util.JsonUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.cnst.FunctionCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.function.Function;
import com.sfpay.module.schedule.client.service.util.SpringContextHolder;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.gw.service.ISysMchOmsService;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年9月13日
 */
@Service("sysMchOmsService")
@HessianExporter
public class SysMchOmsServiceImpl implements ISysMchOmsService {
	private static final Logger LOGGER = LoggerFactory.getLogger(SysMchOmsServiceImpl.class);
	private static final String ADD = "ADD";
	private static final String UPDATE = "UPDATE";
	private static final String BY_SELF = "bySelf";

	@Resource
	private IMchRegInfoDao mchRegInfoDao;
	@Resource
	private IMchRegConfDao mchRegConfDao;
	@Resource
	private IChannelArgCoreService channelArgCoreService;
	@Resource
	private IChannelInfoDao channelInfoDao;

	private void addMerchant(String mchRegNo, String baseInfo, String baseExtInfo) {
		MchRegInfoDto mchRegInfo = mchRegInfoDao.getMchRegInfoByMchRegNo(mchRegNo);
		String logMsg = String.format("申请开通商户通道编码[%s],商户号[%s]", mchRegInfo.getChannelCode(), mchRegInfo.getMchRegNo());
		LOGGER.info("{}开始", logMsg);

		Map<String, String> baseMap = JsonUtil.toMap(baseInfo);
		baseMap.putAll(JsonUtil.toMap(baseExtInfo));
		baseMap.putAll(initAcctAndPayMap(mchRegInfo.getConfCode()));
		LOGGER.info("{}基本信息{}", logMsg, baseMap);

		Map<String, String> extMap = initMchExtMap(mchRegInfo);
		LOGGER.info("{}扩展信息{}", logMsg, extMap);

		String functionName = extMap.get(MapCnst.FUNCTION_NAME);
		Map<String, String> respMap = ((Function) SpringContextHolder.getBean(functionName)).getResp(
				mchRegInfo.getMchRegNo(), FunctionCnst.ADD_MERCHANT_FUNCTION, baseMap, initMchExtMap(mchRegInfo));
		LOGGER.info("{},功能[{}],返回值[{}]", new Object[] { logMsg, functionName, respMap });

		mchRegInfo.setRemark(respMap.get(SqlCnst.RTN_MSG));
		mchRegInfoDao.updateMchRegInfo(mchRegInfo, StatusCnst.INIT);
		if (StringUtils.isNotEmpty(respMap.get(SqlCnst.CHANNEL_MCH_NO))) {
			extMap.putAll(respMap);

			String billMchNo = baseMap.get(MapCnst.BILL_MCH_NO);

			if (BY_SELF.equals(billMchNo)) {
				billMchNo = extMap.get(SqlCnst.CHANNEL_MCH_NO);
			}

			mchRegInfo.setStatus(extMap.get(SqlCnst.STATUS));
			mchRegInfo.setSubMchNo(extMap.get(SqlCnst.SUB_MCH_NO));
			mchRegInfo.setBillMchNo(billMchNo);
			mchRegInfo.setChannelMchNo(extMap.get(SqlCnst.CHANNEL_MCH_NO));
			mchRegInfo.setRtnInfo(extMap.get(SqlCnst.RTN_INFO));
			mchRegInfo.setStatus(StatusCnst.APPLY);

			int regCnt = mchRegInfoDao.updateMchRegInfo(mchRegInfo, StatusCnst.INIT);
			LOGGER.info("{},功能[{}],更新结果[{}]", new Object[] { logMsg, functionName, regCnt });

			if (CharCnst.NUMBER_ONE != regCnt) {
				throw new ServiceException(UpcConstants.FAILURE_DB, "商户信息插入数据库结果不是1条");
			}
		}

	}

	private void getMerchantDetail(String mchRegNo, String baseInfo, String baseExtInfo) {
		MchRegInfoDto mchRegInfo = mchRegInfoDao.getMchRegInfoByMchRegNo(mchRegNo);

		if (StatusCnst.APPLY.equals(mchRegInfo.getStatus())) {

			String logMsg = String.format("申请查询商户通道编码[%s],商户号[%s]", mchRegInfo.getChannelCode(),
					mchRegInfo.getMchRegNo());
			LOGGER.info("{}开始", logMsg);

			Map<String, String> extMap = initMchExtMap(mchRegInfo);
			LOGGER.info("{}扩展信息{}", logMsg, extMap);

			String functionName = extMap.get(MapCnst.FUNCTION_NAME);
			Map<String, String> respMap = ((Function) SpringContextHolder.getBean(functionName))
					.getResp(mchRegInfo.getMchRegNo(), FunctionCnst.GET_MERCHANT_DETAIL_FUNCTION, null, extMap);
			LOGGER.info("{},功能[{}],返回值[{}]", new Object[] { logMsg, functionName, respMap });

			mchRegInfo.setRemark(respMap.get(SqlCnst.RTN_MSG));
			mchRegInfoDao.updateMchRegInfo(mchRegInfo, StatusCnst.APPLY);
			if (StatusCnst.ENABLE.equals(respMap.get(SqlCnst.STATUS))) {
				mchRegInfo.setStatus(StatusCnst.ENABLE);
				int regCnt = mchRegInfoDao.updateMchRegInfo(mchRegInfo, StatusCnst.APPLY);
				LOGGER.info("{},功能[{}],更新结果条数[{}]", new Object[] { logMsg, functionName, regCnt });

				if (CharCnst.NUMBER_ONE != regCnt) {
					throw new ServiceException(UpcConstants.FAILURE_DB, "商户信息更新数据库结果不是1条");
				}
			}
		} else {
			addMerchant(mchRegNo, mchRegInfo.getBaseInfo(), mchRegInfo.getBaseExtInfo());
		}
	}

	private void updateMerchant(String mchRegNo, String baseInfo, String baseExtInfo) {
		MchRegInfoDto mchRegInfo = mchRegInfoDao.getMchRegInfoByMchRegNo(mchRegNo);

		if (StringUtils.isEmpty(mchRegInfo.getChannelMchNo())) {
			addMerchant(mchRegNo, mchRegInfo.getBaseInfo(), mchRegInfo.getBaseExtInfo());
		}

		String logMsg = String.format("申请修改商户通道编码[%s],商户号[%s]", mchRegInfo.getChannelCode(), mchRegInfo.getMchRegNo());
		LOGGER.info("{}开始", logMsg);

		Map<String, String> extMap = initMchExtMap(mchRegInfo);
		LOGGER.info("{}扩展信息{}", logMsg, extMap);

		Map<String, String> baseMap = JsonUtil.toMap(baseInfo);
		baseMap.putAll(JsonUtil.toMap(baseExtInfo));
		baseMap.putAll(initAcctAndPayMap(mchRegInfo.getConfCode()));
		LOGGER.info("{}基本信息{}", logMsg, baseMap);

		String functionName = extMap.get(MapCnst.FUNCTION_NAME);
		Map<String, String> respMap = ((Function) SpringContextHolder.getBean(functionName))
				.getResp(mchRegInfo.getMchRegNo(), FunctionCnst.UPDATE_MERCHANT_FUNCTION, baseMap, extMap);
		LOGGER.info("{},功能[{}],返回值[{}]", new Object[] { logMsg, functionName, respMap });

		mchRegInfo.setRemark(respMap.get(SqlCnst.RTN_MSG));
		int regCnt = mchRegInfoDao.updateMchRegInfo(mchRegInfo, mchRegInfo.getStatus());

		LOGGER.info("{},功能[{}],更新结果条数[{}]", new Object[] { logMsg, functionName, regCnt });

		if (CharCnst.NUMBER_ONE != regCnt) {
			throw new ServiceException(UpcConstants.FAILURE_DB, "商户信息更新数据库结果不是1条");
		}
	}

	private Map<String, String> initMchExtMap(MchRegInfoDto mchRegInfo) {
		Map<String, String> extMap = channelArgCoreService.queryChannelArgMap(mchRegInfo.getChannelCode());

		if (StringUtils.isNotEmpty(mchRegInfo.getChannelMchNo())) {
			extMap.put(MapCnst.CHANNEL_MCH_NO, mchRegInfo.getChannelMchNo());
		}

		if (StringUtils.isNotEmpty(mchRegInfo.getRtnInfo())) {
			extMap.putAll(JsonUtil.toMap(mchRegInfo.getRtnInfo()));
		}

		ChannelInfoDto channelInfo = channelInfoDao.queryChannelInfo(mchRegInfo.getChannelCode());
		extMap.put(MapCnst.FUNCTION_NAME, channelInfo.getFunctionName());
		extMap.put(MapCnst.PAY_CODE, mchRegInfo.getRegPayCode());
		extMap.put(MapCnst.MCH_REG_NO, mchRegInfo.getMchRegNo());
		extMap.put(MapCnst.MCH_REG_STATUS, mchRegInfo.getStatus());

		return extMap;
	}

	private Map<String, String> initAcctAndPayMap(String confCode) {
		MchRegConfDto mchRegConf = mchRegConfDao.queryMchRegConf(confCode);
		Map<String, String> rtnMap = new HashMap<String, String>();

		if (StringUtils.isNotEmpty(mchRegConf.getAcctConf())) {
			rtnMap.putAll(JsonUtil.toMap(mchRegConf.getAcctConf()));
		}
		if (StringUtils.isNotEmpty(mchRegConf.getPayConf())) {
			rtnMap.putAll(JsonUtil.toMap(mchRegConf.getPayConf()));
		}

		rtnMap.put(MapCnst.BILL_MCH_NO, mchRegConf.getBillMchNo());
		return rtnMap;
	}

	@Override
	public void opMerchant(String operationType, String mchRegNo, String baseInfo, String baseExtInfo) {
		if (ADD.equals(operationType)) {
			addMerchant(mchRegNo, baseInfo, baseExtInfo);
		} else if (UPDATE.equals(operationType)) {
			updateMerchant(mchRegNo, baseInfo, baseExtInfo);
		} else {
			getMerchantDetail(mchRegNo, baseInfo, baseExtInfo);
		}
	}

	@Override
	public void confMch(String mchRegNo, String confInfo) {
		MchRegInfoDto mchRegInfo = mchRegInfoDao.getMchRegInfoByMchRegNo(mchRegNo);
		String logMsg = String.format("申请配置商户通道编码[%s],商户号[%s]", mchRegInfo.getChannelCode(), mchRegInfo.getMchRegNo());
		LOGGER.info("{},配置信息{}开始", logMsg, confInfo);

		Map<String, String> baseMap = JsonUtil.toMap(confInfo);
		LOGGER.info("{}基本信息{}", logMsg, baseMap);

		Map<String, String> extMap = initMchExtMap(mchRegInfo);
		LOGGER.info("{}扩展信息{}", logMsg, extMap);

		String functionName = extMap.get(MapCnst.FUNCTION_NAME);
		Map<String, String> respMap = ((Function) SpringContextHolder.getBean(functionName))
				.getResp(mchRegInfo.getMchRegNo(), FunctionCnst.ADD_SUB_DEV_CONFIG_FUNCTION, baseMap, extMap);
		LOGGER.info("{},功能[{}],返回值[{}]", new Object[] { logMsg, functionName, respMap });
	}

}