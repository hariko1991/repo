package com.sfpay.core.service.trade;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import javax.annotation.Resource;

import org.apache.commons.beanutils.BeanUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.service.IMchCoreService;
import com.sfpay.core.service.IMerchantInfoService;
import com.sfpay.core.util.LoadDataThread;
import com.sfpay.core.util.LoadStaticDataUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.utils.StringUtils;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.cnst.FunctionCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.function.Function;
import com.sfpay.module.schedule.client.service.util.SpringContextHolder;
import com.sfpay.upc.gw.domain.sys.req.SysAddMerchantReq;
import com.sfpay.upc.gw.domain.sys.req.SysGetMerchantDetailReq;
import com.sfpay.upc.gw.domain.sys.req.SysUpdateMerchantReq;
import com.sfpay.upc.gw.domain.sys.resp.SysAddMerchantResp;
import com.sfpay.upc.gw.domain.sys.resp.SysGetMerchantDetailResp;
import com.sfpay.upc.gw.domain.sys.resp.SysUpdateMerchantResp;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月26日
 */
@Service("mchCoreService")
public class MchCoreServiceImpl implements IMchCoreService {
	private static final Logger LOGGER = LoggerFactory.getLogger(MchCoreServiceImpl.class);
	private Executor EVENT_EXECUTOR = Executors.newFixedThreadPool(CharCnst.NUMBER_TEN);

	@Resource
	private IMerchantInfoService merchantInfoService;
	@Resource
	private LoadStaticDataUtil loadStaticDataUtil;

	@Override
	public SysAddMerchantResp addMerchant(SysAddMerchantReq req) {
		String logMsg = String.format("通道编码[%s],商户号[%s]", req.getChannelCode(), req.getMchNo());
		SysAddMerchantResp resp = new SysAddMerchantResp();

		Map<String, String> extMap = loadStaticDataUtil.initMchExtMap(req.getChannelCode(), req.getMchNo(),
				req.getPayCode(), FunctionCnst.ADD_MERCHANT_FUNCTION);

		try {
			String functionName = extMap.get(MapCnst.FUNCTION_NAME);
			LOGGER.info("申请开通商户{},功能[{}],扩展参数[{}]", new Object[] { logMsg, functionName, extMap });

			Map<String, String> respMap = ((Function) SpringContextHolder.getBean(functionName)).getResp(req.getMchNo(),
					FunctionCnst.ADD_MERCHANT_FUNCTION, req.toMap(), extMap);
			LOGGER.info("申请开通商户{},功能[{}],返回值[{}]", new Object[] { logMsg, functionName, respMap });

			if (StringUtils.isNotEmpty(respMap.get(SqlCnst.CHANNEL_MCH_NO))) {
				extMap.putAll(respMap);
				if (null != merchantInfoService.createMerchantInfo(logMsg, req, extMap)) {
					EVENT_EXECUTOR.execute(new LoadDataThread());
					LOGGER.info("申请开通商户{},功能[{}],添加商户成功", logMsg, functionName);
				}
			}

			BeanUtils.populate(resp, respMap);
		} catch (ServiceException e) {
			LOGGER.info("申请开通商户{}异常", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(e.getCode());
			resp.setRtnMsg(e.getMessage());
		} catch (Exception e) {
			LOGGER.info("申请开通商户{}异常", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(RtnCodeCnst.FAILURE_SYS);
			resp.setRtnMsg(e.getMessage());
		}

		return resp;
	}

	@Override
	public SysGetMerchantDetailResp getMerchantDetail(SysGetMerchantDetailReq req) {
		String logMsg = String.format("通道编码[%s],商户号[%s]", req.getChannelCode(), req.getMchNo());

		Map<String, String> extMap = loadStaticDataUtil.initMchExtMap(req.getChannelCode(), req.getMchNo(),
				req.getPayCode(), FunctionCnst.GET_MERCHANT_DETAIL_FUNCTION);
		SysGetMerchantDetailResp resp = new SysGetMerchantDetailResp();

		try {
			String functionName = extMap.get(MapCnst.FUNCTION_NAME);
			LOGGER.info("申请查询商户{},功能[{}],扩展参数[{}]", new Object[] { logMsg, functionName, extMap });

			Map<String, String> respMap = ((Function) SpringContextHolder.getBean(functionName)).getResp(req.getMchNo(),
					FunctionCnst.GET_MERCHANT_DETAIL_FUNCTION, req.toMap(), extMap);
			LOGGER.info("申请查询商户{},功能[{}],返回值[{}]", new Object[] { logMsg, functionName, respMap });

			BeanUtils.populate(resp, respMap);

			if (StatusCnst.ENABLE.equals(respMap.get(SqlCnst.STATUS))) {
				Map<String, String> updateMap = new HashMap<String, String>();
				updateMap.put(SqlCnst.ORIGINAL_STATUS, StatusCnst.APPLY);
				updateMap.put(SqlCnst.MCH_NO, req.getMchNo());
				updateMap.put(SqlCnst.CHANNEL_MCH_NO, extMap.get(MapCnst.CHANNEL_MCH_NO));
				int updateCnt = merchantInfoService.updateMerchantInfo(respMap, updateMap);
				EVENT_EXECUTOR.execute(new LoadDataThread());
				LOGGER.info("申请查询商户{},功能[{}],更新结果条数[{}]", new Object[] { logMsg, functionName, updateCnt });
			}

		} catch (ServiceException e) {
			LOGGER.error("申请查询商户{}异常", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(e.getCode());
			resp.setRtnMsg(e.getMessage());
		} catch (Exception e) {
			LOGGER.error("申请查询商户[{}]异常", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(RtnCodeCnst.FAILURE_SYS);
			resp.setRtnMsg(e.getMessage());
		}

		return resp;
	}

	@Override
	public SysUpdateMerchantResp updateMerchant(SysUpdateMerchantReq req) {
		SysUpdateMerchantResp resp = new SysUpdateMerchantResp();
		String logMsg = String.format("通道编码[%s],商户号[%s]", req.getChannelCode(), req.getMchNo());

		Map<String, String> extMap = loadStaticDataUtil.initMchExtMap(req.getChannelCode(), req.getMchNo(),
				req.getPayCode(), FunctionCnst.UPDATE_MERCHANT_FUNCTION);

		try {
			String functionName = extMap.get(MapCnst.FUNCTION_NAME);
			LOGGER.info("申请修改商户{},功能[{}],扩展参数[{}]", new Object[] { logMsg, functionName, extMap });

			Map<String, String> respMap = ((Function) SpringContextHolder.getBean(functionName)).getResp(req.getMchNo(),
					FunctionCnst.UPDATE_MERCHANT_FUNCTION, req.toMap(), extMap);
			LOGGER.info("申请修改商户{},功能[{}],返回值[{}]", new Object[] { logMsg, functionName, respMap });

			BeanUtils.populate(resp, respMap);
		} catch (ServiceException e) {
			LOGGER.info("申请修改商户{}异常", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(e.getCode());
			resp.setRtnMsg(e.getMessage());
		} catch (Exception e) {
			LOGGER.info("申请修改商户{}异常", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(RtnCodeCnst.FAILURE_SYS);
			resp.setRtnMsg(e.getMessage());
		}

		return resp;
	}

}
