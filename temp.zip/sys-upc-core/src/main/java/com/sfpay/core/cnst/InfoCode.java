/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.cnst;

/**
 * 
 * 类说明：<br>
 * 异常码定义
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 830598 wu_jl
 * 
 * CreateDate: 2017年5月2日
 */
public class InfoCode {
	/**
	 * 参数为空
	 */
	public static final String PARAM_NULL = "param-null";
	/**
	 * 参数无效
	 */
	public static final String PARAM_INVALID = "param-invalid";
	/**
	 * 无此枚举值
	 */
	public static final String NO_ENUM_VAL = "no-enum-val";
	/**
	 * 查无记录
	 */
	public static final String NO_RECORD = "no-record";
	/**
	 * 查无配置
	 */
	public static final String NO_CONFIG = "no-config";
	/**
	 * 失败
	 */
	public static final String FAILURE = "failure";
	/**
	 * 数据库操作失败
	 */
	public static final String FAILURE_DB = "failure-database";
}
