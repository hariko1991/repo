/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.dto;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年9月6日
 */
public class MchRegConfDto extends BaseDto {

	private static final long serialVersionUID = 352128321259335097L;

	private String confName;
	private String confCode;
	private String channelCode;
	private String regPayCode;
	private String billMchNo;
	private String baseConf;
	private String acctConf;
	private String payConf;
	private String otherConf;

	public String getConfName() {
		return confName;
	}

	public void setConfName(String confName) {
		this.confName = confName;
	}

	public String getConfCode() {
		return confCode;
	}

	public void setConfCode(String confCode) {
		this.confCode = confCode;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getRegPayCode() {
		return regPayCode;
	}

	public void setRegPayCode(String regPayCode) {
		this.regPayCode = regPayCode;
	}

	public String getBillMchNo() {
		return billMchNo;
	}

	public void setBillMchNo(String billMchNo) {
		this.billMchNo = billMchNo;
	}

	public String getBaseConf() {
		return baseConf;
	}

	public void setBaseConf(String baseConf) {
		this.baseConf = baseConf;
	}

	public String getAcctConf() {
		return acctConf;
	}

	public void setAcctConf(String acctConf) {
		this.acctConf = acctConf;
	}

	public String getPayConf() {
		return payConf;
	}

	public void setPayConf(String payConf) {
		this.payConf = payConf;
	}

	public String getOtherConf() {
		return otherConf;
	}

	public void setOtherConf(String otherConf) {
		this.otherConf = otherConf;
	}

}
