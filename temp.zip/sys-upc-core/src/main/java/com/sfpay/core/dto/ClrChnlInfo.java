package com.sfpay.core.dto;

import com.sfpay.sypay.common.BaseEntity;

/**
 * 
 * 类说明：<br>
 * 银行通道信息表 for clr
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 830598 wu_jl
 * 
 * CreateDate: 2017年5月2日
 */

public class ClrChnlInfo extends BaseEntity {

	private static final long serialVersionUID = -721597155381750561L;

	/**
	 * 商户号，银行分配
	 */
	private String channelMchNo;
	
	/**
	 * 银行编码
	 */
	private String channelCode;

	public String getChannelMchNo() {
		return channelMchNo;
	}

	public void setChannelMchNo(String channelMchNo) {
		this.channelMchNo = channelMchNo;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

}
