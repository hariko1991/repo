/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.web;

import java.io.IOException;
import java.util.Date;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sfpay.core.util.LoadDataApplicationEvent;
import com.sfpay.core.util.SpringContextHolder;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年3月7日
 */
@Controller
@RequestMapping(value = "/monitor")
@SuppressWarnings({ "unchecked", "rawtypes" })
public class Monitor {
	private static final Logger LOGGER = LoggerFactory.getLogger(Monitor.class);
	@Resource
	private RedisTemplate redisTemplate;

	@RequestMapping(value = { "", "/" })
	public void index(HttpServletRequest req, HttpServletResponse resp) {
		try {
			resp.getOutputStream().println("online");
		} catch (IOException e) {
			LOGGER.error("输出流异常", e);
		}
	}

	@RequestMapping("/refresh")
	public void refresh(HttpServletRequest req, HttpServletResponse resp) {
		SpringContextHolder.getApplicationContext().publishEvent(new LoadDataApplicationEvent(this));
		LOGGER.info("刷新内存事件数据成功时间[{}]", new Date());
		try {
			resp.getOutputStream().println("refresh");
		} catch (IOException e) {
			LOGGER.error("输出流异常", e);
		}
	}

	@RequestMapping("/delete")
	public void refresh(String key, HttpServletResponse resp) {
		redisTemplate.delete(key);
		try {
			resp.getOutputStream().println("delete");
		} catch (IOException e) {
			LOGGER.error("输出流异常", e);
		}
	}

}
