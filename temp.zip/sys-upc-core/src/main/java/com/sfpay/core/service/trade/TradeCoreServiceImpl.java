package com.sfpay.core.service.trade;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.sfpay.core.cnst.AppendBusTypeCnst;
import com.sfpay.core.dto.UpcPayInfoDto;
import com.sfpay.core.service.IPayInfoCoreService;
import com.sfpay.core.service.ITradeCoreService;
import com.sfpay.core.util.LoadStaticDataUtil;
import com.sfpay.core.util.SpringContextHolder;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.cnst.FunctionCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.PayModeCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.cnst.TradeTypeCnst;
import com.sfpay.front.function.Function;
import com.sfpay.upc.gw.domain.sys.req.SysBarcodeReq;
import com.sfpay.upc.gw.domain.sys.req.SysCancelReq;
import com.sfpay.upc.gw.domain.sys.req.SysJsprecreateReq;
import com.sfpay.upc.gw.domain.sys.req.SysRefundReq;
import com.sfpay.upc.gw.domain.sys.resp.SysBarcodeResp;
import com.sfpay.upc.gw.domain.sys.resp.SysCancelResp;
import com.sfpay.upc.gw.domain.sys.resp.SysJsprecreateResp;
import com.sfpay.upc.gw.domain.sys.resp.SysRefundResp;

/**
 * 
 * 类说明：<br>
 * 交易核心类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月25日
 */

@Service("tradeCoreService")
public class TradeCoreServiceImpl implements ITradeCoreService {
	private static final Logger LOGGER = LoggerFactory.getLogger(TradeCoreServiceImpl.class);
	@Resource
	private IPayInfoCoreService payInfoCoreService;

	@Resource
	private LoadStaticDataUtil loadStaticDataUtil;

	@Resource
	TradeCoreSupportServiceImpl tradeCoreSupportService;
	
	@Override
	public SysJsprecreateResp jsprecreate(SysJsprecreateReq req) {
		String logMsg = String.format("请求一码付预下单商户号[%s],商户定单号[%s],业务订单号[%s]", req.getMchNo(), req.getBizTradeNo(),
				req.getMchOrderNo());
		LOGGER.info("{}", logMsg);
		SysJsprecreateResp resp = new SysJsprecreateResp();
		String channelCode = "";
		try {
			channelCode = tradeCoreSupportService.screenChannelCode(req.getMchNo(), req.getPayCode());
			
			Map<String, String> extMap = loadStaticDataUtil.initTradeExtMap(
					channelCode , req.getMchNo(), req.getPayCode());
			
			Map<String, String> reqMap = req.toMap();
			reqMap.put(MapCnst.BANK_CHANNEL_CODE, extMap.get(MapCnst.CHANNEL_CODE));
			reqMap.put(MapCnst.PAY_MODE, PayModeCnst.JSPRECREATE_PAY);
			UpcPayInfoDto payInfo = payInfoCoreService.createUpcPayInfo(logMsg, reqMap, extMap);

			String functionName = extMap.get(MapCnst.FUNCTION_NAME);
			LOGGER.info("{},功能[{}],扩展参数[{}]", new Object[] { logMsg, functionName, extMap });

			reqMap.put(MapCnst.REQ_ORDER_NO, payInfo.getReqOrderNo());

			Map<String, String> respMap = ((Function) SpringContextHolder.getBean(functionName))
					.getResp(payInfo.getPayNo(), FunctionCnst.JSPRECREATE_FUNCTION, reqMap, extMap);
			LOGGER.info("{},功能[{}],返回值[{}]", new Object[] { logMsg, functionName, respMap });

			tradeCoreSupportService.notifyMonitorData(channelCode, respMap.get(SqlCnst.TARGET_STATUS), payInfo.getReqOrderNo());
			
			BeanUtils.populate(resp, respMap);

			resp.setPayNo(payInfo.getPayNo());
			resp.setSdkParam(respMap.get(MapCnst.PAY_JSON));
			
			Map<String, String> updateMap = new HashMap<String, String>();
			updateMap.put(SqlCnst.PAY_NO, payInfo.getPayNo());
			updateMap.put(SqlCnst.ORIGINAL_STATUS, StatusCnst.INIT);

			int updateCnt = payInfoCoreService.updateUpcPayInfo(respMap, updateMap);
			LOGGER.info("{},功能[{}],更新结果条数{}", new Object[] { logMsg, functionName, updateCnt });

		} catch (ServiceException e) {
			LOGGER.error("{},异常:", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(e.getCode());
			resp.setRtnMsg(e.getMessage());
			tradeCoreSupportService.notifyMonitorData(channelCode, StatusCnst.FAILURE, "");
		} catch (Exception e) {
			LOGGER.error("{},异常:", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(RtnCodeCnst.FAILURE_SYS);
			resp.setRtnMsg(e.getMessage());
			tradeCoreSupportService.notifyMonitorData(channelCode, StatusCnst.FAILURE, "");
		}

		return resp;
	}

	@Override
	public SysCancelResp cancel(SysCancelReq req) {
		String logMsg = String.format("订单撤销,业务订单号[%s]", req.getBizTradeNo());
		LOGGER.info("{},请求参数:{}", logMsg, req);
		SysCancelResp resp = new SysCancelResp();

		try {
			Map<String, Object> queryMap = new HashMap<String, Object>();
			queryMap.put(SqlCnst.UPP_ORDER_NO, req.getBizTradeNo());
			queryMap.put(SqlCnst.TRADE_TYPE, TradeTypeCnst.TRADE_TYPE_PAY);
			queryMap.put(SqlCnst.APPEND_BUS_TYPE, AppendBusTypeCnst.APPEND_BUS_TYPE_NORMAL);
			UpcPayInfoDto payInfo = payInfoCoreService.queryPayInfo(queryMap);
			if (payInfo == null) {
				resp.setRtnCode(RtnCodeCnst.ORDER_NOT_EXISTS);
				resp.setRtnMsg("订单不存在");
				return resp;
			}
			LOGGER.info("{},订单状态:{}", logMsg, payInfo.getStatus());
			// 如果原支付订单，处于交易中，在重新请求银行一次
			if (StatusCnst.TRADING.equals(payInfo.getStatus())) {
				payInfo = this.payQuery(payInfo);
			}

			if (!StatusCnst.TRADING.equals(payInfo.getStatus())) {
				resp.setRtnCode(RtnCodeCnst.ONLY_TRADING_ORDER_CAN_CANCEL);
				resp.setRtnMsg("只有交易中订单才可以撤销");
				return resp;
			}

			Map<String, String> extMap = loadStaticDataUtil.initTradeExtMap(payInfo.getBankChannelCode(), 
					payInfo.getMchNo(), payInfo.getPayCode());

			String functionName = extMap.get(MapCnst.FUNCTION_NAME);
			LOGGER.info("{},功能[{}],扩展参数[{}]", new Object[] { logMsg, functionName, extMap });

			Map<String, String> reqMap = new HashMap<String, String>();
			// 以下参数键，不能修改
			reqMap.put(MapCnst.REQ_ORDER_NO, payInfo.getReqOrderNo());
			reqMap.put(MapCnst.CANCEL_NO, "CX" + payInfo.getReqOrderNo());

			Map<String, String> respMap = ((Function) SpringContextHolder.getBean(functionName))
					.getResp(payInfo.getPayNo(), FunctionCnst.CANCEL_FUNCTION, reqMap, extMap);
			LOGGER.info("{},功能[{}],前置返回值[{}]", new Object[] { logMsg, functionName, respMap });

			BeanUtils.populate(resp, respMap);

			if (StatusCnst.CLOSE.equals(respMap.get(SqlCnst.TARGET_STATUS))) {
				Map<String, String> updateMap = new HashMap<String, String>();
				updateMap.put(SqlCnst.PAY_NO, payInfo.getPayNo());
				updateMap.put(SqlCnst.ORIGINAL_STATUS, StatusCnst.TRADING);

				int updateCnt = payInfoCoreService.updateUpcPayInfo(respMap, updateMap);
				LOGGER.info("{},功能[{}],更新结果条数{}", new Object[] { logMsg, functionName, updateCnt });
			}
		} catch (ServiceException e) {
			LOGGER.error("订单撤销{},异常 :", req, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(e.getCode());
			resp.setRtnMsg(e.getMessage());
		} catch (Exception e) {
			LOGGER.error("订单撤销{},异常 :", req, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(RtnCodeCnst.FAILURE_SYS);
			resp.setRtnMsg(e.getMessage());
		}
		LOGGER.info("{},响应结果{}", new Object[] { logMsg, resp });
		return resp;
	}

	@Override
	public SysRefundResp refund(SysRefundReq req) {
		String logMsg = String.format("退款来源[%s],退款业务流水号[%s],退款渠道交易号[%s]", req.isSourceBizSystem() ? "业务系统" : "清算系统",
				req.getRefundBizTradeNo(), req.getChannelTradeNo());

		LOGGER.info("{}", logMsg);

		SysRefundResp resp = new SysRefundResp();
		Map<String, String> respMap = null;
		
		// 1、验证重复下单(根据退款订单号验证)
		tradeCoreSupportService.validateRepeatRefund(req, req.isSourceBizSystem()
					? AppendBusTypeCnst.APPEND_BUS_TYPE_NORMAL : AppendBusTypeCnst.APPEND_BUS_TYPE_REFUND);

		// 2、查询原支付信息
		UpcPayInfoDto upcPayInfo = tradeCoreSupportService.validateIsAllowRefund(req);

		// 3.验证部分退款(退款金额)
		tradeCoreSupportService.validatRefundAmt(req, upcPayInfo);

		Map<String, String> extMap = loadStaticDataUtil.initRefundExtMap(upcPayInfo.getBankChannelCode(),
					upcPayInfo.getMchNo(), upcPayInfo.getPayCode());
			
		String functionName = extMap.get(MapCnst.FUNCTION_NAME);
			
		LOGGER.info("{},功能[{}],扩展参数[{}]", new Object[] { logMsg, functionName, extMap });
		UpcPayInfoDto refundInfo = null;
		
		try{
			if(StringUtils.isBlank(functionName) || extMap == null){
				resp = new SysRefundResp();
				resp.setStatus(StatusCnst.REFUND_FAIL);
				resp.setRtnCode(RtnCodeCnst.FAILURE_SYS);
				resp.setRtnMsg("通道配置参数为空");
				return resp;
			}
			// 4、创建退款信息
			refundInfo = payInfoCoreService.createRefundInfo(req, upcPayInfo, extMap);

			Map<String, String> reqMap = req.getExtMap();
			if (reqMap == null) {
				reqMap = new HashMap<String, String>();
			}
			// 以下参数键，不能修改
			reqMap.put(MapCnst.REQ_ORDER_NO, refundInfo.getReqOrderNo());
			reqMap.put(MapCnst.OLD_REQ_ORDER_NO, refundInfo.getOldReqOrderNo());
			reqMap.put(MapCnst.REFUND_AMT, req.getRefundAmt() + "");
			reqMap.put(MapCnst.PAY_CODE, refundInfo.getPayCode());
			respMap = ((Function) SpringContextHolder.getBean(functionName))
					.getResp(refundInfo.getPayNo(), FunctionCnst.REFUND_FUNCTION, reqMap, extMap);
			LOGGER.info("{},功能[{}],前置返回值[{}]", new Object[] { logMsg, functionName, respMap });

			tradeCoreSupportService.notifyMonitorData(refundInfo.getBankChannelCode(), respMap.get(SqlCnst.TARGET_STATUS), refundInfo.getReqOrderNo());
			
			resp.setBizTradeNo(req.getBizTradeNo());
			resp.setChannelCode(refundInfo.getBankChannelCode());
			resp.setPayNo(refundInfo.getPayNo());
			resp.setRefundBizTradeNo(refundInfo.getUppOrderNo());
			resp.setRefundMchOrderNo(req.getRefundMchOrderNo());

			if(respMap.get(SqlCnst.TARGET_STATUS) != null){
				Map<String, String> updateMap = new HashMap<String, String>();
				updateMap.put(SqlCnst.PAY_NO, refundInfo.getPayNo());
				updateMap.put(SqlCnst.ORIGINAL_STATUS, StatusCnst.REFUND_PROC);

				int updateCnt = payInfoCoreService.updateUpcPayInfo(respMap, updateMap);
				LOGGER.info("{},功能[{}],更新结果条数{}", new Object[] { logMsg, functionName, updateCnt });
			}else{
				LOGGER.info("{},功能[{}],无需更新数据库", new Object[] { logMsg, functionName});
			}

		} catch (ServiceException e) {
			LOGGER.error("退款{},异常 :", req, e);
			resp = new SysRefundResp();
			resp.setStatus(StatusCnst.REFUND_FAIL);
			resp.setRtnCode(e.getCode());
			resp.setRtnMsg(e.getMessage());
			if(refundInfo!= null){
				tradeCoreSupportService.notifyMonitorData(refundInfo.getBankChannelCode(), StatusCnst.REFUND_FAIL, refundInfo.getReqOrderNo());
			}
		} catch (Exception e) {
			LOGGER.error("退款{},异常 :", req, e);
			resp = new SysRefundResp();
			resp.setStatus(StatusCnst.REFUND_FAIL);
			resp.setRtnCode(RtnCodeCnst.FAILURE_SYS);
			resp.setRtnMsg(e.getMessage());
			if(refundInfo!= null){
				tradeCoreSupportService.notifyMonitorData(refundInfo.getBankChannelCode(), StatusCnst.REFUND_FAIL, refundInfo.getReqOrderNo());
			}
		}
		
		if (respMap != null && upcPayInfo != null) {
			try {
				respMap.putAll(loadStaticDataUtil.initProvAcctMap(
						upcPayInfo.getBankChannelCode(),
						upcPayInfo.getPayCode()));
				BeanUtils.populate(resp, respMap);
			} catch (Exception e) {
				LOGGER.error("{},获取备付金异常:", logMsg, e);
				resp.setStatus(StatusCnst.REFUND_PROC);
			}
		}
//		if(AppendBusTypeCnst.APPEND_BUS_TYPE_NORMAL.equals(refundInfo.getAppendBusType()) 
//				&& StatusCnst.REFUND_FAIL.equals(resp.getStatus())){
//			LOGGER.error("{},由于调用银行退款失败,返回业务系统的状态{}", logMsg, StatusCnst.REFUND_PROC);
//			resp.setStatus(StatusCnst.REFUND_PROC);
//		}
		return resp;
	}

	@Override
	public SysBarcodeResp barcode(SysBarcodeReq req) {
		String logMsg = String.format("请求条码支付下单商户号[%s],商户定单号[%s],业务订单号[%s]", req.getMchNo(), req.getMchOrderNo(),
				req.getBizTradeNo());
		SysBarcodeResp resp = new SysBarcodeResp();

		Map<String, String> respMap = null;
		UpcPayInfoDto payInfo = null;
		String channelCode = "";
		try {
			
		    channelCode = tradeCoreSupportService.screenChannelCode(req.getMchNo(), req.getPayCode());
			
			Map<String, String> extMap = loadStaticDataUtil.initTradeExtMap(
					channelCode, req.getMchNo(), req.getPayCode());
			
			Map<String, String> reqMap = req.toMap();
			reqMap.put(MapCnst.BANK_CHANNEL_CODE, extMap.get(MapCnst.CHANNEL_CODE));
			reqMap.put(MapCnst.PAY_MODE, PayModeCnst.BARCODE_PAY);
			payInfo = payInfoCoreService.createUpcPayInfo(logMsg, reqMap, extMap);

			String functionName = extMap.get(MapCnst.FUNCTION_NAME);
			LOGGER.info("{},功能[{}],扩展参数[{}]", new Object[] { logMsg, functionName, extMap });

			reqMap.put(MapCnst.REQ_ORDER_NO, payInfo.getReqOrderNo());

			respMap = ((Function) SpringContextHolder.getBean(functionName))
					.getResp(payInfo.getPayNo(), FunctionCnst.BARCODE_FUNCTION, reqMap, extMap);
			LOGGER.info("{},功能[{}],返回值[{}]", new Object[] { logMsg, functionName, respMap });
			
			tradeCoreSupportService.notifyMonitorData(channelCode, respMap.get(SqlCnst.TARGET_STATUS), payInfo.getReqOrderNo());
			
			Map<String, String> updateMap = new HashMap<String, String>();
			updateMap.put(SqlCnst.PAY_NO, payInfo.getPayNo());
			updateMap.put(SqlCnst.ORIGINAL_STATUS, StatusCnst.INIT);

			int updateCnt = payInfoCoreService.updateUpcPayInfo(respMap, updateMap , true , payInfo.getPayCode());
			LOGGER.info("{},功能[{}],更新结果条数{}", new Object[] { logMsg, functionName, updateCnt });
			
			resp.setMchOrderNo(req.getMchOrderNo());
			resp.setPayNo(payInfo.getPayNo());
			resp.setChannelCode(payInfo.getBankChannelCode());

		} catch (ServiceException e) {
			LOGGER.error("{},异常:", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(e.getCode());
			resp.setRtnMsg(e.getMessage());
			tradeCoreSupportService.notifyMonitorData(channelCode, StatusCnst.FAILURE, "");
		} catch (Exception e) {
			LOGGER.error("{},异常:", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(RtnCodeCnst.FAILURE_SYS);
			resp.setRtnMsg(e.getMessage());
			tradeCoreSupportService.notifyMonitorData(channelCode, StatusCnst.FAILURE, "");
		}

		if (respMap != null && payInfo != null) {
			try {
				respMap.putAll(loadStaticDataUtil.initProvAcctMap(
						payInfo.getBankChannelCode(), payInfo.getPayCode()));
				BeanUtils.populate(resp, respMap);
			} catch (Exception e) {
				LOGGER.error("{},获取备付金异常:", logMsg, e);
				resp.setStatus(StatusCnst.TRADING);
			}
		}
		
		return resp;
	}

	@Override
	public UpcPayInfoDto refundQuery(UpcPayInfoDto upcPayInfo) {
		String logMsg = String.format("渠道[%s],渠道支付号[%s],渠道交易号[%s]", upcPayInfo.getBankChannelCode(), upcPayInfo.getPayNo(),
				upcPayInfo.getReqOrderNo());
		LOGGER.debug("{}", logMsg);

		try {
			Map<String, String> extMap = loadStaticDataUtil.initQueryExtMap(upcPayInfo.getBankChannelCode(),
					upcPayInfo.getMchNo(), upcPayInfo.getPayCode());

			String functionName = extMap.get(MapCnst.FUNCTION_NAME);
			LOGGER.info("请求退款查询[{}],功能[{}],扩展参数[{}]", new Object[] { logMsg, functionName, extMap });

			Map<String, String> reqMap = new HashMap<String, String>();

			reqMap.put(MapCnst.REQ_ORDER_NO, upcPayInfo.getReqOrderNo());
			reqMap.put(MapCnst.OLD_REQ_ORDER_NO, upcPayInfo.getOldReqOrderNo());
			reqMap.put(MapCnst.TRADE_TYPE, upcPayInfo.getTradeType());

			Map<String, String> respMap = ((Function) SpringContextHolder.getBean(functionName))
					.getResp(upcPayInfo.getPayNo(), FunctionCnst.REFUND_QUERY_FUNCTION, reqMap, extMap);

			LOGGER.info("请求退款查询[{}],功能[{}],前置返回值[{}]", new Object[] { logMsg, functionName, respMap });

			if (respMap.get(SqlCnst.TARGET_STATUS) != null) {
				Map<String, String> updateMap = new HashMap<String, String>();
				updateMap.put(SqlCnst.PAY_NO, upcPayInfo.getPayNo());
				updateMap.put(SqlCnst.ORIGINAL_STATUS, StatusCnst.REFUND_PROC);

				int updateCnt = payInfoCoreService.updateUpcPayInfo(respMap, updateMap);
				LOGGER.info("请求退款查询[{}],功能[{}],更新结果条数[{}]", new Object[] { logMsg, functionName, updateCnt });
				upcPayInfo.setStatus(respMap.get(SqlCnst.TARGET_STATUS));
				upcPayInfo.setRtnMsg(respMap.get(SqlCnst.RTN_MSG));
				upcPayInfo.setRtnOrderNo(respMap.get(SqlCnst.RTN_ORDER_NO));
				upcPayInfo.setRtnCode(respMap.get(SqlCnst.RTN_CODE));
			} else {
				LOGGER.info("请求退款查询[{}],功能[{}],查询订单状态处于退款中,银行订单状态[{}]",
						new Object[] { logMsg, functionName, upcPayInfo.getStatus() });
			}
			LOGGER.info("请求退款查询[{}],功能[{}],状态[{}]", new Object[] { logMsg, functionName ,upcPayInfo.getStatus()});
		} catch (Exception e) {
			LOGGER.error("退款查询{},异常 :", upcPayInfo, e);
		}

		return upcPayInfo;
	}

	@Override
	public UpcPayInfoDto payQuery(UpcPayInfoDto upcPayInfo) {
		String logMsg = String.format("渠道[%s],渠道支付号[%s],渠道交易号[%s]", upcPayInfo.getChannelCode(), upcPayInfo.getPayNo(),
				upcPayInfo.getReqOrderNo());
		LOGGER.debug("支付查询{}", logMsg);

		try {
			Map<String, String> extMap = loadStaticDataUtil.initQueryExtMap(upcPayInfo.getBankChannelCode(),
					upcPayInfo.getMchNo(), upcPayInfo.getPayCode());

			String functionName = extMap.get(MapCnst.FUNCTION_NAME);
			LOGGER.info("请求支付查询[{}],功能[{}],扩展参数[{}]", new Object[] { logMsg, functionName, extMap });

			Map<String, String> reqMap = new HashMap<String, String>();
			// 以下参数键，不能修改
			reqMap.put(MapCnst.REQ_ORDER_NO, upcPayInfo.getReqOrderNo());
			reqMap.put(MapCnst.TRADE_TYPE, upcPayInfo.getTradeType());

			Map<String, String> respMap = ((Function) SpringContextHolder.getBean(functionName))
					.getResp(upcPayInfo.getPayNo(), FunctionCnst.QUERY_FUNCTION, reqMap, extMap);
			LOGGER.info("请求支付查询[{}],功能[{}],前置返回值[{}]", new Object[] { logMsg, functionName, respMap });

			if (respMap.get(SqlCnst.TARGET_STATUS) != null) {
				Map<String, String> updateMap = new HashMap<String, String>();
				updateMap.put(SqlCnst.PAY_NO, upcPayInfo.getPayNo());
				updateMap.put(SqlCnst.ORIGINAL_STATUS, StatusCnst.TRADING);

				int updateCnt = payInfoCoreService.updateUpcPayInfo(respMap, updateMap, true , upcPayInfo.getPayCode());
				LOGGER.info("请求支付查询[{}],功能[{}],更新结果条数{}", new Object[] { logMsg, functionName, updateCnt });
				upcPayInfo.setStatus(respMap.get(SqlCnst.TARGET_STATUS));
				upcPayInfo.setRtnOrderNo(respMap.get(SqlCnst.RTN_ORDER_NO));
				upcPayInfo.setChannelNo(respMap.get(SqlCnst.CHANNEL_NO));
				upcPayInfo.setRtnCode(respMap.get(SqlCnst.RTN_CODE));
				upcPayInfo.setRtnMsg(respMap.get(SqlCnst.RTN_MSG));
			} else {
				LOGGER.info("请求支付查询[{}],功能[{}],查询订单状态处于未支付,银行订单状态[{}]",
						new Object[] { logMsg, functionName, upcPayInfo.getStatus() });
			}
			LOGGER.info("请求支付查询[{}],功能[{}],订单状态[{}]", new Object[] { logMsg, functionName ,upcPayInfo.getStatus()});
		} catch (Exception e) {
			LOGGER.error("支付查询{},异常 :", upcPayInfo, e);
		}

		return upcPayInfo;
	}

	@Override
	public UpcPayInfoDto notifyResult(Map<String, String> reqMap) {
		String logMsg = String.format("支付通知,请求订单号[%s]", reqMap.get(MapCnst.REQ_ORDER_NO));
		LOGGER.debug("{}", logMsg);
		try {
			Map<String, Object> queryMap = new HashMap<String, Object>();
			queryMap.put(SqlCnst.REQ_ORDER_NO, reqMap.get(MapCnst.REQ_ORDER_NO));
			queryMap.put(SqlCnst.APPEND_BUS_TYPE, AppendBusTypeCnst.APPEND_BUS_TYPE_NORMAL);
			UpcPayInfoDto upcPayInfoDto = payInfoCoreService.queryPayInfo(queryMap);
			if (upcPayInfoDto == null) {
				LOGGER.error("通知结果,查询原始数据,不存在 ,附加类型 " +AppendBusTypeCnst.APPEND_BUS_TYPE_NORMAL+", 请求参数:{}", reqMap);
				queryMap.put(SqlCnst.APPEND_BUS_TYPE, AppendBusTypeCnst.APPEND_BUS_TYPE_REFUND);
				upcPayInfoDto = payInfoCoreService.queryPayInfo(queryMap);
				if(upcPayInfoDto == null){
					LOGGER.error("通知结果,查询原始数据,不存在 ,附加类型 " +AppendBusTypeCnst.APPEND_BUS_TYPE_REFUND+", 请求参数:{}", reqMap);
					return null;
				}
			}
			if(TradeTypeCnst.TRADE_TYPE_PAY.equals(upcPayInfoDto.getTradeType())
					&& !StatusCnst.TRADING.equals(upcPayInfoDto.getStatus()) ){
				LOGGER.error("支付订单状态已更新,无需处理 , 请求参数:{}", reqMap);
				return upcPayInfoDto;
			} else if(TradeTypeCnst.TRADE_TYPE_REFUND.equals(upcPayInfoDto.getTradeType()) &&
					!StatusCnst.REFUND_PROC.equals(upcPayInfoDto.getStatus())){
				LOGGER.error("支付退款订单状态已更新,无需处理 , 请求参数:{}", reqMap);
				return upcPayInfoDto;
			}
			reqMap.put(MapCnst.TRADE_TYPE, upcPayInfoDto.getTradeType());
			Map<String, String> extMap = loadStaticDataUtil.initNotifyExtMap(upcPayInfoDto.getBankChannelCode(),
					upcPayInfoDto.getMchNo(), upcPayInfoDto.getPayCode());
			String functionName = extMap.get(MapCnst.FUNCTION_NAME);
			Map<String, String> respMap = ((Function) SpringContextHolder.getBean(functionName))
					.getResp(upcPayInfoDto.getPayNo(), FunctionCnst.NOTIFY_VALIDATE_SIGN, reqMap, extMap);
			
			LOGGER.info("[{}],功能[{}],前置返回值[{}]", new Object[] { logMsg, functionName, respMap });
			
			if (respMap != null && !respMap.isEmpty()) {
				tradeCoreSupportService.notifyMonitorData(upcPayInfoDto.getBankChannelCode(), respMap.get(SqlCnst.TARGET_STATUS), upcPayInfoDto.getReqOrderNo());
				
				Map<String, String> updateMap = new HashMap<String, String>();
				updateMap.put(SqlCnst.PAY_NO, upcPayInfoDto.getPayNo());
				updateMap.put(SqlCnst.ORIGINAL_STATUS, TradeTypeCnst.TRADE_TYPE_PAY.equals(upcPayInfoDto.getTradeType()) 
						? StatusCnst.TRADING : StatusCnst.REFUND_PROC);

				int updateCnt = payInfoCoreService.updateUpcPayInfo(respMap, updateMap, 
						(TradeTypeCnst.TRADE_TYPE_PAY.equals(upcPayInfoDto.getTradeType()) ? true : false) , upcPayInfoDto.getPayCode());
				
				upcPayInfoDto.setStatus(updateMap.get(SqlCnst.TARGET_STATUS));
				upcPayInfoDto.setRtnOrderNo(updateMap.get(SqlCnst.RTN_ORDER_NO));
				upcPayInfoDto.setRtnCode(updateMap.get(SqlCnst.RTN_CODE));
				upcPayInfoDto.setRtnMsg(updateMap.get(SqlCnst.RTN_MSG));
				upcPayInfoDto.setChannelNo(updateMap.get(SqlCnst.CHANNEL_NO));
				
				LOGGER.info("支付通知,请求订单号[{}],更新结果条数[{}], 订单状态[{}]", 
						new Object[] {upcPayInfoDto.getReqOrderNo() , updateCnt ,upcPayInfoDto.getStatus()});
				return upcPayInfoDto;
			} else {
				LOGGER.error("{},验证签名失败, 请求参数:{}",logMsg, reqMap);
			}
		} catch (Exception e) {
			LOGGER.error("通知结果,请求参数{},异常 ", reqMap, e);
		}
		return null;
	}

	@Override
	public UpcPayInfoDto reRefund(Map<String, String> reqMap) {
		String logMsg = String.format("退款来源[%s],通道请求订单号[%s]", "通道系统", 
				reqMap.get(SqlCnst.REQ_ORDER_NO));
		Map<String, String> respMap = null;
		UpcPayInfoDto upcPayInfo = null;
		try{
			Map<String, Object> queryMap = new HashMap<String, Object>();
			queryMap.put(SqlCnst.REQ_ORDER_NO, reqMap.get(SqlCnst.REQ_ORDER_NO));
			queryMap.put(SqlCnst.APPEND_BUS_TYPE, AppendBusTypeCnst.APPEND_BUS_TYPE_NORMAL);
			queryMap.put(SqlCnst.STATUS, StatusCnst.REFUND_FAIL);
			queryMap.put(SqlCnst.TRADE_TYPE, TradeTypeCnst.TRADE_TYPE_REFUND);
			upcPayInfo = payInfoCoreService.queryPayInfo(queryMap);
			if(upcPayInfo == null){
				throw new ServiceException(RtnCodeCnst.ORDER_NOT_EXISTS,"要重新退款的订单不存在或非退款失败的交易");
			}
			Map<String, String> updateMap = new HashMap<String, String>();
			updateMap.put(SqlCnst.TARGET_STATUS, StatusCnst.REFUND_PROC);
			updateMap.put(SqlCnst.NOTIFY_FLAG, CharCnst.NO_FLAG);
			updateMap.put(SqlCnst.PAY_NO, upcPayInfo.getPayNo());
			updateMap.put(SqlCnst.ORIGINAL_STATUS, StatusCnst.REFUND_FAIL);
			
			payInfoCoreService.updateUpcPayInfo(new HashMap<String, String>(), updateMap);
			
			Map<String, String> extMap = loadStaticDataUtil.initRefundExtMap(upcPayInfo.getBankChannelCode(),
					upcPayInfo.getMchNo(), upcPayInfo.getPayCode());
			
			String functionName = extMap.get(MapCnst.FUNCTION_NAME);
			LOGGER.info("请求重新退款[{}],功能[{}],扩展参数[{}]", new Object[] { logMsg, functionName, extMap });
			
			// 以下参数键，不能修改
			reqMap.put(MapCnst.REQ_ORDER_NO, upcPayInfo.getReqOrderNo());
			reqMap.put(MapCnst.OLD_REQ_ORDER_NO, upcPayInfo.getOldReqOrderNo());
			reqMap.put(MapCnst.REFUND_AMT, upcPayInfo.getTradeAmt() + "");
			reqMap.put(MapCnst.PAY_CODE, upcPayInfo.getPayCode());
			respMap = ((Function) SpringContextHolder.getBean(functionName))
					.getResp(upcPayInfo.getPayNo(), FunctionCnst.REFUND_FUNCTION, reqMap, extMap);
			LOGGER.info("请求重新退款[{}],功能[{}],前置返回值[{}]", new Object[] { logMsg, functionName, respMap });

			if(respMap.get(SqlCnst.TARGET_STATUS) != null){
				updateMap.clear();
				updateMap.put(SqlCnst.PAY_NO, upcPayInfo.getPayNo());
				updateMap.put(SqlCnst.ORIGINAL_STATUS, StatusCnst.REFUND_PROC);

				int updateCnt = payInfoCoreService.updateUpcPayInfo(respMap, updateMap);
				LOGGER.info("请求重新退款[{}],功能[{}],更新结果条数{}", new Object[] { logMsg, functionName, updateCnt });
			}else{
				LOGGER.info("请求重新退款[{}],功能[{}],无需更新数据库", new Object[] { logMsg, functionName});
			}
			queryMap.remove(SqlCnst.STATUS);
			upcPayInfo = payInfoCoreService.queryPayInfo(queryMap);
		} catch (ServiceException e) {
			LOGGER.error("{},重新退款异常:", logMsg, e);
			throw e;
		}catch (Exception e) {
			LOGGER.error("{},重新退款发生其他异常:", logMsg, e);
			throw new ServiceException(RtnCodeCnst.FAILURE_SYS,e);
		}
		return upcPayInfo;
	}

	@Override
	public void notifySecretKeyChange(Map<String, String> reqMap) {
		String logMsg = String.format("秘钥发生改变通知");
		long start = 0L;
		try {
			start = System.currentTimeMillis();
//			LOGGER.info("{},开始刷新Token或ticket,刷新开始时间{}",logMsg, start);
//			Map<String, String> extMap = loadStaticDataUtil.initCommonExtMap(ChannelCnst.CHANNEL_WE);
//			Map<String, String> respMap = ((Function) SpringContextHolder.getBean(extMap.get(MapCnst.FUNCTION_NAME)))
//					.getResp(start + "", FunctionCnst.REFRESH_TOKEN_FUNCTION, null, extMap);
//			LOGGER.info("{},结束刷新Token或ticket,返回结果{}", respMap);
			String data = reqMap.get(MapCnst.NOTIFY_DATA);
			JSONObject dataObj = JSONObject.parseObject(data);
			String changeType = dataObj.getString("changeType");
			String currentValue = dataObj.getString("currentValue");
//			String localValue = "";
//			if("token".equals(changeType)){
//				localValue = respMap.get(MapCnst.ACCESS_TOKEN);
//			}else{
//				localValue = respMap.get(MapCnst.API_TICKET);
//			}
			LOGGER.info("刷新"+changeType+"结束,进行数据比较,外部请求值[{}]", currentValue);
		} catch (Exception e) {
			LOGGER.error("{},刷新Token或ticket过程中异常",logMsg, e);
		} finally {
			LOGGER.info("{},刷新Token或ticket,耗时[{}]", logMsg, (System.currentTimeMillis() - start));
		}
	}

}
