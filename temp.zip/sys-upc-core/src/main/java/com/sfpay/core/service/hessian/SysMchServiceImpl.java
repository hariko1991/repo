package com.sfpay.core.service.hessian;

import java.util.Arrays;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.service.IMchCoreService;
import com.sfpay.core.util.BeanValidUtils;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.upc.gw.domain.sys.req.SysAddMerchantReq;
import com.sfpay.upc.gw.domain.sys.req.SysGetMerchantDetailReq;
import com.sfpay.upc.gw.domain.sys.req.SysUpdateMerchantReq;
import com.sfpay.upc.gw.domain.sys.resp.SysAddMerchantResp;
import com.sfpay.upc.gw.domain.sys.resp.SysGetMerchantDetailResp;
import com.sfpay.upc.gw.domain.sys.resp.SysUpdateMerchantResp;
import com.sfpay.upc.gw.service.ISysMchService;

/**
 * 
 * 类说明：<br>
 * 商户相关服务
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月26日
 */
@HessianExporter
@Service("sysMchService")
public class SysMchServiceImpl implements ISysMchService {
	private static final Logger LOGGER = LoggerFactory.getLogger(SysMchServiceImpl.class);

	private static final List<String> MERCHANT_VALID_FIELD_ARRAY = Arrays
			.asList(new String[] { "channelCode", "mchNo", "payCode" });

	@Resource
	private IMchCoreService mchCoreService;

	@Override
	public SysAddMerchantResp addMerchant(SysAddMerchantReq req) {
		String logMsg = String.format("通道编码[%s],商户号[%s]", req.getChannelCode(), req.getMchNo());
		LOGGER.info("申请开通商户{},请求{}", logMsg, req);
		SysAddMerchantResp resp = new SysAddMerchantResp();

		List<String> validNoPassFields = BeanValidUtils.validNullField(req, MERCHANT_VALID_FIELD_ARRAY);
		LOGGER.info("申请开通商户{},校验请求不通过字段{}", logMsg, validNoPassFields);
		if (CollectionUtils.isNotEmpty(validNoPassFields)) {
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(RtnCodeCnst.ILLEGAL_REQ);
			resp.setRtnMsg("校验不通过字段" + validNoPassFields);
			return resp;
		}

		try {
			resp = mchCoreService.addMerchant(req);
		} catch (ServiceException e) {
			LOGGER.error("申请开通商户{}异常", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(e.getCode());
			resp.setRtnMsg(e.getMessage());
		} catch (Exception e) {
			LOGGER.error("申请开通商户{}异常", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(RtnCodeCnst.FAILURE_SYS);
			resp.setRtnMsg(e.getMessage());
		}

		LOGGER.info("申请开通商户{},结果{}", logMsg, resp);
		return resp;
	}

	@Override
	public SysGetMerchantDetailResp getMerchantDetail(SysGetMerchantDetailReq req) {
		String logMsg = String.format("通道编码[%s],商户号[%s]", req.getChannelCode(), req.getMchNo());
		SysGetMerchantDetailResp resp = new SysGetMerchantDetailResp();
		LOGGER.info("申请查询商户{},请求{}", logMsg, req);
		try {
			List<String> validNoPassFields = BeanValidUtils.validNullField(req, MERCHANT_VALID_FIELD_ARRAY);
			LOGGER.info("申请查询商户{},校验请求不通过字段{}", logMsg, validNoPassFields);
			if (CollectionUtils.isNotEmpty(validNoPassFields)) {
				resp.setStatus(StatusCnst.FAILURE);
				resp.setRtnCode(RtnCodeCnst.ILLEGAL_REQ);
				resp.setRtnMsg("校验不通过字段" + validNoPassFields);
				return resp;
			}

			resp = mchCoreService.getMerchantDetail(req);
		} catch (ServiceException e) {
			LOGGER.error("申请查询商户{}异常", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(e.getCode());
			resp.setRtnMsg(e.getMessage());
		} catch (Exception e) {
			LOGGER.error("申请查询商户[{}]异常", req.getMchNo(), e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(RtnCodeCnst.FAILURE_SYS);
			resp.setRtnMsg(e.getMessage());
		}

		LOGGER.info("申请查询商户{},结果{}", logMsg, resp);
		return resp;
	}

	@Override
	public SysUpdateMerchantResp updateMerchant(SysUpdateMerchantReq req) {
		String logMsg = String.format("通道编码[%s],商户号[%s]", req.getChannelCode(), req.getMchNo());
		SysUpdateMerchantResp resp = new SysUpdateMerchantResp();
		LOGGER.info("申请查询商户{},请求{}", logMsg, req);

		try {
			List<String> validNoPassFields = BeanValidUtils.validNullField(req, MERCHANT_VALID_FIELD_ARRAY);
			LOGGER.info("申请更新商户{},校验请求不通过字段{}", logMsg, validNoPassFields);
			if (CollectionUtils.isNotEmpty(validNoPassFields)) {
				resp.setStatus(StatusCnst.FAILURE);
				resp.setRtnCode(RtnCodeCnst.ILLEGAL_REQ);
				resp.setRtnMsg("校验不通过字段" + validNoPassFields);
				return resp;
			}

			resp = mchCoreService.updateMerchant(req);
		} catch (ServiceException e) {
			LOGGER.error("申请更新商户{}异常", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(e.getCode());
			resp.setRtnMsg(e.getMessage());
		} catch (Exception e) {
			LOGGER.error("申请更新商户{},异常", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(RtnCodeCnst.FAILURE_SYS);
			resp.setRtnMsg(e.getMessage());
		}

		LOGGER.info("申请更新商户{},结果{}", logMsg, resp);
		return resp;
	}

}
