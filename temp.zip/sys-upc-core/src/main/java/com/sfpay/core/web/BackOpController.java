/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.web;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.data.redis.support.atomic.RedisAtomicInteger;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.collect.Lists;
import com.google.common.collect.Sets;
import com.sfpay.core.cnst.AppendBusTypeCnst;
import com.sfpay.core.dao.IChannelReconFileDao;
import com.sfpay.core.dao.IMerchantConfDao;
import com.sfpay.core.dto.ChannelReconFileDto;
import com.sfpay.core.dto.UpcPayInfoDto;
import com.sfpay.core.service.INotifyResultService;
import com.sfpay.core.service.IPayInfoCoreService;
import com.sfpay.core.service.IReconCoreService;
import com.sfpay.core.service.ITradeCoreService;
import com.sfpay.core.util.DateUtils;
import com.sfpay.core.util.LoadDataApplicationEvent;
import com.sfpay.core.util.LoadStaticDataUtil;
import com.sfpay.core.util.ReconUtil;
import com.sfpay.core.util.SFTPUtils;
import com.sfpay.core.util.SpringContextHolder;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.front.cnst.ChannelCnst;
import com.sfpay.front.cnst.DateCnst;
import com.sfpay.front.cnst.FunctionCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.ReconCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.cnst.TradeTypeCnst;
import com.sfpay.front.function.Function;
import com.sfpay.front.util.SfpayFileUtils;
import com.sfpay.upc.gw.domain.sys.req.ManualNotifyReq;
import com.sfpay.upc.gw.domain.sys.resp.ManualNotifyResp;
import com.sfpay.upc.gw.service.IManualNotifyService;

/**
 * 
 * 类说明：<br>
 * 后台操作页面整合
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349 
 * 
 * CreateDate: 2016年12月28日
 */
@Controller
@RequestMapping("/back")
@SuppressWarnings({ "unchecked", "rawtypes" })
public class BackOpController {
	private static final int MAX_NOTIFY_QTY = 20;
	private static final Logger LOGGER = LoggerFactory.getLogger(BackOpController.class);
	private static final String OP_TYPE_ADD = "add";
	private static final String OP_TYPE_UPDATE = "update";
	private static final String OP_TYPE_DOWNLOAD = "download";
	private static final String OP_TYPE_ANALYSIS = "analysis";
	private static final String OP_TYPE_SYNC = "sync";
	private static final String OP_TYPE_REFRESH = "refresh";
	private static final String OP_TYPE_DELETE = "delete";
	private static final List<String> RE_STATUS_LIST = Arrays.asList(new String[] { ReconCnst.RECON_STATUS_INIT,
			ReconCnst.RECON_STATUS_FAILURE, ReconCnst.RECON_STATUS_DOWNLOAD, ReconCnst.RECON_STATUS_ANALYSIS });
	@Resource
	private RedisTemplate redisTemplate;
	@Resource
	private IChannelReconFileDao channelReconFileDao;
	@Resource
	private IReconCoreService reconCoreService;
	@Resource
	private IMerchantConfDao merchantConfDao;
	@Resource
	private ITradeCoreService tradeCoreService;
	@Resource
	private INotifyResultService notifyResultService;
	
	@Resource
	private IPayInfoCoreService payInfoCoreService;
	@Resource
	private IManualNotifyService manualNotifyService;
	
	@Resource
	private LoadStaticDataUtil loadStaticDataUtil;
	
	@RequestMapping("/toPage")
	public String downloadPage(Model model) {
		return "/op";
	}

	@RequestMapping("/toPage/{childPage}")
	public String toChildPage(@PathVariable String childPage, Model model) {
		LOGGER.info("时间[{}]进入后台页面[{}]", new Date(), childPage);
		return "/" + childPage;
	}

	@RequestMapping(value = "/file/exec", produces = "plain/text;charset=UTF-8")
	@ResponseBody
	public String fileExec(String channelCode, String billMchNo, String fileDate, String extArg, String targetStatus,
			String payCode, String opType) {
		String logMsg = String.format("通道[%s],商户号[%s],对账日期[%s],扩展参数[%s],目标状态[%s],类型[%s],所属[%s]初始化对账",
				new Object[] { channelCode, billMchNo, fileDate, extArg, targetStatus, opType, payCode });
		LOGGER.info("{}", logMsg);
		int count = 0;
		if (OP_TYPE_ADD.equals(opType)) {
			ChannelReconFileDto reconFile = new ChannelReconFileDto();
			reconFile.setChannelCode(channelCode);
			reconFile.setBillMchNo(billMchNo);
			reconFile.setExtArg(extArg);
			reconFile.setStatus(targetStatus);
			reconFile.setPayCode(payCode);
			StringBuilder fileName = new StringBuilder().append(channelCode).append(ReconUtil.FILE_SEPERATOR)
					.append(payCode).append(ReconUtil.FILE_SEPERATOR).append(reconFile.getBillMchNo())
					.append(ReconUtil.FILE_SEPERATOR).append(fileDate).append(ReconUtil.FILE_SUFFIX);
			reconFile.setFileName(fileName.toString());
			try {
				Date date = DateUtils.parse(fileDate, DateCnst.YYYYMMDD);
				reconFile.setFileDate(date);
				List<ChannelReconFileDto> reconFileList = new ArrayList<ChannelReconFileDto>();
				reconFileList.add(reconFile);
				count = channelReconFileDao.createChannelReconFile(reconFileList);
			} catch (Exception e) {
				LOGGER.error("{}异常", logMsg, e);
				return e.getMessage();
			}
		}

		if (OP_TYPE_UPDATE.equals(opType)) {
			Map<String, String> updateMap = new HashMap<String, String>();
			updateMap.put(SqlCnst.CHANNEL_CODE, channelCode);
			updateMap.put(ReconCnst.BILL_MCH_NO, billMchNo);
			updateMap.put(ReconCnst.EXT_ARG, extArg);
			updateMap.put(SqlCnst.TARGET_STATUS, targetStatus);
			updateMap.put(SqlCnst.PAY_CODE, payCode);
			try {
				Date date = DateUtils.parse(fileDate, DateCnst.YYYYMMDD);
				count = channelReconFileDao.updateReconFile(updateMap, date);
			} catch (Exception e) {
				LOGGER.error("{}异常", logMsg, e);
				return e.getMessage();
			}
		}
		return "初始化条数为" + count;
	}

	@RequestMapping(value = "/schedule/exec", produces = "plain/text;charset=UTF-8")
	@ResponseBody
	public String scheduleExec(String channelCode, String billMchNo, String fileDate, String opType, String payCode) {
		String logMsg = String.format("通道[%s],商户号[%s],对账日期[%s],类型[%s],所属[%s]",
				new Object[] { channelCode, billMchNo, fileDate, opType, payCode });
		LOGGER.info("{}开始执行", logMsg);

		try {
			Date date = DateUtils.parse(fileDate, DateCnst.YYYYMMDD);
			Map<String, String> reqMap = new HashMap<String, String>();
			reqMap.put(MapCnst.CHANNEL_CODE, channelCode);
			reqMap.put("billMchNo", billMchNo);
			reqMap.put("payCode", payCode);
			List<ChannelReconFileDto> reconFileList = channelReconFileDao.queryAllReconFile(reqMap, date,
					RE_STATUS_LIST);
			for (ChannelReconFileDto reconFile : reconFileList) {
				if (OP_TYPE_DOWNLOAD.equals(opType) && (ReconCnst.RECON_STATUS_INIT.equals(reconFile.getStatus())
						|| ReconCnst.RECON_STATUS_FAILURE.equals(reconFile.getStatus()))) {
					reconCoreService.downloadReconFile(System.currentTimeMillis() + "", reconFile);
				} else if (OP_TYPE_ANALYSIS.equals(opType)
						&& ReconCnst.RECON_STATUS_DOWNLOAD.equals(reconFile.getStatus())) {
					reconCoreService.analysisReconFile(System.currentTimeMillis() + "", reconFile);
				} else if (OP_TYPE_SYNC.equals(opType)
						&& ReconCnst.RECON_STATUS_ANALYSIS.equals(reconFile.getStatus())) {
					reconCoreService.syncReconFile(System.currentTimeMillis() + "", reconFile);
				}
			}
		} catch (Exception e) {
			LOGGER.error("{}异常", logMsg, e);
			return e.getMessage();
		}
		return "执行成功";
	}

	@RequestMapping(value = "/redis/exec", produces = "plain/text;charset=UTF-8")
	@ResponseBody
	public String redisExec(String opType, String redisKey) {
		LOGGER.info("redis缓存控制,操作类型[{}],键[{}]", opType, redisKey);
		try {
			if (OP_TYPE_DELETE.equals(opType)) {
				redisTemplate.delete(redisKey);
			} else if (OP_TYPE_REFRESH.equals(opType)) {
				SpringContextHolder.getApplicationContext().publishEvent(new LoadDataApplicationEvent(this));
			} else if (OP_TYPE_UPDATE.equals(opType)) {
				RedisAtomicInteger redis = new RedisAtomicInteger(redisKey, redisTemplate);
				int oldValue = redis.getAndSet(0);
				return "旧值" + oldValue;
			}
		} catch (Exception e) {
			LOGGER.error("操作[{}]异常", opType, e);
			return e.getMessage();
		}
		return "执行成功";
	}

	@RequestMapping(value = "/mch/exec")
	@ResponseBody
	public String mchExec(String channelCode, String mchNo, String payCode) {
		String logMsg = String.format("商户[%s]配置,切换通道为[%s],付款渠道为[%s]", mchNo, channelCode, payCode);
		LOGGER.info("{}开始执行", logMsg);

		Map<String, String> updateMap = new HashMap<String, String>();
		updateMap.put("channelCode", channelCode);
		updateMap.put("mchNo", mchNo);
		updateMap.put("payCode", payCode);
		try {
			int updateCnt = merchantConfDao.updateMerchantConf(updateMap);
			return "更新结果:" + updateCnt;
		} catch (Exception e) {
			return e.getMessage();
		}
	}
	
	@RequestMapping(value = "/upload/bill")
	@ResponseBody
	public String uploadBill(@RequestParam(value = "file", required = false) MultipartFile file, String channelCode,
			String opType, HttpServletRequest request) {
		String logMsg = String.format("南粤银行,人工上传" + ("bank".equals(opType) ? "银行" : "清算") + "[%s]对账文件,支付渠道编码[%s]",
				file.getOriginalFilename(), channelCode);
		LOGGER.info("上传对账文件{}", logMsg);
		String dir = "bank".equals(opType) ? "/bank/" : "/";
		String serverLocalPath = Property.getProperty(ReconCnst.LOCAL_PATH) + channelCode;
		// sftp地址
		String remoteSftpPath = Property.getProperty(ReconCnst.SFTP_PATH) + channelCode;
		File billDir = null;
		File billFile = null;
		try {
			billDir = new File(serverLocalPath + dir);
			if (!billDir.exists()) {
				billDir.mkdirs();
			}
			billFile = new File(serverLocalPath + dir + file.getOriginalFilename());
			file.transferTo(billFile);

			SFTPUtils sftpClient = new SFTPUtils(Property.getProperty(ReconCnst.SFTP_IP),
					Integer.parseInt(Property.getProperty(ReconCnst.SFTP_PORT)),
					Property.getProperty(ReconCnst.SFTP_USER), Property.getProperty(ReconCnst.SFTP_PASS), 0);

			sftpClient.upload(remoteSftpPath + dir, billFile.getAbsolutePath());
		} catch (Exception e) {
			LOGGER.error("{},上传SFTP异常", logMsg, e);
			return e.getMessage();
		} finally {
			if (billFile != null && billFile.exists()) {
				try {
					SfpayFileUtils.forceDelete(billFile);
				} catch (IOException e) {
				}
			}
		}
		return "上传成功";
	}
	
	@RequestMapping(value = "/reRefund")
	@ResponseBody
	public String reRefund(String reqOrderNo, HttpServletRequest request) {
		String logMsg = String.format("人工对退款失败的订单重新发起退款,退款请求订单号[%s]",reqOrderNo);
		String rs = "退款失败"; 
		try {
			if(StringUtils.isBlank(reqOrderNo)){
				return "参数为空";
			}
			Map<String, String> reqMap = new HashMap<String, String>();
			reqMap.put(SqlCnst.REQ_ORDER_NO, reqOrderNo);
			UpcPayInfoDto payInfoDto =  tradeCoreService.reRefund(reqMap);
			if(payInfoDto != null ){
				if(StatusCnst.REFUND_SUCC.equals(payInfoDto.getStatus())){
					rs = "退款成功"; 
					notifyResultService.notifyResult(payInfoDto);
					LOGGER.info("{},退款通知成功", logMsg);
				}else if(StatusCnst.REFUND_FAIL.equals(payInfoDto.getStatus())){
					rs = "退款失败," + payInfoDto.getRtnMsg(); 
				}else{
					rs = "退款进行中"; 
				}
			}
			LOGGER.info("{},退款处理结果[{}]", logMsg, rs);
		}catch (Exception e) {
			LOGGER.error("{},重新退款异常", logMsg, e);
			return e.getMessage();
		}
		return rs;
	}
	@RequestMapping(value = "/query")
	@ResponseBody
	public String query(String uppOrderNo,String appendBusType, HttpServletRequest request) {
		String logMsg = String.format("人工对交易中的订单重新发起查询,业务订单号[%s]",uppOrderNo);
		String rs = "查询失败"; 
		try {
			if(StringUtils.isBlank(uppOrderNo)){
				return "参数为空";
			}
			Map<String, Object> queryMap = new HashMap<String, Object>();
			queryMap.put(SqlCnst.UPP_ORDER_NO, uppOrderNo);
			queryMap.put(SqlCnst.APPEND_BUS_TYPE, StringUtils.isBlank(appendBusType) ? AppendBusTypeCnst.APPEND_BUS_TYPE_NORMAL : appendBusType);
			UpcPayInfoDto payInfo = payInfoCoreService.queryPayInfo(queryMap);
			if (payInfo == null) {
				return "订单不存在";
			}
			LOGGER.info("{},支付信息处理前状态:{}", logMsg, payInfo.getStatus());
			if (StatusCnst.TRADING.equals(payInfo.getStatus()) || StatusCnst.REFUND_PROC.equals(payInfo.getStatus())) {
				if (TradeTypeCnst.TRADE_TYPE_PAY.equals(payInfo.getTradeType())) {
					payInfo = tradeCoreService.payQuery(payInfo);
				} else {
					payInfo = tradeCoreService.refundQuery(payInfo);
				}
			}
			LOGGER.info("{},支付信息处理后状态:{}", logMsg, payInfo.getStatus());
			if(payInfo != null ){
				if(StatusCnst.REFUND_SUCC.equals(payInfo.getStatus()) || StatusCnst.SUCCESS.equals(payInfo.getStatus())){
					rs = "查询结果[订单状态成功]"; 
					notifyResultService.notifyResult(payInfo);
				}else if(StatusCnst.REFUND_FAIL.equals(payInfo.getStatus())){
					rs = "订单为清算补单，查询结果[订单状态失败]"; 
					notifyResultService.notifyResult(payInfo);
				}else if(StatusCnst.FAILURE.equals(payInfo.getStatus())){
					rs = "查询结果[订单状态失败]," + payInfo.getRtnMsg(); 
				}else{
					rs = "查询结果[订单状态进行中]"; 
				}
			}
			LOGGER.info("{},{}", logMsg, rs);
		}catch (Exception e) {
			LOGGER.error("{},重新退款异常", logMsg, e);
			return e.getMessage();
		}
		return rs;
	}
	
	@RequestMapping(value = "/notify")
	@ResponseBody
	public String notify(String uppOrderNo, HttpServletRequest request) {
		String rs = "查询失败"; 
		try {
			ManualNotifyReq req = new ManualNotifyReq();
			req.setUppOrderNos(getUppOrderNos(uppOrderNo));			
			ManualNotifyResp resp = manualNotifyService.notifyResult(req);			
			rs = getRespMessage(resp);			
		} catch (ServiceException e) {
			LOGGER.error(e.getMsg());
			if (StringUtils.trimToEmpty(e.getCode()).startsWith("MC")) {
				rs = e.getMsg();
			} else {
				rs = "发起了补偿通知失败!";
			}
		} catch (Exception e) {
			LOGGER.error("maintain-->notify发生异常", e);
			rs = "发起了补偿通知失败!";
		}
		return rs;
	}
	
	@RequestMapping(value = "/refreshToken")
	@ResponseBody
	public String refreshToken(String type) {
		long start = 0L;
		String rs = "强制刷新[" +type+ "]"; 
		try {
			start = System.currentTimeMillis();
			LOGGER.info("refreshTokenTask——>start开始时间[{}]", start);
			Map<String, String> extMap = loadStaticDataUtil.initCommonExtMap(ChannelCnst.CHANNEL_WE);
			if("TOKEN".equals(type)){
				extMap.put("forceRefreshToken", "forceRefreshToken");
			}else{
				extMap.put("forceRefreshTicket", "forceRefreshTicket");
			}
			Map<String, String> respMap = ((Function) SpringContextHolder.getBean(extMap.get(MapCnst.FUNCTION_NAME)))
					.getResp(start + "", FunctionCnst.REFRESH_TOKEN_FUNCTION, null, extMap);
			LOGGER.info("refreshTokenTask返回结果{}", respMap);
			rs = rs + ", 刷新成功";
		} catch (Exception e) {
			LOGGER.error("refreshTokenTask执行过程中异常", e);
			rs = rs + ", 刷新失败";
		} finally {
			LOGGER.info("refreshTokenTask——>end,随机号[{}]耗时[{}]", start, (System.currentTimeMillis() - start));
		}
		return rs;
	}
	
	/**
	 * 解析业务订单号列表
	 * @param notify
	 * @return
	 * @throws ServiceException
	 */
	private List<String> getUppOrderNos(String notify) throws ServiceException {
		if (StringUtils.isBlank(notify)) {
			throw new ServiceException("MC001", "业务订单号不能为空!");
		}
		String[] strings = StringUtils.split(notify, ",");
		Set<String> resultList = Sets.newHashSet();
		for (String string : strings) {
			if (StringUtils.isBlank(string)) {
				continue;
			}
			resultList.add(StringUtils.trim(string));
		}
		if (resultList.size() > MAX_NOTIFY_QTY) {
			throw new ServiceException("MC002", "输入业务订单号超过最大处理数量[" + MAX_NOTIFY_QTY + "]!");
		}
		return Lists.newArrayList(resultList);
	}
	/**
	 * 返回结果消息
	 * @param resp
	 * @return
	 */
	private String getRespMessage(ManualNotifyResp resp) {
		if (StringUtils.isNotBlank(resp.getMessage())) {
			return resp.getMessage();
		}
		StringBuilder sb = new StringBuilder();
		if (!CollectionUtils.isEmpty(resp.getSuccessList()) ) {
			sb.append(";")
			  .append(String.format("已成功发起了补偿通知订单号：%s", StringUtils.join(resp.getSuccessList(), ",")));
		}
		if (!CollectionUtils.isEmpty(resp.getFailedList()) ) {
			sb.append(";")
			.append(String.format("发起了补偿通知失败订单号：%s", StringUtils.join(resp.getFailedList(), ",")));
		}
		if (!CollectionUtils.isEmpty(resp.getNoHandleList()) ) {
			sb.append(";")
			.append(String.format("无需发起了补偿通知订单号：%s", StringUtils.join(resp.getNoHandleList(), ",")));
		}
		return sb.length() > 0 ? sb.deleteCharAt(0).toString() : sb.toString();
	}
}
