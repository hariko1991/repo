/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.dto;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年9月6日
 */
public class MchRegInfoDto extends BaseDto {
	private static final long serialVersionUID = -2335531737422595269L;
	private String mchRegNo;
	private String channelCode;
	private String regPayCode;
	private String confCode;
	private String mchNo;
	private String mchName;
	private String channelMchNo;
	private String subMchNo;
	private String billMchNo;
	private String baseInfo;
	private String baseExtInfo;
	private String rtnInfo;
	private String status;

	public String getMchRegNo() {
		return mchRegNo;
	}

	public void setMchRegNo(String mchRegNo) {
		this.mchRegNo = mchRegNo;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getRegPayCode() {
		return regPayCode;
	}

	public void setRegPayCode(String regPayCode) {
		this.regPayCode = regPayCode;
	}

	public String getConfCode() {
		return confCode;
	}

	public void setConfCode(String confCode) {
		this.confCode = confCode;
	}

	public String getMchNo() {
		return mchNo;
	}

	public void setMchNo(String mchNo) {
		this.mchNo = mchNo;
	}

	public String getMchName() {
		return mchName;
	}

	public void setMchName(String mchName) {
		this.mchName = mchName;
	}

	public String getChannelMchNo() {
		return channelMchNo;
	}

	public void setChannelMchNo(String channelMchNo) {
		this.channelMchNo = channelMchNo;
	}

	public String getSubMchNo() {
		return subMchNo;
	}

	public void setSubMchNo(String subMchNo) {
		this.subMchNo = subMchNo;
	}

	public String getBillMchNo() {
		return billMchNo;
	}

	public void setBillMchNo(String billMchNo) {
		this.billMchNo = billMchNo;
	}

	public String getBaseInfo() {
		return baseInfo;
	}

	public void setBaseInfo(String baseInfo) {
		this.baseInfo = baseInfo;
	}

	public String getBaseExtInfo() {
		return baseExtInfo;
	}

	public void setBaseExtInfo(String baseExtInfo) {
		this.baseExtInfo = baseExtInfo;
	}

	public String getRtnInfo() {
		return rtnInfo;
	}

	public void setRtnInfo(String rtnInfo) {
		this.rtnInfo = rtnInfo;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

}
