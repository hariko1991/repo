package com.sfpay.core.dto;

import java.util.Date;

import com.sfpay.sypay.common.BaseEntity;

/**
 * 
 * 类说明：<br>
 * 银行对账单下载接口
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 875504 zhangnannan
 * 
 * CreateDate: 2017-5-3
 */

public class BankBillDownloadInt extends BaseEntity {

	private static final long serialVersionUID = 9032379187261016703L;
	/**商户订单号*/
	private String merOrderNo;
	/**组织机构号*/
	private String channelOrgCode;
	/**商户号*/
	private String channelOrgMerNo;
	/**交易流水号*/
	private String tradeSn;
	/**消费时间*/
	private Date tradeTime;
	/**消费状态*/
	private String tradeStatus;
	/**消费类型*/
	private String tradeType;
	/**订单金额*/
	private Long orderAmt;
	/**商户实收*/
	private Long merAmt;
	/**手续费*/
	private Long fee;
	private Long otherFee;
	/**收单设备*/
	private String orderEqu;
	/**下载日期*/
	private Date reconFileDate;
	/**清算商户号*/
	private String clrMchNo;

	public String getMerOrderNo() {
		return merOrderNo;
	}

	public void setMerOrderNo(String merOrderNo) {
		this.merOrderNo = merOrderNo;
	}

	public String getTradeSn() {
		return tradeSn;
	}

	public void setTradeSn(String tradeSn) {
		this.tradeSn = tradeSn;
	}

	public Date getTradeTime() {
		return tradeTime;
	}

	public void setTradeTime(Date tradeTime) {
		this.tradeTime = tradeTime;
	}

	public String getTradeStatus() {
		return tradeStatus;
	}

	public void setTradeStatus(String tradeStatus) {
		this.tradeStatus = tradeStatus;
	}

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

	public Long getOrderAmt() {
		return orderAmt;
	}

	public void setOrderAmt(Long orderAmt) {
		this.orderAmt = orderAmt;
	}

	public Long getMerAmt() {
		return merAmt;
	}

	public void setMerAmt(Long merAmt) {
		this.merAmt = merAmt;
	}

	public Long getFee() {
		return fee;
	}

	public void setFee(Long fee) {
		this.fee = fee;
	}

	public Long getOtherFee() {
		return otherFee;
	}

	public void setOtherFee(Long otherFee) {
		this.otherFee = otherFee;
	}

	public String getOrderEqu() {
		return orderEqu;
	}

	public void setOrderEqu(String orderEqu) {
		this.orderEqu = orderEqu;
	}

	public Date getReconFileDate() {
		return reconFileDate;
	}

	public void setReconFileDate(Date reconFileDate) {
		this.reconFileDate = reconFileDate;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public String getChannelOrgCode() {
		return channelOrgCode;
	}

	public void setChannelOrgCode(String channelOrgCode) {
		this.channelOrgCode = channelOrgCode;
	}

	public String getChannelOrgMerNo() {
		return channelOrgMerNo;
	}

	public void setChannelOrgMerNo(String channelOrgMerNo) {
		this.channelOrgMerNo = channelOrgMerNo;
	}

	public String getClrMchNo() {
		return clrMchNo;
	}

	public void setClrMchNo(String clrMchNo) {
		this.clrMchNo = clrMchNo;
	}

}
