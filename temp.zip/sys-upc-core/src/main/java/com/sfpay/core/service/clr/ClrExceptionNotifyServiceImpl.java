package com.sfpay.core.service.clr;

import java.util.Date;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import javax.annotation.Resource;

import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.clr.gw.sao.IChannelExceptionNotifyService;
import com.sfpay.clr.gw.sao.domain.channel.ChannelReExtractReq;
import com.sfpay.clr.gw.sao.domain.channel.ChannelReExtractResp;
import com.sfpay.core.cnst.ClearingDataStatus;
import com.sfpay.core.cnst.InfoCode;
import com.sfpay.core.dao.IBankRecon4CLRDao;
import com.sfpay.core.dao.IClrChannelDao;
import com.sfpay.core.dto.BankReconDataStatus;
import com.sfpay.core.dto.ChannelReconFileDto;
import com.sfpay.core.dto.ChannelTradeDataStatus;
import com.sfpay.core.service.IChannel4CLRService;
import com.sfpay.core.service.IChannelReconService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;

/**
 * 
 * 类说明：<br>
 * 清算数据重抽实现类
 * 
 * <p>
 * 详细描述：<br>
 * 包含通道交易数据重抽、银行对账文件数据重抽
 * 
 * </p>
 * 
 * @author 830598 wu_jl
 * 
 *         CreateDate: 2017年5月3日
 */
@Service
@HessianExporter("/clrExceptionNotifyService")
public class ClrExceptionNotifyServiceImpl implements IChannelExceptionNotifyService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	private ExecutorService executor = Executors.newCachedThreadPool();
	private static final String SIDE_CHANNEL = "CHANNEL";
	private static final String SIDE_BANK = "BANK";
	private static final String SIDE_ALL = "ALL";
	private static final String REEXTRACT_FAILURE_0 = "0";// 失败
	private static final String REEXTRACT_SUCCESS_1 = "1";// 成功
	private static final String REEXTRACT_RELOAD_2 = "2";// 正在对账中

	@Resource
	private IBankRecon4CLRDao bankRecon4CLRDao;

	@Resource
	private IChannel4CLRService channel4CLRService;

	@Resource
	private IChannelReconService channelReconService;

	@Resource
	private IClrChannelDao clrChannelDao;

	@Override
	public List<ChannelReExtractResp> notifyChannelBatchReExtract(List<ChannelReExtractReq> channelNotifyReqs) {
		return null;
	}

	@Override
	public ChannelReExtractResp notifyChannelSingleReExtract(ChannelReExtractReq channelNotifyReq) {
		if (null == channelNotifyReq) {
			throw new ServiceException(InfoCode.PARAM_NULL, "请求参数不能为空");
		}
		String side = channelNotifyReq.getSide();// 指定重跑方向,CHANNEL代表通道端重新抽取,BANK代表銀行端重新抽取,ALL代表都要重新抽取
		String channelTypeCode = channelNotifyReq.getChannelTypeCode(); // 渠道类型：QPAY_DEBIT、QPAY_CREDIT
		String channelOrgCode = channelNotifyReq.getChannelOrgCode(); // 渠道机构：
																		// ICBC、ABC等
		Date reconFileDate = channelNotifyReq.getReconDate();// 对账文件日期
		String channelOrgMerNo = channelNotifyReq.getChannelOrgMerNo();// 通道机构商户号
																		// 金融机构分配给恒通的商户编号
		ChannelReExtractResp resp = new ChannelReExtractResp();
		resp.setChannelOrgCode(channelOrgCode);
		resp.setChannelOrgMerNo(channelOrgMerNo);
		resp.setChannelTypeCode(channelTypeCode);
		resp.setSide(side);
		resp.setReconDate(reconFileDate);
		resp.setReturnCode(REEXTRACT_FAILURE_0);

		if (StringUtils.isEmpty(channelTypeCode)) {
			logger.error("渠道类型编码为空");
			return resp;
		}
		if (StringUtils.isEmpty(channelOrgCode)) {
			logger.error("渠道机构编码为空");
			return resp;
		}
		if (StringUtils.isEmpty(channelOrgMerNo)) {
			logger.error("渠道机构商户号为空");
			return resp;
		}
		if (null == reconFileDate) {
			logger.error("交易日期为空");
			return resp;
		}

		if (SIDE_CHANNEL.equals(side)) {
			if (checkChannelTradeReconIsReconing(channelTypeCode, channelOrgCode, channelOrgMerNo, reconFileDate)) {
				resp.setReturnCode(REEXTRACT_RELOAD_2);
				resp.setReturnMsg("通道交易数据正在加载中或重新加载中,请稍后再试！");
				return resp;
			}
			// 异步执行重抽通道数据
			executor.execute(new AsyncChannel4CLR(channelNotifyReq));
		} else if (SIDE_BANK.equals(side)) {
			if (checkBankReconIsReconing(channelTypeCode, channelOrgCode, channelOrgMerNo, reconFileDate)) {
				resp.setReturnCode(REEXTRACT_RELOAD_2);
				resp.setReturnMsg("银行对账文件数据正在加载中或重新加载中,请稍后再试！");
				return resp;
			}
			// 异步执行重抽银行数据
			executor.execute(new AsyncBankRecon4CLR(channelNotifyReq));
		} else if (SIDE_ALL.equals(side)) {
			if (checkBankReconIsReconing(channelTypeCode, channelOrgCode, channelOrgMerNo, reconFileDate)) {
				resp.setReturnCode(REEXTRACT_RELOAD_2);
				resp.setReturnMsg("银行对账文件数据正在加载中或重新加载中,请稍后再试！");
				return resp;
			}
			if (checkChannelTradeReconIsReconing(channelTypeCode, channelOrgCode, channelOrgMerNo, reconFileDate)) {
				resp.setReturnCode(REEXTRACT_RELOAD_2);
				resp.setReturnMsg("通道交易数据正在加载中或重新加载中,请稍后再试！");
				return resp;
			}
			// 异步执行银行对账数据重抽
			executor.execute(new AsyncBankRecon4CLR(channelNotifyReq));
			// 异步执行重抽通道数据
			executor.execute(new AsyncChannel4CLR(channelNotifyReq));
		} else {
			throw new ServiceException(InfoCode.PARAM_INVALID, "请求参数【重跑方向side】有误");
		}
		resp.setReturnCode(REEXTRACT_SUCCESS_1);
		return resp;
	}

	/**
	 * 方法说明：<br>
	 * 判断银行对账状态是否为加载中2或重新加载3
	 * 
	 * @param brds
	 */
	private boolean checkBankReconIsReconing(String channelTypeCode, String channelOrgCode, String channelOrgMerNo,
			Date reconFileDate) {
		String rfd = DateUtil.getDateString(reconFileDate, DateUtil.DATA_FORMAT_PATTERN_2);
		logger.info(
				String.format("开始查询[%s-%s-%s]-[%s]日银行对账数据状态记录", channelTypeCode, channelOrgCode, channelOrgMerNo, rfd));
		BankReconDataStatus reconStatus = null;
		try {
			reconStatus = bankRecon4CLRDao.findBankReconDataStatus(channelTypeCode, channelOrgCode, reconFileDate,
					channelOrgMerNo);
		} catch (Exception e) {
			logger.error(String.format("查询[%s-%s-%s]-[%s]日银行对账数据状态记录异常", channelTypeCode, channelOrgCode,
					channelOrgMerNo, rfd), e);
		}
		if (null == reconStatus) {
			return false;
		} else {
			if (ClearingDataStatus.DOING.getStatus().equals(reconStatus.getStatus())
					|| ClearingDataStatus.AGAINDO.getStatus().equals(reconStatus.getStatus())) {
				return true;
			}
			return false;
		}
	}

	private class AsyncBankRecon4CLR implements Runnable {
		private ChannelReExtractReq channelReExtractReq;

		public AsyncBankRecon4CLR(ChannelReExtractReq exceptionNofityReq) {
			this.channelReExtractReq = exceptionNofityReq;
		}

		@Override
		public void run() {
			logger.info("清算系统重新抽取【银行】对账的参数信息：[{}; {}; {}]", new Object[] { channelReExtractReq.getChannelTypeCode(),
					channelReExtractReq.getChannelOrgCode(), channelReExtractReq.getReconDate() });
			String channelTypeCode = channelReExtractReq.getChannelTypeCode(); // 渠道类型：QPAY_DEBIT、QPAY_CREDIT
			String channelOrgMerNo = channelReExtractReq.getChannelOrgMerNo();// 商户号
			String channelOrgCode = channelReExtractReq.getChannelOrgCode(); // 渠道机构：
																				// ICBC、ABC等
			Date reconFileDate = channelReExtractReq.getReconDate();// 对账文件日期
			String rfd = DateUtil.getDateString(reconFileDate, DateUtil.DATA_FORMAT_PATTERN_2);
			try {
				logger.info(String.format("开始重新抽取[%s-%s-%s]-[%s]数据...", channelTypeCode, channelOrgCode,
						channelOrgMerNo, rfd));
				// bankReconService.extractData4CLR(reconFileDate,channelOrgCode);
				// SysDownloadBillReq req = new SysDownloadBillReq();
				// req.setReconFileDate(reconFileDate);
				// req.setTask(false);
				// //cmbcDownBillService.downBill(req);
				ChannelReconFileDto reconFile = new ChannelReconFileDto();
				reconFile.setChannelCode(channelReExtractReq.getChannelOrgCode());
				reconFile.setPayCode(channelReExtractReq.getChannelOrgMerNo());
				reconFile.setFileDate(channelReExtractReq.getReconDate());
				channelReconService.reDownloadReconFile(RandomStringUtils.randomNumeric(32), reconFile);
			} catch (Exception e) {
				logger.error(String.format("重新抽取[%s-%s-%s]-[%s]数据异常！", channelTypeCode, channelOrgCode, channelOrgMerNo,
						rfd), e);
				updateBankReconDataStatus(
						buildBankReconDataStatus(channelTypeCode, channelOrgCode, channelOrgMerNo, reconFileDate));
			}
		}
	}

	/**
	 * 方法说明：<br>
	 * 组装银行对账数据状态记录
	 * 
	 * @param bankRecon4CLR
	 * @return
	 */
	private BankReconDataStatus buildBankReconDataStatus(String channelTypeCode, String channelOrgCode,
			String channelOrgMerNo, Date reconFileDate) {
		String td = DateUtil.getDateString(reconFileDate, DateUtil.DATA_FORMAT_PATTERN_2);
		String reconFileName = new StringBuilder(100).append(channelTypeCode).append("_").append(channelOrgCode)
				.append("_").append(td).toString();
		BankReconDataStatus brds = new BankReconDataStatus();
		brds.setReconFileDate(reconFileDate);
		brds.setChannelTypeCode(channelTypeCode);
		brds.setChannelOrgCode(channelOrgCode);
		brds.setChannelOrgMerNo(channelOrgMerNo);
		brds.setReconFileName(reconFileName);
		brds.setStatus(ClearingDataStatus.FAILURE.getStatus());// "0"-失败
		brds.setDataRows(0L);
		return brds;

	}

	/**
	 * 方法说明：<br>
	 * 更新对应的银行对账状态数据
	 * 
	 * @param brds
	 */
	private void updateBankReconDataStatus(BankReconDataStatus brds) {
		String rfd = DateUtil.getDateString(brds.getReconFileDate(), DateUtil.DATA_FORMAT_PATTERN_2);
		logger.info(String.format("更新[%s-%s-%s]-[%s]日银行对账数据状态为[%s]...", brds.getChannelTypeCode(),
				brds.getChannelOrgCode(), brds.getChannelOrgMerNo(), rfd, brds.getStatus()));
		try {
			bankRecon4CLRDao.updateBankReconDataStatus(brds);
		} catch (Exception e) {
			logger.error(String.format("更新[%s-%s-%s]-[%s]日银行对账数据状态记录异常", brds.getChannelTypeCode(),
					brds.getChannelOrgCode(), brds.getChannelOrgMerNo(), rfd), e);
		}
	}

	/**
	 * 方法说明：<br>
	 * 判断通道交易状态是否为加载中2或重新加载3
	 * 
	 * @param brds
	 */
	private boolean checkChannelTradeReconIsReconing(String channelTypeCode, String channelOrgCode,
			String channelOrgMerNo, Date reconFileDate) {
		String rfd = DateUtil.getDateString(reconFileDate, DateUtil.DATA_FORMAT_PATTERN_2);
		logger.info(String.format("开始查询[%s-%s-%s]-[%s]日通道交易对账数据状态记录", channelTypeCode, channelOrgCode, channelOrgMerNo,
				rfd));
		ChannelTradeDataStatus param = new ChannelTradeDataStatus();
		param.setChannelTypeCode(channelTypeCode);
		param.setChannelOrgCode(channelOrgCode);
		param.setChannelOrgMerNo(channelOrgMerNo);
		param.setTradeDate(reconFileDate);
		ChannelTradeDataStatus reconStatus = null;
		try {
			reconStatus = clrChannelDao.queryChnlDataStatus(param);
		} catch (Exception e) {
			logger.error(String.format("查询[%s-%s-%s]-[%s]日通道交易对账数据状态记录异常", channelTypeCode, channelOrgCode,
					channelOrgMerNo, rfd), e);
		}
		if (null == reconStatus) {
			return false;
		} else {
			if (ClearingDataStatus.DOING.getStatus().equals(reconStatus.getStatus())
					|| ClearingDataStatus.AGAINDO.getStatus().equals(reconStatus.getStatus())) {
				return true;
			}
			return false;
		}
	}

	private class AsyncChannel4CLR implements Runnable {
		private ChannelReExtractReq channelReExtractReq;

		public AsyncChannel4CLR(ChannelReExtractReq exceptionNofityReq) {
			this.channelReExtractReq = exceptionNofityReq;
		}

		@Override
		public void run() {
			logger.info("清算系统重新抽取【通道】的参数信息：[{}; {}; {}]", new Object[] { channelReExtractReq.getChannelTypeCode(),
					channelReExtractReq.getChannelOrgCode(), channelReExtractReq.getReconDate() });
			String channelTypeCode = channelReExtractReq.getChannelTypeCode(); // 渠道类型：QPAY_DEBIT、QPAY_CREDIT
			String channelOrgCode = channelReExtractReq.getChannelOrgCode(); // 渠道机构：
																				// ICBC、ABC等
			Date tradeDate = channelReExtractReq.getReconDate();// 日期
			try {
				channel4CLRService.synchChannelData(tradeDate, channelTypeCode, channelOrgCode,
						channelReExtractReq.getChannelOrgMerNo());
			} catch (Exception e) {
				logger.error(String.format("重新抽取[%s-%s]数据异常！", channelTypeCode, channelOrgCode), e);
			}
		}
	}

}
