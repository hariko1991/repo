package com.sfpay.core.service.trade;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.sfpay.core.cnst.AppendBusTypeCnst;
import com.sfpay.core.cnst.ConfigKeyEnum;
import com.sfpay.core.dao.IMerchantInfoDao;
import com.sfpay.core.dto.ChannelInfoDto;
import com.sfpay.core.dto.ChannelPayDto;
import com.sfpay.core.dto.UpcMonitorDto;
import com.sfpay.core.dto.UpcPayInfoDto;
import com.sfpay.core.service.IPayInfoCoreService;
import com.sfpay.core.service.ITradeCoreSupportService;
import com.sfpay.core.util.ConfigKeyUtils;
import com.sfpay.core.util.DateUtils;
import com.sfpay.core.util.HttpNetworkUtil;
import com.sfpay.core.util.LoadStaticDataUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.DateCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.cnst.TradeTypeCnst;
import com.sfpay.upc.gw.domain.sys.req.SysRefundReq;

@Service("tradeCoreSupportService")
public class TradeCoreSupportServiceImpl implements ITradeCoreSupportService {
	private final Logger LOGGER = LoggerFactory.getLogger(TradeCoreSupportServiceImpl.class);

	@Resource
	private IPayInfoCoreService payInfoCoreService;
	
	@Resource
	private LoadStaticDataUtil loadStaticDataUtil;
	
	@Resource
	private IMerchantInfoDao merchantInfoDao;

	public void validateRepeatRefund(SysRefundReq req, String appendBusType) throws ServiceException {
		if (StringUtils.isEmpty(req.getRefundBizTradeNo())) {
			LOGGER.info("根据退款订单号，验证是否重复退款，因退款订单号为空，无需验证跳过");
			return;
		}
		Map<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put(SqlCnst.APPEND_BUS_TYPE, appendBusType);
		queryMap.put(SqlCnst.UPP_ORDER_NO, req.getRefundBizTradeNo());
		UpcPayInfoDto payInfo = null;
		try {
			payInfo = payInfoCoreService.queryPayInfo(queryMap);
		} catch (Exception e) {
			throw new ServiceException(RtnCodeCnst.FAILURE_DB, "查询数据库失败");
		}
		if (payInfo != null) {
			if (StatusCnst.REFUND_PROC.equals(payInfo.getStatus())) {
				throw new ServiceException(RtnCodeCnst.ORDER_IS_REFUND_PROC, "该订单退款已受理,无需再次退款");
			} else if (StatusCnst.REFUND_SUCC.equals(payInfo.getStatus())) {
				throw new ServiceException(RtnCodeCnst.ORDER_IS_REFUND_SUCC, "该订单退款已成功,无需再次退款");
			} else if (StatusCnst.REFUND_FAIL.equals(payInfo.getStatus())) {
				throw new ServiceException(RtnCodeCnst.ORDER_IS_REFUND_FAIL, "该订单退款已失败");
			}
		}
	}

	public UpcPayInfoDto validateIsAllowRefund(SysRefundReq req) throws ServiceException {
		Map<String, Object> queryMap = new HashMap<String, Object>();
		UpcPayInfoDto upcPayInfo = null;
		try {
			queryMap.put(SqlCnst.TRADE_TYPE, TradeTypeCnst.TRADE_TYPE_PAY);
			if (!req.isSourceBizSystem()) {
				queryMap.put(SqlCnst.REQ_ORDER_NO, req.getChannelTradeNo());
				queryMap.put(SqlCnst.APPEND_BUS_TYPE, AppendBusTypeCnst.APPEND_BUS_TYPE_RESUPPLY);
				queryMap.put(SqlCnst.STATUS, StatusCnst.SUCCESS);
				upcPayInfo = payInfoCoreService.queryPayInfo(queryMap);
			} else {
				queryMap.put(SqlCnst.UPP_ORDER_NO, req.getBizTradeNo());
			}
			if (upcPayInfo == null) {
				queryMap.put(SqlCnst.APPEND_BUS_TYPE, AppendBusTypeCnst.APPEND_BUS_TYPE_NORMAL);
				queryMap.remove(SqlCnst.STATUS);
				upcPayInfo = payInfoCoreService.queryPayInfo(queryMap);
			}
		} catch (Exception e) {
			throw new ServiceException(RtnCodeCnst.FAILURE_DB, "查询数据库失败", e);
		}
		if (upcPayInfo == null) {
			throw new ServiceException(RtnCodeCnst.ORDER_NOT_EXISTS, "原支付订单不存在");
		} else if (!StatusCnst.SUCCESS.equals(upcPayInfo.getStatus())) {
			throw new ServiceException(RtnCodeCnst.ONLY_SUCC_ORDER_CAN_REFUND, "只有交易成功才可以退款");
		} else if (req.getRefundAmt().longValue() > upcPayInfo.getTradeAmt().longValue()) {
			throw new ServiceException(RtnCodeCnst.REFUND_AMOUNT_GT_TRADE_AMOUNT, "退款金额大于支付总金额");
		}
		return upcPayInfo;
	}

	public void validatRefundAmt(SysRefundReq req, UpcPayInfoDto upcPayInfo) throws ServiceException {
		Map<String, Object> queryMap = new HashMap<String, Object>();
		queryMap.put(SqlCnst.MCH_NO, upcPayInfo.getMchNo());
		queryMap.put(SqlCnst.BANK_CHANNEL_CODE, upcPayInfo.getBankChannelCode());
		queryMap.put(SqlCnst.OLD_UPP_ORDER_NO, upcPayInfo.getUppOrderNo());
		List<String> statusList = new ArrayList<String>();
		statusList.add(StatusCnst.REFUND_SUCC);
		statusList.add(StatusCnst.REFUND_PROC);
		queryMap.put(SqlCnst.STATUS_LIST, statusList);
		List<UpcPayInfoDto> refundPayInfoList = null;
		try {
			refundPayInfoList = payInfoCoreService.queryPayInfoList(queryMap);
		} catch (Exception e) {
			throw new ServiceException(RtnCodeCnst.FAILURE_DB, "查询已款记录失败", e);
		}
		long haveRefundAmount = 0; // 已退款金额
		if (refundPayInfoList != null && !refundPayInfoList.isEmpty()) {
			long totalPayAmount = upcPayInfo.getTradeAmt().longValue();
			for (UpcPayInfoDto p : refundPayInfoList) {
				haveRefundAmount += p.getTradeAmt().longValue();
			}
			if (req.getRefundAmt() + haveRefundAmount > totalPayAmount) {
				LOGGER.error("已退款金额大于支付总金额 总金额:[{}], 已退款:[{}] ", totalPayAmount, haveRefundAmount);
				throw new ServiceException(RtnCodeCnst.REFUND_AMOUNT_GT_TRADE_AMOUNT, "已退款金额大于支付总金额");
			}
		}
	}

	/**
	 * 筛选通道
	 * @param mchNo
	 * @param payCode
	 * @return
	 * @throws Exception
	 */
	public String screenChannelCode(String mchNo , String payCode) throws ServiceException{
		Date curDate = new Date();
		List<String> channelCodeList = merchantInfoDao.queryChannelCode(mchNo, payCode);
		if(channelCodeList == null || channelCodeList.isEmpty()){
			throw new ServiceException(RtnCodeCnst.MCH_OF_ARG_IS_NULL,"商户["+mchNo+"]未配置银行映射关系或银行通道不可用");
		}
		String rsChannelCode = "";
		try{
			for (String channelCode : channelCodeList) {
				ChannelInfoDto channelInfoDto = loadStaticDataUtil.getChannelInfo(channelCode , true);
				if(StringUtils.isNotBlank(channelInfoDto.getMtStartTime()) && StringUtils.isNotBlank(channelInfoDto.getMtEndTime())){
					if(DateUtils.after(curDate, DateUtils.parse(channelInfoDto.getMtStartTime(), DateCnst.YYYY_MM_DD_HH_MM_SS))
							&& DateUtils.before(curDate, DateUtils.parse(channelInfoDto.getMtEndTime(), DateCnst.YYYY_MM_DD_HH_MM_SS))){
						LOGGER.error("通道["+channelCode+"]处于维护期");
						continue;
					}
				}
				ChannelPayDto channelPayDto = loadStaticDataUtil.getChannelPayInfo(channelCode, payCode , true);
				if(StringUtils.isNotBlank(channelPayDto.getMtStartTime()) && StringUtils.isNotBlank(channelPayDto.getMtEndTime())){
					if(DateUtils.after(curDate, DateUtils.parse(channelPayDto.getMtStartTime(), DateCnst.YYYY_MM_DD_HH_MM_SS))
							&& DateUtils.before(curDate, DateUtils.parse(channelPayDto.getMtEndTime(), DateCnst.YYYY_MM_DD_HH_MM_SS))){
						LOGGER.error("通道["+channelCode+"]对应的渠道["+payCode+"]处于维护期");
						continue;
					}
				}
				rsChannelCode = channelCode;
				break;
			}
			if(StringUtils.isBlank(rsChannelCode)){
				throw new ServiceException(RtnCodeCnst.FAILURE_SYS,"所有的通道处于维护期");
			}
		}catch (ServiceException e) {
			throw e;
		}catch (Exception e) {
			throw new ServiceException(RtnCodeCnst.FAILURE_SYS,"通道或渠道维护时间配置错误");
		}
		return rsChannelCode;
	}
	
	public void notifyMonitorData(String channelCode, String status , String reqOrderNo) {
		long start = System.currentTimeMillis();
		try {
			if(StringUtils.isBlank(channelCode)){
				LOGGER.info("通道编码为空");
				return;
			}
			String on = ConfigKeyUtils.getStringConfigKeyParam(
					ConfigKeyEnum.UPC_MONITOR_ON_OFF, "OFF");
			if (!HttpNetworkUtil.MONITOR_ON.equals(on)) {
				LOGGER.info("发送监控数据开关处于关闭状态,ON-OFF:{}", on);
				return;
			}
			String networkParam = ConfigKeyUtils.getStringConfigKeyParam(
					ConfigKeyEnum.UPC_MONITOR_CONFIG_PARAM, "");
			if (StringUtils.isBlank(networkParam)) {
				LOGGER.info("发送监控数据通信参数[UPC_MONITOR_CONFIG_PARAM]未配置");
				return;
			}
			UpcMonitorDto dto = new UpcMonitorDto(channelCode, new Date());
			if (StatusCnst.SUCCESS.equals(status) || StatusCnst.REFUND_SUCC.equals(status)) {
				dto.setType(1);
			} else if (StatusCnst.TRADING.equals(status) || StatusCnst.REFUND_PROC.equals(status)) {
				dto.setType(2);
			} else {
				dto.setType(3);
			}
			HttpNetworkUtil.sendMsg(JSONObject.toJSONString(dto), networkParam);
		} catch (Exception e) {
			LOGGER.error("发送监控数据异常,reqOrderNo:{}" , reqOrderNo , e);
		} finally {
			LOGGER.info("发送监控数据,耗时:{}" , (System.currentTimeMillis() - start));
		}
	}
}
