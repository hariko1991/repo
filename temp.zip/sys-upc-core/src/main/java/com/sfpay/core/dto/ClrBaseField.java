/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.dto;

import java.util.Date;

/**
 * 
 * 类说明：<br>
 * 清算系统库表公用字段,数据库必填
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 830598 wu_jl
 * 
 * CreateDate: 2017年5月2日
 */
public class ClrBaseField extends BaseDto {
	
	private static final long serialVersionUID = 1573008873853462430L;
	/**
	 * 通道类型编码 快捷支付、网银支付、POS等（QPAY_DEBIT 快捷借/QPAY_CREDIT快捷贷
	 */
	private String channelTypeCode;
	/**
	 * 通道机构编码 如ICBC
	 */
	private String channelOrgCode;
	/**
	 * 通道机构商户号 金融机构分配给恒通的商户编号
	 */
	private String channelOrgMerNo;
	/**
	 * 创建时间
	 */
	private Date createTime;
	/**
	 * 更新时间
	 */
	private Date updateTime;

	public String getChannelTypeCode() {
		return channelTypeCode;
	}

	public void setChannelTypeCode(String channelTypeCode) {
		this.channelTypeCode = channelTypeCode;
	}

	public String getChannelOrgCode() {
		return channelOrgCode;
	}

	public void setChannelOrgCode(String channelOrgCode) {
		this.channelOrgCode = channelOrgCode;
	}

	public String getChannelOrgMerNo() {
		return channelOrgMerNo;
	}

	public void setChannelOrgMerNo(String channelOrgMerNo) {
		this.channelOrgMerNo = channelOrgMerNo;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

}
