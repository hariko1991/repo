package com.sfpay.core.task;

import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.cnst.ConfigKeyEnum;
import com.sfpay.core.dto.UpcPayInfoDto;
import com.sfpay.core.service.IPayInfoCoreService;
import com.sfpay.core.service.thread.PayQueryAndNotifyThread;
import com.sfpay.core.util.ConfigKeyUtils;
import com.sfpay.front.cnst.ChannelCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.PayModeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.cnst.TradeTypeCnst;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月21日
 */
@Service("realTimePollingTask")
public class RealTimePollingTask {
	private static final Logger LOGGER = LoggerFactory.getLogger(RealTimePollingTask.class);

	private static final String COMPENSATE_WHEN_LONG_13 = "13";
	
	private List<String> CHANNEL_CODE_LIST = Arrays.asList(new String[] { ChannelCnst.CHANNEL_WE });

	@Resource
	private IPayInfoCoreService payInfoCoreService;

	public final void execute() {
		long start = 0L;
		try {
			start = System.currentTimeMillis();
			LOGGER.info("realTimePollingTask——>start开始时间[{}]", start);
			int minute = ConfigKeyUtils.getConfigKeyParam(ConfigKeyEnum.REAL_TIME_POLLING_TASK_WHEN_LONG,
					COMPENSATE_WHEN_LONG_13);
			Date endTime = ConfigKeyUtils.getQueryTime(new Date(), minute);

			Map<String, String> reqMap = new HashMap<String, String>();
			reqMap.put(SqlCnst.TARGET_STATUS, StatusCnst.TRADING);
			reqMap.put(SqlCnst.TRADE_TYPE, TradeTypeCnst.TRADE_TYPE_PAY);
			reqMap.put(MapCnst.PAY_MODE, PayModeCnst.BARCODE_PAY);

			List<UpcPayInfoDto> payInfoList = payInfoCoreService.querySpecifyPayInfoList(endTime, reqMap,
					CHANNEL_CODE_LIST);
			LOGGER.info("realTimePollingTask——>start开始时间[{}],需要查询笔数[{}]", start, payInfoList.size());
			if (CollectionUtils.isNotEmpty(payInfoList)) {
				new PayQueryAndNotifyThread(payInfoList, 1).run();
			}

		} catch (Exception e) {
			LOGGER.error("realTimePollingTask——>end,随机号[{}]异常", e);
		} finally {
			LOGGER.info("realTimePollingTask——>end,随机号[{}]耗时[{}]", start, (System.currentTimeMillis() - start));
		}
	}

}
