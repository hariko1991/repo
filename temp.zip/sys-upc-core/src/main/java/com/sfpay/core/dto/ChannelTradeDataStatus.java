/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.dto;

import java.util.Date;

/**
 * 
 * 类说明：<br>
 * 通道交易数据状态
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 830598 wu_jl
 * 
 *         CreateDate: 2017年5月2日
 */
public class ChannelTradeDataStatus extends ClrBaseField {

	private static final long serialVersionUID = -4937234072390445526L;
	/**
	 * 交易日期
	 */
	private Date tradeDate;
	/**
	 * 数据条数
	 */
	private Long dataRows;
	/**
	 * 数据准备状态:加载失败0,已完成1，加载中2,重新加载 3
	 */
	private String status;
	/**
	 * 间联通道机构编码 如CMBC_IPAY
	 */
	private String indirectChannelOrgCode;

	public Date getTradeDate() {
		return tradeDate;
	}

	public void setTradeDate(Date tradeDate) {
		this.tradeDate = tradeDate;
	}

	public Long getDataRows() {
		return dataRows;
	}

	public void setDataRows(Long dataRows) {
		this.dataRows = dataRows;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getIndirectChannelOrgCode() {
		return indirectChannelOrgCode;
	}

	public void setIndirectChannelOrgCode(String indirectChannelOrgCode) {
		this.indirectChannelOrgCode = indirectChannelOrgCode;
	}

}
