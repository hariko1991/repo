/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.dao;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.sfpay.core.dto.MerchantInfoDto;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月22日
 */
public interface IMerchantInfoDao {

	List<MerchantInfoDto> queryAllMerchantInfo();

	int createMerchantInfo(MerchantInfoDto merchantInfo);

	int updateMerchantInfo(Map<String, String> updateMap);

	MerchantInfoDto queryUniqueMerchantInfo(Map<String, String> reqMap);

	MerchantInfoDto queryMerchantInfo(@Param("mchNo") String mchNo, @Param("channelCode") String channelCode,
			@Param("payCode") String payCode);

	List<MerchantInfoDto> queryMerchantInfo4Clr();
	
	List<String> queryChannelCode(@Param("mchNo") String mchNo, @Param("payCode") String payCode);
}
