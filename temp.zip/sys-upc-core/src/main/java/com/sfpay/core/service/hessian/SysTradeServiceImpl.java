package com.sfpay.core.service.hessian;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections4.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.cnst.AppendBusTypeCnst;
import com.sfpay.core.dto.ChannelInfoDto;
import com.sfpay.core.dto.UpcPayInfoDto;
import com.sfpay.core.service.IMerchantInfoService;
import com.sfpay.core.service.IPayInfoCoreService;
import com.sfpay.core.service.ITradeCoreService;
import com.sfpay.core.util.BeanValidUtils;
import com.sfpay.core.util.LoadStaticDataUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.core.util.StringUtil;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.PayCodeCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.cnst.TradeTypeCnst;
import com.sfpay.upc.gw.domain.sys.req.SysBarcodeReq;
import com.sfpay.upc.gw.domain.sys.req.SysCancelReq;
import com.sfpay.upc.gw.domain.sys.req.SysJsprecreateReq;
import com.sfpay.upc.gw.domain.sys.req.SysQueryReq;
import com.sfpay.upc.gw.domain.sys.req.SysRefundReq;
import com.sfpay.upc.gw.domain.sys.resp.SysBarcodeResp;
import com.sfpay.upc.gw.domain.sys.resp.SysCancelResp;
import com.sfpay.upc.gw.domain.sys.resp.SysJsprecreateResp;
import com.sfpay.upc.gw.domain.sys.resp.SysQueryResp;
import com.sfpay.upc.gw.domain.sys.resp.SysRefundResp;
import com.sfpay.upc.gw.service.ISysTradeService;

@HessianExporter
@Service("sysTradeService")
public class SysTradeServiceImpl implements ISysTradeService {
	private final Logger LOGGER = LoggerFactory.getLogger(SysTradeServiceImpl.class);
	@Resource
	private ITradeCoreService tradeCoreService;

	@Resource
	private IPayInfoCoreService payInfoCoreService;

	@Resource
	LoadStaticDataUtil loadStaticDataUtil;

	@Resource
	IMerchantInfoService merchantInfoService;

	private static final List<String> JSPRECREATE_VALID_FIELD_ARRAY = Arrays
			.asList(new String[] { "mchNo", "srcAmt", "mchOrderNo", "bizTradeNo", "systemSource" });
	private static final List<String> BARCODE_VALID_FIELD_ARRAY = Arrays
			.asList(new String[] { "mchNo", "srcAmt", "mchOrderNo", "bizTradeNo", "systemSource" });

	private static final List<String> REFUND_VALID_FIELD_ARRAY = Arrays
			.asList(new String[] { "mchOrderNo", "refundBizTradeNo", "bizTradeNo", "refundAmt" });

	private static final List<String> CLS_REFUND_VALID_FIELD_ARRAY = Arrays
			.asList(new String[] { "refundBizTradeNo", "channelTradeNo", "refundAmt" });

	@Override
	public SysJsprecreateResp jsprecreate(SysJsprecreateReq req) {
		String logMsg = String.format("一码付预下单商户定单号[%s],业务订单号[%s]", req.getMchOrderNo(), req.getBizTradeNo());
		LOGGER.info("{},请求参数:{}", logMsg, req);

		SysJsprecreateResp resp = new SysJsprecreateResp();

		List<String> validNoPassFields = BeanValidUtils.validNullField(req, JSPRECREATE_VALID_FIELD_ARRAY);
		LOGGER.info("{},校验请求不通过字段:{}", logMsg, validNoPassFields);
		if (CollectionUtils.isNotEmpty(validNoPassFields)) {
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(RtnCodeCnst.ILLEGAL_REQ);
			resp.setRtnMsg("校验不通过字段" + validNoPassFields);
			return resp;
		}

		if(PayCodeCnst.PAY_CODE_ALIPAY.equals(req.getPayCode()) || PayCodeCnst.PAY_CODE_WX.equals(req.getPayCode())){
			if (!((PayCodeCnst.PAY_CODE_ALIPAY.equals(req.getPayCode()) && StringUtils.isNotEmpty(req.getUserId()))
					|| (PayCodeCnst.PAY_CODE_WX.equals(req.getPayCode()) && StringUtils.isNotEmpty(req.getSubAppid())))) {
				resp.setStatus(StatusCnst.FAILURE);
				resp.setRtnCode(RtnCodeCnst.ILLEGAL_REQ);
				resp.setRtnMsg("校验不通过字段subAppid或者subAppid");
				return resp;
			}
		}

		try {
			resp = tradeCoreService.jsprecreate(req);
		} catch (ServiceException e) {
			LOGGER.error("{},异常 :", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(e.getCode());
			resp.setRtnMsg(e.getMessage());
		} catch (Exception e) {
			LOGGER.error("{},异常 :", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(RtnCodeCnst.FAILURE_SYS);
			resp.setRtnMsg(e.getMessage());
		}

		LOGGER.info("{},结果:{}", logMsg, resp);
		return resp;
	}

	@Override
	public SysQueryResp query(SysQueryReq req) {
		String logMsg = String.format("业务订单查询,业务订单号[%s],UPC渠道支付号[%s]", req.getBizTradeNo(), req.getPayNo());
		LOGGER.info("{},请求参数:{}", logMsg, req);
		SysQueryResp resp = new SysQueryResp();
		try {
			Map<String, Object> queryMap = new HashMap<String, Object>();
			if (!StringUtil.isNullOrEmpty(req.getBizTradeNo())) {
				queryMap.put(SqlCnst.UPP_ORDER_NO, req.getBizTradeNo());
			}
			if (!StringUtil.isNullOrEmpty(req.getPayNo())) {
				queryMap.put(SqlCnst.PAY_NO, req.getPayNo());
			}
			queryMap.put(SqlCnst.APPEND_BUS_TYPE, AppendBusTypeCnst.APPEND_BUS_TYPE_NORMAL);
			UpcPayInfoDto payInfo = payInfoCoreService.queryPayInfo(queryMap);
			if (payInfo == null) {
				resp.setRtnCode(RtnCodeCnst.ORDER_NOT_EXISTS);
				resp.setRtnMsg("订单不存在");
				return resp;
			}
			LOGGER.info("{},支付信息处理前状态:{}", logMsg, payInfo.getStatus());
			if (StatusCnst.TRADING.equals(payInfo.getStatus()) || StatusCnst.REFUND_PROC.equals(payInfo.getStatus())) {
				if (TradeTypeCnst.TRADE_TYPE_PAY.equals(payInfo.getTradeType())) {
					payInfo = tradeCoreService.payQuery(payInfo);
				} else {
					payInfo = tradeCoreService.refundQuery(payInfo);
				}
			}
			LOGGER.info("{},支付信息处理后状态:{}", logMsg, payInfo.getStatus());
			// 非交易中 或 退款中的 数据， 组装返回
			if (!StatusCnst.TRADING.equals(payInfo.getStatus())
					&& !StatusCnst.REFUND_PROC.equals(payInfo.getStatus())) {
				ChannelInfoDto channelInfoDto = loadStaticDataUtil.getChannelInfo(payInfo.getBankChannelCode(), false);
				resp.setChannelName(channelInfoDto.getChannelName());
				resp.setChannelCode(payInfo.getBankChannelCode());
				resp.setPayNo(payInfo.getPayNo());
				resp.setBizTradeNo(payInfo.getUppOrderNo());
				resp.setRtnOrderNo(payInfo.getRtnOrderNo());
				resp.setChannelNo(payInfo.getChannelNo());
				Map<String, String> provAcctMap = loadStaticDataUtil.initProvAcctMap(payInfo.getBankChannelCode(),
						payInfo.getPayCode());
				resp.setProvBankCode(provAcctMap.get(MapCnst.PROV_BANK_CODE));
				resp.setProvBankName(provAcctMap.get(MapCnst.PROV_BANK_NAME));
				resp.setProvAcctName(provAcctMap.get(MapCnst.PROV_ACCT_NAME));
				resp.setProvAcctNo(provAcctMap.get(MapCnst.PROV_ACCT_NO));
				resp.setTradeType(payInfo.getTradeType());
				resp.setStatus(payInfo.getStatus());
				// 业务系统要求，将close状态转化为FAILURE状态返回
				if (StatusCnst.CLOSE.equals(resp.getStatus())) {
					resp.setStatus(StatusCnst.FAILURE);
				}
//				else if(StatusCnst.REFUND_FAIL.equals(resp.getStatus())){
//					resp.setStatus(StatusCnst.REFUND_PROC);
//				}
			} else {
				resp.setStatus(payInfo.getStatus());
			}
			resp.setRtnCode(payInfo.getRtnCode());
			resp.setRtnMsg(payInfo.getRtnMsg());
		} catch (Exception e) {
			LOGGER.error("{},异常 :", logMsg, e);
			resp.setRtnCode(RtnCodeCnst.FAILURE);
			resp.setRtnMsg(RtnCodeCnst.FAILURE_MSG);
		}
		return resp;
	}

	@Override
	public SysCancelResp cancel(SysCancelReq req) {
		String logMsg = String.format("订单撤销,业务订单号[%s]", req.getBizTradeNo());
		LOGGER.info("{},请求参数:{}", logMsg, req);
		SysCancelResp resp = new SysCancelResp();
		try {
			resp = tradeCoreService.cancel(req);
		} catch (ServiceException e) {
			LOGGER.error("订单撤销{},异常 :", req, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(e.getCode());
			resp.setRtnMsg(e.getMessage());
		} catch (Exception e) {
			LOGGER.error("订单撤销{},异常 :", req, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(RtnCodeCnst.FAILURE_SYS);
			resp.setRtnMsg(e.getMessage());
		}

		LOGGER.info("订单撤销{},结果:{}", req, resp);
		return resp;
	}

	@Override
	public SysRefundResp refund(SysRefundReq req) {
		LOGGER.info("退款请求参数:{}", req);
		SysRefundResp resp = new SysRefundResp();

		// 验证基本参数
		List<String> validNoPassFields = BeanValidUtils.validNullField(req,
				req.isSourceBizSystem() ? REFUND_VALID_FIELD_ARRAY : CLS_REFUND_VALID_FIELD_ARRAY);
		LOGGER.info("退款请求参数验证,退款业务流水号 [{}],校验请求不通过字段{}", req.getRefundBizTradeNo(), validNoPassFields);
		if (CollectionUtils.isNotEmpty(validNoPassFields)) {
			LOGGER.error("退款请求参数验证,业务流水号 [{}],校验请求不通过字段{}", req.getBizTradeNo(), "channelTradeNo");
			resp.setStatus(StatusCnst.REFUND_FAIL);
			resp.setRtnCode(RtnCodeCnst.ILLEGAL_REQ);
			resp.setRtnMsg("校验不通过字段channelTradeNo");
			return resp;
		}

		try {
			resp = tradeCoreService.refund(req);
		} catch (ServiceException e) {
			LOGGER.error("退款{},异常 :", req, e);
			resp.setStatus(StatusCnst.REFUND_FAIL);
			resp.setRtnCode(e.getCode());
			resp.setRtnMsg(e.getMessage());
		} catch (Exception e) {
			LOGGER.error("退款{},异常 :", req, e);
			resp.setStatus(StatusCnst.REFUND_FAIL);
			resp.setRtnCode(RtnCodeCnst.FAILURE_SYS);
			resp.setRtnMsg(e.getMessage());
		}
		LOGGER.info("请求退款,响应结果{}", new Object[] {resp });
		return resp;
	}

	@Override
	public SysBarcodeResp barcode(SysBarcodeReq req) {
		String logMsg = String.format("条码支付下单商户定单号[%s],业务订单号[%s]", req.getMchOrderNo(), req.getBizTradeNo());
		LOGGER.info("{},请求参数:{}", logMsg, req);

		SysBarcodeResp resp = new SysBarcodeResp();

		List<String> validNoPassFields = BeanValidUtils.validNullField(req, BARCODE_VALID_FIELD_ARRAY);
		LOGGER.info("{},校验请求不通过字段:{}", logMsg, validNoPassFields);
		if (CollectionUtils.isNotEmpty(validNoPassFields)) {
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(RtnCodeCnst.ILLEGAL_REQ);
			resp.setRtnMsg("校验不通过字段" + validNoPassFields);
			return resp;
		}

		try {
			resp = tradeCoreService.barcode(req);
		} catch (ServiceException e) {
			LOGGER.error("{},异常 :", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(e.getCode());
			resp.setRtnMsg(e.getMessage());
		} catch (Exception e) {
			LOGGER.error("{},异常 :", logMsg, e);
			resp.setStatus(StatusCnst.FAILURE);
			resp.setRtnCode(RtnCodeCnst.FAILURE_SYS);
			resp.setRtnMsg(e.getMessage());
		}

		LOGGER.info("{},结果:{}", logMsg, resp);
		return resp;
	}

}
