/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.util;

import java.nio.charset.Charset;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;

import javax.net.ssl.SSLContext;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.config.ConnectionConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.config.SocketConfig;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.LayeredConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;

public final class HttpNetworkUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(HttpNetworkUtil.class);

	public static final String MONITOR_ON = "ON";
	private static final String MONITOR_NETWORK_URL = "NETWORK_URL";
	private static final String MONITOR_READ_TIME_OUT = "READ_TIME_OUT";
	private static final String MONITOR_CONN_TIME_OUT = "CONN_TIME_OUT";
	private static final String EXCHANGE_TYPE_HTTP = "http";
	private static final String EXCHANGE_TYPE_HTTPS = "https";
	private static final String CONTENT_TYPE_VALUE = "application/json;charset=UTF-8";
	private static final String CONTENT_TYPE_KEY = "Content-Type";
	private static final String UTF_8 = "UTF-8";

	public static HttpClient createAuthNonHttpClient() throws Exception {
		SocketConfig socketConfig = SocketConfig.custom().setSoTimeout(100000).build();
		RegistryBuilder<ConnectionSocketFactory> registryBuilder = RegistryBuilder.<ConnectionSocketFactory>create();
		ConnectionSocketFactory plainSF = new PlainConnectionSocketFactory();
		registryBuilder.register(EXCHANGE_TYPE_HTTP, plainSF);
		// 指定信任密钥存储对象和连接套接字工厂
		try {
			KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
			SSLContext sslContext = SSLContexts.custom().useTLS().loadTrustMaterial(trustStore, new AnyTrustStrategy())
					.build();
			LayeredConnectionSocketFactory sslSF = new SSLConnectionSocketFactory(sslContext,
					SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
			registryBuilder.register(EXCHANGE_TYPE_HTTPS, sslSF);
		} catch (Exception e) {
			LOGGER.error("初始化连接池异常", e);
			throw e;
		}
		Registry<ConnectionSocketFactory> registry = registryBuilder.build();
		// 设置连接参数
		ConnectionConfig connConfig = ConnectionConfig.custom().setCharset(Charset.forName(UTF_8)).build();
		// 设置连接管理器
		PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager(registry);
		connManager.setDefaultConnectionConfig(connConfig);
		connManager.setDefaultSocketConfig(socketConfig);
		// 指定cookie存储对象
		BasicCookieStore cookieStore = new BasicCookieStore();
		return HttpClientBuilder.create().setDefaultCookieStore(cookieStore).setConnectionManager(connManager).build();
	}

	public static String sendMsg(String reqMsg, String networkParam) throws Exception {
		HttpResponse resp = null;
		HttpClient httpClient = createAuthNonHttpClient();
		try {
			JSONObject rtnObj = JSONObject.parseObject(networkParam);
			HttpPost httpPost = new HttpPost(rtnObj.getString(MONITOR_NETWORK_URL));
			httpPost.setConfig(getRequestConfig(rtnObj));
			httpPost.setHeader(CONTENT_TYPE_KEY, CONTENT_TYPE_VALUE);
			HttpEntity postEntity = new StringEntity(reqMsg,UTF_8);
			httpPost.setEntity(postEntity);
			resp = httpClient.execute(httpPost);
			HttpEntity entity = resp.getEntity();
			return EntityUtils.toString(entity);
		} catch (Exception e) {
			LOGGER.error("发送监控数据到监控平台{}异常", reqMsg, e);
			throw e;
		} finally {
			HttpClientUtils.closeQuietly(resp);
			HttpClientUtils.closeQuietly(httpClient);
		}
	}

	private static class AnyTrustStrategy implements TrustStrategy {
		@Override
		public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
			return true;
		}
	}

	private static RequestConfig getRequestConfig(JSONObject rtnObj) {
		int readTimeOut = Integer.valueOf(rtnObj.getString(MONITOR_READ_TIME_OUT));
		int connTimeOut = Integer.valueOf(rtnObj.getString(MONITOR_CONN_TIME_OUT));
		return RequestConfig.custom().setSocketTimeout(readTimeOut).setConnectTimeout(connTimeOut).build();
	}
}
