/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.util;

import java.util.Date;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.sfpay.core.service.IChannelArgCoreService;
import com.sfpay.core.service.IChannelInfoService;
import com.sfpay.core.service.IChannelPayService;
import com.sfpay.core.service.IMerchantInfoService;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年3月7日
 */
@Component
public class LoadDataApplicationListener implements ApplicationListener<LoadDataApplicationEvent> {
	private static final Logger LOGGER = LoggerFactory.getLogger(LoadDataApplicationListener.class);

	@Resource
	private IChannelArgCoreService channelArgCoreService;
	@Resource
	private IMerchantInfoService merchantInfoService;
	@Resource
	private IChannelInfoService channelInfoService;
	@Resource
	private IChannelPayService channelPayService;
	@Resource
	private LoadStaticDataUtil loadStaticDataUtil;

	@Override
	public void onApplicationEvent(LoadDataApplicationEvent event) {

		loadData();
	}

	public void loadData() {
		LOGGER.info("触发加载配置变量到内存,开始时间点[{}]", new Date());
		loadStaticDataUtil.setCacheMap(LoadStaticDataUtil.REDIS_KEY_CHANNEL_ARG,
				channelArgCoreService.queryAllChannelArg());
		loadStaticDataUtil.setCacheMap(LoadStaticDataUtil.REDIS_KEY_CHANNEL_INFO,
				channelInfoService.queryAllChannelInfo());
		loadStaticDataUtil.setCacheMap(LoadStaticDataUtil.REDIS_KEY_MERCHANT_INFO,
				merchantInfoService.queryAllMerchantInfo());
		loadStaticDataUtil.setCacheMap(LoadStaticDataUtil.REDIS_KEY_CHANNEL_PAY,
				channelPayService.queryAllChannelPay());
		LOGGER.info("触发加载配置变量到内存,结束时间点[{}]", new Date());
	}

}
