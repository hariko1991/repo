/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.dao.IChannelArgCoreDao;
import com.sfpay.core.dao.IChannelInfoDao;
import com.sfpay.core.dto.ChannelArgDto;
import com.sfpay.core.dto.ChannelInfoDto;
import com.sfpay.core.service.IChannelArgCoreService;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月22日
 */
@Service("channelArgCoreService")
public class ChannelArgCoreServiceImpl implements IChannelArgCoreService {
	private static final Logger LOGGER = LoggerFactory.getLogger(ChannelArgCoreServiceImpl.class);

	@Resource
	private IChannelArgCoreDao channelArgCoreDao;
	@Resource
	private IChannelInfoDao channelInfoDao;

	@Override
	public Map<String, Map<String, String>> queryAllChannelArg() {
		List<ChannelInfoDto> channelInfoList = channelInfoDao.queryAllChannelInfo();
		List<ChannelArgDto> channelArgList = channelArgCoreDao.queryAllChannelArg();
		Map<String, Map<String, String>> channelArgMap = new HashMap<String, Map<String, String>>();

		if (CollectionUtils.isNotEmpty(channelInfoList)) {
			LOGGER.info("数据库中有通道信息[{}]条", channelInfoList.size());
			for (ChannelInfoDto channelInfo : channelInfoList) {
				channelArgMap.put(channelInfo.getChannelCode(), new HashMap<String, String>());
			}
		} else {
			LOGGER.info("数据库中有通道信息[0]条");
		}

		if (CollectionUtils.isNotEmpty(channelArgList)) {
			LOGGER.info("数据库中有银行参数相关配置[{}]条", channelArgList.size());
			for (ChannelArgDto channelArg : channelArgList) {
				if (channelArgMap.keySet().contains(channelArg.getChannelCode())) {
					channelArgMap.get(channelArg.getChannelCode()).put(channelArg.getArgKey(),
							channelArg.getArgValue());
				}
			}
			LOGGER.info("组装银行参数映射完成,结果为[{}]", channelArgMap);
		} else {
			LOGGER.info("数据库中有银行参数相关配置[0]条");
		}

		return channelArgMap;
	}

	@Override
	public Map<String, String> queryChannelArgMap(String channelCode) {
		List<ChannelArgDto> channelArgList = channelArgCoreDao.queryChannelArg(channelCode);
		Map<String, String> channelArgMap = new HashMap<String, String>();

		if (CollectionUtils.isNotEmpty(channelArgList)) {
			LOGGER.info("数据库中有银行[{}]参数相关配置[{}]条", channelCode, channelArgList.size());
			for (ChannelArgDto channelArg : channelArgList) {
				channelArgMap.put(channelArg.getArgKey(), channelArg.getArgValue());
			}
			LOGGER.info("组装银行[{}]参数映射完成,结果为[{}]", channelArgMap);
		} else {
			LOGGER.info("数据库中有银行[{}]参数相关配置[0]条");
		}
		return channelArgMap;
	}

}
