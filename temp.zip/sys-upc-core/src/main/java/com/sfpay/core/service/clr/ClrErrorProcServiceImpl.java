/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service.clr;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.collections4.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.clr.gw.sao.IChannelReconNotifyService;
import com.sfpay.clr.gw.sao.domain.channel.ChannelRefundReq;
import com.sfpay.clr.gw.sao.domain.channel.ChannelRefundResp;
import com.sfpay.clr.gw.sao.domain.channel.ChannelResupplyReq;
import com.sfpay.clr.gw.sao.domain.channel.ChannelResupplyResp;
import com.sfpay.core.cnst.ClrCnst;
import com.sfpay.core.cnst.InfoCode;
import com.sfpay.core.dao.IClrChannelDao;
import com.sfpay.core.dao.IPayInfoCoreDao;
import com.sfpay.core.dto.UpcPayInfoDto;
import com.sfpay.core.service.IClrNotifyService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.gw.domain.sys.req.ClrNotifyReq;
import com.sfpay.upc.gw.domain.sys.req.SysRefundReq;
import com.sfpay.upc.gw.domain.sys.resp.SysRefundResp;
import com.sfpay.upc.gw.service.ISysTradeService;

/**
 * 类说明：<br>
 * 清算系统补查、补单、退款接口实现
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 830598 wu_jl
 * 
 * CreateDate: 2017年5月4日
 */
@Service
@HessianExporter("/clearErrorProcService")
public class ClrErrorProcServiceImpl implements IChannelReconNotifyService {
	private static final Logger logger = LoggerFactory.getLogger(ClrErrorProcServiceImpl.class);
	
	@Resource
	private IPayInfoCoreDao payInfoCoreDao;
	
	@Resource
	private IClrChannelDao clrChannelDao;
	
	@Resource
	private ISysTradeService refundService;
	
	@Resource
	private IClrNotifyService notifyService;
	
	@Override
	public ChannelResupplyResp notifyChannelResupply(ChannelResupplyReq req) {
		checkParam(req);//参数检查
		ChannelResupplyResp resp = new ChannelResupplyResp();
		
		String reconSn = req.getReconSn();
		String chnlOrgCode = req.getChannelOrgCode();
		String chnlMerNo = req.getChannelOrgMerNo();
		
		 //检查该请求银行流水号交易记录
		logger.info(String.format("查询机构-商户号[%s]-[%s]请求银行流水号[%s]通道交易记录...", chnlOrgCode, chnlMerNo, reconSn));
		List<UpcPayInfoDto> payList = null;
		
		try {
			payList = payInfoCoreDao.queryUpcPayInfo4Clr(chnlOrgCode, chnlMerNo, reconSn);
        } catch (Exception e) {
        	logger.error(String.format("查询机构-商户号[%s]-[%s]请求银行流水号[%s]通道交易记录异常", chnlOrgCode, chnlMerNo, reconSn), e);
            resp.setReturnCode(ClrCnst.RETURN_CODE_0);
            resp.setReturnMsg("通道交易不存在");
            return resp;
        }
        if(CollectionUtils.isEmpty(payList)) {
        	logger.error(String.format("查询机构-商户号[%s]-[%s]请求银行流水号[%s]查询交易记录不存在", chnlOrgCode, chnlMerNo, reconSn));
            resp.setReturnCode(ClrCnst.RETURN_CODE_0);
            resp.setReturnMsg("通道对账流水号不存在");
            return resp;
        }
        
        UpcPayInfoDto payInfo = new UpcPayInfoDto();
        if(payList.size() > 1) {
        	for(UpcPayInfoDto upi : payList){
                if(StatusCnst.SUCCESS.equals((upi.getStatus())) || StatusCnst.REFUND_SUCC.equals((upi.getStatus()))) {
                    logger.error(String.format("[清算补单]查询机构-商户号[%s]-[%s]请求银行流水号[%s]通道交易记录中已存在成功状态的交易记录", chnlOrgCode, chnlMerNo, reconSn));
                    if(ClrCnst.APPEND_BUSI_TYPE_RESUPPLY.equals(upi.getAppendBusType())) {
                    	return converRlt(resp, upi, ClrCnst.RETURN_CODE_1, "已存在成功的补登记记录", reconSn);
                    } else {
                    	return converRlt(resp, upi, ClrCnst.RETURN_CODE_2, "该交易记录状态为成功，已不支持补登记", reconSn);
                    }
                }
            }
        } else {
        	payInfo = payList.get(0);
        	if(StatusCnst.SUCCESS.equals((payInfo.getStatus())) || StatusCnst.REFUND_SUCC.equals((payInfo.getStatus()))) {
            	return converRlt(resp, payInfo, ClrCnst.RETURN_CODE_2, "该交易记录状态为成功，已不支持补登记", reconSn);
        	}
        }
        
        //补单操作
        int num = 0;
        try {
        	Date channelTradeTime = clrChannelDao.getDatabaseTime();
            num = payInfoCoreDao.buildClearResupply(reconSn, chnlOrgCode, channelTradeTime);
            payInfo.setEndTime(channelTradeTime);
        } catch (Exception e) {
            logger.error(String.format("为机构-商户号[%s]-[%s]请求银行流水号[%s]补单异常", chnlOrgCode, chnlMerNo, reconSn), e);
            throw new ServiceException(InfoCode.FAILURE_DB, "补单数据库操作异常");
        }
        
        if(num != 1){
            logger.error(String.format("为机构-商户号[%s]-[%s]请求银行流水号[%s]补单失败", chnlOrgCode, chnlMerNo, reconSn));
            resp.setReturnCode(ClrCnst.RETURN_CODE_0);
        	resp.setReturnMsg("未找到原始失败记录");
            return resp;
        }
        
		return converRlt(resp, payInfo, ClrCnst.RETURN_CODE_1, "补登记成功", reconSn);
	}


	/**
	 * 方法说明：<br>
	 * 
	 * @param resp
	 * @param bp
	 * @param returnCode1
	 * @param string
	 * @param reconSn
	 * @return
	 */
	private ChannelResupplyResp converRlt(ChannelResupplyResp resp, UpcPayInfoDto bp, String returnCode, String returnMsg, String reconSn) {
		resp.setReturnCode(returnCode);
		resp.setReturnMsg(returnMsg);
		/** 回填数据至清算系统 **/
		resp.setChannelTypeCode(ClrCnst.CHNL_TYPE_CODE);
		// resp.setChannelOrgMerNo(bp.getChannelMchNo());
		resp.setChannelOrgCode(bp.getBankChannelCode());
		resp.setBizSn(bp.getUppOrderNo());
		resp.setBizSysSrc(bp.getSystemSource());// 需确认
		resp.setChannelCcy(ClrCnst.CHANNEL_RMB.equals(bp.getCcy()) ? ClrCnst.CHANNEL_CNY : ClrCnst.EMPTY);
		resp.setChannelReconSn(reconSn);
		resp.setChannelTradeAmt(bp.getTradeAmt());
		resp.setChannelTradeTime(bp.getEndTime());
		resp.setCustBankAcctNo(ClrCnst.EMPTY);
		resp.setSendOrgSn(reconSn);
		resp.setOriBizSn(bp.getOldUppOrderNo());
		// resp.setOriSendOrgSn(ClrCnst.TRADE_TYPE_REFUND.equals(bp.getTradeType())
		// ? bp.getOldMchOrderNo(): ClrCnst.EMPTY);
		resp.setChannelTradeStatus(ClrCnst.RETURN_CODE_1);// 补单，默认给成功
		String channelTradeType = bp.getTradeType(); // 渠道交易类型"PAY"转换成清算的“PAYMENT”
		if (ClrCnst.TRADE_TYPE_PAY.equals(channelTradeType)) {
			resp.setChannelTradeType(ClrCnst.TRADE_TYPE_PAYMENT);
		} else if (ClrCnst.TRADE_TYPE_PAY_REFUND.equals(channelTradeType)) {
			resp.setChannelTradeType(ClrCnst.TRADE_TYPE_REFUND);
		} else {
			resp.setChannelTradeType(channelTradeType);
		}
		resp.setCustBankCardType(ClrCnst.EMPTY);
		resp.setOrgBackSn(bp.getRtnOrderNo());
		resp.setReconSn(reconSn);
		return resp;
	}


	@Override
	public ChannelRefundResp notifyChannelRefund(ChannelRefundReq cReq) {
		logger.info("[清算退款], 请求入参: {}", cReq.toString());
		SysRefundReq sReq = new SysRefundReq();
		ChannelRefundResp resp = new ChannelRefundResp();
		SysRefundResp sResp = null;
		sReq.setRefundMchOrderNo(cReq.getRefundSn());
		sReq.setRefundBizTradeNo(cReq.getRefundSn());
		sReq.setMchOrderNo(cReq.getRefundSn());
		sReq.setRefundAmt(cReq.getAmt());
		sReq.setChannelTradeNo(cReq.getOriginalOrgSn());//支付交易请求银行流水号
		sReq.setSourceBizSystem(Boolean.FALSE);
		logger.info("[清算退款], 请求upc发起退款: {}", sReq.toString());
		try {
			sResp = refundService.refund(sReq);
		} catch (Exception e) {
			logger.error("[清算退款], 请求upc异常", e);
			resp.setReturnCode(ClrCnst.RETURN_CODE_0);
			resp.setReturnMsg("未知异常，请重试");
			return resp;
		}
		if (null == sResp) {
			logger.error("[清算退款], 退款响应为空");
			resp.setReturnCode(ClrCnst.RETURN_CODE_0);
			resp.setReturnMsg("未知异常，请重试");
			return resp;
		}
		logger.info("[清算退款], upc退款响应报文: {}", sResp.toString());
		String msg = sResp.getRtnMsg();
		String refundStatus = sResp.getStatus();
		resp.setReturnCode(ClrCnst.RETURN_CODE_1);//无异常，则返回接收成功，根据实际返回状态来判断是否通知清算系统
		resp.setReturnMsg(StringUtils.isEmpty(msg) ? "接收成功" : msg);
		if (!refundStatus.equals(TradeStatus.REFUND_PROC.name())) {//若为处理中状态，由交易侧通知clr
			refundStatus = refundStatus.equals(TradeStatus.REFUND_SUCC.name()) ? ClrCnst.RETURN_CODE_1 : ClrCnst.RETURN_CODE_0;
			ClrNotifyReq notifyReq = new ClrNotifyReq();
			notifyReq.setChannelCode(cReq.getChannelOrgCode());
			notifyReq.setRefundStatus(refundStatus);
			notifyReq.setRefundAmt(cReq.getAmt());
			notifyReq.setOriAmt(cReq.getOriginalAmt());
			notifyReq.setOriReqOrderNo(cReq.getOriginalOrgSn());
			notifyReq.setUppOrderNo(cReq.getRefundSn());
			notifyService.notifyClrRefund(notifyReq);//通知clr
		}
		return resp;
	}

	/**
	 * 方法说明：<br>
	 * 
	 * @param req
	 */
	private void checkParam(ChannelResupplyReq req) {
		if(StringUtils.isEmpty(req.getChannelTypeCode())) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "通道类型编码为空");
		}
		
		if(StringUtils.isEmpty(req.getChannelTypeCode()) || !ClrCnst.CHNL_TYPE_CODE.equals(req.getChannelTypeCode())) {
			throw new ServiceException(InfoCode.PARAM_INVALID, "通道类型编码不存在");
		}
		
		if(StringUtils.isEmpty(req.getChannelOrgCode())) {
			throw new ServiceException(InfoCode.PARAM_NULL, "通道机构编码不能为空");
		}
		
		if(StringUtils.isEmpty(req.getChannelOrgMerNo())) {
			throw new ServiceException(InfoCode.PARAM_NULL, "通道机构商户号不能为空");
		}
		
		if(StringUtils.isEmpty(req.getReconSn())) {
			throw new ServiceException(InfoCode.PARAM_NULL, "对账流水号不能为空");
		}
	}

}
