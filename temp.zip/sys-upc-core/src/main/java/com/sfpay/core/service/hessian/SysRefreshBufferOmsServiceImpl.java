package com.sfpay.core.service.hessian;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.util.LoadDataApplicationEvent;
import com.sfpay.core.util.SpringContextHolder;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.upc.gw.service.ISysRefreshBufferOmsService;

@HessianExporter
@Service("sysRefreshBufferOmsService")
public class SysRefreshBufferOmsServiceImpl implements
		ISysRefreshBufferOmsService {

	private static final Logger LOGGER = LoggerFactory.getLogger(SysRefreshBufferOmsServiceImpl.class);
	
	@Override
	public boolean refreshBuffer() {
		boolean flag = true;
		try {
			LOGGER.info("开始刷新redis缓存");
			SpringContextHolder.getApplicationContext().publishEvent(new LoadDataApplicationEvent(this));
			LOGGER.info("结束刷新redis缓存");
		} catch (Exception e) {
			LOGGER.error("刷新redis缓存异常", e);
			flag = false;
		}
		return flag;
	}

}
