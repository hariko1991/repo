/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.cnst;

/**
 * 
 * 类说明：<br>
 * 用于清算相关常量类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 830598 wu_jl
 * 
 * CreateDate: 2017年5月4日
 */
public final class ClrCnst {
	/**
	 * 通道类型编码
	 */
	public static final String CHNL_TYPE_CODE = "UPC";
	
	/**
	 * 附加业务类型：补单
	 */
    public static final String APPEND_BUSI_TYPE_RESUPPLY = "RESUPPLY";
    
    /**
     * 交易类型 支付
     */
    public static final String TRADE_TYPE_PAY = "PAY";
    
    /**
     * 交易类型 PAY_REFUND
     */
    public static final String TRADE_TYPE_PAY_REFUND = "PAY_REFUND";
    
    /**
     * 交易类型 支付
     */
    public static final String TRADE_TYPE_PAYMENT = "PAYMENT";
    
    /**
     * 交易类型 PAY_REFUND
     */
    public static final String TRADE_TYPE_REFUND = "REFUND";
    
    /**
     * 交易币种
     */
    public static final String CHANNEL_RMB = "RMB";
    
    /**
     * 交易币种
     */
    public static final String CHANNEL_CNY = "CNY";
    
    /**
     * 返回码 补单无记录，原通道交易不存在
     */
    public static final String RETURN_CODE_0 = "0";
    /**
     * 返回码 补单补登记成功(针对通道有对应流水号但是状态不是成功)：通道交易状态不是成功 RESUPPLY_FAILURE_1 = "1"
     */
    public static final String RETURN_CODE_1 = "1";
    
    /**
     * 返回码 补查 通道交易状态为成功 RESUPPLY_SUCCESS_2 = "2"
     */
    public static final String RETURN_CODE_2= "2";
    
    /**
     * 空
     */
    public static final String EMPTY= "";
    
	/**
	 * 附加业务类型：清算退款的附加类型
	 */
    public static final String APPEND_BUSI_TYPE_REFUND = "REFUND";
    
    /**
     * 清算退款通知清算系统URL
     */
    public static final String CLEAR_REFUND_NOTIFY_URL = "CLEAR_REFUND_NOTIFY_URL";
    
    /**
     * 通道AID
     */
    public static final String CHNL_AID = "CHNL_AID";
	
}
