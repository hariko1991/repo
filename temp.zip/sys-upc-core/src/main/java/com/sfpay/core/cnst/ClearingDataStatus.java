package com.sfpay.core.cnst;

/**
 * 
 * 类说明：<br>
 * 清算数据准备状态
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 830598 wu_jl
 * 
 * CreateDate: 2017年5月2日
 */
public enum ClearingDataStatus {
	/**
	 * 加载失败
	 */
	FAILURE("0", "加载失败"),
	/**
	 * 加载成功
	 */
	SUCCESS("1", "加载成功"),
	/**
	 * 加载中
	 */
	DOING("2", "加载中"),
	/**
	 * 重新加载
	 */
	AGAINDO("3", "重新加载");

	private String status;

	private String statusName;

	private ClearingDataStatus(String status, String statusName) {
		this.status = status;
		this.statusName = statusName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

}
