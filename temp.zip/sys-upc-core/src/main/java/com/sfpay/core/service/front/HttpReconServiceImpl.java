/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service.front;

import java.util.Date;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.core.dao.IChannelReconFileDao;
import com.sfpay.core.util.DateUtils;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.cnst.DateCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.ReconCnst;
import com.sfpay.front.service.IHttpReconService;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月6日
 */
@HessianExporter
@Service("httpReconService")
public class HttpReconServiceImpl implements IHttpReconService {
	private static final Logger LOGGER = LoggerFactory.getLogger(HttpReconServiceImpl.class);

	@Resource
	private IChannelReconFileDao channelReconFileDao;

	@Override
	public boolean updateChannelReconFile(String logMsg, Map<String, String> reqMap) throws Exception {
		Date fileDate = null;
		try {
			fileDate = DateUtils.parse(reqMap.get(ReconCnst.FILE_DATE), DateCnst.YYYYMMDD);
		} catch (Exception e) {
			LOGGER.error("[{}]下载对账文件异常", reqMap.get(MapCnst.CHANNEL_CODE), e);
			throw e;
		}
		int count = channelReconFileDao.updateReconFile(reqMap, fileDate);
		LOGGER.info("{}初始化数据库,更新数据库条数[{}]", logMsg, count);
		if (CharCnst.NUMBER_ONE != count) {
			throw new ServiceException("接收数据异常");
		}
		return Boolean.TRUE;
	}

}
