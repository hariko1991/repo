package com.sfpay.core.service;

import java.util.Date;

import com.sfpay.framework2.exception.ServiceException;

import com.sfpay.upc.exception.UPCServiceException;

/**
 * 
 * 类说明：<br>
 * 将银行对账文件数据抽取到对应的库表
 * 
 * </p>
 * 
 * @author 875504 张男男 CreateDate: 2017-05-02
 */
public interface IClrBankReconService {

	/**
	 * 将银行对账文件数据抽取到对应的库表
	 * 
	 * @param tradeDate
	 * @param bc
	 * @return
	 * @throws UPCServiceException
	 */
	public String extractData4CLR(Date tradeDate, String bankCode, String channelOrgMerNo, String flag)
			throws ServiceException;

	/**
	 * 初始化状态表
	 * @param channelTypeCode
	 * @param channelOrgCode
	 * @param channelOrgMerNo
	 * @param reconFileDate
	 * @return
	 * @throws ServiceException
	 */
	public String dealBankReconDataStatus(String channelTypeCode, String channelOrgCode, String channelOrgMerNo,
			Date reconFileDate) throws ServiceException;

}
