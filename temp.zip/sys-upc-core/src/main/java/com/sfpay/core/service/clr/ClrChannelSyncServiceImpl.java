/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.service.clr;

import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.core.cnst.ClearingDataStatus;
import com.sfpay.core.cnst.ClrCnst;
import com.sfpay.core.cnst.InfoCode;
import com.sfpay.core.dao.IClrChannelDao;
import com.sfpay.core.dto.ChannelTradeDataStatus;
import com.sfpay.core.dto.ClrChnlInfo;
import com.sfpay.core.service.IChannel4CLRService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.upc.constant.UpcConstants;

/**
 * 类说明：<br>
 * 清算通道实现类
 * 
 * <p>
 * 详细描述：<br>
 * 包括通道交易数据同步操作
 * 
 * </p>
 * 
 * @author 830598 wu_jl
 * 
 * CreateDate: 2017年5月2日
 */
@Service
@HessianExporter("/channel4CLRService")
public class ClrChannelSyncServiceImpl implements IChannel4CLRService {
	private final Logger logger = LoggerFactory.getLogger(ClrChannelSyncServiceImpl.class);

	@Resource
	private IClrChannelDao clrChannelDao;

	@Override
	public void synchChannelData(Date tradeDate, String channelTypeCode, String channelOrgCode, String channelOrgMchNo)
			throws ServiceException {
		checkParam(tradeDate, channelTypeCode, channelOrgCode);
		tradeDate = DateUtil.getDateFormatStr(DateUtil.getDateString(tradeDate, DateUtil.DATA_FORMAT_PATTERN_2),
				DateUtil.DATA_FORMAT_PATTERN_2);

		// 数据准备状态:加载失败0,已完成1,加载中2,重新加载3
		Long dataRows = 0L;
		ChannelTradeDataStatus param = new ChannelTradeDataStatus();
		param.setTradeDate(tradeDate);
		param.setChannelTypeCode(channelTypeCode);
		param.setChannelOrgCode(channelOrgCode);
		param.setChannelOrgMerNo(channelOrgMchNo);

		logger.info("进入通道数据抽取,抽取日期：[{}]通道类型编码:[{}]通道机构编码:[{}]通道商户号:[{}]",
				new Object[] { DateUtil.getDateString(tradeDate, DateUtil.DATA_FORMAT_PATTERN_2), channelTypeCode,
						channelOrgCode, channelOrgMchNo });
		try {
			ChannelTradeDataStatus tradeData = clrChannelDao.queryChnlDataStatus(param);
			if (tradeData == null) {
				param.setStatus(ClearingDataStatus.DOING.getStatus().toString()); // 加载中
				param.setDataRows(dataRows);
				insertChannelData(param);
			} else {
				if (ClearingDataStatus.DOING.getStatus().toString().equals(tradeData.getStatus())
						|| ClearingDataStatus.AGAINDO.getStatus().toString().equals(tradeData.getStatus())) {
					throw new ServiceException("通道数据抽取中，请稍后再抽取!");
				}
				param.setStatus(ClearingDataStatus.AGAINDO.getStatus().toString()); // 重新加载
				param.setDataRows(dataRows);
				updateChannelStatus(param);
			}
		} catch (Exception e) {
			logger.error("数据库操作通道交易数据状态表失败[{}]", e.getMessage());
			throw new ServiceException(InfoCode.FAILURE_DB, "数据库操作通道交易数据状态表失败");
		}

		String tag = "";
		if (ClearingDataStatus.DOING.getStatus().toString().equals(param.getStatus())) {
			tag = "初始加载";
		} else if (ClearingDataStatus.AGAINDO.getStatus().toString().equals(param.getStatus())) {
			tag = "重新加载";
		}

		logger.info("开始通道数据抽取,执行[{}]", tag);

		// 数据抽取
		try {
			clrChannelDao.excuteSynchChannelData(channelOrgCode, channelTypeCode, param.getStatus(), tradeDate,
					channelOrgMchNo);
		} catch (Exception e) {
			logger.error("同步通道交易接口表数据失败" + e.getMessage());
			param.setStatus(ClearingDataStatus.FAILURE.getStatus().toString());
			updateChannelStatus(param);
		}

		logger.info("完成通道数据抽取,抽取日期：[{}]通道类型编码:[{}]通道机构编码:[{}]通道商户号:[{}]",
				new Object[] { DateUtil.getDateString(tradeDate, DateUtil.DATA_FORMAT_PATTERN_2), channelTypeCode,
						channelOrgCode, param.getChannelOrgMerNo() });
	}

	/**
	 * 方法说明：<br>
	 * 查询机构商户号
	 * 
	 * @param channelOrgCode
	 * @return
	 */
	protected String getChnlAidByOrg(String channelOrgCode) {
		String aid = "";
		try {
			aid = clrChannelDao.getParamVal(channelOrgCode, ClrCnst.CHNL_AID);
		} catch (Exception e) {
			throw new ServiceException(InfoCode.NO_RECORD, "查询通道机构商户号异常");
		}
		return aid;
	}

	/**
	 * 参数校验
	 * 
	 * @param channelTypeCode
	 * @param channelOrgCode
	 * @param tradeDate
	 */
	private void checkParam(Date tradeDate, String channelTypeCode, String channelOrgCode) {
		if (StringUtils.isEmpty(channelTypeCode)) {
			throw new ServiceException(InfoCode.PARAM_NULL, "通道类型编码不能为空");
		}
		if (StringUtils.isEmpty(channelOrgCode)) {
			throw new ServiceException(InfoCode.PARAM_NULL, "通道机构编码不能为空");
		}
		if (tradeDate == null) {
			throw new ServiceException(InfoCode.PARAM_NULL, "交易日期请求参数为空");
		}
	}

	private void insertChannelData(ChannelTradeDataStatus param) {
		try {
			clrChannelDao.insertChannelData(param);
		} catch (Exception e) {
			throw new ServiceException(InfoCode.FAILURE_DB, e);
		}
	}

	private void updateChannelStatus(ChannelTradeDataStatus param) {
		try {
			clrChannelDao.updateChannelStatus(param);
		} catch (Exception e) {
			logger.error("" + e);
			throw new ServiceException(InfoCode.FAILURE_DB, e);
		}
	}

	@Override
	public List<ClrChnlInfo> findClrChnlList() throws ServiceException {
		List<ClrChnlInfo> chnlList = null;
		try {
			chnlList = clrChannelDao.findClrChnlList();
		} catch (Exception e) {
			throw new ServiceException(UpcConstants.FAILURE_DB, e);
		}

		return chnlList;
	}

}
