/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.core.util;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;

import org.apache.commons.collections4.MapUtils;
import org.springframework.data.redis.core.HashOperations;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import com.sfpay.core.dto.ChannelInfoDto;
import com.sfpay.core.dto.ChannelPayDto;
import com.sfpay.core.dto.MerchantInfoDto;
import com.sfpay.core.service.IChannelArgCoreService;
import com.sfpay.core.service.IChannelInfoService;
import com.sfpay.core.service.IChannelPayService;
import com.sfpay.core.service.IMerchantInfoService;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.cnst.FunctionCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.StatusCnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年3月9日
 */
@SuppressWarnings({ "rawtypes", "unchecked" })
@Component
public class LoadStaticDataUtil {
	public static final String REDIS_KEY_CHANNEL_ARG = "SYS_UPC_CORE_WE_REDIS_KEY_FOR_CHANNEL_ARG_MAP";
	public static final String REDIS_KEY_MERCHANT_INFO = "SYS_UPC_CORE_WE_REDIS_KEY_FOR_MERCHANT_INFO_MAP";
	public static final String REDIS_KEY_CHANNEL_INFO = "SYS_UPC_CORE_WE_REDIS_KEY_FOR_CHANNEL_INFO_MAP";
	public static final String REDIS_KEY_CHANNEL_PAY = "SYS_UPC_CORE_WE_REDIS_KEY_FOR_CHANNEL_PAY_MAP";

	@Resource
	private RedisTemplate redisTemplate;
	@Resource
	private IChannelArgCoreService channelArgCoreService;
	@Resource
	private IChannelInfoService channelInfoService;
	@Resource
	private IMerchantInfoService merchantInfoService;
	@Resource
	private IChannelPayService channelPayService;

	public <T> HashOperations<String, String, T> setCacheMap(String key, Map<String, T> dataMap) {
		HashOperations<String, String, T> hashOperations = redisTemplate.opsForHash();

		redisTemplate.delete(key);
		for (Map.Entry<String, T> entry : dataMap.entrySet()) {
			hashOperations.put(key, entry.getKey(), entry.getValue());
		}

		return hashOperations;
	}

	public <T> Map<String, T> getCacheMap(String key) {
		return redisTemplate.opsForHash().entries(key);
	}

	/**
	 * 支付交易获取扩展参数
	 * @param channelCode
	 * @param mchNo
	 * @param payCode
	 * @return
	 */
	public Map<String, String> initTradeExtMap(String channelCode, String mchNo, String payCode) {
		MerchantInfoDto merchantInfo = getMerchantInfo(channelCode, mchNo, payCode , true);
		Map<String, String> extMap = getChannelArg(channelCode);

		extMap.put(MapCnst.CHANNEL_CODE, merchantInfo.getChannelCode());
		extMap.put(MapCnst.CHANNEL_MCH_NO, merchantInfo.getChannelMchNo());
		extMap.put(MapCnst.ENCRYPT_ID, merchantInfo.getEncryptId());
		extMap.put(MapCnst.PUBLIC_KEY, merchantInfo.getPublicKey());

		ChannelInfoDto channelInfo = getChannelInfo(channelCode , true);
		extMap.put(MapCnst.FUNCTION_NAME, channelInfo.getFunctionName());
		return extMap;
	}
	
	/**
	 * 退款获取扩展参数
	 * @param channelCode
	 * @param mchNo
	 * @param payCode
	 * @return
	 */
	public Map<String, String> initRefundExtMap(String channelCode, String mchNo, String payCode) {
		MerchantInfoDto merchantInfo = getMerchantInfo(channelCode, mchNo, payCode , false);
		Map<String, String> extMap = getChannelArg(channelCode);

		extMap.put(MapCnst.CHANNEL_CODE, merchantInfo.getChannelCode());
		extMap.put(MapCnst.CHANNEL_MCH_NO, merchantInfo.getChannelMchNo());
		extMap.put(MapCnst.ENCRYPT_ID, merchantInfo.getEncryptId());
		extMap.put(MapCnst.PUBLIC_KEY, merchantInfo.getPublicKey());

		ChannelInfoDto channelInfo = getChannelInfo(channelCode,false);
		extMap.put(MapCnst.FUNCTION_NAME, channelInfo.getFunctionName());
		return extMap;
	}
	
	/**
	 * 查询获取扩展参数
	 * @param channelCode
	 * @param mchNo
	 * @param payCode
	 * @return
	 */
	public Map<String, String> initQueryExtMap(String channelCode, String mchNo, String payCode) {
		MerchantInfoDto merchantInfo = getMerchantInfo(channelCode, mchNo, payCode , false);
		Map<String, String> extMap = getChannelArg(channelCode);

		extMap.put(MapCnst.CHANNEL_CODE, merchantInfo.getChannelCode());
		extMap.put(MapCnst.CHANNEL_MCH_NO, merchantInfo.getChannelMchNo());
		extMap.put(MapCnst.ENCRYPT_ID, merchantInfo.getEncryptId());
		extMap.put(MapCnst.PUBLIC_KEY, merchantInfo.getPublicKey());

		ChannelInfoDto channelInfo = getChannelInfo(channelCode,false);
		extMap.put(MapCnst.FUNCTION_NAME, channelInfo.getFunctionName());
		return extMap;
	}
	
	/**
	 * 支付通知获取扩展参数
	 * @param channelCode
	 * @param mchNo
	 * @param payCode
	 * @return
	 */
	public Map<String, String> initNotifyExtMap(String channelCode, String mchNo, String payCode) {
		MerchantInfoDto merchantInfo = getMerchantInfo(channelCode, mchNo, payCode , false);
		Map<String, String> extMap = getChannelArg(channelCode);

		extMap.put(MapCnst.CHANNEL_CODE, merchantInfo.getChannelCode());
		extMap.put(MapCnst.CHANNEL_MCH_NO, merchantInfo.getChannelMchNo());
		extMap.put(MapCnst.ENCRYPT_ID, merchantInfo.getEncryptId());
		extMap.put(MapCnst.PUBLIC_KEY, merchantInfo.getPublicKey());

		ChannelInfoDto channelInfo = getChannelInfo(channelCode,false);
		extMap.put(MapCnst.FUNCTION_NAME, channelInfo.getFunctionName());
		return extMap;
	}

	/**
	 * 商户进件、更新、查询获取扩展参数
	 * @param channelCode
	 * @param mchNo
	 * @param payCode
	 * @param function
	 * @return
	 */
	public Map<String, String> initMchExtMap(String channelCode, String mchNo, String payCode, String function) {
		MerchantInfoDto merchantInfo = getMerchantInfo(channelCode, mchNo, payCode,false);
		Map<String, String> extMap = getChannelArg(channelCode);
		if (FunctionCnst.ADD_MERCHANT_FUNCTION.equals(function)) {
			if (null != merchantInfo) {
				throw new ServiceException(RtnCodeCnst.MCH_NO_IS_EXISTS, "该商户号已存在,状态为" + merchantInfo.getStatus());
			}
		}

		if(merchantInfo != null && merchantInfo.getChannelMchNo() != null){
			extMap.put(MapCnst.CHANNEL_MCH_NO, merchantInfo.getChannelMchNo());
		}

		ChannelInfoDto channelInfo = getChannelInfo(channelCode,true);
		extMap.put(MapCnst.FUNCTION_NAME, channelInfo.getFunctionName());
		extMap.put(MapCnst.PAY_CODE, payCode);

		return extMap;
	}

	public Map<String, String> initProvAcctMap(String channelCode, String payCode) {
		ChannelPayDto channelPayDto = getChannelPayInfo(channelCode, payCode , false);
		Map<String, String> provAcctMap = new HashMap<String, String>();
		provAcctMap.put(MapCnst.PROV_ACCT_NAME, channelPayDto.getProvAcctName());
		provAcctMap.put(MapCnst.PROV_ACCT_NO, channelPayDto.getProvAcctNo());
		provAcctMap.put(MapCnst.PROV_BANK_CODE, channelPayDto.getProvBankCode());
		provAcctMap.put(MapCnst.PROV_BANK_NAME, channelPayDto.getProvBankName());
		return provAcctMap;
	}

	public ChannelPayDto getChannelPayInfo(String channelCode, String payCode , boolean isClose) {
		Map<String, ChannelPayDto> channelPayMap = this.getCacheMap(REDIS_KEY_CHANNEL_PAY);
		String channelPayCode = channelCode + CharCnst.UNDER_LINE_FOR + payCode;
		ChannelPayDto channelPayDto = channelPayMap.get(channelPayCode);
		if (null == channelPayDto) {
			channelPayDto = channelPayService.queryChannelPay(channelPayCode);
			if (null == channelPayDto) {
				throw new ServiceException(RtnCodeCnst.PROV_ACCT_NOT_INIT, "不支持此通道,信息不全");
			}
		}
		if(isClose && CharCnst.NO_FLAG.equals(channelPayDto.getStatus())){
			throw new ServiceException(RtnCodeCnst.PROV_ACCT_NOT_INIT, "通道["+channelCode+"]对应的渠道[" +payCode+ "]处于关闭状态");
		}
		return channelPayDto;
	}

	/**
	 * 下载对账单、刷新Token获取扩展参数
	 * @param channelCode
	 * @return
	 */
	public Map<String, String> initCommonExtMap(String channelCode) {
		Map<String, String> extMap = getChannelArg(channelCode);

		ChannelInfoDto channelInfo = getChannelInfo(channelCode,false);
		extMap.put(MapCnst.FUNCTION_NAME, channelInfo.getFunctionName());

		return extMap;
	}

	public ChannelInfoDto getChannelInfo(String channelCode , boolean isClose) {
		Map<String, ChannelInfoDto> channelInfoMap = this.getCacheMap(REDIS_KEY_CHANNEL_INFO);
		ChannelInfoDto channelInfo = channelInfoMap.get(channelCode);
		if (null == channelInfo) {
			channelInfo = channelInfoService.queryChannelInfo(channelCode);
			if (null == channelInfo) {
				throw new ServiceException(RtnCodeCnst.CHANNEL_INFO_IS_NULL, "银行参数为空");
			}
		}
		if(isClose && CharCnst.NO_FLAG.equals(channelInfo.getStatus())){
			throw new ServiceException(RtnCodeCnst.CHANNEL_INFO_IS_NULL, "通道[" +channelCode+ "]处于关闭状态");
		}
		return channelInfo;
	}

	private Map<String, String> getChannelArg(String channelCode) {
		Map<String, Map<String, String>> channelArgMap = this.getCacheMap(REDIS_KEY_CHANNEL_ARG);
		Map<String, String> extMap = channelArgMap.get(channelCode);
		if (MapUtils.isEmpty(extMap)) {
			extMap = channelArgCoreService.queryChannelArgMap(channelCode);
			if (MapUtils.isEmpty(extMap)) {
				throw new ServiceException(RtnCodeCnst.CHANNEL_ARG_IS_NULL, "银行参数为空");
			}
		}
		return extMap;
	}

	private MerchantInfoDto getMerchantInfo(String channelCode, String mchNo, String payCode , boolean isClose) {
		Map<String, MerchantInfoDto> merchantInfoMap = this.getCacheMap(REDIS_KEY_MERCHANT_INFO);
		MerchantInfoDto merchantInfo = merchantInfoMap
				.get(channelCode + CharCnst.UNDER_LINE_FOR + payCode + CharCnst.UNDER_LINE_FOR + mchNo);
		if (null == merchantInfo) {
			merchantInfo = merchantInfoService.queryMerchantInfo(mchNo, channelCode, payCode);
			if (null == merchantInfo) {
				throw new ServiceException(RtnCodeCnst.INVALID_MCH_NO, "该商户号[" +mchNo+ "]尚未开通渠道商户");
			}
		}
		if (isClose && !StatusCnst.ENABLE.equals(merchantInfo.getStatus())) {
			throw new ServiceException(RtnCodeCnst.INVALID_MCH_NO, "该商户号[" +mchNo+ "]对应的通道渠道处于关闭状态");
		}
		return merchantInfo;
	}

}
