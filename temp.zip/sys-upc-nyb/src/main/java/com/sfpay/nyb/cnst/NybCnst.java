/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.nyb.cnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月27日
 */
public final class NybCnst {
	/////////////////////// 支付渠道类型/////////////////////////////////
	// 微信公众账号支付
	public static final String PAY_CHANNEL_WXPUB = "wxPub";
	// 微信付款码支付
	public static final String PAY_CHANNEL_WXMICRO = "wxMicro";
	// 支付宝扫码支付
	public static final String PAY_CHANNEL_ALIPAYQR = "alipayQR";
	// 支付宝APP支付
	public static final String PAY_CHANNEL_ALIPAYAPP = "alipayApp";
	// 支付宝付款码支付
	public static final String PAY_CHANNEL_ALIPAYMICRO = "alipayMicro";

	/////////////////////// 通道类型///////////////////////////////////////////
	public static final String CHANNEL_TYPE_WEIXIN = "weixin";
	public static final String CHANNEL_TYPE_ALIPAY = "alipay";

	//////////////////// 交易常量////////////////////////////////////////////
	// 默认版本号1.3
	public static final String VERSION_1_3 = "1.3";
	// 默认币种CNY
	public static final String CURRENCY_CNY = "CNY";
	public static final String NO_CREDIT = "no_credit";
	public static final String SIGN = "sign";

	public static final String SUB_MCH_ID = "subMchId";

	public static final String PAY_CODE = "payCode";
	public static final String CODE_URL = "codeUrl";
	public static final String OUT_CHANNEL_NO = "outChannelNo";
	public static final String CHANNEL_ORDER_NO = "channelOrderNo";
	public static final String RETURN_CODE = "returnCode";
	public static final String RETURN_MSG = "returnMsg";
	public static final String RESULT_CODE = "resultCode";
	public static final String ERR_CODE = "errCode";
	public static final String ERR_CODE_DES = "errCodeDes";
	public static final String CHANNEL_REFUND_NO = "channelRefundNo";

	//////////////////// 交易状态返回/////////////////////////////
	public static final String PAY_STATUS = "status";
	public static final String REFUND_STATUS = "refundStatus";

	///////////////////// 交易成功或者失败/////////////////////////////
	public static final String SUCCESS = "0";
	
	///////////////////// 查询类型/////////////////////////////
	public static final String QUERY_TYPE_1 = "1";//支付订单
	public static final String QUERY_TYPE_3 = "3";//退款订单
	

}
