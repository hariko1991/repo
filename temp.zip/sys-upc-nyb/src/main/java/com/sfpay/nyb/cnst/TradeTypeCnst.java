/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.nyb.cnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年7月26日
 */
public final class TradeTypeCnst {
	
	public static final String CS_MERCHANT_REGISTER = "cs.merchant.register";
	public static final String CS_MERCHANT_MODIFY = "cs.merchant.modify";
	public static final String CS_PAY_SUBMIT = "cs.pay.submit";
	public static final String CS_REFUND_APPLY = "cs.refund.apply";
	public static final String CS_TRADE_SINGLE_QUERY = "cs.trade.single.query";
	public static final String CS_BILL_DOWNLOAD = "cs.bill.download";
	public static final String CS_CHANNEL_BILL_DOWNLOAD = "cs.channel.bill.download";

}
