/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.nyb.function;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.ChannelCnst;
import com.sfpay.front.cnst.LimitPayCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.PayCodeCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.service.IHttpInvokeService;
import com.sfpay.front.util.CurrencyUtil;
import com.sfpay.nyb.cnst.BarcodePayCnst;
import com.sfpay.nyb.cnst.NybCnst;
import com.sfpay.nyb.cnst.PublicPayCnst;
import com.sfpay.nyb.cnst.TradeTypeCnst;
import com.sfpay.nyb.dto.req.trade.BarcodePayReq;
import com.sfpay.nyb.util.ReqArgValidationUtil;
import com.sfpay.nyb.util.SignUtil;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月2日
 */
public class BarcodePayFunction {
	private static final Logger LOGGER = LoggerFactory.getLogger(BarcodePayFunction.class);
	private static final String[] BARCODE_PAY_KEY_ARRAY = new String[] { BarcodePayCnst.AUTHCODE,
			BarcodePayCnst.SUBJECT };
	private static final String RESULT_NOTIFY = "result/pay";
	private static final List<String> BARCODE_PAY_KEY_LIST = Arrays.asList(BARCODE_PAY_KEY_ARRAY);

	public static Map<String, String> getResp(IHttpInvokeService httpInvokeService, Map<String, String> reqMap,
			Map<String, String> extMap, String logMsg) {
		if (ReqArgValidationUtil.validationArg(reqMap, BARCODE_PAY_KEY_LIST)) {
			LOGGER.info("{}校验通过,参数没有问题", logMsg);
		}

		Map<String, String> respMap = new HashMap<String, String>();
		String reqMsg = "";
		try {
			reqMsg = buildReqMsg(reqMap, extMap);
			LOGGER.info("{}组装请求参数json格式[{}]", logMsg, reqMsg);
		} catch (Exception e) {
			LOGGER.error("{}组装请求参数json加密串为异常", logMsg, e);
			throw new ServiceException(RtnCodeCnst.SIGN_FAIL, "签名异常");
		}

		String respMsg = "";
		try {
			respMsg = httpInvokeService.sendAndReceiveForTrade(ChannelCnst.CHANNEL_NYB, reqMsg, extMap);
			LOGGER.info("{}请求返回报文[{}]", logMsg, respMsg);
		} catch (Exception e) {
			LOGGER.error("{}和银行通信异常", logMsg, e);
			throw new ServiceException(RtnCodeCnst.NETWORK_EXCHANGE_EXCEPTION, "网络通迅异常");
		}

		JSONObject jsonObj = JSONObject.parseObject(respMsg);
		if (NybCnst.SUCCESS.equals(jsonObj.getString(NybCnst.RETURN_CODE))) {
			respMap.put(SqlCnst.RTN_CODE, jsonObj.getString(NybCnst.RETURN_CODE));
			respMap.put(SqlCnst.RTN_MSG, jsonObj.getString(NybCnst.RETURN_MSG));
			if (NybCnst.SUCCESS.equals(jsonObj.getString(NybCnst.RESULT_CODE))) {
				respMap.put(SqlCnst.TARGET_STATUS, StatusCnst.TRADING);
				respMap.put(SqlCnst.RTN_ORDER_NO, jsonObj.getString(NybCnst.OUT_CHANNEL_NO));
				respMap.put(SqlCnst.CHANNEL_NO, jsonObj.getString(NybCnst.CHANNEL_ORDER_NO));
			} else {
				respMap.put(SqlCnst.TARGET_STATUS, StatusCnst.FAILURE);
				respMap.put(SqlCnst.RTN_CODE, jsonObj.getString(NybCnst.ERR_CODE));
				respMap.put(SqlCnst.RTN_MSG, jsonObj.getString(NybCnst.ERR_CODE_DES));
			}
		} else {
			respMap.put(SqlCnst.TARGET_STATUS, StatusCnst.FAILURE);
			respMap.put(SqlCnst.RTN_CODE, jsonObj.getString(NybCnst.RETURN_CODE));
			respMap.put(SqlCnst.RTN_MSG, jsonObj.getString(NybCnst.RETURN_MSG));
		}

		respMap.put(SqlCnst.STATUS, respMap.get(SqlCnst.TARGET_STATUS));
		return respMap;
	}

	private static String buildReqMsg(Map<String, String> reqMap, Map<String, String> extMap) throws Exception {
		BarcodePayReq payReq = new BarcodePayReq();
		payReq.setTradeType(TradeTypeCnst.CS_PAY_SUBMIT);
		payReq.setVersion(NybCnst.VERSION_1_3);
		payReq.setMchId(extMap.get(MapCnst.APP_ID));

		if (PayCodeCnst.PAY_CODE_ALIPAY.equals(reqMap.get(MapCnst.PAY_CODE))) {
			payReq.setChannel(NybCnst.PAY_CHANNEL_ALIPAYMICRO);
		} else if (PayCodeCnst.PAY_CODE_WX.equals(reqMap.get(MapCnst.PAY_CODE))) {
			payReq.setChannel(NybCnst.PAY_CHANNEL_WXMICRO);
			String limitPay = reqMap.get(PublicPayCnst.LIMITPAY);
			if(StringUtils.isNotBlank(limitPay) && LimitPayCnst.DEPOSIT_CARD.contains(limitPay)){
				payReq.setLimitPay(NybCnst.NO_CREDIT);
			}else{
				payReq.setLimitPay("");
			}
			payReq.setReceipt(reqMap.get(MapCnst.RECEIPT));
		}

		payReq.setSubMchId(extMap.get(MapCnst.CHANNEL_MCH_NO));

		payReq.setBody(reqMap.get(BarcodePayCnst.SUBJECT));
		payReq.setOutTradeNo(reqMap.get(MapCnst.REQ_ORDER_NO));
		payReq.setAmount(new BigDecimal(CurrencyUtil.fen2Yuan(Long.valueOf(reqMap.get(MapCnst.SRC_AMT)))));

		payReq.setDescription(reqMap.get(PublicPayCnst.DESC));
		payReq.setCurrency(NybCnst.CURRENCY_CNY);
		payReq.setSubject(reqMap.get(BarcodePayCnst.SUBJECT));

		payReq.setAuthCode(reqMap.get(BarcodePayCnst.AUTHCODE));
		payReq.setNotifyUrl(extMap.get(MapCnst.NOTIFY_URL) + RESULT_NOTIFY);

		payReq.setSign(SignUtil.sign(extMap.get(MapCnst.SECRET_KEY), payReq.toMap()));
		return JSON.toJSONString(payReq);
	}
}
