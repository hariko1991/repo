package com.sfpay.nyb.dto.req.trade;

import com.sfpay.nyb.dto.req.Req;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年7月27日
 */
public class RefundQueryReq extends Req {
	private static final long serialVersionUID = -15011920926064008L;
	private static final String QUERY_TYPE_REFUND = "3";

	// 交易类型 tradeType 是 String(32) cs.bill.download
	private String tradeType;
	// 版本 version 是 String(8) 版本号 1.3
	private String version;
	// 代理商号 mchId 是 String(32) 由平台分配 000100003
	private String mchId;
	// 商户号 subMchId 是 String(32) 由平台分配的商户号 000100001000004
	private String subMchId;
	// 商户订单号 outTradeNo 是 String(32) 支付订单或退款的商户订单号
	private String outTradeNo;
	// 查询类型 queryType 是 String(1) 1：支付订单 3：退款 3
	private String queryType = QUERY_TYPE_REFUND;
	// 签名 sign 是 String(32) 签名，详见本文档签名签名说明 18e4682fbe3d4c92837c7315ba749d60
	private String sign;

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getMchId() {
		return mchId;
	}

	public void setMchId(String mchId) {
		this.mchId = mchId;
	}

	public String getSubMchId() {
		return subMchId;
	}

	public void setSubMchId(String subMchId) {
		this.subMchId = subMchId;
	}

	public String getOutTradeNo() {
		return outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	public String getQueryType() {
		return queryType;
	}

	public void setQueryType(String queryType) {
		this.queryType = queryType;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}
}
