/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.nyb.function;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.cnst.TradeTypeCnst;
import com.sfpay.nyb.cnst.NybCnst;
import com.sfpay.nyb.util.SignUtil;
import com.sfpay.nyb.util.StatusUtil;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月2日
 */
public class ValidateSignFunction {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ValidateSignFunction.class);
	
	public static Map<String, String> validateSign(Map<String, String> reqMap,
			Map<String, String> extMap, String logMsg) {
		LOGGER.info("{}组装请求参数json格式[{}]", logMsg, reqMap);
		
		Map<String, String> respMap = new HashMap<String, String>();
		try {
			if(!NybCnst.SUCCESS.equals(reqMap.get(NybCnst.RETURN_CODE))){
				throw new ServiceException(RtnCodeCnst.FAILURE_SYS, "南粤银行通知返回状态码为失败");
			}else{
				if(!NybCnst.SUCCESS.equals(reqMap.get(NybCnst.RESULT_CODE))){
					throw new ServiceException(RtnCodeCnst.FAILURE_SYS, "南粤银行通知返回业务结果状态为失败");
				}else{
					String key = extMap.get(MapCnst.SECRET_KEY);
					String tradeType = reqMap.get(MapCnst.TRADE_TYPE);
					//验签前，将不需要的提出掉
					reqMap.remove(MapCnst.REQ_ORDER_NO);
					reqMap.remove(MapCnst.TRADE_TYPE);
					if(SignUtil.validSign(reqMap, key)){
						if(TradeTypeCnst.TRADE_TYPE_PAY.equals(tradeType)){
							return dualPay(logMsg,reqMap,respMap);
						}else{
							return dualPayRefund(logMsg,reqMap,respMap);
						}
					}else{
						throw new ServiceException(RtnCodeCnst.SIGN_NOT_PASS, "验证签名不通过");
					}
				}
			}
		} catch (Exception e) {
			LOGGER.error("{}组装请求参数json加密串为异常", logMsg, e);
		}
		return null;
	}
	
	private static Map<String, String> dualPay(String logMsg , Map<String, String> reqMap , 
			Map<String, String> respMap) {
		String status = StatusUtil.getPayStatus(reqMap.get(NybCnst.PAY_STATUS));
		if(StatusCnst.TRADING.equals(status)){
			return respMap;
		}
		respMap.put(SqlCnst.TARGET_STATUS, status);
		respMap.put(SqlCnst.CHANNEL_NO, reqMap.get(NybCnst.CHANNEL_ORDER_NO));
		respMap.put(SqlCnst.RTN_ORDER_NO, reqMap.get(NybCnst.OUT_CHANNEL_NO));
		respMap.put(SqlCnst.EXT_TAB_BUYERID, "");
		respMap.put(SqlCnst.EXT_TAB_OPENID, "");
		respMap.put(SqlCnst.EXT_TAB_BUYERACCOUNT, "");
		respMap.put(SqlCnst.RTN_CODE, reqMap.get(NybCnst.RESULT_CODE));
		respMap.put(SqlCnst.RTN_MSG, StatusCnst.SUCCESS.equals(status) ? "支付成功" :
			reqMap.get(NybCnst.ERR_CODE_DES));
		return respMap;
	}
	private static Map<String, String> dualPayRefund(String logMsg , Map<String, String> reqMap , 
			Map<String, String> respMap) {
		String refundStatus = StatusUtil.getRefundStatus(reqMap.get(NybCnst.REFUND_STATUS));
		if(StatusCnst.REFUND_PROC.equals(refundStatus)){
			return respMap;
		}
		respMap.put(SqlCnst.TARGET_STATUS, refundStatus);
		respMap.put(SqlCnst.CHANNEL_NO, reqMap.get(NybCnst.CHANNEL_ORDER_NO));
		respMap.put(SqlCnst.RTN_ORDER_NO, reqMap.get(NybCnst.OUT_CHANNEL_NO));
		respMap.put(SqlCnst.RTN_CODE, reqMap.get(NybCnst.RESULT_CODE));
		respMap.put(SqlCnst.RTN_MSG, StatusCnst.REFUND_SUCC.equals(refundStatus) ? "退款成功" :
			reqMap.get(NybCnst.ERR_CODE_DES));
		return respMap;
	}
}
