/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.nyb.util;

import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.RtnCodeCnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月27日
 */
public final class ReqArgValidationUtil {

	public static boolean validationArg(Map<String, String> reqMap, List<String> keyList) {
		for (String key : keyList) {
			if (StringUtils.isEmpty(reqMap.get(key))) {
				throw new ServiceException(RtnCodeCnst.ILLEGAL_REQ, key + "字段为空,校验不通过");
			}
		}
		return true;
	}
}
