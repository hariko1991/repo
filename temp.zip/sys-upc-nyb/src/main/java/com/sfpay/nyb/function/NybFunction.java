/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.nyb.function;

import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.FunctionCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.function.Function;
import com.sfpay.front.service.IHttpInvokeService;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月24日
 */
@Service("nybFunction")
public class NybFunction extends Function {
	private static final Logger LOGGER = LoggerFactory.getLogger(NybFunction.class);

	@Resource
	private IHttpInvokeService httpInvokeService;

	public Map<String, String> getResp(String uqNo, String function, Map<String, String> reqMap,
			Map<String, String> extMap) {
		String logMsg = String.format("南粤银行唯一编号[%s],功能[%s]", uqNo, function);
		LOGGER.info("{}开始处理,请求[{}],扩展参数[{}]", new Object[] { logMsg, reqMap, extMap });

		if (FunctionCnst.JSPRECREATE_FUNCTION.equals(function)) {
			return PublicPayFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else if (FunctionCnst.ADD_MERCHANT_FUNCTION.equals(function)) {
			return AddMerchantFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else if (FunctionCnst.GET_MERCHANT_DETAIL_FUNCTION.equals(function)) {
			return GetMerchantDetailFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else if (FunctionCnst.BARCODE_FUNCTION.equals(function)) {
			return BarcodePayFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else if (FunctionCnst.REFUND_FUNCTION.equals(function)) {
			return RefundFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else if (FunctionCnst.DOWNLOAD_BILL_FUNCTION.equals(function)) {
			return DownloadBillFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else if (FunctionCnst.REFUND_QUERY_FUNCTION.equals(function)) {
			return RefundQueryFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else if (FunctionCnst.QUERY_FUNCTION.equals(function)) {
			return QueryFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else if (FunctionCnst.UPDATE_MERCHANT_FUNCTION.equals(function)) {
			return UpdateMerchantFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else if (FunctionCnst.NOTIFY_VALIDATE_SIGN.equals(function)) {
			return ValidateSignFunction.validateSign(reqMap, extMap, logMsg);
		} else {
			throw new ServiceException(RtnCodeCnst.NOT_SUPPORT_FUNCTION, "不支持功能" + function);
		}
	}
}
