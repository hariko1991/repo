/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.nyb.util;

import java.io.File;
import java.io.FileInputStream;
import java.math.BigDecimal;
import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.sfpay.front.cnst.EncodingCnst;
import com.sfpay.nyb.cnst.NybCnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月23日
 */
public final class SignUtil {
	private static final String ALGORITHM_MD5 = "MD5";
	private static final String KEY = "&key=";
	private static final String EQUALS_SYMBOL = "=";
	private static final String AND_SYMBOL = "&";
	private final static char HEXDIGITS[] = { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E',
			'F' };

	private static Map<String, String> paraFilter(Map<String, String> sArray) {
		Map<String, String> result = new HashMap<String, String>();
		if (sArray == null || sArray.size() <= 0) {
			return result;
		}
		DecimalFormat formater = new DecimalFormat("###0.00");
		for (String key : sArray.keySet()) {
			String finalValue = null;
			Object value = sArray.get(key);
			if (value instanceof BigDecimal) {
				finalValue = formater.format(value);
			} else {
				finalValue = (String) value;
			}
			if (value == null || value.equals("") || key.equalsIgnoreCase("sign")) {
				continue;
			}
			result.put(key, finalValue);
		}
		return result;
	}

	private static String createLinkString(Map<String, String> params) {
		List<String> tempKeyList = new ArrayList<String>(params.keySet());
		List<String> keyList = new ArrayList<String>();
		for (String tempKey : tempKeyList) {
			if (null != params.get(tempKey) && StringUtils.isNotEmpty(params.get(tempKey))) {
				keyList.add(tempKey);
			}
		}

		Collections.sort(keyList, String.CASE_INSENSITIVE_ORDER);

		StringBuffer prestr = new StringBuffer();

		for (int i = 0; i < keyList.size(); i++) {
			String key = keyList.get(i);
			String value = params.get(key);

			if (i == keyList.size() - 1) {// 拼接时，不包括最后一个&字符
				prestr.append(key).append(EQUALS_SYMBOL).append(value);
			} else {
				prestr.append(key).append(EQUALS_SYMBOL).append(value).append(AND_SYMBOL);
			}
		}

		return prestr.toString();
	}

	public static String sign(String key, Map<String, String> params) throws Exception {
		return getMD5((createLinkString(params) + KEY + key).getBytes(EncodingCnst.UTF_8));
	}

	public static boolean validSign(Map<String, String> map, String key) throws Exception {
		String oldSign = map.get(NybCnst.SIGN);
		String sign = sign(key, paraFilter(map));
		return sign.equalsIgnoreCase(oldSign);
	}

	public static String getMD5(File file) throws Exception {
		FileInputStream fis = null;
		try {
			MessageDigest md = MessageDigest.getInstance(ALGORITHM_MD5);
			fis = new FileInputStream(file);
			byte[] buffer = new byte[2048];
			int length = -1;
			while ((length = fis.read(buffer)) != -1) {
				md.update(buffer, 0, length);
			}
			byte[] b = md.digest();
			return byteToHexString(b);
		} finally {
			if (null != fis) {
				fis.close();
			}
		}
	}

	public static String getMD5(byte[] data) throws Exception {
		MessageDigest md = MessageDigest.getInstance(ALGORITHM_MD5);

		byte[] b = md.digest(data);
		return byteToHexString(b);
	}

	private static String byteToHexString(byte[] tmp) {
		// 用字节表示就是 16 个字节
		char str[] = new char[16 * 2]; // 每个字节用 16 进制表示的话，使用两个字符，
		// 所以表示成 16 进制需要 32 个字符
		int k = 0; // 表示转换结果中对应的字符位置
		for (int i = 0; i < 16; i++) { // 从第一个字节开始，对 MD5 的每一个字节
			// 转换成 16 进制字符的转换
			byte byte0 = tmp[i]; // 取第 i 个字节
			str[k++] = HEXDIGITS[byte0 >>> 4 & 0xf]; // 取字节中高 4 位的数字转换,
			// >>> 为逻辑右移，将符号位一起右移
			str[k++] = HEXDIGITS[byte0 & 0xf]; // 取字节中低 4 位的数字转换
		}
		return new String(str);
	}

	public static void main(String[] args) throws Exception {
		Map<String, String> map = new HashMap<String, String>();
		map.put("mchId", "000100008");
		map.put("merchantName", "顺丰速运有限公司");
		map.put("merchantShortName", "顺丰速运");
		System.out.println(sign("4009296b94dd48c19b1f320396a7794c", map));
	}

}
