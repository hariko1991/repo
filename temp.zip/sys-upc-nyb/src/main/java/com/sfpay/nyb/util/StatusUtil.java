/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.nyb.util;

import java.util.Arrays;
import java.util.List;

import org.apache.commons.lang3.StringUtils;

import com.sfpay.front.cnst.StatusCnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年7月27日
 */
public final class StatusUtil {

	public static final String BANK_STATUS_01 = "01";
	public static final String BANK_STATUS_02 = "02";
	public static final String BANK_STATUS_03 = "03";
	public static final String BANK_STATUS_04 = "04";
	public static final String BANK_STATUS_05 = "05";
	public static final String BANK_STATUS_06 = "06";
	public static final String BANK_STATUS_07 = "07";
	public static final String BANK_STATUS_08 = "08";
	public static final String BANK_STATUS_09 = "09";
	public static final String BANK_STATUS_10 = "10";

	public static final List<String> PAY_SUCCESS_LIST = Arrays.asList(new String[] {BANK_STATUS_02,BANK_STATUS_05});
	public static final List<String> PAY_FAILURE_LIST = Arrays.asList(new String[] {BANK_STATUS_03,BANK_STATUS_04,BANK_STATUS_06,BANK_STATUS_07,BANK_STATUS_08,BANK_STATUS_09,BANK_STATUS_10});
	public static final List<String> PAY_TRADING_LIST = Arrays.asList(new String[] {BANK_STATUS_01});

	/**
	 * 方法说明：<br>
	 * 01：未支付 
	 * 02：已支付
	 * 03：已冲正
	 * 04：已关闭
	 * 05：转入退款
	 * 09：支付失败
	 * 10：订单超时
	 * @param bankStatus
	 * @return String
	 */
	public static String getPayStatus(String bankStatus) {
		if (StringUtils.isEmpty(bankStatus)) {
			return StatusCnst.TRADING;
		} else if (PAY_SUCCESS_LIST.contains(bankStatus)) {
			return StatusCnst.SUCCESS;
		} else if (PAY_FAILURE_LIST.contains(bankStatus)) {
			return StatusCnst.FAILURE;
		}
		return StatusCnst.TRADING;
	}

	/**
	 * 方法说明：<br>
	 * 退款状态；退款查询类型时有返回
	 * 01：退款申请
	 * 02：退款成功
	 * 03：退款失败
	 * @param bankStatus
	 * @return String
	 */
	public static String getRefundStatus(String bankStatus) {
		if (BANK_STATUS_01.equals(bankStatus)) {
			return StatusCnst.REFUND_PROC;
		} else if (BANK_STATUS_02.equals(bankStatus)) {
			return StatusCnst.REFUND_SUCC;
		} else if (BANK_STATUS_03.equals(bankStatus)) {
			return StatusCnst.REFUND_FAIL;
		}
		return StatusCnst.REFUND_PROC;
	}

}
