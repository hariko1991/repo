/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.nyb.dto.req.trade;

import com.sfpay.nyb.dto.req.Req;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年7月27日
 */
public class DownloadBillReq extends Req {

	private static final long serialVersionUID = 1143183225759170731L;
	// 交易类型 tradeType 是 String(32) cs.bill.download
	private String tradeType;
	// 版本 version 是 String(8) 版本号 1.3
	private String version;
	//由平台分配 代理商户号号
	private String channelNo;
	// 代理商号 mchId 是 String(32) 由平台分配 000100003
	private String mchId;
	// 商户号 subMchId 是 String(32) 由平台分配的商户号 000100001000004
	private String subMchId;
	// 对账日期 billDate 是 String(8) yyyyMMdd 20161210
	private String billDate;
	// 签名 sign 是 String(32) 签名，详见本文档签名签名说明 18e4682fbe3d4c92837c7315ba749d60
	private String sign;

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getChannelNo() {
		return channelNo;
	}

	public void setChannelNo(String channelNo) {
		this.channelNo = channelNo;
	}

	public String getMchId() {
		return mchId;
	}

	public void setMchId(String mchId) {
		this.mchId = mchId;
	}

	public String getSubMchId() {
		return subMchId;
	}

	public void setSubMchId(String subMchId) {
		this.subMchId = subMchId;
	}

	public String getBillDate() {
		return billDate;
	}

	public void setBillDate(String billDate) {
		this.billDate = billDate;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

}
