/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.nyb.dto.req.merchant;

import com.sfpay.nyb.dto.req.Req;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月26日
 */
public class AddMerchantReq extends Req {

	private static final long serialVersionUID = -2098187219207687057L;
	/**
	 * 交易类型	tradeType	是	String(32)	cs.merchant.register	
	 */
	private String tradeType;
	/**
	 * 版本	version	是	String(8)	版本号	1.3
	 */
	private String version;
	/**
	 * 代理商编号	mchId	是	String(32)	由平台分配的代理商编号	000100003
	 */
	private String mchId;
	/**
	 * 商户名称	merchantName	是	String(128)	要求与营业执照上的名称一致	
	 */
	private String merchantName;
	/**
	 * 商户简称	merchantShortName	是	String(20)	商户简称	
	 */
	private String merchantShortName;
	/**
	 * 负责人	opName	是	String(20)	负责人	
	 */
	private String opName;
	/**
	 * 负责人电话	opPhone	是	String(20)	负责人电话，手机或座机	13900008888
	 */
	private String opPhone;
	/**
	 * 客服电话	customerTelephone	是	String(20)	客服电话,手机或座机	
	 */
	private String customerTelephone;
	/**
	 * 省份	proName	是	String(20)	省份	北京
	 */
	private String proName;
	/**
	 * 城市	cityName	是	String(20)	城市	北京
	 */
	private String cityName;
	/**
	 * 地址	address	是	String(240)	地址	
	 */
	private String address;
	/**
	 * 区县	areaName	是	String(20)	区县	朝阳区
	 */
	private String areaName;
	/**
	 * 电话	telephone	是	String(32)	电话,手机或座机	
	 */
	private String telephone;
	/**
	 * 邮箱	email	是	String(50)	邮箱	
	 */
	private String email;
	/**
	 * 经营类目	categoryWx	是	String(32)	微信经营类目
	 */
	private String categoryWx;
	/**
	 * 经营类目	categoryZfb	是	String(32)	支付宝经营类目
	 */
	private String categoryZfb;
	/**
	 * 经营类目	categoryYl	是	String(32)	银联经营类目
	 */
	private String categoryYl;
	/**
	 * 银行类型	bankType	是	String(20)	银行类型 见附件7.7
	 */
	private String bankType;
	/**
	 * 银行名称	bankName	是	String(100)	银行名称
	 */
	private String bankName;
	/**
	 * 银行卡号	bankCardNo	是	String(20)	银行卡号
	 */
	private String bankCardNo;
	/**
	 * 户名	bankAccName	是	String(100)	户名
	 */
	private String bankAccName;
	/**
	 * 帐户类型	accountType	是	Integer(1)	帐户类型;1：个人；2：企业
	 */
	private String accountType;
	/**
	 * 营业执照类型	businessLicenseType	否	String(20)	营业执照类型：NATIONAL_LEGAL：营业执照；NATIONAL_LEGAL_MERGE:多证合一；INST_RGST_CTF：事业单位法人证书
	 */
	private String businessLicenseType;
	/**
	 * 营业执照编号	businessLicense	否	String(20)	营业执照编号
	 */
	private String businessLicense;
	/**
	 * 受理商户负责人信息	legalPersonType	是	String(20)	负责人信息：LEGAL_PERSON：法人；CONTROLLER：实际控制人；AGENT：代理人；OTHER：其他
	 */
	private String legalPersonType;
	/**
	 * 证件类型	certificateType	否	Integer(1)	证件类型；1-身份证；2-营业执照
	 */
	private Integer certificateType;
	/**
	 * 证件号码	certificateNo	否	String(50)	证件号码
	 */
	private String certificateNo;
	/**
	 * 支付类型列表	payTypes	是	String(1000)	说明：payTypeCode必填项：请从附件：支付渠道中取值；rateType必填项：1表示交易额比例(%)，2表示固定费率；rate必填项，费率值； rmk非必填项	"payTypes":"[{\"payTypeCode\":\"wxPub\",\"rateType\":1,\"rate\":0.3,\"rmk\":\"微信公众账号支付\"},{\"payTypeCode\":\"wxPubQR\",\"rateType\":2,\"rate\":0.35,\"rmk\":\"公众账号扫码支付\"}]"
	 */
	private String payTypes;
	/**
	 * 商户经营类型	merchantOperationType	是	String(1)	实体：1    虚拟：2	1
	 */
	private String merchantOperationType;
	/**
	 * 备注说明	rmk	否	String(128)	介绍商户营业内容等	
	 */
	private String rmk;
	/**
	 * 签名	sign	是	String(32)	签名，详见本文档签名签名说明	3B61007C11C5BABEC3F5020F2775D619
	 */
	private String sign;

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getMchId() {
		return mchId;
	}

	public void setMchId(String mchId) {
		this.mchId = mchId;
	}

	public String getMerchantName() {
		return merchantName;
	}

	public void setMerchantName(String merchantName) {
		this.merchantName = merchantName;
	}

	public String getMerchantShortName() {
		return merchantShortName;
	}

	public void setMerchantShortName(String merchantShortName) {
		this.merchantShortName = merchantShortName;
	}

	public String getOpName() {
		return opName;
	}

	public void setOpName(String opName) {
		this.opName = opName;
	}

	public String getOpPhone() {
		return opPhone;
	}

	public void setOpPhone(String opPhone) {
		this.opPhone = opPhone;
	}

	public String getCustomerTelephone() {
		return customerTelephone;
	}

	public void setCustomerTelephone(String customerTelephone) {
		this.customerTelephone = customerTelephone;
	}

	public String getProName() {
		return proName;
	}

	public void setProName(String proName) {
		this.proName = proName;
	}

	public String getCityName() {
		return cityName;
	}

	public void setCityName(String cityName) {
		this.cityName = cityName;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getAreaName() {
		return areaName;
	}

	public void setAreaName(String areaName) {
		this.areaName = areaName;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getCategoryWx() {
		return categoryWx;
	}

	public void setCategoryWx(String categoryWx) {
		this.categoryWx = categoryWx;
	}

	public String getCategoryZfb() {
		return categoryZfb;
	}

	public void setCategoryZfb(String categoryZfb) {
		this.categoryZfb = categoryZfb;
	}

	public String getCategoryYl() {
		return categoryYl;
	}

	public void setCategoryYl(String categoryYl) {
		this.categoryYl = categoryYl;
	}

	public String getBankType() {
		return bankType;
	}

	public void setBankType(String bankType) {
		this.bankType = bankType;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankCardNo() {
		return bankCardNo;
	}

	public void setBankCardNo(String bankCardNo) {
		this.bankCardNo = bankCardNo;
	}

	public String getBankAccName() {
		return bankAccName;
	}

	public void setBankAccName(String bankAccName) {
		this.bankAccName = bankAccName;
	}

	public String getAccountType() {
		return accountType;
	}

	public void setAccountType(String accountType) {
		this.accountType = accountType;
	}

	public String getBusinessLicenseType() {
		return businessLicenseType;
	}

	public void setBusinessLicenseType(String businessLicenseType) {
		this.businessLicenseType = businessLicenseType;
	}

	public String getBusinessLicense() {
		return businessLicense;
	}

	public void setBusinessLicense(String businessLicense) {
		this.businessLicense = businessLicense;
	}

	public String getLegalPersonType() {
		return legalPersonType;
	}

	public void setLegalPersonType(String legalPersonType) {
		this.legalPersonType = legalPersonType;
	}

	public Integer getCertificateType() {
		return certificateType;
	}

	public void setCertificateType(Integer certificateType) {
		this.certificateType = certificateType;
	}

	public String getCertificateNo() {
		return certificateNo;
	}

	public void setCertificateNo(String certificateNo) {
		this.certificateNo = certificateNo;
	}

	public String getPayTypes() {
		return payTypes;
	}

	public void setPayTypes(String payTypes) {
		this.payTypes = payTypes;
	}

	public String getMerchantOperationType() {
		return merchantOperationType;
	}

	public void setMerchantOperationType(String merchantOperationType) {
		this.merchantOperationType = merchantOperationType;
	}

	public String getRmk() {
		return rmk;
	}

	public void setRmk(String rmk) {
		this.rmk = rmk;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

}
