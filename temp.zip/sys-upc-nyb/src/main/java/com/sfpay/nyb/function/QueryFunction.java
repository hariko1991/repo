/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.nyb.function;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.ChannelCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.service.IHttpInvokeService;
import com.sfpay.nyb.cnst.NybCnst;
import com.sfpay.nyb.cnst.TradeTypeCnst;
import com.sfpay.nyb.dto.req.trade.QueryReq;
import com.sfpay.nyb.util.ReqArgValidationUtil;
import com.sfpay.nyb.util.SignUtil;
import com.sfpay.nyb.util.StatusUtil;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月2日
 */
public class QueryFunction {

	private static final Logger LOGGER = LoggerFactory.getLogger(QueryFunction.class);
	private static final String[] QUERY_KEY_ARRAY = new String[] { MapCnst.REQ_ORDER_NO };
	private static final List<String> QUERY_KEY_LIST = Arrays.asList(QUERY_KEY_ARRAY);

	public static Map<String, String> getResp(IHttpInvokeService httpInvokeService, Map<String, String> reqMap,
			Map<String, String> extMap, String logMsg) {
		if (ReqArgValidationUtil.validationArg(reqMap, QUERY_KEY_LIST)) {
			LOGGER.info("{}校验通过,参数没有问题", logMsg);
		}

		Map<String, String> respMap = new HashMap<String, String>();
		String reqMsg = "";
		try {
			reqMsg = buildReqMsg(reqMap, extMap);
			LOGGER.info("{}组装请求参数json格式[{}]", logMsg, reqMsg);
		} catch (Exception e) {
			LOGGER.error("{}组装请求参数json加密串为异常", logMsg, e);
			throw new ServiceException(RtnCodeCnst.SIGN_FAIL, "签名异常");
		}

		String respMsg = null;
		try {
			respMsg = httpInvokeService.sendAndReceiveForTrade(ChannelCnst.CHANNEL_NYB, reqMsg, extMap);
			LOGGER.info("{}请求返回报文[{}]", logMsg, respMsg);
		} catch (Exception e) {
			LOGGER.error("{}和银行通信异常", logMsg, e);
			throw new ServiceException(RtnCodeCnst.NETWORK_EXCHANGE_EXCEPTION, "网络通迅异常");
		}

		JSONObject jsonObj = JSONObject.parseObject(respMsg);
		String rtnCode = "";
		String rtnMsg = "";
		if (NybCnst.SUCCESS.equals(jsonObj.getString(NybCnst.RETURN_CODE))) {
			if (NybCnst.SUCCESS.equals(jsonObj.getString(NybCnst.RESULT_CODE))) {
				String status = StatusUtil.getPayStatus(jsonObj.getString(NybCnst.PAY_STATUS));
				if (StatusCnst.TRADING.equals(status)) {
					return respMap;
				}
				respMap.put(SqlCnst.TARGET_STATUS, status);
				respMap.put(SqlCnst.CHANNEL_NO, jsonObj.getString(NybCnst.CHANNEL_ORDER_NO));
				respMap.put(SqlCnst.RTN_ORDER_NO, jsonObj.getString(NybCnst.OUT_CHANNEL_NO));
				respMap.put(SqlCnst.EXT_TAB_BUYERID, "");
				respMap.put(SqlCnst.EXT_TAB_OPENID, "");
				respMap.put(SqlCnst.EXT_TAB_BUYERACCOUNT, "");
				if (StatusCnst.FAILURE.equals(status)) {
					rtnCode = jsonObj.getString(NybCnst.ERR_CODE);
					rtnMsg = jsonObj.getString(NybCnst.ERR_CODE_DES);
					if(StringUtils.isBlank(rtnMsg)){
						rtnMsg = "支付失败,主动查询,返回状态["+jsonObj.getString(NybCnst.PAY_STATUS)+"]";
					}
				} else {
					rtnCode = jsonObj.getString(NybCnst.RESULT_CODE);
					rtnMsg = "支付成功,主动查询";
				}
			} else {
				respMap.put(SqlCnst.TARGET_STATUS, StatusCnst.FAILURE);
				LOGGER.error("{}和银行通道应答业务结果失败,响应结果{}", logMsg, respMsg);
				rtnCode = jsonObj.getString(NybCnst.ERR_CODE);
				rtnMsg = jsonObj.getString(NybCnst.ERR_CODE_DES);
			}
		} else {
			LOGGER.error("{}和银行通道应答失败,响应结果{}", logMsg, respMsg);
			rtnCode = jsonObj.getString(NybCnst.RETURN_CODE);
			rtnMsg = jsonObj.getString(NybCnst.RETURN_MSG);
		}
		respMap.put(SqlCnst.RTN_CODE, rtnCode);
		respMap.put(SqlCnst.RTN_MSG, rtnMsg);
		return respMap;
	}

	private static String buildReqMsg(Map<String, String> reqMap, Map<String, String> extMap) throws Exception {
		QueryReq query = new QueryReq();
		query.setTradeType(TradeTypeCnst.CS_TRADE_SINGLE_QUERY);
		query.setVersion(NybCnst.VERSION_1_3);
		query.setMchId(extMap.get(MapCnst.APP_ID));
		query.setSubMchId(extMap.get(MapCnst.CHANNEL_MCH_NO));
		query.setOutTradeNo(reqMap.get(MapCnst.REQ_ORDER_NO));
		query.setQueryType(NybCnst.QUERY_TYPE_1);
		query.setSign(SignUtil.sign(extMap.get(MapCnst.SECRET_KEY), query.toMap()));
		return JSON.toJSONString(query);
	}
}
