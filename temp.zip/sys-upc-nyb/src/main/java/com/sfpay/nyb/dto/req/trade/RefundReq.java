package com.sfpay.nyb.dto.req.trade;

import java.math.BigDecimal;

import com.sfpay.nyb.dto.req.Req;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年7月27日
 */
public class RefundReq extends Req {

	private static final long serialVersionUID = -3387506944806396159L;
	// 交易类型 tradeType 是 String(32) cs.bill.download
	private String tradeType;
	// 版本 version 是 String(8) 版本号 1.3
	private String version;
	// 代理商号 mchId 是 String(32) 由平台分配 000100003
	private String mchId;
	// 商户号 subMchId 是 String(32) 由平台分配的商户号 000100001000004
	private String subMchId;
	// 通道类型 channel 是 String(24) 第三方通道类型 见附件“通道类型”
	private String channel;
	// 商户订单号 outTradeNo 是 String(32) 商户系统内部的订单号,32个字符内、可包含字母, 确保在商户系统唯一
	private String outTradeNo;

	// 商户退款单号 outRefundNo 是 String(32)
	// 商户系统内部的退款单号，商户系统内部唯一，同一退款单号多次请求只退一笔,一笔退款失败后重新提交，要采用原来的退款单号
	private String outRefundNo;

	// 退款金额 amount 是 Number 单位：元 0.01
	private BigDecimal amount;

	// 退款详情 description 否 String(127) 退款详情
	private String description;

	// 签名 sign 是 String(32) 签名，详见本文档签名签名说明 18e4682fbe3d4c92837c7315ba749d60
	private String sign;

	// 前台回调URL callbackUrl 否 退款申请成功后回调商户url; form表单形式提交商户后台；参数参考交易详细查询;
	private String callbackUrl;

	// 后台通知URL notifyUrl 否 退款申请成功后回调商户url；后台通知参数参考交易详细查询
	private String notifyUrl;

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getMchId() {
		return mchId;
	}

	public void setMchId(String mchId) {
		this.mchId = mchId;
	}

	public String getSubMchId() {
		return subMchId;
	}

	public void setSubMchId(String subMchId) {
		this.subMchId = subMchId;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getOutTradeNo() {
		return outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	public String getOutRefundNo() {
		return outRefundNo;
	}

	public void setOutRefundNo(String outRefundNo) {
		this.outRefundNo = outRefundNo;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public String getNotifyUrl() {
		return notifyUrl;
	}

	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}

}
