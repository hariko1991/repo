/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.nyb.dto.req.trade;

import java.math.BigDecimal;

import com.sfpay.nyb.dto.req.Req;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月1日
 */
public class PublicPayReq extends Req {

	private static final long serialVersionUID = 3553619496844901922L;

	private static final String IS_RAW_1 = "1";

	/**
	 * 交易类型	tradeType	是	String(32)	cs.pay.submit
	 */
	private String tradeType;
	/**
	 * 版本	version	是	String(8)	版本号	1.3
	 */
	private String version;
	/**
	 * 代理商号	mchId	是	String(32)	由平台分配	000100003
	 */
	private String mchId;
	/**
	 * 支付渠道	channel	是	String(24)	支付使用的第三方支付渠道	见附件“支付渠道”
	 */
	private String channel;
	/**
	 * 终端类型	terminalType	否	String(20)		见附件“终端类型”
	 */
	private String terminalType;
	/**
	 * 操作员	cashierNo	否	String(20)		
	 */
	private String cashierNo;
	/**
	 * 商户号	subMchId	是	String(32)	由平台分配的商户号	0000000050000000005
	 */
	private String subMchId;
	/**
	 * 签名	sign	是	String(32)	签名，详见本文档签名签名说明	18e4682fbe3d4c92837c7315ba749d60
	 */
	private String sign;
	/**
	 * 商品描述	body	是	String(128)	商品或支付单简要描述	
	 */
	private String body;
	/**
	 * 商户订单号	outTradeNo	是	String(32)	商户系统内部的订单号,32个字符内、可包含字母, 确保在商户系统唯一
	 */
	private String outTradeNo;
	/**
	 * 交易金额	amount	是	Number	单位：元	0.01
	 */
	private BigDecimal amount;
	/**
	 * 附加数据	description	否	String(127)	附加数据，在查询API和支付通知中原样返回，该字段主要用于商户携带订单的自定义数据
	 */
	private String description;
	/**
	 * 货币类型	currency	否	String(16)	默认人民币：CNY	CNY
	 */
	private String currency;
	/**
	 * 订单支付时间	timePaid	否	String(14)	"订单支付时间 格式为：yyyyMMddHHmmss，"	如2016年10月1日10点10分10秒表示为20161001101010
	 */
	private String timePaid;
	/**
	 * 订单失效时间	timeExpire	否	String(14)	订单失效时间，格式同上,不传默认30分钟	如2016年10月1日10点10分10秒表示为20161001101010
	 */
	private String timeExpire;
	/**
	 * 商品的标题	subject	否	String(16)	商品的标题，该参数最长为 32 个 Unicode 字符，京东支付、网关支付、快捷支付、QQ钱包为必填
	 */
	private String subject;
	/**
	 * 为指定支付方式，指定不能使用信用卡支付可设置为no_credit
	 */
	private String limitPay;
	/**
	 * 支付成功跳转路径；form表单形式提交商户后台；参数参考交易详细查询;
	 */
	private String callbackUrl;
	/**
	 * 支付完成后结果通知url；参数参考交易详细查询;
	 */
	private String notifyUrl;
	/**
	 *  0:待封装;1:原生公众号(返回json串给jsapi拉起支付)
	 */
	private String isRaw = IS_RAW_1;
	/**
	 * 子商户公众号标识
	 */
	private String subAppId;
	/**
	 * 子商户公众号下关注的用户openid
	 */
	private String subOpenId;
	/**
	 * 微信支付分配的子商户号
	 */
	private String wxSubMchId;

	private String receipt;

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

	public String getVersion() {
		return version;
	}

	public void setVersion(String version) {
		this.version = version;
	}

	public String getMchId() {
		return mchId;
	}

	public void setMchId(String mchId) {
		this.mchId = mchId;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getTerminalType() {
		return terminalType;
	}

	public void setTerminalType(String terminalType) {
		this.terminalType = terminalType;
	}

	public String getCashierNo() {
		return cashierNo;
	}

	public void setCashierNo(String cashierNo) {
		this.cashierNo = cashierNo;
	}

	public String getSubMchId() {
		return subMchId;
	}

	public void setSubMchId(String subMchId) {
		this.subMchId = subMchId;
	}

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getBody() {
		return body;
	}

	public void setBody(String body) {
		this.body = body;
	}

	public String getOutTradeNo() {
		return outTradeNo;
	}

	public void setOutTradeNo(String outTradeNo) {
		this.outTradeNo = outTradeNo;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getTimePaid() {
		return timePaid;
	}

	public void setTimePaid(String timePaid) {
		this.timePaid = timePaid;
	}

	public String getTimeExpire() {
		return timeExpire;
	}

	public void setTimeExpire(String timeExpire) {
		this.timeExpire = timeExpire;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getLimitPay() {
		return limitPay;
	}

	public void setLimitPay(String limitPay) {
		this.limitPay = limitPay;
	}

	public String getCallbackUrl() {
		return callbackUrl;
	}

	public void setCallbackUrl(String callbackUrl) {
		this.callbackUrl = callbackUrl;
	}

	public String getNotifyUrl() {
		return notifyUrl;
	}

	public void setNotifyUrl(String notifyUrl) {
		this.notifyUrl = notifyUrl;
	}

	public String getIsRaw() {
		return isRaw;
	}

	public void setIsRaw(String isRaw) {
		this.isRaw = isRaw;
	}

	public String getSubAppId() {
		return subAppId;
	}

	public void setSubAppId(String subAppId) {
		this.subAppId = subAppId;
	}

	public String getSubOpenId() {
		return subOpenId;
	}

	public void setSubOpenId(String subOpenId) {
		this.subOpenId = subOpenId;
	}

	public String getWxSubMchId() {
		return wxSubMchId;
	}

	public void setWxSubMchId(String wxSubMchId) {
		this.wxSubMchId = wxSubMchId;
	}

	public String getReceipt() {
		return receipt;
	}

	public void setReceipt(String receipt) {
		this.receipt = receipt;
	}

}
