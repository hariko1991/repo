/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.nyb.dto.req;

import java.io.Serializable;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年7月26日
 */
public class Req implements Serializable {
	private static final long serialVersionUID = -3816777108663715170L;
	private static final String CLAZZ = "class";

	@SuppressWarnings("unchecked")
	public Map<String, String> toMap() throws Exception {
		Map<String, String> rtnMap = BeanUtils.describe(this);
		rtnMap.remove(CLAZZ);
		return rtnMap;
	}

}