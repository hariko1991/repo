/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.nyb.cnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月26日
 */
public final class MerchantCnst {
	public static final String MERCHANT_NAME = "merchantName";
	public static final String MERCHANT_SHORT_NAME = "merchantShortName";

	public static final String OP_NAME = "opName";
	public static final String OP_PHONE = "opPhone";

	public static final String CUSTOMER_TELEPHONE = "customerTelephone";
	public static final String PRO_NAME = "proName";
	public static final String CITY_NAME = "cityName";
	public static final String ADDRESS = "address";
	public static final String AREANAME = "areaName";
	public static final String TELEPHONE = "telephone";
	public static final String EMAIL = "email";

	public static final String CATEGORY_WX = "categoryWx";
	public static final String CATEGORY_ZFB = "categoryZfb";
	public static final String CATEGORY_YL = "categoryYl";

	public static final String BANK_TYPE = "bankType";
	public static final String BANK_NAME = "bankName";
	public static final String BANK_CARD_NO = "bankCardNo";
	public static final String BANK_ACC_NAME = "bankAccName";
	public static final String ACCOUNT_TYPE = "accountType";
	public static final String BUSINESS_LICENSE_TYPE = "businessLicenseType";
	public static final String BUSINESS_LICENSE = "businessLicense";
	public static final String LEGAL_PERSON_TYPE = "legalPersonType";
	public static final String CERTIFICATE_TYPE = "certificateType";
	public static final String CERTIFICATE_NO = "certificateNo";
	public static final String PAY_TYPES = "payTypes";
	public static final String MERCHANT_OPERATION_TYPE = "merchantOperationType";
	public static final String RMK = "rmk";
	public static final String SIGN = "sign";

	/**
	 * 交易类型	tradeType	是	String(32)	cs.merchant.register	
	 * 版本	version	是	String(8)	版本号	1.3
	 * 代理商编号	mchId	是	String(32)	由平台分配的代理商编号	000100003
	 * 商户名称	merchantName	是	String(128)	要求与营业执照上的名称一致	
	 * 商户简称	merchantShortName	是	String(20)	商户简称	
	 * 负责人	opName	是	String(20)	负责人	
	 * 负责人电话	opPhone	是	String(20)	负责人电话，手机或座机	13900008888
	 * 客服电话	customerTelephone	是	String(20)	客服电话,手机或座机	
	 * 省份	proName	是	String(20)	省份	北京
	 * 城市	cityName	是	String(20)	城市	北京
	 * 地址	address	是	String(240)	地址	
	 * 区县	areaName	是	String(20)	区县	朝阳区
	 * 电话	telephone	是	String(32)	电话,手机或座机	
	 * 邮箱	email	是	String(50)	邮箱	
	 * 经营类目	categoryWx	是	String(32)	微信经营类目	见附件：微信经营类目
	 * 经营类目	categoryZfb	是	String(32)	支付宝经营类目	见附件：支付宝经营类目
	 * 经营类目	categoryYl	是	String(32)	银联经营类目	见附件：银联经营类目
	 * 银行类型	bankType	是	String(20)	银行类型 见附件7.7	
	 * 银行名称	bankName	是	String(100)	银行名称	
	 * 银行卡号	bankCardNo	是	String(20)	银行卡号	
	 * 户名	bankAccName	是	String(100)	户名	
	 * 帐户类型	accountType	是	Integer(1)	帐户类型;1：个人；2：企业	
	 * 营业执照类型	businessLicenseType	否	String(20)	营业执照类型：NATIONAL_LEGAL：营业执照；NATIONAL_LEGAL_MERGE:多证合一；INST_RGST_CTF：事业单位法人证书	
	 * 营业执照编号	businessLicense	否	String(20)	营业执照编号	
	 * 受理商户负责人信息	legalPersonType	是	String(20)	负责人信息：LEGAL_PERSON：法人；CONTROLLER：实际控制人；AGENT：代理人；OTHER：其他	
	 * 证件类型	certificateType	否	Integer(1)	证件类型；1-身份证；2-营业执照	
	 * 证件号码	certificateNo	否	String(50)	证件号码	
	 * 支付类型列表	payTypes	是	String(1000)	说明：payTypeCode必填项：请从附件：支付渠道中取值；rateType必填项：1表示交易额比例(%)，2表示固定费率；rate必填项，费率值； rmk非必填项	"payTypes":"[{\"payTypeCode\":\"wxPub\",\"rateType\":1,\"rate\":0.3,\"rmk\":\"微信公众账号支付\"},{\"payTypeCode\":\"wxPubQR\",\"rateType\":2,\"rate\":0.35,\"rmk\":\"公众账号扫码支付\"}]"
	 * 商户经营类型	merchantOperationType	是	String(1)	实体：1    虚拟：2	1
	 * 备注说明	rmk	否	String(128)	介绍商户营业内容等	
	 * 签名	sign	是	String(32)	签名，详见本文档签名签名说明	3B61007C11C5BABEC3F5020F2775D619
	 */
}
