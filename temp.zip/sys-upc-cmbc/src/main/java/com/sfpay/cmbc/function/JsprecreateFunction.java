package com.sfpay.cmbc.function;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.cmbc.cnst.CharCnst;
import com.sfpay.cmbc.cnst.DataCnst;
import com.sfpay.cmbc.cnst.JsprecreateCnst;
import com.sfpay.cmbc.cnst.MethodCnst;
import com.sfpay.cmbc.util.PackerUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.ChannelCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.PayCodeCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.service.IHttpInvokeService;
import com.sfpay.front.util.CurrencyUtil;

/**
 * 
 * 类说明：<br>
 * 10.一码付预下单接口：
 * 
 * <p>
 * 详细描述：<br>
 * 由于该接口需要配置微信二维码回调地址， 所需要在生产环境进行调试测试
 * 生产请求地址： https://test.njcmbc.com/oss-transaction/gateway/jsprecreate
 * 测试参数请联系对接调试人员
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月5日
 */
public class JsprecreateFunction {

	private static final Logger LOGGER = LoggerFactory.getLogger(JsprecreateFunction.class);

	public static Map<String, String> getResp(IHttpInvokeService httpInvokeService, Map<String, String> reqMap,
			Map<String, String> extMap, String logMsg) {

		String reqMsg = buildReqMsg(reqMap, extMap);
		LOGGER.info("{}组装请求银行 post data 明文[{}]", logMsg, reqMsg);

		String respMsg = null;
		try {
			respMsg = httpInvokeService.sendAndReceiveForTrade(ChannelCnst.CHANNEL_CMBC, reqMsg, extMap);
			LOGGER.info("{}请求返回报文[{}]", logMsg, respMsg);
		} catch (Exception e) {
			LOGGER.error("{}和银行通信异常", logMsg, e);
			throw new ServiceException(RtnCodeCnst.NETWORK_EXCHANGE_EXCEPTION, "网络通迅异常");
		}

		return PackerUtil.analysisSignMsg(respMsg, extMap.get(MapCnst.PUBLIC_KEY));
	}

	private static String buildReqMsg(Map<String, String> reqMap, Map<String, String> extMap) {
		Map<String, Object> contentMap = new HashMap<String, Object>();
		contentMap.put("encryptId", extMap.get(MapCnst.ENCRYPT_ID));

		contentMap.put("apiVersion", DataCnst.CMBC_APIVERSION);
		contentMap.put("txnDate", System.currentTimeMillis());
		contentMap.put("mid", extMap.get(MapCnst.CHANNEL_MCH_NO));

		contentMap.put("method", MethodCnst.JSPRECREATE_METHOD);
		String walletType = reqMap.get(JsprecreateCnst.walletType);
		if (PayCodeCnst.PAY_CODE_ALIPAY.equals(walletType)) {
			contentMap.put("walletType", CharCnst.WALLET_TYPE_1);
		} else if (PayCodeCnst.PAY_CODE_WX.equals(walletType)) {
			contentMap.put("walletType", CharCnst.WALLET_TYPE_2);
		}
		contentMap.put("srcAmt", CurrencyUtil.fen2Yuan(Long.valueOf(reqMap.get(JsprecreateCnst.srcAmt))));
		contentMap.put("goods_desc", reqMap.get(JsprecreateCnst.goodsDesc));
		contentMap.put("merchantInput", reqMap.get(JsprecreateCnst.merchantInput));
		contentMap.put("bizOrderNumber", reqMap.get(MapCnst.REQ_ORDER_NO));

		contentMap.put("notifyUrl", extMap.get(MapCnst.NOTIFY_URL));
		contentMap.put("userId", reqMap.get(JsprecreateCnst.userId)); // 支付宝为buyer_id
																		// 微信为open_id
		contentMap.put("subAppid", reqMap.get(JsprecreateCnst.subAppid));// 不必须微信使用
		contentMap.put("receipt",
				Boolean.valueOf(reqMap.get(JsprecreateCnst.receipt)) ? CharCnst.YES_FLAG : CharCnst.NO_FALG);

		return PackerUtil.packerSignMsg(contentMap, extMap.get(MapCnst.PUBLIC_KEY));
	}

}
