package com.sfpay.cmbc.function;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.cmbc.cnst.DataCnst;
import com.sfpay.cmbc.cnst.MethodCnst;
import com.sfpay.cmbc.util.PackerUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.ChannelCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.ReconCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.service.IHttpInvokeService;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月27日
 */
public class DownloadBillFunction {

	private final static Logger LOGGER = LoggerFactory.getLogger(DownloadBillFunction.class);

	public static Map<String, String> getResp(IHttpInvokeService httpInvokeService, Map<String, String> reqMap,
			Map<String, String> extMap, String logMsg) {

		String reqMsg = buildReqMsg(reqMap, extMap);
		LOGGER.info("{}组装请求银行 post data 明文[{}]", logMsg, reqMsg);

		String respMsg = null;
		try {
			respMsg = httpInvokeService.sendAndReceiveForRecon(ChannelCnst.CHANNEL_CMBC, reqMsg, extMap);
			LOGGER.info("{}请求返回报文[{}]", logMsg, respMsg);
		} catch (Exception e) {
			LOGGER.error("{}和银行通信异常", logMsg, e);
			throw new ServiceException(RtnCodeCnst.NETWORK_EXCHANGE_EXCEPTION, "网络通迅异常");
		}

		String[] respStr = respMsg.split(ReconCnst.VERTICAL_SEPARATOR);
		Map<String, String> respMap = new HashMap<String, String>();
		respMap.put(SqlCnst.RTN_CODE, respStr[0]);
		respMap.put(SqlCnst.RTN_MSG, respStr[1]);
		return respMap;
	}

	private static String buildReqMsg(Map<String, String> reqMap, Map<String, String> extMap) {
		Map<String, Object> contentMap = new HashMap<String, Object>();
		contentMap.put("encryptId", extMap.get(MapCnst.ENCRYPT_ID));
		contentMap.put("apiVersion", DataCnst.CMBC_APIVERSION);
		contentMap.put("txnDate", System.currentTimeMillis());
		contentMap.put("mid", extMap.get(MapCnst.CHANNEL_MCH_NO));
		contentMap.put("method", MethodCnst.DOWNLOADBILL_METHOD);
		contentMap.put("txnSubmittedDate", reqMap.get("txnSubmittedDate"));

		return PackerUtil.packerSignMsg(contentMap, extMap.get(MapCnst.PUBLIC_KEY));
	}

}
