/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.cmbc.cnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月3日
 */
public final class MethodCnst {
	public static final String ADD_MERCHANT_METHOD = "addMerchant";

	public static final String CANCEL_METHOD = "cancel";

	public static final String DOWNLOADBILL_METHOD = "downloadbill";

	public static final String GET_MERCHANT_DETAIL_METHOD = "getMerchantDetail";

	public static final String QUERY_METHOD = "query";

	public static final String REFUND_METHOD = "refund";

	public static final String UPDATEMERCHANT_METHOD = "updateMerchant";

	public static final String UPDATE_NOTIFY_URL_METHOD = "updateNotifyUrl";

	public static final String UPLOAD_IMAGE_METHOD = "uploadImage";
	
	public static final String CREATE_AND_PAY_METHOD = "createAndPay";
	
	public static final String JSPRECREATE_METHOD = "jsprecreate";
	
}
