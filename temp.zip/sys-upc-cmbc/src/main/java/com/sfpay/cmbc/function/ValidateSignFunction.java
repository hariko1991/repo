package com.sfpay.cmbc.function;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.cmbc.util.PackerUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;

public class ValidateSignFunction {

private static final Logger LOGGER = LoggerFactory.getLogger(ValidateSignFunction.class);
	
	public static Map<String, String> validateSign(Map<String, String> reqMap,
			Map<String, String> extMap, String logMsg) {
		LOGGER.info("{}组装请求参数json格式[{}]", logMsg, reqMap);
		Map<String, String> respMap = new HashMap<String, String>();
		try {
			StringBuilder sb = new StringBuilder();
			sb.append(MapCnst.BIZ_ORDER_NUMBER).append("=")
					.append(reqMap.get(MapCnst.BIZ_ORDER_NUMBER)).append("&")
					.append(MapCnst.COMPLETED_TIME).append("=")
					.append(reqMap.get(MapCnst.COMPLETED_TIME)).append("&")
					.append(MapCnst.MID).append("=")
					.append(reqMap.get(MapCnst.MID)).append("&")
					.append(MapCnst.SRC_AMT).append("=")
					.append(reqMap.get(MapCnst.SRC_AMT));
			boolean flag = PackerUtil.md5Verify(sb.toString(),
					reqMap.get(MapCnst.NOTIFY_SIGN),
					extMap.get(MapCnst.PUBLIC_KEY));
			if(flag){
				respMap.put(SqlCnst.TARGET_STATUS, StatusCnst.SUCCESS);
				return respMap;
			}else{
				throw new ServiceException(RtnCodeCnst.SIGN_NOT_PASS, "验证签名不通过");
			}
		} catch (Exception e) {
			LOGGER.error("{}组装请求参数json加密串为异常", logMsg, e);
		}
		return null;
	}
}
