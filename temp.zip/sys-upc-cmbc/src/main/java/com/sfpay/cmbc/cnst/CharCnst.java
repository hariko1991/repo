/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.cmbc.cnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月3日
 */
public final class CharCnst {
	public static final String TRADE_MID = "TRADE_MID";
	public static final String TRADE_ENCRYPT_ID = "TRADE_ENCRYPT_ID";
	public static final String TRADE_PUBLIC_KEY = "TRADE_PUBLIC_KEY";
	public static final String MERCHANT_AID = "MERCHANT_AID";
	public static final String MERCHANT_ENCRYPT_ID = "MERCHANT_ENCRYPT_ID";
	public static final String MERCHANT_PUBLIC_KEY = "MERCHANT_PUBLIC_KEY";
	public static final String NETWORK_URL = "NETWORK_URL";
	public static final String YES_FLAG = "Y";
	public static final String NO_FALG = "N";
	public static final String ENABLE = "ENABLE";
	public static final String DISABLE = "DISABLE";

	public static final String METHOD = "method";
	public static final String CONTENT = "content";
	public static final String SIGN = "sign";
	public static final String RESULT = "result";
	public static final String DATA = "data";
	public static final String KEY = "key";
	public static final String CODE = "code";
	public static final String MESSAGE = "message";
	public static final String WALLETTYPE = "walletType";

	public static final String JSPRECREATE_NOTIFY_URL = "JSPRECREATE_NOTIFY_URL";

	public static final String ENV = "ENV";
	public static final String ENV_TEST = "TEST";
	public static final String PROV_ACCT_NO = "CMBC_PROV_ACCT_NO";
	public static final String COMPENSATE_NOTIFY_WHEN_LONG = "COMPENSATE_NOTIFY_WHEN_LONG";

	public static final String WALLET_TYPE_1 = "1";
	public static final String WALLET_TYPE_2 = "2";
}
