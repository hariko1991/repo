package com.sfpay.cmbc.cnst;

public final class DataCnst {
	
	public static final String WALLET_TYPE_ALIPAY = "1";
	
	public static final String WALLET_TYPE_WX = "2";
	
	public static final String CMBC_STATUS_SUCCESS = "s";

	public static final String CMBC_STATUS_REFUND = "r";
	
	public static final String CMBC_STATUS_CLOSED = "c";
	
	public static final String CMBC_STATUS_PROCESSING = "p";
	/**
	 * 交易成功(针对对账单)
	 */
	public static final String CMBC_BILL_STATUS_SUCCESS = "P";
	
	public static final String CMBC_APIVERSION = "1";
	
	public static final String AID = "aid";
	public static final String ENCRYPTID = "encryptId";
	public static final String PUBLICKEY = "publicKey";
	
	public static final String MID = "mid";
	
}
