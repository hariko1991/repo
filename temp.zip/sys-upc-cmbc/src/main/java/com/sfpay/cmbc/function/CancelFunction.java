package com.sfpay.cmbc.function;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.sfpay.cmbc.cnst.CharCnst;
import com.sfpay.cmbc.cnst.DataCnst;
import com.sfpay.cmbc.cnst.MethodCnst;
import com.sfpay.cmbc.util.PackerUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.ChannelCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.service.IHttpInvokeService;

public class CancelFunction {

	private static final Logger LOGGER = LoggerFactory.getLogger(CancelFunction.class);

	public static Map<String, String> getResp(IHttpInvokeService httpInvokeService, Map<String, String> reqMap,
			Map<String, String> extMap, String logMsg) {

		String reqMsg = buildReqMsg(reqMap, extMap);
		LOGGER.info("{}组装请求银行 post data 明文[{}]", logMsg, reqMsg);

		String respMsg = null;
		try {
			respMsg = httpInvokeService.sendAndReceiveForTrade(ChannelCnst.CHANNEL_CMBC, reqMsg, extMap);
			LOGGER.info("{}请求返回报文[{}]", logMsg, respMsg);
		} catch (Exception e) {
			LOGGER.error("{}和银行通信异常", logMsg, e);
			throw new ServiceException(RtnCodeCnst.NETWORK_EXCHANGE_EXCEPTION, "网络通迅异常");
		}
		return analysisSignMsg(respMsg, extMap.get(MapCnst.PUBLIC_KEY));
	}

	@SuppressWarnings("unchecked")
	private static Map<String, String> analysisSignMsg(String respMsg, String publicKey) {
		Map<String, String> respMap = new HashMap<String, String>();

		Map<String, Object> rltMap = JSON.parseObject(respMsg, Map.class);
		Map<String, Object> resultMap = JSON.parseObject((String) rltMap.get(PackerUtil.RESULT), Map.class);

		// 如果是成功返回码，才需要验证
		if (PackerUtil.SUCCESS_CODE.equals((String) resultMap.get(PackerUtil.CODE))) {
			if (!PackerUtil.md5Verify((String) rltMap.get(PackerUtil.RESULT), (String) rltMap.get(PackerUtil.SIGN),
					publicKey)) {
				throw new ServiceException(RtnCodeCnst.SIGN_NOT_PASS, "签名校验不通过");
			}
			respMap.put(SqlCnst.TARGET_STATUS, StatusCnst.CLOSE);
			// Map<String, String> dataMap = (Map<String, String>)
			// resultMap.get(PackerUtil.DATA);
			// if (dataMap != null && !dataMap.isEmpty()) {
			// respMap.put(SqlCnst.RTN_ORDER_NO, dataMap.get("bizOrderNumber"));
			// }
		} else {
			LOGGER.error("{},银行通道返回撤销失败", respMsg);
			//throw new ServiceException(RtnCodeCnst.BANK_RTN_CANCEL_FAILURE, "银行通道返回撤销失败");
		}

		respMap.put(SqlCnst.RTN_CODE, (String) resultMap.get(CharCnst.CODE));
		respMap.put(SqlCnst.RTN_MSG, (String) resultMap.get(CharCnst.MESSAGE));
		return respMap;
	}

	private static String buildReqMsg(Map<String, String> reqMap, Map<String, String> extMap) {
		Map<String, Object> contentMap = new HashMap<String, Object>();
		contentMap.put("encryptId", extMap.get(MapCnst.ENCRYPT_ID));
		contentMap.put("apiVersion", DataCnst.CMBC_APIVERSION);
		contentMap.put("txnDate", System.currentTimeMillis());
		contentMap.put("mid", extMap.get(MapCnst.CHANNEL_MCH_NO));

		contentMap.put("method", MethodCnst.CANCEL_METHOD);
		contentMap.put("bizOrderNumber", reqMap.get(MapCnst.REQ_ORDER_NO));

		return PackerUtil.packerSignMsg(contentMap, extMap.get(MapCnst.PUBLIC_KEY));
	}

}
