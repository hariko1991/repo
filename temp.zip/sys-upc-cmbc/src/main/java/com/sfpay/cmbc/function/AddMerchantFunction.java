package com.sfpay.cmbc.function;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.cmbc.cnst.DataCnst;
import com.sfpay.cmbc.cnst.MethodCnst;
import com.sfpay.cmbc.util.PackerUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.ChannelCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.service.IHttpInvokeService;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月27日
 */
public class AddMerchantFunction {
	private static final Logger LOGGER = LoggerFactory.getLogger(AddMerchantFunction.class);

	public static Map<String, String> getResp(IHttpInvokeService httpInvokeService, Map<String, String> reqMap,
			Map<String, String> extMap, String logMsg) {

		String reqMsg = buildReqMsg(reqMap, extMap);
		LOGGER.info("{}组装请求银行 post data 明文[{}]", logMsg, reqMsg);

		String respMsg = null;
		try {
			respMsg = httpInvokeService.sendAndReceiveForTrade(ChannelCnst.CHANNEL_CMBC, reqMsg, extMap);
			LOGGER.info("{}请求返回报文[{}]", logMsg, respMsg);
		} catch (Exception e) {
			LOGGER.error("{}和银行通信异常", logMsg, e);
			throw new ServiceException(RtnCodeCnst.NETWORK_EXCHANGE_EXCEPTION, "网络通迅异常");
		}

		return PackerUtil.analysisSignMsg(respMsg, extMap.get(MapCnst.PUBLIC_KEY));
	}

	private static String buildReqMsg(Map<String, String> reqMap, Map<String, String> extMap) {
		Map<String, Object> contentMap = new HashMap<String, Object>();

		contentMap.put("encryptId", extMap.get(MapCnst.ENCRYPT_ID));
		contentMap.put("apiVersion", DataCnst.CMBC_APIVERSION);
		contentMap.put("txnDate", System.currentTimeMillis());
		contentMap.put("aid", extMap.get(MapCnst.AID));

		contentMap.put("method", MethodCnst.ADD_MERCHANT_METHOD);
		contentMap.put("email", reqMap.get("email"));
		contentMap.put("name", reqMap.get("name"));
		contentMap.put("shortName", reqMap.get("shortName"));
		contentMap.put("address", reqMap.get("address"));
		contentMap.put("alipayCategoryCode", reqMap.get("alipayCategoryCode"));
		contentMap.put("webchatCategoryCode", reqMap.get("webchatCategoryCode"));
		contentMap.put("legalPerson", reqMap.get("legalPerson"));
		contentMap.put("legalPersonID", reqMap.get("legalPersonID"));
		contentMap.put("firstName", reqMap.get("firstName"));
		contentMap.put("cellPhone", reqMap.get("cellPhone"));
		contentMap.put("bankCode", reqMap.get("bankCode"));
		contentMap.put("issuerProvince", reqMap.get("issuerProvince"));
		contentMap.put("issuerCity", reqMap.get("issuerCity"));
		contentMap.put("isPrivate", reqMap.get("isPrivate"));
		contentMap.put("holderName", reqMap.get("holderName"));
		contentMap.put("idCard", reqMap.get("idCard"));
		contentMap.put("accountNumber", reqMap.get("accountNumber"));
		contentMap.put("alipayFee", reqMap.get("alipayFee"));
		contentMap.put("wechatFee", reqMap.get("wechatFee"));
		contentMap.put("bizLicenseCode", reqMap.get("bizLicenseCode"));
		contentMap.put("legalPersonID1ImageId", reqMap.get("legalPersonID1ImageId"));
		contentMap.put("legalPersonID2ImageId", reqMap.get("legalPersonID2ImageId"));
		contentMap.put("bizLicenseImageId", reqMap.get("bizLicenseImageId"));
		contentMap.put("bizPlaceSnapshot1ImageId", reqMap.get("bizPlaceSnapshot1ImageId"));
		contentMap.put("bizPlaceSnapshot2ImageId", reqMap.get("bizPlaceSnapshot2ImageId"));
		contentMap.put("bizPlaceSnapshot3ImageId", reqMap.get("bizPlaceSnapshot3ImageId"));
		contentMap.put("parentMid", reqMap.get("parentMid"));
		contentMap.put("otherCertImageId", reqMap.get("otherCertImageId"));

		return PackerUtil.packerSignMsg(contentMap, extMap.get(MapCnst.PUBLIC_KEY));
	}

}
