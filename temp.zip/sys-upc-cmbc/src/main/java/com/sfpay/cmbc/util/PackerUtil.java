/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.cmbc.util;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;

import com.alibaba.fastjson.JSON;
import com.sfpay.cmbc.cnst.CharCnst;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.RtnCodeCnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月27日
 */
public final class PackerUtil {

	public static final String SUCCESS_CODE = "000000";
	public static final String RESULT = "result";
	public static final String DATA = "data";
	public static final String KEY = "key";
	public static final String CODE = "code";
	public static final String MESSAGE = "message";
	public static final String CONTENT = "content";
	public static final String SIGN = "sign";

	public static String packerSignMsg(Map<String, Object> reqMap, String publicKey) {
		// 请求内容以Map格式转化为json串
		String contentJson = JSON.toJSONString(reqMap);

		Map<String, Object> signMap = new HashMap<String, Object>();
		signMap.put(CharCnst.CONTENT, contentJson);
		signMap.put(CharCnst.KEY, publicKey);

		String signJson = JSON.toJSONString(signMap);

		String sign = Md5Utils.md5Hex(signJson);

		Map<String, String> paramMap = new HashMap<String, String>();
		paramMap.put(CharCnst.CONTENT, contentJson);
		paramMap.put(CharCnst.SIGN, sign);

		return JSON.toJSONString(paramMap);
	}

	@SuppressWarnings("unchecked")
	public static Map<String, String> analysisSignMsg(String respMsg, String publicKey) {
		Map<String, String> respMap = new HashMap<String, String>();

		Map<String, Object> rltMap = JSON.parseObject(respMsg, Map.class);
		Map<String, Object> resultMap = JSON.parseObject((String) rltMap.get(RESULT), Map.class);

		// 如果是成功返回码，才需要验证
		if (SUCCESS_CODE.equals((String) resultMap.get(CODE))) {
			if (!md5Verify((String) rltMap.get(RESULT), (String) rltMap.get(SIGN), publicKey)) {
				throw new ServiceException(RtnCodeCnst.SIGN_NOT_PASS, "签名校验不通过");
			}
			Map<String, String> dataMap = (Map<String, String>) resultMap.get(DATA);
			if (dataMap != null && !dataMap.isEmpty()) {
				respMap.putAll(dataMap);
			}
		}

		respMap.put(MapCnst.RTN_CODE, (String) resultMap.get(CharCnst.CODE));
		respMap.put(MapCnst.RTN_MSG, (String) resultMap.get(CharCnst.MESSAGE));
		return respMap;
	}

	public static boolean md5Verify(String signData, String rltSign, String cmbcKey) {
		Map<String, Object> rltSignMap = new HashMap<String, Object>();
		rltSignMap.put(CharCnst.RESULT, signData);
		rltSignMap.put(CharCnst.KEY, cmbcKey);

		String rltRqSign = Md5Utils.md5Hex(JSON.toJSONString(rltSignMap));
		return StringUtils.equals(rltRqSign, rltSign) ? Boolean.TRUE : Boolean.FALSE;
	}

}
