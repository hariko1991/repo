/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.cmbc.util;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import com.sfpay.acquirer.common.StringUtils;


/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * 
 * CreateDate: 2017-3-22
 */
public class Md5Utils {
    /**
     * Returns a MessageDigest for the given <code>algorithm</code>.
     * 
     * @param algorithm
     *            The MessageDigest algorithm name.
     * @return An MD5 digest instance.
     * @throws ServiceException
     *             when a {@link java.security.NoSuchAlgorithmException} is
     *             caught
     */

    static MessageDigest getDigest() {
        try {
            return MessageDigest.getInstance("MD5");
        } catch (NoSuchAlgorithmException e) {
            throw new RuntimeException("MD5算法不存在", e);
        }
    }

    /**
     * Calculates the MD5 digest and returns the value as a 16 element
     * <code>byte[]</code>.
     * 
     * @param data
     *            Data to digest
     * @return MD5 digest
     */
    public static byte[] md5(byte[] data) {
        return getDigest().digest(data);
    }

    /**
     * Calculates the MD5 digest and returns the value as a 16 element
     * <code>byte[]</code>.
     * 
     * @param data
     *            Data to digest
     * @return MD5 digest
     */
    public static byte[] md5(String data) {
        return md5(data.getBytes());
    }

    /**
     * Calculates the MD5 digest and returns the value as a 32 character hex
     * string.
     * 
     * @param data
     *            Data to digest
     * @return MD5 digest as a hex string
     */
    public static String md5Hex(byte[] data) {
        return HexUtil.toHexString(md5(data));
    }

    /**
     * Calculates the MD5 digest and returns the value as a 32 character hex
     * string.
     * 
     * @param data
     *            Data to digest
     * @return MD5 digest as a hex string
     */
    public static String md5Hex(String data) {
        return HexUtil.toHexString(md5(data));
    }
    
    public static String md5HexByKey(String data, String key) {
		String result = null;
		try {
			result = HexUtil.toHexString(md5Hex(md5(data), md5(key)));
		} catch (Exception e) {
			//logger.error(String.format("md5算法出错，加密源码：[%s]", data));
			e.getStackTrace();
		}
		return result;
	}

	public static byte[] md5Hex(byte[] data, byte[] key) {
		MessageDigest md5 = getDigest();
		getDigest().update(data);
		return md5.digest(key);
	}

	public static String md5Hex(String data, String key) {
		if(StringUtils.isEmpty(data)){
			return "";
		}
		if(StringUtils.isEmpty(key)){
			key = "";
		}
		return md5Hex(data+key);
	}
	
}
