package com.sfpay.cmbc.util;

import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.PropertyUtils;
import org.apache.commons.lang3.StringUtils;


/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年2月17日
 */
public class BeanValidUtils {
	/**
	 * 方法说明：<br>
	 * 校验验证bean中必填字段是否为空
	 * 
	 * @param bean
	 *            待验证的Bean
	 * @param requireFields
	 *            非空字段的变量名称
	 * @return 为空的必填字段的字段名称
	 */
	public static List<String> validNullField(Object bean, List<String> requireFields) {
		List<String> errFields = new ArrayList<String>();
		if (bean == null) {
			return requireFields;
		}
		for (String name : requireFields) {
			if (PropertyUtils.isReadable(bean, name)) {
				try {
					Object value = PropertyUtils.getProperty(bean, name);
					if (value == null || StringUtils.isEmpty(String.valueOf(value))) {
						errFields.add(name);
					}
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			}
		}
		return errFields;
	}
	
	/**
	 * 方法说明：<br>
	 * 校验验证bean中必填字段是否为空
	 * @param bean 待验证的Bean
	 * @param requireFields  必填字段列表
	 * @return true：存在为空的必填字段;
	 */
	public static boolean existsNullField(Object bean, List<String> requireFields){
		if(bean==null){
			return true;
		}
		for (String name : requireFields) {
			if (PropertyUtils.isReadable(bean, name)) {
				try {
					Object value = PropertyUtils.getProperty(bean, name);
					if (value == null) {
						return true;
					}
				} catch (Exception e) {
					throw new RuntimeException(e);
				}
			}
		}
		return false;
	}

}
