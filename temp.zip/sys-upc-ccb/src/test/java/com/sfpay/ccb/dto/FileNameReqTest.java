package com.sfpay.ccb.dto;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.helper.HttpProxyHelper;
import com.sfpay.ccb.dto.req.FileNameReq;
import com.sfpay.ccb.dto.req.FileNameReq.TxInfo;
import com.sfpay.ccb.util.JaxbUtils;

public class FileNameReqTest {
	private static final Logger LOGGER = LoggerFactory.getLogger(FileNameReqTest.class);
	@Test
	public void fileNameReqTest() throws Exception{
		FileNameReq req = new FileNameReq();
		req.setCustId("105584073990419");
		// req.setLanguage("language");
		req.setRequestSn(RandomStringUtils.randomNumeric(16));
		req.setTxCode("5W1005");
		req.setPassword("sf123456");
		req.setUserId("105584073990419-003");
		TxInfo txInfo = new FileNameReq.TxInfo();
		txInfo.setDate("20171011");
		txInfo.setType("0");
		req.setTxInfo(txInfo );
		String reqxml = JaxbUtils.convertToXml(req, "GB2312", false);
		LOGGER.info(reqxml);
		Map<String, String> header = new HashMap<String, String>();
		header.put("Connection", "close");
		String respXml = HttpProxyHelper.sendByPost("http://10.118.206.25:12345", "requestXml=" + reqxml, "GB2312", 5000, 20000, header);
		LOGGER.info(respXml);
		Assert.assertNotNull(respXml);
	}
}
