/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.dto;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.junit.Assert;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.helper.HttpProxyHelper;
import com.sfpay.ccb.dto.req.FileDownReq;
import com.sfpay.ccb.dto.req.FileDownReq.TxInfo;
import com.sfpay.ccb.util.JaxbUtils;


/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 * CreateDate: 2017年9月15日
 */
public class FileDownReqTest  {

	private static final Logger LOGGER = LoggerFactory.getLogger(FileNameReqTest.class);
	@Test
	public void fileNameReqTest() throws Exception{
		FileDownReq req = new FileDownReq();
		req.setCustId("105584073990419");
		// req.setLanguage("language");

		req.setRequestSn(RandomStringUtils.randomNumeric(16));
		req.setTxCode("6W0111");
		req.setPassword("sf123456");
		req.setUserId("105584073990419-003");
		TxInfo txInfo = new FileDownReq.TxInfo();
		txInfo.setSource("SHOP.105584073990419.20171011.20171011.20171012085955.zip");
		req.setTxInfo(txInfo );
		String reqxml = JaxbUtils.convertToXml(req, "GB2312", false);
		LOGGER.info(reqxml);
		Map<String, String> header = new HashMap<String, String>();
		header.put("Connection", "close");
		String respXml = HttpProxyHelper.sendByPost("http://10.118.206.25:12345", "requestXml=" + reqxml, "GB2312", 5000, 20000, header);
		LOGGER.info(respXml);
		Assert.assertNotNull(respXml);
	}
}
