/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.dto.req;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * 类说明：<br>
 * 商户单笔退款交易DTO
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2017年9月8日
 */
@XmlRootElement(name = "TX")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "txInfo"})
public class RefundReq extends BaseReq {

	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(propOrder = { "money", "order", "refundCode" })
	public static class TxInfo {

		/**
		 * 7 MONEY 退款金额 varChar(100) F CN
		 */
		@XmlElement(name = "MONEY", required = true)
		private String money;

		/**
		 * 8 ORDER 订单号 varChar(30) F CN
		 */
		@XmlElement(name = "ORDER", required = true)
		private String order;
		/**
		 * 9 REFUND_CODE 退款流水号 varChar(15) F CN
		 */
		@XmlElement(name = "REFUND_CODE", required = true)
		private String refundCode;

		public String getMoney() {
			return money;
		}

		public String getOrder() {
			return order;
		}

		public String getRefundCode() {
			return refundCode;
		}

		public void setMoney(String money) {
			this.money = money;
		}

		public void setOrder(String order) {
			this.order = order;
		}

		public void setRefundCode(String refundCode) {
			this.refundCode = refundCode;
		}

	}

	private static final long serialVersionUID = -3376217537747069840L;

	@XmlElement(name = "TX_INFO", required = true)
	private TxInfo txInfo;

	public TxInfo getTxInfo() {
		return txInfo;
	}

	public void setTxInfo(TxInfo txInfo) {
		this.txInfo = txInfo;
	}

}
