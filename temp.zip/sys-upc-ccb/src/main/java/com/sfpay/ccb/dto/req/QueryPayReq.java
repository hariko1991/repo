package com.sfpay.ccb.dto.req;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年7月27日
 */
@XmlRootElement(name = "TX")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "txInfo"})
public class QueryPayReq extends BaseReq {
	private static final long serialVersionUID = 2118916057244074427L;
	
	@XmlElement(name = "TX_INFO", required = true)
	private TxInfo txInfo;
	
	public QueryPayReq() {
	}
	
	public TxInfo getTxInfo() {
		return txInfo;
	}
	public void setTxInfo(TxInfo txInfo) {
		this.txInfo = txInfo;
	}
	
	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(propOrder = { 
			"start", "starthour", "startmin", "end", "endhour", "endmin", "kind", "order", 
			"account", "dexcel", "money", "norderby", "page", "posCode", "status"})
	public static class TxInfo {
		/**
		 * 起始日期
		 */		
		@XmlElement(name = "START", required = false)
		private String start;
		/**
		 * 开始小时
		 */			
		@XmlElement(name = "STARTHOUR", required = false)
		private String starthour;
		/**
		 * 开始分钟
		 */				
		@XmlElement(name = "STARTMIN", required = false)
		private String startmin;
		/**
		 * 截止日期
		 */			
		@XmlElement(name = "END", required = false)		
		private String end;
		/**
		 * 截止日期
		 */					
		@XmlElement(name = "ENDHOUR", required = false)
		private String endhour;
		/**
		 * 结束分钟
		 */					
		@XmlElement(name = "ENDMIN", required = false)
		private String endmin;
		/**
		 * 流水类型 0:未结流水,1:已结流水
		 */			
		@XmlElement(name = "KIND", required = true)
		private String kind = "1";
		/**
		 * 订单号 按订单号查询时，时间段不起作用
		 */					
		@XmlElement(name = "ORDER", required = true)
		private String order;
		/**
		 * 结算账户号  暂不用
		 */					
		@XmlElement(name = "ACCOUNT", required = false)
		private String account;
		/**
		 * 文件类型 默认为1,1:不压缩,2.压缩成zip文件
		 */					
		@XmlElement(name = "DEXCEL", required = true)
		private String dexcel = "1";
		/**
		 * 金额  不支持以金额查询
		 */			
		@XmlElement(name = "MONEY", required = false)
		private String money;
		/**
		 * 排序  默认为1,1:交易日期,2:订单号
		 */			
		@XmlElement(name = "NORDERBY", required = true)
		private String norderby = "1";
		/**
		 * 当前页次
		 */			
		@XmlElement(name = "PAGE", required = true)
		private String page = "1";
		/**
		 * 柜台号
		 */			
		@XmlElement(name = "POS_CODE", required = false)
		private String posCode;
		/**
		 * 流水状态 0:交易失败,1:交易成功,2:待银行确认(针对未结流水查询);3:全部
		 */			
		@XmlElement(name = "STATUS", required = true)
		private String status = "3"; 
		
		public TxInfo() {
		}
		
		public String getStart() {
			return start;
		}
		public void setStart(String start) {
			this.start = start;
		}
		public String getStarthour() {
			return starthour;
		}
		public void setStarthour(String starthour) {
			this.starthour = starthour;
		}
		public String getStartmin() {
			return startmin;
		}
		public void setStartmin(String startmin) {
			this.startmin = startmin;
		}
		public String getEnd() {
			return end;
		}
		public void setEnd(String end) {
			this.end = end;
		}
		public String getEndhour() {
			return endhour;
		}
		public void setEndhour(String endhour) {
			this.endhour = endhour;
		}
		public String getEndmin() {
			return endmin;
		}
		public void setEndmin(String endmin) {
			this.endmin = endmin;
		}
		public String getKind() {
			return kind;
		}
		public void setKind(String kind) {
			this.kind = kind;
		}
		public String getOrder() {
			return order;
		}
		public void setOrder(String order) {
			this.order = order;
		}
		public String getAccount() {
			return account;
		}
		public void setAccount(String account) {
			this.account = account;
		}
		public String getDexcel() {
			return dexcel;
		}
		public void setDexcel(String dexcel) {
			this.dexcel = dexcel;
		}
		public String getMoney() {
			return money;
		}
		public void setMoney(String money) {
			this.money = money;
		}
		public String getNorderby() {
			return norderby;
		}
		public void setNorderby(String norderby) {
			this.norderby = norderby;
		}
		public String getPage() {
			return page;
		}
		public void setPage(String page) {
			this.page = page;
		}
		public String getPosCode() {
			return posCode;
		}
		public void setPosCode(String posCode) {
			this.posCode = posCode;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}	    
	}
}
