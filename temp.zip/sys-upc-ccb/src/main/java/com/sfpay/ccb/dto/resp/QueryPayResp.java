/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.dto.resp;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.commons.lang3.builder.ToStringBuilder;
import org.apache.commons.lang3.builder.ToStringStyle;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2017年9月14日
 */
@XmlRootElement(name = "TX")
@XmlAccessorType(XmlAccessType.FIELD)
public class QueryPayResp extends BaseResp {
	private static final long serialVersionUID = -3849558093169761858L;
	
	@XmlElement(name = "TX_INFO")
	private TxInfo txInfo;

	public TxInfo getTxInfo() {
		return txInfo;
	}

	public void setTxInfo(TxInfo txInfo) {
		this.txInfo = txInfo;
	}
	
	@Override
	public String toString() {
		return ToStringBuilder.reflectionToString(this, ToStringStyle.MULTI_LINE_STYLE);
	}
	
	@XmlAccessorType(XmlAccessType.FIELD)
	public static class TxInfo {
		@XmlElement(name = "CUR_PAGE", required = false)
		private String curPage;
		@XmlElement(name = "PAGE_COUNT", required = false)
		private String pageCount;
		@XmlElement(name = "NOTICE", required = false)
		private String notice;		
		@XmlElement(name = "LIST", required = false)		
		private List<TxInfoChild> list;
		
		public String getCurPage() {
			return curPage;
		}
		public void setCurPage(String curPage) {
			this.curPage = curPage;
		}
		public String getPageCount() {
			return pageCount;
		}
		public void setPageCount(String pageCount) {
			this.pageCount = pageCount;
		}
		public String getNotice() {
			return notice;
		}
		public void setNotice(String notice) {
			this.notice = notice;
		}
		public List<TxInfoChild> getList() {
			return list;
		}
		public void setList(List<TxInfoChild> list) {
			this.list = list;
		}		
	}
	@XmlAccessorType(XmlAccessType.FIELD)
	public static class TxInfoChild {	    
		@XmlElement(name = "TRAN_DATE", required = false)
		private String tranDate;
		@XmlElement(name = "ACC_DATE", required = false)
		private String accDate;
		@XmlElement(name = "ORDER", required = false)
		private String order;		
		@XmlElement(name = "ACCOUNT", required = false)
		private String account;
		@XmlElement(name = "PAYMENT_MONEY", required = false)
		private String paymentMoney;
		@XmlElement(name = "REFUND_MONEY", required = false)
		private String refundMoney;		
		@XmlElement(name = "POS_ID", required = false)
		private String posId;		
		@XmlElement(name = "REM1", required = false)
		private String rem1;		
		@XmlElement(name = "REM2", required = false)
		private String rem2;		
		@XmlElement(name = "ORDER_STATUS", required = false)
		private String orderStatus;		
		
		public TxInfoChild() {
		}

		public String getTranDate() {
			return tranDate;
		}

		public void setTranDate(String tranDate) {
			this.tranDate = tranDate;
		}

		public String getAccDate() {
			return accDate;
		}

		public void setAccDate(String accDate) {
			this.accDate = accDate;
		}

		public String getOrder() {
			return order;
		}

		public void setOrder(String order) {
			this.order = order;
		}

		public String getAccount() {
			return account;
		}

		public void setAccount(String account) {
			this.account = account;
		}

		public String getPaymentMoney() {
			return paymentMoney;
		}

		public void setPaymentMoney(String paymentMoney) {
			this.paymentMoney = paymentMoney;
		}

		public String getRefundMoney() {
			return refundMoney;
		}

		public void setRefundMoney(String refundMoney) {
			this.refundMoney = refundMoney;
		}

		public String getPosId() {
			return posId;
		}

		public void setPosId(String posId) {
			this.posId = posId;
		}

		public String getRem1() {
			return rem1;
		}

		public void setRem1(String rem1) {
			this.rem1 = rem1;
		}

		public String getRem2() {
			return rem2;
		}

		public void setRem2(String rem2) {
			this.rem2 = rem2;
		}

		public String getOrderStatus() {
			return orderStatus;
		}

		public void setOrderStatus(String orderStatus) {
			this.orderStatus = orderStatus;
		}
	}
}
