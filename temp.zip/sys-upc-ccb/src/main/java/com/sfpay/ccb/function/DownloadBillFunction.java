/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.function;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.RandomStringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.sfpay.acquirer.helper.HttpProxyHelper;
import com.sfpay.ccb.dto.req.BaseReq;
import com.sfpay.ccb.dto.req.FileDownReq;
import com.sfpay.ccb.dto.req.FileNameReq;
import com.sfpay.ccb.dto.req.FileNameReq.TxInfo;
import com.sfpay.ccb.dto.resp.BaseResp;
import com.sfpay.ccb.dto.resp.FileDownResp;
import com.sfpay.ccb.dto.resp.FileNameResp;
import com.sfpay.ccb.util.JaxbUtils;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.base.utils.StringUtils;
import com.sfpay.front.cnst.BankCnst;
import com.sfpay.front.cnst.ChannelCnst;
import com.sfpay.front.cnst.DateCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.ReconCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.service.IHttpInvokeService;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 *         CreateDate: 2017年6月6日
 */
public class DownloadBillFunction {
	private static final Logger LOGGER = LoggerFactory.getLogger(DownloadBillFunction.class);
	/**
	 * 商户流水文件下载
	 */
	private static final String TX_CODE_NAME = "5W1005";
	/**
	 * 大文件下载
	 */
	private static final String TX_CODE_DOWN = "6W0111";

	public static Map<String, String> getResp(IHttpInvokeService httpInvokeService, Map<String, String> reqMap,
			Map<String, String> extMap, String logMsg) {
		extMap.putAll(reqMap);
		Map<String, String> respMap = new HashMap<String, String>();
		respMap.put(SqlCnst.RTN_CODE, "SUCCESS");
		respMap.put(SqlCnst.RTN_MSG, "成功");
		LOGGER.info("{}下载[{}]流水文件", logMsg, extMap.get(ReconCnst.FILE_DATE));
		String payFilename = downFile(httpInvokeService, reqMap, extMap);
		if (StringUtils.isEmpty(payFilename)) {
			respMap.put(SqlCnst.RTN_CODE, "FAILURE");
			respMap.put(SqlCnst.REMARK, extMap.get(SqlCnst.REMARK));
			return respMap;
		}
		extMap.put(ReconCnst.BANK_FILE_NAME, payFilename);
		LOGGER.info("{}下载[{}]流水文件[{}]成功", new String[] { logMsg, extMap.get(ReconCnst.FILE_DATE), payFilename });

		try {
			String respMsg = HttpProxyHelper.sendByPost(extMap.get(BankCnst.ACTUAL_NETWORK_URL), JSON.toJSONString(extMap));
			LOGGER.info("{}请求返回报文[{}]", logMsg, respMsg);
		} catch (Exception e) {
			LOGGER.error("{}和银行通信异常", logMsg, e);
			throw new ServiceException(RtnCodeCnst.NETWORK_EXCHANGE_EXCEPTION, "网络通迅异常");
		}
		return respMap;
	}

	private static String downFile(IHttpInvokeService httpInvokeService, Map<String, String> reqMap,
				Map<String, String> extMap) {
		String fileName = "";
		try {
			FileNameReq fileNameReq = buildFileNameReq(reqMap, extMap);
			String reqXml = JaxbUtils.convertToXml(fileNameReq, BaseReq.ENCODE, false);
			String respXml = httpInvokeService.sendAndReceiveForTrade(ChannelCnst.CHANNEL_CCB, reqXml, extMap);
			FileNameResp fileNameResp = JaxbUtils.convertToJavaBean(respXml, FileNameResp.class);
			if (!BaseResp.SUCCESS.equals(fileNameResp.getReturnCode())
					|| StringUtils.isEmpty(fileNameResp.getTxInfo().getFileName())) {
				extMap.put(SqlCnst.REMARK, "fileNameErr:" + fileNameResp.getReturnMsg());
				return "";
			}
			fileName = fileNameResp.getTxInfo().getFileName();
			FileDownReq fileDownReq = buildFileDownReq(reqMap, extMap);
			fileDownReq.getTxInfo().setSource(fileName);
			reqXml = JaxbUtils.convertToXml(fileDownReq, BaseReq.ENCODE, false);
			respXml = httpInvokeService.sendAndReceiveForTrade(ChannelCnst.CHANNEL_CCB, reqXml, extMap);
			FileDownResp fileDownResp = JaxbUtils.convertToJavaBean(respXml, FileDownResp.class);
			if (!BaseResp.SUCCESS.equals(fileDownResp.getReturnCode())) {
				extMap.put(SqlCnst.REMARK, "fileDownErr:" + fileDownResp.getReturnMsg());
				fileName = "";
			}
		} catch (Exception e) {
			fileName = "";
			extMap.put(SqlCnst.REMARK, "fileOtherErr:" + e.getMessage());
			LOGGER.error("建行文件下载异常", e);
		}
		return fileName;
	}

	private static FileNameReq buildFileNameReq(Map<String, String> reqMap, Map<String, String> extMap) {
		FileNameReq req = new FileNameReq();
		req.setRequestSn(
				new SimpleDateFormat(DateCnst.YYYYMMDDHHMMSS).format(new Date()) + RandomStringUtils.randomNumeric(2));
		req.setCustId(extMap.get(MapCnst.APP_ID));
		req.setPassword(extMap.get(BaseReq.PASSWORD));
		req.setUserId(extMap.get(BaseReq.USER_ID));
		req.setTxCode(TX_CODE_NAME);
		TxInfo txInfo = new FileNameReq.TxInfo();
		txInfo.setDate(extMap.get(ReconCnst.FILE_DATE));
		req.setTxInfo(txInfo);
		return req;
	}

	private static FileDownReq buildFileDownReq(Map<String, String> reqMap, Map<String, String> extMap) {
		FileDownReq req = new FileDownReq();
		req.setRequestSn(
				new SimpleDateFormat(DateCnst.YYYYMMDDHHMMSS).format(new Date()) + RandomStringUtils.randomNumeric(2));
		req.setCustId(extMap.get(MapCnst.APP_ID));
		req.setPassword(extMap.get(BaseReq.PASSWORD));
		req.setUserId(extMap.get(BaseReq.USER_ID));
		req.setTxCode(TX_CODE_DOWN);
		com.sfpay.ccb.dto.req.FileDownReq.TxInfo txInfo = new FileDownReq.TxInfo();
		req.setTxInfo(txInfo);
		return req;
	}

}
