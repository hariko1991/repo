/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.dto.req;


/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月1日
 */
public class PublicPayReq extends Req {
	private static final long serialVersionUID = -1789908350065336641L;

	/**
	 * MERCHANTID CHAR(15)	Y	由建行统一分配
	 */
	private String merchantId;

	/**
	 * 商户柜台代码	CHAR(9)	Y	由建行统一分配，
	 */
	private String posId;
	/**
	 * 分行代码	CHAR(9)	Y	由建行统一指定
	 */
	private String branchId;
	/**
	 * 定单号	CHAR(30)	Y	由商户提供，最长30位
	 */
	private String orderId;
	/**
	 * 支付渠道	channel	是	String(24)	支付使用的第三方支付渠道	见附件“支付渠道”
	 */
	private String payment;
	/**
	 * 币种	CHAR(2)	Y	缺省为01－人民币（只支持人民币支付）
	 */
	private String curCode = "01";
	/**
	 * 备注1	CHAR(30)	N	网银不处理，直接传到城综网		
	 */
	private String remark1 = "";
	/**
	 * 备注2	CHAR(30)	N	网银不处理，直接传到城综网
	 */
	private String remark2 = "";
	/**
	 * 交易码	CHAR(6)	Y	由建行统一分配为520100
	 */
	private String txCode;
	/**
	 * MAC校验域	CHAR(32)	Y	采用标准MD5算法，由商户实现
	 */
	private String mac;
	/**
	 * 接口类型	CHAR(1)	Y	1- 防钓鱼接口
	 */
	private String type = "1";
	/**
	 * 公钥后30位	CHAR(30)	Y	仅作为源串参加MD5摘要，不作为参数传递
	 */
	private String pub;
	/**
	 * 网关类型	VARCHAR(100)	Y	详见下方的GATEWAY设置说明
	 */
	private String gateway;
	/**
	 * 客户端IP	CHAR(40)	N	客户在商户系统中的IP
	 */
	private String clientIp;
	/**
	 * 客户注册信息 CHAR(256)	N	客户在商户系统中注册的信息，中文需使用escape编码
	 */
	private String regInfo;
	/**
	 * 需要url编码
	 * 商品信息	CHAR(256)	N	客户购买的商品 中文需使用escape编码
	 */
	private String proInfo;
	/**
	 * 需要url编码
	 * 商户URL	CHAR(100)	N	商户送空值即可，银行从后台读取商户设置的一级域名，如www.ccb.com则设为：
	 *  “ccb.com”，最多允许设置三个不同的域名，格式为：****.com| ****.com.cn|****.net）
	 */
	private String referer = "";
	/**
	 * 订单超时时间	CHAR(14)	N	格式： YYYYMMDDHHMMSS如：20120214143005
     *                               银行系统时间> TIMEOUT时拒绝交易，若送空值则不判断超时。
     *                               当该字段有值时参与MAC校验，否则不参与MAC校验。
	 */
	private String timeout;

	public String getMerchantId() {
		return merchantId;
	}


	public void setMerchantId(String merchantId) {
		this.merchantId = merchantId;
	}


	public String getPosId() {
		return posId;
	}


	public void setPosId(String posId) {
		this.posId = posId;
	}


	public String getBranchId() {
		return branchId;
	}


	public void setBranchId(String branchId) {
		this.branchId = branchId;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public String getPayment() {
		return payment;
	}


	public void setPayment(String payment) {
		this.payment = payment;
	}


	public String getCurCode() {
		return curCode;
	}


	public void setCurCode(String curCode) {
		this.curCode = curCode;
	}


	public String getRemark1() {
		return remark1;
	}


	public void setRemark1(String remark1) {
		this.remark1 = remark1;
	}


	public String getRemark2() {
		return remark2;
	}


	public void setRemark2(String remark2) {
		this.remark2 = remark2;
	}


	public String getTxCode() {
		return txCode;
	}


	public void setTxCode(String txCode) {
		this.txCode = txCode;
	}


	public String getMac() {
		return mac;
	}


	public void setMac(String mac) {
		this.mac = mac;
	}


	public String getType() {
		return type;
	}


	public void setType(String type) {
		this.type = type;
	}


	public String getPub() {
		return pub;
	}


	public void setPub(String pub) {
		this.pub = pub;
	}


	public String getGateway() {
		return gateway;
	}


	public void setGateway(String gateway) {
		this.gateway = gateway;
	}


	public String getClientIp() {
		return clientIp;
	}


	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}


	public String getRegInfo() {
		return regInfo;
	}


	public void setRegInfo(String regInfo) {
		this.regInfo = regInfo;
	}


	public String getProInfo() {
		return proInfo;
	}


	public void setProInfo(String proInfo) {
		this.proInfo = proInfo;
	}


	public String getReferer() {
		return referer;
	}


	public void setReferer(String referer) {
		this.referer = referer;
	}


	public String getTimeout() {
		return timeout;
	}


	public void setTimeout(String timeout) {
		this.timeout = timeout;
	}


	public String getOldMac(){
		StringBuilder sb = new StringBuilder();
		sb.append("MERCHANTID=").append(this.getMerchantId())
		.append("&POSID=").append(this.getPosId())
		.append("&BRANCHID=").append(this.getBranchId())
		.append("&ORDERID=").append(this.getOrderId())
		.append("&PAYMENT=").append(this.getPayment())
		.append("&CURCODE=").append(this.getCurCode())
		.append("&TXCODE=").append(this.getTxCode())
		.append("&REMARK1=").append(this.getRemark1())
		.append("&REMARK2=").append(this.getRemark2())
		.append("&TYPE=").append(this.getType())
		.append("&PUB=").append(this.getPub())
		.append("&GATEWAY=").append(this.getGateway())
		.append("&CLIENTIP=").append(this.getClientIp())
		.append("&REGINFO=").append(this.getRegInfo())
		.append("&PROINFO=").append(this.getProInfo())
		.append("&REFERER=").append(this.getReferer());
		return sb.toString();
	}
}
