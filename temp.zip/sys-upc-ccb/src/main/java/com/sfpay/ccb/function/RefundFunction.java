/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.function;

import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.ccb.dto.req.BaseReq;
import com.sfpay.ccb.dto.req.RefundReq;
import com.sfpay.ccb.dto.req.RefundReq.TxInfo;
import com.sfpay.ccb.dto.resp.RefundResp;
import com.sfpay.ccb.util.JaxbUtils;
import com.sfpay.ccb.util.ReqArgValidationUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.ChannelCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.service.IHttpInvokeService;
import com.sfpay.front.util.CurrencyUtil;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 * CreateDate: 2017年9月11日
 */
/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 *         CreateDate: 2017年6月2日
 */
public class RefundFunction {
	private static final String TX_CODE = "5W1004";
	private static final Logger LOGGER = LoggerFactory.getLogger(RefundFunction.class);
	private static final String[] REFUND_KEY_ARRAY = new String[] { MapCnst.REQ_ORDER_NO, MapCnst.OLD_REQ_ORDER_NO,
			MapCnst.REFUND_AMT, MapCnst.PAY_CODE };
	private static final List<String> REFUND_KEY_LIST = Arrays.asList(REFUND_KEY_ARRAY);

	public static Map<String, String> getResp(IHttpInvokeService httpInvokeService, Map<String, String> reqMap,
			Map<String, String> extMap, String logMsg) {

		Map<String, String> respMap = new HashMap<String, String>();
		if (ReqArgValidationUtil.validationArg(reqMap, REFUND_KEY_LIST)) {
			LOGGER.info("{}校验通过,参数没有问题", logMsg);
		}

		String reqMsg = "";
		try {
			reqMsg = buildReqMsg(reqMap, extMap);
			LOGGER.info("{}组装请求参数xml格式[{}]", logMsg, reqMsg);
		} catch (Exception e) {
			LOGGER.error("{}组装请求参数xml异常", logMsg, e);
			throw new ServiceException(RtnCodeCnst.ILLEGAL_REQ, "参数异常");
		}

		String respXml = null;
		try {
			respXml = httpInvokeService.sendAndReceiveForTrade(ChannelCnst.CHANNEL_CCB, reqMsg, extMap);
			LOGGER.info("{}请求返回报文[{}]", logMsg, respXml);
		} catch (Exception e) {
			LOGGER.error("{}和银行通信异常", logMsg, e);
			throw new ServiceException(RtnCodeCnst.NETWORK_EXCHANGE_EXCEPTION, "网络通迅异常");
		}
		
		
		RefundResp resp = null;
		try {
			resp = JaxbUtils.convertToJavaBean(respXml, RefundResp.class);
		} catch (Exception e) {
			LOGGER.error("{}响应报文解析失败", logMsg, e);
			throw new ServiceException(RtnCodeCnst.NETWORK_EXCHANGE_EXCEPTION, "响应报文解析失败");
		}
		respMap.put(SqlCnst.RTN_CODE, resp.getReturnCode());
		if ("000000".equals(resp.getReturnCode())) {
			respMap.put(SqlCnst.RTN_MSG, "退款成功");
			respMap.put(SqlCnst.TARGET_STATUS, StatusCnst.REFUND_SUCC);//全部认为受理成功，后续由轮询查询退款结果
		}else{
			respMap.put(SqlCnst.RTN_MSG, "退款已受理");
			respMap.put(SqlCnst.TARGET_STATUS, StatusCnst.REFUND_PROC);//全部认为受理成功，后续由轮询查询退款结果
		}
		respMap.put(SqlCnst.STATUS, respMap.get(SqlCnst.TARGET_STATUS));//全部认为受理成功，后续由轮询查询退款结果
		respMap.put(SqlCnst.RTN_ORDER_NO, reqMap.get(MapCnst.REQ_ORDER_NO));
		respMap.put(SqlCnst.CHANNEL_NO, reqMap.get(MapCnst.REQ_ORDER_NO));
		return respMap;
	}

	private static String buildReqMsg(Map<String, String> reqMap, Map<String, String> extMap) throws Exception {
		RefundReq req = new RefundReq();
		req.setRequestSn(reqMap.get(MapCnst.REQ_ORDER_NO));
		req.setCustId(extMap.get(MapCnst.APP_ID));
		req.setPassword(extMap.get(BaseReq.PASSWORD));
		req.setUserId(extMap.get(BaseReq.USER_ID));
		req.setTxCode(TX_CODE);
		TxInfo txInfo = new RefundReq.TxInfo();
		txInfo.setMoney(CurrencyUtil.fen2Yuan(Long.valueOf(reqMap.get(MapCnst.REFUND_AMT))));
		txInfo.setOrder(reqMap.get(MapCnst.OLD_REQ_ORDER_NO));
		txInfo.setRefundCode(reqMap.get(MapCnst.REQ_ORDER_NO));
		req.setTxInfo(txInfo);
		String reqXml = JaxbUtils.convertToXml(req, BaseReq.ENCODE, false);
		return reqXml;
	}
}
