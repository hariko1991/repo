/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.dto.req;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2017年9月8日
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "requestSn", "custId", "userId", "password", "txCode", "language"})
public abstract class BaseReq implements Serializable {

	private static final long serialVersionUID = -6115906064587307065L;

	/**
	 * 报文编码
	 */
	public static final String ENCODE = "GB2312";
	/**
	 * (银行参数关键字)PASSWORD 密码 varChar(32) F 操作员密码
	 */
	public static final String PASSWORD = "password";
	/**
	 *
	 * (银行参数关键字)USER_ID 操作员号 varChar(6) F 20051210后必须使用
	 */
	public static final String USER_ID = "userId";

	/**
	 * 2 CUST_ID 商户号 varChar(21) F 字符型char，网银商户号
	 */
	@XmlElement(name = "CUST_ID", required = true)
	private String custId;

	/**
	 * 6 LANGUAGE 语言 varChar(2) F CN
	 */
	@XmlElement(name = "LANGUAGE", required = true)
	private String language = "CN";

	/**
	 * 4 PASSWORD 密码 varChar(32) F 操作员密码
	 */
	@XmlElement(name = "PASSWORD", required = true)
	private String password;

	/**
	 * 1 REQUEST_SN 请求序列号 varChar(16) F 只可以使用数字
	 */
	@XmlElement(name = "REQUEST_SN", required = true)
	private String requestSn;

	/**
	 * 5 TX_CODE 交易码 varChar(6) F 交易请求码
	 */
	@XmlElement(name = "TX_CODE", required = true)
	private String txCode;

	/**
	 * 3 USER_ID 操作员号 varChar(6) F 20051210后必须使用
	 */
	@XmlElement(name = "USER_ID", required = true)
	private String userId;

	public String getCustId() {
		return custId;
	}

	public String getLanguage() {
		return language;
	}

	public String getPassword() {
		return password;
	}

	public String getRequestSn() {
		return requestSn;
	}

	public String getTxCode() {
		return txCode;
	}

	public String getUserId() {
		return userId;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public void setRequestSn(String requestSn) {
		this.requestSn = requestSn;
	}

	public void setTxCode(String txCode) {
		this.txCode = txCode;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

}
