/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.dto.req;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * 类说明：<br>
 * 商户单笔退款交易DTO
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2017年9月8日
 */
@XmlRootElement(name = "TX")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "txInfo" })
public class RefundStatusReq extends BaseReq {

	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(propOrder = { "kind", "order", "dexcel", "norderby", "page", "status" })
	public static class TxInfo {

		/**
		 * 16 DEXCEL 文件类型 Char(1) F 默认为“1”，其中：1:不压缩,2.压缩成zip文件
		 */
		@XmlElement(name = "DEXCEL", required = true)
		private String dexcel = "1";
		/**
		 * 13 KIND 流水类型 Char(1) F 0:未结流水,1:已结流水
		 */
		@XmlElement(name = "KIND", required = true)
		private String kind = "1";
		/**
		 * 18 NORDERBY 排序 Char(1) F 1:交易日期,2:订单号
		 */
		@XmlElement(name = "NORDERBY", required = true)
		private String norderby = "2";
		/**
		 * 14 ORDER 定单号 varChar(30) F 按订单号查询时，时间段不起作用
		 */
		@XmlElement(name = "ORDER", required = true)
		private String order;
		/**
		 * 19 PAGE 当前页次 Int F
		 */
		@XmlElement(name = "PAGE", required = true)
		private String page = "1";
		/**
		 * 21 STATUS 流水状态 Char(1) F 0:交易失败,1:交易成功,2:待银行确认(针对未结流水查询);3:全部
		 */
		@XmlElement(name = "STATUS", required = true)
		private String status = "3";

		public String getDexcel() {
			return dexcel;
		}

		public String getKind() {
			return kind;
		}

		public String getNorderby() {
			return norderby;
		}

		public String getOrder() {
			return order;
		}

		public String getPage() {
			return page;
		}

		public String getStatus() {
			return status;
		}

		public void setDexcel(String dexcel) {
			this.dexcel = dexcel;
		}

		public void setKind(String kind) {
			this.kind = kind;
		}

		public void setNorderby(String norderby) {
			this.norderby = norderby;
		}

		public void setOrder(String order) {
			this.order = order;
		}

		public void setPage(String page) {
			this.page = page;
		}

		public void setStatus(String status) {
			this.status = status;
		}

	}

	private static final long serialVersionUID = -3376217537747069840L;

	@XmlElement(name = "TX_INFO", required = true)
	private TxInfo txInfo;

	public TxInfo getTxInfo() {
		return txInfo;
	}

	public void setTxInfo(TxInfo txInfo) {
		this.txInfo = txInfo;
	}

}
