/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.function;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sfpay.ccb.cnst.PublicPayCnst;
import com.sfpay.ccb.dto.req.PublicPayReq;
import com.sfpay.ccb.util.SignUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.service.IHttpInvokeService;
import com.sfpay.front.util.CurrencyUtil;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年7月26日
 */
public class PublicPayFunction {
	private static final Logger LOGGER = LoggerFactory.getLogger(PublicPayFunction.class);

	public static Map<String, String> getResp(
			IHttpInvokeService httpInvokeService, Map<String, String> reqMap,
			Map<String, String> extMap, String logMsg) {
		Map<String, String> respMap = new HashMap<String, String>();
		String payJson = "";
		try {
			payJson = buildPayJson(reqMap, extMap);
			LOGGER.info("{}组装请求参数json格式[{}]", logMsg, payJson);
		} catch (Exception e) {
			LOGGER.error("{}组装请求参数json加密串为异常", logMsg, e);
			throw new ServiceException(RtnCodeCnst.SIGN_FAIL, "签名异常");
		}

		respMap.put(SqlCnst.RTN_CODE, "0");
		respMap.put(SqlCnst.RTN_MSG, "生成订单成功");
		respMap.put(SqlCnst.TARGET_STATUS, StatusCnst.TRADING);
		respMap.put(MapCnst.PAY_JSON, payJson);
		respMap.put(SqlCnst.STATUS, respMap.get(SqlCnst.TARGET_STATUS));
		return respMap;
	}

	private static String buildPayJson(Map<String, String> reqMap, Map<String, String> extMap) throws Exception {
		PublicPayReq payReq = new PublicPayReq();
		payReq.setMerchantId(extMap.get(MapCnst.APP_ID));
		payReq.setPosId(extMap.get(MapCnst.POS_ID));
		payReq.setBranchId(extMap.get(MapCnst.BRANCH_ID));
		payReq.setOrderId(reqMap.get(MapCnst.REQ_ORDER_NO));
		payReq.setPayment(CurrencyUtil.fen2Yuan(Long.valueOf(reqMap.get(MapCnst.SRC_AMT))));
//		payReq.setCurCode(reqMap.get(MapCnst.REQ_ORDER_NO));
		payReq.setTxCode("520100");
//		payReq.setRemark1("");
//		payReq.setRemark2("");
		payReq.setType("1");
		payReq.setPub(getPub(extMap));
		payReq.setGateway("");
//		payReq.setClientIp(reqMap.get(PublicPayCnst.SPBILLCREATEIP));
		payReq.setClientIp("");
		if(StringUtils.isNotBlank(reqMap.get(PublicPayCnst.DESC))){
			payReq.setRegInfo(URLEncoder.encode(reqMap.get(PublicPayCnst.DESC), "UTF-8"));
		}else{
			payReq.setRegInfo("");
		}
//		if(StringUtils.isNotBlank(reqMap.get(PublicPayCnst.SUBJECT))){
//			payReq.setProInfo(URLEncoder.encode(reqMap.get(PublicPayCnst.SUBJECT), "UTF-8"));
//		}else{
			payReq.setProInfo("");
//		}
		//payReq.setReferer(extMap.get(MapCnst.NOTIFY_URL) + RESULT_NOTIFY);
		payReq.setMac(SignUtil.getMD5(payReq.getOldMac().getBytes("UTF-8")));
		String rtnJson = JSON.toJSONString(payReq);
		LOGGER.info("建行龙支付，签名前的参数：[{}]", rtnJson);
		@SuppressWarnings("unchecked")
		Map<String, String> data = (Map<String, String>)JSON.parse(rtnJson);
		Map<String, String> dataTmp = new HashMap<String, String>();
		for (Map.Entry<String, String> dataStr : data.entrySet()) {
			if(!"OLDMAC".equals(dataStr.getKey().toUpperCase())){
				dataTmp.put(dataStr.getKey().toUpperCase(), dataStr.getValue());
			}
		}
		return JSONObject.toJSONString(dataTmp);
	}
	
	private static String getPub(Map<String, String> extMap){
		String pub = extMap.get(MapCnst.MCH_PUBLIC_KEY);
		if(pub != null && pub.length() > 30){
			pub = pub.substring((pub.length() - 30));
		}
		return pub;
	}

}
