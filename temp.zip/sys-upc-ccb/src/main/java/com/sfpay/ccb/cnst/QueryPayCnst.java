/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.cnst;

import java.util.Arrays;
import java.util.List;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01107265
 * 
 * CreateDate: 2017年09月14日
 */
public final class QueryPayCnst {
	///////////////////// 交易成功/////////////////////////////
	public static final String SUCCESS = "000000";
	
	/////////////////// 订单状态：失败/////////////////////////////
	public static final String ORDER_FAILURE = "0";
	/////////////////// 订单状态：成功/////////////////////////////	
	public static final String ORDER_SUCCESS = "1";	
	/////////////////// 订单状态：待银行确认/////////////////////////////	
	public static final String ORDER_AWAIT_CFM1 = "2";	
	/////////////////// 订单状态：已部分退款/////////////////////////////
	public static final String ORDER_PART_REFUND = "3";	
	/////////////////// 订单状态：已全额退款/////////////////////////////	
	public static final String ORDER_ALL_REFUND = "4";	
	/////////////////// 订单状态：待银行确认/////////////////////////////	
	public static final String ORDER_AWAIT_CFM2 = "5";

	public static final List<String> QUERY_PAY_SUCCESS_LIST = 
			Arrays.asList(ORDER_SUCCESS, ORDER_PART_REFUND, ORDER_ALL_REFUND);
	public static final List<String> QUERY_PAY_TRADING_LIST = 
			Arrays.asList(ORDER_AWAIT_CFM1, ORDER_AWAIT_CFM2);
}
