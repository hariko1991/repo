/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.dto.req;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * 类说明：<br>
 * 商户流水文件下载DTO
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2017年9月8日
 */
@XmlRootElement(name = "TX")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "txInfo" })
public class FileDownReq extends BaseReq {

	private static final long serialVersionUID = -3376217537747069840L;

	@XmlElement(name = "TX_INFO", required = true)
	private TxInfo txInfo;

	public TxInfo getTxInfo() {
		return txInfo;
	}

	public void setTxInfo(TxInfo txInfo) {
		this.txInfo = txInfo;
	}

	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(propOrder = { "source", "filepath", "localRemote" })
	public static class TxInfo {
		/**
		 * 1 SOURCE 要下载的文件名称 varChar(128) F 要下载的文件名，如：CBB1172476199728
		 */
		@XmlElement(name = "SOURCE", required = true)
		private String source;
		/**
		 * 4 FILEPATH 文件路径 varChar(30) F 要下载文件的路径:merchant/shls,必须填该值
		 */
		@XmlElement(name = "FILEPATH", required = true)
		private String filepath = "merchant/shls";
		/**
		 * 5 LOCAL_REMOTE 下载路径标志 varChar(1) F 一般0
		 */
		@XmlElement(name = "LOCAL_REMOTE", required = true)
		private String localRemote = "0";

		public String getSource() {
			return source;
		}

		public void setSource(String source) {
			this.source = source;
		}

		public String getFilepath() {
			return filepath;
		}

		public void setFilepath(String filepath) {
			this.filepath = filepath;
		}

		public String getLocalRemote() {
			return localRemote;
		}

		public void setLocalRemote(String localRemote) {
			this.localRemote = localRemote;
		}

	}

}
