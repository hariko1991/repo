/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.dto.req;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;

/**
 * 类说明：<br>
 * 商户流水文件下载DTO
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2017年9月8日
 */
@XmlRootElement(name = "TX")
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(propOrder = { "txInfo" })
public class FileNameReq extends BaseReq {

	@XmlAccessorType(XmlAccessType.FIELD)
	@XmlType(propOrder = { "date", "kind", "filetype", "type", "norderby", "posCode", "order", "status", "billFlag" })
	public static class TxInfo {

		/**
		 * 15 BILL_FLAG 对账单标志 Char(1) F 1：新对账单,2：旧对账单
		 **/
		@XmlElement(name = "BILL_FLAG", required = true)
		private String billFlag ="1";
		/**
		 * 7 DATE 日期 varChar(8) F
		 */
		@XmlElement(name = "DATE", required = true)
		private String date;
		/**
		 * 9 FILETYPE 文件类型 Char(1) F 1：txt（默认），2：excel（一点接商户不支持excel文件格式下载）
		 */
		@XmlElement(name = "FILETYPE", required = true)
		private String filetype ="1";
		/**
		 * 8 KIND 流水状态 Char(1) F 1：已结流水（默认），0：未结流水
		 */
		@XmlElement(name = "KIND", required = true)
		private String kind = "1";
		/**
		 * 11 NORDERBY 排序 Char(1) T 1：交易日期；2：订单号
		 */
		@XmlElement(name = "NORDERBY", required = true)
		private String norderby ="1";
		/**
		 * 13 ORDER 订单号 varChar(30) T
		 */
		@XmlElement(name = "ORDER")
		private String order;
		/**
		 * 12 POS_CODE 柜台号 varChar(9) T 不输入为全部
		 */
		@XmlElement(name = "POS_CODE")
		private String posCode ;
		/**
		 * 14 STATUS 订单状态 Char(1) F 0：交易失败,1：交易成功,2：待银行确认(未结流水);3：全部(未结流水)
		 */
		@XmlElement(name = "STATUS", required = true)
		private String status ="1";
		/**
		 * 10 TYPE 流水类型 Char(1) F 0：支付流水；1：退款流水<br>
		 * 备注：新版本(BILL_FLAG=1)对账文件不区分流水类型，
		 */
		@XmlElement(name = "TYPE", required = true)
		private String type = "0";
		public String getBillFlag() {
			return billFlag;
		}
		public String getDate() {
			return date;
		}
		public String getFiletype() {
			return filetype;
		}
		public String getKind() {
			return kind;
		}
		public String getNorderby() {
			return norderby;
		}
		public String getOrder() {
			return order;
		}
		public String getPosCode() {
			return posCode;
		}
		public String getStatus() {
			return status;
		}
		public String getType() {
			return type;
		}
		public void setBillFlag(String billFlag) {
			this.billFlag = billFlag;
		}
		public void setDate(String date) {
			this.date = date;
		}
		public void setFiletype(String filetype) {
			this.filetype = filetype;
		}
		public void setKind(String kind) {
			this.kind = kind;
		}
		public void setNorderby(String norderby) {
			this.norderby = norderby;
		}
		public void setOrder(String order) {
			this.order = order;
		}
		public void setPosCode(String posCode) {
			this.posCode = posCode;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public void setType(String type) {
			this.type = type;
		}

	}

	private static final long serialVersionUID = -3376217537747069840L;

	@XmlElement(name = "TX_INFO", required = true)
	private TxInfo txInfo;

	public TxInfo getTxInfo() {
		return txInfo;
	}

	public void setTxInfo(TxInfo txInfo) {
		this.txInfo = txInfo;
	}

}
