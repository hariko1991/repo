/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.function;

import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.ccb.dto.req.BaseReq;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.front.cnst.BankCnst;
import com.sfpay.front.cnst.FunctionCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.function.Function;
import com.sfpay.front.service.IHttpInvokeService;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01107265 Simon.Shu
 * 
 *         CreateDate: 2017年9月14日
 */
@Service("ccbFunction")
public class CcbFunction extends Function {
	private static final String CCB_ACTUAL_NETWORK_URL = "CCB_ACTUAL_NETWORK_URL";

	private static final String CCB_URL = "CCB_URL";

	private static final String CCB_PASSWORD = "CCB_PASSWORD";

	private static final String CCB_USER_ID = "CCB_USER_ID";

	private static final Logger LOGGER = LoggerFactory.getLogger(CcbFunction.class);

	@Resource
	private IHttpInvokeService httpInvokeService;

	public Map<String, String> getResp(String uqNo, String function, Map<String, String> reqMap,
			Map<String, String> extMap) {
		String logMsg = String.format("建设银行龙支付唯一编号[%s],功能[%s]", uqNo, function);
		extMap.put(BaseReq.USER_ID, Property.getProperty(CCB_USER_ID));
		extMap.put(BaseReq.PASSWORD, Property.getProperty(CCB_PASSWORD));
		extMap.put(BankCnst.NETWORK_URL, Property.getProperty(CCB_URL));
		extMap.put(BankCnst.ACTUAL_NETWORK_URL, Property.getProperty(CCB_ACTUAL_NETWORK_URL));
		LOGGER.info("{}开始处理,请求[{}],扩展参数[{}]", new Object[] { logMsg, reqMap, extMap });
		if (FunctionCnst.JSPRECREATE_FUNCTION.equals(function)) {
			return PublicPayFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else if (FunctionCnst.QUERY_FUNCTION.equals(function)) {
			return QueryFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else if (FunctionCnst.REFUND_FUNCTION.equals(function)) {
			return RefundFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else if (FunctionCnst.DOWNLOAD_BILL_FUNCTION.equals(function)) {
			return DownloadBillFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else if (FunctionCnst.REFUND_QUERY_FUNCTION.equals(function)) {
			return RefundQueryFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else if (FunctionCnst.NOTIFY_VALIDATE_SIGN.equals(function)) {
			return ValidateSignFunction.validateSign(reqMap, extMap, logMsg);
		} else if (FunctionCnst.ADD_MERCHANT_FUNCTION.equals(function)) {
			return AddMerchantFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else if (FunctionCnst.UPDATE_MERCHANT_FUNCTION.equals(function)) {
			return UpdateMerchantFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else if (FunctionCnst.GET_MERCHANT_DETAIL_FUNCTION.equals(function)) {
			return GetMerchantDetailFunction.getResp(httpInvokeService, reqMap, extMap, logMsg);
		} else {
			throw new ServiceException(RtnCodeCnst.NOT_SUPPORT_FUNCTION, "不支持功能" + function);
		}

	}
}
