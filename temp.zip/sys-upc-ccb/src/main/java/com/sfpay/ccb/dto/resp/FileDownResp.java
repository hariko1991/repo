/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.dto.resp;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2017年9月14日
 */
@XmlRootElement(name = "TX")
@XmlAccessorType(XmlAccessType.FIELD)
public class FileDownResp extends BaseResp {
	

	private static final long serialVersionUID = -8576058079853792732L;

}
