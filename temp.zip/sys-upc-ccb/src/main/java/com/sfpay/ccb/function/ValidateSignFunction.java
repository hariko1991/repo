/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.function;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.alibaba.fastjson.JSONObject;
import com.sfpay.ccb.util.MCipherDecode;
import com.sfpay.ccb.util.SignUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月2日
 */
public class ValidateSignFunction {
	
	private static final Logger LOGGER = LoggerFactory.getLogger(ValidateSignFunction.class);
	
	public static Map<String, String> validateSign(Map<String, String> reqMap,
			Map<String, String> extMap, String logMsg) {
		LOGGER.info("{}组装请求参数json格式[{}]", logMsg, reqMap);
		
		Map<String, String> respMap = new HashMap<String, String>();
		try {
			String reqOrderNo = reqMap.get(MapCnst.REQ_ORDER_NO);
			String data = reqMap.get(MapCnst.NOTIFY_DATA);
			String signStr = reqMap.get(MapCnst.NOTIFY_SIGN);
			JSONObject dataObj = JSONObject.parseObject(data);
			String sign = dataObj.getString("sIGN");
			
			if(isPass(sign, signStr, extMap.get(MapCnst.MCH_PUBLIC_KEY))){
				String tradeStatus = dataObj.getString("sUCCESS");
				if("Y".equals(tradeStatus)){
					respMap.put(SqlCnst.TARGET_STATUS, StatusCnst.SUCCESS);
					respMap.put(SqlCnst.RTN_CODE, "000000");
					respMap.put(SqlCnst.RTN_MSG, "支付成功");
//					if(StringUtils.isNotBlank(dataObj.getString("dISCOUNT"))){
//						respMap.put(SqlCnst.EXT_TAB_DISCOUNT, (Float.parseFloat(dataObj.getString("dISCOUNT")) * 100) + "");
//					}
					respMap.put(SqlCnst.EXT_TAB_PAYMESSAGE, data);
					dualUsrMsg(dataObj.getString("uSRMSG") , extMap.get(MapCnst.MCH_PUBLIC_KEY) , respMap , logMsg);
				}else{
					respMap.put(SqlCnst.TARGET_STATUS, StatusCnst.TRADING);
				}
				respMap.put(SqlCnst.CHANNEL_NO, reqOrderNo);
				respMap.put(SqlCnst.RTN_ORDER_NO, reqOrderNo);
				return respMap;
			}else{
				throw new ServiceException(RtnCodeCnst.SIGN_NOT_PASS, "验证签名不通过");
			}
		} catch (Exception e) {
			LOGGER.error("{}组装请求参数json加密串为异常", logMsg, e);
		}
		return null;
	}
	
	private static boolean isPass(String sign, String signSrc,
			String pubKey) {
		LOGGER.info("建行支付,支付通知验证签名,pubKey:[{}]", pubKey);
		try {
			return  SignUtil.sign(signSrc, sign, pubKey);
		} catch (Exception e) {
			throw new ServiceException(RtnCodeCnst.SIGN_NOT_PASS, "验证签名不通过");
		}
	}
	
	private static void dualUsrMsg(String usrMsg , String pubKey , Map<String, String> respMap, String logMsg){
		try{
			if(StringUtils.isNotBlank(usrMsg)){
				if(pubKey != null && pubKey.length() > 30){
					pubKey = pubKey.substring((pubKey.length() - 30));
				}
				MCipherDecode mcd = new MCipherDecode(pubKey);//设置密钥
				String decodedString = mcd.getDecodeString(usrMsg);//解密
				byte[] tempByte = decodedString.getBytes("ISO-8859-1"); 
				usrMsg = new String(tempByte,"GBK"); //进行字符转码
				String [] usrMsgs = usrMsg.split("|");
				if(usrMsgs != null && usrMsgs.length >= 2){
					respMap.put(SqlCnst.EXT_TAB_BUYERID, usrMsgs[0]);
					respMap.put(SqlCnst.EXT_TAB_BUYERACCOUNT, usrMsgs[1]);
				}
			}
		}catch (Exception e) {
			LOGGER.error("{},获取支付人信息失败异常 ", logMsg, e);
		}
	}
}
