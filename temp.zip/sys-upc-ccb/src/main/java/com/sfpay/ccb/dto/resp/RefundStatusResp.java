/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.dto.resp;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2017年9月14日
 */
@XmlRootElement(name = "TX")
@XmlAccessorType(XmlAccessType.FIELD)
public class RefundStatusResp extends BaseResp {
	@XmlAccessorType(XmlAccessType.FIELD)
	public static class RefundStatus {

		/**
		 * 13 ORDER_NUMBER 订单号 varChar(30) T 　 
		 */
		@XmlElement(name = "ORDER_NUMBER")
		private String orderNumber;
		/**
		 * 15 PAY_AMOUNT 支付金额 Decimal(16,2) T 　 　 
		 */
		@XmlElement(name = "PAY_AMOUNT")
		private String payAmount;
		/**
		 * 17 POS_CODE 柜台号 varChar(9) T 　
		 */
		@XmlElement(name = "POS_CODE")
		private String posCode;
		/**
		 * 14 REFUND_ACCOUNT 退款账号 varChar(30) T T 　 
		 */
		@XmlElement(name = "REFUND_ACCOUNT")
		private String refundAccount;
		/**
		 * 9 REFUND_CODE 退款流水号 varChar(15) F CN
		 */
		@XmlElement(name = "REFUND_CODE", required = true)
		private String refundCode;
		/**
		 * 12 REFUND_DATE 退款日期 varChar(32) T 　 　 
		 */
		@XmlElement(name = "REFUND_DATE")
		private String refundDate;
		/**
		 * 16 REFUNDEMENT_AMOUNT 退款金额 Decimal(16,2) T 　
		 */
		@XmlElement(name = "REFUNDEMENT_AMOUNT")
		private String refundementAmount;
		/**
		 * 19 STATUS 订单状态 Char(1) T 0:失败,1:成功,2:待银行确认,5:待银行确认 
		 */
		@XmlElement(name = "STATUS")
		private String status;
		/**
		 * 11 TRAN_DATE 交易日期 varChar(32) T 　 
		 */
		@XmlElement(name = "TRAN_DATE")
		private String tranDate;
		
		/**
		 * 18 USERID 操作员 varChar(21) T 　 
		 */
		@XmlElement(name = "USERID")
		private String userid;
		public String getOrderNumber() {
			return orderNumber;
		}
		public String getPayAmount() {
			return payAmount;
		}
		public String getPosCode() {
			return posCode;
		}
		public String getRefundAccount() {
			return refundAccount;
		}
		public String getRefundCode() {
			return refundCode;
		}
		public String getRefundDate() {
			return refundDate;
		}
		public String getRefundementAmount() {
			return refundementAmount;
		}
		public String getStatus() {
			return status;
		}
		public String getTranDate() {
			return tranDate;
		}
		public String getUserid() {
			return userid;
		}
		public void setOrderNumber(String orderNumber) {
			this.orderNumber = orderNumber;
		}
		public void setPayAmount(String payAmount) {
			this.payAmount = payAmount;
		}
		public void setPosCode(String posCode) {
			this.posCode = posCode;
		}
		public void setRefundAccount(String refundAccount) {
			this.refundAccount = refundAccount;
		}
		public void setRefundCode(String refundCode) {
			this.refundCode = refundCode;
		}
		public void setRefundDate(String refundDate) {
			this.refundDate = refundDate;
		}
		public void setRefundementAmount(String refundementAmount) {
			this.refundementAmount = refundementAmount;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public void setTranDate(String tranDate) {
			this.tranDate = tranDate;
		}
		public void setUserid(String userid) {
			this.userid = userid;
		}

	}
	
	@XmlAccessorType(XmlAccessType.FIELD)
	public static class TxInfo {
		/**
		 * 9 CUR_PAG 当前页次 Int T 　 　 
		 */
		@XmlElement(name = "CUR_PAG")
		private String curPag;
		@XmlElement(name = "LIST")
		private List<RefundStatus> list;
		/**
		 * 10 NOTICE 提示 varChar(200) T 提示信息  T 　 　 
		 */
		@XmlElement(name = "NOTICE")
		private String notice;
		/**
		 * 8 TPAGE 总页次 Int T 　 
		 */
		@XmlElement(name = "TPAGE")
		private String tpage;
		public String getCurPag() {
			return curPag;
		}
		public List<RefundStatus> getList() {
			return list;
		}
		public String getNotice() {
			return notice;
		}
		public String getTpage() {
			return tpage;
		}
		public void setCurPag(String curPag) {
			this.curPag = curPag;
		}
		public void setList(List<RefundStatus> list) {
			this.list = list;
		}
		public void setNotice(String notice) {
			this.notice = notice;
		}
		public void setTpage(String tpage) {
			this.tpage = tpage;
		}
	}

	private static final long serialVersionUID = -8576058079853792732L;
	@XmlElement(name = "TX_INFO")
	private TxInfo txInfo;

	public TxInfo getTxInfo() {
		return txInfo;
	}

	public void setTxInfo(TxInfo txInfo) {
		this.txInfo = txInfo;
	}

}
