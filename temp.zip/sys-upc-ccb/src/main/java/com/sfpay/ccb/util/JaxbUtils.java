/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.util;

import java.io.StringReader;
import java.io.StringWriter;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;
import javax.xml.transform.sax.SAXSource;

import org.apache.commons.lang3.StringUtils;
import org.dom4j.io.OutputFormat;
import org.dom4j.io.XMLWriter;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.XMLFilterImpl;
import org.xml.sax.helpers.XMLReaderFactory;

/**
 * 类说明：<br>
 * Jaxb2工具类
 * 
 * <p>
 * 详细描述：<br>
 * Jaxb2工具类
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2015-11-6
 * modifyDate: 2016-09-28
 */
@SuppressWarnings("unchecked")
public final class JaxbUtils {

	/**
	 * 方法说明：<br>
	 * JavaBean转换成xml          默认编码为UTF_8,不格式化,忽略头,忽略命名空间
	 * 
	 * @param obj
	 * @param ignoreNameSpace
	 * @return
	 * @throws Exception
	 */
	public static <T> String convertToXml(Object obj)
			throws Exception {
		return convertToXml(obj, "utf-8");
	}

	/**
	 * 方法说明：<br>
	 * JavaBean转换成xml          默认忽略头,不格式化,忽略命名空间
	 * 
	 * @param obj  转化的对象
	 * @param encoding 字符编码
	 * @return String 响应内容
	 */
	public static <T> String convertToXml(Object obj,
			String encoding) throws Exception {
		return convertToXml(obj, encoding, true);
	}
	
	/**
	 * 方法说明：<br>
	 * JavaBean转换成xml          默认不格式化,忽略命名空间
	 * 
	 * @param obj
	 * @param encoding
	 * @param ignoreHead
	 * @return
	 * @throws Exception
	 */
	public static <T> String convertToXml(Object obj,
			String encoding, boolean ignoreHead) throws Exception{
		return convertToXml(obj, encoding, ignoreHead, false);
	}
	
	/**
	 * 方法说明：<br>
	 * JavaBean转换成xml          默认忽略命名空间
	 * 
	 * @param obj
	 * @param encoding
	 * @param ignoreHead
	 * @param ignoreFormat
	 * @return
	 * @throws Exception
	 */
	public static <T> String convertToXml(Object obj, String encoding, boolean ignoreHead, boolean ignoreFormat)
			throws Exception {
		return convertToXml(obj, encoding, ignoreHead, ignoreFormat, true);
	}
	

	/**
	 * 
	 * 方法说明：<br>
	 * 根据指定的信息返回生成的字符串
	 * 
	 * @param obj  具体的对象
	 * @param encoding  编码方式               
	 * @param ignoreHead 是否忽略头信息       true 忽略     false 不忽略 
	 * @param ignoreFormat 是否格式化         true 格式化  false 不格式化
	 * @param ignoreNameSpace 是否忽略命名空间  false 忽略 true 不忽略
	 * @return xml xml对象
	 * @throws Exception
	 */
	public static String convertToXml(Object obj, String encoding, boolean ignoreHead, boolean ignoreFormat,
			final boolean ignoreNameSpace) throws Exception {
		if (StringUtils.isEmpty(encoding)) {
			encoding = "utf-8";
		}
		JAXBContext context = JAXBContext.newInstance(obj.getClass());
		Marshaller marshal = context.createMarshaller();
		
		StringWriter out = new StringWriter();
		OutputFormat format = new OutputFormat();
		format.setSuppressDeclaration(ignoreHead); // 是否忽略头
		format.setIndent(ignoreFormat);
		format.setNewlines(ignoreFormat);
		format.setNewLineAfterDeclaration(false);
		format.setEncoding(encoding);
		XMLWriter writer = new XMLWriter(out, format);
		writer.setEscapeText(false);

		XMLFilterImpl nsfFilter = new XMLFilterImpl() {
			private boolean ignoreNamespace = ignoreNameSpace;
			private String rootNamespace = null;
			private boolean isRootElement = true;

			@Override
			public void startDocument() throws SAXException {
				super.startDocument();
			}

			@Override
			public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
				if (this.ignoreNamespace)
					uri = "";
				if (this.isRootElement)
					this.isRootElement = false;
				else if (!uri.equals("") && !localName.contains("xmlns"))
					localName = localName + " xmlns=\"" + uri + "\"";

				super.startElement(uri, localName, localName, atts);
			}

			@Override
			public void endElement(String uri, String localName, String qName) throws SAXException {
				if (this.ignoreNamespace)
					uri = "";
				super.endElement(uri, localName, localName);
			}

			@Override
			public void startPrefixMapping(String prefix, String url) throws SAXException {
				if (this.rootNamespace != null)
					url = this.rootNamespace;
				if (!this.ignoreNamespace)
					super.startPrefixMapping("", url);
			}
		};
		nsfFilter.setContentHandler(writer);
		marshal.marshal(obj, nsfFilter);
		return out.toString();
	}

	/**
	 * xml转换成JavaBean
	 * 
	 * @param xml 转化的内容
	 * @param clazz   将内容转化该对象
	 * @param ignoreNameSpace 忽略命名空间
	 * @return T 响应内容
	 */
	public static <T> T convertToJavaBean(String xml, Class<T> clazz, final boolean ignoreNameSpace) throws Exception {
		JAXBContext context = JAXBContext.newInstance(clazz);
		Unmarshaller unmarshaller = context.createUnmarshaller();
		XMLReader reader = XMLReaderFactory.createXMLReader();
		XMLFilterImpl nsfFilter = new XMLFilterImpl() {
			private boolean ignoreNamespace = ignoreNameSpace;

			@Override
			public void startDocument() throws SAXException {
				super.startDocument();
			}

			@Override
			public void startElement(String uri, String localName, String qName, Attributes atts) throws SAXException {
				if (this.ignoreNamespace)
					uri = "";
				super.startElement(uri, localName, qName, atts);
			}

			@Override
			public void endElement(String uri, String localName, String qName) throws SAXException {
				if (this.ignoreNamespace)
					uri = "";
				super.endElement(uri, localName, localName);
			}

			@Override
			public void startPrefixMapping(String prefix, String url) throws SAXException {
				if (!this.ignoreNamespace)
					super.startPrefixMapping("", url);
			}
		};
		nsfFilter.setParent(reader);
		InputSource input = new InputSource(new StringReader(xml));
		SAXSource source = new SAXSource(nsfFilter, input);
		return (T) unmarshaller.unmarshal(source);
	}
	
	/**
	 * xml转换成JavaBean
	 * 
	 * @param xml   转化的内容
	 * @param c   将内容转化该对象
	 * @return T 响应内容
	 */
	public static <T> T convertToJavaBean(String xml, Class<T> c) throws Exception {
		T t = null;
		JAXBContext context = JAXBContext.newInstance(c);
		Unmarshaller unmarshaller = context.createUnmarshaller();
		t = (T) unmarshaller.unmarshal(new StringReader(xml));
		return t;
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据指定的信息返回生成的字符串
	 * 
	 * @param clazz 具体的class类型
	 * @param obj  具体的对象
	 * @param encoding 编码方式
	 * @param ignoreHead 是否忽略头信息 false 忽略 true 不忽略
	 * @param ignoreFormat 是否格式化 true 格式化 false 不格式化
	 * @return xml xml对象
	 * @throws Exception
	 */
	public static <T> String convertToXml(Class<T> clazz, Object obj, String encoding, boolean ignoreHead,
			boolean ignoreFormat) throws Exception {
		if (StringUtils.isEmpty(encoding)) {
			encoding = "utf-8";
		}
		JAXBContext context = JAXBContext.newInstance(clazz);
		Marshaller marshal = context.createMarshaller();
		
		marshal.setProperty(Marshaller.JAXB_ENCODING, encoding); // 设置编码格式
		marshal.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, ignoreFormat); // 是否格式化xml
		marshal.setProperty(Marshaller.JAXB_FRAGMENT, ignoreHead); // 是否忽略xml头信息
		StringWriter writer = new StringWriter();
		marshal.marshal(obj, writer);
		String xml = writer.toString();
		writer.flush();
		writer.close();
		return xml;
	}
   
}
