/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.dto.resp;

import java.io.Serializable;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2017年9月8日
 */
@XmlAccessorType(XmlAccessType.FIELD)
public abstract class BaseResp implements Serializable {

	private static final long serialVersionUID = -1596122583634883511L;
	
	public static final String SUCCESS = "000000";
	/**
	 * 2 CUST_ID 商户号 varChar(21) F 字符型char，网银商户号
	 */
	@XmlElement(name = "CUST_ID")
	private String custId;

	/**
	 * 6 LANGUAGE 语言 varChar(2) F CN
	 */
	@XmlElement(name = "LANGUAGE")
	private String language = "CN";

	/**
	 * 1 REQUEST_SN 请求序列号 varChar(16) F 只可以使用数字
	 */
	@XmlElement(name = "REQUEST_SN")
	private String requestSn;

	/**
	 * 4 RETURN_CODE 响应码 varChar(12) F 交易响应码
	 */
	@XmlElement(name = "RETURN_CODE")
	private String returnCode;
	/**
	 * 5 RETURN_MSG 响应信息 varChar(99) T 交易响应信息
	 */
	@XmlElement(name = "RETURN_MSG")
	private String returnMsg;
	/**
	 * 5 TX_CODE 交易码 varChar(6) F 交易请求码
	 */
	@XmlElement(name = "TX_CODE")
	private String txCode;

	public String getCustId() {
		return custId;
	}

	public String getLanguage() {
		return language;
	}

	public String getRequestSn() {
		return requestSn;
	}

	public String getReturnCode() {
		return returnCode;
	}

	public String getReturnMsg() {
		return returnMsg;
	}

	public String getTxCode() {
		return txCode;
	}

	public void setCustId(String custId) {
		this.custId = custId;
	}

	public void setLanguage(String language) {
		this.language = language;
	}

	public void setRequestSn(String requestSn) {
		this.requestSn = requestSn;
	}

	public void setReturnCode(String returnCode) {
		this.returnCode = returnCode;
	}

	public void setReturnMsg(String returnMsg) {
		this.returnMsg = returnMsg;
	}

	public void setTxCode(String txCode) {
		this.txCode = txCode;
	}

}
