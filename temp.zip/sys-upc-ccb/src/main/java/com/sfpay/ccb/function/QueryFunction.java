/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.ccb.function;

import java.text.DecimalFormat;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang.math.RandomUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.shiro.util.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.common.DateUtil;
import com.sfpay.acquirer.common.Encoding;
import com.sfpay.ccb.cnst.QueryPayCnst;
import com.sfpay.ccb.dto.req.BaseReq;
import com.sfpay.ccb.dto.req.QueryPayReq;
import com.sfpay.ccb.dto.req.QueryPayReq.TxInfo;
import com.sfpay.ccb.dto.resp.QueryPayResp;
import com.sfpay.ccb.dto.resp.QueryPayResp.TxInfoChild;
import com.sfpay.ccb.util.JaxbUtils;
import com.sfpay.ccb.util.ReqArgValidationUtil;
import com.sfpay.framework.base.exception.ServiceException;
import com.sfpay.front.cnst.ChannelCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.RtnCodeCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.service.IHttpInvokeService;

/**
 * 类说明：支付查询接口实现<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 支付查询接口实现
 * 
 * </p>
 * 
 * @author 01107265 Simon.Shu
 * 
 * CreateDate: 2017年9月14日
 */
public class QueryFunction {

	private static final Logger LOGGER = LoggerFactory.getLogger(QueryFunction.class);	
	private static final String[] QUERY_KEY_ARRAY = new String[] { MapCnst.REQ_ORDER_NO };
	private static final List<String> QUERY_KEY_LIST = Arrays.asList(QUERY_KEY_ARRAY);
	private static final String TX_CODE = "5W1002";
	
	public static Map<String, String> getResp(IHttpInvokeService httpInvokeService, Map<String, String> reqMap,
			Map<String, String> extMap, String logMsg) {
		if (ReqArgValidationUtil.validationArg(reqMap, QUERY_KEY_LIST)) {
			LOGGER.info("{}校验通过,参数没有问题", logMsg);
		}

		Map<String, String> respMap = new HashMap<String, String>();
		String reqMsg = "";
		try {
			reqMsg = buildReqMsg(reqMap, extMap);
			LOGGER.info("{}组装请求参数json格式[{}]", logMsg, reqMsg);
		} catch (Exception e) {
			LOGGER.error("{}组装请求参数json加密串为异常", logMsg, e);
			throw new ServiceException(RtnCodeCnst.SIGN_FAIL, "签名异常");
		}
		
		String respXml = null;
		try {
			respXml = httpInvokeService.sendAndReceiveForTrade(ChannelCnst.CHANNEL_CCB, reqMsg, extMap);
			LOGGER.info("{}请求返回报文[{}]", logMsg, respXml);
		} catch (Exception e) {
			LOGGER.error("{}和银行通信异常", logMsg, e);
			throw new ServiceException(RtnCodeCnst.NETWORK_EXCHANGE_EXCEPTION, "网络通迅异常");
		}		
		
		QueryPayResp resp = null;
		try {
			resp = JaxbUtils.convertToJavaBean(respXml, QueryPayResp.class);
		} catch (Exception e) {
			LOGGER.error("{}响应报文解析失败", logMsg, e);
			throw new ServiceException(RtnCodeCnst.NETWORK_EXCHANGE_EXCEPTION, "响应报文解析失败");
		}
		String rtnCode = "";
		String rtnMsg = "";
		if (QueryPayCnst.SUCCESS.equals(resp.getReturnCode()) ) {
			if (resp.getTxInfo() != null && !CollectionUtils.isEmpty(resp.getTxInfo().getList())) {
				TxInfoChild infoChild = resp.getTxInfo().getList().get(0);
				String status = StringUtils.trim(infoChild.getOrderStatus());
				if (QueryPayCnst.QUERY_PAY_TRADING_LIST.contains(status) ) {
					return respMap;
				}
				if (QueryPayCnst.QUERY_PAY_SUCCESS_LIST.contains(status) ) {
					respMap.put(SqlCnst.TARGET_STATUS, StatusCnst.SUCCESS);
					respMap.put(SqlCnst.RTN_ORDER_NO, infoChild.getOrder());
					respMap.put(SqlCnst.CHANNEL_NO, infoChild.getOrder());
					rtnCode = resp.getReturnCode();
					rtnMsg = StringUtils.isNotBlank(resp.getReturnMsg()) ? resp.getReturnMsg() : "支付成功,主动查询";					
				} else if (QueryPayCnst.ORDER_FAILURE.equals(status)) {
					respMap.put(SqlCnst.TARGET_STATUS, StatusCnst.FAILURE);
					LOGGER.error("{}和银行通道应答业务结果失败,响应结果{}", logMsg, resp);
					rtnCode = resp.getReturnCode();
					rtnMsg = StringUtils.isNotBlank(resp.getReturnMsg()) ? 
						resp.getReturnMsg() : String.format("支付失败,主动查询,返回状态[%s]", status);
				} else {
					LOGGER.error("{}和银行通道应答业务结果未知,响应结果{}", logMsg, resp);
					rtnCode = resp.getReturnCode();
					rtnMsg = resp.getReturnMsg();
				}
			}
		} else {
			LOGGER.error("{}和银行通道应答失败,响应结果{}", logMsg, resp);
			rtnCode = resp.getReturnCode();
			rtnMsg = resp.getReturnMsg();
		}		
		respMap.put(SqlCnst.RTN_CODE, rtnCode);
		respMap.put(SqlCnst.RTN_MSG, rtnMsg);
		return respMap;
	}

	private static String buildReqMsg(Map<String, String> reqMap, Map<String, String> extMap) throws Exception {
		QueryPayReq req = new QueryPayReq();
		req.setRequestSn(generateRequestSn());
		req.setCustId(extMap.get(MapCnst.APP_ID));
		req.setPassword(extMap.get(BaseReq.PASSWORD));
		req.setUserId(extMap.get(BaseReq.USER_ID));
		req.setTxCode(TX_CODE);		
		TxInfo txInfo = new TxInfo();
		txInfo.setOrder(reqMap.get(MapCnst.REQ_ORDER_NO));	
		req.setTxInfo(txInfo);		
		return JaxbUtils.convertToXml(req, Encoding.UTF_8, false);
	}
	
	private static String generateRequestSn() {
		return new StringBuffer()
				.append(new DecimalFormat("#0000").format(RandomUtils.nextInt(10000)))
				.append(DateUtil.getDateString(new Date(), "yyMMddHHmmss"))
				.toString();
	}
}
