/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.upc.ccb.server;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.sfpay.front.cnst.ReconCnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2017年9月18日
 */
public class ReconFileThreadTest {
	@Test
	public void reconFileThread() {
		Map<String, String> bankArg = new HashMap<String, String>();
		bankArg.put(ReconCnst.SFTP_IP, "10.118.243.108");
		bankArg.put(ReconCnst.SFTP_PORT, "20020");
		bankArg.put(ReconCnst.SFTP_PATH, "./ebank/");
		bankArg.put(ReconCnst.SFTP_USER, "ebank");
		bankArg.put(ReconCnst.SFTP_PASS, "ebank#SF0405");
		bankArg.put(ReconCnst.LOCAL_PATH,
				"D:/svn/09-sypay-branches/1043-20171010(channel)/sys-upc-front-ccb/src/test/java/com/sfpay/upc/ccb/server/");
		bankArg.put(ReconCnst.TRADE_TYPE_PAYMENT, "SHOP.105140888890234.20170110.02.success.txt");
		bankArg.put(ReconCnst.TRADE_TYPE_REFUND, "SHOP.105140888890234.20170110.04.success.txt");
		bankArg.put(ReconCnst.FILE_DATE, "20170916");

		System.out.println(JSON.toJSONString(bankArg));
		
		ReconFileThread thread = new ReconFileThread(bankArg);
		thread.run();
	}

}
