package com.sfpay.upc.ccb.server;

import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.cnst.ReconCnst;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2017年9月16日
 */
@Service("ccbReconServer")
@SuppressWarnings("rawtypes")
public class CcbReconServer extends HttpServlet {
	private static final long serialVersionUID = -3169775951665948516L;
	private static Logger LOGGER = LoggerFactory.getLogger(CcbReconServer.class);
	private Executor EVENT_EXECUTOR = Executors.newFixedThreadPool(CharCnst.NUMBER_TEN);
	private static final String ENCODING_UTF_8 = "UTF-8";

	@SuppressWarnings("unchecked")
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		boolean flag = true;
		try {

			Enumeration nameList = request.getParameterNames();
			String bangArgStr = null;
			if (nameList.hasMoreElements()) {
				bangArgStr = (String) nameList.nextElement();
				LOGGER.info("请求参数信息:[{}]", bangArgStr);
			}
			if (StringUtils.isEmpty(bangArgStr)) {
				throw new NullPointerException("请求参数为空");
			}
			Map<String, String> bankArg = JSON.parseObject(bangArgStr, HashMap.class);
			if (bankArg == null || StringUtils.isEmpty(bankArg.get(ReconCnst.SFTP_IP))
					|| StringUtils.isEmpty(bankArg.get(ReconCnst.SFTP_PORT))
					|| StringUtils.isEmpty(bankArg.get(ReconCnst.SFTP_PATH))
					|| StringUtils.isEmpty(bankArg.get(ReconCnst.SFTP_USER))
					|| StringUtils.isEmpty(bankArg.get(ReconCnst.SFTP_PASS))) {
				throw new NullPointerException("SFTP参数为空");
			}

			if (StringUtils.isEmpty(bankArg.get(ReconCnst.FILE_DATE))) {
				throw new NullPointerException("对账日期为空");
			}

			String localDir = bankArg.get(ReconCnst.LOCAL_PATH);
			if (StringUtils.isEmpty(localDir)) {
				throw new NullPointerException("本地文件目录 为空");
			}

			String bankFilename = bankArg.get(ReconCnst.BANK_FILE_NAME);
			if (StringUtils.isEmpty(bankFilename)) {
				throw new NullPointerException("流水文件名称为空");
			}

			File file = new File(localDir + bankFilename);
			if (!file.exists()) {
				throw new NullPointerException("对账文件不存在");
			}
			// }

			EVENT_EXECUTOR.execute(new ReconFileThread(bankArg));
		} catch (Exception e) {
			LOGGER.error("异常", e);
			flag = false;
		} finally {
			response.setCharacterEncoding(ENCODING_UTF_8);
			PrintWriter pw = response.getWriter();
			if (flag) {
				pw.write("接收成功");
			} else {
				pw.write("参数错误");
			}
			pw.flush();
			pw.close();
		}

	}

}
