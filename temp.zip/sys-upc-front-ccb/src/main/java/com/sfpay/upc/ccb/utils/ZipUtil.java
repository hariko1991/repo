/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.upc.ccb.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import org.apache.commons.io.FileUtils;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 *         CreateDate: 2017年7月6日
 */
public final class ZipUtil {
	private static final int BUFFER_LENGTH = 1024;

	public static List<String> unZip(String zipFileName) throws Exception {
		ZipInputStream zis = null;
		ByteArrayOutputStream baos = null;
		File unZipFile = null;
		List<String> fileList = new ArrayList<String>();
		try {
			File zipFile = new File(zipFileName);
			byte[] data = FileUtils.readFileToByteArray(zipFile);
			zis = new ZipInputStream(new ByteArrayInputStream(data));
			ZipEntry entry = null;
			while ((entry = zis.getNextEntry()) != null) {
				byte[] buf = new byte[BUFFER_LENGTH];
				int num = -1;
				baos = new ByteArrayOutputStream();
				while ((num = zis.read(buf, 0, buf.length)) != -1) {
					baos.write(buf, 0, num);
				}
				unZipFile = new File(zipFile.getParent() + File.separator + entry.getName());
				FileUtils.writeByteArrayToFile(unZipFile, baos.toByteArray());
				fileList.add(entry.getName());
				baos.flush();
				baos.close();
			}
			return fileList;
		} finally {
			zis.close();
			if (null != baos) {
				baos.close();
			}
		}
	}
}
