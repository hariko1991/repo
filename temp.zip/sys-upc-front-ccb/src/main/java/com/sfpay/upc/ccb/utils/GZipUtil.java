/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.upc.ccb.utils;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.util.zip.GZIPInputStream;

import org.apache.commons.io.FileUtils;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 *         CreateDate: 2017年7月6日
 */
public final class GZipUtil {
	private static final int BUFFER_LENGTH = 1024;

	/**
	 * 方法说明：<br>
	 * 
	 * @param gzFileName 压缩文件名称
	 * @return 解压的文件名称
	 * @throws Exception
	 */
	public static String unZip(String gzFileName) throws Exception {
		GZIPInputStream zis = null;
		ByteArrayOutputStream baos = new ByteArrayOutputStream();
		try {
			byte[] data =FileUtils.readFileToByteArray(new File(gzFileName));
			zis = new GZIPInputStream(new ByteArrayInputStream(data));
			int count;
			byte[] buf = new byte[BUFFER_LENGTH];
			while ((count = zis.read(buf, 0, BUFFER_LENGTH)) != -1) {
				baos.write(buf, 0, count);
			}
			String unGzFileName = gzFileName.substring(0, gzFileName.length()-3);
			File unGzFile = new File(unGzFileName);
			FileUtils.writeByteArrayToFile(unGzFile, baos.toByteArray());
			baos.flush();
			baos.close();
			return unGzFile.getName();
		} finally {
			zis.close();
			if (null != baos) {
				baos.close();
			}
		}
	}
	
}
