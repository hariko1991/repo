/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.upc.ccb.server;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.io.FileUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.front.cnst.ChannelCnst;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.cnst.EncodingCnst;
import com.sfpay.front.cnst.ReconCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.dto.ReconFileDetail;
import com.sfpay.front.service.IHttpReconService;
import com.sfpay.upc.ccb.utils.SFTPUtils;
import com.sfpay.upc.ccb.utils.SpringContextHolder;
import com.sfpay.upc.ccb.utils.ZipUtil;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 840162 王胜军
 * 
 *         CreateDate: 2017年9月16日
 */
public class ReconFileThread implements Runnable {
	private static Logger LOGGER = LoggerFactory.getLogger(ReconFileThread.class);
	private static final String BANK = "/bank/";
	private static final String CHANNEL_CODE = "CCB";
	private Map<String, String> bankArg;
	private IHttpReconService httpReconService;

	public ReconFileThread(Map<String, String> bankArg) {
		this.bankArg = bankArg;
		httpReconService = SpringContextHolder.getBean("httpReconService");
	}

	@Override
	public void run() {
		Map<String, String> updateMap = new HashMap<String, String>();
		updateMap.put(SqlCnst.ORIGINAL_STATUS, ReconCnst.RECON_STATUS_INIT);
		updateMap.put(ReconCnst.BILL_MCH_NO, bankArg.get(ReconCnst.BILL_MCH_NO));
		updateMap.put(ReconCnst.FILE_DATE, bankArg.get(ReconCnst.FILE_DATE));
		updateMap.put(ReconCnst.PAY_CODE, bankArg.get(ReconCnst.PAY_CODE));
		updateMap.put(ReconCnst.CHANNEL_CODE, ChannelCnst.CHANNEL_CCB);
		try {
			String fileDate = bankArg.get(ReconCnst.FILE_DATE);
			LOGGER.info("解析[{}]对账文件开始", fileDate);

			String localDir = bankArg.get(ReconCnst.LOCAL_PATH);
			String reconFilename = bankArg.get(ReconCnst.FILE_NAME);
			FileUtils.writeStringToFile(new File(localDir + reconFilename), "");
			String remoteDir = bankArg.get(ReconCnst.SFTP_PATH);
			SFTPUtils sftpClient = new SFTPUtils(bankArg.get(ReconCnst.SFTP_IP),
					Integer.parseInt(bankArg.get(ReconCnst.SFTP_PORT)), bankArg.get(ReconCnst.SFTP_USER),
					bankArg.get(ReconCnst.SFTP_PASS), 0);
			boolean res = false;
			String bankFilename = bankArg.get(ReconCnst.BANK_FILE_NAME);
			LOGGER.info("解析[{}]对账流水文件[{}]开始", fileDate, bankFilename);
			res = createReconFile(localDir, reconFilename, bankFilename);
			if (res) {
				sftpClient.upload(remoteDir + CHANNEL_CODE + BANK, localDir + bankFilename);
				FileUtils.forceDelete(new File(localDir + bankFilename));// 删除支付文件
			}

			LOGGER.info("解析[{}]对账文件[{}]上传SFTP", fileDate, reconFilename);
			sftpClient.upload(remoteDir + CHANNEL_CODE, localDir + reconFilename);
			FileUtils.forceDelete(new File(localDir + reconFilename));
			updateMap.put(SqlCnst.TARGET_STATUS, ReconCnst.RECON_STATUS_DOWNLOAD);
		} catch (IOException e) {
			LOGGER.error("文件解析错误", e);
			updateMap.put(SqlCnst.TARGET_STATUS, ReconCnst.RECON_STATUS_FAILURE);
			updateMap.put(SqlCnst.REMARK, e.getMessage());
		} catch (Exception e) {
			LOGGER.error("文件解析错误", e);
			updateMap.put(SqlCnst.TARGET_STATUS, ReconCnst.RECON_STATUS_FAILURE);
			updateMap.put(SqlCnst.REMARK, e.getMessage());
		}
		LOGGER.info("解析[{}]对账文件--调用核心", bankArg.get(ReconCnst.FILE_DATE));
		try {
			httpReconService.updateChannelReconFile("", updateMap);
		} catch (Exception e) {
			LOGGER.error("通道[{}]下载文件成功,通知核心异常", CHANNEL_CODE, e);
		}

	}

	private static boolean createReconFile(String localDir, String reconFilename, String zipFilename) {
		List<String> dataLines = null;
		InputStream inputStream = null;
		BufferedReader bufferedReader = null;
		try {
			String bankFilename = ZipUtil.unZip(localDir + zipFilename).get(0);
			File bankfile = new File(localDir + bankFilename);
			inputStream = new FileInputStream(bankfile);
			bufferedReader = new BufferedReader(new InputStreamReader(inputStream, EncodingCnst.UTF_8));

			// 前两行跳过
			String line = bufferedReader.readLine();
			line = bufferedReader.readLine();
			if (StringUtils.isNotEmpty(line)) {
				dataLines = new ArrayList<String>();
				while (null != (line = bufferedReader.readLine())) {
					analysisPayContent(line, dataLines);
					if (dataLines.size() % (ReconCnst.FILE_NUMBER_PER_WRITE
							+ CharCnst.NUMBER_ONE) == ReconCnst.FILE_NUMBER_PER_WRITE) {
						FileUtils.writeLines(new File(localDir + reconFilename), EncodingCnst.UTF_8, dataLines, null,
								true);
						dataLines.clear();
					}
				}
				if (CollectionUtils.isNotEmpty(dataLines)) {
					FileUtils.writeLines(new File(localDir + reconFilename), EncodingCnst.UTF_8, dataLines, null, true);
				}
			}
			inputStream.close();
			bufferedReader.close();
			FileUtils.forceDelete(bankfile);// 删除解压文件
		} catch (Exception e) {
			LOGGER.error("生成对账文件异常", e);
		} finally {
			if (inputStream != null) {
				try {
					inputStream.close();
				} catch (IOException e) {
				}
			}
			if (bufferedReader != null) {
				try {
					bufferedReader.close();
				} catch (IOException e) {
				}
			}
		}
		return true;
	}

	/**
	 * 方法说明：<br>
	 * 序号 字段 字段说明（0923上线）<br>
	 * 1 交易时间 <br>
	 * 2 记账日期 清算日期<br>
	 * 3 银行流水号 全局事件流水跟踪号，25位<br>
	 * 4 商户流水号 商户上送，可为空<br>
	 * 5 订单号 <br>
	 * 6 订单状态 <br>
	 * 7 付款方账号/客户号 显示付款方账号，通道为微信或支付宝时，显示微信或支付宝客户号；其中付款方账号根据P2开关“完整显示付款人账号”来显示
	 * <br>
	 * 8 付款方户名 对公账户支付显示户名，其余不显示，后续优化<br>
	 * 9 订单金额 商户上送的订单金额，退款时显示原支付订单金额；如关联使用优惠活动时，显示优惠前的订单金额。<br>
	 * 10 交易金额 客户实际支付或退款的金额，退款金额负号表示；如关联使用优惠活动时，交易金额=订单金额-优惠金额。<br>
	 * 11 手续费 根据客户交易金额计算手续费；对于使用优惠券+卡支付的订单，按卡支付金额计算手续费，不含优惠券支付手续费<br>
	 * 12 结算金额 手续费消费本金抵扣时，结算金额=交易金额减去手续费；手续费从手续费账户单独支取时，结算金额=交易金额<br>
	 * 13 柜台代码 <br>
	 * 14 发卡行/通道 本行、银联（网银跨行支付）、快钱（龙支付跨行）、支付宝（聚合支付）、微信（聚合支付） <br>
	 * 15 支付卡种 借记卡（含存折、贷款账户）、信用卡、他行卡<br>
	 * 16 交易类型 目前仅有龙支付显示，后续优化<br>
	 * 17 期数 信用卡分期显示期数，其他交易显示为1<br>
	 * 18 授权号 快捷付交易显示，目前为空，后续优化<br>
	 * 19 项目号 招投标交易显示，目前为空，后续优化<br>
	 * 20 基本户 招投标交易显示，目前为空，后续优化<br>
	 * 21 备注一 <br>
	 * 22 备注二<br>
	 * 
	 * @param line
	 * @param dataLines
	 */
	private static void analysisPayContent(String line, List<String> dataLines) {
		ReconFileDetail fileDetail = new ReconFileDetail();
		String[] cols = line.split("\t");
		// 交易时间 记账日期 银行流水号 商户流水号 订单号 订单状态 付款方账号/客户号 付款方户名 订单金额 交易金额 手续费 结算金额
		// 柜台代码 发卡行/通道 支付卡种 交易类型 期数 授权号 项目号 基本户 备注一 备注二
		if (cols.length >= 22) {
			// 银行日期 2017-01-10 07:12:03 对账文件日期20170110071203
			fileDetail.setTradeTime(cols[0].replaceAll("-", "").replaceAll(":", "").replaceAll(" ", ""));
			BigDecimal tradeAmt = new BigDecimal(cols[9]).multiply(new BigDecimal("100"));
			if (tradeAmt.compareTo(new BigDecimal(0L)) >= 0) {// 支付
				fileDetail.setTradeSn(cols[4]);// 订单号
				fileDetail.setTradeType(ReconCnst.TRADE_TYPE_PAYMENT);
				fileDetail.setOrderAmt(new BigDecimal(cols[8]).multiply(new BigDecimal("100")).longValue());
			} else { // 退款
				if (StringUtils.isEmpty(cols[3])) {// 商户平台退款，无商户订单号，只有银行流水号
					return;
				}
				fileDetail.setTradeSn(cols[3]);// 商户流水号 商户上送，可为空
				fileDetail.setTradeType(ReconCnst.TRADE_TYPE_REFUND);
				fileDetail.setOrderAmt(tradeAmt.multiply(new BigDecimal("-1")).longValue());
			}
			fileDetail.setMerOrderNo(fileDetail.getTradeSn());
			fileDetail.setTradeSn(fileDetail.getMerOrderNo());
			fileDetail.setTradeStatus(StatusCnst.SUCCESS);
			fileDetail.setMerAmt(fileDetail.getOrderAmt());
			fileDetail.setFee(new BigDecimal(cols[10]).multiply(new BigDecimal("100")).longValue());
			fileDetail.setOtherFee(0L);
			dataLines.add(fileDetail.toReconStr());
		}

	}

}
