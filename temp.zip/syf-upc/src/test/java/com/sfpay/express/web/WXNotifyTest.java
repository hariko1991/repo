package com.sfpay.express.web;

import java.util.Map;

import org.junit.Test;

import com.sfpay.express.web.domain.TestWxNotify;
import com.sfpay.framework.common.json.JSONUtils;
import com.sfpay.upc.common.WXSignUtil;
import com.sfpay.upc.util.HttpProxyHelper;

public class WXNotifyTest {
	@Test
	public void testNotifyByBank() throws Exception {
		String url = "http://localhost:48080/syf-upc/upc/201607130002000126/notify";
		
		TestWxNotify notify = new TestWxNotify();
		notify.setAppid("wx0d9aa0e894066e87");
		notify.setAttach("test");
		notify.setBank_type("ICBC");
		notify.setCash_fee(1);
		notify.setCash_fee_type("CNY");
		notify.setFee_type("CNY");
		notify.setIs_subscribe("N");
		notify.setMch_id("1332855701");
		notify.setNonce_str("46131321sdasdsjakldjal");
		notify.setOpenid("lsadlaskdjaskddada4566");
		notify.setOut_trade_no("1607132050340000000282");
		notify.setResult_code("SUCCESS");
		notify.setReturn_code("SUCCESS");
		notify.setTime_end("2016225091010");
		notify.setTotal_fee(100);
		notify.setTrade_type("JSAPI");
		notify.setTransaction_id("4334564132123999777");
		notify.setErr_code("");
		notify.setErr_code_des("");
//		notify.setCoupon_fee(10); 
//		notify.setCoupon_count(2);
//		notify.setCoupon_id_0("001");
//		notify.setCoupon_id_1("002");
//		notify.setCoupon_fee_0(5);
//		notify.setCoupon_fee_1(5);
		
		Map<String, Object> req = JSONUtils.fromJSONStr(JSONUtils.fromObject(notify));
		req.put("key", "96298270c222e5e3ccb5b35ce84394da");
		
		String sign = WXSignUtil.packageSign(req);
		notify.setSign(sign);
		System.out.println(notify.toString());
		Object result = HttpProxyHelper.sendByPost(url, notify.toString(), false);
		System.out.println(result);
	}
}
