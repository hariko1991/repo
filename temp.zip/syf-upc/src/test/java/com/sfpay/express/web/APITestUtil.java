///**
// * =================================================================
// * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
// * -----------------------------------------------------------------
// * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
// * 不允许对程序代码以任何形式任何目的的再发布
// * =================================================================
// */
//package com.sfpay.express.web;
//
//
//
//
//public class APITestUtil {
//	public static Map<String, String> executeOpenApi(String url, Map<String, Object> data) throws Exception {
//		Map<String, String> map = new HashMap<String, String>();
//		InputStream inputStream = null;
//		int size = 0;
//		byte[] bytes = new byte[1024 * 10];
//		String response = "";
//		try {
//			HttpClient httpClient = new HttpClient();
//
//			httpClient.getParams().setParameter(HttpMethodParams.HTTP_CONTENT_CHARSET, "UTF-8");
//			HttpMethod requestMethod = new PostMethod(url);
//			requestMethod.addRequestHeader(new Header("Accept",
//					"application/json, application/x-www-form-urlencoded, text/*"));
//			requestMethod.addRequestHeader(new Header("Content-Type", "application/x-www-form-urlencoded"));
//
//			NameValuePair[] params = new NameValuePair[data.size()];
//			NameValuePair prir = new NameValuePair();
//			int count = 0;
//			for(Map.Entry<String, Object> re: data.entrySet()) {
//				prir = new NameValuePair(re.getKey(), String.valueOf(re.getValue()));
//				params[count++] = prir;
//			}
//			
//			requestMethod.setQueryString(params);
//			int rs = httpClient.executeMethod(requestMethod);
//			System.out.println("返回码：" + rs);
//			inputStream = requestMethod.getResponseBodyAsStream();
//			size = inputStream.read(bytes);
//			response = new String(Arrays.copyOfRange(bytes, 0, size), "UTF-8");
//			map.put("response", response);
//			System.out.println("response: " + response);
//			System.out.println("*********请求header*****************");
//			Header[] hearderArray = requestMethod.getRequestHeaders();
//			for (Header h : hearderArray) {
//				System.out.println(h.getName() + "  " + h.getValue());
//			}
//			System.out.println("**************************");
//			System.out.println("*********返回header************");
//			hearderArray = requestMethod.getResponseHeaders();
//			for (Header h : hearderArray) {
//				System.out.println(h.getName() + "  " + h.getValue());
//			}
//			Header cookieHeader = requestMethod.getResponseHeader("Set-Cookie");
//			String cookieValues = null;
//			if (cookieHeader != null) {
//				cookieValues = cookieHeader.getValue();
//			}
//			if (!StringUtil.isNullOrEmpty(cookieValues)) {
//				int sessionIdIndex = cookieValues.indexOf("SFPAY_JSESSIONID");
//				int begin = cookieValues.indexOf('=', sessionIdIndex);
//				int end = cookieValues.indexOf(';', sessionIdIndex);
//				String returnSessionId = cookieValues.substring(begin + 1, end);
//				map.put("sessionId", returnSessionId);
//			}
//
//			return map;
//		} catch (HttpException e) {
//			e.printStackTrace();
//		} catch (IOException e) {
//			e.printStackTrace();
//		} finally {
//
//		}
//		return null;
//	}
//}
