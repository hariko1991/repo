package com.sfpay.express.web;

import java.util.Date;

import javax.annotation.Resource;

import org.apache.http.client.methods.HttpGet;
import org.junit.Test;

import com.sfpay.acquirer.common.MD5Util;
import com.sfpay.framework.web.test.SpringTestCase;
import com.sfpay.framework2.core.util.DateUtil;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.service.HttpProxyServiceImpl;
import com.sfpay.upc.util.HttpProxyHelper;

public class SfPayNotifyTest extends SpringTestCase {
	
	@Resource
	private HttpProxyServiceImpl httpProxyService;
	
	@Test
	public void testNotifyByBank() throws Exception {
		String url = "http://localhost:8085/syf-upc/upc/201610170000046933/notify";

		StringBuilder sb = new StringBuilder();
		String merchantId = "1000422941";
		String orderId = "201610170000046933";
		Long amt = 9L;
		String status = TradeStatus.SUCCESS.name();
		String sfBusinessNo = "refund554564564asdasd88";
		String requestTime = DateUtil.format(new Date(), DateUtil.YYYY_MM_DD_HH_MM_SS);
		String orderBeginTime = DateUtil.format(new Date(), DateUtil.YYYY_MM_DD_HH_MM_SS);
		sb.append("merchantId=").append(merchantId).append("&orderId=").append(orderId).append("&amt=").append(amt)
				.append("&orderBeginTime=").append(orderBeginTime).append("&status=").append(status)
				.append("&sfBusinessNo=").append(sfBusinessNo);
		String key = MD5Util.md5Hex(requestTime);
		String sign = MD5Util.md5Hex(sb.toString() + key);
		sb.append("&sign=").append(sign);
		sb.append("&serviceName=APPSY_ASYNC_NOTIFY");
		sb.append("&requestTime=").append(requestTime);
		
		Object result = HttpProxyHelper.sendByPost(url, sb.toString(), false);
		System.out.println(result);
	}
	
	
	
}
