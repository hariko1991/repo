package com.sfpay.express.web;

import org.junit.Test;

import com.sfpay.upc.util.HttpProxyHelper;


public class AlipayNotifyTest {

	@Test
	public void testNotifyByBank() throws Exception {
		String url = "https://mapi.alipay.com/gateway.do?service=notify_verify&partner=2088421207758794&notify_id=64ce1b6ab92d00ede0ee56ade98fdf2f4c";
		// String url =
		// "http://localhost:48080/syf-upc/upc/201606180000000383/notify?discount=0.00&payment_type=1&subject=测试&trade_no=2013082244524842&buyer_email=dlwdgl@gmail.com&gmt_create=2013-08-22 14:45:23&notify_type=trade_status_sync&quantity=1&out_trade_no=082215222612710&seller_id=2088501624816263&notify_time=2013-08-22 14:45:24&body=测试测试&trade_status=TRADE_SUCCESS&is_total_fee_adjust=N&total_fee=1.00&gmt_payment=2013-08-22 14:45:24&seller_email=xxx@alipay.com&price=1.00&buyer_id=2088602315385429&notify_id=64ce1b6ab92d00ede0ee56ade98fdf2f4c&use_coupon=N";
		Object result = HttpProxyHelper.httpGet(url);
		System.out.println(result);
	}

}
