package com.sfpay.express.web;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.framework.web.test.SpringTestCase;
import com.sfpay.upc.domain.upc.QueryUpcPayParam;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.exception.UPCServiceException;
import com.sfpay.upc.service.IUpcPayInfoService;

public class HessServiceImplTest extends SpringTestCase {

	@Resource
	private IUpcPayInfoService payInfoService;
	@Test
	public void test1() throws UPCServiceException {
		QueryUpcPayParam payParam = new QueryUpcPayParam();
		payParam.setPayNo("201606200000000389");
		UpcPayInfo payInfo = payInfoService.queryPayInfo(payParam);
		System.out.println(payInfo.getPayNo());
		
	}

}
