/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.express.web;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;

import com.alibaba.fastjson.JSON;
import com.sfpay.framework.web.test.SpringTestCase;
import com.sfpay.front.cnst.BankCnst;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.upc.util.HttpProxyHelper;
import com.sfpay.upc.util.WeNetworkUtil;

import junit.framework.Assert;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月31日
 */
public class WeTest extends SpringTestCase {

	@Test
	public void testGetAccessToken() throws Exception {
		String path = "C:/Configuration/upc/cert/ ";
		String url = "https://l.test-svrapi.webank.com/api/oauth2/access_token?app_id=W3910554&secret=EvewhICzhMCtD19XbNRLkbzwNGt56J1kPVM4qTLQJWSS6Oc8vMIINbwNgyBRtquJ&grant_type=client_credential&version=1.0.0";
		Map<String, String> extMap = new HashMap<String, String>();
		extMap.put(BankCnst.ACTUAL_NETWORK_URL, url);
		extMap.put(BankCnst.PATH, path);
		extMap.put(BankCnst.CLIENT_PASS, "Abcd1234");
		extMap.put(BankCnst.JKS, "U5840214.p12");
		extMap.put(BankCnst.TRUST, "webank_root.jks");
		extMap.put(BankCnst.SERVER_PASS, "123456");
		extMap.put(BankCnst.EXCHANGE_TYPE, CharCnst.EXCHANGE_TYPE_GET);
		Assert.assertNotNull(WeNetworkUtil.sendAndReceiveForTrade("", extMap), null);
	}

	@Test
	public void testSendJson() throws Exception {
		String url = "https://cpay-sit.sf-pay.com/syf-upc/weNotify/bill?nonce=123&timestamp=12212&sign=234343";
		Map<String, String> outMap = new HashMap<String, String>();
		Map<String, String> innerMap = new HashMap<String, String>();
		innerMap.put("webankAppId", "W0000001");
		innerMap.put("token", "upFDpjPt");
		innerMap.put("file_id", "900000001498181423282-2107576261000000014974902232821319");
		innerMap.put("file_hash", "fc0edb8b51e0637a2dc4306a4d082b00");
		innerMap.put("work_date", "18030100036600");
		String innerJson = JSON.toJSONString(innerMap);
		outMap.put("type", "file");
		outMap.put("data", innerJson);
		String meta = JSON.toJSONString(outMap);
		HttpProxyHelper.sendByPostByJson(url, meta);
	}
}
