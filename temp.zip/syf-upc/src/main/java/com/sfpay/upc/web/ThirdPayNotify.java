package com.sfpay.upc.web;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sfpay.acquirer.common.Encoding;
import com.sfpay.acquirer.common.HttpHelper;
import com.sfpay.acquirer.common.MD5Util;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework2.core.util.DateUtil;
import com.sfpay.upc.common.WXSignUtil;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.QueryUpcPayParam;
import com.sfpay.upc.domain.upc.UpcBaseReq;
import com.sfpay.upc.domain.upc.UpcHandleAlipayParam;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.upc.UpcPayUnknownParam;
import com.sfpay.upc.domain.wx.WXNotifyRlt;
import com.sfpay.upc.enums.SystemSource;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.exception.UPCServiceException;
import com.sfpay.upc.service.IAlipayService;
import com.sfpay.upc.service.IChannelArgService;
import com.sfpay.upc.service.IMqService;
import com.sfpay.upc.service.IUpcPayInfoService;
import com.sfpay.upc.service.IWXService;

/**
 * 
 * 类说明：<br>
 * 后台回调
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-5-4
 */
@Controller
@RequestMapping("/upc")
public class ThirdPayNotify {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	private static String handleSuccWxNotifyMsg = "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>";
	@Resource
	private IUpcPayInfoService payInfoService;
	@Resource
	private IChannelArgService channelArgService;
	@Resource
	private IWXService wxService;
	@Resource
	private IAlipayService alipayService;
	@Resource
	private IMqService mqService;

	@RequestMapping(value = "/{payNo}/notify")
	public void notifyByThirdPay(@PathVariable("payNo") String payNo, HttpServletRequest req, HttpServletResponse resp) {

		long startTime = System.currentTimeMillis();
		logger.info("接收支付流水payNO:[{}] 的银行[后端]回调...", payNo);
		if (StringUtils.isEmpty(payNo)) {
			logger.error("支付流水号payNO不能为空");
			return;
		}
		logger.info("查找支付流水payNO:[{}]...", payNo);
		UpcPayInfo payInfo = null;
		try {
			QueryUpcPayParam payParam = new QueryUpcPayParam();
			payParam.setPayNo(payNo);
			payInfo = payInfoService.queryPayInfo(payParam);
		} catch (Exception e) {
			logger.error(String.format("查找支付流水[%s]异常", payNo), e);
			return;
		}
		if (null == payInfo) {
			logger.info("无法找到支付流水[{}]信息.[结束]", payNo);
			return;
		}
		if (payInfo.getSystemSource() == null) {
			logger.info("未知订单系统来源[{}][结束]", payNo);
			return;
		}
		// 微信回调
		if (payInfo.getChannelCode().startsWith("WX")) {
			handlerWX(payInfo, req, resp);
			logger.info("响应微信通知upc notifyByThirdPay payNo:[{}],处理共用时:[{}]毫秒", payNo, System.currentTimeMillis()
					- startTime);
			return;
		} else if (payInfo.getChannelCode().startsWith("ALIPAY")) {
			handlerAlipay(payInfo, req, resp);
			logger.info("响应支付宝通知upc notifyByThirdPay payNo:[{}], 处理共用时:[{}]毫秒", payNo, System.currentTimeMillis()
					- startTime);
			return;
		} else if (payInfo.getChannelCategoryCode().startsWith("SFPAY")) {
			handlerSFPAY(payInfo, req, resp);
			logger.info("响应顺手付通知upc notifyByThirdPay payNo:[{}], 处理共用时:[{}]毫秒", payNo, System.currentTimeMillis()
					- startTime);
			return;
		}
	}

	/**
	 * 处理顺手付
	 * 
	 * @param payInfo
	 * @param req
	 * @param resp
	 */
	private void handlerSFPAY(UpcPayInfo payInfo, HttpServletRequest request, HttpServletResponse resp) {
		if (!TradeStatus.TRADING.name().equals(payInfo.getStatus())
				&& !TradeStatus.REFUND_PROC.name().equals(payInfo.getStatus())) {
			// 交易成功且是upp且发送mq消息失败 重新发送
			if ((TradeStatus.SUCCESS.name().equals(payInfo.getStatus())
					|| TradeStatus.FAILURE.name().equals(payInfo.getStatus())
					|| TradeStatus.REFUND_SUCC.name().equals(payInfo.getStatus()) || TradeStatus.REFUND_FAIL.name()
					.equals(payInfo.getStatus()))
					&& SystemSource.UPP.name().equals(payInfo.getSystemSource())
					&& ("N".equals(payInfo.getNotifyFlag()) || StringUtils.isEmpty(payInfo.getNotifyFlag()))) {
				
				sendMqAndRecordToUpp(payInfo, payInfo.getStatus(), payInfo.getRtnOrderNo(), payInfo.getPayBankType(),
						"", "");

			}
			try {
				resp.getOutputStream().print("success");
				return;
			} catch (IOException e) {
				logger.error("反馈成功结果给顺手付异常", e);
			}
		}

		// 获取顺手付POST过来反馈信息
		Map<?, ?> params = request.getParameterMap();
		// 组装支付宝请求数据
		Map<String, String> requestParams = new HashMap<String, String>();
		for (Iterator<?> iter = params.keySet().iterator(); iter.hasNext();) {
			String name = (String) iter.next();
			String[] values = (String[]) params.get(name);
			String valueStr = "";
			for (int i = 0; i < values.length; i++) {
				valueStr = (i == values.length - 1) ? valueStr + values[i] : valueStr + values[i] + ",";
			}

			requestParams.put(name, valueStr);
		}

		logger.info("顺手付请求参数：{}", requestParams.toString());

		// 验证顺手付请求参数
		boolean validParams = validSfpayReqParams(payInfo, requestParams);
		if (!validParams) {
			return;
		}
		String status = requestParams.get("status");
		if ("CLOSED".equals(status)) {
			status = "CLOSE";
		}

		String orignalStatus = TradeStatus.TRADING.name();
		String targetStatus = status;
		if ("PAY_REFUND".equals(payInfo.getTradeType())) {
			orignalStatus = TradeStatus.REFUND_PROC.name();
			targetStatus = getUpcStatus(status);
		}

		UpcPayUnknownParam reqParam = new UpcPayUnknownParam();
		reqParam.setMchNo(payInfo.getMchNo());
		reqParam.setPayNo(payInfo.getPayNo());
		reqParam.setOriginalStatus(orignalStatus);
		reqParam.setTargetStatus(targetStatus);
		try {
			payInfoService.updateUpcPayUnknown(reqParam);
		} catch (UPCServiceException e) {
			logger.info("更新顺手付结果异常, data:{}", reqParam.toString());
			return;
		}

		// 通知upp
		if (SystemSource.UPP.name().equals(payInfo.getSystemSource()) && !"CLOSED".equals(status)) {
			// MQ发消息 ,并记录通知结果
			sendMqAndRecordToUpp(payInfo, targetStatus, payInfo.getRtnOrderNo(), "", "", "");
		}

		try {
			resp.getOutputStream().print("success");
			return;
		} catch (IOException e) {
			logger.error("反馈成功结果给顺手付异常", e);
		}

	}

	private String getUpcStatus(String status) {
		return Sfpay2UpcRefundStatus.valueOf(status).getUpcRefundStatus();
	}

	public enum Sfpay2UpcRefundStatus {

		SUCCESS(TradeStatus.REFUND_SUCC.name()), FAILURE(TradeStatus.REFUND_FAIL.name()), CLOSED(TradeStatus.CLOSE
				.name());

		String upcRefundStatus;

		private Sfpay2UpcRefundStatus(String status) {
			this.upcRefundStatus = status;
		}

		public String getUpcRefundStatus() {
			return upcRefundStatus;
		}

	}

	private boolean validSfpayReqParams(UpcPayInfo payInfo, Map<String, String> requestParams) {
		String sypayNotify = requestParams.get("serviceName");
		String sign = requestParams.get("sign");
		String requestTime = requestParams.get("requestTime");
		String merchantId = requestParams.get("merchantId");
		String orderId = requestParams.get("orderId");
		String amt = requestParams.get("amt");
		String orderBeginTime = requestParams.get("orderBeginTime");
		String status = requestParams.get("status");
		String sfBusinessNo = requestParams.get("sfBusinessNo");

		if (StringUtils.isEmpty(sypayNotify) || StringUtils.isEmpty(sign) || StringUtils.isEmpty(requestTime)
				|| StringUtils.isEmpty(merchantId) || StringUtils.isEmpty(orderId) || StringUtils.isEmpty(amt)
				|| StringUtils.isEmpty(status) || StringUtils.isEmpty(sfBusinessNo)) {
			logger.info("顺手付请求必填参数为空");
			return false;
		}

		if (!payInfo.getPayNo().equals(orderId) || payInfo.getTradeAmt().longValue() != Long.valueOf(amt)) {
			logger.info("顺手付订单号或金额不匹配");
			return false;
		}
		// SUCCESS成功、FAILURE失败、CLOSED 交易关闭
		if (!"SUCCESS".equals(status) && !"FAILURE".equals(status) && !"CLOSED".equals(status)) {
			logger.info("顺手付订单状态不合法 :{}", status);
			return false;
		}
		StringBuilder sb = new StringBuilder();
		sb.append("merchantId=").append(merchantId).append("&orderId=").append(orderId).append("&amt=").append(amt)
				.append("&orderBeginTime=").append(orderBeginTime).append("&status=").append(status)
				.append("&sfBusinessNo=").append(sfBusinessNo);
		String key = MD5Util.md5Hex(requestTime);
		logger.info("签名原始串：{}, key:{}", sb.toString(), key);
		String newSign = MD5Util.md5Hex(sb.toString() + key);
		boolean isValid = sign.equals(newSign);
		logger.info("签名不正确");
		return isValid;

	}

	private void handlerWX(UpcPayInfo payInfo, HttpServletRequest requst, HttpServletResponse resp) {
		ChannelArgs channelArgs = channelArgService.getChannelArgs(payInfo.getChannelCode(), payInfo.getMchNo());
		// 1.解析报文
		WXNotifyRlt wxnr = parseWXPostDataXml(requst, payInfo, channelArgs);
		if (null == wxnr) {
			logger.info("回调报文结果解析异常,回调结束.sn:{}", payInfo.getReqOrderNo());
			return;
		}
		// 2. 重复回调处理直接返回成功
		if (!TradeStatus.TRADING.name().equals(payInfo.getStatus())) {

			// 交易成功且是upp且发送mq消息失败 重新发送
			if (TradeStatus.SUCCESS.name().equals(payInfo.getStatus())
					&& SystemSource.UPP.name().equals(payInfo.getSystemSource())
					&& ("N".equals(payInfo.getNotifyFlag()) || StringUtils.isEmpty(payInfo.getNotifyFlag()))) {
				sendMqAndRecordToUpp(payInfo, TradeStatus.SUCCESS.name(), payInfo.getRtnOrderNo(),
						payInfo.getPayBankType(), "", "");
			}

			try {
				resp.getOutputStream().print(handleSuccWxNotifyMsg);
				return;
			} catch (IOException e) {
				logger.error("反馈成功结果给微信异常", e);
			}
		}

		UpcPayUnknownParam upcParam = new UpcPayUnknownParam();
		upcParam.setMchNo(payInfo.getMchNo());
		upcParam.setPayNo(payInfo.getPayNo());
		upcParam.setPayBankCode(wxnr.getBankType());
		upcParam.setOpenid(wxnr.getOpenid());
		upcParam.setRtnOrderNo(wxnr.getWxOrderNo());
		upcParam.setOriginalStatus(TradeStatus.TRADING.name());
		upcParam.setTargetStatus(UpcConstants.SUCCESS.equals(wxnr.getReturnCode())
				&& UpcConstants.SUCCESS.equals(wxnr.getResultCode()) ? TradeStatus.SUCCESS.name() : TradeStatus.FAILURE
				.name());
		upcParam.setRtnBankCode(StringUtils.isEmpty(wxnr.getErrCode()) ? wxnr.getReturnCode() : wxnr.getErrCode());
		upcParam.setRtnBankMsg(StringUtils.isEmpty(wxnr.getErrCodeDes()) ? wxnr.getReturnMsg() : wxnr.getErrCodeDes());
		// 3.处理支付流水
		try {
			wxService.handleWxNotify(upcParam);
		} catch (UPCServiceException e1) {
			logger.error(String.format("处理支付流水异常：payNo:%s wxOrderNo:%s", payInfo.getPayNo(), wxnr.getWxOrderNo()), e1);
			return;
		}

		// 4.调用业务系统
		logger.info("通知系统 payNo:[{}] 系统来源:[{}]", payInfo.getPayNo(), payInfo.getSystemSource());
		if (SystemSource.HHT.name().equals(payInfo.getSystemSource())) {
			notifyOtherSystem(payInfo, wxnr);
		} else if (SystemSource.UPP.name().equals(payInfo.getSystemSource())) {

			// MQ发消息 ,并记录通知结果
			sendMqAndRecordToUpp(payInfo, TradeStatus.SUCCESS.name(), wxnr.getWxOrderNo(), wxnr.getBankType(),
					wxnr.getErrCode(), wxnr.getErrCodeDes());

		}
		// 5.响应微信 通知微信成功
		logger.info(String.format("反馈成功结果给微信,订单[上送的交易流水(%s),支付流水号(%s)]", wxnr.getReqBankSn(), payInfo.getPayNo()));
		try {
			resp.getOutputStream().print(handleSuccWxNotifyMsg);
		} catch (IOException e) {
			logger.error("反馈成功结果给微信异常", e);
		}
	}

	private void sendMqAndRecordToUpp(UpcPayInfo payInfo, String upcTradeStatus, String rtnOrderNo, String payBankType,
			String errorCode, String errorMsg) {
		Map<String, String> mapMsg = new HashMap<String, String>();

		mapMsg.put("tradeType", "PAY".equals(payInfo.getTradeType()) ? "PAYMENT" : "REFUND");
		mapMsg.put("channelCode", payInfo.getChannelCode());
		mapMsg.put("mchNo", payInfo.getMchNo());
		mapMsg.put("uppChannelTradeNo", payInfo.getUppOrderNo());
		mapMsg.put("mchOrderNo", payInfo.getMchOrderNo());
		mapMsg.put("rtnOrderNo", rtnOrderNo);
		mapMsg.put("tradeAmt", String.valueOf(payInfo.getTradeAmt()));
		mapMsg.put("tradeFee", String.valueOf(payInfo.getTradeFee() == null ? 0L : payInfo.getTradeFee()));
		mapMsg.put("ccy", payInfo.getCcy());
		mapMsg.put("status", upcTradeStatus);
		mapMsg.put("payBankType", payBankType);
		mapMsg.put("beginTime", DateUtil.format(payInfo.getBeginTime(), DateUtil.YYYY_MM_DD_HH_MM_SS));
		mapMsg.put("endTime", DateUtil.format(new Date(), DateUtil.YYYY_MM_DD_HH_MM_SS));
		mapMsg.put("errorCode", errorCode);
		mapMsg.put("errorMsg", errorMsg);

		boolean newVersion = false;
		if (StringUtils.isNotEmpty(payInfo.getUppOrderNo())) {
			newVersion = true;
		}
		logger.info("syf-upc 通知聚合支付mq消息 :[{}]", mapMsg.toString());
		mqService.sendMsg(newVersion, mapMsg);

		try {
			payInfoService.updateNotifyFlag(payInfo.getPayNo(), "Y");
		} catch (UPCServiceException e) {
			logger.error("syf-upc 记录通知结果异常", e);
		}
	}

	/**
	 * 处理支付宝 交易成功 完成、关闭订单和退款
	 * 
	 * @param payInfo
	 * @param req
	 * @param resp
	 */
	private void handlerAlipay(UpcPayInfo payInfo, HttpServletRequest request, HttpServletResponse resp) {
		// 重复回调处理直接返回成功
		if (!TradeStatus.TRADING.name().equals(payInfo.getStatus())) {

			// 交易成功且是upp且发送mq消息失败 重新发送
			if (TradeStatus.SUCCESS.name().equals(payInfo.getStatus())
					&& SystemSource.UPP.name().equals(payInfo.getSystemSource())
					&& ("N".equals(payInfo.getNotifyFlag()) || StringUtils.isEmpty(payInfo.getNotifyFlag()))) {
				sendMqAndRecordToUpp(payInfo, TradeStatus.SUCCESS.name(), payInfo.getRtnOrderNo(),
						payInfo.getPayBankType(), "", "");
			}

			try {
				resp.getOutputStream().print("success");
				return;
			} catch (IOException e) {
				logger.error("反馈成功结果给支付宝异常", e);
			}
		}

		// 商户订单号验证
		String mchOrderNo = request.getParameter("out_trade_no");
		if (!payInfo.getReqOrderNo().equals(mchOrderNo)) {
			logger.info("非法请求:[{}] 商户订单号跟payinfo订单号不匹配", mchOrderNo);
			return;
		}

		// 获取支付宝POST过来反馈信息
		Map<?, ?> requestParams = request.getParameterMap();
		// 组装支付宝请求数据
		Map<String, String> params = new HashMap<String, String>();
		for (Iterator<?> iter = requestParams.keySet().iterator(); iter.hasNext();) {
			String name = (String) iter.next();
			String[] values = (String[]) requestParams.get(name);
			String valueStr = "";
			for (int i = 0; i < values.length; i++) {
				valueStr = (i == values.length - 1) ? valueStr + values[i] : valueStr + values[i] + ",";
			}

			params.put(name, valueStr);
		}

		logger.info("支付宝通知请求参数:[{}]", params.toString());
		// 支付宝交易号
		String alipayTradeNo = request.getParameter("trade_no");
		// 交易状态
		String alipayTradeStatus = request.getParameter("trade_status");

		UpcBaseReq baseReq = new UpcBaseReq(payInfo.getMchNo(), payInfo.getChannelCode());
		if (alipayService.verifyAlipayNotify(baseReq, params)) {// 验证成功
			String upcStatus = TradeStatus.TRADING.name();
			if ("WAIT_BUYER_PAY".equals(alipayTradeStatus) || "TRADE_CLOSED".equals(alipayTradeStatus)) {
				// 不做处理
				try {
					resp.getOutputStream().print("success");
					return;
				} catch (IOException e) {
					logger.error("反馈成功结果给支付宝异常", e);
				}
			} else if ("TRADE_FINISHED".equals(alipayTradeStatus) || "TRADE_SUCCESS".equals(alipayTradeStatus)) {
				upcStatus = TradeStatus.SUCCESS.name();
			} else {
				logger.info("无法使用支付宝状态:[{}]", alipayTradeStatus);
				return;
			}
			UpcHandleAlipayParam reqParam = new UpcHandleAlipayParam();

			reqParam.setMchNo(payInfo.getMchNo());
			reqParam.setPayNo(payInfo.getPayNo());
			reqParam.setRtnOrderNo(alipayTradeNo);
			reqParam.setOriginalStatus(TradeStatus.TRADING.name());
			reqParam.setTargetStatus(upcStatus);
			reqParam.setSellerId(request.getParameter("seller_id"));
			reqParam.setSellerAccount(request.getParameter("seller_email"));
			reqParam.setBuyerId(request.getParameter("buyer_id"));
			reqParam.setBuyerAccount(StringUtils.isNotBlank(request.getParameter("buyer_email")) ? request
					.getParameter("buyer_email") : request.getParameter("buyer_logon_id"));

			alipayService.handleAlipayNotify(reqParam);

			// 通知upp
			if (SystemSource.UPP.name().equals(payInfo.getSystemSource())
					&& TradeStatus.SUCCESS.name().equals(upcStatus)) {
				// MQ发消息 ,并记录通知结果
				sendMqAndRecordToUpp(payInfo, TradeStatus.SUCCESS.name(), alipayTradeNo, "", "", "");
			}

			try {
				resp.getOutputStream().print("success");
				return;
			} catch (IOException e) {
				logger.error("反馈成功结果给支付宝异常", e);
			}

		} else {// 验签名失败
			logger.info("验签失败: 请求数据：[{}]", requestParams.toString());
			try {
				resp.getOutputStream().print("fail");
				return;
			} catch (IOException e) {
				logger.error("反馈成功结果给支付宝异常", e);
			}
		}
	}

	private String notifyOtherSystem(UpcPayInfo payInfo, WXNotifyRlt wxnr) {
		// 通知返回成功状态,执行业务流水表更新及商户通知
		String url = null;
		StringBuffer meta = new StringBuffer();
		if (SystemSource.HHT.name().equals(payInfo.getSystemSource())) {

			url = String.format("%s/express/%s/notify", Property.getProperty("SYS_EXP_URI"), payInfo.getMchOrderNo());
			logger.info("system source hht notify url:[{}]", url);
			meta.append("&mchPayNo=").append(payInfo.getReqOrderNo());
			// 支付成功
			if (UpcConstants.SUCCESS.equals(wxnr.getReturnCode()) && UpcConstants.SUCCESS.equals(wxnr.getResultCode())) {
				meta.append("&status=").append(UpcConstants.SUCCESS);
				meta.append("&wxOderNo=").append(wxnr.getWxOrderNo());
				meta.append("&reqBankSn=").append(wxnr.getReqBankSn());
				meta.append("&openid=").append(wxnr.getOpenid());
			}
			// 支付失败
			else {
				meta.append("&status=").append("FAIL");
				meta.append("&respCode=").append(wxnr.getErrCode());
				meta.append("&respDesc=").append(wxnr.getErrCodeDes());
			}

			meta.append("&sign=").append(MD5Util.md5Hex("WX" + payInfo.getMchOrderNo()).toUpperCase());
		} else {

		}

		logger.info(String.format("后台通知[%s]-[%s]", url, meta.toString()));
		String rs = null;
		try {
			rs = HttpHelper.sendByPost(url, meta.toString(), Encoding.UTF_8);
		} catch (Exception e) {
			logger.error(String.format("通知[%s]异常(报文: %s)", url, meta), e);
		}
		return rs;

	}

	// 解析微信数据
	private WXNotifyRlt parseWXPostDataXml(HttpServletRequest request, UpcPayInfo payInfo, ChannelArgs args) {

		WXNotifyRlt notifyRlt = new WXNotifyRlt();
		try {
			Map<String, Object> resultMap = com.sfpay.upc.util.XMLToMapUtil.getInstanceContentMap(request
					.getInputStream());

			logger.info("微信通知顺手付数据解析：{}", resultMap.toString());

			boolean isValidSign = verifySign(resultMap, args);
			if (!isValidSign) {
				logger.info("签名不一致");
				return null;
			}

			notifyRlt.setReturnCode((String) resultMap.get("return_code"));
			notifyRlt.setReturnMsg((String) resultMap.get("return_msg"));
			notifyRlt.setAppId((String) resultMap.get("appid"));
			notifyRlt.setPartnerId((String) resultMap.get("mch_id"));
			notifyRlt.setNonceStr((String) resultMap.get("nonce_str"));
			notifyRlt.setSign((String) resultMap.get("sign"));
			notifyRlt.setResultCode((String) resultMap.get("result_code"));
			notifyRlt.setErrCode((String) resultMap.get("err_code"));
			notifyRlt.setErrCodeDes((String) resultMap.get("err_code_des"));
			notifyRlt.setOpenid((String) resultMap.get("openid"));
			notifyRlt.setIsSubscribe((String) resultMap.get("is_subscribe"));
			notifyRlt.setTradeType((String) resultMap.get("trade_type"));
			notifyRlt.setBankType((String) resultMap.get("bank_type"));
			notifyRlt.setTotalFee(Integer.parseInt((String) resultMap.get("total_fee")));
			notifyRlt.setCashFee(resultMap.get("cash_fee") == null ? 0 : Integer.parseInt((String) resultMap
					.get("cash_fee")));
			notifyRlt.setWxOrderNo((String) resultMap.get("transaction_id"));
			notifyRlt.setReqBankSn((String) resultMap.get("out_trade_no"));
			notifyRlt.setAttach((String) resultMap.get("attach"));
			notifyRlt.setTimeEnd((String) resultMap.get("time_end"));
		} catch (Exception e) {
			logger.error("xml 转 map异常:{}", e);
			notifyRlt = null;
		}

		return notifyRlt;
	}

	private boolean verifySign(Map<String, Object> resultMap, ChannelArgs args) {
		//args.getValueByKey("mch_key")
		String mch_id = String.valueOf(resultMap.get("mch_id"));
		resultMap.put("key", parseMchInfo("mch_key",mch_id,args));
		try {
			String newSign = WXSignUtil.packageSign(resultMap);
			return newSign.equals((String) resultMap.get("sign"));
		} catch (Exception e) {
			logger.error("组装签名异常：{}", resultMap.toString());
		}
		return false;
	}
	
	private static String parseMchInfo(String argType,String sourceValue,ChannelArgs bankArgs)
	{
		Map<String, String> map =bankArgs.getMap();
		Iterator<String> iter = map.keySet().iterator();
		String tempStr = "";
		while(iter.hasNext())
		{
			String ss = iter.next();
			String sss = map.get(ss);
			if(sourceValue.equals(sss))
			{
				tempStr = ss;
				break;
			}
		}
		
		if(tempStr.contains("program"))
		{
			if(argType.equals("app_id"))
			{
				sourceValue = bankArgs.getValueByKey("program_app_id");
			}
			else if(argType.equals("mch_id"))
			{
				sourceValue = bankArgs.getValueByKey("program_mch_id");
			}
			else if(argType.equals("mch_key"))
			{
				sourceValue = bankArgs.getValueByKey("program_mch_key");
			}
		}else
		{
			if(argType.equals("app_id"))
			{
				sourceValue = bankArgs.getValueByKey("app_id");
			}
			else if(argType.equals("mch_id"))
			{
				sourceValue = bankArgs.getValueByKey("mch_id");
			}
			else if(argType.equals("mch_key"))
			{
				sourceValue = bankArgs.getValueByKey("mch_key");
			}
		}
		
		return sourceValue;
	}

}
