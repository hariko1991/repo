package com.sfpay.upc.web;

import java.io.IOException;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSON;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.service.IHttpReceiveNotifyService;

/**
 * 南粤银行回调通知入口
 * @author 719811
 *
 */
@Controller
@RequestMapping("/nybNotify")
public class NybNotify {
	private final Logger LOGGER = LoggerFactory.getLogger(NybNotify.class);

	private static final String OUT_TRADE_NO = "outTradeNo";
	private static final String OUT_REFUND_NO = "outRefundNo";
	private static final String RS_SUCCESS = "SUCCESS";
	private static final String RS_FAILURE = "FAILURE";
	
	@Resource
	private IHttpReceiveNotifyService httpReceiveNotifyService;

	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/result/pay")
	public void result(@RequestBody String notifyContent, HttpServletRequest req , HttpServletResponse resp) throws Exception {
		String logMsg = String.format("南粤银行通知支付结果,通知请求参数[%s]", notifyContent);
		long startTime = System.currentTimeMillis();
		boolean rs = false;
		try{
			Map<String, String> reqMap = (Map<String, String>)JSON.parse(notifyContent);
			reqMap.put(MapCnst.REQ_ORDER_NO, reqMap.get(OUT_TRADE_NO));
			rs = httpReceiveNotifyService.notifyResult(logMsg, reqMap);
		}catch (Exception e) {
			LOGGER.error("{},后续处理异常", logMsg , e);
		}
		if(rs){
			writeResult(resp,RS_SUCCESS);	
		}else{
			writeResult(resp,RS_FAILURE);
		}
		LOGGER.info("{},UPC处理通知结果耗时：{}", logMsg, (System.currentTimeMillis() - startTime));
	}
	
	@SuppressWarnings("unchecked")
	@RequestMapping(value = "/result/refund")
	public void refundResult(@RequestBody String notifyContent, HttpServletRequest req , HttpServletResponse resp) throws Exception {
		String logMsg = String.format("南粤银行通知退款结果,通知请求参数[%s]", notifyContent);
		long startTime = System.currentTimeMillis();
		boolean rs = false;
		try{
			Map<String, String> reqMap = (Map<String, String>)JSON.parse(notifyContent);
			reqMap.put(MapCnst.REQ_ORDER_NO, reqMap.get(OUT_REFUND_NO));
			rs = httpReceiveNotifyService.notifyResult(logMsg, reqMap);
		}catch (Exception e) {
			LOGGER.error("{},后续处理异常", logMsg , e);
		}
		if(rs){
			writeResult(resp,RS_SUCCESS);	
		}else{
			writeResult(resp,RS_FAILURE);
		}
		LOGGER.info("{},UPC处理通知结果耗时：{}", logMsg, (System.currentTimeMillis() - startTime));
	}
	
	private void writeResult(HttpServletResponse resp , String resultCode){
    	try {
			resp.getOutputStream().print(resultCode);
		} catch (IOException e) {
			LOGGER.error("反馈标识success结果给南粤通道异常", e);
		}	
    }
}
