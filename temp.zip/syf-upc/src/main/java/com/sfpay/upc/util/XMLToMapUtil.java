package com.sfpay.upc.util;

import java.io.InputStream;
import java.util.HashMap;

import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.xml.sax.Attributes;
import org.xml.sax.SAXException;
import org.xml.sax.helpers.DefaultHandler;

/**
 * 
 * 类说明：<br>
 * xml转成map工具
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-18
 */
public class XMLToMapUtil {

	private static final Logger logger = LoggerFactory
			.getLogger(XMLToMapUtil.class);

	/**
	 * 返回xml数据内容
	 * 
	 * @param tags
	 * @return
	 * @throws Exception
	 * @throws PosOtherException
	 */
	public static HashMap<String, Object> getInstanceContentMap(
			InputStream inputStream) throws Exception {
		try {
			SAXParserFactory factory = SAXParserFactory.newInstance();
			SAXParser reader = factory.newSAXParser();
			ItemContentHandler handler = new ItemContentHandler();
			reader.parse(inputStream, handler);
			return handler.getContentMap();
		} catch (Exception e) {
			logger.error("XML解析异常:{}", e);
			throw new Exception("XML解析异常");
		}

	}

	// 按tags过滤
	static class ItemContentHandler extends DefaultHandler {
		private HashMap<String, Object> maps;
		private String tagName;

		public ItemContentHandler() {
			maps = new HashMap<String, Object>();
		}

		public HashMap<String, Object> getContentMap() {
			return maps;
		}

		public void startElement(String namespaceURI, String localName,
				String qName, Attributes attr) throws SAXException {
			tagName = qName;
		}

		public void endElement(String namespaceURI, String localName,
				String qName) throws SAXException {
			tagName = "";
		}

		// 获取报文正文
		public void characters(char[] ch, int start, int length)
				throws SAXException {
			if(StringUtils.isNotBlank(tagName)) {
				maps.put(tagName, new String(ch, start, length));
			}
		}
	}

}
