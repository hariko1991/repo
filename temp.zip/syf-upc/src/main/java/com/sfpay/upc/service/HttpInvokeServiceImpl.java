/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.upc.service;

import java.util.Map;
import java.util.concurrent.Executor;
import java.util.concurrent.Executors;

import javax.annotation.Resource;

import org.springframework.stereotype.Service;

import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.front.cnst.ChannelCnst;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.service.IHttpInvokeService;
import com.sfpay.front.service.IHttpReconService;
import com.sfpay.upc.util.CcbNetworkUtil;
import com.sfpay.upc.util.CmbcNetworkUtil;
import com.sfpay.upc.util.DownloadFileThread;
import com.sfpay.upc.util.NybNetworkUtil;
import com.sfpay.upc.util.WeNetworkUtil;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月27日
 */
@Service("httpInvokeService")
@HessianExporter
public class HttpInvokeServiceImpl implements IHttpInvokeService {

	private Executor EVENT_EXECUTOR = Executors.newFixedThreadPool(CharCnst.NUMBER_TEN);
	private static final String RECON_SUCCESS = "SUCCESS|成功";
	@Resource
	private IHttpReconService httpReconService;

	@Override
	public String sendAndReceiveForTrade(String channelCode, String reqMsg, Map<String, String> extMap)
			throws Exception {
		if (ChannelCnst.CHANNEL_CMBC.equals(channelCode)) {
			return CmbcNetworkUtil.sendAndReceiveForTrade(reqMsg, extMap);
		} else if (ChannelCnst.CHANNEL_WE.equals(channelCode)) {
			return WeNetworkUtil.sendAndReceiveForTrade(reqMsg, extMap);
		} else if (ChannelCnst.CHANNEL_NYB.equals(channelCode)) {
			return NybNetworkUtil.sendAndReceiveForTrade(reqMsg, extMap);
		} else if (ChannelCnst.CHANNEL_CCB.equals(channelCode)) {
			return CcbNetworkUtil.sendAndReceiveForTrade(reqMsg, extMap);
		}
		return null;
	}

	@Override
	public String sendAndReceiveForRecon(String channelCode, String reqMsg, Map<String, String> extMap)
			throws Exception {
		EVENT_EXECUTOR.execute(new DownloadFileThread(httpReconService, channelCode, reqMsg, extMap));
		return RECON_SUCCESS;
	}

}
