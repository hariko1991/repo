package com.sfpay.upc.service;

import javax.sql.rowset.serial.SerialException;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.stereotype.Service;

import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework2.remote.caucho.server.HessianExporter;
import com.sfpay.upc.util.HttpProxyHelper;

/**
 * 
 * 类说明：<br>
 * http 代理服务
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-5-3
 */
@Service
@HessianExporter("/httpProxy")
public class HttpProxyServiceImpl implements IHttpProxyService, InitializingBean {

	@Override
	public String sendByPostWithCert(String url, String meta, String certPwd, String certName) throws Exception {

		String certPath = Property.getProperty("THIRD_CERT_PATH");
		certPath = certPath + certName;
		return HttpProxyHelper.sendByPostWithCert(url, meta, certPwd, certPath);
	}

	@Override
	public String sendChannelPostWithCert(String channelType, String url, String meta, String accountNo, String certPwd)
			throws Exception {
		String certPath = null;

		if (StringUtils.isNotBlank(certPath)) {
			return HttpProxyHelper.sendByPostWithCert(url, meta, certPwd, certPath);
		} else {
			throw new SerialException("certPath is null");
		}
	}

	@Override
	public String sendByPost(String url, String meta) throws Exception {
		return HttpProxyHelper.sendByPost(url, meta, true);
	}

	@Override
	public String sendByPostNoProxy(String url, String meta) throws Exception {
		return HttpProxyHelper.sendByPost(url, meta, false);
	}

	@Override
	public String verifyAlipayId(String urlvalue) throws Exception {
		return HttpProxyHelper.httpGet(urlvalue);
	}

	@Override
	public void afterPropertiesSet() throws Exception {

	}

	@Override
	public String sendGetAccessTokenByGet(String reqUrl) throws Exception {
		return HttpProxyHelper.httpGet(reqUrl);
	}

	@Override
	public String sendByPostByJson(String url, String meta) throws Exception {
		return HttpProxyHelper.sendByPostByJson(url, meta);
	}
	
	@Override
	public String sendByPostByJson2(String url, String meta) throws Exception {
		return HttpProxyHelper.sendByPostByJson2(url, meta);
	}
}
