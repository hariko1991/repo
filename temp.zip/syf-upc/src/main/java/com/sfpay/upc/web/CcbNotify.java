package com.sfpay.upc.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSONObject;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.service.IHttpReceiveNotifyService;
import com.sfpay.upc.dto.CcbNotifyResult;

@Controller
@RequestMapping("/ccbNotify")
public class CcbNotify {
	private final Logger LOGGER = LoggerFactory.getLogger(CcbNotify.class);


	@Resource
	private IHttpReceiveNotifyService httpReceiveNotifyService;

	@RequestMapping(value = "/result")
	public void result(CcbNotifyResult notifyRlt, HttpServletRequest req , HttpServletResponse resp) throws Exception {
		String logMsg = String.format("建设银行通知结果,订单ID[%s]", notifyRlt.getORDERID());
		long startTime = System.currentTimeMillis();
		LOGGER.info("{}", logMsg);
		try {

			Map<String, String> reqMap = new HashMap<String, String>();
			reqMap.put(MapCnst.NOTIFY_DATA, JSONObject.toJSONString(notifyRlt));
			reqMap.put(MapCnst.NOTIFY_SIGN, notifyRlt.getSignStr());
			reqMap.put(MapCnst.REQ_ORDER_NO, notifyRlt.getORDERID());

			LOGGER.info("{}通知请求参数{}", logMsg, reqMap);
			httpReceiveNotifyService.notifyResult(logMsg, reqMap);
			
			resp.getOutputStream().print("success");
		} catch (IOException e) {
			LOGGER.error("反馈标识success结果给微众通道异常", e);
		} catch (Exception e) {
			LOGGER.error("解析支付通知异常", e);
		}
		
		LOGGER.info("{},UPC处理通知结果耗时：{}", logMsg, (System.currentTimeMillis() - startTime));
	}
}
