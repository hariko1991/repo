/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.upc.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.Charset;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.config.ConnectionConfig;
import org.apache.http.config.Registry;
import org.apache.http.config.RegistryBuilder;
import org.apache.http.config.SocketConfig;
import org.apache.http.conn.socket.ConnectionSocketFactory;
import org.apache.http.conn.socket.LayeredConnectionSocketFactory;
import org.apache.http.conn.socket.PlainConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.conn.ssl.TrustStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.BasicCookieStore;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.framework.config.properties.Property;
import com.sfpay.front.cnst.BankCnst;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.cnst.EncodingCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.PayCodeCnst;
import com.sfpay.front.cnst.ReconCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.dto.ReconFileDetail;
import com.sfpay.front.util.CurrencyUtil;
import com.sfpay.front.util.SfpayFileUtils;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年7月26日
 */
@SuppressWarnings("deprecation")
public final class NybNetworkUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(NybNetworkUtil.class);

	private static final String EXCHANGE_TYPE_HTTP = "http";
	private static final String EXCHANGE_TYPE_HTTPS = "https";
	private static final String CONTENT_TYPE_VALUE = "application/json;charset=UTF-8";
	private static final String CONTENT_TYPE_KEY = "Content-Type";
	private static final String HHMMSS = "000000";
	private static final List<String> WXPAY_TRADE_TYPE_LIST = Arrays.asList(new String[] {"wxPub","wxMicro"});
	private static final List<String> ALIPAY_TRADE_TYPE_LIST = Arrays.asList(new String[] {"alipayApp","alipayMicro"});
	private static final String NYB_ORDER_TYPE_1= "1";
	private static final String NYB_ORDER_TYPE_2= "2";

	public static HttpClient createAuthNonHttpClient() throws Exception {
		SocketConfig socketConfig = SocketConfig.custom().setSoTimeout(100000).build();
		RegistryBuilder<ConnectionSocketFactory> registryBuilder = RegistryBuilder.<ConnectionSocketFactory>create();
		ConnectionSocketFactory plainSF = new PlainConnectionSocketFactory();
		registryBuilder.register(EXCHANGE_TYPE_HTTP, plainSF);
		// 指定信任密钥存储对象和连接套接字工厂
		try {
			KeyStore trustStore = KeyStore.getInstance(KeyStore.getDefaultType());
			SSLContext sslContext = SSLContexts.custom().useTLS().loadTrustMaterial(trustStore, new AnyTrustStrategy())
					.build();
			LayeredConnectionSocketFactory sslSF = new SSLConnectionSocketFactory(sslContext,
					SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
			registryBuilder.register(EXCHANGE_TYPE_HTTPS, sslSF);
		} catch (Exception e) {
			LOGGER.error("南粤银行初始化連接池异常", e);
			throw e;
		}
		Registry<ConnectionSocketFactory> registry = registryBuilder.build();
		// 设置连接参数
		ConnectionConfig connConfig = ConnectionConfig.custom().setCharset(Charset.forName(EncodingCnst.UTF_8)).build();
		// 设置连接管理器
		PoolingHttpClientConnectionManager connManager = new PoolingHttpClientConnectionManager(registry);
		connManager.setDefaultConnectionConfig(connConfig);
		connManager.setDefaultSocketConfig(socketConfig);
		// 指定cookie存储对象
		BasicCookieStore cookieStore = new BasicCookieStore();
		return HttpClientBuilder.create().setDefaultCookieStore(cookieStore).setConnectionManager(connManager).build();
	}

	public static String sendAndReceiveForTrade(String reqMsg, Map<String, String> extMap) throws Exception {
		HttpResponse resp = null;
		HttpClient httpClient = createAuthNonHttpClient();
		try {
			HttpPost httpPost = new HttpPost(extMap.get(BankCnst.NETWORK_URL));
			httpPost.setConfig(getRequestConfig(extMap));
			httpPost.setHeader(CONTENT_TYPE_KEY, CONTENT_TYPE_VALUE);
			HttpEntity postEntity = new StringEntity(reqMsg, EncodingCnst.UTF_8);
			httpPost.setEntity(postEntity);
			resp = httpClient.execute(httpPost);
			HttpEntity entity = resp.getEntity();
			return EntityUtils.toString(entity);
		} catch (Exception e) {
			LOGGER.error("南粤银行发送交易{}异常", reqMsg, e);
			throw e;
		} finally {
			HttpClientUtils.closeQuietly(resp);
			HttpClientUtils.closeQuietly(httpClient);
		}
	}

	private static class AnyTrustStrategy implements TrustStrategy {
		@Override
		public boolean isTrusted(X509Certificate[] chain, String authType) throws CertificateException {
			return true;
		}

	}

	private static RequestConfig getRequestConfig(Map<String, String> extMap) {
		int readTimeOut = Integer.valueOf(extMap.get(BankCnst.READ_TIME_OUT));
		int connTimeOut = Integer.valueOf(extMap.get(BankCnst.CONN_TIME_OUT));
		return RequestConfig.custom().setSocketTimeout(readTimeOut).setConnectTimeout(connTimeOut).build();
	}

	public static void sendAndReceiveForRecon(String reqMsg, Map<String, String> extMap) throws Exception {
		String logMsg =  String.format("南粤银行,下载[%s]对账文件,支付渠道编码[%s]",extMap.get(ReconCnst.FILE_NAME), extMap.get(ReconCnst.PAY_CODE));
		List<String> dataLines = null;
		File file = null;
		InputStream inputStream = null;
		BufferedReader bufferedReader = null;
		try {
			List<String> tradeTypeList = StringUtils.equals(PayCodeCnst.PAY_CODE_WX, extMap.get(MapCnst.PAY_CODE)) 
					? WXPAY_TRADE_TYPE_LIST : ALIPAY_TRADE_TYPE_LIST;
			String localFilePath = Property.getProperty(ReconCnst.LOCAL_PATH) + extMap.get(ReconCnst.CHANNEL_CODE);
			String remoteSftpPath = Property.getProperty(ReconCnst.SFTP_PATH) + extMap.get(ReconCnst.CHANNEL_CODE);
			
			file = new File(downloadBillFile(logMsg,localFilePath, extMap));
			// 上传银行对账文件到sftp
			SFTPUtils sftpClient = new SFTPUtils(Property.getProperty(ReconCnst.SFTP_IP),
					Integer.parseInt(Property.getProperty(ReconCnst.SFTP_PORT)),
					Property.getProperty(ReconCnst.SFTP_USER), Property.getProperty(ReconCnst.SFTP_PASS), 0);

			sftpClient.upload(remoteSftpPath + "/bank/", file.getAbsolutePath());

			File clsFile = new File(localFilePath+ "/" + extMap.get(ReconCnst.FILE_NAME) );
			if (!clsFile.exists()) {
				clsFile.createNewFile();
			}
			inputStream = new FileInputStream(file);
			bufferedReader = new BufferedReader(new InputStreamReader(inputStream, EncodingCnst.UTF_8));
			String line = bufferedReader.readLine();
			LOGGER.info("{},开始解析对账文件,对账文件第一行内容[{}]",logMsg,line);
			if (StringUtils.isNotEmpty(line)) {
				dataLines = new ArrayList<String>();
				while (null != (line = bufferedReader.readLine())) {
					line = line.replaceAll(ReconCnst.ACCENT_SEPARATOR, "");
					analysisContent(line, tradeTypeList, dataLines);
					if (dataLines.size() % (ReconCnst.FILE_NUMBER_PER_WRITE + CharCnst.NUMBER_ONE) 
							== ReconCnst.FILE_NUMBER_PER_WRITE) {
						SfpayFileUtils.writeLines(clsFile, EncodingCnst.UTF_8, dataLines, Boolean.TRUE);
						dataLines.clear();
					}
				}
				if (CollectionUtils.isNotEmpty(dataLines)) {
					SfpayFileUtils.writeLines(clsFile, EncodingCnst.UTF_8, dataLines, Boolean.TRUE);
				}
				sftpClient.upload(remoteSftpPath + "/", clsFile.getAbsolutePath());
				if (clsFile.exists()) {
					SfpayFileUtils.forceDelete(clsFile);
				}
			}
			LOGGER.info("{},结束解析对账文件",logMsg);
		} catch (Exception e) {
			LOGGER.info("南粤银行下载[{}]对账文件异常", extMap.get(ReconCnst.FILE_DATE), e);
			throw e;
		} finally {
			if (inputStream != null) {
				inputStream.close();
			}
			if (bufferedReader != null) {
				bufferedReader.close();
			}
			if (file != null && file.exists()) {
				SfpayFileUtils.forceDelete(file);
			}
		}
	}
	
	private static String downloadBillFile(String logMsg ,String localFilePath , Map<String, String> extMap) throws Exception{
		localFilePath = localFilePath + "/bank/";
		File billDir = new File(localFilePath);
		if (!billDir.exists()) {
			billDir.mkdirs();
		}
		localFilePath = localFilePath + extMap.get(ReconCnst.FILE_NAME);
		LOGGER.info("{},通过SFTP方式,开始从南粤银行下载对账单文件,保存地址{}",logMsg,localFilePath);
		String bankBillFileName = extMap.get(ReconCnst.BILL_MCH_NO) + "_" + extMap.get(ReconCnst.FILE_DATE);
		SFTPUtils sftpClient = new SFTPUtils(extMap.get(BankCnst.BANK_SFTP_IP),
				Integer.parseInt(extMap.get(BankCnst.BANK_SFTP_PORT)),
				extMap.get(BankCnst.BANK_SFTP_USER), extMap.get(BankCnst.BANK_SFTP_PWD), 0);
		sftpClient.download(extMap.get(BankCnst.BANK_SFTP_URL), bankBillFileName, localFilePath);
		LOGGER.info("{},通过SFTP方式,结束从南粤银行下载对账单文件",logMsg);
		return localFilePath;
	}
	
	private static void analysisContent(String line, List<String> tradeTypeList, List<String> dataLines){
		String[] content = line.split(ReconCnst.SPLIT_COMMA_SEPARATOR);
		if(!tradeTypeList.contains(content[4])){
			return ;
		}
		if(StringUtils.isBlank(content[1])){
        	LOGGER.info("南粤银行下载对账单,渠道编码[{}],请求银行订单号为空 ,数据[{}]" , tradeTypeList.toString() , line);
			return;
		}
		ReconFileDetail fileDetail = new ReconFileDetail();
		if(content.length >= 15){
			fileDetail.setTradeTime(content[3].replaceAll(ReconCnst.LINE_SEPARATOR, "").substring(0, 8) + HHMMSS);
			fileDetail.setMerOrderNo(content[1]);
			fileDetail.setTradeSn(content[1]);
			fileDetail.setTradeStatus(StatusCnst.SUCCESS);
			if(StringUtils.equals(NYB_ORDER_TYPE_1, content[14])){
				fileDetail.setTradeType(ReconCnst.TRADE_TYPE_PAYMENT);
				fileDetail.setOrderAmt(Math.abs(CurrencyUtil.yuan2Fen(content[7].trim())));
			}else if(StringUtils.equals(NYB_ORDER_TYPE_2, content[14])){
				fileDetail.setTradeType(ReconCnst.TRADE_TYPE_REFUND);
				fileDetail.setOrderAmt(Math.abs(CurrencyUtil.yuan2Fen(content[8].trim())));
			}else{
				fileDetail.setTradeType(content[5]);
			}
			if(StringUtils.isNotBlank(content[10])){
				fileDetail.setFee( CurrencyUtil.yuan2Fen(content[10].trim()));
			}else{
				fileDetail.setFee( 0l);
			}
			fileDetail.setMerAmt((fileDetail.getOrderAmt() - fileDetail.getFee()));
			fileDetail.setOtherFee(0l);
			dataLines.add(fileDetail.toReconStr());
		}
	}
}
