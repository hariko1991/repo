/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.upc.enums;
/**
 * zookeeper 配置中心的属性枚举
 * @author 744723
 */
import com.sfpay.framework2.context.configuration.ConfigKey;

public enum ConfigKeyEnum implements ConfigKey { 
	/**
	 * http连接池开关，
	 */
	HTTP_POOL_SWITCH("HTTP_POOL_SWITCH");
	
    private ConfigKeyEnum(String key) {
        this.key = key;
    }
    
    private String key;
    
    @Override
    public String getKey() {
        return key;
    }
}
