package com.sfpay.upc.web;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.service.IHttpReceiveNotifyService;

@Controller
@RequestMapping("/upcCmbc")
public class CmbcNotify {

	private final Logger logger = LoggerFactory.getLogger(getClass());

//	@Resource
//	private IUpcPayInfoService payInfoService;
	
	@Resource
	private IHttpReceiveNotifyService httpReceiveNotifyService;

	@RequestMapping(value = "/notify")
	public void notifyByThirdPay(String bizOrderNumber, String completedTime, String mid, String srcAmt, String sign,
			HttpServletRequest req, HttpServletResponse resp) {
		
		String logMsg = String.format("接收CMBC银行回调通知 , bizOrderNumber:[%s],completedTime:[%s],mid:[%s],srcAmt:[%s],sign:[%s]", bizOrderNumber , completedTime, mid , srcAmt , sign);
		logger.info(logMsg);
		long startTime = System.currentTimeMillis();
		
		if (StringUtils.isEmpty(bizOrderNumber)) {
			logger.error("支付流水号  payNO不能为空");
			return;
		}
		if (StringUtils.isEmpty(mid)) {
			logger.error("商户号mid不能为空");
			return;
		}
		if (StringUtils.isEmpty(sign)) {
			logger.error("签名sign不能为空 ");
			return;
		}

		Map<String, String> reqMap = new HashMap<String, String>();
		reqMap.put(MapCnst.REQ_ORDER_NO, bizOrderNumber);
		reqMap.put(MapCnst.COMPLETED_TIME, completedTime);
		reqMap.put(MapCnst.MID, mid);
		reqMap.put(MapCnst.SRC_AMT, srcAmt);
		reqMap.put(MapCnst.NOTIFY_SIGN, sign);
		reqMap.put(MapCnst.BIZ_ORDER_NUMBER, bizOrderNumber);
		
		
		boolean flag =  httpReceiveNotifyService.notifyResult(logMsg, reqMap);
		
		logger.info("CMBC通知耗时为[ {} ]", (System.currentTimeMillis() - startTime));
		
		if(flag){
			writeResult(resp,"success");		
		}
	}
	
    private void writeResult(HttpServletResponse resp , String resultCode){
    	try {
			resp.getOutputStream().print(resultCode);
		} catch (IOException e) {
			logger.error("反馈标识success结果给民生通道异常", e);
		}	
    }
}
