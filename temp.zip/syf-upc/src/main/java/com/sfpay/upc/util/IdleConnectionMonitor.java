package com.sfpay.upc.util;

import java.util.HashSet;
import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.apache.http.conn.HttpClientConnectionManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * 空闲连接回收类
 * 考虑一种网络架构
 * 
 * 客户端---->防火墙---->服务端
 * 
 * 如果客户端没有空闲连接回收策略，并且服务端设置的长连接空闲时间大于防火墙的超时时间，
 * 那可能出现：服务器在回收长连接之前，防火墙已经将连接中断，由于防火墙不会通知连接双方，导致客户端认为连接仍然可用。
 * 所以，对于长连接的管理，在客户端和服务端都应该有空闲连接的回收策略和失效连接的回收策略。
 * @author 253807 2016-11-9 下午3:35:20
 * @since 1.6.0
 */
public class IdleConnectionMonitor implements Runnable
{
	private final Set<HttpClientConnectionManager> CONNECTION_MANAGERS=new HashSet<HttpClientConnectionManager>();
	private int idleTime;
	private int checkPeriod;
	private static final Logger LOGGER=LoggerFactory.getLogger(IdleConnectionMonitor.class);
	private volatile boolean shutdown=false;
	public synchronized void registHttpClientConnectionManager(HttpClientConnectionManager httpClientConnectionManager)
	{
		CONNECTION_MANAGERS.add(httpClientConnectionManager);
	}
	
	/**
	 * 启动空闲连接检测并进行回收
	 */
	@Override
	public void run()
	{
		while (!shutdown)
		{
			synchronized (this)
			{
				wait4close(checkPeriod);
				checkAndRelease();
			}
		}
	}
	
	private void checkAndRelease()
	{
		for(HttpClientConnectionManager connectionManager:CONNECTION_MANAGERS)
		{
			try
			{
				connectionManager.closeExpiredConnections();
				connectionManager.closeIdleConnections(idleTime, TimeUnit.MILLISECONDS);
			}
			catch (Exception e)
			{
				LOGGER.warn("关闭空闲连接异常",e);
			}
		}
	}
	
	public void startConnectionMonitor()
	{
		Thread thread=new Thread(this);
		thread.setDaemon(true);
		thread.setName(IdleConnectionMonitor.class.getSimpleName());
		thread.start();
		Runtime.getRuntime().addShutdownHook(new Thread(){
			@Override
			public void run()
			{
				shutdownPool();
			}
		});
	}

	public void setIdleTime(int idleTime)
	{
		this.idleTime = idleTime;
	}

	public void setCheckPeriod(int checkPeriod)
	{
		this.checkPeriod = checkPeriod;
	}
	
	/**
	 * 容器关闭时对所有连接进行回收
	 */
	public void shutdownPool()
	{
		LOGGER.info("=================begin shutdown IdleConnectionMonitor==================");
		shutdown=true;
		synchronized (this)
		{
			for(HttpClientConnectionManager connectionManager:CONNECTION_MANAGERS)
			{
				connectionManager.shutdown();
			}
		}
		LOGGER.info("=================shutdown IdleConnectionMonitor finish==================");
	}
	
	private void wait4close(long time)
	{
		try
		{
			wait(time);
		}
		catch (InterruptedException e)
		{
			LOGGER.warn("thread sleep error",e);
		}
	}

}