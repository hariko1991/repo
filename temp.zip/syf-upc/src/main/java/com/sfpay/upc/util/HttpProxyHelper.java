package com.sfpay.upc.util;

import java.io.BufferedReader;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.lang.reflect.Field;
import java.net.URI;
import java.security.KeyStore;
import java.security.cert.X509Certificate;
import java.util.Map;
import java.util.Properties;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.conn.HttpClientConnectionManager;
import org.apache.http.conn.params.ConnRouteParams;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.apache.http.ssl.SSLContexts;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.ReflectionUtils;

import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.helper.ReaderHelper;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.framework2.context.configuration.ConfigurerHolder;
import com.sfpay.framework2.http.client.HttpClientFactoryBean;
import com.sfpay.upc.enums.ConfigKeyEnum;

@SuppressWarnings({ "deprecation", "unused", "resource", "rawtypes" })
public class HttpProxyHelper {
	private static final Logger logger = LoggerFactory.getLogger(HttpProxyHelper.class);
	public static final String CHARSET = "UTF-8";
	private static String proxyHost;
	private static String port;
	private static int proxyPort = -1;
	private static int httpConnTimeout = 20000;
	private static int httpReadTimeout = 70000;
	private static int connectRequestTimeout = 3000;
	private static HttpClientFactoryBean httpClientFactoryBean=new HttpClientFactoryBean(); 
  
    /* HttpClient */  
    private static HttpClient httpClient = null;  
    
    /* 连接池最大生成连接数200 */  
    private static int Pool_MaxTotal = 300;  
  
    /* 连接池默认路由最大连接数,默认为20 */  
	private static int Pool_MaxRoute = 100;  
    
    private static int Pool_Default_MaxRoute = 50;
  
    /* 请求超时时间 */  
    private static int Request_TimeOut = 10*1000;  
    
    /* 检测时间 */ 
    private static int Check_Period= 60*1000;
      
    /* 空闲连接时间 */ 
    private static int Idle_Time= 60*1000;

	public static String sendByPostWithCert(String url, String meta, String certPwd, String certPath) throws Exception {
		return sendByPostWithCert(url, meta, CHARSET, httpConnTimeout, httpReadTimeout, certPwd, certPath);
	}

	public static String sendByPost(String url, String meta, boolean needProxy) throws Exception {
		return sendByPost(url, meta, CHARSET, needProxy);
	}

	public static String sendByPost(String url, String meta, String charset, boolean needProxy) throws Exception {
		return sendByPost(url, meta, charset, httpConnTimeout, httpReadTimeout, null, needProxy);
	}

	public static String sendByPost(String url, String meta, String charset, int conn, int read,
			Map<String, String> header, boolean needProxy) throws Exception {
		logger.info("请求url:{}, 参数:{}", url, meta);
		if (StringUtils.isEmpty(url)) {
			throw new IllegalArgumentException("URL不能为空");
		}

		String cs = StringUtils.isEmpty(charset) ? "UTF-8" : charset;
		String poolSwitch = ConfigurerHolder.get(ConfigKeyEnum.HTTP_POOL_SWITCH);
		if(StringUtils.isEmpty(poolSwitch) || "on".equalsIgnoreCase(poolSwitch))
		{
			logger.info("sendByPost,请求url:{}, http请求有连接池方法是:{}", url, "getHttpClientByPool");
			return getHttpClientByPool(url, meta, cs, conn, read, header, needProxy);
		}
		else
		{
			logger.info("sendByPost,请求url:{}, http请求有连接池方法是:{}", url, "getHttpClientByNoPool");
			return getHttpClientByNoPool(url, meta, cs, conn, read, header, needProxy);
		}
	}

	public static String sendByPostWithCert(String url, String meta, String charset, int conn, int read,
			String certPwd, String certPath) throws Exception {
		logger.info("请求url:{}, 参数:{}", url, meta);
		if (StringUtils.isEmpty(url)) {
			throw new IllegalArgumentException("URL不能为空");
		}

		String cs = StringUtils.isEmpty(charset) ? "UTF-8" : charset;
		HttpClientBuilder builder = HttpClients.custom();
		

		HttpHost proxy = null;
		HttpHost target = null;
		HttpClientContext context = null;
		logger.info(String.format("代理服务器: %s, 端口: %s, 编码: %s, URL: %s",
				new Object[] { proxyHost, Integer.valueOf(proxyPort), cs, url }));
		BasicScheme basicAuth;
		if ((!StringUtils.isEmpty(proxyHost)) && (proxyPort != -1)) {
			proxy = new HttpHost(proxyHost, proxyPort);
			URI uri = new URI(url);
			target = new HttpHost(uri.getHost(), uri.getPort(), uri.getScheme());

			CredentialsProvider provider = new BasicCredentialsProvider();
			provider.setCredentials(new AuthScope(proxyHost, proxyPort), new UsernamePasswordCredentials("", ""));
			builder.setDefaultCredentialsProvider(provider);
			AuthCache auth = new BasicAuthCache();
			basicAuth = new BasicScheme();
			auth.put(proxy, basicAuth);

			context = HttpClientContext.create();
			context.setCredentialsProvider(provider);
			context.setAuthCache(auth);
		}
		if (url.startsWith("https")) {
			builder.setSSLSocketFactory(createSSLFacoty(certPwd, certPath));
		}

		HttpPost req = new HttpPost(url);
		req.setConfig(RequestConfig.custom().setSocketTimeout(read).setConnectTimeout(conn).setProxy(proxy).build());
		req.addHeader(new BasicHeader("Content-Type", "application/x-www-form-urlencoded"));
		if (!StringUtils.isEmpty(meta)) {
			req.setEntity(new StringEntity(meta, cs));
		}

		CloseableHttpResponse resp = null;
		CloseableHttpClient client = builder.build();
		try {
			if (null == proxy)
				resp = client.execute(req);
			else {
				resp = client.execute(target, req, context);
			}
			String result = ReaderHelper.getPlain(resp.getEntity().getContent(), cs);
			logger.info("请求返回结果：{}", result);
			return result;
		} catch (Exception e) {
			logger.error("请求异常", e);
			throw e;
		} finally {
			try {
				resp.close();
				client.close();
			} catch (Exception e) {
				logger.error("关闭连接异常", e);
			}
		}
	}

	public static String httpGet(String url) throws Exception {
		if (StringUtils.isEmpty(url)) {
			throw new IllegalArgumentException("URL不能为空");
		}

		HttpClientBuilder builder = HttpClients.custom();
		// 创建HttpClient实例
		HttpClient client = new DefaultHttpClient();
		if ((!StringUtils.isEmpty(proxyHost)) && (proxyPort != -1)) {
			client = getHttpClient(proxyHost, proxyPort);
		}
		if (url.startsWith("https")) {
			builder.setSSLSocketFactory(createSSLFacoty());
		}

		StringBuffer sb = new StringBuffer();

		// 创建httpGet
		HttpGet httpGet = new HttpGet(url);
		// 执行
		try {
			HttpResponse response = client.execute(httpGet);
			HttpEntity entry = response.getEntity();
			if (entry != null) {
				InputStreamReader is = new InputStreamReader(entry.getContent(), "utf-8");
				BufferedReader br = new BufferedReader(is);
				String str = null;
				while ((str = br.readLine()) != null) {
					sb.append(str.trim());
				}
				br.close();
			}

		} catch (Exception e) {
			logger.error("httpget异常: url:[{}]" + url, e);
		}
		return sb.toString();
	}

	public static HttpClient getHttpClient(String proxyHost, int proxyPort) {

		DefaultHttpClient httpClient = new DefaultHttpClient();
		httpClient.getCredentialsProvider().setCredentials(new AuthScope(proxyHost, proxyPort),
				new UsernamePasswordCredentials("", ""));
		HttpHost proxy = new HttpHost(proxyHost, proxyPort);
		httpClient.getParams().setParameter(ConnRouteParams.DEFAULT_PROXY, proxy);
		return httpClient;
	}
	
	/**
	 * 不用连接池进行连接。
	 * @param url
	 * @param needProxy
	 * @return
	 * @throws Exception 
	 */
	private static String getHttpClientByNoPool(String url, String meta, String cs, int conn, int read,
			Map<String, String> header, boolean needProxy) throws Exception
	{
		
		HttpClientBuilder builder = HttpClients.custom();
		HttpHost proxy = null;
		HttpHost target = null;
		HttpClientContext context = null;
		if (needProxy) {
			logger.info(String.format("代理服务器: %s, 端口: %s, 编码: %s, URL: %s",
					new Object[] { proxyHost, Integer.valueOf(proxyPort), cs, url }));
			BasicScheme basicAuth;
			if ((!StringUtils.isEmpty(proxyHost)) && (proxyPort != -1)) {
				proxy = new HttpHost(proxyHost, proxyPort);
				URI uri = new URI(url);
				target = new HttpHost(uri.getHost(), uri.getPort(), uri.getScheme());

				CredentialsProvider provider = new BasicCredentialsProvider();
				provider.setCredentials(new AuthScope(proxyHost, proxyPort), new UsernamePasswordCredentials("", ""));
				builder.setDefaultCredentialsProvider(provider);
				AuthCache auth = new BasicAuthCache();
				basicAuth = new BasicScheme();
				auth.put(proxy, basicAuth);

				context = HttpClientContext.create();
				context.setCredentialsProvider(provider);
				context.setAuthCache(auth);
			}
		}
		if (url.startsWith("https")) {
			builder.setSSLSocketFactory(createSSLFacoty());
		}

		CloseableHttpResponse resp = null;
		CloseableHttpClient client = builder.build();
		
		HttpPost req = new HttpPost(url);
		req.setConfig(RequestConfig.custom().setSocketTimeout(read).setConnectTimeout(conn).build());//.setProxy(proxy)
		req.addHeader(new BasicHeader("Content-Type", "application/x-www-form-urlencoded"));
		if (!StringUtils.isEmpty(meta)) {
			req.setEntity(new StringEntity(meta, cs));
		}
		if ((null != header) && (header.size() > 0)) {
			for (Map.Entry entry : header.entrySet()) {
				req.setHeader((String) entry.getKey(), (String) entry.getValue());
			}
		}
		
		try {
			if (null == proxy)
				resp = client.execute(req);
			else {
				resp = client.execute(target, req, context);
			}
			String result = ReaderHelper.getPlain(resp.getEntity().getContent(), cs);
			logger.info("HttpClientByNoPool请求返回结果：{}", result);
			return result;
		} catch (Exception e) {
			logger.error("HttpClientByNoPool请求异常", e);
			throw e;
		}finally{
			try {
				resp.close();
				client.close();
			} catch (Exception e) {
				logger.error("HttpClientByNoPool关闭连接异常", e);
			}
		}
	}
	
	private static String getHttpClientByPool(String url, String meta, String cs, int conn, int read,
			Map<String, String> header, boolean needProxy) throws Exception
	{

		HttpResponse resp = null;
		HttpPost req = new HttpPost(url);
		req.setConfig(RequestConfig.custom().setSocketTimeout(read).setConnectTimeout(conn).build());//.setProxy(proxy)
		req.addHeader(new BasicHeader("Content-Type", "application/x-www-form-urlencoded"));
		if (!StringUtils.isEmpty(meta)) {
			req.setEntity(new StringEntity(meta, cs));
		}
		if ((null != header) && (header.size() > 0)) {
			for (Map.Entry entry : header.entrySet()) {
				req.setHeader((String) entry.getKey(), (String) entry.getValue());
			}
		}
		
		try {
				resp = httpClient.execute(req);
			String result = ReaderHelper.getPlain(resp.getEntity().getContent(), cs);
			logger.info("HttpClientByPool请求返回结果：{}", result);
			return result;
		} catch (Exception e) {
			logger.error("HttpClientByPool请求异常", e);
			
			//用短连接重新请求一次。
//			throw e; 
			return getHttpClientByNoPool(url, meta, cs, conn, read, header, needProxy);
			
		} finally {
			try {
				if(resp != null)
				{
					((CloseableHttpResponse)resp).close();
				}
				if(req != null)
				{
					req.releaseConnection();
				}
			} catch (Exception e) {
				logger.error("HttpClientByPool关闭连接异常", e);
			}
		}
	}

	private static SSLConnectionSocketFactory createSSLFacoty(String certPwd, String certPath) throws Exception {

		if (certPwd == null || certPath == null) {
			SSLContext sslcontext = SSLContexts.createDefault();

			// Allow TLSv1 protocol only
			return new SSLConnectionSocketFactory(sslcontext, new String[] { "TLSv1" }, null,
					SSLConnectionSocketFactory.getDefaultHostnameVerifier());
		}

		KeyStore keyStore = KeyStore.getInstance("PKCS12");
		FileInputStream instream = new FileInputStream(new File(certPath));// 加载本地的证书进行https加密传输
		keyStore.load(instream, certPwd.toCharArray());// 设置证书密码
		if (instream != null) {
			instream.close();
		}

		// Trust own CA and all self-signed certs
		SSLContext sslcontext = SSLContexts.custom().loadKeyMaterial(keyStore, certPwd.toCharArray()).build();
		// Allow TLSv1 protocol only
		return new SSLConnectionSocketFactory(sslcontext, new String[] { "TLSv1" }, null,
				SSLConnectionSocketFactory.getDefaultHostnameVerifier());
	}

	private static SSLConnectionSocketFactory createSSLFacoty() throws Exception {
		return createSSLFacoty(null, null);
	}
	

	static {
		
		Properties prop = System.getProperties();
		proxyHost = prop.getProperty("https.proxyHost");
		port = prop.getProperty("https.proxyPort");
		String httpConn = prop.getProperty("HTTP_CONNECT_TIMEOUT");
		String httpRedTimeOut = prop.getProperty("HTTP_READ_TIMEOUT");
		proxyPort = StringUtils.isEmpty(port) ? -1 : Integer.parseInt(port);
		httpConnTimeout = StringUtils.isEmpty(httpConn) ? httpConnTimeout : Integer.parseInt(httpConn);
		httpReadTimeout = StringUtils.isEmpty(httpRedTimeOut) ? httpReadTimeout : Integer.parseInt(httpRedTimeOut);

		String pool_maxtotal = Property.getProperty("HTTP_POOL_MAXTOTAL");
		//String pool_maxroute = Property.getProperty("HTTP_POOL_MAXROUTE");
		String pool_Default_maxroute = Property.getProperty("HTTP_POOL_Default_MAXROUTE");
		
		String CheckPeriod = Property.getProperty("Check_Period");
		String IdleTime = Property.getProperty("Idle_Time");
		
		  /*连接池总的最大生成连接数500 */  
        Pool_MaxTotal = StringUtils.isEmpty(pool_maxtotal) ? Pool_MaxTotal : Integer.parseInt(pool_maxtotal);  
  
        /* 连接池每个路由的最大连接数,默认为20 */  
       // Pool_MaxRoute = StringUtils.isEmpty(pool_maxroute) ? Pool_MaxRoute : Integer.parseInt(pool_maxroute); 
        
        /* 连接池每个路由的最大连接数,默认为20 */  
        Pool_Default_MaxRoute = StringUtils.isEmpty(pool_Default_maxroute) ? Pool_Default_MaxRoute : Integer.parseInt(pool_Default_maxroute); 
  
        /* 连接池每个路由的最大连接数,默认为20 */  
        Check_Period = StringUtils.isEmpty(CheckPeriod) ? Check_Period : Integer.parseInt(CheckPeriod); 
  
        /* 连接池每个路由的最大连接数,默认为20 */  
        Idle_Time = StringUtils.isEmpty(IdleTime) ? Idle_Time : Integer.parseInt(IdleTime); 
  
        
        /* 请求超时时间 60 * 1000 */  
        Request_TimeOut = 60000;  
        
        httpClientFactoryBean.setMaxConnTotal(Pool_MaxTotal);
        httpClientFactoryBean.setDefaultMaxConnPerRoute(Pool_Default_MaxRoute);
        httpClientFactoryBean.setConnectionRequestTimeout(connectRequestTimeout);
        httpClientFactoryBean.setConnectTimeout(httpConnTimeout);
        httpClientFactoryBean.setReadTimeout(httpReadTimeout);
        
       

        try {
			httpClient = httpClientFactoryBean.getObject();
			
			Field connManagerField = ReflectionUtils.findField(httpClient.getClass(), "connManager");
	        connManagerField.setAccessible(true);
	        HttpClientConnectionManager httpClientConnectionManager = (HttpClientConnectionManager)ReflectionUtils.getField(connManagerField, httpClient);
	        IdleConnectionMonitor connectionMonitor=new IdleConnectionMonitor();
	        connectionMonitor.setCheckPeriod(Check_Period);
	        connectionMonitor.setIdleTime(Idle_Time);
	        connectionMonitor.registHttpClientConnectionManager(httpClientConnectionManager);
	        connectionMonitor.startConnectionMonitor();
			
		} catch (Exception e) {
			logger.error("初始化httpclient出错!",e);
		}
	}
	
	public static String sendByPostByJson(String url, String meta) throws Exception {
		return sendByPostByJson(url, meta, CHARSET, httpConnTimeout, httpReadTimeout, null);
	}

	public static String sendByPostByJson2(String url, String meta) throws Exception {
		return sendByPostByJson2(url, meta, CHARSET, httpConnTimeout, httpReadTimeout, null);
	}
	/**
	 * json 格式请求HTTP
	 * @param url
	 * @param meta
	 * @param charset
	 * @param conn
	 * @param read
	 * @return
	 * @throws Exception 
	 */
	public static String sendByPostByJson(String url, String meta, String charset, int conn, int read,
			Map<String, String> header) throws Exception {
		logger.info("HttpProxyHelper.sendByPostByJson 请求url:{}, 参数:{}", url, meta);

		logger.info("请求url:{}, 参数:{}", url, meta);
		if (StringUtils.isEmpty(url)) {
			throw new IllegalArgumentException("URL不能为空");
		}

		String cs = StringUtils.isEmpty(charset) ? "UTF-8" : charset;
		HttpClientBuilder builder = HttpClients.custom();

		HttpHost proxy = null;
		HttpHost target = null;
		HttpClientContext context = null;
		logger.info(String.format("代理服务器: %s, 端口: %s, 编码: %s, URL: %s",
				new Object[] { proxyHost, Integer.valueOf(proxyPort), cs, url }));
		BasicScheme basicAuth;
		if ((!StringUtils.isEmpty(proxyHost)) && (proxyPort != -1)) {
			proxy = new HttpHost(proxyHost, proxyPort);
			URI uri = new URI(url);
			target = new HttpHost(uri.getHost(), uri.getPort(), uri.getScheme());

			CredentialsProvider provider = new BasicCredentialsProvider();
			provider.setCredentials(new AuthScope(proxyHost, proxyPort), new UsernamePasswordCredentials("", ""));
			builder.setDefaultCredentialsProvider(provider);
			AuthCache auth = new BasicAuthCache();
			basicAuth = new BasicScheme();
			auth.put(proxy, basicAuth);

			context = HttpClientContext.create();
			context.setCredentialsProvider(provider);
			context.setAuthCache(auth);
		}
		if (url.startsWith("https")) {
			builder.setSSLSocketFactory(sendJsonCreateSSLFacoty());
		}

		HttpPost req = new HttpPost(url);
		req.setConfig(RequestConfig.custom().setSocketTimeout(read).setConnectTimeout(conn).setProxy(proxy).build());
		req.addHeader(new BasicHeader("Content-Type", "application/json"));
		if (!StringUtils.isEmpty(meta)) {
			req.setEntity(new StringEntity(meta, cs));
		}

		CloseableHttpResponse resp = null;
		CloseableHttpClient client = builder.build();
		try {
			if (null == proxy)
				resp = client.execute(req);
			else {
				resp = client.execute(target, req, context);
			}
			String result = ReaderHelper.getPlain(resp.getEntity().getContent(), cs);
			logger.info("请求url:{}, 银行响应结果:{}", url, result);
			return result;
		} catch (Exception e) {
			logger.error("请求异常", e);
			throw e;
		} finally {
			try {
				if (resp != null)
					resp.close();
				if (client != null)
					client.close();
			} catch (Exception e) {
				logger.error("关闭连接异常", e);
			}
		}
	}
	
	/**
	 * json 格式请求HTTP
	 * @param url
	 * @param meta
	 * @param charset
	 * @param conn
	 * @param read
	 * @return
	 * @throws Exception 
	 */
	public static String sendByPostByJson2(String url, String meta, String charset, int conn, int read,
			Map<String, String> header) throws Exception {
		logger.info("HttpProxyHelper.sendByPostByJson 请求url:{}, 参数:{}", url, meta);

		logger.info("请求url:{}, 参数:{}", url, meta);
		if (StringUtils.isEmpty(url)) {
			throw new IllegalArgumentException("URL不能为空");
		}

		String cs = StringUtils.isEmpty(charset) ? "UTF-8" : charset;
		HttpClientBuilder builder = HttpClients.custom();

		HttpHost proxy = null;
		HttpHost target = null;
		HttpClientContext context = null;
		logger.info(String.format("代理服务器: %s, 端口: %s, 编码: %s, URL: %s",
				new Object[] { proxyHost, Integer.valueOf(proxyPort), cs, url }));
		BasicScheme basicAuth;
		if ((!StringUtils.isEmpty(proxyHost)) && (proxyPort != -1)) {
			proxy = new HttpHost(proxyHost, proxyPort);
			URI uri = new URI(url);
			target = new HttpHost(uri.getHost(), uri.getPort(), uri.getScheme());

			CredentialsProvider provider = new BasicCredentialsProvider();
			provider.setCredentials(new AuthScope(proxyHost, proxyPort), new UsernamePasswordCredentials("", ""));
			builder.setDefaultCredentialsProvider(provider);
			AuthCache auth = new BasicAuthCache();
			basicAuth = new BasicScheme();
			auth.put(proxy, basicAuth);

			context = HttpClientContext.create();
			context.setCredentialsProvider(provider);
			context.setAuthCache(auth);
		}
		if (url.startsWith("https")) {
			builder.setSSLSocketFactory(sendJsonCreateSSLFacoty());
		}

		HttpPost req = new HttpPost(url);
		req.setConfig(RequestConfig.custom().setSocketTimeout(read).setConnectTimeout(conn).setProxy(proxy).build());
		req.addHeader(new BasicHeader("Content-Type", "application/json"));
		if (!StringUtils.isEmpty(meta)) {
			req.setEntity(new StringEntity(meta, cs));
		}

		CloseableHttpResponse resp = null;
		CloseableHttpClient client = builder.build();
		try {
			if (null == proxy)
				resp = client.execute(req);
			else {
				resp = client.execute(target, req, context);
			}
			
			//BufferedReader bf = ReaderHelper.getReader(resp.getEntity().getContent(), cs);
			InputStream resStream = null ;
			ByteArrayOutputStream ms = null;
			String respText=null;
			ms = new ByteArrayOutputStream();
			resStream = resp.getEntity().getContent();
			byte[] buf = new byte[4096];
			int count;
			while ((count = resStream.read(buf, 0, buf.length)) > 0)
			{
				ms.write(buf, 0, count);
			}
			resStream.close();
			respText = new String(ms.toByteArray(), "UTF-8");
			return respText;
		} catch (Exception e) {
			logger.error("请求异常", e);
			throw e;
		} finally {
			try {
				if (resp != null)
					resp.close();
				if (client != null)
					client.close();
			} catch (Exception e) {
				logger.error("关闭连接异常", e);
			}
		}
	}

	private static SSLConnectionSocketFactory sendJsonCreateSSLFacoty() throws Exception {
		X509TrustManager x509mgr = new X509TrustManager() {
			public void checkClientTrusted(X509Certificate[] xcs, String string) {
			}

			public void checkServerTrusted(X509Certificate[] xcs, String string) {
			}

			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}
		};
		SSLContext ctx = SSLContext.getInstance("TLS");
		ctx.init(null, new TrustManager[] { x509mgr }, null);
		return new SSLConnectionSocketFactory(ctx, SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
	}

}
