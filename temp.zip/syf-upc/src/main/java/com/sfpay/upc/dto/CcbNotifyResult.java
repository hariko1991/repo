package com.sfpay.upc.dto;

import org.apache.commons.lang3.StringUtils;

import com.sfpay.framework.base.entity.BaseEntity;

public class CcbNotifyResult extends BaseEntity {
	private static final long serialVersionUID = -9168556888020017402L;
	// 商户柜台代码
	private String POSID;
	// 分行代码
	private String BRANCHID;
	// 定单号，是商户订单号也是建行订单号。
	private String ORDERID;
	// 付款金额
	private String PAYMENT;
	// 币种
	private String CURCODE;
	// 备注一
	private String REMARK1;
	// 备注2
	private String REMARK2;
	// 账户类型30：表示信用卡
	private String ACC_TYPE;
	// 成功标志成功－Y，失败－N
	private String SUCCESS;
	// 接口类型1- 防钓鱼接口
	private String TYPE;
	// Referer信息
	private String REFERER;
	// 客户端IP
	private String CLIENTIP;

	// 系统记账日期
	// 商户主管在商户后台设置返回记账日期时返回该字且参与验签，字段格式为YYYYMMDD（如20100907），未设置时无此
	private String ACCDATE;

	// 支付账户信息
	// 业务人员在ECTIP后台设置返回账户信息的开关且支付成功时将返回账户加密信息且该字段参与验签，否则无此字段返回且不参与验签，格式如下：“姓名|账号”
	private String USRMSG;

	// 分期期数
	private String INSTALLNUM;

	// 错误信息
	// 该值默认返回为空，商户无需处理，仅需参与验签即可。当有分期期数返回时，则有ERRMSG字段返回且参与验签，否则无此字段返回且不参与验签
	private String ERRMSG;

	// 客户加密信息
	// 业务人员在ECTIP后台设置客户信息加密返回的开关且该字段参与验签，否则无此字段返回且不参与验签，格式如下：“证件号密文|手机号密文”。该字段不可解密。
	private String USRINFO;

	// 优惠金额
	// 客户实际支付的金额。仅对配置了商户号的商户返回，参与延签。其他商户不返回该字段，不参与延签
	private String DISCOUNT;
	private String SIGN;

	public String getPOSID() {
		return POSID;
	}

	public String getBRANCHID() {
		return BRANCHID;
	}

	public void setBRANCHID(String bRANCHID) {
		BRANCHID = bRANCHID;
	}

	public String getORDERID() {
		return ORDERID;
	}

	public void setORDERID(String oRDERID) {
		ORDERID = oRDERID;
	}

	public String getPAYMENT() {
		return PAYMENT;
	}

	public void setPAYMENT(String pAYMENT) {
		PAYMENT = pAYMENT;
	}

	public String getCURCODE() {
		return CURCODE;
	}

	public void setCURCODE(String cURCODE) {
		CURCODE = cURCODE;
	}

	public String getREMARK1() {
		return REMARK1;
	}

	public void setREMARK1(String rEMARK1) {
		REMARK1 = rEMARK1;
	}

	public String getREMARK2() {
		return REMARK2;
	}

	public void setREMARK2(String rEMARK2) {
		REMARK2 = rEMARK2;
	}

	public String getACC_TYPE() {
		return ACC_TYPE;
	}

	public void setACC_TYPE(String aCC_TYPE) {
		ACC_TYPE = aCC_TYPE;
	}

	public String getSUCCESS() {
		return SUCCESS;
	}

	public void setSUCCESS(String sUCCESS) {
		SUCCESS = sUCCESS;
	}

	public String getTYPE() {
		return TYPE;
	}

	public void setTYPE(String tYPE) {
		TYPE = tYPE;
	}

	public String getREFERER() {
		return REFERER;
	}

	public void setREFERER(String rEFERER) {
		REFERER = rEFERER;
	}

	public String getCLIENTIP() {
		return CLIENTIP;
	}

	public void setCLIENTIP(String cLIENTIP) {
		CLIENTIP = cLIENTIP;
	}

	public String getACCDATE() {
		return ACCDATE;
	}

	public void setACCDATE(String aCCDATE) {
		ACCDATE = aCCDATE;
	}

	public String getUSRMSG() {
		return USRMSG;
	}

	public void setUSRMSG(String uSRMSG) {
		USRMSG = uSRMSG;
	}

	public String getINSTALLNUM() {
		return INSTALLNUM;
	}

	public void setINSTALLNUM(String iNSTALLNUM) {
		INSTALLNUM = iNSTALLNUM;
	}

	public String getERRMSG() {
		return ERRMSG;
	}

	public void setERRMSG(String eRRMSG) {
		ERRMSG = eRRMSG;
	}

	public String getUSRINFO() {
		return USRINFO;
	}

	public void setUSRINFO(String uSRINFO) {
		USRINFO = uSRINFO;
	}

	public String getDISCOUNT() {
		return DISCOUNT;
	}

	public void setDISCOUNT(String dISCOUNT) {
		DISCOUNT = dISCOUNT;
	}

	public String getSIGN() {
		return SIGN;
	}

	public void setSIGN(String sIGN) {
		SIGN = sIGN;
	}

	public void setPOSID(String pOSID) {
		POSID = pOSID;
	}

	public String getSignStr() {
		// 进行拼装签名参数。
		StringBuffer sb = new StringBuffer();
		// 请注意ACC_TYPE、ACCDATE、USRMSG、INSTALLNUM、ERRMSG、USRINFO、DISCOUNT只有在满足条件的情况下才参与签名。
		// POSID=000000000&BRANCHID=110000000&ORDERID=19991101234&PAYMENT=500.00
		// &CURCODE=01&REMARK1=&REMARK2=&ACC_TYPE=12&SUCCESS=Y
		// &TYPE=1&REFERER=http://www.ccb.com/index.jsp&CLIENTIP=172.0.0.1
		// &ACCDATE=20100907&USRMSG=T4NJx%2FVgocRsLyQnrMZLyuQQkFzMAxQjdqyzf6pM%2Fcg%3D
		// &INSTALLNUM=3&ERRMSG=
		// &USRINFO=
		// T4NJx%2FVgocRsLyQnrMZLyuQQkFzMAxQjdqyzf6pM%2Fcg%3D&DISCOUNT=1.00

		sb.append("POSID=").append(this.getPOSID()).append("&BRANCHID=")
				.append(this.getBRANCHID()).append("&ORDERID=")
				.append(this.getORDERID()).append("&PAYMENT=")
				.append(this.getPAYMENT()).append("&CURCODE=")
				.append(this.getCURCODE()).append("&REMARK1=")
				.append(this.getREMARK1()).append("&REMARK2=")
				.append(this.getREMARK2());

		if (!StringUtils.isEmpty(this.getACC_TYPE())) {
			sb.append("&ACC_TYPE=").append(this.getACC_TYPE());
		}

		sb.append("&SUCCESS=").append(this.getSUCCESS()).append("&TYPE=")
				.append(this.getTYPE()).append("&REFERER=")
				.append(this.getREFERER()).append("&CLIENTIP=")
				.append(this.getCLIENTIP()).append("&ACCDATE=")
				.append(this.getACCDATE());

//		if (StringUtils.isNotBlank(this.getACCDATE())) {
//			sb.append("&ACCDATE=").append(this.getACCDATE());
//		}

		if (StringUtils.isNotBlank(this.getUSRMSG())) {
			sb.append("&USRMSG=").append(this.getUSRMSG());
		}

		if (StringUtils.isNotBlank(this.getINSTALLNUM())) {
			sb.append("&INSTALLNUM=").append(this.getINSTALLNUM());
		}

		if (StringUtils.isNotBlank(this.getERRMSG())) {
			sb.append("&ERRMSG=").append(this.getERRMSG());
		}

		if (StringUtils.isNotBlank(this.getUSRINFO())) {
			sb.append("&USRINFO=").append(this.getUSRINFO());
		}

		if (StringUtils.isNotBlank(this.getDISCOUNT())) {
			sb.append("&DISCOUNT=").append(this.getDISCOUNT());
		}
		return sb.toString();
	}
}
