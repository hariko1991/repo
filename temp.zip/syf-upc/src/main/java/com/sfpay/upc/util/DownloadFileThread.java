/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.upc.util;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.front.cnst.ChannelCnst;
import com.sfpay.front.cnst.ReconCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.service.IHttpReconService;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月7日
 */
public class DownloadFileThread implements Runnable {
	private static final Logger LOGGER = LoggerFactory.getLogger(DownloadFileThread.class);
	private String channelCode;
	private String reqMsg;
	private Map<String, String> extMap;
	private IHttpReconService httpReconService;

	public DownloadFileThread(IHttpReconService httpReconService, String channelCode, String reqMsg,
			Map<String, String> extMap) {
		super();
		this.httpReconService = httpReconService;
		this.channelCode = channelCode;
		this.reqMsg = reqMsg;
		this.extMap = extMap;
	}

	@Override
	public void run() {
		Map<String, String> updateMap = new HashMap<String, String>();
		updateMap.put(SqlCnst.ORIGINAL_STATUS, ReconCnst.RECON_STATUS_INIT);
		updateMap.put(ReconCnst.BILL_MCH_NO, extMap.get(ReconCnst.BILL_MCH_NO));
		updateMap.put(ReconCnst.FILE_DATE, extMap.get(ReconCnst.FILE_DATE));
		updateMap.put(ReconCnst.PAY_CODE, extMap.get(ReconCnst.PAY_CODE));

		try {
			if (ChannelCnst.CHANNEL_CMBC.equals(channelCode)) {
				updateMap.put(SqlCnst.CHANNEL_CODE, ChannelCnst.CHANNEL_CMBC);
				CmbcNetworkUtil.sendAndReceiveForRecon(reqMsg, extMap);
			} else if (ChannelCnst.CHANNEL_WE.equals(channelCode)) {
				updateMap.put(SqlCnst.CHANNEL_CODE, ChannelCnst.CHANNEL_WE);
				WeNetworkUtil.sendAndReceiveForRecon(reqMsg, extMap);
			} else if (ChannelCnst.CHANNEL_NYB.equals(channelCode)) {
				updateMap.put(SqlCnst.CHANNEL_CODE, ChannelCnst.CHANNEL_NYB);
				NybNetworkUtil.sendAndReceiveForRecon(reqMsg, extMap);
			} 
			updateMap.put(SqlCnst.TARGET_STATUS, ReconCnst.RECON_STATUS_DOWNLOAD);
		} catch (Exception e) {
			updateMap.put(SqlCnst.TARGET_STATUS, ReconCnst.RECON_STATUS_FAILURE);
			updateMap.put(SqlCnst.REMARK, e.getMessage());
			LOGGER.error("通道["+channelCode+"]下载文件异常 , 需要更新结果参数updateMap[{}]", updateMap, e);
		}
		try {
			httpReconService.updateChannelReconFile("", updateMap);
		} catch (Exception e) {
			LOGGER.error("通道[{}]下载文件成功,通知核心异常", channelCode, e);
		}
	}

}
