package com.sfpay.upc.web;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.alibaba.fastjson.JSONObject;
import com.sfpay.front.cnst.ChannelCnst;
import com.sfpay.front.cnst.EncodingCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.ReconCnst;
import com.sfpay.front.cnst.SqlCnst;
import com.sfpay.front.service.IHttpReceiveNotifyService;
import com.sfpay.front.service.IHttpReconService;

/**
 * 
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年6月6日
 */
@Controller
@RequestMapping("/weNotify")
public class WeNotify {
	private final Logger LOGGER = LoggerFactory.getLogger(WeNotify.class);
	private static final String DATA = "data";
	private static final String TOKEN = "token";
	private static final String FILE_ID = "file_id";
	private static final String WORK_DATE = "work_date";
	private static final String AND_SYMBOL = "&";
	private static final String EQUAL = "=";
	private static final String AGENCY_ID = "agency_id";
	private static final String DEST_U = "202";
	private static final String SRC_U = "U";
	private static final String DEST_B = "203";
	private static final String SRC_B = "B";
	private static final String APP_ID = "app_id";
	private static final String TYPE = "type";
	private static final String TOKEN_TICKET_CHANGE = "TOKEN_TICKET_CHANGE";

	@Resource
	private IHttpReconService httpReconService;

	@Resource
	private IHttpReceiveNotifyService httpReceiveNotifyService;

	@RequestMapping(value = "/result")
	public void result(String nonce_str, String timestamp, String sign, HttpServletRequest req , HttpServletResponse resp) throws Exception {
		String logMsg = String.format("微众银行通知结果,随机字符串[%s],时间戳[%s]", nonce_str, timestamp);
		long startTime = System.currentTimeMillis();
		LOGGER.info("{}签名串[{}]", logMsg, sign);
		try {
			String respJson = getReqJson(req);
			LOGGER.info("{}请求内容[{}]", logMsg, respJson);
			JSONObject rtnObj = JSONObject.parseObject(respJson);
			JSONObject dataObj = JSONObject.parseObject(rtnObj.getString(DATA));
			
			Map<String, String> reqMap = new HashMap<String, String>();
			reqMap.put(MapCnst.NOTIFY_NONCE_STR, nonce_str);
			reqMap.put(MapCnst.NOTIFY_TIMESTAMP, timestamp);
			if(!TOKEN_TICKET_CHANGE.equals(rtnObj.getString(TYPE))){
				reqMap.put(MapCnst.NOTIFY_SIGN, sign);
				reqMap.put(MapCnst.NOTIFY_DATA, rtnObj.getString(DATA));
	
				reqMap.put(MapCnst.REQ_ORDER_NO, dataObj.getString(MapCnst.ORDER_ID));
	
				LOGGER.info("{},通知支付请求参数{}", logMsg, reqMap);
				httpReceiveNotifyService.notifyResult(logMsg, reqMap);
			}else{
				reqMap.put(MapCnst.NOTIFY_DATA, rtnObj.getString(DATA));
				LOGGER.info("{},通知秘钥改变请求参数{}", logMsg, reqMap);
				httpReceiveNotifyService.notifySecretKeyChange(logMsg, reqMap);
			}
			resp.getOutputStream().print("success");
		} catch (IOException e) {
			LOGGER.error("反馈标识success结果给微众通道异常", e);
		} catch (Exception e) {
			LOGGER.error("解析支付通知异常", e);
		}
		
		LOGGER.info("{},UPC处理通知结果耗时：{}", logMsg, (System.currentTimeMillis() - startTime));
	}

	private String getReqJson(HttpServletRequest req) throws UnsupportedEncodingException, IOException {
		// 读取请求内容
		StringBuilder sb = null;
		BufferedReader br = null;
		try {
			br = new BufferedReader(new InputStreamReader(req.getInputStream(), EncodingCnst.UTF_8));
			String line = null;
			sb = new StringBuilder();
			while ((line = br.readLine()) != null) {
				sb.append(line);
			}
		} finally {
			br.close();
		}
		// 将资料解码
		String respJson = sb.toString();
		return respJson;
	}

	@RequestMapping(value = "/bill")
	public void bill(String nonce_str, String timestamp, String sign, HttpServletRequest req , HttpServletResponse resp) throws Exception {
		String logMsg = String.format("微众银行对账单,随机字符串[%s],时间戳[%s]", nonce_str, timestamp);
		LOGGER.info("{}签名串[{}]", logMsg, sign);
		String respJson = getReqJson(req);
		LOGGER.info("{}请求内容[{}]", logMsg, respJson);
		JSONObject rtnObj = JSONObject.parseObject(respJson);
		JSONObject dataObj = JSONObject.parseObject(rtnObj.getString(DATA));
		StringBuilder extArg = new StringBuilder("").append(TOKEN).append(EQUAL).append(dataObj.getString(TOKEN))
				.append(AND_SYMBOL).append(FILE_ID).append(EQUAL).append(dataObj.getString(FILE_ID));

		Map<String, String> updateMap = new HashMap<String, String>();
		updateMap.put(SqlCnst.CHANNEL_CODE, ChannelCnst.CHANNEL_WE);
		updateMap.put(SqlCnst.ORIGINAL_STATUS, ReconCnst.RECON_STATUS_INIT);
		updateMap.put(ReconCnst.EXT_ARG, extArg.toString());
		updateMap.put(ReconCnst.FILE_DATE, dataObj.getString(WORK_DATE));
		if (StringUtils.isNotEmpty(dataObj.getString(AGENCY_ID))) {
			updateMap.put(ReconCnst.BILL_MCH_NO, dataObj.getString(AGENCY_ID));
		} else {
			updateMap.put(ReconCnst.BILL_MCH_NO,
					dataObj.getString(APP_ID).replace(SRC_U, DEST_U).replace(SRC_B, DEST_B));
		}
		LOGGER.info("{}通知请求参数{}", logMsg, updateMap);
		try{
			httpReconService.updateChannelReconFile(logMsg, updateMap);
			resp.getOutputStream().print("success");
			LOGGER.info("{}通知结束", logMsg);
		}catch (Exception e) {
			LOGGER.error("{}通知处理异常",logMsg,e);
		}
	}
}
