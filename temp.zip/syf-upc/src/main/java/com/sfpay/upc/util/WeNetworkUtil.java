/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.upc.util;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.PrintWriter;
import java.security.KeyStore;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;

import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.conn.ssl.SSLContexts;
import org.apache.http.conn.ssl.TrustSelfSignedStrategy;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.framework.config.properties.Property;
import com.sfpay.front.cnst.BankCnst;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.cnst.EncodingCnst;
import com.sfpay.front.cnst.MapCnst;
import com.sfpay.front.cnst.PayCodeCnst;
import com.sfpay.front.cnst.ReconCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.dto.ReconFileDetail;
import com.sfpay.front.util.CurrencyUtil;
import com.sfpay.front.util.SfpayFileUtils;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月27日
 */
@SuppressWarnings("deprecation")
public final class WeNetworkUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(WeNetworkUtil.class);

	private static final String TRUST_STORE = "JKS";
	private static final String KEY_STORE = "PKCS12";
	private static SSLConnectionSocketFactory SSL_CONNECTION_SOCKET_FACTORY = null;
	private static final String SSL_SOCKET_FACTORY_TYPE = "TLSv1";
	private static final String CONTENT_TYPE = "application/json;charset=UTF-8";

	private static final String WX_PAYMENT = "消费";
	private static final String WX_REFUND = "退货";

	private static final String ALIPAY_PAYMENT = "01";
	private static final String ALIPAY_REFUND = "02";

	private static final String HHMMSS = "000000";
	private static final String NO_CHECK_CERTIFICATE = " --no-check-certificate";
	private static final String REPLACE_QUOTA_CHAR = "`";

	private static SSLConnectionSocketFactory initSslConnectionSocketFactory(Map<String, String> extMap)
			throws Exception {
		// 此处加入https双向认证
		KeyStore keyStore = KeyStore.getInstance(KEY_STORE);
		KeyStore trustStore = KeyStore.getInstance(TRUST_STORE);

		InputStream keyStoreIn = new FileInputStream(extMap.get(BankCnst.PATH) + extMap.get(BankCnst.JKS));
		InputStream trustStoreIn = new FileInputStream(extMap.get(BankCnst.PATH) + extMap.get(BankCnst.TRUST));
		char[] clientPassArray = extMap.get(BankCnst.CLIENT_PASS).toCharArray();
		char[] serverPassArray = extMap.get(BankCnst.SERVER_PASS).toCharArray();

		try {
			keyStore.load(keyStoreIn, clientPassArray);
			trustStore.load(trustStoreIn, serverPassArray);
		} finally {
			keyStoreIn.close();
			trustStoreIn.close();
		}

		SSLContext sslcontext = null;
		sslcontext = SSLContexts.custom().loadKeyMaterial(keyStore, clientPassArray)
				.loadTrustMaterial(trustStore, new TrustSelfSignedStrategy()).build();

		SSLConnectionSocketFactory factory = new SSLConnectionSocketFactory(sslcontext,
				new String[] { SSL_SOCKET_FACTORY_TYPE }, null,
				SSLConnectionSocketFactory.getDefaultHostnameVerifier());

		return factory;
	}

	public static String sendAndReceiveForTrade(String reqMsg, Map<String, String> extMap) throws Exception {
		if (null == SSL_CONNECTION_SOCKET_FACTORY) {
			synchronized (WeNetworkUtil.class) {
				if (null == SSL_CONNECTION_SOCKET_FACTORY) {
					SSL_CONNECTION_SOCKET_FACTORY = initSslConnectionSocketFactory(extMap);
				}
			}
		}

		CloseableHttpClient httpclient = HttpClients.custom().setSSLSocketFactory(SSL_CONNECTION_SOCKET_FACTORY)
				.build();

		HttpResponse response = null;
		if (CharCnst.EXCHANGE_TYPE_GET.equals(extMap.get(BankCnst.EXCHANGE_TYPE))) {
			HttpGet httpGet = new HttpGet(extMap.get(BankCnst.ACTUAL_NETWORK_URL));
			httpGet.setConfig(getRequestConfig(extMap));
			response = httpclient.execute(httpGet);
		} else if (CharCnst.EXCHANGE_TYPE_POST.equals(extMap.get(BankCnst.EXCHANGE_TYPE))) {
			HttpPost httpPost = new HttpPost(extMap.get(BankCnst.ACTUAL_NETWORK_URL));
			httpPost.setConfig(getRequestConfig(extMap));
			StringEntity reqEntity = new StringEntity(reqMsg, EncodingCnst.UTF_8);
			reqEntity.setContentType(CONTENT_TYPE);
			httpPost.setEntity(reqEntity);

			response = httpclient.execute(httpPost);
		}

		HttpEntity entity = response.getEntity();

		return EntityUtils.toString(entity, EncodingCnst.UTF_8).trim();
	}

	public static void sendAndReceiveForRecon(String reqMsg, Map<String, String> extMap) throws Exception {
		// downloadByHttps(extMap); //用https线上下载
		String localFullName = Property.getProperty(ReconCnst.LOCAL_PATH) + extMap.get(ReconCnst.CHANNEL_CODE) + "/"
				+ extMap.get(ReconCnst.FILE_NAME);
		File convertFullFile = new File(localFullName);

		if (convertFullFile.exists()) {
			SfpayFileUtils.forceDelete(convertFullFile);
		}

		downloadByWget(extMap, convertFullFile);// 用linux命令下的wget去下载
	}

	private static void downloadByWget(Map<String, String> extMap, File convertFullFile) throws Exception {
		LOGGER.info("微众银行下载[{}]对账文件方式為[wget]", extMap.get(ReconCnst.FILE_DATE));

		File bankFullDir = new File(
				Property.getProperty(ReconCnst.LOCAL_PATH) + extMap.get(ReconCnst.CHANNEL_CODE) + "/bank/");
		if (bankFullDir.mkdirs()) {
			LOGGER.info("微众银行下载[{}]对账文件方式為[wget]创建文件目录[{}]成功", extMap.get(ReconCnst.FILE_DATE),
					bankFullDir.getAbsolutePath());
		} else {
			LOGGER.info("微众银行下载[{}]对账文件方式為[wget]创建文件目录[{}]已存在", extMap.get(ReconCnst.FILE_DATE),
					bankFullDir.getAbsolutePath());
		}
		String bankFullName = Property.getProperty(ReconCnst.LOCAL_PATH) + extMap.get(ReconCnst.CHANNEL_CODE) + "/bank/"
				+ extMap.get(ReconCnst.FILE_NAME);
		File bankFullFile = new File(bankFullName);

		if (bankFullFile.exists()) {
			SfpayFileUtils.forceDelete(bankFullFile);
		}

		String crtFullPath = extMap.get(BankCnst.PATH) + extMap.get(BankCnst.CRT);
		String keyFullPath = extMap.get(BankCnst.PATH) + extMap.get(BankCnst.KEY);
		// wget -O %s -c --certificate=%s --certificate-type=PEM
		// --private-key=%s --private-key-type=PEM "%s"
		String shellScript = String.format(extMap.get(BankCnst.SHELL_SCRIPT), bankFullName, crtFullPath, keyFullPath,
				extMap.get(BankCnst.ACTUAL_NETWORK_URL));

		if (BankCnst.ENV_TEST.equals(extMap.get(BankCnst.ENV))) {
			shellScript = shellScript + NO_CHECK_CERTIFICATE;
		}
		LOGGER.info("微众银行下载[{}]对账文件方式為[wget],脚本命令为[{}]", extMap.get(ReconCnst.FILE_DATE), shellScript);

		Process process = null;
		PrintWriter out = null;
		try {
			ProcessBuilder pb = new ProcessBuilder(extMap.get(BankCnst.BIN_ENV));
			process = pb.start();
			// 获取输出流，可以通过它向SHELL发送命令。
			out = new PrintWriter(new BufferedWriter(new OutputStreamWriter(process.getOutputStream())), true);
			out.println(shellScript);
			out.println("exit");

			new FlushStreamHandler(process.getErrorStream()).start();
			new FlushStreamHandler(process.getInputStream()).start();

			int wf = process.waitFor();
			LOGGER.info("下微众银行下载[{}]对账文件方式為[wget]命令执行完毕.", extMap.get(ReconCnst.FILE_DATE));
			if (wf != 0) {
				LOGGER.error("下微众银行下载[{}]对账文件方式為[wget]命令执行完毕, waitFor值: [{}]", extMap.get(ReconCnst.FILE_DATE), wf);
				throw new Exception("下载文件结果值:" + wf);
			}

			LOGGER.info("微众银行下载[{}]对账文件方式為[wget]下载完成", extMap.get(ReconCnst.FILE_DATE));
		} catch (Exception e) {
			LOGGER.error("微众银行下载[{}]对账文件方式為[wget]异常", extMap.get(ReconCnst.FILE_DATE), e);
			throw e;
		} finally {
			out.close();
			process.destroy();
		}

		try {
			convertToLocalFile(extMap, new FileInputStream(bankFullFile), convertFullFile, bankFullFile);
		} catch (Exception e) {
			LOGGER.error("微众银行下载[{}]对账文件方式為[wget]转换文件异常", extMap.get(ReconCnst.FILE_DATE), e);
			throw e;
		} finally {
			if (bankFullFile.exists()) {
				SfpayFileUtils.forceDelete(bankFullFile);
			}

		}
	}
	
	public static void downloadByHttps(Map<String, String> extMap, File convertFullFile)
			throws Exception, IOException, ClientProtocolException {
		LOGGER.info("微众银行下载[{}]对账文件方式為[https]", extMap.get(ReconCnst.FILE_DATE));
		if (null == SSL_CONNECTION_SOCKET_FACTORY) {
			synchronized (WeNetworkUtil.class) {
				if (null == SSL_CONNECTION_SOCKET_FACTORY) {
					SSL_CONNECTION_SOCKET_FACTORY = initSslConnectionSocketFactory(extMap);
				}
			}
		}

		CloseableHttpClient httpClient = HttpClients.custom().setSSLSocketFactory(SSL_CONNECTION_SOCKET_FACTORY)
				.build();

		HttpGet httpGet = new HttpGet(extMap.get(BankCnst.ACTUAL_NETWORK_URL));
		httpGet.setConfig(getRequestConfig(extMap));

		HttpResponse response = httpClient.execute(httpGet);
		HttpEntity entity = response.getEntity();

		convertToLocalFile(extMap, entity.getContent(), convertFullFile, null);
	}

	private static void convertToLocalFile(Map<String, String> extMap, InputStream inputStream, File convertFullFile,
			File bankFullFile) throws IOException, Exception {
		List<String> localLines = new ArrayList<String>();

		String encoding = EncodingCnst.UTF_8;

		BufferedReader bufferedReader = null;
		try {
			SFTPUtils sftpClient = new SFTPUtils(Property.getProperty(ReconCnst.SFTP_IP),
					Integer.parseInt(Property.getProperty(ReconCnst.SFTP_PORT)),
					Property.getProperty(ReconCnst.SFTP_USER), Property.getProperty(ReconCnst.SFTP_PASS), 0);
			String remoteBankSftpPath = Property.getProperty(ReconCnst.SFTP_PATH) + extMap.get(ReconCnst.CHANNEL_CODE)
					+ "/bank/";
			if (null != bankFullFile) {
				sftpClient.upload(remoteBankSftpPath, bankFullFile.getAbsolutePath());
			}

			String payCode = extMap.get(MapCnst.PAY_CODE);
			bufferedReader = new BufferedReader(new InputStreamReader(inputStream, encoding));
			String line = bufferedReader.readLine();
			LOGGER.info("微众银行下载[{}],渠道类型[{}],编码[{}],对账文件第一行内容[{}]",
					new Object[] { extMap.get(ReconCnst.FILE_DATE),payCode, encoding, line });
			if (StringUtils.isNotEmpty(line)) {
				while (null != (line = bufferedReader.readLine())) {
					convertToReconFile(localLines, line , payCode);
					if (localLines.size() % (ReconCnst.FILE_NUMBER_PER_WRITE
							+ CharCnst.NUMBER_ONE) == ReconCnst.FILE_NUMBER_PER_WRITE) {
						SfpayFileUtils.writeLines(convertFullFile, EncodingCnst.UTF_8, localLines, Boolean.TRUE);
						localLines = new ArrayList<String>();
					}
				}
				if (CollectionUtils.isNotEmpty(localLines)) {
					SfpayFileUtils.writeLines(convertFullFile, EncodingCnst.UTF_8, localLines, Boolean.TRUE);
				}

				String remoteSftpPath = Property.getProperty(ReconCnst.SFTP_PATH) + extMap.get(ReconCnst.CHANNEL_CODE)
						+ "/";

				sftpClient.upload(remoteSftpPath, convertFullFile.getAbsolutePath());
				if (convertFullFile.exists()) {
					SfpayFileUtils.forceDelete(convertFullFile);
				}
			}
		} catch (Exception e) {
			LOGGER.info("微众银行下载[{}]对账文件异常", extMap.get(ReconCnst.FILE_DATE), e);
			throw e;
		} finally {
			bufferedReader.close();
		}
	}

	private static void convertToReconFile(List<String> localLines, String line , String payCode) {
		String[] content = line.split(ReconCnst.SPLIT_COMMA_SEPARATOR);
		if (PayCodeCnst.PAY_CODE_WX.equals(payCode) && content.length >= 12) {
			ReconFileDetail fileDetail = new ReconFileDetail();
			fileDetail.setTradeTime(content[0] + HHMMSS);
			fileDetail.setMerOrderNo(content[6]);
			fileDetail.setTradeSn(content[6]);

			fileDetail.setOrderAmt(CurrencyUtil.yuan2Fen(content[9].trim()));
			fileDetail.setMerAmt(CurrencyUtil.yuan2Fen(content[11].trim()));
			if (WX_PAYMENT.equals(content[5])) {
				fileDetail.setTradeType(ReconCnst.TRADE_TYPE_PAYMENT);
			} else if (WX_REFUND.equals(content[5])) {
				if(StringUtils.isBlank(content[6])){
		        	LOGGER.info("微众银行下载对账单,渠道编码[{}],请求银行订单号为空 ,数据[{}]" , payCode , line);
					return;
				}
				fileDetail.setTradeType(ReconCnst.TRADE_TYPE_REFUND);
				fileDetail.setOrderAmt(Math.abs(CurrencyUtil.yuan2Fen(content[9].trim())));
				fileDetail.setMerAmt(Math.abs(CurrencyUtil.yuan2Fen(content[11].trim())));
			} else {
				fileDetail.setTradeType(content[5]);
			}

			fileDetail.setTradeStatus(StatusCnst.SUCCESS);
			fileDetail.setFee(CurrencyUtil.yuan2Fen(content[10].trim()));
			fileDetail.setOtherFee(0l);
			localLines.add(fileDetail.toReconStr());
			return;
		}
//		if (PayCodeCnst.PAY_CODE_WX.equals(payCode) && content.length == 13) {
//			ReconFileDetail fileDetail = new ReconFileDetail();
//			fileDetail.setTradeTime(content[0] + HHMMSS);
//			fileDetail.setMerOrderNo(content[6]);
//			fileDetail.setTradeSn(content[6]);
//
//			fileDetail.setOrderAmt(CurrencyUtil.yuan2Fen(content[9].trim()));
//			fileDetail.setMerAmt(CurrencyUtil.yuan2Fen(content[12].trim()));
//			if (WX_PAYMENT.equals(content[5])) {
//				fileDetail.setTradeType(ReconCnst.TRADE_TYPE_PAYMENT);
//			} else if (WX_REFUND.equals(content[5])) {
//				fileDetail.setTradeType(ReconCnst.TRADE_TYPE_REFUND);
//				fileDetail.setOrderAmt(Math.abs(CurrencyUtil.yuan2Fen(content[9].trim())));
//				fileDetail.setMerAmt(Math.abs(CurrencyUtil.yuan2Fen(content[12].trim())));
//			} else {
//				fileDetail.setTradeType(content[5]);
//			}
//
//			fileDetail.setTradeStatus(StatusCnst.SUCCESS);
//			fileDetail.setFee(CurrencyUtil.yuan2Fen(content[10].trim()));
//			fileDetail.setOtherFee(CurrencyUtil.yuan2Fen(content[11].trim()));
//			localLines.add(fileDetail.toReconStr());
//		}
		if (PayCodeCnst.PAY_CODE_ALIPAY.equals(payCode) && content.length >= 17) {
			content = line.replace(REPLACE_QUOTA_CHAR, "").split(ReconCnst.SPLIT_COMMA_SEPARATOR);
			ReconFileDetail fileDetail = new ReconFileDetail();
			fileDetail.setTradeTime(content[0] + HHMMSS);
			fileDetail.setOrderAmt(CurrencyUtil.yuan2Fen(content[8].trim()));
			fileDetail.setFee(CurrencyUtil.yuan2Fen(content[9].trim()));
			fileDetail.setMerAmt(CurrencyUtil.yuan2Fen(content[10].trim()));
			if (ALIPAY_PAYMENT.equals(content[7])) {
				fileDetail.setMerOrderNo(content[5]);
				fileDetail.setTradeSn(content[5]);
				fileDetail.setTradeType(ReconCnst.TRADE_TYPE_PAYMENT);
			} else if (ALIPAY_REFUND.equals(content[7])) {
				if(StringUtils.isBlank(content[14])){
		        	LOGGER.info("微众银行下载对账单,渠道编码[{}],请求银行订单号为空 ,数据[{}]" , payCode , line);
					return;
				}
				fileDetail.setMerOrderNo(content[14]);
				fileDetail.setTradeSn(content[14]);
				fileDetail.setTradeType(ReconCnst.TRADE_TYPE_REFUND);
				fileDetail.setOrderAmt(Math.abs(CurrencyUtil.yuan2Fen(content[8].trim())));
				fileDetail.setMerAmt(Math.abs(CurrencyUtil.yuan2Fen(content[10].trim())));
			} else {
				fileDetail.setMerOrderNo(content[5]);
				fileDetail.setTradeSn(content[5]);
				fileDetail.setTradeType(content[7]);
			}
			fileDetail.setTradeStatus(StatusCnst.SUCCESS);
			fileDetail.setOtherFee(0l);
			localLines.add(fileDetail.toReconStr());
		}
	}

	private static RequestConfig getRequestConfig(Map<String, String> extMap) {
		int readTimeOut = Integer.valueOf(extMap.get(BankCnst.READ_TIME_OUT));
		int connTimeOut = Integer.valueOf(extMap.get(BankCnst.CONN_TIME_OUT));
		return RequestConfig.custom().setSocketTimeout(readTimeOut).setConnectTimeout(connTimeOut).build();
	}

}


@SuppressWarnings("unused")
class FlushStreamHandler extends Thread {
	private InputStream is;

	public FlushStreamHandler(InputStream is) {
		this.is = is;
	}

	public void run() {
		BufferedReader reader = null;
		String line = "";
		try {
			reader = new BufferedReader(new InputStreamReader(is));
			while (null != (line = reader.readLine())) {
			}
		} catch (Exception e) {
		} finally {
			try {
				reader.close();
				if (null != is) {
					is.close();
				}
			} catch (IOException e) {
			}
		}
	}
}
