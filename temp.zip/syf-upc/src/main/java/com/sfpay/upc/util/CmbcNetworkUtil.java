/**
 * =================================================================
 * 版权所有 2011-2020 恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.upc.util;

import java.io.BufferedReader;
import java.io.File;
import java.io.InputStreamReader;
import java.security.cert.X509Certificate;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.commons.collections.CollectionUtils;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.helper.ReaderHelper;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.front.cnst.BankCnst;
import com.sfpay.front.cnst.CharCnst;
import com.sfpay.front.cnst.DateCnst;
import com.sfpay.front.cnst.EncodingCnst;
import com.sfpay.front.cnst.ReconCnst;
import com.sfpay.front.cnst.StatusCnst;
import com.sfpay.front.dto.ReconFileDetail;
import com.sfpay.front.util.CurrencyUtil;
import com.sfpay.front.util.SfpayFileUtils;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author 01117349
 * 
 * CreateDate: 2017年5月27日
 */
public final class CmbcNetworkUtil {
	private static final Logger LOGGER = LoggerFactory.getLogger(CmbcNetworkUtil.class);
	private static final String RECON_FILE_HEAD = "消费时间|商户订单号|交易流水号|交易状态|支付方式|订单金额|商户实收|手续费|收单设备";

	public static String sendAndReceiveForTrade(String reqMsg, Map<String, String> extMap) throws Exception {
		HttpClientBuilder builder = HttpClients.custom();
		builder.setSSLSocketFactory(createSSLFacoty());

		String networkUrl = extMap.get(BankCnst.NETWORK_URL);
		HttpPost req = new HttpPost(networkUrl);

		int readTimeOut = Integer.valueOf(extMap.get(BankCnst.READ_TIME_OUT));
		int connTimeOut = Integer.valueOf(extMap.get(BankCnst.CONN_TIME_OUT));
		req.setConfig(RequestConfig.custom().setSocketTimeout(readTimeOut).setConnectTimeout(connTimeOut).build());
		req.addHeader(new BasicHeader("Content-Type", "application/json"));

		if (!StringUtils.isEmpty(reqMsg)) {
			req.setEntity(new StringEntity(reqMsg, EncodingCnst.UTF_8));
		}

		CloseableHttpResponse resp = null;
		CloseableHttpClient client = builder.build();
		try {
			resp = client.execute(req);

			return ReaderHelper.getPlain(resp.getEntity().getContent(), EncodingCnst.UTF_8);
		} finally {
			if (resp != null)
				resp.close();
			if (client != null)
				client.close();

		}
	}

	@SuppressWarnings("deprecation")
	private static SSLConnectionSocketFactory createSSLFacoty() throws Exception {
		X509TrustManager x509mgr = new X509TrustManager() {
			public void checkClientTrusted(X509Certificate[] xcs, String string) {
			}

			public void checkServerTrusted(X509Certificate[] xcs, String string) {
			}

			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}
		};
		SSLContext ctx = SSLContext.getInstance("TLS");
		ctx.init(null, new TrustManager[] { x509mgr }, null);
		return new SSLConnectionSocketFactory(ctx, SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
	}

	public static void sendAndReceiveForRecon(String reqMsg, Map<String, String> extMap) throws Exception {
		HttpClientBuilder builder = HttpClients.custom();
		builder.setSSLSocketFactory(createSSLFacoty());

		String networkUrl = extMap.get(BankCnst.NETWORK_URL);
		HttpPost req = new HttpPost(networkUrl);

		int readTimeOut = Integer.valueOf(extMap.get(BankCnst.READ_TIME_OUT));
		int connTimeOut = Integer.valueOf(extMap.get(BankCnst.CONN_TIME_OUT));
		req.setConfig(RequestConfig.custom().setSocketTimeout(readTimeOut).setConnectTimeout(connTimeOut).build());
		req.addHeader(new BasicHeader("Content-Type", "application/json"));
		req.setEntity(new StringEntity(reqMsg, EncodingCnst.UTF_8));

		CloseableHttpResponse resp = null;
		CloseableHttpClient client = builder.build();

		String localFullName = Property.getProperty(ReconCnst.LOCAL_PATH) + extMap.get(ReconCnst.CHANNEL_CODE) + "/"
				+ extMap.get(ReconCnst.FILE_NAME);
		File convertFullFile = new File(localFullName);

		List<String> localLines = new ArrayList<String>();
		if (convertFullFile.exists()) {
			SfpayFileUtils.forceDelete(convertFullFile);
		}

		BufferedReader bufferedReader = null;
		try {
			resp = client.execute(req);

			bufferedReader = new BufferedReader(
					new InputStreamReader(resp.getEntity().getContent(), EncodingCnst.UTF_8));
			String line = bufferedReader.readLine();
			LOGGER.info("民生银行下载[{}]对账文件返回结果[{}]", extMap.get(ReconCnst.FILE_DATE), line);
			if (null != line && RECON_FILE_HEAD.equals(line)) {
				while (null != (line = bufferedReader.readLine())) {
					String[] content = line.split(ReconCnst.SPLIT_COMMA_SEPARATOR);
					ReconFileDetail fileDetail = new ReconFileDetail();

					fileDetail.setTradeTime(DateUtils.format(DateUtils.parse(content[0], DateCnst.YYYY_MM_DD_HH_MM_SS),
							DateCnst.YYYYMMDDHHMMSS));
					fileDetail.setMerOrderNo(content[1]);
					fileDetail.setTradeSn(content[2]);
					/*
					 * p（小写） 支付中 P（大写） 交易成功(针对对账单) s 交易成功 r 退款成功 c 交易关闭
					 */
					if (CMBC_PAYMENT.equals(content[3])) {
						fileDetail.setTradeType(ReconCnst.TRADE_TYPE_PAYMENT);
					} else if (CMBC_REFUND.equals(content[3])) {
						fileDetail.setTradeType(ReconCnst.TRADE_TYPE_REFUND);
					} else {
						continue;
					}
					fileDetail.setTradeStatus(StatusCnst.SUCCESS);
					fileDetail.setOrderAmt(CurrencyUtil.yuan2Fen(content[5].trim()));
					fileDetail.setMerAmt(CurrencyUtil.yuan2Fen(content[6].trim()));
					fileDetail.setFee(CurrencyUtil.yuan2Fen(content[7].trim()));
					localLines.add(fileDetail.toReconStr());

					if (localLines.size() % (ReconCnst.FILE_NUMBER_PER_WRITE
							+ CharCnst.NUMBER_ONE) == ReconCnst.FILE_NUMBER_PER_WRITE) {
						SfpayFileUtils.writeLines(convertFullFile, EncodingCnst.UTF_8, localLines, Boolean.TRUE);
						localLines = new ArrayList<String>();
					}
				}
				if (CollectionUtils.isNotEmpty(localLines)) {
					SfpayFileUtils.writeLines(convertFullFile, EncodingCnst.UTF_8, localLines, Boolean.TRUE);
				}
				String remoteSftpPath = Property.getProperty(ReconCnst.SFTP_PATH) + extMap.get(ReconCnst.CHANNEL_CODE)
						+ "/";
				SFTPUtils sftpClient = new SFTPUtils(Property.getProperty(ReconCnst.SFTP_IP),
						Integer.parseInt(Property.getProperty(ReconCnst.SFTP_PORT)),
						Property.getProperty(ReconCnst.SFTP_USER), Property.getProperty(ReconCnst.SFTP_PASS), 0);
				sftpClient.upload(remoteSftpPath, localFullName);

				SfpayFileUtils.forceDelete(convertFullFile);
			}
		} catch (Exception e) {
			LOGGER.info("民生银行下载[{}]对账文件异常", extMap.get(ReconCnst.FILE_DATE), e);
			throw e;
		} finally {
			bufferedReader.close();
		}
	}

	private static final String CMBC_PAYMENT = "P";
	private static final String CMBC_REFUND = "r";

}
