package com.sfpay.upc.web;

import java.io.PrintWriter;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.sfpay.acquirer.common.Encoding;
import com.sfpay.acquirer.common.HttpHelper;
import com.sfpay.acquirer.common.MD5Util;
import com.sfpay.framework.config.properties.Property;
import com.sfpay.upc.common.WXSignUtil;
import com.sfpay.upc.constant.UpcConstants;
import com.sfpay.upc.domain.upc.ChannelArgs;
import com.sfpay.upc.domain.upc.UpcPayInfo;
import com.sfpay.upc.domain.wx.WXNotifyRlt;
import com.sfpay.upc.enums.SystemSource;
import com.sfpay.upc.enums.TradeStatus;
import com.sfpay.upc.service.IAlipayService;
import com.sfpay.upc.service.IChannelArgService;
import com.sfpay.upc.service.IMqService;
import com.sfpay.upc.service.IUpcPayInfoService;
import com.sfpay.upc.service.IWXService;

/**
 * 
 * 类说明：<br>
 * 后台回调
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-5-4
 */
@Controller
@RequestMapping("/upc")
public class ThirdCallBackNotify {

	private final Logger logger = LoggerFactory.getLogger(getClass());

	private static String handleSuccWxNotifyMsg = "<xml><return_code><![CDATA[SUCCESS]]></return_code><return_msg><![CDATA[OK]]></return_msg></xml>";
	@Resource
	private IUpcPayInfoService payInfoService;
	@Resource
	private IChannelArgService channelArgService;
	@Resource
	private IWXService wxService;
	@Resource
	private IAlipayService alipayService;
	@Resource
	private IMqService mqService;

	@RequestMapping(value = "/callBack/notify")
	public void notifyByThirdPay( HttpServletRequest req, HttpServletResponse resp) {

		logger.info("接收支付流水payNO:[{}] 的银行[后端]回调...");
		Map<String,String> resultMap = new HashMap<String,String>();
		resultMap.put("signature", req.getParameter("signature"));
		resultMap.put("timestamp", req.getParameter("timestamp"));
		resultMap.put("nonce", req.getParameter("nonce"));
		resultMap.put("echostr", req.getParameter("echostr"));
		// 微信回调
		Boolean falg = handlerWX(req, resp,resultMap);
		if(falg)
		{
			outputJson(resultMap.get("echostr"),resp);
		}
		return;
	}

	
	private String getUpcStatus(String status) {
		return Sfpay2UpcRefundStatus.valueOf(status).getUpcRefundStatus();
	}

	public enum Sfpay2UpcRefundStatus {

		SUCCESS(TradeStatus.REFUND_SUCC.name()), FAILURE(TradeStatus.REFUND_FAIL.name()), CLOSED(TradeStatus.CLOSE
				.name());

		String upcRefundStatus;

		private Sfpay2UpcRefundStatus(String status) {
			this.upcRefundStatus = status;
		}

		public String getUpcRefundStatus() {
			return upcRefundStatus;
		}

	}

	

	private Boolean handlerWX(HttpServletRequest requst, HttpServletResponse resp,Map<String,String> maps) {
		Map<String, String> map = new HashMap<String, String>();
		ChannelArgs channelArgs = new ChannelArgs(map);
		// 1.解析报文
		Boolean wxnr = parseWXPostDataXml(requst, channelArgs,maps);
		
		return wxnr;

	}

	

	private String notifyOtherSystem(UpcPayInfo payInfo, WXNotifyRlt wxnr) {
		// 通知返回成功状态,执行业务流水表更新及商户通知
		String url = null;
		StringBuffer meta = new StringBuffer();
		if (SystemSource.HHT.name().equals(payInfo.getSystemSource())) {

			url = String.format("%s/express/%s/notify", Property.getProperty("SYS_EXP_URI"), payInfo.getMchOrderNo());
			logger.info("system source hht notify url:[{}]", url);
			meta.append("&mchPayNo=").append(payInfo.getReqOrderNo());
			// 支付成功
			if (UpcConstants.SUCCESS.equals(wxnr.getReturnCode()) && UpcConstants.SUCCESS.equals(wxnr.getResultCode())) {
				meta.append("&status=").append(UpcConstants.SUCCESS);
				meta.append("&wxOderNo=").append(wxnr.getWxOrderNo());
				meta.append("&reqBankSn=").append(wxnr.getReqBankSn());
				meta.append("&openid=").append(wxnr.getOpenid());
			}
			// 支付失败
			else {
				meta.append("&status=").append("FAIL");
				meta.append("&respCode=").append(wxnr.getErrCode());
				meta.append("&respDesc=").append(wxnr.getErrCodeDes());
			}

			meta.append("&sign=").append(MD5Util.md5Hex("WX" + payInfo.getMchOrderNo()).toUpperCase());
		} else {

		}

		logger.info(String.format("后台通知[%s]-[%s]", url, meta.toString()));
		String rs = null;
		try {
			rs = HttpHelper.sendByPost(url, meta.toString(), Encoding.UTF_8);
		} catch (Exception e) {
			logger.error(String.format("通知[%s]异常(报文: %s)", url, meta), e);
		}
		return rs;

	}

	// 解析微信数据
	private Boolean parseWXPostDataXml(HttpServletRequest request, ChannelArgs args,Map<String,String> map) {

		try {
//			Map<String, Object> resultMap = com.sfpay.upc.util.XMLToMapUtil.getInstanceContentMap(request
//					.getInputStream());

			logger.info("微信通知顺手付数据解析：{}", map.toString());
			map.put("token", "GNN5opwHS28ORdfafadsfasfasfasdf");
			boolean isValidSign = verifySign(map, args);
			if (!isValidSign) {
				logger.info("签名不一致");
				return false;
			}

		} catch (Exception e) {
			logger.error("xml 转 map异常:{}", e);
			
			return false;
		}

		return true;
	}

	private boolean verifySign(Map<String, String> resultMap, ChannelArgs args) {
		try {
			String newSign = WXSignUtil.notifySign(resultMap);
			return newSign.equals((String) resultMap.get("signature"));
		} catch (Exception e) {
			logger.error("组装签名异常：{}", resultMap.toString());
		}
		return false;
	}
	
	public void outputJson(String jsonStr, HttpServletResponse response) {
		PrintWriter out = getPrintWriter(response);
		if(out == null){
			return;
		}
		out.print(jsonStr);
		if(out != null){
			out.flush();
			out.close();
		}
		
	}
	
	protected PrintWriter getPrintWriter(HttpServletResponse resp) {
		PrintWriter out = null;
		resp.setContentType("text/plain;charset=UTF-8");
		try {
			out = resp.getWriter();
		} catch (Exception e) {
			logger.error("获取输出流异常", e);
		}
		return out;
	}

}
