package com.sfpay.bill.dao;

import org.apache.ibatis.annotations.Param;

import com.sfpay.bill.domain.AllChannelBillDetail;

/**
 *
 * @Description: 渠道账单汇总明细服务类
 * @date 2016-12-24 15:23:47
 * @version V1.0
 * @author 896728
 */
public interface AllChannelBillDetailDao {

	/**
	 * 更新对象
	 * 
	 * @param model
	 */
	void updateAllChannelBillDetail(AllChannelBillDetail allChannelBillDetail);

	/**
	 * 保存对象
	 * 
	 * @param model
	 */
	void saveAllChannelBillDetail(AllChannelBillDetail allChannelBillDetail);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据商户订单号查询记录
	 * @param mchOrderNo
	 * @return
	 */
	AllChannelBillDetail findAllChannelBillDetailByMchOrderNo(
			@Param(value = "mchOrderNo")String mchOrderNo, 
			@Param(value = "channelCode")String channelCode, 
			@Param(value = "channelMchId")String channelMchId, 
			@Param(value = "tradeTime")String tradeTime,
			@Param(value = "tradeType")String tradeType);

}
