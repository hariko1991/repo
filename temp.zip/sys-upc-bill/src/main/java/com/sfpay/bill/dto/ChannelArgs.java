/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.bill.dto;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

/**
 * 类说明：<br>
 * 银行参数接口封装
 * 
 * <p>
 * 详细描述：<br>
 * 
 * </p>
 * 
 */
public final class ChannelArgs implements Serializable {

	private static final long serialVersionUID = 8595523785922584539L;

	private String mchChannelParamKey;

	private Map<String, String> map = new HashMap<String, String>();

	public ChannelArgs(Map<String, String> map) {
		this.map = map;
	}

	public String getMchChannelParamKey() {
		return mchChannelParamKey;
	}

	public void setMchChannelParamKey(String mchChannelParamKey) {
		this.mchChannelParamKey = mchChannelParamKey;
	}

	public String getValueByKey(String key) {
		return map.get(key);
	}

}
