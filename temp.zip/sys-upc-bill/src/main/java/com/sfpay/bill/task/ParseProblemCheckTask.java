package com.sfpay.bill.task;

import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.bill.dao.AllChannelBillDetailDao;
import com.sfpay.bill.dao.AllChannelBillSummaryDao;
import com.sfpay.bill.dao.ParseBillProcDao;
import com.sfpay.bill.dao.WxBillDetailDao;
import com.sfpay.bill.domain.ParseBillProc;
import com.sfpay.bill.enums.ParseStatus;
import com.sfpay.bill.service.impl.UpcMerchantMapService;
import com.sfpay.framework2.config.properties.Property;

/**
 * 检查解析问题
 * 
 * @author 896728
 * @date 2016年12月31日
 *
 */
@Service("ParseProblemCheckTask")
public class ParseProblemCheckTask {

	private final Logger logger = LoggerFactory.getLogger(getClass());
	@Resource
	private UpcMerchantMapService upcMerchantMapService;
	@Resource
	private WxBillDetailDao wxBillDao;
	@Resource
	private ParseBillProcDao parseBill;
	@Resource
	private AllChannelBillSummaryDao channelBillSummaryDao;
	@Resource
	private ParseBillProcDao parseBillProcDao;
	@Resource
	private AllChannelBillDetailDao allChannelBillDetailDao;

	/**
	 * 解析微信异常处理
	 */
	public void checkProcessing() {
		try {
			String procDelayTimeObj = Property.getProperty("PROC_DELAY_TIME");

			int defaultDelayTime = 5;
			if (StringUtils.isNotBlank(procDelayTimeObj)) {
				defaultDelayTime = Integer.parseInt(procDelayTimeObj);
			}
			List<ParseBillProc> list = null;
			try {
				list = parseBillProcDao.findParseProblemItem(ParseStatus.PROCESSING.name(),
						defaultDelayTime);
			} catch (Exception e) {
				logger.error("findParseProblemItem异常数据出现异常", e);
				return;
			}

			if (list == null || list.isEmpty()) {
				return;
			}

			for (ParseBillProc proc : list) {
				// 查询渠道商户映射配置
				try {
					proc.setStatus(ParseStatus.FAIL.name());
					parseBillProcDao.updateParseBillProcByStatus(proc, ParseStatus.PROCESSING.name());
				} catch (Exception e) {
					logger.error("执行更新updateParseBillProcByStatus异常", e);
				}
			}

		} catch (Exception e) {
			logger.error("解析微信异常", e);
		}

	}
}
