/**
 * =================================================================
 * 版权所有 2011-2020 顺丰恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.bill.service.impl;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.bill.constants.ChannelCodeConstants;
import com.sfpay.bill.constants.ChannelTradeTypeConstants;
import com.sfpay.bill.domain.AlipayBillDetail;
import com.sfpay.bill.domain.AllChannelBillDetail;
import com.sfpay.bill.domain.AllChannelBillSummary;
import com.sfpay.bill.enums.ParseStage;
import com.sfpay.bill.util.FileDeleteUtils;

/**
 * 类说明：<br>
 * 支付宝解析账单数据服务
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 从对应的账单文件解析数据入库（不包括账单文件下载，下载有单独的服务）
 * 
 * </p>
 * 
 * 
 * CreateDate: 2016-12-28
 */
@Service
public class AlipayParseBillDataStageService extends UpcBillDataParseBaseService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	/**支付宝账单明细文件*/
	private static final String ALIPAY_BILL_DETAIL_FILE = "ALIPAY_BILL_DETAIL_FILE";
	/**支付宝账单明细文件最后几个字符*/
	private static final String ALIPAY_BILL_DETAIL_SUFFIX = "_业务明细.csv";
	/**支付宝账单明细汇总文件*/
	private static final String ALIPAY_BILL_DETAIL_SUMMARY_FILE = "ALIPAY_BILL_DETAIL_SUMMARY_FILE";
	/**支付宝账单明细汇总文件最后几个字符*/
	private static final String ALIPAY_BILL_DETAIL_SUMMARY_SUFFIX = "_业务明细(汇总).csv";
	
	/**
	 * 
	 * 方法说明：<br>
	 * 处理账单数据解析
	 * @param filePath 账单文件路径
	 * @param channelMerchantId 渠道商户号
	 * @param billDate 账单日期
	 */
	public void processBillDataParse(String filePath, String channelMerchantId, String billDate){
		//账单解析
		//开始账单解析
		boolean parseSuccess = startBillStage(ChannelCodeConstants.ALIPAY_CHANNEL, billDate, channelMerchantId, ParseStage.NORMAL_PARSE.name(), filePath);
		if(!parseSuccess){
			return;
		}
		
		//解析账单数据
		parseSuccess = parseBillDataStage(filePath, channelMerchantId, billDate);
		
		//解析阶段完成
		endBillStage(ChannelCodeConstants.ALIPAY_CHANNEL, billDate, channelMerchantId, parseSuccess, ParseStage.NORMAL_PARSE.name(), filePath);
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 解析账单数据文件
	 * @param filePath 账单路径
	 * @param channelMchId 渠道商户号
	 * @param billDate 账单日期
	 */
	private boolean parseBillDataStage(String filePath, String channelMchId, String billDate) {
		//从指定的解压目录获取具体的文件
		Map<String, List<String>> fileMap = getFileFromPath(filePath);
		if(fileMap == null || fileMap.isEmpty()){
			return false;
		}
		
		List<String> billDetailFileList = fileMap.get(ALIPAY_BILL_DETAIL_FILE);
		List<String> billDetailSummaryFileList = fileMap.get(ALIPAY_BILL_DETAIL_SUMMARY_FILE);
		
		
		int failTimes = 0;
		boolean parseSuc = true;
		//账单明细数据解析
		if(billDetailFileList != null && billDetailFileList.size() > 0){
			for(String file : billDetailFileList){
				parseSuc = parseFileContent(file, channelMchId, billDate);
				if(!parseSuc){
					failTimes++;
				}
			}
		}
		
		//账单明细汇总数据解析
		if(billDetailSummaryFileList != null && billDetailSummaryFileList.size() > 0){
			for(String file : billDetailSummaryFileList){
				parseSuc = parseFileContent(file, channelMchId, billDate);
				if(!parseSuc){
					failTimes++;
				}
			}
		}
		
		boolean allParseSuc = failTimes > 0 ? false : true;
		if(allParseSuc){
			//全部解析成功，则删除对应的压缩文件及文件夹
			File zipFile = new File(filePath+ZIP_FILE_SUFFIX);
			File pathFile = new File(filePath);
			try {
				FileDeleteUtils.deleteFile(zipFile);
				FileDeleteUtils.deleteFile(pathFile);
			} catch (Exception e) {
				logger.error("文件删除出错，文件路径：{}", pathFile);
			}
		}
		
		return allParseSuc;
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 从解压后的文件夹路径获取具体的文件名字，注意：包括父目录路径
	 * @param filePath
	 * @return
	 */
	private Map<String, List<String>> getFileFromPath(String filePath) {
		File parentPath = new File(filePath);
		if(!parentPath.exists()){
			logger.error("文件目录不存在，目录：{}", filePath);
			return null;
		}
		
		if(!parentPath.isDirectory()){
			logger.error("传入路径不是文件目录，请传入文件目录路径，当前路径：{}", filePath);
			return null;
		}
		
		File[] files = parentPath.listFiles();
		if(files == null || files.length == 0){
			logger.error("该目录下面不存在文件，文件路径：{}", filePath);
			//删除空目录
			parentPath.delete();
		}
		
		//获取文件的名字
		Map<String, List<String>> map = new HashMap<String, List<String>>();
		List<String> billDetailList = new LinkedList<String>();
		List<String> billDetailSummaryList = new LinkedList<String>();
		
		for(File file : files){
			String fileName = file.getName();
			
			if(fileName.endsWith(ALIPAY_BILL_DETAIL_SUFFIX)){
				billDetailList.add(file.getAbsolutePath());
				continue;
			}
			
			if(fileName.endsWith(ALIPAY_BILL_DETAIL_SUMMARY_SUFFIX)){
				billDetailSummaryList.add(file.getAbsolutePath());
				continue;
			}
		}
		
		map.put(ALIPAY_BILL_DETAIL_FILE, billDetailList);
		map.put(ALIPAY_BILL_DETAIL_SUMMARY_FILE, billDetailSummaryList);
		
		return map;
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 解析文件内容
	 * @param filePath
	 * @param channelMchId
	 * @param billDate
	 * @return
	 */
	private boolean parseFileContent(String filePath, String channelMchId, String billDate) {
		boolean parseSuccess = true;
		int failTimes = 0;//解析失败次数
		
		try {
			File billFile = new File(filePath);
			if(!billFile.exists()){
				return true;
			}
			
			BufferedReader buf = null;
			buf = new BufferedReader(new InputStreamReader(new FileInputStream(billFile), FILE_CHARSET_GBK));

			AlipayBillDetail billDetail = null;
			AllChannelBillDetail allDetail = null;
			String line_record = null;
			int billDetailCount = 0;
			int billSummaryCount = 0;
			while ((line_record = buf.readLine()) != null) {
				String[] fields = line_record.split(",",-1);
				logger.info("解析字段 fields长度:[{}]", fields.length);
				
				// bill detail
				if (fields.length == 25) {
					billDetailCount++;
					
					if(billDetailCount != 1){
						billDetail = buildAlipayDetail(fields, channelMchId, billDate);
						//保存支付宝账单明细记录
						parseSuccess = upcBillCommonService.saveAlipayDetail(billDetail);;
						//如果解析失败，则失败次数自动增加一次
						if(!parseSuccess){
							failTimes++;
						}
						
						//保存到公共表里
						allDetail = buildAllDetail(billDetail, channelMchId, billDate);
						parseSuccess = upcBillCommonService.saveAllChannelDetail(allDetail);
						//如果解析失败，则失败次数自动增加一次
						if(!parseSuccess){
							failTimes++;
						}
					}
				}
				
				// bill summary
				else if (fields.length == 12) {
					billSummaryCount++;

					if (billSummaryCount != 1) {
						AllChannelBillSummary summary = buildAlipaySummary(fields, channelMchId, billDate);
						//保存支付宝账单汇总记录
						parseSuccess = upcBillCommonService.saveAllChanelSummary(summary);
						//如果解析失败，则失败次数自动增加一次
						if(!parseSuccess){
							failTimes++;
						}
					}
				}
			}

			// 关闭连接
			buf.close();
			//正常解析完成，删除对应的文件
			if(failTimes == 0){
				// 删除本地下载包
				billFile.delete();
				File file = new File(filePath);
				file.delete();
			}
		} catch (Exception e) {
			logger.error(String.format("解析账单文件出错，渠道商户号：%s，账单日期：%s", channelMchId, billDate), e);
			failTimes++;
		}
		
		boolean success = failTimes > 0 ? false : true;
		if(!success){
			//保存解析异常数据
			upcBillCommonService.saveParseExcpData(ChannelCodeConstants.ALIPAY_CHANNEL, billDate, channelMchId, ParseStage.NORMAL_PARSE.name(), "账单没有完全解析完成");
		}
		
		return success;
	}
	
	private AlipayBillDetail buildAlipayDetail(String[] fields, String channelMchId, String billDate) {
		AlipayBillDetail detail = new AlipayBillDetail();
		
		detail.setChannelMchId(trim(channelMchId));
		detail.setTradeTime(trim(billDate));
		detail.setAlipayTradeNo(trim(fields[0]));
		detail.setMchOrderNo(trim(fields[1]));
		detail.setBusinessType(convertBusiType(trim(fields[2])));
		detail.setGoodsName(trim(fields[3]));
		detail.setTradeStartTime(trim(fields[4]));
		detail.setTradeEndTime(trim(fields[5]));
		detail.setStoreNo(trim(fields[6]));
		detail.setStoreName(trim(fields[7]));
		detail.setOperator(trim(fields[8]));
		detail.setTerminal(trim(fields[9]));
		detail.setOppositeAccount(trim(fields[10]));
		detail.setOrderAmt(StringUtils.isEmpty(trim(fields[11])) ? BigDecimal.ZERO : new BigDecimal(trim(fields[11])));
		detail.setActuralAmount(StringUtils.isEmpty(trim(fields[12])) ? BigDecimal.ZERO : new BigDecimal(trim(fields[12])));
		detail.setAlipayRedpackAmount(StringUtils.isEmpty(trim(fields[13])) ? BigDecimal.ZERO : new BigDecimal(trim(fields[13])));
		detail.setPackCreditAmount(StringUtils.isEmpty(trim(fields[14])) ? BigDecimal.ZERO : new BigDecimal(trim(fields[14])));
		detail.setAlipayDiscountAmount(StringUtils.isEmpty(trim(fields[15])) ? BigDecimal.ZERO : new BigDecimal(trim(fields[15])));
		detail.setMchDiscountAmount(StringUtils.isEmpty(trim(fields[16])) ? BigDecimal.ZERO : new BigDecimal(trim(fields[16])));
		detail.setCouponAmount(StringUtils.isEmpty(trim(fields[17])) ? BigDecimal.ZERO : new BigDecimal(trim(fields[17])));
		detail.setCouponName(trim(fields[18]));
		detail.setMchRedpackUseAmount(StringUtils.isEmpty(trim(fields[19])) ? BigDecimal.ZERO : new BigDecimal(trim(fields[19])));
		detail.setCardAmount(StringUtils.isEmpty(trim(fields[20])) ? BigDecimal.ZERO : new BigDecimal(trim(fields[20])));
		detail.setRefundNo(trim(fields[21]));
		detail.setServiceFee(StringUtils.isEmpty(trim(fields[22])) ? BigDecimal.ZERO : new BigDecimal(trim(fields[22])));
		detail.setShareBenefit(StringUtils.isEmpty(trim(fields[23])) ? BigDecimal.ZERO : new BigDecimal(trim(fields[23])));
		detail.setRemark(trim(fields[24]));
		
		return detail;
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 将中文的业务类型转换成英文业务类型
	 * @param busiType
	 * @return
	 */
	private String convertBusiType(String busiType) {
		if(StringUtils.equals("交易", busiType)){
			return ChannelTradeTypeConstants.PAY;
		} else if (StringUtils.equals("退款", busiType)) {
			return ChannelTradeTypeConstants.REFUND;
		} else {
			return busiType;
		}
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 构造所有的明细
	 * @param bd
	 * @param channelMchId
	 * @param billDate
	 * @return
	 */
	private AllChannelBillDetail buildAllDetail(AlipayBillDetail bd, String channelMchId, String billDate) {
		AllChannelBillDetail ad = new AllChannelBillDetail();
		
		ad.setChannelCode(ChannelCodeConstants.ALIPAY_CHANNEL);
		ad.setChannelMchId(channelMchId);
		ad.setChannelOrderNo(bd.getAlipayTradeNo());
		ad.setChannelRefundNo(null);
		ad.setGoodsName(bd.getGoodsName());
		ad.setMchOrderNo(bd.getMchOrderNo());
		if(StringUtils.equals(ChannelTradeTypeConstants.REFUND, bd.getBusinessType())){
			ad.setMchRefundNo(bd.getRefundNo());
			ad.setRefundAmount(bd.getOrderAmt());
			ad.setRefundStatus("SUCCESS");
		}
		ad.setServiceFee(bd.getServiceFee());
		ad.setTradeAmount(bd.getOrderAmt());
		ad.setTradeState("SUCCESS");
		ad.setTradeTime(billDate);
		ad.setTradeType(bd.getBusinessType());
		
		return ad;
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 构造支付宝汇总对象
	 * @param fields
	 * @param channelMchId
	 * @param billDate
	 * @return
	 */
	private AllChannelBillSummary buildAlipaySummary(String[] fields, String channelMchId, String billDate) {
		AllChannelBillSummary summary = new AllChannelBillSummary();
		
		summary.setTradeTime(billDate);
		summary.setChannelCode(ChannelCodeConstants.ALIPAY_CHANNEL);
		summary.setSfpayMchId(null);
		summary.setChannelMchId(channelMchId);
		summary.setTradeAmount(StringUtils.isEmpty(trim(fields[4])) ? BigDecimal.ZERO : new BigDecimal(trim(fields[4])));
		summary.setFeeAmount(StringUtils.isEmpty(trim(fields[9])) ? BigDecimal.ZERO : new BigDecimal(trim(fields[9])));
		Integer payCount = StringUtils.isEmpty(trim(fields[2])) ? 0 : Integer.parseInt(trim(fields[2]));
		Integer refCount = StringUtils.isEmpty(trim(fields[3])) ? 0 : Integer.parseInt(trim(fields[3]));
		summary.setTotalCount(payCount+refCount);
		
		return summary;
	}
	
}
