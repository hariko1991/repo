package com.sfpay.bill.dao;

import org.springframework.stereotype.Service;

import com.sfpay.bill.domain.ParseBillProc;

/**
 *
 * @Description: 账单解析过程服务类
 * @date 2016-12-24 15:24:40
 * @version V1.0
 * @author 896728
 */
@Service
public class ParseBillProcService {


	/**
	 * 
	 * @param tradeTime
	 * @param channelCode
	 * @param channelMchId
	 * @return
	 */
	public ParseBillProc queryParseBillProc(String tradeTime, String channelCode, String channelMchId) {
		return null;
	}

}
