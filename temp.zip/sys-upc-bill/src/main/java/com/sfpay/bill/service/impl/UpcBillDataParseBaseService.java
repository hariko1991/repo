/**
 * =================================================================
 * 版权所有 2011-2020 顺丰恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.bill.service.impl;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.bill.dao.ParseBillProcDao;
import com.sfpay.bill.domain.ParseBillProc;
import com.sfpay.bill.enums.ParseStatus;

/**
 * 类说明：<br>
 * 账单服务基础类
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * 
 * CreateDate: 2016-12-28
 */
public abstract class UpcBillDataParseBaseService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	protected UpcBillCommonService upcBillCommonService;
	@Resource
	private ParseBillProcDao parseBillProcDao;

	protected static final String SEPRATOR = "_";
	protected static final String BILL_TRADE_TYPE = "trade";
	protected static final String FILE_CHARSET_GBK = "GBK";
	protected static final String ZIP_FILE_SUFFIX = ".zip";
	
	
	/**
	 * 
	 * 方法说明：<br>
	 * 开始账单处理，包括：账单下载、账单解析
	 * @param channelCode 渠道编码必传
	 * @param billDate 账单日期
	 * @param channelMchId 渠道商户号
	 * @param parseStage 解析阶段，包括：账单下载、账单解析
	 * @param filePath 解析账单文件路径，绝对路径，只有是账单解析阶段才有值
	 * @return
	 */
	public boolean startBillStage(String channelCode, String billDate, String channelMchId, String parseStage, String filePath){
		logger.info(String.format("startBillStage 开始。。。渠道编码：%s，账单日期：%s，渠道商户号：%s，解析阶段：%s", channelCode, billDate, channelMchId, parseStage));
		//先查询对应的记录是否存在
		ParseBillProc  proc = upcBillCommonService.findProcByMchIdAndBillDate(channelCode, channelMchId, billDate, parseStage);
		
		if(proc == null) {
			ParseBillProc billProc = new ParseBillProc();
			billProc.setChannelCode(channelCode);
			billProc.setChannelMchId(channelMchId);
			billProc.setParseStage(parseStage);
			billProc.setSfpayMchId(null);
			billProc.setStatus(ParseStatus.PROCESSING.name());
			billProc.setTradeTime(billDate);
			billProc.setBillFilePath(filePath);//只有账单解析阶段才有值
			
			try {
				parseBillProcDao.saveParseBillProc(billProc);
			} catch (Exception e) {
				logger.error(String.format("(method:startBillStage)保存解析过程记录失败，账单日期：%s，渠道商户号：%s", billDate, channelMchId), e);
				return false;
			}
			return true;
		}
		
		String status = proc.getStatus();
		logger.info(String.format("(method:startBillStage)已经存在解析处理记录，记录状态：%s，渠道商户号：%s，账单日期：%s", status, channelMchId, billDate));
		
		//如果状态是失败，则更新为进行中
		if(StringUtils.equals(ParseStatus.SUCCESS.name(), status) || StringUtils.equals(ParseStatus.PROCESSING.name(), status)){
			return false;
		}
		
		ParseBillProc update = new ParseBillProc();
		update.setId(proc.getId());
		update.setStatus(ParseStatus.PROCESSING.name());
		try {
			int num = parseBillProcDao.updateParseBillProcByStatus(update, ParseStatus.FAIL.name());
			if(num <= 0){
				return false;
			}
		} catch (Exception e) {
			logger.error(String.format("(method:startBillStage)更新解析记录状态失败，渠道商户号：%s，账单日期：%s", channelMchId, billDate), e);
			return false;
		}
		
		return true;
	}
	
	
	
	/**
	 * 
	 * 方法说明：<br>
	 * 结束账单处理，包括：账单下载、账单解析
	 * @param channelCode 渠道编码
	 * @param billDate 账单日期
	 * @param channelMchId 渠道商户号
	 * @param startStatus 开始阶段状态
	 * @param parseStage 账单阶段
	 * @param filePath 文件路径
	 */
	public void endBillStage(String channelCode, String billDate, String channelMchId, boolean startStatus, String parseStage, String filePath){
		ParseBillProc  proc = upcBillCommonService.findProcByMchIdAndBillDate(channelCode, channelMchId, billDate, parseStage);
		if(proc == null){
			return;
		}
		
		//更新记录状态
		ParseBillProc update = new ParseBillProc();
		update.setId(proc.getId());
		update.setStatus(startStatus ? ParseStatus.SUCCESS.name() : ParseStatus.FAIL.name());
		update.setBillFilePath(filePath);//将文件路径更新进去
		try {
			parseBillProcDao.updateParseBillProcByStatus(update, ParseStatus.PROCESSING.name());
		} catch (Exception e) {
			logger.error(String.format("(method:endBillStage)更新存在的解析过程记录失败，账单日期：%s，渠道商户号：%s", billDate, channelMchId), e);
		}
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 去掉前后空格
	 * @param oldStr
	 * @return
	 */
	protected String trim(String oldStr) {
		if(oldStr == null){
			return "";
		}
		
		return StringUtils.trim(oldStr);
	}
}
