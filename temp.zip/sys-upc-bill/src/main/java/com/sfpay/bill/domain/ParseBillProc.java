package com.sfpay.bill.domain;
import java.io.Serializable;
import java.util.Date;

/**   
 *
 * @Description: 账单解析过程
 * @date 2016-12-24 15:24:39
 * @version V1.0   
 * @author 896728
 */

public class ParseBillProc implements Serializable  {
	private static final long serialVersionUID = 9185723813161268548L;
	
	/** 主键*/
	private Long id;
	/** 解析阶段: 下载:DOWNLOAD_PARSE, 解析正常：NORMAL_PARSE */
	private String parseStage;
	/** 交易时间yyyy-MM-dd*/
	private String tradeTime;
	/** 渠道编码 WX:微信 ALIPAY:支付宝 SFPAY:顺手付*/
	private String channelCode;
	/** 顺手付商户号*/
	private String sfpayMchId;
	/** 渠道商户号*/
	private String channelMchId;
	/** 状态 SUCCESS:成功 FAIL:失败 PROCESSING:处理中*/
	private String status;
	/** 备注-存放解析异常*/
	private String remark;
	/**账单文件路径，绝对路径*/
	private String billFilePath;
	/** 创建时间*/
	private Date createDate;
	/** 更新时间*/
	private Date updateDate;

	public Long getId(){
		return id;
	}

	public void setId(Long id){
		this.id = id;
	}

	public String getParseStage(){
		return parseStage;
	}

	public void setParseStage(String parseStage){
		this.parseStage = parseStage;
	}

	public String getTradeTime(){
		return tradeTime;
	}

	public void setTradeTime(String tradeTime){
		this.tradeTime = tradeTime;
	}

	public String getChannelCode(){
		return channelCode;
	}

	public void setChannelCode(String channelCode){
		this.channelCode = channelCode;
	}

	public String getSfpayMchId(){
		return sfpayMchId;
	}

	public void setSfpayMchId(String sfpayMchId){
		this.sfpayMchId = sfpayMchId;
	}

	public String getChannelMchId(){
		return channelMchId;
	}

	public void setChannelMchId(String channelMchId){
		this.channelMchId = channelMchId;
	}

	public String getStatus(){
		return status;
	}

	public void setStatus(String status){
		this.status = status;
	}

	public String getRemark(){
		return remark;
	}

	public void setRemark(String remark){
		this.remark = remark;
	}

	public String getBillFilePath() {
		return billFilePath;
	}

	public void setBillFilePath(String billFilePath) {
		this.billFilePath = billFilePath;
	}

	public Date getCreateDate(){
		return createDate;
	}

	public void setCreateDate(Date createDate){
		this.createDate = createDate;
	}

	public Date getUpdateDate(){
		return updateDate;
	}

	public void setUpdateDate(Date updateDate){
		this.updateDate = updateDate;
	}
}
