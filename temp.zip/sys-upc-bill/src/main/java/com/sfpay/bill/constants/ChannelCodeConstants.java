/**
 * =================================================================
 * 版权所有 2011-2020 顺丰恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.bill.constants;

/**
 * 类说明：<br>
 * 渠道编码定义
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * 
 * CreateDate: 2016-12-28
 */
public interface ChannelCodeConstants {
	
	/**支付宝*/
	public static final String ALIPAY_CHANNEL = "ALIPAY";
	
	/**微信*/
	public static final String WX_CHANNEL = "WX";
	
	/**顺手付*/
	public static final String SFPAY_CHANNEL = "SFPAY";
	
}
