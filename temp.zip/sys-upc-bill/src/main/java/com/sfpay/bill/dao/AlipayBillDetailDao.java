package com.sfpay.bill.dao;
import org.apache.ibatis.annotations.Param;

import com.sfpay.bill.domain.AlipayBillDetail;

/**   
 *
 * @Description: 支付宝账单明细服务类
 * @date 2016-12-24 15:22:55
 * @version V1.0   
 * @author 896728
 */
public interface AlipayBillDetailDao {
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据账单日期、支付宝商户号、商户订单号查询支付宝明细记录
	 * @param tradeTime 账单日期，格式yyyy-MM-dd
	 * @param channelMchId 支付宝商户号
	 * @param mchOrderNo 商户订单号
	 * @return
	 */
	AlipayBillDetail findByChannelMchIdAndMchOrderNo(
			@Param(value = "tradeTime")String tradeTime, 
			@Param(value = "channelMchId")String channelMchId, 
			@Param(value = "mchOrderNo")String mchOrderNo,
			@Param(value = "tradeType")String tradeType);
	
	/**
	 * 保存对象
	 * 
	 */
	void saveAlipayBillDetail(AlipayBillDetail alipayBillDetail);
	
}
