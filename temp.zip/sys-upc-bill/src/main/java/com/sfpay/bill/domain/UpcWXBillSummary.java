package com.sfpay.bill.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 
 * @Description: 统一支付渠道对账单汇总
 * @date 2016-05-17 10:47:49
 * @version V1.0
 * @author 896728
 */

public class UpcWXBillSummary implements Serializable {
	private static final long serialVersionUID = -6850490081522464123L;
	/** id */
	private Long id;
	/** 交易时间 */
	private String tradeTime;
	/** 商户号 */
	private String mchId;
	/** 总交易笔数 */
	private Integer totalTradeCount;
	/** 总交易额 */
	private BigDecimal totalTradeAmount;
	/** 总退款金额 */
	private BigDecimal totalRefundAmount;
	/** 总企业红包退款金额 */
	private BigDecimal totalMchRedpackRefundAmoun;
	/** 总结算金额 */
	private BigDecimal totalSettleAmount;
	/** 手续费总金额 */
	private BigDecimal totalServiceFee;
	/** 创建时间 */
	private Date createDate;
	/** 更新时间 */
	private Date updateDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTradeTime() {
		return tradeTime;
	}

	public void setTradeTime(String tradeTime) {
		this.tradeTime = tradeTime;
	}

	public String getMchId() {
		return mchId;
	}

	public void setMchId(String mchId) {
		this.mchId = mchId;
	}

	public Integer getTotalTradeCount() {
		return totalTradeCount;
	}

	public void setTotalTradeCount(Integer totalTradeCount) {
		this.totalTradeCount = totalTradeCount;
	}

	public BigDecimal getTotalTradeAmount() {
		return totalTradeAmount;
	}

	public void setTotalTradeAmount(BigDecimal totalTradeAmount) {
		this.totalTradeAmount = totalTradeAmount;
	}

	public BigDecimal getTotalRefundAmount() {
		return totalRefundAmount;
	}

	public void setTotalRefundAmount(BigDecimal totalRefundAmount) {
		this.totalRefundAmount = totalRefundAmount;
	}

	public BigDecimal getTotalMchRedpackRefundAmoun() {
		return totalMchRedpackRefundAmoun;
	}

	public void setTotalMchRedpackRefundAmoun(BigDecimal totalMchRedpackRefundAmoun) {
		this.totalMchRedpackRefundAmoun = totalMchRedpackRefundAmoun;
	}

	public BigDecimal getTotalSettleAmount() {
		return totalSettleAmount;
	}

	public void setTotalSettleAmount(BigDecimal totalSettleAmount) {
		this.totalSettleAmount = totalSettleAmount;
	}

	public BigDecimal getTotalServiceFee() {
		return totalServiceFee;
	}

	public void setTotalServiceFee(BigDecimal totalServiceFee) {
		this.totalServiceFee = totalServiceFee;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

}
