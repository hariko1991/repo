package com.sfpay.bill.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.bill.domain.UpcMerchantMap;

/**
 * 
 * @Description: 商户映射服务类
 * @date 2016-04-27 17:17:29
 * @version V1.0
 * @author 896728
 */
public interface UpcMerchantMapDao {


	/**
	 * 查询渠道商户号列表
	 * 
	 * @param channelCode
	 * @param channelMchNo 渠道商户号 可为空
	 * @return
	 */
	List<UpcMerchantMap> queryChannelMchNo(@Param("channelCode")String channelCode, @Param("channelMchNo") String channelMchNo);

}
