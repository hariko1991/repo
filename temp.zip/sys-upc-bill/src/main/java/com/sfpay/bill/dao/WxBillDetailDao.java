package com.sfpay.bill.dao;

import com.sfpay.bill.domain.UpcWXBillDetail;

public interface WxBillDetailDao {

	void insertWXBillDetail(UpcWXBillDetail billDetail);

	long getWxBillDetailNo();

}
