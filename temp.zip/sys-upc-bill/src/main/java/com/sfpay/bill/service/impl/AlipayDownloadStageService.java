/**
 * =================================================================
 * 版权所有 2011-2020 顺丰恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.bill.service.impl;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSON;
import com.alipay.api.AlipayClient;
import com.alipay.api.request.AlipayDataDataserviceBillDownloadurlQueryRequest;
import com.alipay.api.response.AlipayDataDataserviceBillDownloadurlQueryResponse;
import com.sfpay.bill.constants.ChannelCodeConstants;
import com.sfpay.bill.constants.UpcConstants;
import com.sfpay.bill.enums.ParseStage;
import com.sfpay.bill.util.AlipayClientExt;
import com.sfpay.bill.util.AntZipUtils;
import com.sfpay.bill.util.Either;
import com.sfpay.bill.util.FileDeleteUtils;
import com.sfpay.framework2.config.properties.Property;

/**
 * 类说明：<br>
 * 
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * @author jiangxl 江小林
 * 
 * CreateDate: 2016-12-30
 */
@Service
public class AlipayDownloadStageService extends UpcBillDataParseBaseService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	/**
	 * 
	 * 方法说明：<br>
	 * 账单解析封装
	 * @param appId 支付宝应用id
	 * @param channelMerchantId 支付宝商户号
	 * @param merchantPrvK 商户私钥
	 * @param alipayPubKey 支付宝公钥
	 * @param billDate 账单日期
	 */
	public String processBillDataDownload(String appId, String channelMerchantId, String merchantPrvK, String alipayPubKey, String billDate){
		//下载阶段开始
		boolean downloadSuccess = startBillStage(ChannelCodeConstants.ALIPAY_CHANNEL, billDate, channelMerchantId, ParseStage.DOWNLOAD_PARSE.name(), null);
		logger.info(String.format("开始下载返回结果：%s，账单日期：%s，渠道商户号：%s", downloadSuccess, billDate, channelMerchantId));
		if(!downloadSuccess){
			return null;
		}
		
		//账单下载阶段过程
		String filePath = downloadBillDataStage(appId, channelMerchantId, merchantPrvK, alipayPubKey, billDate);
		if(StringUtils.isBlank(filePath)){//下载失败
			downloadSuccess = false;
		}
		
		//下载阶段结束
		endBillStage(ChannelCodeConstants.ALIPAY_CHANNEL, billDate, channelMerchantId, downloadSuccess, ParseStage.DOWNLOAD_PARSE.name(), filePath);
		
		if(downloadSuccess){
			return filePath;
		}
		
		return null;
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 账单下载阶段
	 * @param appId 支付宝应用id
	 * @param channelMerchantId 支付宝商户号
	 * @param merchantPrvK 商户私钥
	 * @param alipayPubKey 支付宝公钥
	 * @param billDate 账单日期
	 */
	private String downloadBillDataStage(String appId, String channelMerchantId, String merchantPrvK, String alipayPubKey, String billDate) {
		//获取支付宝账单下载地址
		Either<String, String> eitherQueryUrl = getAlipayBillDownloadUrl(appId, channelMerchantId, merchantPrvK, alipayPubKey, billDate);
		if(eitherQueryUrl.isRightDefined()){
			logger.error(String.format("获取支付宝账单下载地址结果为空，渠道商户号：%s，账单日期：%s", channelMerchantId, billDate));
			//加入到解析异常信息表里
			upcBillCommonService.saveParseExcpData(ChannelCodeConstants.ALIPAY_CHANNEL, billDate, channelMerchantId, ParseStage.DOWNLOAD_PARSE.name(), eitherQueryUrl.right);
			return null;
		}
		String billDownloadUrl = eitherQueryUrl.left;
		
		//根据支付宝账单下载地址下载对账单到指定地址
		Either<String, String> eitherfilePath = downloadBillData(billDownloadUrl, channelMerchantId, billDate);
		if(eitherfilePath.isRightDefined()) {
			logger.error(String.format("根据支付宝返回地址获取对账单文件失败，渠道商户号：%s，账单日期：%s", channelMerchantId, billDate));
			//下载失败加入到解析异常表里
			upcBillCommonService.saveParseExcpData(ChannelCodeConstants.ALIPAY_CHANNEL, billDate, channelMerchantId, ParseStage.DOWNLOAD_PARSE.name(), eitherfilePath.right);
			return null;
		}
		
		String filePath = eitherfilePath.left;
		//解压压缩文件，解压文件格式是RAR
		String zipFile = filePath+ZIP_FILE_SUFFIX;
		try {
			AntZipUtils.unzipGBK(zipFile, filePath, true);
		} catch (Exception e) {
			logger.error("解压账单压缩文件失败，待解压文件，待解压文件：{}", zipFile);
			
			//如果账单文件解压失败，则删除对应的文件
			File faileFile = new File(zipFile);
			File faileFilePath = new File(filePath);
			FileDeleteUtils.deleteFile(faileFile);
			FileDeleteUtils.deleteFile(faileFilePath);
			
			return null;
		}
		
		return filePath;
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 获取支付宝对账单下载地址
	 * @param appId 第三方应用在支付宝的唯一编号
	 * @param channelMerchantId 支付宝商户号
	 * @param merchantPrvK 商户私钥
	 * @param alipayPubKey 支付宝公钥
	 * @param billDate 账单日期
	 * @return
	 */
	private Either<String, String> getAlipayBillDownloadUrl(String appId, String channelMerchantId, String merchantPrvK, String alipayPubKey, String billDate){
		String downloadQueryUrl = Property.getProperty("ALIPAY_BILLDATA_DOWNLOAD_URL_QUERY");
		logger.info(String.format("支付宝获取账单下载地址接口：%s", downloadQueryUrl));
		
        AlipayClient alipayClient = new AlipayClientExt(downloadQueryUrl,appId,merchantPrvK,"json","UTF-8",alipayPubKey);
        AlipayDataDataserviceBillDownloadurlQueryRequest request = new AlipayDataDataserviceBillDownloadurlQueryRequest();
        Map<String, String> paramMap = new HashMap<String, String>();
        paramMap.put("bill_type", "trade");
        paramMap.put("bill_date", billDate);
        
        request.setBizContent(JSON.toJSONString(paramMap));
        AlipayDataDataserviceBillDownloadurlQueryResponse response;
		try {
			response = alipayClient.execute(request);
		} catch (Exception e) {
			logger.error(String.format("调用支付宝获取对账单下载地址出现异常，支付宝商户号：%s", channelMerchantId), e);
			return Either.Right(String.format("获取支付宝账单下载地址失败，渠道商户号：%s，账单日期：%s", channelMerchantId, billDate));
		}
		
        if(response.isSuccess()){
        	return Either.Left(response.getBillDownloadUrl());
        } else {
        	logger.error(String.format("获取支付宝对账单下载地址失败，支付宝返回结果：%s", JSON.toJSONString(response)));
        	if(StringUtils.equals("isp.bill_not_exist", response.getSubCode())){
        		return Either.Right(UpcConstants.BILL__NOT_EXIST);
        	}
        	return Either.Right(response.getMsg());
        }
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 下载账单数据到指定文件
	 * @param downloadUrl 下载地址
	 * @param channelMchId 渠道商户号
	 * @param billDate 账单日期
	 * @return
	 */
	private Either<String, String> downloadBillData(String downloadUrl, String channelMchId, String billDate){
		//指定希望保存的文件路径
		String saveFilePath = Property.getProperty("ALIPAY_BILLDATA_DOWNLOAD_PATH");
		if(StringUtils.isBlank(saveFilePath)){
			logger.error(String.format("请配置支付宝账单下载存放地址，支付宝商户号：%s", channelMchId));
			return null;
		}
		
		File saveFile = new File(saveFilePath);
		if(!saveFile.exists()){
			saveFile.mkdirs();
			saveFile.setExecutable(true);
			saveFile.setReadable(true);
			saveFile.setWritable(true);
		}
		
		if(saveFilePath.lastIndexOf("/") < (saveFilePath.length()-1)){
			saveFilePath = saveFilePath+"/";
		}
		saveFilePath = saveFilePath+getBillFileName(channelMchId, billDate);
		
		URL url = null;
		HttpURLConnection httpUrlConnection = null;
		InputStream fis = null;
		FileOutputStream fos = null;
		try {
			File fileSave = new File(saveFilePath+ZIP_FILE_SUFFIX);
			if(fileSave.exists()){
				fileSave.delete();
			}
			
			Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress(Property.getProperty("PROXY_HOST"), Integer.parseInt(Property.getProperty("PROXY_PORT")))); 
			url = new URL(downloadUrl);
			httpUrlConnection = (HttpURLConnection) url.openConnection(proxy);
			httpUrlConnection.setConnectTimeout(5 * 1000);
			httpUrlConnection.setDoInput(true);
			httpUrlConnection.setDoOutput(true);
			httpUrlConnection.setUseCaches(false);
			httpUrlConnection.setRequestMethod("GET");
			httpUrlConnection.setRequestProperty("Charsert", "UTF-8");
			httpUrlConnection.connect();
			fis = httpUrlConnection.getInputStream();
			byte[] temp = new byte[1024];
			int b;
			
			fos = new FileOutputStream(fileSave);
			while ((b = fis.read(temp)) != -1) {
				fos.write(temp, 0, b);
				fos.flush();
			}
			
			return Either.Left(saveFilePath);
		} catch (Exception e) {
			logger.error(String.format("下载对账单失败，渠道商户号：%s，账单日期：%s，原因：", channelMchId, billDate), e);
			return Either.Right(String.format("账单下载失败，渠道商户号：%s，账单日期：%s", channelMchId, billDate));
		} finally {
			try {
				if(fis!=null) fis.close();
				if(fos!=null) fos.close();
				if(httpUrlConnection!=null) httpUrlConnection.disconnect();
			} catch (IOException e) {
				logger.error("对账单压缩文件下载失败", e);
			}
		}
		
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 账单文件名称，trade_支付宝商户号_账单日期
	 * @param channelMchId
	 * @param billDate
	 * @return
	 */
	private String getBillFileName(String channelMchId, String billDate) {
		StringBuffer sb = new StringBuffer();
		sb.append(BILL_TRADE_TYPE).append(SEPRATOR).append(channelMchId).append(SEPRATOR).append(billDate);
		
		return sb.toString();
	}
	
}
