/**
 * =================================================================
 * 版权所有 2011-2020 顺丰恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.bill.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Enumeration;

import org.apache.tools.zip.ZipEntry;
import org.apache.tools.zip.ZipFile;
import org.apache.tools.zip.ZipOutputStream;

/**
 * 类说明：<br>
 * ant zip解压压缩工具类
 * 
 * <p>
 * 详细描述：<br>
 * 可以用于文件解压、压缩，可以设置对应的字符编码
 * 
 * </p>
 * 
 * 
 * CreateDate: 2016-12-29
 */
public class AntZipUtils {
	
	/**默认文件编码为UTF-8*/
	public static final String ENCODING_DEFAULT = "UTF-8";    
	/**中文编码为GBK*/
	public static final String ENCODING_GBK = "GBK";
    /**缓冲数组长度*/
    public static final int BUFFER_SIZE_DIFAULT = 128;    
    
    /**
     * 
     * 方法说明：<br>
     * 文件压缩 ，默认使用UTF-8编码
     * @param inFilePaths 待压缩文件路径
     * @param zipPath 压缩后文件路径
     * @throws Exception
     */
    public static void makeZip(String[] inFilePaths, String zipPath)    
            throws Exception {    
        makeZip(inFilePaths, zipPath, ENCODING_DEFAULT);    
    }    
    
    public static void makeZip(String[] inFilePaths, String zipPath,    
            String encoding) throws Exception {    
        File[] inFiles = new File[inFilePaths.length];    
        for (int i = 0; i < inFilePaths.length; i++) {    
            inFiles[i] = new File(inFilePaths[i]);    
        }    
        makeZip(inFiles, zipPath, encoding);    
    }    
    
    public static void makeZip(File[] inFiles, String zipPath) throws Exception {    
        makeZip(inFiles, zipPath, ENCODING_DEFAULT);    
    }    
    
    public static void makeZip(File[] inFiles, String zipPath, String encoding)    
            throws Exception {    
        ZipOutputStream zipOut = new ZipOutputStream(new BufferedOutputStream(    
                new FileOutputStream(zipPath)));    
        zipOut.setEncoding(encoding);    
        for (int i = 0; i < inFiles.length; i++) {    
            File file = inFiles[i];    
            doZipFile(zipOut, file, file.getParent());    
        }    
        zipOut.flush();    
        zipOut.close();    
    }    
    
    private static void doZipFile(ZipOutputStream zipOut, File file,    
            String dirPath) throws FileNotFoundException, IOException {    
        if (file.isFile()) {    
            BufferedInputStream bis = new BufferedInputStream(    
                    new FileInputStream(file));    
            String zipName = file.getPath().substring(dirPath.length());    
            while (zipName.charAt(0) == '\\' || zipName.charAt(0) == '/') {    
                zipName = zipName.substring(1);    
            }    
            
            ZipEntry entry = new ZipEntry(zipName);    
            zipOut.putNextEntry(entry);    
            byte[] buff = new byte[BUFFER_SIZE_DIFAULT];    
            int size;    
            while ((size = bis.read(buff, 0, buff.length)) != -1) {    
                zipOut.write(buff, 0, size);    
            }    
            zipOut.closeEntry();    
            bis.close();    
        } else {    
            File[] subFiles = file.listFiles();    
            for (File subFile : subFiles) {    
                doZipFile(zipOut, subFile, dirPath);    
            }    
        }    
    }    
    
    /**
     * 
     * 方法说明：<br>
     * 文件解压，编码为UTF-8
     * @param zipFilePath
     * @param storePath
     * @param isDelete 是否需要先删除解压后的文件夹，然后再新建 true：是，false：否
     * @throws IOException
     */
    public static void unzipUTF8(String zipFilePath, String storePath, boolean isDelete) throws IOException {
    	unZip(zipFilePath, storePath, ENCODING_DEFAULT, isDelete);
    }
    
    /**
     * 
     * 方法说明：<br>
     * 文件解压，编码为GBK
     * @param zipFilePath 压缩文件绝对路径
     * @param storePath 解压后的文件低至
     * @param isDelete 是否需要先删除解压后的文件夹，然后再新建 true：是，false：否
     * @throws IOException
     */
    public static void unzipGBK(String zipFilePath, String storePath, boolean isDelete) throws IOException {
    	unZip(zipFilePath, storePath, ENCODING_GBK, isDelete);
    }
    
    /**
     * 
     * 方法说明：<br>
     * 根据指定的字符编码解压文件
     * @param zipFilePath 压缩文件绝对路径
     * @param storePath 解压后的文件低至
     * @param charset 字符编码
     * @param isDelete 是否需要先删除解压后的文件夹，然后再新建 true：是，false：否
     * @throws IOException
     */
    private static void unZip(String zipFilePath, String storePath, String charset, boolean isDelete)    
            throws IOException {    
        unZip(new File(zipFilePath), storePath, charset, isDelete);    
    }    
    
    /**
     * 
     * 方法说明：<br>
     * 根据指定的字符编码解压文件
     * @param zipFile 压缩文件对象
     * @param storePath 解压后的文件低至
     * @param charset 字符编码
     * @param isDelete 是否需要先删除解压后的文件夹，然后再新建 true：是，false：否
     * @throws IOException
     */
    private static void unZip(File zipFile, String storePath, String charset, boolean isDelete) throws IOException {    
    	File storeFile = new File(storePath);
    	
    	if(isDelete){
    		//先删除文件夹
        	FileDeleteUtils.deleteFile(storeFile); 
    	}
    	if(!storeFile.exists()){
    		storeFile.mkdirs();    
    	} 
    
        ZipFile zip = new ZipFile(zipFile, charset);    
        try {
        	Enumeration<ZipEntry> entries = (Enumeration<ZipEntry>) zip.getEntries();    
            while (entries.hasMoreElements()) {    
                ZipEntry zipEntry = entries.nextElement();    
                if (zipEntry.isDirectory()) {    
                    // TODO    
                } else {    
                    String zipEntryName = zipEntry.getName();  
                    
                    if (zipEntryName.indexOf(File.separator) > 0) {    
                        String zipEntryDir = zipEntryName.substring(0, zipEntryName    
                                .lastIndexOf(File.separator) + 1);    
                        String unzipFileDir = storePath + File.separator    
                                + zipEntryDir;    
                        File unzipFileDirFile = new File(unzipFileDir);    
                        if (!unzipFileDirFile.exists()) {    
                            unzipFileDirFile.mkdirs();    
                        }    
                    }    
        
                    InputStream is = zip.getInputStream(zipEntry);    
                    FileOutputStream fos = new FileOutputStream(new File(storePath    
                            + File.separator + zipEntryName));    
                    byte[] buff = new byte[BUFFER_SIZE_DIFAULT];    
                    int size;    
                    while ((size = is.read(buff)) > 0) {    
                        fos.write(buff, 0, size);    
                    }    
                    fos.flush();    
                    fos.close();    
                    is.close();    
                }    
            }
		} finally {
			zip.close();
		}
    }    
}
