package com.sfpay.bill.dao;

import org.apache.ibatis.annotations.Param;

import com.sfpay.bill.domain.AllChannelBillSummary;

/**
 *
 * @Description: 渠道账单汇总服务类
 * @date 2016-12-24 15:24:10
 * @version V1.0
 * @author 896728
 */
public interface AllChannelBillSummaryDao {

	/**
	 * 查找列表
	 * 
	 * @param model
	 *            中间类
	 * @param pageHelper
	 *            分页对象
	 */
	String findAllChannelBillSummarys();
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据渠道商户号、账单日期、渠道编码哈讯汇总信息
	 * @param channelMchId
	 * @param tradeTime
	 * @param channelCode
	 * @return
	 */
	AllChannelBillSummary findSummaryByChaMchIdAndDate(
			@Param(value = "channelMchId")String channelMchId, 
			@Param(value = "tradeTime")String tradeTime, 
			@Param(value = "channelCode")String channelCode);

	/**
	 * 更新对象
	 * 
	 * @param model
	 */
	void updateAllChannelBillSummary(AllChannelBillSummary allChannelBillSummary);

	/**
	 * 保存对象
	 * 
	 * @param model
	 */
	void saveAllChannelBillSummary(AllChannelBillSummary allChannelBillSummary);
}
