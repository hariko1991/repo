package com.sfpay.bill.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.bill.domain.UpcChannelArg;

public interface ChannelArgDao {

	List<UpcChannelArg> queryArgsByChannelCodeAndMchNo(@Param("channelMchParamKey")String channelMchParamKey);

}
