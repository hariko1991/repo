package com.sfpay.bill.dao;

import com.sfpay.bill.domain.UpcWXBillSummary;

public interface UpcWxBillSummaryDao {

	void insertWxBillSummary(UpcWXBillSummary summary);

}
