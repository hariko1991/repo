package com.sfpay.bill.enums;

public enum ParseStage {
	DOWNLOAD_PARSE("下载阶段"), NORMAL_PARSE("解析阶段");

	String text;

	private ParseStage(String text) {
		this.text = text;
	}

	public String getText() {
		return text;
	}
}
