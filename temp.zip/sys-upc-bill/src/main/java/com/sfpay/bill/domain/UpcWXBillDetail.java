package com.sfpay.bill.domain;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * 
 * @Description: 微信对账单明细
 * @date 2016-05-14 14:26:55
 * @version V1.0
 * @author 896728
 */

public class UpcWXBillDetail implements Serializable {
	private static final long serialVersionUID = -2441148234286203457L;
	/** id */
	private Long id;
	/** 交易时间 */
	private String tradeTime;
	/** 公众号Id */
	private String appid;
	/** 商户号 */
	private String mchId;
	/** 子商户号 */
	private String subMchId;
	/** 设备号 */
	private String deviceCode;
	/** 微信订单号 */
	private String wxOrderNo;
	/** 商户订单号 */
	private String mchOrderNo;
	/** 用户标识 */
	private String userInfo;
	/** 交易类型 */
	private String tradeType;
	/** 交易状态 */
	private String tradeState;
	/** 付款银行 */
	private String payBankCode;
	/** 货币种类 */
	private String ccy;
	/** 交易总金额 */
	private BigDecimal tradeAmount;
	/** 企业红包金额 */
	private BigDecimal mchRedpackAmount;
	/** 企业红包退款金额 */
	private BigDecimal mchRefundRedpackAmount;
	/** 微信退款单号 */
	private String wxRefundNo;
	/** 商户退款单号 */
	private String mchRefundNo;
	/** 退款金额 */
	private BigDecimal refundAmount;
	/**
	 * 退款类型 ORIGINAL—原路退款 BALANCE—退回到余额
	 */
	private String refundType;
	/** 退款状态 */
	private String refundStatus;
	/** 商品名称 */
	private String goodsName;
	/** 备注 */
	private String remark;
	/** 服务费 */
	private BigDecimal serviceFee;
	/** 费率 */
	private String feeRate;
	/** 创建时间 */
	private Date createDate;
	/** 更新时间 */
	private Date updateDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getTradeTime() {
		return tradeTime;
	}

	public void setTradeTime(String tradeTime) {
		this.tradeTime = tradeTime;
	}

	public String getAppid() {
		return appid;
	}

	public void setAppid(String appid) {
		this.appid = appid;
	}

	public String getMchId() {
		return mchId;
	}

	public void setMchId(String mchId) {
		this.mchId = mchId;
	}

	public String getSubMchId() {
		return subMchId;
	}

	public void setSubMchId(String subMchId) {
		this.subMchId = subMchId;
	}

	public String getDeviceCode() {
		return deviceCode;
	}

	public void setDeviceCode(String deviceCode) {
		this.deviceCode = deviceCode;
	}

	public String getWxOrderNo() {
		return wxOrderNo;
	}

	public void setWxOrderNo(String wxOrderNo) {
		this.wxOrderNo = wxOrderNo;
	}

	public String getMchOrderNo() {
		return mchOrderNo;
	}

	public void setMchOrderNo(String mchOrderNo) {
		this.mchOrderNo = mchOrderNo;
	}

	public String getUserInfo() {
		return userInfo;
	}

	public void setUserInfo(String userInfo) {
		this.userInfo = userInfo;
	}

	public String getTradeType() {
		return tradeType;
	}

	public void setTradeType(String tradeType) {
		this.tradeType = tradeType;
	}

	public String getTradeState() {
		return tradeState;
	}

	public void setTradeState(String tradeState) {
		this.tradeState = tradeState;
	}

	public String getPayBankCode() {
		return payBankCode;
	}

	public void setPayBankCode(String payBankCode) {
		this.payBankCode = payBankCode;
	}

	public String getCcy() {
		return ccy;
	}

	public void setCcy(String ccy) {
		this.ccy = ccy;
	}

	public BigDecimal getTradeAmount() {
		return tradeAmount;
	}

	public void setTradeAmount(BigDecimal tradeAmount) {
		this.tradeAmount = tradeAmount;
	}

	public BigDecimal getMchRedpackAmount() {
		return mchRedpackAmount;
	}

	public void setMchRedpackAmount(BigDecimal mchRedpackAmount) {
		this.mchRedpackAmount = mchRedpackAmount;
	}

	public BigDecimal getMchRefundRedpackAmount() {
		return mchRefundRedpackAmount;
	}

	public void setMchRefundRedpackAmount(BigDecimal mchRefundRedpackAmount) {
		this.mchRefundRedpackAmount = mchRefundRedpackAmount;
	}

	public String getWxRefundNo() {
		return wxRefundNo;
	}

	public void setWxRefundNo(String wxRefundNo) {
		this.wxRefundNo = wxRefundNo;
	}

	public String getMchRefundNo() {
		return mchRefundNo;
	}

	public void setMchRefundNo(String mchRefundNo) {
		this.mchRefundNo = mchRefundNo;
	}

	public BigDecimal getRefundAmount() {
		return refundAmount;
	}

	public void setRefundAmount(BigDecimal refundAmount) {
		this.refundAmount = refundAmount;
	}

	public String getRefundType() {
		return refundType;
	}

	public void setRefundType(String refundType) {
		this.refundType = refundType;
	}

	public String getRefundStatus() {
		return refundStatus;
	}

	public void setRefundStatus(String refundStatus) {
		this.refundStatus = refundStatus;
	}

	public String getGoodsName() {
		return goodsName;
	}

	public void setGoodsName(String goodsName) {
		this.goodsName = goodsName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public BigDecimal getServiceFee() {
		return serviceFee;
	}

	public void setServiceFee(BigDecimal serviceFee) {
		this.serviceFee = serviceFee;
	}

	public String getFeeRate() {
		return feeRate;
	}

	public void setFeeRate(String feeRate) {
		this.feeRate = feeRate;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public Date getUpdateDate() {
		return updateDate;
	}

	public void setUpdateDate(Date updateDate) {
		this.updateDate = updateDate;
	}

}
