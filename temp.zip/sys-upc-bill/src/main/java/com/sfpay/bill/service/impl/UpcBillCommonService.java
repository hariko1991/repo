/**
 * =================================================================
 * 版权所有 2011-2020 顺丰恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.bill.service.impl;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.bill.constants.ChannelTradeTypeConstants;
import com.sfpay.bill.constants.UpcConstants;
import com.sfpay.bill.dao.AlipayBillDetailDao;
import com.sfpay.bill.dao.AllChannelBillDetailDao;
import com.sfpay.bill.dao.AllChannelBillSummaryDao;
import com.sfpay.bill.dao.ParseBillProcDao;
import com.sfpay.bill.domain.AlipayBillDetail;
import com.sfpay.bill.domain.AllChannelBillDetail;
import com.sfpay.bill.domain.AllChannelBillSummary;
import com.sfpay.bill.domain.ParseBillProc;
import com.sfpay.bill.enums.ParseStatus;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 类说明：<br>
 * 账单公共服务
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * 
 * CreateDate: 2017-1-1
 */
@Service
public class UpcBillCommonService {
	private final Logger logger = LoggerFactory.getLogger(getClass());
	
	@Resource
	private AlipayBillDetailDao alipayBillDetailDao;
	@Resource
	private AllChannelBillDetailDao allChannelBillDetailDao;
	@Resource
	private AllChannelBillSummaryDao allChannelBillSummaryDao;
	@Resource
	private ParseBillProcDao parseBillProcDao;

	public void saveAlipayBillDetail(AlipayBillDetail alipayBillDetail) throws ServiceException {
		try {
			alipayBillDetailDao.saveAlipayBillDetail(alipayBillDetail);
		} catch (Exception e) {
			logger.error("单条保存支付宝账单明细记录出错，原因：", e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "数据库保存记录异常");
		}
	}

	public AlipayBillDetail findAlipayDetailByMchIdAndDate(String channelMchId, String tradeDate, String mchOrderNo, String billType) throws ServiceException {
		try {
			return alipayBillDetailDao.findByChannelMchIdAndMchOrderNo(tradeDate, channelMchId, mchOrderNo, billType);
		} catch (Exception e) {
			logger.error(String.format("根据支付宝商户号、账单日期、商户订单号查询支付宝账单明细记录出错，支付宝商户号：%s，账单日期：%s，商户订单号：%s，原因：", 
					channelMchId, tradeDate, mchOrderNo), e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "数据库保存记录异常");
		}
	}

	/**
	 * 
	 * 方法说明：<br>
	 * 保存公共明细记录
	 * @param ad
	 * @return
	 */
	public boolean saveAllChannelDetail(AllChannelBillDetail ad) {
		try {
			//查询对应的记录是否已经存在
			AllChannelBillDetail old = null;
			if(StringUtils.equals(ChannelTradeTypeConstants.PAY, ad.getTradeType())){
				old = allChannelBillDetailDao.findAllChannelBillDetailByMchOrderNo(ad.getMchOrderNo(), ad.getChannelCode(), 
						ad.getChannelMchId(), ad.getTradeTime(), ad.getTradeType());
			}else{
				old = allChannelBillDetailDao.findAllChannelBillDetailByMchOrderNo(ad.getMchRefundNo(), ad.getChannelCode(), 
						ad.getChannelMchId(), ad.getTradeTime(), ad.getTradeType());
			}
			
			if(old != null){
				logger.info(String.format("对应的记录已经存在，商户订单号：%s，商户退款单号：%s，交易类型：%s", ad.getMchOrderNo(), ad.getMchRefundNo(), ad.getTradeType()));
				return true;
			}
			
			allChannelBillDetailDao.saveAllChannelBillDetail(ad);
			return true;
		} catch (Exception e) {
			logger.error(String.format("保存支付宝公共明细数据出现异常，商户订单号：%s", ad.getMchOrderNo()), e);
			return false;
		}
	}

	/**
	 * 
	 * 方法说明：<br>
	 * 保存公共汇总记录
	 * @param summary
	 * @return
	 * Anthor:jiangxl 江小林
	 */
	public boolean saveAllChanelSummary(AllChannelBillSummary summary) {
		try {
			//查询记录是否已经存在
			AllChannelBillSummary old = allChannelBillSummaryDao.findSummaryByChaMchIdAndDate(summary.getChannelMchId(), summary.getTradeTime(), summary.getChannelCode());
			if(old != null){
				logger.info(String.format("(saveAllChanelSummary)渠道汇总记录已经存在，渠道商户号：%s，账单日期：%s，渠道编码：%s", 
						summary.getChannelMchId(), summary.getTradeTime(), summary.getChannelCode()));
				return true;
			}
			
			allChannelBillSummaryDao.saveAllChannelBillSummary(summary);
			return true;
		} catch (Exception e) {
			logger.error(String.format("保存渠道汇总记录失败，渠道商户号：%s，账单日期：%s，渠道编码：%s", 
					summary.getChannelMchId(), summary.getTradeTime(), summary.getChannelCode()));
			return false;
		}
	}

	/**
	 * 
	 * 方法说明：<br>
	 * 保存支付宝交易明细
	 * @param billDetail
	 * @return
	 */
	public boolean saveAlipayDetail(AlipayBillDetail billDetail) {
		try {
			//判断对应的订单是否已经解析过
			AlipayBillDetail old = null;
			if(StringUtils.equals(ChannelTradeTypeConstants.PAY, billDetail.getBusinessType())){
				old = findAlipayDetailByMchIdAndDate(billDetail.getChannelMchId(), 
						billDetail.getTradeTime(), billDetail.getMchOrderNo(), billDetail.getBusinessType());
			}else{
				old = findAlipayDetailByMchIdAndDate(billDetail.getChannelMchId(), 
						billDetail.getTradeTime(), billDetail.getRefundNo(), billDetail.getBusinessType());
			}
			
			if(old != null) {
				logger.info(String.format("该条记录已经入库，不用重复入库，商户订单号：%s，账单日期：%s", billDetail.getMchOrderNo(), 
						billDetail.getTradeTime()));
				return true;
			}
			
			saveAlipayBillDetail(billDetail);
			return true;
		} catch (Exception e) {
			logger.error(String.format("保存支付宝账单明细失败，商户订单号：%s，业务类型：%s", billDetail.getMchOrderNo(), billDetail.getBusinessType()), e);
			return false;
		}
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据渠道商户号、账单日期、解析阶段查询解析过程记录
	 * @param channelCode 渠道编码必传
	 * @param channelMchId 渠道商户号
	 * @param billDate 账单日期
	 * @param parseStage 解析阶段，包括下载阶段、解析阶段
	 * @return
	 */
	public ParseBillProc findProcByMchIdAndBillDate(String channelCode,
			String channelMchId, String billDate, String parseStage) {
		try {
			return parseBillProcDao.findProcByMchIdAndCode(billDate, channelCode, channelMchId, parseStage);
		} catch (Exception e) {
			logger.error(String.format("(method:findProcByMchIdAndBillDate)查询已经存在的解析过程记录失败，账单日期：%s，渠道商户号：%s", billDate, channelMchId), e);
			return null;
		}
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 保存解析异常数据
	 * @param channelCode 渠道编码
	 * @param billDate 账单日期
	 * @param channelMchId 渠道商户号
	 * @param parseStage 解析阶段，包括：下载文件阶段，正常解析阶段
	 * @param remark 备注
	 */
	public void saveParseExcpData(String channelCode, String billDate,
			String channelMchId, String parseStage, String remark) {
		logger.info(String.format("saveParseExcpData 开始。。。账单日期：%s，渠道商户号：%s，解析阶段：%s", billDate, channelMchId, parseStage));
		//先查询对应的记录是否存在
		ParseBillProc  proc = findProcByMchIdAndBillDate(channelCode, channelMchId, billDate, parseStage);
		
		if(proc == null) {
			ParseBillProc billProc = null;
			billProc = new ParseBillProc();
			billProc.setChannelCode(channelCode);
			billProc.setChannelMchId(channelMchId);
			billProc.setParseStage(parseStage);
			billProc.setSfpayMchId(null);
			billProc.setStatus(ParseStatus.FAIL.name());
			billProc.setTradeTime(billDate);
			billProc.setRemark(remark);
			
			try {
				parseBillProcDao.saveParseBillProc(proc);
			} catch (Exception e) {
				logger.error(String.format("(method:saveParseExcpData)保存解析过程记录失败，账单日期：%s，渠道商户号：%s", billDate, channelMchId), e);
			}
			return;
		}
		
		if(StringUtils.isBlank(remark)) {
			return;
		}
		
		String status = null;//此处状态不要随便设置，目前仅处理账单不存在的情况
		if(StringUtils.equals(UpcConstants.BILL__NOT_EXIST, remark)){
			status = ParseStatus.UNPROCESS_FAIL.name();//如果是账单不存在，则不用处理
		}
		
		try {
			parseBillProcDao.saveParseErrMsg(remark, status, proc.getId());
		} catch (Exception e) {
			logger.error(String.format("更新备注信息失败，渠道商户号：%s，账单日期：%s，原因", channelMchId, billDate), e);
		}
	}
}
