/**
 * =================================================================
 * 版权所有 2011-2020 顺丰恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.bill.service.impl;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

/**
 * 类说明：<br>
 * 异步处理支付宝账单
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * 
 * CreateDate: 2017-1-1
 */
@Service
public class AsyncProcessAlipayBillData {
	
	@Resource
	private AlipayDownloadStageService downloadStageService;
	@Resource
	private AlipayParseBillDataStageService parseDataStageService;
	
	/**
	 * 
	 * 方法说明：<br>
	 * 处理支付宝账单解析，包括：账单下载及内容解析
	 * @param appId 第三方应用在支付宝的唯一编号
	 * @param channelMerchantId 支付宝商户号
	 * @param merchantPrvK 商户私钥
	 * @param alipayPubKey 支付宝公钥
	 * @param billDate 账单日期
	 * @param onlyParseFile 是否只解析文件，true：只进行文件解析，false：先下载文件，后解析文件内容
	 * @param parseFilePath 待解析文件地址，如果onlyParseFile=true，必须有值
	 */
	@Async
	public void processBillParse(String appId, String channelMerchantId, String merchantPrvK, String alipayPubKey, String billDate, 
			boolean onlyParseFile, String parseFilePath){
		if(!onlyParseFile){
			//账单下载
			parseFilePath = downloadStageService.processBillDataDownload(appId, channelMerchantId, merchantPrvK, alipayPubKey, billDate);
			if(StringUtils.isBlank(parseFilePath)){
				return;
			}
		}
		
		//账单解析
		parseDataStageService.processBillDataParse(parseFilePath, channelMerchantId, billDate);
	}
}
