package com.sfpay.bill.service.impl;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.bill.constants.UpcConstants;
import com.sfpay.bill.dao.UpcMerchantMapDao;
import com.sfpay.bill.domain.UpcMerchantMap;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：<br>
 * 统一支付流水管理
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-18
 */
@Service
public class UpcMerchantMapService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private UpcMerchantMapDao upcMerchantMapDao;

	public List<UpcMerchantMap> queryDistinctMerchantMap(String channelCode) throws ServiceException {
		try {
			List<UpcMerchantMap> mchMapList = upcMerchantMapDao.queryChannelMchNo(channelCode, null);
			List<UpcMerchantMap> distinctMchMapList = new ArrayList<UpcMerchantMap>();

			if (mchMapList == null || mchMapList.isEmpty()) {
				return distinctMchMapList;
			}
			for (UpcMerchantMap map : mchMapList) {
				setNotExists(distinctMchMapList, map);
			}

			return distinctMchMapList;
		} catch (Exception e) {
			logger.error("查询商户映射异常", e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "数据库查询出错");
		}
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据渠道编码、渠道商户号查询商户映射信息
	 * @param channelCode 渠道编码
	 * @param channelMchId 渠道商户号
	 * @return
	 * @throws ServiceException
	 */
	public UpcMerchantMap queryDistinctMerMapByChannelMchId(String channelCode, String channelMchId) throws ServiceException {
		logger.info(String.format("根据渠道商户号查询商户映射配置，渠道编码：%s，渠道商户号：%s", channelCode, channelMchId));
		if(StringUtils.isBlank(channelCode) || StringUtils.isBlank(channelMchId)){
			throw new ServiceException(UpcConstants.PARAM_NULL, "参数不能为空");
		}
		
		try {
			List<UpcMerchantMap> mchMapList = upcMerchantMapDao.queryChannelMchNo(channelCode, channelMchId);
			if(mchMapList == null || mchMapList.size() == 0){
				return null;
			}
			
			return mchMapList.get(0);
		} catch (Exception e) {
			logger.error(String.format("查询渠道配置映射失败，渠道编码：%s，渠道商户号：%s", channelCode, channelMchId), e);
			throw new ServiceException(UpcConstants.FAILURE_DB, "数据库查询出错");
		}
	}

	private void setNotExists(List<UpcMerchantMap> distinctMchMapList, UpcMerchantMap map) {
		
		if(map == null) {
			return;
		}
		boolean isExistChannelMchNo = false;
		for (UpcMerchantMap mm : distinctMchMapList) {
			if (mm.getChannelMchNo().equals(map.getChannelMchNo())) {
				isExistChannelMchNo = true;
				break;
			}
		}

		if (!isExistChannelMchNo) {
			distinctMchMapList.add(map);
		}
	}

}
