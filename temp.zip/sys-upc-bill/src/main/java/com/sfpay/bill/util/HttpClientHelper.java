package com.sfpay.bill.util;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URI;
import java.security.cert.X509Certificate;
import java.util.Map;

import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManager;
import javax.net.ssl.X509TrustManager;

import org.apache.http.HttpEntity;
import org.apache.http.HttpHost;
import org.apache.http.HttpResponse;
import org.apache.http.auth.AuthScope;
import org.apache.http.auth.UsernamePasswordCredentials;
import org.apache.http.client.AuthCache;
import org.apache.http.client.CredentialsProvider;
import org.apache.http.client.HttpClient;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.client.protocol.HttpClientContext;
import org.apache.http.conn.params.ConnRouteParams;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.auth.BasicScheme;
import org.apache.http.impl.client.BasicAuthCache;
import org.apache.http.impl.client.BasicCredentialsProvider;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicHeader;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.sfpay.acquirer.common.StringUtils;
import com.sfpay.acquirer.helper.ReaderHelper;
import com.sfpay.framework2.config.properties.Property;

public final class HttpClientHelper {
	private static final Logger logger = LoggerFactory.getLogger(HttpClientHelper.class);
	private static String proxyHost;
	private static int proxyPort = -1;
	private static String port;
	private static String[] nonProxyHosts = null;
	private static final String SEPRATOR = "\\|";

	/**
	 * 
	 * 方法说明：<br>
	 * 发送http post请求，默认header为空，charset=UTF-8,connect-timeout=5000ms,read-timeout=20000ms
	 * @param url 需要请求的url
	 * @param meta 请求的参数
	 * @return
	 * @throws Exception
	 * Anthor:744723 江小林
	 */
	public static String sendByPost(String url, String meta) throws Exception {
		return sendByPost(url, meta, "UTF-8",null);
	}

	/**
	 * 
	 * 方法说明：<br>
	 * 发送http post请求 可以传递header参数，charset=UTF-8,connect-timeout=5000ms,read-timeout=20000ms
	 * @param url请求的Url
	 * @param meta 请求参数
	 * @param header 请求头
	 * @return
	 * @throws Exception
	 * Anthor:744723 江小林
	 */
	public static String sendByPost(String url, String meta,Map<String, String> header) throws Exception {
		return sendByPost(url, meta, "UTF-8",header);
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 发送http post请求，可以传递header参数，charset参数connect-timeout=5000ms,read-timeout=20000ms
	 * @param url请求Url
	 * @param meta 请求参数
	 * @param charset请求参数编码
	 * @param header请求头
	 * @return
	 * @throws Exception
	 * Anthor:744723 江小林
	 */
	public static String sendByPost(String url, String meta, String charset,Map<String, String> header) throws Exception {
		return sendByPost(url, meta, charset, 5000, 20000, header);
	}

	public static String sendByPost(String url, String meta, String charset, int conn, int read,
			Map<String, String> header) throws Exception {
		if (StringUtils.isEmpty(url)) {
			throw new IllegalArgumentException("URL不能为空");
		}

		String cs = StringUtils.isEmpty(charset) ? "UTF-8" : charset;
		HttpClientBuilder builder = HttpClients.custom();

		HttpHost proxy = null;
		HttpHost target = null;
		HttpClientContext context = null;
		logger.info(String.format("代理服务器: %s, 端口: %s, 编码: %s, URL: %s",
				new Object[] { proxyHost, Integer.valueOf(proxyPort), cs, url }));
		BasicScheme basicAuth;
		
		boolean ignoreProxy = false;
		if(checkIsNonProxy(url)){//判断该地址是否需要走代理 true：不走代理 false：走代理
			ignoreProxy = true;
		}
		
		logger.info(ignoreProxy? "不走代理：[{}]": "走代理：[{}]", url);
		if (!ignoreProxy && (!StringUtils.isEmpty(proxyHost)) && (proxyPort != -1)) {
			proxy = new HttpHost(proxyHost, proxyPort);
			URI uri = new URI(url);
			target = new HttpHost(uri.getHost(), uri.getPort(), uri.getScheme());

			CredentialsProvider provider = new BasicCredentialsProvider();
			provider.setCredentials(new AuthScope(proxyHost, proxyPort), new UsernamePasswordCredentials("",
					""));
			builder.setDefaultCredentialsProvider(provider);
			AuthCache auth = new BasicAuthCache();
			basicAuth = new BasicScheme();
			auth.put(proxy, basicAuth);

			context = HttpClientContext.create();
			context.setCredentialsProvider(provider);
			context.setAuthCache(auth);
		}
		if (url.startsWith("https")) {
			builder.setSSLSocketFactory(createSSLFacoty());
		}

		HttpPost req = new HttpPost(url);
		req.setConfig(RequestConfig.custom().setSocketTimeout(read).setConnectTimeout(conn).setProxy(proxy)
				.build());
		req.addHeader(new BasicHeader("Content-Type", "application/x-www-form-urlencoded;charset="+cs));
		if (!StringUtils.isEmpty(meta)) {
			logger.info("请求参数: {}", meta);
			req.setEntity(new StringEntity(meta, cs));
		}
		if ((null != header) && (header.size() > 0)) {
			for (Map.Entry entry : header.entrySet()) {
				req.setHeader((String) entry.getKey(), (String) entry.getValue());
			}
		}
		CloseableHttpResponse resp = null;
		CloseableHttpClient client = builder.build();
		if (null == proxy)
			resp = client.execute(req);
		else {
			resp = client.execute(target, req, context);
		}
		try {
			return ReaderHelper.getPlain(resp.getEntity().getContent(), cs);
		} finally {
			try {
				resp.close();
				client.close();
			} catch (Exception e) {
				logger.error("", e);
			}
		}
	}
	
	public static String httpGet(String url) throws Exception {
		if (StringUtils.isEmpty(url)) {
			throw new IllegalArgumentException("URL不能为空");
		}

		HttpClientBuilder builder = HttpClients.custom();
		// 创建HttpClient实例
		HttpClient client = new DefaultHttpClient();
		if ((!StringUtils.isEmpty(proxyHost)) && (proxyPort != -1)) {
			client = getHttpClient(proxyHost, proxyPort);
		}
		if (url.startsWith("https")) {
			builder.setSSLSocketFactory(createSSLFacoty());
		}

		StringBuffer sb = new StringBuffer();

		// 创建httpGet
		HttpGet httpGet = new HttpGet(url);
		// 执行
		try {
			HttpResponse response = client.execute(httpGet);
			HttpEntity entry = response.getEntity();
			if (entry != null) {
				InputStreamReader is = new InputStreamReader(entry.getContent(), "utf-8");
				BufferedReader br = new BufferedReader(is);
				String str = null;
				while ((str = br.readLine()) != null) {
					sb.append(str.trim());
				}
				br.close();
			}

		} catch (Exception e) {
			logger.error("httpget异常: url:[{}]" + url, e);
		}
		return sb.toString();
	}
	
	public static HttpClient getHttpClient(String proxyHost, int proxyPort) {

		DefaultHttpClient httpClient = new DefaultHttpClient();
		httpClient.getCredentialsProvider().setCredentials(new AuthScope(proxyHost, proxyPort),
				new UsernamePasswordCredentials("", ""));
		HttpHost proxy = new HttpHost(proxyHost, proxyPort);
		httpClient.getParams().setParameter(ConnRouteParams.DEFAULT_PROXY, proxy);
		return httpClient;
	}

	private static SSLConnectionSocketFactory createSSLFacoty() throws Exception {
		X509TrustManager x509mgr = new X509TrustManager() {
			public void checkClientTrusted(X509Certificate[] xcs, String string) {
			}

			public void checkServerTrusted(X509Certificate[] xcs, String string) {
			}

			public X509Certificate[] getAcceptedIssuers() {
				return null;
			}
		};
		SSLContext ctx = SSLContext.getInstance("TLS");
		ctx.init(null, new TrustManager[] { x509mgr }, null);
		return new SSLConnectionSocketFactory(ctx, SSLConnectionSocketFactory.ALLOW_ALL_HOSTNAME_VERIFIER);
	}

	static {
		try {
			proxyHost = Property.getProperty("PROXY_HOST");
			port = Property.getProperty("PROXY_PORT");
			proxyPort = StringUtils.isEmpty(port) ? -1 : Integer.parseInt(port);
			String nonProxy = Property.getProperty("NONPROXY_HOSTS");
			if(!StringUtils.isEmpty(nonProxy)){
				nonProxyHosts = nonProxy.split(SEPRATOR);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 检测Ip是否需要代理
	 * 目前免代理IP配置只支持结尾配置*和倒数第二个段配*，eg:10.79.*.*和10.79.11.*这两种
	 * @param url
	 * @return true：不走代理，false:走代理
	 * Anthor:744723 江小林
	 */
	public static boolean checkIsNonProxy(String url){
		if(StringUtils.isEmpty(url)){
			return true;
		}
		boolean isNonProxy = false;
		if(nonProxyHosts != null && nonProxyHosts.length > 0){
			for(int i = 0; i < nonProxyHosts.length; i++){
				String host = nonProxyHosts[i];
				//去掉开头的*
				if(host.indexOf("*.") == 0 && host.length() > 2){
					host = host.substring(2, host.length());
				}
				//去掉结尾的*
				if(host.lastIndexOf(".*") > 0){
					host = host.replace(".*", "");
				}
				if(url.equals("localhost") || url.equals("127.0.0.1")){
					isNonProxy = true;
					break;
				}
				if(url.indexOf(host) > 0){
					isNonProxy = true;
					break;
				}
			}
		}
		return isNonProxy;
	}
}