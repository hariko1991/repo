package com.sfpay.bill.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.sfpay.bill.domain.ParseBillProc;

/**
 *
 * @Description: 账单解析过程服务类
 * @date 2016-12-24 15:24:40
 * @version V1.0
 * @author 896728
 */
public interface ParseBillProcDao {
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据账单日期、渠道编码、渠道商户号、解析类型查询解析记录
	 * @param tradeTime 账单日期
	 * @param channelCode 渠道编码
	 * @param channelMchId 渠道商户号  
	 * @param parseStage 解析阶段
	 * @return
	 */
	ParseBillProc findProcByMchIdAndCode(
			@Param(value = "tradeTime")String tradeTime, 
			@Param(value = "channelCode")String channelCode, 
			@Param(value = "channelMchId")String channelMchId, 
			@Param(value = "parseStage")String parseStage);

	/**
	 * 
	 * 方法说明：<br>
	 * 根据记录ID、原解析记录状态更新数据
	 * @param parseBillProc
	 * @param oldStatus
	 */
	int updateParseBillProcByStatus(@Param(value = "entity")ParseBillProc parseBillProc, @Param(value = "oldStatus")String oldStatus);

	/**
	 * 保存对象
	 * 
	 * @param model
	 */
	void saveParseBillProc(ParseBillProc parseBillProc);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 保存错误信息
	 * @param remark
	 * @param id
	 */
	void saveParseErrMsg(@Param(value = "remark")String remark, @Param(value = "status")String status, @Param(value = "id")Long id);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 根据账单日期、渠道编码查询异常数据
	 * @param tradeTime 账单日期
	 * @param channelCode 渠道编码
	 * @param channelMchId 渠道商户号 可为空
	 * @param parseStage 解析阶段 可为空
	 * @return
	 */
	List<ParseBillProc> findExcpByBillDateAndChannelCode(
			@Param(value = "tradeTime")String tradeTime, 
			@Param(value = "channelCode")String channelCode, 
			@Param(value = "channelMchId")String channelMchId, 
			@Param(value = "parseStage")String parseStage);
	
	/**
	 * 
	 * 方法说明：<br>
	 * 查询不在指定账单日期里的异常数据
	 * @param tradeTime 需要排除的账单日期
	 * @param channelCode 渠道编码
	 * @param channelMchId 渠道商户号 可为空
	 * @param parseStage 解析阶段可为空
	 * @return
	 */
	List<ParseBillProc> findNotInDateExcpByDateAndCode(
			@Param(value = "tradeTime")String tradeTime, 
			@Param(value = "channelCode")String channelCode, 
			@Param(value = "channelMchId")String channelMchId, 
			@Param(value = "parseStage")String parseStage);

	
	/**
	 * 查询处理时间超过defaultDelayTime时间的记录
	 * @param status
	 * @param defaultDelayTime 小时
	 * @return
	 */
	List<ParseBillProc> findParseProblemItem(@Param("status")String status,
			@Param("defaultDelayTime")int defaultDelayTime);
	
}
