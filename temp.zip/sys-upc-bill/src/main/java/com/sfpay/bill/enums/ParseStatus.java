package com.sfpay.bill.enums;

public enum ParseStatus {
	SUCCESS("成功"), FAIL("失败"), UNPROCESS_FAIL("不用处理的失败情况"), PROCESSING("处理中");

	String text;

	private ParseStatus(String text) {
		this.text = text;
	}

	public String getText() {
		return text;
	}
}
