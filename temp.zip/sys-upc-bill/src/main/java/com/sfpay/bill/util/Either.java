/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.bill.util;

/**
 * 类说明：<br>
 * 用于在一个方法中可能有两种返回结果
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * 
 * CreateDate: 2014-12-29
 */
public class Either<L,R> {

	public L left;
	
	public R right;
	
	public Either(L left, R right){
		this.left = left;
		this.right = right;
	}
	
	public static <L, R> Either<L, R> Left(L left){
		return new Either<L, R>(left, null);
	}
	
	public static <L, R> Either<L, R> Right(R right){
		return new Either<L, R>(null, right);
	}

	public boolean isLeftDefined(){
		if(this.left == null){
			return false;
		}
		return true;
	}
	
	public boolean isRightDefined(){
		if(this.right == null){
			return false;
		}
		return true;
	}
}