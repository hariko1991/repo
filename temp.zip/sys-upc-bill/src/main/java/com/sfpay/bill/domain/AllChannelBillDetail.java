package com.sfpay.bill.domain;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**   
 *
 * @Description: 渠道账单汇总明细
 * @date 2016-12-24 15:23:46
 * @version V1.0   
 * @author 896728
 */

public class AllChannelBillDetail implements Serializable  {
	private static final long serialVersionUID = 6701726005905919789L;
	/** 主键*/
	private Long id;
	/** 交易时间*/
	private String tradeTime;
	/** 渠道编码 WX:微信 ALIPAY:支付宝 SFPAY:顺手付*/
	private String channelCode;
	/** 顺手付商户号*/
	private String sfpayMchId;
	/** 渠道商户号*/
	private String channelMchId;
	/** 渠道订单号*/
	private String channelOrderNo;
	/** 商户订单号*/
	private String mchOrderNo;
	/** 交易类型*/
	private String tradeType;
	/** 交易状态*/
	private String tradeState;
	/** 交易总金额*/
	private BigDecimal tradeAmount;
	/** 渠道退款单号*/
	private String channelRefundNo;
	/** 商户退款单号*/
	private String mchRefundNo;
	/** 退款金额*/
	private BigDecimal refundAmount;
	/** 退款状态*/
	private String refundStatus;
	/** 商品名称*/
	private String goodsName;
	/** 服务费*/
	private BigDecimal serviceFee;
	/** 创建时间*/
	private Date createDate;
	/** 更新时间*/
	private Date updateDate;
	

	public String getTradeTime(){
		return tradeTime;
	}

	public void setTradeTime(String tradeTime){
		this.tradeTime = tradeTime;
	}

	public String getChannelCode(){
		return channelCode;
	}

	public void setChannelCode(String channelCode){
		this.channelCode = channelCode;
	}

	public String getSfpayMchId(){
		return sfpayMchId;
	}

	public void setSfpayMchId(String sfpayMchId){
		this.sfpayMchId = sfpayMchId;
	}

	public String getChannelMchId(){
		return channelMchId;
	}

	public void setChannelMchId(String channelMchId){
		this.channelMchId = channelMchId;
	}

	public String getChannelOrderNo(){
		return channelOrderNo;
	}

	public void setChannelOrderNo(String channelOrderNo){
		this.channelOrderNo = channelOrderNo;
	}

	public String getMchOrderNo(){
		return mchOrderNo;
	}

	public void setMchOrderNo(String mchOrderNo){
		this.mchOrderNo = mchOrderNo;
	}

	public String getTradeType(){
		return tradeType;
	}

	public void setTradeType(String tradeType){
		this.tradeType = tradeType;
	}

	public String getTradeState(){
		return tradeState;
	}

	public void setTradeState(String tradeState){
		this.tradeState = tradeState;
	}

	public BigDecimal getTradeAmount(){
		return tradeAmount;
	}

	public void setTradeAmount(BigDecimal tradeAmount){
		this.tradeAmount = tradeAmount;
	}

	public String getChannelRefundNo(){
		return channelRefundNo;
	}

	public void setChannelRefundNo(String channelRefundNo){
		this.channelRefundNo = channelRefundNo;
	}

	public String getMchRefundNo(){
		return mchRefundNo;
	}

	public void setMchRefundNo(String mchRefundNo){
		this.mchRefundNo = mchRefundNo;
	}

	public BigDecimal getRefundAmount(){
		return refundAmount;
	}

	public void setRefundAmount(BigDecimal refundAmount){
		this.refundAmount = refundAmount;
	}

	public String getRefundStatus(){
		return refundStatus;
	}

	public void setRefundStatus(String refundStatus){
		this.refundStatus = refundStatus;
	}

	public String getGoodsName(){
		return goodsName;
	}

	public void setGoodsName(String goodsName){
		this.goodsName = goodsName;
	}

	public BigDecimal getServiceFee(){
		return serviceFee;
	}

	public void setServiceFee(BigDecimal serviceFee){
		this.serviceFee = serviceFee;
	}

	public Date getCreateDate(){
		return createDate;
	}

	public void setCreateDate(Date createDate){
		this.createDate = createDate;
	}

	public Date getUpdateDate(){
		return updateDate;
	}

	public void setUpdateDate(Date updateDate){
		this.updateDate = updateDate;
	}

	public Long getId(){
		return id;
	}

	public void setId(Long id){
		this.id = id;
	}
}
