/**
 * =================================================================
 * 版权所有 2011-2020 顺丰恒通支付有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.bill.service.impl;

import java.util.Calendar;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.bill.constants.ChannelCodeConstants;
import com.sfpay.bill.dao.ParseBillProcDao;
import com.sfpay.bill.domain.ParseBillProc;
import com.sfpay.bill.domain.UpcMerchantMap;
import com.sfpay.bill.dto.ChannelArgs;
import com.sfpay.bill.enums.ParseStage;
import com.sfpay.bill.enums.ParseStatus;
import com.sfpay.bill.service.AlipayBillParseService;
import com.sfpay.framework2.core.util.DateUtil;

/**
 * 类说明：<br>
 * 支付宝账单解析服务
 * 
 * <p>
 * 详细描述：<br>
 * 
 * 
 * </p>
 * 
 * 
 * CreateDate: 2016-12-26
 */
@Service("alipayBillParseService")
public class AlipayBillParseServiceImpl implements AlipayBillParseService {

	private final Logger logger = LoggerFactory.getLogger(getClass());
	@Resource
	private UpcMerchantMapService upcMerchantMapService;
	@Resource
	private ChannelArgService channelArgService;
	@Resource
	private UpcBillCommonService upcBillCommonService;
	@Resource
	private AsyncProcessAlipayBillData asyncProcessAlipayBillData;
	@Resource
	private ParseBillProcDao parseBillProcDao;

	
	
	@Override
	public void execAlipayYestodayBillParse() {
		logger.info("开始执行支付宝昨日账单的解析调度。。。。");
		//查询商户信息
		List<UpcMerchantMap> list = null;
		
		try {
			list = upcMerchantMapService.queryDistinctMerchantMap(ChannelCodeConstants.ALIPAY_CHANNEL);
		} catch (Exception e) {
			logger.error("查询支付宝渠道商户信息失败，原因：", e);
			return;
		}
		
		if(list == null || list.size() == 0) {
			logger.info("支付宝渠道商户信息为空");
			return;
		}
		
		String billDate = getBillDate();
		for(UpcMerchantMap map : list) {
			//处理每个商户的对账下载
			execMerchantBillParse(map, billDate);
		}
		
		logger.info("完成执行支付宝昨日账单的解析调度。。。。");
	}
	
	@Override
	public void handleYestodayExcpParseBillData() {
		logger.info("开始执行处理支付宝昨日异常账单的解析调度。。。。");
		handleAlipayExcpData(true);
	}

	@Override
	public void handleHistoryExcpParseBillData() {
		logger.info("开始执行处理支付宝非昨日异常账单的解析调度。。。。");
		handleAlipayExcpData(false);
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 商户账单解析
	 * @param map 映射配置
	 * @param billDate 账单日期
	 */
	public void execMerchantBillParse(UpcMerchantMap map, String billDate) {
		if(map == null){
			return;
		}
		
		if(StringUtils.isBlank(billDate)) {
			billDate = getBillDate();
		}
		
		//下载对账文件
		ChannelArgs args = null;
		try {
			args = channelArgService.getChannelArgs(map.getChannelMchParamKey());
		} catch (Exception e) {
			logger.error(String.format("(method:execMerchantBill)根据商户paramKey查询配置参数出现异常，参数key：%s", map.getChannelMchParamKey()), e);
			return;
		}
		if(args == null){
			logger.info(String.format("(method:execMerchantBill)根据商户paramKey查询配置参数结果为空，参数key：%s", map.getChannelMchParamKey()));
			return;
		}
		
		String appId = args.getValueByKey("app_id");
		String channelMerchantId = args.getValueByKey("mch_id");
		String merchantPrvK = args.getValueByKey("mch_private_key_new");
		String alipayPubKey = args.getValueByKey("alipay_unify_key");
		if(StringUtils.isBlank(appId) || StringUtils.isBlank(channelMerchantId) || StringUtils.isBlank(merchantPrvK) || 
				StringUtils.isBlank(alipayPubKey)) {
			logger.error(String.format("渠道参数为空，账单日期：%s，渠道编码：%s", billDate, ChannelCodeConstants.ALIPAY_CHANNEL));
			return;
		}
		
		//查询对应的解析阶段信息
		boolean downloadSuc = false;//下载阶段是否成功
		
		//判断文件下载阶段是否处理成功
		ParseBillProc downloadProc = upcBillCommonService.findProcByMchIdAndBillDate(ChannelCodeConstants.ALIPAY_CHANNEL, channelMerchantId, billDate, 
				ParseStage.DOWNLOAD_PARSE.name());
		if(downloadProc != null){
			//下载成功
			if(StringUtils.equals(downloadProc.getStatus(), ParseStatus.SUCCESS.name())){
				downloadSuc = true;
			}
			
			//下载处理中或者是不用处理的状态(例如：账单不存在)，则不用处理
			if(StringUtils.equals(downloadProc.getStatus(), ParseStatus.PROCESSING.name()) || StringUtils.equals(downloadProc.getStatus(), ParseStatus.UNPROCESS_FAIL.name())){
				return;
			}
		}
		
		//判断文件解析阶段是否处理成功
		ParseBillProc parseProc = upcBillCommonService.findProcByMchIdAndBillDate(ChannelCodeConstants.ALIPAY_CHANNEL, channelMerchantId, billDate, 
				ParseStage.NORMAL_PARSE.name());
		if(parseProc != null){
			//如果是解析成功，或者解析进行中，都不用处理
			if(StringUtils.equals(parseProc.getStatus(), ParseStatus.SUCCESS.name()) || 
					StringUtils.equals(parseProc.getStatus(), ParseStatus.PROCESSING.name()) || 
					StringUtils.equals(downloadProc.getStatus(), ParseStatus.UNPROCESS_FAIL.name())){
				return;
			}
		}
		
		boolean onlyParseFile = false;//是否只进行文件解析，不下载
		
		//下载成功，只进行文件内容解析
		if(downloadSuc){
			onlyParseFile = true;
		}
		
		String filePath = downloadProc != null ? downloadProc.getBillFilePath() : (parseProc != null ? parseProc.getBillFilePath() : null);
		
		try {
			asyncProcessAlipayBillData.processBillParse(appId, channelMerchantId, merchantPrvK, alipayPubKey, billDate, onlyParseFile, filePath);
		} catch (Exception e) {
			logger.error(String.format("调用前置账单处理服务失败，渠道商户号：%s，账单日期：%s", channelMerchantId, billDate), e);
		}
	}
	
	
	
	/**
	 * 
	 * 方法说明：<br>
	 * 获取当前账单日期，昨天的时间
	 * @return
	 */
	private String getBillDate(){
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, -1);
		return DateUtil.format(calendar.getTime(), DateUtil.YYYY_MM_DD);
	}
	
	/**
	 * 
	 * 方法说明：<br>
	 * 处理支付宝账单异常数据
	 * @param isYestoday 是否是昨天的账单 true：昨天账单，false : 非昨天账单(除了昨天之外的所有异常账单)
	 */
	private void handleAlipayExcpData(boolean isYestoday) {
		logger.info("开始处理支付宝账单异常数据。。。");
		//获取昨天的账单日期
		String yestodayBillDate = getBillDate();
		
		List<ParseBillProc> list = null;
		try {
			if(isYestoday){
				list = parseBillProcDao.findExcpByBillDateAndChannelCode(yestodayBillDate, ChannelCodeConstants.ALIPAY_CHANNEL, null, null);
			}else{
				list = parseBillProcDao.findNotInDateExcpByDateAndCode(yestodayBillDate, ChannelCodeConstants.ALIPAY_CHANNEL, null, null);
			}
		} catch (Exception e) {
			logger.error(String.format("查询账单异常数据出现异常，账单日期：%s，渠道编码：%s", yestodayBillDate, ChannelCodeConstants.ALIPAY_CHANNEL), e);
			return;
		}
		
		if(list == null || list.size() == 0){
			return;
		}
		
		for(ParseBillProc proc : list){
			//查询渠道商户映射配置
			UpcMerchantMap map = null;
			try {
				map = upcMerchantMapService.queryDistinctMerMapByChannelMchId(ChannelCodeConstants.ALIPAY_CHANNEL, proc.getChannelMchId());
			} catch (Exception e) {
				logger.error(String.format("查询商户配置失败，渠道商户号：%s", proc.getChannelMchId()));
			}
			
			if(map != null){
				//商户账单解析
				execMerchantBillParse(map, proc.getTradeTime());
			}
		}
	}

}
