package com.sfpay.bill.task;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.math.BigDecimal;
import java.util.Calendar;
import java.util.List;

import javax.annotation.Resource;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.bill.constants.ChannelCodeConstants;
import com.sfpay.bill.constants.ChannelTradeTypeConstants;
import com.sfpay.bill.dao.AllChannelBillDetailDao;
import com.sfpay.bill.dao.AllChannelBillSummaryDao;
import com.sfpay.bill.dao.ParseBillProcDao;
import com.sfpay.bill.dao.WxBillDetailDao;
import com.sfpay.bill.domain.AllChannelBillDetail;
import com.sfpay.bill.domain.AllChannelBillSummary;
import com.sfpay.bill.domain.ParseBillProc;
import com.sfpay.bill.domain.UpcMerchantMap;
import com.sfpay.bill.domain.UpcWXBillDetail;
import com.sfpay.bill.enums.ParseStage;
import com.sfpay.bill.enums.ParseStatus;
import com.sfpay.bill.ftp.SFTPUtils;
import com.sfpay.bill.service.impl.UpcBillCommonService;
import com.sfpay.bill.service.impl.UpcBillDataParseBaseService;
import com.sfpay.bill.service.impl.UpcMerchantMapService;
import com.sfpay.bill.util.AntZipUtils;
import com.sfpay.framework2.config.properties.Property;
import com.sfpay.framework2.core.util.DateUtil;
import com.sfpay.framework2.exception.ServiceException;

/**
 * 解析对账单任务
 * 
 * @author 896728
 * 
 */
@Service("ParseWeChatBillTask")
public class ParseWeChatBillTask extends UpcBillDataParseBaseService {

	private final Logger logger = LoggerFactory.getLogger(getClass());
	@Resource
	private UpcMerchantMapService upcMerchantMapService;
	@Resource
	private WxBillDetailDao wxBillDao;
	@Resource
	private AllChannelBillSummaryDao channelBillSummaryDao;
	@Resource
	private UpcBillCommonService upcBillCommonService;
	@Resource
	private ParseBillProcDao parseBillProcDao;
	@Resource
	private AllChannelBillDetailDao allChannelBillDetailDao;

	/**
	 * 解析微信对账单
	 */
	public void parseWXBill() {
		try {
			List<UpcMerchantMap> channelMchNoList = upcMerchantMapService
					.queryDistinctMerchantMap(ChannelCodeConstants.WX_CHANNEL);

			if (channelMchNoList == null || channelMchNoList.isEmpty()) {
				logger.info("没有渠道商户号, 请配置Upc_Merchant_Map表");
				return;
			}
			for (UpcMerchantMap map : channelMchNoList) {
				long startTime = System.currentTimeMillis();
				logger.info("********************处理微信对账单[开始]**************************");
				String channelMchNo = map.getChannelMchNo();
				logger.info("渠道商户号:[{}]", channelMchNo);
				doParse(channelMchNo, null);
				logger.info("处理微信对账渠道商户号:{}, 共用时:{} ms", channelMchNo, System.currentTimeMillis() - startTime);
				logger.info("********************处理微信对账单[结束]**************************");
			}
		} catch (Exception e) {
			logger.error("解析微信异常", e);
		}

	}

	/**
	 * 解析微信异常处理
	 */
	public void parseWXExcepBill() {
		try {
			// 获取昨天的账单日期
			String handleDate = getPreDay();

			List<ParseBillProc> list = null;
			try {
				list = parseBillProcDao.findNotInDateExcpByDateAndCode(handleDate, ChannelCodeConstants.WX_CHANNEL,
						null, null);
			} catch (Exception e) {
				logger.error(
						String.format("查询账单异常数据出现异常，账单日期：%s，渠道编码：%s", handleDate, ChannelCodeConstants.WX_CHANNEL), e);
				return;
			}

			if (list == null || list.isEmpty()) {
				return;
			}

			for (ParseBillProc proc : list) {
				// 查询渠道商户映射配置
				UpcMerchantMap map = null;
				try {
					map = upcMerchantMapService.queryDistinctMerMapByChannelMchId(ChannelCodeConstants.WX_CHANNEL,
							proc.getChannelMchId());
				} catch (Exception e) {
				}
				if (map == null) {
					return;
				}

				// 商户账单解析
				doParse(map.getChannelMchNo(), proc.getTradeTime());
			}

		} catch (Exception e) {
			logger.error("解析微信异常", e);
		}

	}

	private void doParse(String channelMchNo, String tradeTime) {

		String handleTime = getPreDay();
		if (StringUtils.isNotBlank(tradeTime)) {
			handleTime = tradeTime;
		}
		String ftpFileName = channelMchNo + "-All-" + handleTime + ".zip";
		String decompressPath = Property.getProperty("SAVE_WX_FILE_PATH");
		String saveFile = decompressPath + ftpFileName;

		String decompressBillCsv = decompressPath + channelMchNo + "All" + handleTime + ".csv";
		try {

			// 查询对应的解析阶段信息
			boolean downloadSuc = false;// 下载阶段是否成功
			boolean parseSuc = false;// 解析阶段是否成功

			// 判断文件下载阶段是否处理成功
			ParseBillProc downloadProc = upcBillCommonService.findProcByMchIdAndBillDate(
					ChannelCodeConstants.WX_CHANNEL, channelMchNo, handleTime, ParseStage.DOWNLOAD_PARSE.name());
			if (downloadProc != null && StringUtils.equals(downloadProc.getStatus(), ParseStatus.SUCCESS.name())) {
				downloadSuc = true;
			}

			// 判断文件解析阶段是否处理成功
			ParseBillProc parseProc = upcBillCommonService.findProcByMchIdAndBillDate(ChannelCodeConstants.WX_CHANNEL,
					channelMchNo, handleTime, ParseStage.NORMAL_PARSE.name());
			if (parseProc != null && StringUtils.equals(parseProc.getStatus(), ParseStatus.SUCCESS.name())) {
				parseSuc = true;
			}
			// 解析文件已经成功，不用重复解析
			if (parseSuc) {
				return;
			}

			// 下载不成功，则进行文件下载和文件内容解析
			if (!downloadSuc) {
				// 处理下载解压
				boolean isDownloadSucc = handleDownloadOrDecompressWxBill(channelMchNo, handleTime, ftpFileName,
						saveFile, decompressPath);

				if (!isDownloadSucc) {
					return;
				}

				// 处理解析
				handleParseWXBill(channelMchNo, handleTime, saveFile, decompressBillCsv);
				return;
			}

			// 文件解析不成功，说明下载成功，只进行文件内容解析
			if (!parseSuc) {

				// 处理解析
				handleParseWXBill(channelMchNo, handleTime, saveFile, decompressBillCsv);
			}

		} catch (Exception e) {
			logger.error("Exception解析对账单异常:商户号：[{}]" + channelMchNo, e);
		}

	}

	private void handleParseWXBill(String channelMchNo, String handleDate, String saveFile, String decompressBillCsv)
			throws Exception {

		// 开始账单解析
		boolean parseSuccess = startBillStage(ChannelCodeConstants.WX_CHANNEL, handleDate, channelMchNo,
				ParseStage.NORMAL_PARSE.name(), null);
		if (!parseSuccess) {
			return;
		}

		// 解析内容
		parseSuccess = doParseWxContent(channelMchNo, handleDate, saveFile, decompressBillCsv);

		// 解析阶段完成
		endBillStage(ChannelCodeConstants.WX_CHANNEL, handleDate, channelMchNo, parseSuccess,
				ParseStage.NORMAL_PARSE.name(), null);
	}

	private boolean doParseWxContent(String channelMchNo, String handleDate, String saveFile, String decompressBillCsv) {
		
		long startTime = System.currentTimeMillis();
		
		boolean isIgnoreFirstDetailRow = false;
		boolean isIgnoreFirstSummaryRow = false;
		boolean parseSuccess = true;

		String wxTradeTime = null;
		File billFile = null;
		BufferedReader buf = null;
		try {
			// 解析
			billFile = new File(decompressBillCsv);
			buf = new BufferedReader(new InputStreamReader(new FileInputStream(billFile)));

			UpcWXBillDetail billDetail = null;
			AllChannelBillDetail allBillDetail = null;
			String line_record = null;
			while ((line_record = buf.readLine()) != null) {
				String[] fields = line_record.split(",", -1);
				logger.info("解析字段 fields长度:[{}]", fields.length);
				// bill detail
				if (fields.length == 24) {
					if (isIgnoreFirstDetailRow) {
						try {
							billDetail = buildUpcWxBillDetail(fields);
							wxTradeTime = billDetail.getTradeTime();
							
							//0409需求，默认将processing状态的，也是结算成功的。
//							if (!"PROCESSING".equals(billDetail.getRefundStatus())) {
							if("PROCESSING".equals(billDetail.getRefundStatus()))
							{
								//0409需求，将微信退款是进行中的状态，更新为成功。
								billDetail.setRefundStatus("SUCCESS");
							}
								wxBillDao.insertWXBillDetail(billDetail);

								// 保存到公共表里
								allBillDetail = buildAllDetail(billDetail, channelMchNo, handleDate);
								parseSuccess = saveAllChannelDetail(allBillDetail);
//							}
						} catch (Exception e) {
							parseSuccess = false;
							logger.error("插入微信明细异常", e);
						}
					} else {
						isIgnoreFirstDetailRow = true;
					}
				}
				// bill summary
				else if (fields.length == 5) {
					logger.info("微信[明细]数据解析完成....渠道商户号:{}", channelMchNo);
					if (isIgnoreFirstSummaryRow) {
						try {
							AllChannelBillSummary summary = buildWXBillSummary(channelMchNo, wxTradeTime, fields);
							channelBillSummaryDao.saveAllChannelBillSummary(summary);
							logger.info("微信[汇总]数据解析完成....渠道商户号:{}", channelMchNo);
						} catch (Exception e) {
							parseSuccess = false;
							logger.error("插入微信汇总异常", e);
						}
					} else {
						isIgnoreFirstSummaryRow = true;
					}
				}
			}
			
			logger.info("微信对账单数据解析完成....渠道商户号:{} 共用时:{} 秒", channelMchNo, (System.currentTimeMillis() - startTime)/1000);
			return parseSuccess;
		} catch (Exception e) {
			logger.error("解析微信内容异常", e);
		} finally {
			// 解析成功
			if (parseSuccess) {
				try {
					buf.close();

					File file = new File(saveFile);
					if (file.exists()) {
						file.delete();
					}

					file = new File(decompressBillCsv);
					if (file.exists()) {
						file.delete();
					}
				} catch (Exception e) {
					logger.error("连接关闭异常 ", e);
				}
			}
		}
		return false;

	}

	/**
	 * 
	 * 方法说明：<br>
	 * 构造所有的明细
	 * 
	 * @param billDetail
	 * @param channelMchId
	 * @param billDate
	 * @return
	 */
	private AllChannelBillDetail buildAllDetail(UpcWXBillDetail billDetail, String channelMchId, String billDate) {
		AllChannelBillDetail ad = new AllChannelBillDetail();

		ad.setChannelCode(ChannelCodeConstants.WX_CHANNEL);
		ad.setChannelMchId(channelMchId);
		ad.setChannelOrderNo(billDetail.getWxOrderNo());
		ad.setChannelRefundNo(null);
		ad.setGoodsName(billDetail.getGoodsName());
		ad.setMchOrderNo(billDetail.getMchOrderNo());
		ad.setMchRefundNo(billDetail.getMchRefundNo());
		ad.setChannelRefundNo(billDetail.getWxRefundNo());
		ad.setRefundAmount(billDetail.getRefundAmount());
		ad.setRefundStatus(billDetail.getRefundStatus());
		ad.setServiceFee(billDetail.getServiceFee());
		ad.setTradeAmount(billDetail.getTradeAmount());
		ad.setTradeState(billDetail.getTradeState());
		ad.setTradeTime(billDate);

		if ("SUCCESS".equals(billDetail.getTradeState())) {
			ad.setTradeType(ChannelTradeTypeConstants.PAY);
		} else {
			ad.setTradeType(ChannelTradeTypeConstants.REFUND);
		}

		return ad;
	}

	/**
	 * 
	 * 方法说明：<br>
	 * 保存公共渠道明细数据
	 * 
	 * @param ad
	 */
	private boolean saveAllChannelDetail(AllChannelBillDetail ad) {
		try {
			// 查询对应的记录是否已经存在
			AllChannelBillDetail old = allChannelBillDetailDao.findAllChannelBillDetailByMchOrderNo(ad.getMchOrderNo(),
					ad.getChannelCode(), ad.getChannelMchId(), ad.getTradeTime(), ad.getTradeType());
			if (old != null && ad.getTradeState().equals(ad.getTradeState())) {
				logger.info(String.format("对应的记录已经存在，商户订单号：%s", ad.getMchOrderNo()));
				return true;
			}

			allChannelBillDetailDao.saveAllChannelBillDetail(ad);
			return true;
		} catch (Exception e) {
			logger.error(String.format("保存支付宝公共明细数据出现异常，商户订单号：%s", ad.getMchOrderNo()), e);
			return false;
		}
	}

	/**
	 * 处理微信下载解压异常
	 * 
	 * @param ftpFileName
	 * @param saveFile
	 * @param decompressPath
	 * @throws Exception
	 */
	private boolean handleDownloadOrDecompressWxBill(String channelMchNo, String preDay, String ftpFileName,
			String saveFile, String decompressPath) throws Exception {

		// 下载阶段开始
		boolean downloadSuccess = startBillStage(ChannelCodeConstants.WX_CHANNEL, preDay, channelMchNo,
				ParseStage.DOWNLOAD_PARSE.name(), null);
		logger.info(String.format("开始下载返回结果：%s，账单日期：%s，渠道商户号：%s", downloadSuccess, preDay, channelMchNo));
		if (!downloadSuccess) {
			return false;
		}

		String wxZipPath = Property.getProperty("FTP_WX_DIRECTORY");
		try {
			// 下载
			SFTPUtils.getInstance().download(wxZipPath, ftpFileName, saveFile);
			logger.info("下载微信对账单成功: ftpFileName:{}, saveFile:{}", ftpFileName, saveFile);

			File file = new File(saveFile);
			if (!file.exists()) {
				throw new ServiceException("微信对账单文件不存在");
			} else {
				// 解压
				AntZipUtils.unzipGBK(saveFile, decompressPath, false);
				logger.info("微信对账单解压成功: decompressPath:{}, saveFile:{}", decompressPath, saveFile);
			}
		} catch (Exception e) {
			logger.error("处理微信下载或解压异常", e);
			downloadSuccess = false;
			
			// 保存异常数据
			upcBillCommonService.saveParseExcpData(ChannelCodeConstants.WX_CHANNEL, preDay, channelMchNo, ParseStage.DOWNLOAD_PARSE.name(),
					e.toString());

			String decompressBillCsv = decompressPath + channelMchNo + "All" + preDay + ".csv";
			// 下载或解压异常删除本地下载包
			try {
				File file = new File(saveFile);
				if (file.exists()) {
					file.delete();
				}

				file = new File(decompressBillCsv);
				if (file.exists()) {
					file.delete();
				}
			} catch (Exception e1) {
				logger.error("删除文件 file:" + saveFile, e1);
			}
		}
		
		// 下载阶段结束
		endBillStage(ChannelCodeConstants.WX_CHANNEL, preDay, channelMchNo, downloadSuccess,
				ParseStage.DOWNLOAD_PARSE.name(), null);

		return downloadSuccess;

	}

	private String getPreDay() {
		Calendar calendar = Calendar.getInstance();
		calendar.add(Calendar.DAY_OF_MONTH, -1);
		String preDay = DateUtil.format(calendar.getTime(), DateUtil.YYYY_MM_DD);
		return preDay;
	}

	private AllChannelBillSummary buildWXBillSummary(String channelMchNo, String wxTradeTime, String[] fields) {
		AllChannelBillSummary summary = new AllChannelBillSummary();
		if (StringUtils.isNotBlank(wxTradeTime)) {
			wxTradeTime = wxTradeTime.split(" ")[0];
		}
		summary.setTradeTime(wxTradeTime);
		int totalCount = Integer.valueOf(removeSpecialCharacter(fields[0]));
		BigDecimal totalTradeAmount = new BigDecimal(removeSpecialCharacter(fields[1]));
		BigDecimal totalRefundAmount = StringUtils.isEmpty(removeSpecialCharacter(fields[2])) ? BigDecimal.ZERO
				: new BigDecimal(removeSpecialCharacter(fields[2]));
		BigDecimal totalServiceFee = StringUtils.isEmpty(removeSpecialCharacter(fields[4])) ? BigDecimal.ZERO
				: new BigDecimal(removeSpecialCharacter(fields[4]));

		summary.setChannelCode(ChannelCodeConstants.WX_CHANNEL);
		summary.setChannelMchId(channelMchNo);
		summary.setTotalCount(totalCount);
		summary.setTradeAmount(totalTradeAmount);
		summary.setRefundAmount(totalRefundAmount);
		summary.setFeeAmount(totalServiceFee);
		return summary;
	}

	private UpcWXBillDetail buildUpcWxBillDetail(String[] fields) {
		UpcWXBillDetail billDetail = new UpcWXBillDetail();
		billDetail.setTradeTime(removeSpecialCharacter(fields[0]));
		billDetail.setAppid(removeSpecialCharacter(fields[1]));
		billDetail.setMchId(removeSpecialCharacter(fields[2]));
		billDetail.setSubMchId(removeSpecialCharacter(fields[3]));
		billDetail.setDeviceCode(removeSpecialCharacter(fields[4]));
		billDetail.setWxOrderNo(removeSpecialCharacter(fields[5]));
		billDetail.setMchOrderNo(removeSpecialCharacter(fields[6]));
		billDetail.setUserInfo(removeSpecialCharacter(fields[7]));
		billDetail.setTradeType(removeSpecialCharacter(fields[8]));
		billDetail.setTradeState(removeSpecialCharacter(fields[9]));
		billDetail.setPayBankCode(removeSpecialCharacter(fields[10]));
		billDetail.setCcy(removeSpecialCharacter(fields[11]));
		billDetail.setTradeAmount(new BigDecimal(removeSpecialCharacter(fields[12])));

		String redpackAmt = removeSpecialCharacter(fields[13]);
		billDetail.setMchRedpackAmount(StringUtils.isEmpty(redpackAmt) ? BigDecimal.ZERO : new BigDecimal(redpackAmt));
		billDetail.setWxRefundNo(removeSpecialCharacter(fields[14]));
		billDetail.setMchRefundNo(removeSpecialCharacter(fields[15]));
		billDetail.setRefundAmount(new BigDecimal(removeSpecialCharacter(fields[16])));

		billDetail.setMchRefundRedpackAmount(new BigDecimal(removeSpecialCharacter(fields[17])));
		billDetail.setRefundType(removeSpecialCharacter(fields[18]));
		billDetail.setRefundStatus(removeSpecialCharacter(fields[19]));
		billDetail.setGoodsName(removeSpecialCharacter(fields[20]));
		billDetail.setRemark(removeSpecialCharacter(fields[21]));
		String serviceFee = removeSpecialCharacter(fields[22]);
		billDetail.setServiceFee(StringUtils.isEmpty(serviceFee) ? BigDecimal.ZERO : new BigDecimal(serviceFee));
		billDetail.setFeeRate(removeSpecialCharacter(fields[23]));
		return billDetail;
	}

	private String removeSpecialCharacter(String value) {
		if (StringUtils.isEmpty(value))
			return value;

		return value.substring(value.indexOf("`") + 1);
	}
}
