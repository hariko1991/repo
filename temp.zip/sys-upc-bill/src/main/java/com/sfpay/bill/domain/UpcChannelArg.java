package com.sfpay.bill.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @Description: 统一支付渠道参数
 * @date 2016-04-27 17:24:17
 * @version V1.0
 * @author 896728
 */

public class UpcChannelArg implements Serializable {
	private static final long serialVersionUID = 634485998702036994L;
	/** 主键 */
	private Long id;
	/** 渠道编码 WX:微信 ALIPAY:支付宝 */
	private String channelCode;
	/** 商户号 */
	private String mchNo;
	/** 渠道商户参数key */
	private String channelMchParamKey;
	/** 参数名 */
	private String argName;
	/** 参数key */
	private String argKey;
	/** 参数值 */
	private String argValue;
	/** 备注 */
	private String remark;
	/** 创建时间 */
	private Date createDate;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getArgName() {
		return argName;
	}

	public void setArgName(String argName) {
		this.argName = argName;
	}

	public String getArgKey() {
		return argKey;
	}

	public void setArgKey(String argKey) {
		this.argKey = argKey;
	}

	public String getArgValue() {
		return argValue;
	}

	public void setArgValue(String argValue) {
		this.argValue = argValue;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public Date getCreateDate() {
		return createDate;
	}

	public void setCreateDate(Date createDate) {
		this.createDate = createDate;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getMchNo() {
		return mchNo;
	}

	public void setMchNo(String mchNo) {
		this.mchNo = mchNo;
	}

	public String getChannelMchParamKey() {
		return channelMchParamKey;
	}

	public void setChannelMchParamKey(String channelMchParamKey) {
		this.channelMchParamKey = channelMchParamKey;
	}

}
