package com.sfpay.bill.constants;


/**
 * 
 * 类说明：<br>
 * 统一支付返回码
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-19
 */
public class UpcConstants {
	/**
	 * 成功
	 */
	public final static String SUCCESS = "SUCCESS";
	/**
	 * 参数不能为空
	 */
	public final static String PARAM_NULL = "PARAM_NULL";
	/**
	 * 系统异常
	 */
	public final static String FAILURE_SYS = "FAILURE_SYS";
	/**
	 * 数据库异常
	 */
	public final static String FAILURE_DB = "FAILURE_DB";
	/**
	 * 调用其它系统异常
	 */
	public final static String FAILURE_INVOKE = "FAILURE_INVOKE";
	/**
	 * 调用Hessian时发生异常
	 */
	public final static String FAILURE_HESSIAN = "FAILURE_HESSIAN";
	/**
	 * 签名非法
	 */
	public final static String INVALID_SIGN = "INVALID_SIGN";
	/**
	 * 无效的商户号
	 */
	public final static String INVALID_MCH_NO = "INVALID_MCH_NO";
	/**
	 * 订单已存在
	 */
	public static final String ORDER_IS_EXISTS = "ORDER_IS_EXISTS";
	/**
	 * 订单不存在
	 */
	public static final String ORDER_NOT_EXISTS = "ORDER_NOT_EXISTS";
	/**
	 * 订单已过期
	 */
	public static final String ORDER_IS_EXPIRE = "ORDER_IS_EXPIRE";
	/**
	 * 订单已支付成功
	 */
	public static final String ORDER_IS_SUCCESS = "ORDER_IS_SUCCESS";
	/**
	 * 订单正在支付
	 */
	public static final String ORDER_IS_PAYING = "ORDER_IS_PAYING";
	/**
	 * 订单已关闭
	 */
	public static final String ORDER_IS_CLOSED = "ORDER_IS_CLOSED";
	/**
	 * 交易失败
	 */
	public static final String ORDER_IS_FAIL = "ORDER_IS_FAIL";
	/**
	 * 订单状态不合法
	 */
	public static final String ORDER_STATUS_ILLEGAL = "ORDER_STATUS_ILLEGAL";
	/**
	 * 订单正在退款
	 */
	public static final String ORDER_IS_REFUND_PROC = "ORDER_IS_REFUND_PROC";
	/**
	 * 订单已退款
	 */
	public static final String ORDER_IS_REFUND_SUCC = "ORDER_IS_REFUND_SUCC";
	/**
	 * 订单已冻结
	 */
	public static final String ORDER_IS_FREEZE = "ORDER_IS_FREEZE";
	/**
	 * 订单冻结失败
	 */
	public static final String ORDER_FREEZE_FAIL = "ORDER_FREEZE_FAIL";
	/**
	 * 解冻失败
	 */
	public static final String ORDER_UNFREEZE_FAIL = "ORDER_UNFREEZE_FAIL";
	/**
	 * 解冻支付失败
	 */
	public static final String ORDER_UNFREEZE_AND_PAY_FAIL = "ORDER_UNFREEZE_AND_PAY_FAIL";
	/**
	 * 订单已退款
	 */
	public static final String ORDER_IS_REFUND_FAIL = "ORDER_IS_REFUND_FAIL";
	/**
	 * 支付成功的单才支持退款
	 */
	public static final String ONLY_SUCC_ORDER_CAN_REFUND = "ONLY_SUCC_ORDER_CAN_REFUND";
	/**
	 * 无效的渠道编码
	 */
	public static final String INVALID_CHANNEL_CODE = "INVALID_CHANNEL_CODE";
	/**
	 * 非法请求
	 */
	public static final String ILLEGAL_REQ = "ILLEGAL_REQ";

	/**
	 * 商户号为空
	 */
	public static final String MCH_NO_IS_NULL = "MCH_NO_IS_NULL";
	/**
	 * 渠道编码为空
	 */
	public static final String CHANNEL_CODE_IS_NULL = "CHANNEL_CODE_IS_NULL";
	/**
	 * 商户订单号为空
	 */
	public static final String MCH_ORDER_NO_IS_NULL = "MCH_ORDER_NO_IS_NULL";
	/**
	 * 商户退款订单号为空
	 */
	public static final String MCH_REFUND_ORDER_NO_IS_NULL = "MCH_REFUND_ORDER_NO_IS_NULL";
	/**
	 * 商品名为空
	 */
	public static final String MCH_PRODUCT_NAME_IS_NULL = "MCH_PRODUCT_NAME_IS_NULL";
	
	/**
	 * 商品详情为空
	 */
	public static final String MCH_PRODUCT_DESC_IS_NULL = "MCH_PRODUCT_DESC_IS_NULL";
	/**
	 * 交易金额为空
	 */
	public static final String TRADE_AMOUNT_IS_NULL = "TRADE_AMOUNT_IS_NULL";
	
	/**
	 * 商品展示地址
	 */
	public static final String MCH_PRODUCT_URL_IS_NULL = "MCH_PRODUCT_URL_IS_NULL";
	/**
	 * 退款金额无效
	 */
	public static final String INVALID_REFUND_AMOUNT = "INVALID_REFUND_AMOUNT";
	/**
	 * 退款金额大于交易金额
	 */
	public static final String REFUND_AMOUNT_GT_TRADE_AMOUNT = "REFUND_AMOUNT_GT_TRADE_AMOUNT";
	/**
	 * 退款失败
	 */
	public static final String REFUND_FAIL = "REFUND_FAIL";
	/**
	 * 请求ip为空
	 */
	public static final String REQUEST_IP_IS_NULL = "REQUEST_IP_IS_NULL";
	/**
	 * 系统来源为空
	 */
	public static final String SYSTEM_SOURCE_IS_NULL = "SYSTEM_SOURCE_IS_NULL";
	/**
	 * 微信openid为空
	 */
	public static final String WX_OPEN_ID_IS_NULL = "WX_OPEN_ID_IS_NULL";
	/**
	 * 用户帐号异常或注销
	 */
	public static final String USER_ACCOUNT_EXCEPTION_OR_LOGOUT = "USER_ACCOUNT_EXCEPTION_OR_LOGOUT";
	/**
	 * 商户没有此接口权限
	 */
	public static final String NO_AUTH_FOR_THE_INTERFACE = "NO_AUTH_FOR_THE_INTERFACE";
	/**
	 * 支付宝单笔总额超限
	 */
	public static final String ALIPAY_TOTAL_FEE_EXCEED = "ALIPAY_TOTAL_FEE_EXCEED";
	/**
	 * 券类型不正确
	 */
	public static final String VOUCHER_IS_NOT_RIGHT = "VOUCHER_IS_NOT_RIGHT";
	/**
	 * 超时
	 */
	public static final String SOCKET_TIMEOUT = "SOCKET_TIMEOUT";
	/**
	 * 查询签约号失败
	 */
	public static final String QUERY_SIGNNO_FAIL = "QUERY_SIGNNO_FAIL";
	/**
	 * 订单支付失败
	 */
	public static final String ORDER_PAY_FAIL = "ORDER_PAY_FAIL";
	/**
	 * 订单关单失败
	 */
	public static final String ORDER_CLOSE_FAIL = "ORDER_CLOSE_FAIL";
	/**
	 * 订单已解冻
	 */
	public static final String ORDER_IS_UNFREEZE = "ORDER_IS_UNFREEZE";
	/**
	 * 重复提交
	 */
	public static final String REPEAT_SUBMIT = "REPEAT_SUBMIT";
	/**
	 * 风控异常
	 */
	public static final String RISK_EXCEPTION = "RISK_EXCEPTION";
	/**
	 * 下载或解压异常
	 */
	public static final String DOWNLOAD_OR_DEC_EXCEPTION = "DOWNLOAD_OR_DEC_EXCEPTION";
	/**
	 * 账单文件不存在
	 */
	public static final String BILL__NOT_EXIST = "BILL__NOT_EXIST";
}
