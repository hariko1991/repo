package com.sfpay.bill.domain;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**   
 *
 * @Description: 渠道账单汇总
 * @date 2016-12-24 15:24:09
 * @version V1.0   
 * @author 896728
 */

public class AllChannelBillSummary implements Serializable  {
	private static final long serialVersionUID = 3456164218486427392L;
	
	/** 主键*/
	private Long id;
	/** 交易时间*/
	private String tradeTime;
	/** 渠道编码 WX:微信 ALIPAY:支付宝 SFPAY:顺手付*/
	private String channelCode;
	/** 顺手付商户号*/
	private String sfpayMchId;
	/** 渠道商户号*/
	private String channelMchId;
	/**交易总笔数*/
	private Integer totalCount;
	/** 交易总金额*/
	private BigDecimal tradeAmount;
	/** 退款总金额*/
	private BigDecimal refundAmount;
	/** 手续费总金额*/
	private BigDecimal feeAmount;
	/** 优惠退款总金额*/
	private BigDecimal discountAmount;
	/** 创建时间*/
	private Date createDate;
	/** 更新时间*/
	private Date updateDate;
	

	public Long getId(){
		return id;
	}

	public void setId(Long id){
		this.id = id;
	}

	public String getTradeTime(){
		return tradeTime;
	}

	public void setTradeTime(String tradeTime){
		this.tradeTime = tradeTime;
	}

	public String getChannelCode(){
		return channelCode;
	}

	public void setChannelCode(String channelCode){
		this.channelCode = channelCode;
	}

	public String getSfpayMchId(){
		return sfpayMchId;
	}

	public void setSfpayMchId(String sfpayMchId){
		this.sfpayMchId = sfpayMchId;
	}

	public String getChannelMchId(){
		return channelMchId;
	}

	public void setChannelMchId(String channelMchId){
		this.channelMchId = channelMchId;
	}

	public Integer getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(Integer totalCount) {
		this.totalCount = totalCount;
	}

	public BigDecimal getTradeAmount(){
		return tradeAmount;
	}

	public void setTradeAmount(BigDecimal tradeAmount){
		this.tradeAmount = tradeAmount;
	}

	public BigDecimal getRefundAmount(){
		return refundAmount;
	}

	public void setRefundAmount(BigDecimal refundAmount){
		this.refundAmount = refundAmount;
	}

	public BigDecimal getFeeAmount(){
		return feeAmount;
	}

	public void setFeeAmount(BigDecimal feeAmount){
		this.feeAmount = feeAmount;
	}

	public BigDecimal getDiscountAmount(){
		return discountAmount;
	}

	public void setDiscountAmount(BigDecimal discountAmount){
		this.discountAmount = discountAmount;
	}

	public Date getCreateDate(){
		return createDate;
	}

	public void setCreateDate(Date createDate){
		this.createDate = createDate;
	}

	public Date getUpdateDate(){
		return updateDate;
	}

	public void setUpdateDate(Date updateDate){
		this.updateDate = updateDate;
	}
}
