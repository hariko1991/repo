package com.sfpay.bill.domain;

import java.io.Serializable;
import java.util.Date;

/**
 * 
 * @Description: 商户映射
 * @date 2016-04-27 17:17:28
 * @version V1.0
 * @author 896728
 */

public class UpcMerchantMap implements Serializable {
	private static final long serialVersionUID = 5427661409205897868L;
	/** 序列 */
	private Long id;
	/** 商户号 */
	private String mchNo;
	/** 渠道商户号 */
	private String channelMchNo;
	/** 渠道商户参数key */
	private String channelMchParamKey;
	/** 渠道编码 */
	private String channelCode;
	/** 状态 启用ENABLED 禁用DISABLED */
	private String status;
	/** 创建时间 */
	private Date createTime;
	/** 更新时间 */
	private Date updateTime;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getMchNo() {
		return mchNo;
	}

	public void setMchNo(String mchNo) {
		this.mchNo = mchNo;
	}

	public String getChannelMchNo() {
		return channelMchNo;
	}

	public void setChannelMchNo(String channelMchNo) {
		this.channelMchNo = channelMchNo;
	}

	public String getChannelMchParamKey() {
		return channelMchParamKey;
	}

	public void setChannelMchParamKey(String channelMchParamKey) {
		this.channelMchParamKey = channelMchParamKey;
	}

	public String getChannelCode() {
		return channelCode;
	}

	public void setChannelCode(String channelCode) {
		this.channelCode = channelCode;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public Date getUpdateTime() {
		return updateTime;
	}

	public void setUpdateTime(Date updateTime) {
		this.updateTime = updateTime;
	}

}
