package com.sfpay.bill.domain;
import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**   
 *
 * @Description: 支付宝账单明细
 * @date 2016-12-24 15:22:55
 * @version V1.0   
 * @author 896728
 */

public class AlipayBillDetail implements Serializable {
	private static final long serialVersionUID = -1223988169342843455L;
	/** 主键*/
	private Long id;
	/** 支付宝交易号*/
	private String alipayTradeNo;
	/**渠道商户号*/
	private String channelMchId;
	/** 商户订单号*/
	private String mchOrderNo;
	/**账单日期：格式yyyy-MM-dd*/
	private String tradeTime;
	/** 业务类型*/
	private String businessType;
	/** 商品名称*/
	private String goodsName;
	/** 创建时间*/
	private String tradeStartTime;
	/** 完成时间*/
	private String tradeEndTime;
	/** 门店编号*/
	private String storeNo;
	/** 门店名称*/
	private String storeName;
	/** 操作员*/
	private String operator;
	/** 终端号*/
	private String terminal;
	/** 对方账户*/
	private String oppositeAccount;
	/** 订单金额（元）*/
	private BigDecimal orderAmt;
	/** 商家实收（元）*/
	private BigDecimal acturalAmount;
	/** 支付宝红包（元）*/
	private BigDecimal alipayRedpackAmount;
	/** 集分宝（元）*/
	private BigDecimal packCreditAmount;
	/** 支付宝优惠（元）*/
	private BigDecimal alipayDiscountAmount;
	/** 商家优惠（元）*/
	private BigDecimal mchDiscountAmount;
	/** 券核销金额（元）*/
	private BigDecimal couponAmount;
	/** 券名称*/
	private String couponName;
	/** 商家红包消费金额（元）*/
	private BigDecimal mchRedpackUseAmount;
	/** 卡消费金额（元）*/
	private BigDecimal cardAmount;
	/** 退款批次号/请求号*/
	private String refundNo;
	/** 服务费（元）*/
	private BigDecimal serviceFee;
	/** 分润（元）*/
	private BigDecimal shareBenefit;
	/** 创建时间*/
	private Date createDate;
	/** 更新时间*/
	private Date updateDate;
	/** 备注*/
	private String remark;
	

	public Long getId(){
		return id;
	}

	public void setId(Long id){
		this.id = id;
	}

	public String getAlipayTradeNo(){
		return alipayTradeNo;
	}

	public void setAlipayTradeNo(String alipayTradeNo){
		this.alipayTradeNo = alipayTradeNo;
	}

	public String getMchOrderNo(){
		return mchOrderNo;
	}

	public void setMchOrderNo(String mchOrderNo){
		this.mchOrderNo = mchOrderNo;
	}

	public String getChannelMchId() {
		return channelMchId;
	}

	public void setChannelMchId(String channelMchId) {
		this.channelMchId = channelMchId;
	}

	public String getTradeTime() {
		return tradeTime;
	}

	public void setTradeTime(String tradeTime) {
		this.tradeTime = tradeTime;
	}

	public String getBusinessType(){
		return businessType;
	}

	public void setBusinessType(String businessType){
		this.businessType = businessType;
	}

	public String getGoodsName(){
		return goodsName;
	}

	public void setGoodsName(String goodsName){
		this.goodsName = goodsName;
	}

	public String getTradeStartTime(){
		return tradeStartTime;
	}

	public void setTradeStartTime(String tradeStartTime){
		this.tradeStartTime = tradeStartTime;
	}

	public String getTradeEndTime(){
		return tradeEndTime;
	}

	public void setTradeEndTime(String tradeEndTime){
		this.tradeEndTime = tradeEndTime;
	}

	public String getStoreNo(){
		return storeNo;
	}

	public void setStoreNo(String storeNo){
		this.storeNo = storeNo;
	}

	public String getStoreName(){
		return storeName;
	}

	public void setStoreName(String storeName){
		this.storeName = storeName;
	}

	public String getOperator(){
		return operator;
	}

	public void setOperator(String operator){
		this.operator = operator;
	}

	public String getTerminal(){
		return terminal;
	}

	public void setTerminal(String terminal){
		this.terminal = terminal;
	}

	public String getOppositeAccount(){
		return oppositeAccount;
	}

	public void setOppositeAccount(String oppositeAccount){
		this.oppositeAccount = oppositeAccount;
	}

	public BigDecimal getOrderAmt(){
		return orderAmt;
	}

	public void setOrderAmt(BigDecimal orderAmt){
		this.orderAmt = orderAmt;
	}

	public BigDecimal getActuralAmount(){
		return acturalAmount;
	}

	public void setActuralAmount(BigDecimal acturalAmount){
		this.acturalAmount = acturalAmount;
	}

	public BigDecimal getAlipayRedpackAmount(){
		return alipayRedpackAmount;
	}

	public void setAlipayRedpackAmount(BigDecimal alipayRedpackAmount){
		this.alipayRedpackAmount = alipayRedpackAmount;
	}

	public BigDecimal getPackCreditAmount(){
		return packCreditAmount;
	}

	public void setPackCreditAmount(BigDecimal packCreditAmount){
		this.packCreditAmount = packCreditAmount;
	}

	public BigDecimal getAlipayDiscountAmount(){
		return alipayDiscountAmount;
	}

	public void setAlipayDiscountAmount(BigDecimal alipayDiscountAmount){
		this.alipayDiscountAmount = alipayDiscountAmount;
	}

	public BigDecimal getMchDiscountAmount(){
		return mchDiscountAmount;
	}

	public void setMchDiscountAmount(BigDecimal mchDiscountAmount){
		this.mchDiscountAmount = mchDiscountAmount;
	}

	public BigDecimal getCouponAmount(){
		return couponAmount;
	}

	public void setCouponAmount(BigDecimal couponAmount){
		this.couponAmount = couponAmount;
	}

	public String getCouponName(){
		return couponName;
	}

	public void setCouponName(String couponName){
		this.couponName = couponName;
	}

	public BigDecimal getMchRedpackUseAmount(){
		return mchRedpackUseAmount;
	}

	public void setMchRedpackUseAmount(BigDecimal mchRedpackUseAmount){
		this.mchRedpackUseAmount = mchRedpackUseAmount;
	}

	public BigDecimal getCardAmount(){
		return cardAmount;
	}

	public void setCardAmount(BigDecimal cardAmount){
		this.cardAmount = cardAmount;
	}

	public String getRefundNo(){
		return refundNo;
	}

	public void setRefundNo(String refundNo){
		this.refundNo = refundNo;
	}

	public BigDecimal getServiceFee(){
		return serviceFee;
	}

	public void setServiceFee(BigDecimal serviceFee){
		this.serviceFee = serviceFee;
	}

	public BigDecimal getShareBenefit(){
		return shareBenefit;
	}

	public void setShareBenefit(BigDecimal shareBenefit){
		this.shareBenefit = shareBenefit;
	}

	public Date getCreateDate(){
		return createDate;
	}

	public void setCreateDate(Date createDate){
		this.createDate = createDate;
	}

	public Date getUpdateDate(){
		return updateDate;
	}

	public void setUpdateDate(Date updateDate){
		this.updateDate = updateDate;
	}

	public String getRemark(){
		return remark;
	}

	public void setRemark(String remark){
		this.remark = remark;
	}
}
