package com.sfpay.bill.ftp;

import com.sfpay.acquirer.common.SFTPUtil;
import com.sfpay.framework2.config.properties.Property;

public class SFTPUtils {
	private static SFTPUtil sftp = null;
	static {
		sftp = new SFTPUtil(Property.getProperty("FTP_HOST"), Integer.parseInt(Property.getProperty("FTP_PORT")),
				Property.getProperty("FTP_USER_NAME"), Property.getProperty("FTP_PASSWORD"), Integer.parseInt(Property
						.getProperty("TIME_OUT")));
	}

	public static SFTPUtil getInstance() {
		return sftp;
	}
}
