/**
 * =================================================================
 * 版权所有 2011-2020 泰海网络支付服务有限公司，并保留所有权利
 * -----------------------------------------------------------------
 * 这不是一个自由软件！您不能在任何未经允许的前提下对程序代码进行修改和使用；
 * 不允许对程序代码以任何形式任何目的的再发布
 * =================================================================
 */
package com.sfpay.bill.service.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.sfpay.bill.dao.ChannelArgDao;
import com.sfpay.bill.domain.UpcChannelArg;
import com.sfpay.bill.dto.ChannelArgs;
import com.sfpay.framework.base.exception.ServiceException;

/**
 * 
 * 类说明：<br>
 * 渠道参数服务
 * 
 * </p>
 * 
 * @author 896728 杜猛超(duke) CreateDate: 2016-4-27
 */
@Service
public class ChannelArgService {
	private final Logger logger = LoggerFactory.getLogger(getClass());

	@Resource
	private ChannelArgDao dao;

	public ChannelArgs getChannelArgs(String mchChannelParamKey) {
		List<UpcChannelArg> ls = null;
		try {
			ls = dao.queryArgsByChannelCodeAndMchNo(mchChannelParamKey);
		} catch (Exception e) {
			logger.error(String.format("查询[%s]对应的银行配置参数异常", mchChannelParamKey), e);
			throw new ServiceException("FAILURE_DB", "查询异常");
		}
		Map<String, String> map = new HashMap<String, String>();
		for (UpcChannelArg bca : ls) {
			
			map.put(bca.getArgKey(), bca.getArgValue());
		}
		ChannelArgs arg = new ChannelArgs(map);
		arg.setMchChannelParamKey(mchChannelParamKey);
		return arg;
	}

}
