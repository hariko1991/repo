package com.sfpay.bill.task;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.framework.web.test.SpringTestCase;

public class ParseProblemCheckTaskTest  extends SpringTestCase {

	@Resource
	ParseProblemCheckTask problemCheckTask;
	@Test
	public void testCheckProcessing() {
		problemCheckTask.checkProcessing();
	}

}
