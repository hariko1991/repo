package com.sfpay.bill.task;

import java.io.IOException;
import java.math.BigDecimal;

import javax.annotation.Resource;

import org.junit.Test;

import com.sfpay.bill.dao.AllChannelBillDetailDao;
import com.sfpay.bill.domain.AllChannelBillDetail;
import com.sfpay.bill.domain.UpcMerchantMap;
import com.sfpay.bill.service.impl.AlipayBillParseServiceImpl;
import com.sfpay.bill.util.AntZipUtils;
import com.sfpay.framework.web.test.SpringTestCase;

public class ParseBillTaskTest extends SpringTestCase {
	
	@Resource
	private ParseWeChatBillTask billTask;
	@Resource
	private AlipayBillParseServiceImpl alipayBillParseService;
	@Resource
	private AllChannelBillDetailDao allChannelBillDetailDao;
	
	@Test
	public void testParseWXBill() {
		billTask.parseWXBill();
	}
	@Test
	public void testWXExcepBill() {
		billTask.parseWXExcepBill();
	}
	
	@Test
	public void testAlipayMerchantBillParse() throws InterruptedException{
		UpcMerchantMap map = new UpcMerchantMap();
		map.setChannelMchParamKey("TEST_ALIPAY111");
		String billDate = "2016-12-30";
		alipayBillParseService.execMerchantBillParse(map, billDate);
//		Thread.sleep(100000);
	}
	
	@Test
	public void testHandleHistoryExcpParseBillData() throws InterruptedException{
		alipayBillParseService.handleHistoryExcpParseBillData();
	}
	
	@Test
	public void testHandleYestodyExcpParseBillData() throws InterruptedException{
		alipayBillParseService.handleYestodayExcpParseBillData();
	}
	
	@Test
	public void testHandleExecBillData() throws InterruptedException{
		alipayBillParseService.execAlipayYestodayBillParse();
	}
	
	@Test
	public void testUnzip() throws IOException{
//		ZipUtil.doDecompress("H:/alipay/bill_data/trade_2088421207758794_2016-12-06.zip", "H:/alipay/bill_data/trade_2088421207758794_2016-12-06");
		AntZipUtils.unzipGBK("H:/alipay/bill_data/trade_2088421207758794_2016-12-06.zip", "H:/alipay/bill_data/trade_2088421207758794_2016-12-06", true);
	}
	
	@Test
	public void testAllChannelSave(){
		AllChannelBillDetail ad = new AllChannelBillDetail();
		
		ad.setChannelCode("ALIPAY");
		ad.setChannelMchId("21124432565456");
		ad.setChannelOrderNo("21124432565456");
		ad.setChannelRefundNo(null);
		ad.setGoodsName("sdfsdfsdfsf");
		ad.setMchOrderNo("21124432565456");
		ad.setServiceFee(BigDecimal.ZERO);
		ad.setTradeAmount(BigDecimal.ZERO);
		ad.setTradeState("SUCCESS");
		ad.setTradeTime("sdfsdf");
		ad.setTradeType("sdfsdfsfd");
		
		try {
			allChannelBillDetailDao.saveAllChannelBillDetail(ad);
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
