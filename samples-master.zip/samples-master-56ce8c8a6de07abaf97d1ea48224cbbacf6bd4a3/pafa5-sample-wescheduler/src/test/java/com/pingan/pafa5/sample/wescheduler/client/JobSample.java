package com.pingan.pafa5.sample.wescheduler.client;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.stp.wescheduler.client.WeschedulerName;

@Component
public class JobSample extends BaseServices {

	 //配置job,定义执行表达式 
    @Scheduled(cron="0/60 * * * * ?") 
    //定义job名字,组件内唯一即可 
    @WeschedulerName("testjob") 
    public void test(){ 
       logger.info("Runner test1 ....."); 
    } 
   
    @Scheduled(fixedRate=70000)
    @WeschedulerName("testjob2")
    public void test2() {
        logger.info("Runner test2 .....");
    }
    
    
}
