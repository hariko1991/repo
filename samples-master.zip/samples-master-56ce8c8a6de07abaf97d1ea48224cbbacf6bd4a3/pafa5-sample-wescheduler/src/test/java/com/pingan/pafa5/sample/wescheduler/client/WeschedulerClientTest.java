package com.pingan.pafa5.sample.wescheduler.client;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList = "wescheduler-client-sample")
public class WeschedulerClientTest extends BaseSARTest {
	
	static {
		System.setProperty("dubbo.protocol.port", "50089");
	}

    @Test
    public void test() throws Exception {
        System.in.read();
    }

}
