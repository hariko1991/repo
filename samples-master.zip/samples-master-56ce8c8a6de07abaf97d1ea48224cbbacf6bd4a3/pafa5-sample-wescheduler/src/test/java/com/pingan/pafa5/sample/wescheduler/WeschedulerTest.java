package com.pingan.pafa5.sample.wescheduler;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList = "wescheduler-server", protocols = "jetty,dubbo")
public class WeschedulerTest extends BaseSARTest {

    @Test
    public void test() throws Exception {
        System.in.read();
    }

}
