package com.pingan.pafa5.sample.esg;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.esg.common.extension.PA_API;
import com.paic.pafa.validator.annotation.Valid;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;

@Controller
/**服务定义*/
@PA_API("PAFA5_SAMPLE_TEST")
public class HelloESG extends BaseController {

	/** 接口定义，注意要和URIPattern：/esg/**对应。 */
	@RequestMapping(value = "/esg/hello2", method = RequestMethod.POST)
	@ESA(name = "hello2")
	public @ResponseBody
	ModelMap hello(@ModelAttribute @Valid HelloForm form) {
		if (logger.isInfoEnabled()) {
			logger.info("name=" + form.getName());
			logger.info("clientId=" + form.getClientId());
		}
		String msg = "Hello," + form.getName();
		ModelMap model = new ModelMap();
		model.put("responseCode", "0");
		model.put("message", msg);
		return model;
	}

}
