package com.pingan.pafa5.sample.esg;

import com.paic.pafa.validator.annotation.VLength;
import com.paic.pafa.validator.annotation.VNotEmpty;

public class HelloForm {

	@VNotEmpty
	@VLength(min=3,max=20)
	private String name;
	
	@VLength(max=32,min=16)
	private String clientId;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getClientId() {
		return clientId;
	}

	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	
	
	
}
