package com.pingan.pafa5.sample.esg;

import java.util.HashMap;
import java.util.Map;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.web.client.RestOperations;

import com.alibaba.fastjson.JSONObject;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="sample-esg" ,plugins="jetty")
public class HelloESGTests extends BaseSARTest{

	@Autowired
	@Qualifier("myService")
	private RestOperations restOperations;
	
	@Test
	public void tests() throws Exception {
//		for(int i=0;i<10;i++){
			Map<String, Object> param = new HashMap<String,Object>();
			param.put("name","nangua");
			String url = "/esg/hello2";
			
			JSONObject json=restOperations.postForObject(url, param,JSONObject.class);
			System.out.println("json="+json);
//		}
//		System.in.read();
	}
	
	public void setRestOperations(RestOperations restOperations) {
		this.restOperations = restOperations;
	}
	
}
