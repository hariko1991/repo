package com.pingan.pafa5.sample.esg;

import org.junit.Test;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="sample-esg"
		,plugins="jetty")
public class HelloESGTests2 extends BaseSARTest{

	
	
	@ActionClient(name="esg/hello2",pafaAc="esg_pafa_ac")
	private IServiceClient client;
	
	
	@Test
	public void tests() throws Exception {
//		for(int i=0;i<10;i++){
			ServiceParams params = new ServiceParams();
//			params.put("name","nangua"+i);
			params.put("name","nangua");
			ServiceResults json=client.invoke(params);
			System.out.println("json="+json);
//		}
//		System.in.read();
	}
	
	

}
