package com.pingan.pafa5.sample.esg;

import java.util.UUID;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="sample-esg")
public class HelloESGTests3 extends BaseSARTest{
	
	
	@Test
	public void tests() throws Exception {
		String result=this.handleWebRequest(this.createMockRequest("/appsvr/group/esg/hello2"
				, "name=nangua&clientId="+UUID.randomUUID().toString().replaceAll("-", ""))
				,this.createMockResponse());
		logger.info(result);
	}
	
	

}
