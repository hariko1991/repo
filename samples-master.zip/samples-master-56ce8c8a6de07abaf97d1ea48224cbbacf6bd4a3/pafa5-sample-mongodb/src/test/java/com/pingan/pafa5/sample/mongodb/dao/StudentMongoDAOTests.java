package com.pingan.pafa5.sample.mongodb.dao;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.mongodb.MongoPagination;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa5.sample.mongodb.dao.StudentMongoDAO;
import com.pingan.pafa5.sample.mongodb.dtos.StudentDTO;

@SARContextConfiguration(sarList="sample-mongodb")
public class StudentMongoDAOTests extends BaseSARTest {
	
	@Autowired
	private StudentMongoDAO studentDAO;

	@Test
	public void test() throws Exception{
		//studentMongoCollection.indexOps().dropAllIndexes();
        //查询所有的数据
		logger.info("------------------7:"+studentDAO.removeById("11"));
		
		StudentDTO stu=new StudentDTO("nangua1", 20);
		stu.setId("11");
		studentDAO.add(stu);
		String id=stu.getId();
		logger.info("------------------id="+id);
		logger.info("------------------0:"+studentDAO.getById(id));
		stu.setStuName("nangua2");
		logger.info("------------------1:"+studentDAO.updateById(stu));
		logger.info("------------------11:"+studentDAO.getById(id));
		//-------------------------------
		logger.info("------------------2:"+studentDAO.getByName("nangua2")); 
		logger.info("------------------3:"+studentDAO.listByName("nangua2"));
		MongoPagination<StudentDTO> page=new MongoPagination<StudentDTO>(1,2);
		studentDAO.paginated(page,"nangua2");
		logger.info("------------------4:"+page.getPojos());
		logger.info("------------------5:"+page.getTotalSize());
		logger.info("------------------6:"+studentDAO.size());
		//回滚测试数据
		logger.info("------------------7:"+studentDAO.removeById(id));
		
	} 
}
