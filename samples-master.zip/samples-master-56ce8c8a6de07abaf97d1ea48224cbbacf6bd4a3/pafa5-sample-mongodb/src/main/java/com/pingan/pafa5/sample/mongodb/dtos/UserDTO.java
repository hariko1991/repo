package com.pingan.pafa5.sample.mongodb.dtos;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.alibaba.fastjson.JSONObject;


@Document(collection="SampleUserDTO")
public class UserDTO {
	
	@Id
	@Indexed
	private String uid;
	
	@Indexed
	private String userName;
	
	public UserDTO(){}
	 
	public UserDTO(String uid){
		this.uid=uid;
	}
	
	public UserDTO(String uid,String userName){
		this.uid=uid;
		this.userName=userName;
	}

	
	@Override
	public String toString() {
		return JSONObject.toJSONString(this);
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
	
	
}
