package com.pingan.pafa5.sample.mongodb.dao;

import java.util.Map;

import org.springframework.data.mongodb.core.DbCallback;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.stereotype.Component;

import com.mongodb.DB;
import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa.mongodb.MongoPagination;
import com.pingan.pafa5.sample.mongodb.dtos.UserDTO;

@Component
public class UserMongoDAO extends BaseMongoDAO<UserDTO>{

	public void test() throws Exception{
		this.getMongoTemplate().indexOps(this.getCollectionName()).dropAllIndexes();
        //查询所有的数据
		logger.info("-----------0:"+this._remove(where("uid").ne(null)));
		
		logger.info("-----------1:"+this._removeById("1"));
		logger.info("-----------2:"+this._removeByProperty("userName", "nangua3"));
		logger.info("-----------3:"+this._removeById("6"));
		logger.info("-----------4:"+this._removeById("2"));
		this._add(new UserDTO("1", "nangua1"));
		this._add(new UserDTO("2", "nangua2"),new UserDTO("3", "nangua3"));
		logger.info("-----------7:"+this._getById("1"));
		logger.info("-----------8:"+this._get(Criteria.where("userName").is("nangua3"))); 
		logger.info("-----------9:"+this._getByProperty("userName", "nangua3"));
		logger.info("-----------91:"+this._list(where("userName").regex("nangua").and("age").lt(10)));
		// 
		this.executeInSession(new DbCallback<Object>() {
		
			@Override
			public Object doInDB(DB db) {
				
				logger.info("-----------10:"+UserMongoDAO.this._updateById( "2",new UserDTO("2","nangua4")));
				logger.info("-----------11:"+UserMongoDAO.this._updateByProperty("name","nangua4",new UserDTO("2","nangua5")));
				logger.info("-----------12:"+UserMongoDAO.this._update( where("uid").is("2").and("userName").is("nangua5"),new UserDTO("2","nangua6")));
				logger.info("-----------13:"+UserMongoDAO.this._getById("2"));
				return null;
			}
		});
		
		logger.info("-----------14:"+this._getAndUpdate(where("uid").is("2").and("userName").is("nangua6"), new UserDTO("2","nangua7")));
		logger.info("-----------15:"+this._getAndUpdate(where("uid").is("2"), new UserDTO("2","nangua8")));
		logger.info("-----------16:"+this._getAndUpdate(where("userName").is("nangua8"), new UserDTO("2","nangua9")));
		logger.info("-----------16:"+this._getAndUpdate(where("userName").is("nangua8")
				, new UserDTO("2","nangua9"))); 
		//
		logger.info("-----------17:"+this._listAndDesc(null,"userName"));
		logger.info("-----------18:"+this._list(null,2,1));
		logger.info("-----------19:"+this._list(where("uid").is("1")));
		MongoPagination<UserDTO> page=new MongoPagination<UserDTO>(1,2);
		this._paginated(null, page); 
		logger.info("-----------20:"+page.getPojos());
		logger.info("-----------21:"+page.getTotalSize());
		
		logger.info("-----------22:"+this._groupBy( this.groupOperation().min("userName").as("userName_count"),null, Map.class));
		
		logger.info("-----------9999:"+this.getMongoTemplate().indexOps(this.getCollectionName()).getIndexInfo());
	} 
}
