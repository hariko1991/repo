package com.pingan.pafa5.sample.mongodb.dtos;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.alibaba.fastjson.JSONObject;


@Document(collection="SampleStudentDTO")
public class StudentDTO {
	
	@Id
	private String id;
	
	@Indexed
	private String stuName;
	
	
	private Integer age;
	
	public StudentDTO(){}
	 
	public StudentDTO(String stuName){
		this.stuName=stuName;
	}
	
	public StudentDTO(String stuName,Integer age){
		this.stuName=stuName;
		this.age=age;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	@Override
	public String toString() {
		return JSONObject.toJSONString(this);
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}
	
	
	
}
