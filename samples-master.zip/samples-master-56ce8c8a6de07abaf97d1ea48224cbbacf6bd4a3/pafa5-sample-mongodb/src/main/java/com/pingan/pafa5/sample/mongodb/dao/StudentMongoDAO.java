package com.pingan.pafa5.sample.mongodb.dao;

import java.util.List;

import org.springframework.stereotype.Component;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa.mongodb.MongoPagination;
import com.pingan.pafa5.sample.mongodb.dtos.StudentDTO;

@Component
public class StudentMongoDAO extends BaseMongoDAO<StudentDTO>{

	public StudentMongoDAO(){
	}
	
	public StudentDTO getById(String stuId){
		return this._getById(stuId);
	}
	
	public boolean removeById(String stuId){
		return this._removeById(stuId);
	}
	
	public boolean updateById(StudentDTO stu){
		return this._updateById(stu);
	}
	
	public void add(StudentDTO stu){
		this._add(stu);
	}
	
	public StudentDTO getByName(String name){
		return this._get(where("stuName").is(name).and("age").lt(23));
	}

	public List<StudentDTO> listByName(String name){
		return this._list(where("stuName").is(name));
	}
	
	public MongoPagination<StudentDTO>  paginated(MongoPagination<StudentDTO> page,String name){
		return this._paginated(where("stuName").is(name), page);
	}
	
	public long size(){
		return this._count(null);
	}
	
	
}
