package com.pingan.pafa5.sample.sar.services;


import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa5.sample.sar.dto.SampleDTO;

@SARContextConfiguration(sarList= "sample-sar")
public class SampleServicesTest extends BaseSARTest {

	@Autowired
	private  SampleServices  sampleServices;
	
	@Test
	public void test(){
		SampleDTO dto=new SampleDTO();
		Assert.assertNotNull(sampleServices.say(dto));
	}

}
