package com.pingan.pafa5.sample.sar.facade;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.pingan.pafa.papp.esa.client.ActionClientFactory;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList= "sample-sar")
public class SampleFacadeTest extends BaseSARTest {

	@Autowired
	private ActionClientFactory actionsClients;

	@Test
	public void testSayHello() {
		ServiceResults result=actionsClients.get("sample-sar.say").invoke(ServiceParams.newInstance().set("name", "zhangsan"));
		logger.info("result="+result);
		 Assert.assertEquals(result.get("responseCode"), "0");
	}
	

}
