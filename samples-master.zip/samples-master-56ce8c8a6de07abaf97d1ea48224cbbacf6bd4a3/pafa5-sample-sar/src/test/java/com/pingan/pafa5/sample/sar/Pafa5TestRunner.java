package com.pingan.pafa5.sample.sar;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;


@SARContextConfiguration(sarList= "sample-sar", plugins = "jetty")
public class Pafa5TestRunner extends BaseSARTest {


    @Test
    public void run() throws Throwable {
        System.in.read();
    }

}
