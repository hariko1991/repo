package com.pingan.pafa5.sample.sar;

import com.pingan.pafa.datasource.SARDatasource;
import com.pingan.pafa.datasource.SARTransaction;
import com.pingan.pafa.papp.sar.annotations.SAR;
import com.pingan.pafa.support.quartz.SARQuartz;

@SAR(webEnable=true,webPatterns="/sample-sar/**")
@SARTransaction
@SARDatasource("pizza:/datasource/sample-sar.druid.properties")
@SARQuartz
public interface SARBoot {

}
