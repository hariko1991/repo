package com.pingan.pafa5.sample.sar.sao;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.biz.sao.BaseSAO;
import com.pingan.pafa.papp.esa.client.ActionClientFactory;

@Component("sampleSAO")
public class SampleSAOBean extends BaseSAO implements SampleSAO{
	
	@Autowired
	private ActionClientFactory actionsClients;

	
	@Override
	public void sample() {
		ServiceResults result=actionsClients.get("sample-sao.mock-sample").invoke(ServiceParams.newInstance().set("name", "zhangsan"));
		logger.info("result="+result);
	}
	



	public ActionClientFactory getActionsClients() {
		return actionsClients;
	}



	public void setActionsClients(ActionClientFactory actionsClients) {
		this.actionsClients = actionsClients;
	}


	

	
}
