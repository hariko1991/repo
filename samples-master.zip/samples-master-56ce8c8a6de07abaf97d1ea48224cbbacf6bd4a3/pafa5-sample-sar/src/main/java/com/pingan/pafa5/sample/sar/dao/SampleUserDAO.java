package com.pingan.pafa5.sample.sar.dao;

import java.util.List;

import com.pingan.pafa5.sample.sar.dao.model.SampleUserModel;
import com.pingan.pafa5.sample.sar.utils.BaseMyBatisMapper;

public interface SampleUserDAO extends BaseMyBatisMapper {
	
	boolean insertUser(SampleUserModel user);
	
	SampleUserModel getUserByName(String name);
	
	List<SampleUserModel> getAll();
	
}
