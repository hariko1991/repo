package com.pingan.pafa5.sample.sar.services;

import com.pingan.pafa5.sample.sar.dto.SampleDTO;

public interface SampleServices {
	
	String say(SampleDTO  sampleDTO);
	
}
