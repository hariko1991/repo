package com.pingan.pafa5.sample.sar.web;

import com.paic.pafa.validator.annotation.VLength;
import com.pingan.pafa5.sample.sar.dto.SampleDTO;

public class SayHelloForm {
	
	@VLength(min=2)
	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	public SampleDTO toSampleDTO(){
		SampleDTO dto=new SampleDTO();
		dto.setName(name);
		return dto;
	}
	
}
