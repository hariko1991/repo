package com.pingan.pafa5.sample.sar.web;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa5.sample.sar.services.SampleServices;

@Controller
public class SampleController extends BaseController {
	
	@Autowired
	private SampleServices sampleServices;
	

    @ResponseBody
    @RequestMapping("/sample-sar/say")
    public ResponseModel hello(SayHelloForm params) {
        if (logger.isInfoEnabled()) {
            logger.info("name=" + params.getName());
        }
        String msg = sampleServices.say(params.toSampleDTO());
        ResponseModel model = new ResponseModel();
        model.put("message", msg);
        return model;
    }

	public SampleServices getSampleServices() {
		return sampleServices;
	}

	public void setSampleServices(SampleServices sampleServices) {
		this.sampleServices = sampleServices;
	}
    
    

}
