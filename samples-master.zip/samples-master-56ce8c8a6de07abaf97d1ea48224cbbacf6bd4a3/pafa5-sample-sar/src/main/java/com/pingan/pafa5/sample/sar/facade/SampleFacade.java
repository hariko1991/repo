package com.pingan.pafa5.sample.sar.facade;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa5.sample.sar.services.SampleServices;

@Service
public class SampleFacade extends BaseServices{
	
	
	@Autowired
	private SampleServices sampleServices;
	


	@ResponseBody
	@ESA("${sar.name}.say")
	public ResponseModel hello(SayHelloActionParams params) throws Exception {
		if (logger.isInfoEnabled()) {
			logger.info("name=" + params.getName());
		}
		//
		String msg = sampleServices.say(params.toSampleDTO());
		ResponseModel model = new ResponseModel();
		model.put("message", msg);
		return model;
	}


	public SampleServices getSampleServices() {
		return sampleServices;
	}



	public void setSampleServices(SampleServices sampleServices) {
		this.sampleServices = sampleServices;
	}
	
	
}
