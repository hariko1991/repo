package com.pingan.pafa5.sample.sar.utils;

public interface BaseMyBatisMapper {

}
