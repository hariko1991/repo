package com.pingan.pafa5.sample.sar.sao;

public interface SampleSAO {

	void sample();
	
}
