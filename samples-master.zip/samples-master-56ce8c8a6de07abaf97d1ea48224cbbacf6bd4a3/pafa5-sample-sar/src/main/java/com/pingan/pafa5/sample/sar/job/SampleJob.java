package com.pingan.pafa5.sample.sar.job;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.redis.lock.RedisLock;
import com.pingan.pafa.redis.lock.RedisLockFactory;

@Component
public class SampleJob extends BaseServices  {

	
	private Random random=new Random();
	
	private int counter;
	
	@Value("${sample.wait.mills}")
	private int waitMills;
	
	
	
	@Autowired
	@Qualifier("lock_factory")
	private RedisLockFactory lockFactory;
	
	
	@Scheduled(cron="${sample.job.cron}")
	public void execute() throws Exception{
		RedisLock lock=lockFactory.getLock("SampleJob");
		if(lock.tryLock(waitMills)){
			try{
				int i=random.nextInt(2)+1000;
				Thread.sleep(i);
				//job执行代码
				logger.info("Job running,counter="+(counter++)+",sleep="+i);
			}finally{
				lock.unlock();
			}
		}
	}


	public RedisLockFactory getLockFactory() {
		return lockFactory;
	}


	public void setLockFactory(RedisLockFactory lockFactory) {
		this.lockFactory = lockFactory;
	}


	public int getWaitMills() {
		return waitMills;
	}


	public void setWaitMills(int waitMills) {
		this.waitMills = waitMills;
	}





	
	
	
	
	
}
