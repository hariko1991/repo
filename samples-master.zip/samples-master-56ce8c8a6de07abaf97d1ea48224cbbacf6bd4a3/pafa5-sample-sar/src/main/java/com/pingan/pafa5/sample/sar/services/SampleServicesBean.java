package com.pingan.pafa5.sample.sar.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa5.sample.sar.dao.SampleUserDAO;
import com.pingan.pafa5.sample.sar.dao.model.SampleUserModel;
import com.pingan.pafa5.sample.sar.dto.SampleDTO;
import com.pingan.pafa5.sample.sar.sao.SampleSAO;

@Component("sampleServices")
public class SampleServicesBean extends BaseServices implements SampleServices {
	
	@Autowired
	private SampleSAO sampleSAO;
	
	@Autowired
	private SampleUserDAO sampleUserDAO;

	@Override
	@Transactional//开启事务
	public String say(SampleDTO  sampleDTO) {
		SampleUserModel user=sampleUserDAO.getUserByName(sampleDTO.getName());
		if(user!=null){
			return "Welcome,"+sampleDTO.getName();
		}else{
			sampleUserDAO.insertUser(user);
			sampleSAO.sample();
			return "Hello,"+sampleDTO.getName();
		}
	}

	public SampleSAO getSampleSAO() {
		return sampleSAO;
	}

	public void setSampleSAO(SampleSAO sampleSAO) {
		this.sampleSAO = sampleSAO;
	}

	public SampleUserDAO getSampleUserDAO() {
		return sampleUserDAO;
	}

	public void setSampleUserDAO(SampleUserDAO sampleUserDAO) {
		this.sampleUserDAO = sampleUserDAO;
	}
	
	
	
}
