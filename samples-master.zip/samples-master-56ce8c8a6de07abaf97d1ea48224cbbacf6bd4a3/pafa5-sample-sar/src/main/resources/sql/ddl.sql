
CREATE TABLE student (
	Id INT NOT NULL,
	name VARCHAR(32),
	age INT,
	PRIMARY KEY (Id)
) ENGINE=InnoDB;
