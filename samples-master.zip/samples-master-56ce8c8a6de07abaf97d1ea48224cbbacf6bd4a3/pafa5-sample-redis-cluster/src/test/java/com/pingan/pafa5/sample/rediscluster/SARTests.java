package com.pingan.pafa5.sample.rediscluster;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;



@SARContextConfiguration(sarList="sample-rediscluster",plugins="jetty")
public class SARTests extends BaseSARTest{

	
	@Test
	public void iz() throws Throwable{
		
		System.in.read();
	}
	
}
