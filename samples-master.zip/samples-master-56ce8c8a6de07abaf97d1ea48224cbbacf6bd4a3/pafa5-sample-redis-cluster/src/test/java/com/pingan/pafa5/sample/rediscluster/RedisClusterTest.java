package com.pingan.pafa5.sample.rediscluster;

import static org.hamcrest.Matchers.equalTo;
import static org.hamcrest.Matchers.is;
import static org.junit.Assert.assertThat;

import java.io.UnsupportedEncodingException;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import redis.clients.jedis.JedisCluster;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="sample-rediscluster", plugins="jetty")
public class RedisClusterTest extends BaseSARTest {
	
	@Autowired
	private JedisCluster cluster;
	
	@Test
	public void testSetAndGetex() {
		String result = cluster.setex("hello", 20, "redis-cluster");
		assertThat(result, equalTo("OK"));
		assertThat(cluster.get("hello"), equalTo("redis-cluster"));
		
	}
	
	@Test
	public void testSetAndGetexByte() throws UnsupportedEncodingException {
		byte[] key = "hello".getBytes("utf-8");
		byte[] val = "redis-cluster".getBytes("utf-8");
		cluster.setex(key, 20, val);
		assertThat(cluster.get(key), equalTo(val));
	}
	
	@Test
	public void testDelStr() {
		cluster.set("hello", "redis-cluster");
		assertThat(cluster.get("hello"), equalTo("redis-cluster"));
		cluster.del("hello");
		assertThat(cluster.exists("hello"), is(false));
	}
	
	@Test
	public void testAppendStr() {
		cluster.set("hello", "redis-cluster");
		cluster.append("hello", "-postfix");
		assertThat(cluster.get("hello"), equalTo("redis-cluster-postfix"));
		cluster.del("hello");
	}
	
	@Test
	public void testOperateList() {
		cluster.del("list");
		cluster.lpush("list", "val1");
		cluster.lpush("list", "val2");
		cluster.rpush("list", "val3");
		cluster.rpush("list", "val4");
		cluster.rpush("list", "val5");
		cluster.lpop("list");
		cluster.rpop("list");
		List<String> list = new LinkedList<String>();
		list.add("val1");
		list.add("val3");
		list.add("val4");
		assertThat(cluster.lrange("list", 0, -1), equalTo(list));
		cluster.del("list");
	}
	@Test
	public void testOperateMap() {
		Map<String, String> map = new HashMap<String, String>();
		map.put("key1", "val1");
		map.put("key2", "val2");
		cluster.hmset("map", map);
		assertThat(cluster.hgetAll("map"), equalTo(map));
		cluster.del("map");
	}

}
