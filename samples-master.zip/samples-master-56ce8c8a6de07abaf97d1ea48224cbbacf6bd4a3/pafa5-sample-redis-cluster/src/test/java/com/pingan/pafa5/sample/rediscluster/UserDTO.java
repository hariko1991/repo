package com.pingan.pafa5.sample.rediscluster;

/**
 * Created by WUJIANFENG806 on 2017/12/19.
 */
public class UserDTO implements java.io.Serializable, Cloneable {
	private static final long serialVersionUID = 5514034164192897354L;

	private String name;

	private int age;

	public UserDTO() {
	}

	public UserDTO(String name, int age) {
		this.name = name;
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String toString() {
		return "name=" + name + ",age=" + age;
	}


}
