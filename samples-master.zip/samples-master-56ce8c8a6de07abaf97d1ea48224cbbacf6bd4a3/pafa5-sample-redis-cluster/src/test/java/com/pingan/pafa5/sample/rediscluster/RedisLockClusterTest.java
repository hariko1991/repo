package com.pingan.pafa5.sample.rediscluster;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa.redis.lock.RedisLock;
import com.pingan.pafa.redis.lock.RedisLockFactory;

@SARContextConfiguration(sarList="sample-rediscluster", plugins="jetty")
public class RedisLockClusterTest extends BaseSARTest {
	
	@Autowired
	private RedisLockFactory redislock;
	
	@Test
	public void lockTest() {
		RedisLock lock = redislock.getLock("lock1");
		
		//使用execute方法
		lock.execute(new Runnable() {
			
			@Override
			public void run() {
				// TODO Auto-generated method stub
				logger.info("lock success.");
				
			}
		});
		
		//手工trylock，控制更好些，比如加超时时间
		if(lock.tryLock(1000)) {
			try {
				logger.info("lock success.");
			} finally {
				lock.unlock();
			}
		}else{
			logger.error("lock fail.");
		}
		
	}

}
