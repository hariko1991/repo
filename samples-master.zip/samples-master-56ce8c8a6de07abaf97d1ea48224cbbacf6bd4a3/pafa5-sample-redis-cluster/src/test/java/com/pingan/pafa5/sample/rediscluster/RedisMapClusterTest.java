package com.pingan.pafa5.sample.rediscluster;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa.redis.map.RedisMap;
import com.pingan.pafa.redis.map.RedisMapFactory;

@SARContextConfiguration(sarList="sample-rediscluster", plugins="jetty")
public class RedisMapClusterTest extends BaseSARTest {
	
	@Autowired
	private RedisMapFactory<String,UserDTO> sampleGlobalMapClusterFactory;
	
	@Autowired
	private RedisMap<String,UserDTO> sampleGlobalMapCluster;
	
	@Test
	public void RedisMapFactoryBeanTest() {
		RedisMap<String, UserDTO>  redisMap = sampleGlobalMapClusterFactory.get("id1");
		redisMap.put("id_2", new UserDTO("nangua2", 31));
		redisMap.put("id_3", new UserDTO("nangua", 32));
		redisMap.setExpiredTime(10);
		redisMap.put("id_4", new UserDTO("nangua", 32));
		UserDTO user = (UserDTO)redisMap.get("id_2");
		logger.info("name:" + user.getName() + "  age:" + user.getAge());
		Assert.assertEquals("nangua2", user.getName());
	}
	
	@Test
	public void RedisClusterMapBeanTest() {
		sampleGlobalMapCluster.put("id_2", new UserDTO("nangua2", 31));
		sampleGlobalMapCluster.put("id_3", new UserDTO("nangua", 32));
		sampleGlobalMapCluster.setExpiredTime(10);
		sampleGlobalMapCluster.put("id_4", new UserDTO("nangua", 32));
		UserDTO user = (UserDTO)sampleGlobalMapCluster.get("id_2");
		logger.info("name:" + user.getName() + "  age:" + user.getAge());
		Assert.assertEquals("nangua2", user.getName());
		
	}

}
