package com.pingan.pafa5.sample.rediscluster;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa.redis.queue.RedisQueue;

@SARContextConfiguration(sarList="sample-rediscluster", plugins="jetty")
public class RedisQueueClusterTest extends BaseSARTest {
	
	@Autowired
	private RedisQueue<UserDTO> sampleQueuefactory;
	
	@Test
	public void lockTest() {
		sampleQueuefactory.clear();
		sampleQueuefactory.push(new UserDTO("nangua", 16));
		sampleQueuefactory.push(new UserDTO("zhangsan", 16));
		sampleQueuefactory.push(new UserDTO("lisi", 16));

		UserDTO user = sampleQueuefactory.pop();
		logger.info(user);
		user = sampleQueuefactory.pop();
		logger.info(user);
		user = sampleQueuefactory.pop();
		logger.info(user);
	}

}
