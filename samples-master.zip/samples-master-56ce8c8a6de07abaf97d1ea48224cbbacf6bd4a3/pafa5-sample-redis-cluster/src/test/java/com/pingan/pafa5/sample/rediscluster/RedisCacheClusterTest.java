package com.pingan.pafa5.sample.rediscluster;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa.redis.cache.RedisCache;


@SARContextConfiguration(sarList="sample-rediscluster", plugins="jetty")
public class RedisCacheClusterTest extends BaseSARTest {
	
	@Autowired
	private RedisCache<UserDTO> sample_cache;
	
	@Test
	public void lockTest() {
		UserDTO user = new UserDTO();
		user.setName("name");
		sample_cache.set("u1", user);

		UserDTO getuser = sample_cache.get("u1");
		logger.info(getuser.getName());
		Assert.assertEquals(user.getName(), getuser.getName());
		
	}

}
