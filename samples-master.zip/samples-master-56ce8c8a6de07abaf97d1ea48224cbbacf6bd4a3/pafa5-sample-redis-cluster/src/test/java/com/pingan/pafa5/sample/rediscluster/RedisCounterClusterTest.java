package com.pingan.pafa5.sample.rediscluster;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa.redis.counter.RedisInteger;
import com.pingan.pafa.redis.counter.RedisLong;


@SARContextConfiguration(sarList="sample-rediscluster", plugins="jetty")
public class RedisCounterClusterTest extends BaseSARTest {
	
	@Autowired
	//@Qualifier("sampleCounterInteger")
	private RedisInteger sampleCounterInteger;
	
	@Test
	public void sampleCounterIntegerTest() {
		sampleCounterInteger.set(0);
		sampleCounterInteger.increment();
		sampleCounterInteger.increment();
		sampleCounterInteger.add(3);
		sampleCounterInteger.decrement();
		int d = sampleCounterInteger.decrement();
		Assert.assertEquals(3, d);
		logger.info("value=" + d);
	}
	
	@Autowired
	//@Qualifier("sampleCounterLongfactory")
	private RedisLong sampleCounterLongfactory;
	
	@Test
	public void sampleCounterLongFactoryTest() {
		sampleCounterLongfactory.set(0);
		sampleCounterLongfactory.increment();
		sampleCounterLongfactory.increment();
		sampleCounterLongfactory.add(3);
		sampleCounterLongfactory.decrement();
		long d = sampleCounterLongfactory.decrement();
		Assert.assertEquals(3, d);
		logger.info("value=" + d);
	}

}
