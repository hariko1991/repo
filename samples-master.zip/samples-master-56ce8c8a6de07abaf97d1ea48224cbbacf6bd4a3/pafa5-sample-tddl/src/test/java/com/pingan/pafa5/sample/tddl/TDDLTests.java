package com.pingan.pafa5.sample.tddl;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa5.sample.tddl.services.TDDLSampleServcies;


@SARContextConfiguration(sarList="sample-tddl")
public class TDDLTests extends BaseSARTest{

	@Autowired
	private TDDLSampleServcies services;
	
	@Test
	public void test2() throws Throwable{
		services.test();
	}
	
}
