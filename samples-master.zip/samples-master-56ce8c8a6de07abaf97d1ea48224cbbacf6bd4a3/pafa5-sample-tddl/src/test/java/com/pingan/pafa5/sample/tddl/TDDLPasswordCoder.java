package com.pingan.pafa5.sample.tddl;



import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.spec.SecretKeySpec;

public class TDDLPasswordCoder  {

	private static byte[] ENC_KEY_BYTES = "This is a finger".getBytes();

	public String encode(String encKey, String secret)
			throws NoSuchAlgorithmException, NoSuchPaddingException,
			InvalidKeyException, IllegalBlockSizeException, BadPaddingException {
		byte[] kbytes = ENC_KEY_BYTES;
		if (encKey != null && !"".equals(encKey))
			kbytes = encKey.getBytes();

		SecretKeySpec key = new SecretKeySpec(kbytes, "AES");
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(1, key);
		byte[] encoding = cipher.doFinal(secret.getBytes());
		BigInteger n = new BigInteger(encoding);
		return n.toString(16);
	}

	public String encode(String secret) throws NoSuchPaddingException,
			NoSuchAlgorithmException, InvalidKeyException, BadPaddingException,
			IllegalBlockSizeException {
		return encode(null, secret);
	}

	public String decode(String encKey, String secret)
			throws NoSuchPaddingException, NoSuchAlgorithmException,
			InvalidKeyException, BadPaddingException, IllegalBlockSizeException {
		byte[] kbytes = ENC_KEY_BYTES;
		if (encKey != null && !"".equals(encKey))
			kbytes = encKey.getBytes();

		SecretKeySpec key = new SecretKeySpec(kbytes, "AES");
		BigInteger n = new BigInteger(secret, 16);
		byte[] encoding = n.toByteArray();
		Cipher cipher = Cipher.getInstance("AES");
		cipher.init(2, key);
		byte[] decode = cipher.doFinal(encoding);
		return new String(decode);
	}

	public char[] decode(String secret) throws NoSuchPaddingException,
			NoSuchAlgorithmException, InvalidKeyException, BadPaddingException,
			IllegalBlockSizeException {
		return decode(null, secret).toCharArray();
	}

	public static void main(String[] args) throws Exception {

		TDDLPasswordCoder paPasswdCode = new TDDLPasswordCoder();

		String encPasswd = null;
		String password = "root";
		
		
		encPasswd = new String(paPasswdCode.encode(password));

		System.out.println("原密码：" + password);
		System.out.println("加密后的密码：" + encPasswd);

		// if (args.length == 0) {
		// System.out.println("请输入密码的密文：");
		// return;
		// }
		// encPasswd = args[0];

		// encPasswd="";
		// password = new String(paPasswdCode.decode(encPasswd));
		//
		// System.out.println("加密后的密码：" + encPasswd);
		// System.out.println("原密码：" + password);

		// System.out.println("Encoded password: " + new
		// String(paPasswdCode.encode("tddl")));
		// System.out.println("Decoded password: " + new
		// String(paPasswdCode.decode("5a826c8121945c969bf9844437e00e28")));
	}
}