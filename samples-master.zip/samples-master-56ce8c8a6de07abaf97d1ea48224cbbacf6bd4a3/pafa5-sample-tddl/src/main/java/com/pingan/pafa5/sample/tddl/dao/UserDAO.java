package com.pingan.pafa5.sample.tddl.dao;

import com.pingan.pafa5.sample.tddl.dto.UserDTO;

public interface UserDAO {
	
	boolean add(UserDTO sampleDTO);
	
	UserDTO getById(Integer id);
	
	boolean delById(Integer id);
	
	boolean updateName(Integer id,String newName);
}
