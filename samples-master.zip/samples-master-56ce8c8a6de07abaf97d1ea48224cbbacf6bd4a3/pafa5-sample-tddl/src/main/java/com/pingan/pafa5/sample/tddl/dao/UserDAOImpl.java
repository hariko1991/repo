package com.pingan.pafa5.sample.tddl.dao;

import org.springframework.stereotype.Component;

import com.paic.pafa.biz.dao.BaseDAO;
import com.pingan.pafa5.sample.tddl.dto.UserDTO;

@Component
public class UserDAOImpl  extends BaseDAO  implements UserDAO {

	public boolean add(UserDTO sampleDTO){
		 this._insert("user.add", sampleDTO); 
		 return true;
	}

	public boolean delById(Integer id) {
		return this._delete("user.delById", id)!=0;
	}
	
	public UserDTO getById(Integer id){
		return (UserDTO)this._getObject("user.getById", id);
	}

	@Override
	public boolean updateName(Integer id, String newName) {
		UserDTO temp=new UserDTO();
		temp.setId(id);
		temp.setName(newName);
		return this._update("user.updateName", temp)!=0;
	}
	
	
}
