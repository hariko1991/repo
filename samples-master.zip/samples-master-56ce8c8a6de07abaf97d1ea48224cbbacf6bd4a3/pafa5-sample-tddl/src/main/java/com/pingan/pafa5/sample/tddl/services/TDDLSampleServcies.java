package com.pingan.pafa5.sample.tddl.services;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.ModelMap;

import com.alibaba.fastjson.JSON;
import com.pingan.pafa5.sample.tddl.dao.UserDAO;
import com.pingan.pafa5.sample.tddl.dto.UserDTO;


@Component
public class TDDLSampleServcies {

	private Log logger=LogFactory.getLog(this.getClass());
	
	@Autowired
	private UserDAO userDAO;
	
	
	public ModelMap test() {
		testAdd();
		testGetById();
		testUpdate();
		testDelById();
		return null;
	}


	public void testAdd(){
		UserDTO dto=JSON.parseObject("{name:'name',age:'18',remark:'kdkdllslsl',birthday:'1980-08-08'}",UserDTO.class);
		for(int i=0;i<100;i++){
			dto.setId(i);
			Assert.assertTrue(userDAO.add(dto));
		}
	}
	
	
	public void testGetById(){
		for(int i=0;i<100;i++){
			logger.info("getById="+userDAO.getById(i));
		}
	}
	
	public void testUpdate(){
		Assert.assertTrue(userDAO.updateName(10, "nangua"));
		Assert.assertEquals(userDAO.getById(10).getName(),"nangua");;
	}
	
	
	public void testDelById(){
		for(int i=0;i<100;i++){
			Assert.assertTrue(userDAO.delById(i));
		}
	}


	public UserDAO getUserDAO() {
		return userDAO;
	}


	public void setUserDAO(UserDAO userDAO) {
		this.userDAO = userDAO;
	}
	
}
