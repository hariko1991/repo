
CREATE DATABASE `tddl_sample_1` /*!40100 DEFAULT CHARACTER SET utf8 */;
use  `tddl_sample_1;

CREATE TABLE `t_user_0` (
  `id` int(11) NOT NULL,
  `name` varchar(32) default NULL,
  `age` int(20) default NULL,
  `remark` varchar(2000) default NULL,
  `birthday` datetime default NULL,
  `sync_version` int(11) default '1',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `t_user_1` (
  `id` int(11) NOT NULL,
  `name` varchar(32) default NULL,
  `age` int(20) default NULL,
  `remark` varchar(2000) default NULL,
  `birthday` datetime default NULL,
  `sync_version` int(11) default '1',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE DATABASE `tddl_sample_2` /*!40100 DEFAULT CHARACTER SET utf8 */;
use  `tddl_sample_2;

CREATE TABLE `t_user_2` (
  `id` int(11) NOT NULL,
  `name` varchar(32) default NULL,
  `age` int(20) default NULL,
  `remark` varchar(2000) default NULL,
  `birthday` datetime default NULL,
  `sync_version` int(11) default '1',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

CREATE TABLE `t_user_3` (
  `id` int(11) NOT NULL,
  `name` varchar(32) default NULL,
  `age` int(20) default NULL,
  `remark` varchar(2000) default NULL,
  `birthday` datetime default NULL,
  `sync_version` int(11) default '1',
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
