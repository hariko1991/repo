package com.pingan.pafa5.sample.dao;

import java.util.List;

import com.pingan.pafa5.sample.dao.model.UserModel;
import com.pingan.pafa5.sample.dao.mybatis.BaseMapper;

public interface UserDao extends BaseMapper {
	void insertUser(UserModel user);
	
	UserModel getUser(String userId);
	
	List<UserModel> getAll();
	
	void updateUser(UserModel user);
	
	void deleteUser(String userId);
}
