package com.pingan.pafa5.sample.dao.mybatis;

public interface BaseMapper {

}
