package com.pingan.pafa5.sample.dao;

import javax.sql.DataSource;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="sample-mybatis")
public class DDLTests extends BaseSARTest {
	
	@Autowired
	private DataSource dataSource;

	@Test
	public void testADdd() throws Exception
	{
		dataSource.getConnection().createStatement()
			.execute("create table t_user(id varchar(20),username varchar(20) ,nickname varchar(20),sex varchar(20),age int)");
	} 
	

	
}
