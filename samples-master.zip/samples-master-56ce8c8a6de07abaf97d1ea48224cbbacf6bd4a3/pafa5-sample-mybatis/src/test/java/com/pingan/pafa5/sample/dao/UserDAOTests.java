package com.pingan.pafa5.sample.dao;

import java.util.List;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa5.sample.dao.model.UserModel;

@SARContextConfiguration(sarList="sample-mybatis")
public class UserDAOTests extends BaseSARTest {
	

	
	@Autowired
	private UserDao userDao;

	@Test
	public void testADdd() throws Exception
	{
		UserModel user = new UserModel();
		user.setId("7");
		//
		user.setUsername("houshangzhi377");
		user.setNickname("xuanying");
		user.setAge(27);
		user.setSex(1);
		userDao.insertUser(user);
		System.out.println("add complete.");
	} 
	
	@Test
	public void testSelect() throws Exception
	{

		List<UserModel> list = userDao.getAll();
		
		if(list != null && list.size() > 0)
		{
			for (UserModel userModel : list) 
			{
				System.out.println(userModel);
			}
		}
	}
	
	@Test
	public void testGetUser() throws Exception
	{
		UserModel u = userDao.getUser("7");
		System.out.println(u);
	}
	
	@Test
	public void testUpdate() throws Exception
	{
		UserModel user = new UserModel();
		user.setId("7");
		user.setUsername("houshangzhi377");
		user.setNickname("xuanying777777");
		user.setAge(27);
		user.setSex(1);
		userDao.updateUser(user);
		System.out.println("update success.");
		
		UserModel u = userDao.getUser("7");
		System.out.println(u);
	}
	
	@Test
	public void testDelete() throws Exception
	{
		userDao.deleteUser("7");
		
		System.out.println("delete success.");
		
		List<UserModel> list = userDao.getAll();
		
		if(list != null && list.size() > 0)
		{
			for (UserModel userModel : list)
			{
				System.out.println(userModel);
			}
		}
	}
	
	
}
