package com.pingan.pafa5.sample.redis;

import java.util.Map;

import javax.annotation.Resource;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="sample-redis")
public class RedisMapTests  extends BaseSARTest{

	
	@Resource(name="sample_globalMap")
	private Map<String,Object> redisMap;
	
	@Test
	public void test(){
		redisMap.put("id_2", new UserDTO("nangua",32));
		redisMap.put("id_3", "nangua");
		redisMap.put("id_4", 1);
		logger.info("name="+((UserDTO)redisMap.get("id_2")).getName());
		logger.info("name="+redisMap.get("id_3"));
		logger.info("name="+((Integer)redisMap.get("id_4")));
	}
}
