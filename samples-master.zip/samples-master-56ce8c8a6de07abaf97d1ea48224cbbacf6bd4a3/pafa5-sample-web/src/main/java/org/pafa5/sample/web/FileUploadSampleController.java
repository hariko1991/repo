package org.pafa5.sample.web;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;
@Controller
public class FileUploadSampleController extends BaseController {

    @ResponseBody
    @RequestMapping("/sample-web/upload")
    public ResponseModel upload(@RequestParam("file")CommonsMultipartFile file) {
        if (logger.isInfoEnabled()) {
            logger.info("name=" + file.getOriginalFilename()
            			+" and size="+file.getSize());
        }
        String msg = "Hello," + file.getOriginalFilename();
        ResponseModel model = new ResponseModel();
        model.put("message", msg);
        return model;
    }

}
