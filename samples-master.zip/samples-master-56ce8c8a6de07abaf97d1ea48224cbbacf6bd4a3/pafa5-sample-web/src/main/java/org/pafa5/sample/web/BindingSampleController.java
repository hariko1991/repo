package org.pafa5.sample.web;

import org.pafa5.sample.web.form.AddStudentForm;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.validator.annotation.Valid;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;

@Controller
public class BindingSampleController extends BaseController {

    @ResponseBody
    @RequestMapping("/sample-web/bind")
    public ResponseModel doBind(@Valid AddStudentForm form) {
        if (logger.isInfoEnabled()) {
            logger.info("name=" + form.getName());
        }
        String msg = "Hello," + form.getName();
        ResponseModel model = new ResponseModel();
        model.put("message", msg);
        return model;
    }

}
