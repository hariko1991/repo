package org.pafa5.sample.web;

import com.pingan.pafa.papp.sar.annotations.SAR;

@SAR(webEnable=true,webPatterns= {"/sample-web/**"})
public interface SARBoot {

}
