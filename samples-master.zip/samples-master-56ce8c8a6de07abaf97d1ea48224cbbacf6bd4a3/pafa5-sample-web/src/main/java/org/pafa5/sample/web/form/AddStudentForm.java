package org.pafa5.sample.web.form;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.paic.pafa.validator.annotation.VDate;
import com.paic.pafa.validator.annotation.VEnum;
import com.paic.pafa.validator.annotation.VLength;
import com.paic.pafa.validator.annotation.VNotEmpty;
import com.paic.pafa.validator.annotation.VNumber;
import com.paic.pafa.validator.annotation.VRegex;

public class AddStudentForm {
	
	
	@VNotEmpty(message="姓名不能为空")
	@VRegex(value="^[a-zA-Z\\\\d\\\\s]*$",message="姓名格式错误")
	@VLength(min=2,max=16,message="姓名格式错误，由2到16个字符组成！")
	private  String name;

	@VNumber(min=18,max=100,message="年龄不对")
	private  int age;
	
	@VEnum(value={"M","F"},message="年龄不对")
	private  String gender;
	
	@VDate(max="{-10y}",message="生日不对")
	@DateTimeFormat(pattern="yyyy-MM-dd")
	private Date birthday;
	
	
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}
	
	
}
