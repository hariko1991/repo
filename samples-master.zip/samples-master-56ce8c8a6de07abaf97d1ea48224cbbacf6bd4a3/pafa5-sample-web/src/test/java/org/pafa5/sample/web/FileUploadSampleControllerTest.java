package org.pafa5.sample.web;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpException;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.junit.Assert;
import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarName= "sample-web",protocols="jetty")
public class FileUploadSampleControllerTest extends BaseSARTest {
	
	@Test
	public void testUpload() throws Exception{
		String url="http://127.0.0.1:8080/sample-web/upload";
		File f=new File(FileUploadSampleControllerTest.class.getResource(FileUploadSampleControllerTest.class.getSimpleName()+".class").toURI());
		System.out.println("f="+f.getAbsolutePath());
		FileInputStream fis=new FileInputStream(f);
		String result=upload(url,"test.class","application/octet-stream",fis);
		System.err.println("result="+result);
		Assert.assertEquals(this.toMap(result).get("responseCode"), "0");
	}

	
	public  String upload(String url,String fileName,String contentType,InputStream input){
		CloseableHttpClient httpClient =HttpClients.createDefault();
		CloseableHttpResponse response=null;
		try {
			HttpPost request = new HttpPost(url);
			MultipartEntityBuilder builder=MultipartEntityBuilder.create();
			builder.addBinaryBody("file",input,ContentType.parse(contentType), fileName);
			HttpEntity entity =builder.build();
			request.setEntity(entity);
			//
			 response = httpClient.execute(request);
			StatusLine status = response.getStatusLine();
			if (status != null && status.getStatusCode() >= 300) {
				throw new HttpException(
						"Did not receive successful HTTP response: status code = "
								+ status.getStatusCode()
								+ ", status message = ["
								+ status.getReasonPhrase() + "]");
			}
			InputStream is = (response == null || response.getEntity() == null ? null : response.getEntity().getContent());
			String json=null;
			if (is != null) {
				try{
					json=IOUtils.toString(is, "UTF8");
				}finally{
					is.close();
				}
			}
			if(json==null || json.length()<3){
				throw new HttpException("http response content be null.");
			}
			return json;
		}catch(Exception ex){
			System.err.println("Http client upload file="+fileName+"error,cause:"+ex.getMessage());
			ex.printStackTrace(System.err);
		}finally{
			if(response!=null)
				try {
					response.close();
				} catch (IOException e) {
				}
		}
		return null;
	      
	}
}
