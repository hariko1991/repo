package org.pafa5.sample.web;


import org.junit.Assert;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.ui.ModelMap;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarName= "sample-web")
public class BindingSampleControllerTest extends BaseSARTest {

    @Test
    public void testHello() throws Exception {
    	MockHttpServletRequest request=this.createMockRequest("/sample-web/bind");
    	ModelMap params=new ModelMap();
		params.put("name", "zhangsan");
		params.put("age", "18");
		params.put("gender", "M");
		params.put("birthday", "2001-01-02");
		
		String json=this.toJson(params);
		logger.info("params="+json);
		this.forJSONParams(request, json);
		//
        String result =
                this.handleWebRequest(request,
                        this.createMockResponse());

        logger.info(result);
        Assert.assertEquals(this.toMap(result).get("responseCode"), "0");
    }
    
    @Test
    public void testHello2() throws Exception {
    	MockHttpServletRequest request=this.createMockRequest("/sample-web/bind");
    	ModelMap params=new ModelMap();
		params.put("name", "zhangsan");
		params.put("age", "10");
		params.put("gender", "M");
		params.put("birthday", "2001-01-02");
		
		String json=this.toJson(params);
		logger.info("params="+json);
		this.forJSONParams(request, json);
		//
        String result =
                this.handleWebRequest(request,
                        this.createMockResponse());
        logger.info(result);
        Assert.assertEquals(this.toMap(result).get("responseCode"), "900502");
        Assert.assertEquals(this.toMap(result).get("responseMsg"), "年龄不对");
        
    }
    
    @Test
    public void testHello3() throws Exception {
    	MockHttpServletRequest request=this.createMockRequest("/sample-web/bind");
    	ModelMap params=new ModelMap();
		params.put("name", "zhangsan");
		params.put("age", "a");
		params.put("gender", "M");
		params.put("birthday", "2001-01-02");
		
		String json=this.toJson(params);
		logger.info("params="+json);
		this.forJSONParams(request, json);
		//
        String result =
                this.handleWebRequest(request,
                        this.createMockResponse());
        logger.info(result);
        Assert.assertEquals(this.toMap(result).get("responseCode"), "900103");
    }

}
