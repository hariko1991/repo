package org.pafa5.sample.web;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;


@SARContextConfiguration(sarName= "pafa5-sample-web", protocols = "jetty")
public class Pafa5TestRunner extends BaseSARTest {


    @Test
    public void run() throws Throwable {
        System.in.read();
    }

}
