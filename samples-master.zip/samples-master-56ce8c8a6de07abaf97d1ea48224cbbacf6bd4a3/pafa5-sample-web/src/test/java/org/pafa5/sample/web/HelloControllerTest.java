package org.pafa5.sample.web;


import org.junit.Assert;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.ui.ModelMap;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarName= "sample-web")
public class HelloControllerTest extends BaseSARTest {

    @Test
    public void testHello() throws Exception {
    	MockHttpServletRequest request=this.createMockRequest("/sample-web/say-hello");
    	ModelMap params=new ModelMap();
		params.put("name", "zhangsan");
		String json=this.toJson(params);
		logger.info("params="+json);
		this.forJSONParams(request, json);
		//
        String result =
                this.handleWebRequest(request,
                        this.createMockResponse());

        logger.info(result);
        Assert.assertEquals(this.toMap(result).get("responseCode"), "0");
    }

}
