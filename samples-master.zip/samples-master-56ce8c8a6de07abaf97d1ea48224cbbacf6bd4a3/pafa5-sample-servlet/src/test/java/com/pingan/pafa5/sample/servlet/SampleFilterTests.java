package com.pingan.pafa5.sample.servlet;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="sample-servlet")
public class SampleFilterTests  extends BaseSARTest{

	@Test
	public void test2() throws Exception{
		String result=this.handleWebRequest(this.createMockRequest("/filter/hello.do"
				, "name=nangua")
				,this.createMockResponse());
		logger.info(result);
	}
	
	
	@Test
	public void test1() throws Exception{
		String result=this.handleWebRequest(this.createMockRequest("/final-sample/test"
				, "name=nangua")
				,this.createMockResponse());
		logger.info(result);
	}
	
}
