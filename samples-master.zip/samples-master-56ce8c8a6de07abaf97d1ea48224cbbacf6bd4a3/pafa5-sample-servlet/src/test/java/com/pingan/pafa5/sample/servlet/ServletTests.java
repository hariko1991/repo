package com.pingan.pafa5.sample.servlet;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="sample-servlet")
public class ServletTests  extends BaseSARTest{

	@Test
	public void test2() throws Exception{
		String result=this.handleWebRequest(this.createMockRequest("/test-servlet")
				,this.createMockResponse());
		logger.info(result);
	}
	
}
