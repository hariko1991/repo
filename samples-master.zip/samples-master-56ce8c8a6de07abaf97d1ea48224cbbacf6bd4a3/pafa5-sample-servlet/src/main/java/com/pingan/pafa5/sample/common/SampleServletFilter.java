package com.pingan.pafa5.sample.common;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

public class SampleServletFilter implements Filter{
	
	private Log logger=LogFactory.getLog(this.getClass());

	@Override
	public void destroy() {
		
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		if(logger.isInfoEnabled()){
			logger.info("---SampleServletFilter:begin...");
		}
		chain.doFilter(request, response);
		if(logger.isInfoEnabled()){
			logger.info("---SampleServletFilter:end...");
		}
	}

	@Override
	public void init(FilterConfig config) throws ServletException {
		if(logger.isInfoEnabled()){
			logger.info("---Init params:"+config.getInitParameter("xxxFile"));
		}
	}

}
