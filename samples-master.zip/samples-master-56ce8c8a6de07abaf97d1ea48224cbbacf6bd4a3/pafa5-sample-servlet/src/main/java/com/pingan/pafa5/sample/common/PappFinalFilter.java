package com.pingan.pafa5.sample.common;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.pingan.pafa.papp.web.filter.AbstractWebFilter;

public class PappFinalFilter extends AbstractWebFilter {

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		if(logger.isInfoEnabled()){
			logger.info("----------PappFinalFilter:begin...");
		}
		response.setContentType("text/html");
		response.setCharacterEncoding("UTF8");
		response.getWriter().write("<b><font color='red' >hello</font></b>");
		response.getWriter().flush();
		logger.info("----------PappFinalFilter:end...");
	}

}
