package com.pingan.pafa5.sample.servlet;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import org.springframework.stereotype.Component;

import com.pingan.pafa.papp.web.filter.AbstractWebFilter;

@Component
public class SarSampleFilter extends AbstractWebFilter{
	
	public SarSampleFilter(){
		//过滤所有请求
		this.setPattern("/**");
		//执行优先级，越小优先级越高,可为负值
		this.setOrder(100);
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		if(logger.isInfoEnabled()){
			logger.info("----------SarSampleFilter:begin...");
		}
		chain.doFilter(request, response);
		logger.info("----------SarSampleFilter:end...");
	}

}
