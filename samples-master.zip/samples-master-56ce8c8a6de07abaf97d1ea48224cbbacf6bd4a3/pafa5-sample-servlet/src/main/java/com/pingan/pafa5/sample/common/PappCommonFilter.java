package com.pingan.pafa5.sample.common;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;

import com.pingan.pafa.papp.web.filter.AbstractWebFilter;

public class PappCommonFilter extends AbstractWebFilter {

	@Override
	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		if(logger.isInfoEnabled()){
			logger.info("----------PappSampleFilter:begin...");
		}
		chain.doFilter(request, response);
		logger.info("----------PappSampleFilter:end...");
	}

}
