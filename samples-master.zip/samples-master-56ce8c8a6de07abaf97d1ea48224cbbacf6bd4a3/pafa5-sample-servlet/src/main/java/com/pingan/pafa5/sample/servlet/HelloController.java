package com.pingan.pafa5.sample.servlet;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;

@Controller
public class HelloController extends BaseController{
	
	@RequestMapping("/filter/hello.do")
	@ResponseBody
	public  Object hello(@RequestParam("name")String name){
		if(logger.isInfoEnabled()){
			logger.info("name=abc");
		}
		ResponseModel model=new ResponseModel();
		model.put("msg", "hello,"+name);
		return model;
	}
}
