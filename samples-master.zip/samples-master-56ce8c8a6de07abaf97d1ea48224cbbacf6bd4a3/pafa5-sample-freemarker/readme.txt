
说明：
启动SARTests.java 然后浏览器里面输入http://localhost:9000/hello 
端口号9000可以在jetty.properties中自行更改