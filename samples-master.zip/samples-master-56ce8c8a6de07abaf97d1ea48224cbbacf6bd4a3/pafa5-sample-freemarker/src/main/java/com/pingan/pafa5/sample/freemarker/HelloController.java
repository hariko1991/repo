package com.pingan.pafa5.sample.freemarker;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.paic.pafa.web.BaseController;

@Controller
public class HelloController extends BaseController {

	@RequestMapping("/hello")
	public ModelAndView dohello() {
		ModelAndView mv = new ModelAndView("hello.ftl");
		mv.addObject("title", "FreeMarker实例");
		mv.addObject("content", "测试FreeMarKer 需要去掉@ResponseBody ");
		return mv;
	}

}
