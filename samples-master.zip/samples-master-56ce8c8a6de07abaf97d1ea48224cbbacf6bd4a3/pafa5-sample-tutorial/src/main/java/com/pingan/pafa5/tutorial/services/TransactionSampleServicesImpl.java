package com.pingan.pafa5.tutorial.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa5.tutorial.dao.StuDAO;

@Component("transactionSampleServices")
public class TransactionSampleServicesImpl  extends BaseServices implements TransactionSampleServices {

	@Autowired
	private StuDAO stuDAO;
	

	@Transactional
	@ESA("nanguakdkkd.ss")
	public void sample(){
		stuDAO.add("1111", "test");
		logger.info(stuDAO.updateName("1111", "abc"));
		/*if(1==1){
			this._throwEx("rollback");
		}*/
		logger.info(stuDAO.delById("1111"));
	}

	public StuDAO getStuDAO() {
		return stuDAO;
	}

	public void setStuDAO(StuDAO stuDAO) {
		this.stuDAO = stuDAO;
	}
	
	
}
