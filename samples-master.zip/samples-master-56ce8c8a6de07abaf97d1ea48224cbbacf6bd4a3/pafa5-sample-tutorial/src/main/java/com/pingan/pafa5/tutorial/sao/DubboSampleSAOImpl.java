package com.pingan.pafa5.tutorial.sao;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;

@Component
public class DubboSampleSAOImpl implements DubboSampleSAO{
	
	private Log logger=LogFactory.getLog(this.getClass());

	@ActionClient(name="pafa5_tutorial.esa_mock_sample")
	private IServiceClient esa_mock_sample;
	
	
	@Override
	public void sample() {
		ServiceResults result=esa_mock_sample.invoke(ServiceParams.newInstance().set("name", "zhangsan"));
		logger.info("result="+result);
	}
	


	public Log getLogger() {
		return logger;
	}


	public void setLogger(Log logger) {
		this.logger = logger;
	}



	public IServiceClient getEsa_mock_sample() {
		return esa_mock_sample;
	}



	public void setEsa_mock_sample(IServiceClient esa_mock_sample) {
		this.esa_mock_sample = esa_mock_sample;
	}


	


	
}
