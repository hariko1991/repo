package com.pingan.pafa5.tutorial.web;

import com.pingan.pafa5.tutorial.dtos.StuDTO;

public class StudentQueryVO {
	
	private String stuId;

	private String stuName;
	
	public StudentQueryVO(StuDTO stu){
		this.stuId=stu.getId();
		this.stuName=stu.getName();
	}

	public String getStuName() {
		return stuName;
	}

	public void setStuName(String stuName) {
		this.stuName = stuName;
	}

	public String getStuId() {
		return stuId;
	}

	public void setStuId(String stuId) {
		this.stuId = stuId;
	}
	
	
	
}
