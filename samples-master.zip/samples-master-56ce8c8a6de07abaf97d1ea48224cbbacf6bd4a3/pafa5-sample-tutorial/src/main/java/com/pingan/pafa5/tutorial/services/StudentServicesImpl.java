package com.pingan.pafa5.tutorial.services;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa5.tutorial.dao.StuDAO;
import com.pingan.pafa5.tutorial.dtos.StuDTO;

@Component
public class StudentServicesImpl  extends BaseServices  implements StudentServices{
	

	@Autowired
	private StuDAO stuDAO;
	
	
	private Random random=new Random();
	
	@Override
	public StuDTO queryStu(String stuId) {
		if(stuId==null){
			this._throwEx("stuId is null.");
		}
		StuDTO stu=stuDAO.getById(stuId);
		if(stu==null){
			this._throwEx("stu<"+stuId+"> not exists.");
		}
		return stu;
	}

	@Override
	public String addStu(StuDTO stu) {
		if(stu.getId()!=null){
			this._throwEx("stu id is not null");
		}
		String id=""+Math.abs(random.nextInt());
		stuDAO.add(id, stu.getName());
		return id;
	}

	public StuDAO getStuDAO() {
		return stuDAO;
	}

	public void setStuDAO(StuDAO stuDAO) {
		this.stuDAO = stuDAO;
	}
	
	
	
}
