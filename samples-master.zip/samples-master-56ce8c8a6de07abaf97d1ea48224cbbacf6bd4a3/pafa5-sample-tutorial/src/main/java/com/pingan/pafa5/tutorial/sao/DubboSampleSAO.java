package com.pingan.pafa5.tutorial.sao;

public interface DubboSampleSAO {

	void sample();
	
}
