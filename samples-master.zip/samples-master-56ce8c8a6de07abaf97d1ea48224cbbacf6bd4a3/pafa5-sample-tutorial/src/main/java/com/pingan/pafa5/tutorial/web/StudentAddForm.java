package com.pingan.pafa5.tutorial.web;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.paic.pafa.validator.annotation.VDate;
import com.paic.pafa.validator.annotation.VEnum;
import com.paic.pafa.validator.annotation.VLength;
import com.paic.pafa.validator.annotation.VNotEmpty;
import com.paic.pafa.validator.annotation.VNumber;
import com.paic.pafa.validator.annotation.VRegex;

public class StudentAddForm {

	@VNotEmpty
	@VLength(min=4,max=20)
	@VRegex("^\\w*$")
	private String name;
	
	@VNotEmpty
	@VEnum({"0","1","2"})
	private Integer gender;
	
	@VNotEmpty
	@DateTimeFormat(pattern="yyyy-MM-dd")
	@VDate(max="{-1d}")//不能小于-1D
	private Date birthday;
	
	@VNumber(min=0,max=100)
	private Integer age;
	
	

	public String getName() {
		
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getGender() {
		return gender;
	}

	public void setGender(Integer gender) {
		this.gender = gender;
	}

	public Date getBirthday() {
		return birthday;
	}

	public void setBirthday(Date birthday) {
		this.birthday = birthday;
	}

	public Integer getAge() {
		return age;
	}

	public void setAge(Integer age) {
		this.age = age;
	}
	
	
	
	
}
