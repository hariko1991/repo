package com.pingan.pafa5.tutorial.services;

import org.springframework.stereotype.Component;



@Component
public class DemoServicesImpl implements DemoServices {
	
	
	    @Override  
	    public String sayHello(String name) {
	        return "Hello " + name;
	    }
	    
	    
}
