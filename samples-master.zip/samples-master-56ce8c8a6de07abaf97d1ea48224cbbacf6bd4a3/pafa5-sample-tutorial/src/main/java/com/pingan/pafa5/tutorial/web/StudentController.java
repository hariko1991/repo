package com.pingan.pafa5.tutorial.web;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.validator.annotation.Valid;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa5.tutorial.dtos.StuDTO;
import com.pingan.pafa5.tutorial.services.StudentServices;

@Controller
public class StudentController extends BaseController  {
	
	@Autowired
	private StudentServices studentServices;

	
	@RequestMapping("/sample-tutorial/addStudent")
	@ResponseBody
	public  ModelMap addStudent(@Valid @ModelAttribute StudentAddForm form){
		if(logger.isInfoEnabled()){
			logger.info("name="+form.getName());
		}
		StuDTO stu=new StuDTO();
		stu.setName(form.getName());
		//
		String stuId=studentServices.addStu(stu);
		ModelMap model=new ModelMap();
		model.put("responseCode", "0");
		model.put("stuId",stuId);
		return model;
	}
	
	@RequestMapping("/sample-tutorial/queryStu")
	@ResponseBody
	public  ModelMap queryStu(@Valid @ModelAttribute StudentQueryForm form){
		if(logger.isInfoEnabled()){
			logger.info("stuId="+form.getStuId());
		}
		//
		StuDTO stu=studentServices.queryStu(String.valueOf(form.getStuId()));
		ModelMap model=new ModelMap();
		model.put("responseCode", "0");
		model.put("stu",new StudentQueryVO(stu));
		return model;
	}


	public StudentServices getStudentServices() {
		return studentServices;
	}


	public void setStudentServices(StudentServices studentServices) {
		this.studentServices = studentServices;
	}
	
	
}
