package com.pingan.pafa5.tutorial.services;

public interface DemoServices {  
	 String sayHello(String name);
}  
