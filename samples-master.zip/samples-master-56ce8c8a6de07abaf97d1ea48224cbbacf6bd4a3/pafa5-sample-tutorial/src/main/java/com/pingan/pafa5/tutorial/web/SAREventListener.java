package com.pingan.pafa5.tutorial.web;

import org.springframework.context.ApplicationListener;
import org.springframework.stereotype.Component;

import com.pingan.pafa.papp.sar.event.SAREvent;

@Component
public class SAREventListener implements ApplicationListener<SAREvent> {

	@Override
	public void onApplicationEvent(SAREvent event) {
		System.err.println("------------------"+event.getClass().getName());
	}

}
