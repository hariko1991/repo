package com.pingan.pafa5.tutorial.dao;

import org.springframework.stereotype.Component;

import com.paic.pafa.biz.dao.BaseDAO;
import com.pingan.pafa5.tutorial.dtos.StuDTO;

@Component
public class StuDAOImpl  extends BaseDAO  implements StuDAO {

	public boolean add(String id,String name ){
		 this._insert("stu.add", 
				 this.createParamsMap().set("id", id).set("name", name)); 
		 return true;
	}

	public boolean delById(String id) {
		return this._delete("stu.delById", id)!=0;
	}
	
	
	@Override
	public StuDTO getById(String id) {
		return this._getDTO("stu.getById", id);
	}

	@Override
	public boolean updateName(String id, String newName) {
		
		return this._update("stu.updateName",  this.createParamsMap().set("id", id).set("name", newName))!=0;
	}
	
	
}
