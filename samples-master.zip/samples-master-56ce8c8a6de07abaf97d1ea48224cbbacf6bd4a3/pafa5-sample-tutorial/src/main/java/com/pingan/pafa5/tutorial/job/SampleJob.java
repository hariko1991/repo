package com.pingan.pafa5.tutorial.job;

import java.util.Random;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.paic.pafa.biz.services.BaseServices;

@Component
public class SampleJob extends BaseServices  {

	
	private Random random=new Random();
	
	private int counter;
	
	
	@Scheduled(cron="*/5 * * * * ?")
	public void execute() throws Exception{
		int i=random.nextInt(2)+1000;
		Thread.sleep(i);
		//job执行代码
		logger.info("Job running,counter="+(counter++)+",sleep="+i);
	}





	
	
	
	
	
}
