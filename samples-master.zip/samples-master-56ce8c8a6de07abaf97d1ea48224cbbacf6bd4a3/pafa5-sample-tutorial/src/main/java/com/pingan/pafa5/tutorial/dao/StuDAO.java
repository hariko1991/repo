package com.pingan.pafa5.tutorial.dao;

import com.pingan.pafa5.tutorial.dtos.StuDTO;


public interface StuDAO {
	
	boolean add(String id,String name);

	boolean delById(String id);
	
	boolean updateName(String id,String newName);
	
	StuDTO getById(String id);
}
