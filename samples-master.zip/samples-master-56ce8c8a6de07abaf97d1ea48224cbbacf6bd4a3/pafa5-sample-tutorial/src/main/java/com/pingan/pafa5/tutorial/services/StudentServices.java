package com.pingan.pafa5.tutorial.services;

import com.pingan.pafa5.tutorial.dtos.StuDTO;


public interface StudentServices {

	
	 String addStu(StuDTO stu);
	 
	 StuDTO queryStu(String stuId);
	
}
