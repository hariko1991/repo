package com.pingan.pafa5.tutorial.web;

import com.paic.pafa.validator.annotation.VNotEmpty;
import com.paic.pafa.validator.annotation.VNumber;

public class StudentQueryForm {

	@VNotEmpty
	@VNumber(min=0)
	private Integer stuId;

	public Integer getStuId() {
		return stuId;
	}

	public void setStuId(Integer stuId) {
		this.stuId = stuId;
	}
	
	
	
}
