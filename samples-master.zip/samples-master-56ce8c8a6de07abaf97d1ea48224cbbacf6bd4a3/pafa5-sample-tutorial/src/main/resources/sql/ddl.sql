 CREATE TABLE `pafa5_sample_stu` (
  `id` varchar(10) default NULL,
  `name` varchar(30) default NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;