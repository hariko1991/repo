package com.pingan.pafa5.tutorial.sao;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa5.tutorial.sao.DubboSampleSAO;

@SARContextConfiguration(sarList="sample-tutorial")
public class DubboSampleSAOTests extends BaseSARTest{

	@Autowired
	private DubboSampleSAO $;
	
	@Test
	public void test() throws Exception{
		$.sample();
	}
	
}
