package com.pingan.pafa5.tutorial.sao;

import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;

import com.pingan.pafa.papp.ESA;

@Component
public class esa_mock_sample {
	
	private Log logger=LogFactory.getLog(this.getClass());

	@ESA("pafa5_tutorial.esa_mock_sample")
	public ModelMap mock(Map params){
		logger.info("params="+params);
		ModelMap model=new ModelMap();
		model.put("resultCode", "0");
		model.put("message", "hello,"+params.get("name"));
		return model;
	}
	
	
}
