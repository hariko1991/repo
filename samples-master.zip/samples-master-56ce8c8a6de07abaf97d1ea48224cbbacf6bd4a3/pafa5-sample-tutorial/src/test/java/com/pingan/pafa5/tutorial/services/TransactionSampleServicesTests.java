package com.pingan.pafa5.tutorial.services;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa5.tutorial.services.TransactionSampleServices;


@SARContextConfiguration(sarList="sample-tutorial")
public class TransactionSampleServicesTests extends BaseSARTest{

	
	
	@Autowired
	@Qualifier("transactionSampleServices")
	private TransactionSampleServices transactionSampleServices;

	@Test
	public void test() throws Exception{
		logger.info("$="+transactionSampleServices);
		transactionSampleServices.sample();
	}

}
