package com.pingan.pafa5.tutorial.web;

import java.util.Map;

import org.junit.Assert;
import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;


@SARContextConfiguration(sarList="sample-tutorial")
public class StudentControllerTests  extends BaseSARTest{


	@Test
	public void test1() throws Exception{
		String result=this.handleWebRequest(this.createMockRequest("/sample-tutorial/addStudent"
				, "name=zhangsan&gender=1&birthday=1999-09-09&age=88")
				,this.createMockResponse());
		logger.info(result);
		String stuId=(String)this.toMap(result).get("stuId");
		Assert.assertNotNull(stuId);
		result=this.handleWebRequest(this.createMockRequest("/sample-tutorial/queryStu","stuId="+stuId), this.createMockResponse());
		logger.info(result);
		String stuName=(String)((Map)this.toMap(result).get("stu")).get("stuName");
		Assert.assertEquals(stuName, "zhangsan");
	}
	
}
