package com.pingan.pafa5.tutorial;

import javax.sql.DataSource;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="sample-tutorial")
public class DDLTests extends BaseSARTest {
	
	@Autowired
	private DataSource dataSource;
	@Test
	public void testADdd() throws Exception
	{
		dataSource.getConnection().createStatement()
			.execute("create table pafa5_sample_stu(id varchar(20),name varchar(20))");
	} 
	

	
}
