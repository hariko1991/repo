package com.pingan.pafa5.support.mq.kafka;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa5.support.mq.IMessageProducer;

@SARContextConfiguration(sarList = "mq_kafka_test")
public class KafkaMQTests extends BaseSARTest  {

	@Autowired
	private IMessageProducer messageProducer;
	
	
	@Test
	public void test() throws Exception{
		for(int i=0;i<10;i++)
		messageProducer.send(new InfoDTO("hello,nangua"+i));
		
		logger.error("yyyyyy");
		System.in.read();
	}
}
