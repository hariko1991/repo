/**
d * Oct 14, 2016
 */
package com.pingan.pafa5.kafka.test;

import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;

import org.apache.kafka.clients.producer.RecordMetadata;
import org.junit.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.kafka.core.ProducerTemplate;
import com.pingan.pafa.kafka.producer.MessageRecord;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList = "kafka_sample")
public class KafkaTests extends BaseSARTest {

	
	protected  Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Autowired
	protected ProducerTemplate<String, String> producerTemplate;

	protected void sendMessage(String topic, int size) throws InterruptedException, ExecutionException {
		for (int i = 0; i < size; i++) {
			Future<RecordMetadata> future = producerTemplate.send(
					new MessageRecord<String, String>(topic, "hello world " + i));
			RecordMetadata metadata = future.get();
			logger.info("Message send successfully! partition:{} topic:{}",
					new Object[] { metadata.partition(), metadata.topic() });
		}
	}
	
	@Test
	public void sendMessageTest() throws Exception {
		int count = 10;
		// while (true) {
		long start = System.currentTimeMillis();
		this.sendMessage("testq", count);
		System.out.println("------------------- sent successfully , it takes"
				+ (System.currentTimeMillis() - start));
		System.in.read();

	}

	
}
