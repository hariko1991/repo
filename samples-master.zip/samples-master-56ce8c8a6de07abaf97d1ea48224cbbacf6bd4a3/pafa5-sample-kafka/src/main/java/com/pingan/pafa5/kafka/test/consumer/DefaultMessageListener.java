/**
 * Nov 1, 2016
 */
package com.pingan.pafa5.kafka.test.consumer;

import java.util.concurrent.atomic.AtomicInteger;

import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.apache.kafka.clients.consumer.ConsumerRecords;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.pingan.pafa.kafka.listener.CommitCallback;
import com.pingan.pafa.kafka.listener.MessageListener;

/**
 * @Author LUOPENG441
 * @Version 1.0.0
 */

public class DefaultMessageListener implements MessageListener<String, String> {
	private  Logger logger = LoggerFactory.getLogger(this.getClass());
	private AtomicInteger count = new AtomicInteger(0);

	public DefaultMessageListener() {
	}

	/**无序高并发消费,无需提交回执*/
	public void onMessage(ConsumerRecords<String, String> records) {
		printRecords(records);
	}

	private void printRecords(ConsumerRecords<String, String> records) {
		for (ConsumerRecord<String, String> record : records) {
			logger.info("===========================threadId={} offset = {}, key = {}, value = {}, checksum={}",
					new Object[] { Thread.currentThread().getId(), record.offset(), record.key(), record.value(), record.checksum() });
			count.incrementAndGet();
		}
		logger.info("------------------------------------threadId={} {} records are consumed!", Thread.currentThread().getId(), count.get());
	}

	/***
	 * 顺序消费，手工提交回执
	 */
	public void onMessage(ConsumerRecords<String, String> records, CommitCallback<String, String> callback) {
		printRecords(records);
		callback.commit(records);
	}
}
