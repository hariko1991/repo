package com.pingan.pafa5.support.mq.kafka;

public class InfoDTO implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = -8509487085207532385L;
	
	public InfoDTO() {}
	
	public InfoDTO(String name) {
		this.name=name;
	}

	private String name;
	
	private int age;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}
	
	
}
