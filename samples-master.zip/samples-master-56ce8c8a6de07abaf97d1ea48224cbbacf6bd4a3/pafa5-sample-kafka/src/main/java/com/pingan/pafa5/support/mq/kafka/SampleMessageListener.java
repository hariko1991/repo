package com.pingan.pafa5.support.mq.kafka;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Component;

import com.pingan.pafa5.support.mq.ConsumeContext;
import com.pingan.pafa5.support.mq.IMessageListener;

@Component("sampleMessageListener")
public class SampleMessageListener implements IMessageListener<InfoDTO> {

	private final  Logger logger = LoggerFactory.getLogger(this.getClass());
	
	@Override
	public void consumeMessage(InfoDTO msg, ConsumeContext context) throws Exception {
		logger.info("-----------------------------------------------------Msg="+msg.getName());
		System.err.println("-----------------------------------------------------Msg="+msg.getName());
	}

}
