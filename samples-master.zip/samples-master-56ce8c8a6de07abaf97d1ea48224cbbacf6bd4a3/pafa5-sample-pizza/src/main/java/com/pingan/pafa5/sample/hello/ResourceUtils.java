package com.pingan.pafa5.sample.hello;

import java.util.Properties;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Component;

@Component
public class ResourceUtils {
	
	@Value("pizza:/sar/sample-pizza.properties")
	private Resource propertiesResource;

	public Properties getProperties() throws Exception{
		Properties properties=new Properties();
		properties.load(propertiesResource.getInputStream());
		return properties;
	}

	public void setPropertiesResource(Resource propertiesResource) {
		this.propertiesResource = propertiesResource;
	}

}
