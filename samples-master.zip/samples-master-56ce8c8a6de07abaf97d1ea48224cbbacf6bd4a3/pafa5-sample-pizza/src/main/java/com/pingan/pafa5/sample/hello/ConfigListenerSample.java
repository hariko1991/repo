package com.pingan.pafa5.sample.hello;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

import org.springframework.stereotype.Component;

import com.pingan.pafa.pizza.classloader.PizzaURL;
import com.pingan.pafa.pizza.spring.PizzaResourceHandler;
import com.pingan.pafa.pizza.spring.annotation.PizzaResourceConfig;

@Component
public class ConfigListenerSample implements PizzaResourceHandler {
	
	private static final String PIZZA_URL="pizza:/sar/sample-pizza.properties";
	

	private volatile Properties properties=new Properties();
	
	public void init() throws Exception {
		PizzaURL pizzaURL=PizzaURL.valueOf(PIZZA_URL);
		properties.load(pizzaURL.getInputStream());
	}
	
	public String getProperty(String name) {
		return properties.getProperty(name);
	}
	
	@PizzaResourceConfig(pizzaURL=PIZZA_URL)
	public void handlePizzaResource(PizzaURL pizzaURL, InputStream content) throws Exception {
		Properties properties=new Properties();
		try {
			properties.load(content);
			this.properties=properties;
		} catch (IOException e) {
		}
	}

}
