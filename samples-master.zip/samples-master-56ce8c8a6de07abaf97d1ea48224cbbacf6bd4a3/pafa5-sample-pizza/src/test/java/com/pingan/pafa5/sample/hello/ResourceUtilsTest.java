package com.pingan.pafa5.sample.hello;

import java.util.Properties;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;


@SARContextConfiguration(sarList= "sample-pizza")
public class ResourceUtilsTest extends BaseSARTest {

	@Autowired
	private ResourceUtils ResourceUtils;

	@Test
	public void test() throws Exception{
		Properties props=ResourceUtils.getProperties();
		logger.info("properties="+props);
		Assert.assertEquals("nangua", props.get("name"));
	}
}
