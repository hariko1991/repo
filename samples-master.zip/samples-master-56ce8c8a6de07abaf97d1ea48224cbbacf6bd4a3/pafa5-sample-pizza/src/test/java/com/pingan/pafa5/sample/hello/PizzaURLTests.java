package com.pingan.pafa5.sample.hello;

import java.net.URL;
import java.util.Properties;

import com.pingan.pafa.pizza.classloader.PizzaURL;

public class PizzaURLTests {

	public static void main(String args[]) throws Exception{
		PizzaURL pizzaURL=PizzaURL.valueOf("pizza:/sar/sample-pizza.properties");
		URL javaURL=pizzaURL.toJavaURL();
		Properties properties=new Properties();
		properties.load(pizzaURL.getInputStream());
		System.err.println("javaURL="+javaURL);
		System.err.println("name="+properties.getProperty("name"));
	}
}
