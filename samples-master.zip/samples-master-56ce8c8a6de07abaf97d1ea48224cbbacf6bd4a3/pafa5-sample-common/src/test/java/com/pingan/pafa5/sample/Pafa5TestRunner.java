package com.pingan.pafa5.sample;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;


@SARContextConfiguration(plugins = "jetty")
public class Pafa5TestRunner extends BaseSARTest {


    @Test
    public void run() throws Throwable {
        System.in.read();
    }
 
}
