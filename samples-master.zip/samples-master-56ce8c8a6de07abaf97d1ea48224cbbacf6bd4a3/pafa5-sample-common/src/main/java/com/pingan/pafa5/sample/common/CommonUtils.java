package com.pingan.pafa5.sample.common;

public class CommonUtils {

}
