package com.pingan.pafa5.sample.wesession;

import javax.servlet.http.Cookie;

import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="wesession-tests" ,plugins="jetty")
public class LoginControllerTest extends BaseSARTest {

	private static String sessionId;
	   
    private String cookieName="wesession-sample";
    
   @Test
    public void testLogin() throws Exception{
        MockHttpServletResponse response=this.createMockResponse();
        String result=this.handleWebRequest(this.createMockRequest("/login.do","name=nangua")
                ,response);
        Cookie cookie=response.getCookie(cookieName);
        sessionId=cookie.getValue();
        logger.info("sessionId="+sessionId);
        logger.info(result);
    }
   
    @Test
    public void test1() throws Exception{
        String result=this.handleWebRequest(this.createMockRequest("/sample1.do")
                ,this.createMockResponse());
        logger.info(result);   
    }
   
 
   
    @Test
    public void test3() throws Exception{
        MockHttpServletRequest mockRequest=this.createMockRequest("/sample1.do");
        mockRequest.addHeader(cookieName, sessionId);
        String result=this.handleWebRequest(mockRequest
                ,this.createMockResponse());
        logger.info(result);
    }
    
    @Test
    public void test4() throws Exception{
        MockHttpServletRequest mockRequest=this.createMockRequest("/sample2.do");
        mockRequest.addHeader(cookieName, sessionId);
        String result=this.handleWebRequest(mockRequest
                ,this.createMockResponse());
        logger.info(result);
    }
}
