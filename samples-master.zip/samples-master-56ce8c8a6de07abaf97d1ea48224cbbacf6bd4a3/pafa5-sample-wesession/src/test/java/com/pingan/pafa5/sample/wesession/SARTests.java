package com.pingan.pafa5.sample.wesession;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="wesession-tests",plugins="jetty,dubbo")
public class SARTests extends BaseSARTest{

	@Test
	public void iz() throws Throwable{
		System.in.read();
	}
	
}
