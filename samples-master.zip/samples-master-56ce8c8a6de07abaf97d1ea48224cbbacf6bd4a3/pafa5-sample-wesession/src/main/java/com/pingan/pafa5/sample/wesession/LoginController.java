package com.pingan.pafa5.sample.wesession;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.stp.wesso.WeSSO;

@Controller
public final class LoginController extends BaseController {

	@Resource(name="wesso")
    private WeSSO wesso;
	
	@ResponseBody
    @RequestMapping("/login.do")
    public  ResponseModel login(@RequestParam("name") String name,
    		HttpServletRequest request, HttpServletResponse response){
        if(logger.isInfoEnabled()){
            logger.info("name="+name);
        }
        wesso.login(request, response, name);
        ResponseModel model=new ResponseModel();
        model.put("responseCode", "0");
        model.put("user", name);
        return model;
    }
	
	
	@ResponseBody
    @RequestMapping("/logout.do")
    public  ResponseModel login(HttpServletRequest request, HttpServletResponse response){
        wesso.logout(request, response);
        return new ResponseModel();
    }
   
 
    public WeSSO getWesso() {
        return wesso;
    }
 
    public void setWesso(WeSSO wesso) {
        this.wesso = wesso;
    }
}
