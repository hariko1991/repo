package com.pingan.pafa5.sample.wesession;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.esa.ResponseModel;

@Controller
public final class UserController extends BaseController {

	@ResponseBody
    @RequestMapping("/setName")
    public  ResponseModel setName(@RequestParam("name") String name,HttpSession session){
       
        session.setAttribute("name", name);
        if(logger.isInfoEnabled()){
            logger.info("name="+name);
            logger.info("sessionId="+session.getId());
        }
        ResponseModel model=new ResponseModel();
        model.put("responseCode", "0");
        return model;
    }
 
    @ResponseBody
    @RequestMapping("/getName")
    public  ResponseModel getName(HttpSession session){
        String name=(String)session.getAttribute("name");
        if(logger.isInfoEnabled()){
            logger.info("name="+name);
            logger.info("sessionId="+session.getId());
        }
        String msg="Hello,"+name;
        ResponseModel model=new ResponseModel();
        model.put("responseCode", "0");
        model.put("message", msg);
        return model;
    }

}
