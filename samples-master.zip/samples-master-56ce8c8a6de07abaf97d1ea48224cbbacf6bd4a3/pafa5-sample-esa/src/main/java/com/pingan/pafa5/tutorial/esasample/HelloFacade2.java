package com.pingan.pafa5.tutorial.esasample;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestParam;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.papp.esa.ResponseModel;

@Controller
public class HelloFacade2 extends BaseController{
	

	@ESA(name="${sar.name}.hello2")
	public  ResponseModel hello(@RequestParam("name") String name,
			@ModelAttribute ModelMap model
			,@ModelAttribute HelloParams params) throws Exception{
		name=(String)model.get("name");
		if(logger.isInfoEnabled()){
			logger.info("name="+params.getName());
		}
		String msg="Hello,"+params.getName();
		ResponseModel result =new ResponseModel();  
		result.put("message", msg);
		return result;
	}
}
