package com.pingan.pafa5.tutorial.esasample;

import com.pingan.pafa.papp.sar.annotations.SAR;

@SAR(webEnable=true)
public interface SARBoot {

}
