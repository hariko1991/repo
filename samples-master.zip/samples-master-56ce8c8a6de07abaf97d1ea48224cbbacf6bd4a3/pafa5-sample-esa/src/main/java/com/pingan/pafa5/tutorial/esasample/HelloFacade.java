package com.pingan.pafa5.tutorial.esasample;

import java.util.Random;

import org.springframework.stereotype.Controller;

import com.paic.pafa.validator.annotation.Valid;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.papp.esa.ResponseModel;

@Controller
public class HelloFacade extends BaseController{
	
	private Random random=new Random();

	@ESA(name="${sar.name}.hello" /*服务接口ID，推荐:{组件名}.{操作/动作}*/
			,mock="return {'responseCode':'1119999','responseMsg':'系统错误请重试!'}"/*服务降级策略*/)
	public  ResponseModel hello(@Valid HelloParams params) throws Exception{
		int sleepTime=200+random.nextInt(2000);
		if(logger.isInfoEnabled()){
			logger.info("name="+params.getName()+",sleepTime="+sleepTime);
		}
		Thread.sleep(sleepTime);
		String msg="Hello,"+params.getName();
		ResponseModel result =new ResponseModel();  
		result.put("message", msg);
		return result;
	}
}
