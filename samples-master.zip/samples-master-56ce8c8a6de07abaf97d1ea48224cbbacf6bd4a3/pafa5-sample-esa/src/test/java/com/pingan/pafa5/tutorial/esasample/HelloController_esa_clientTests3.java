package com.pingan.pafa5.tutorial.esasample;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.pingan.pafa.papp.esa.client.ActionClientFactory;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;



@SARContextConfiguration(sarList="sample-esa")
public class HelloController_esa_clientTests3 extends BaseSARTest{

	
	@Autowired
	ActionClientFactory actionClientFactory;
	
	@Test
	public void test() throws Exception{
		ServiceResults result=actionClientFactory.get("sample-esa.hello").invoke(
				ServiceParams.newInstance()
				.set("name", "nangua"));
		logger.info("result="+result);
		Assert.assertEquals("Hello,nangua",result.getString("message"));
		Assert.assertEquals("0",result.getString("responseCode"));
	}

	public ActionClientFactory getActionClientFactory() {
		return actionClientFactory;
	}

	public void setActionClientFactory(ActionClientFactory actionClientFactory) {
		this.actionClientFactory = actionClientFactory;
	}

	
}
