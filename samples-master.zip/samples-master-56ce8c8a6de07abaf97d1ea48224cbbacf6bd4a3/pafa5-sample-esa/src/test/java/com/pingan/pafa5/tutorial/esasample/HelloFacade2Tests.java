package com.pingan.pafa5.tutorial.esasample;

import org.junit.Assert;
import org.junit.Test;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="sample-esa")
public class HelloFacade2Tests extends BaseSARTest{

	@ActionClient(name="sample-esa.hello2")
	private IServiceClient helloClient;
	
	@Test
	public void test() throws Exception{
		ServiceResults result=helloClient.invoke(
				ServiceParams.newInstance().set("name", "nangua"));
		logger.info("result="+result);
		Assert.assertEquals("Hello,nangua",result.getString("message"));
		Assert.assertEquals("0",result.getString("responseCode"));
	}

	public IServiceClient getHelloClient() {
		return helloClient;
	}

	public void setHelloClient(IServiceClient helloClient) {
		this.helloClient = helloClient;
	}
}
