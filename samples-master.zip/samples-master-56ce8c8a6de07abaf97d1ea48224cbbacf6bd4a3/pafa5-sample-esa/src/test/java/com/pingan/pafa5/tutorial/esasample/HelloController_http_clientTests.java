package com.pingan.pafa5.tutorial.esasample;

import java.util.Map;
import java.util.UUID;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClients;
import org.junit.Test;

import com.alibaba.fastjson.JSONObject;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="sample-esa",protocols="jetty")
public class HelloController_http_clientTests  extends BaseSARTest{

	
	

	@Test
	public void test2() throws Exception{
		//服务ID
		String esaName="sample-esa.hello";
		//请求地址
		String url="http://127.0.0.1:81/esa/";
		HttpPost post=new HttpPost(url+esaName);
		//设置入参
		JSONObject json=new JSONObject();
		json.put("name", "zhangsan");
		json.put("clientId", UUID.randomUUID().toString().replaceAll("-", ""));
		String httpRequestBody=json.toJSONString();
		//构建json字符串
		StringEntity entity=new StringEntity(httpRequestBody);
		//设置content-type及字符编码
		entity.setContentType("application/json;charset=UTF8");
		post.setEntity(entity);
		//----
		HttpClient httpClient=HttpClients.createDefault();
		HttpResponse response=httpClient.execute(post);
		//发起请求，取得结果
		String  responseJson=IOUtils.toString(response.getEntity().getContent());
		Map result=JSONObject.parseObject(responseJson,Map.class);
		//----------------------------------------------------------
		System.out.println(result.get("responseCode"));
		System.out.println(result.get("message"));
	}
	
}
