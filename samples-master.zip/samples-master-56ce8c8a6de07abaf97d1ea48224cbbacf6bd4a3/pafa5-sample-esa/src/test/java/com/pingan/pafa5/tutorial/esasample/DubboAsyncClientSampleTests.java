package com.pingan.pafa5.tutorial.esasample;

import java.util.concurrent.TimeUnit;

import org.junit.Test;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.paic.pafa.appclient.dubbo.DubboAsyncFuture;
import com.paic.pafa.appclient.dubbo.DubboAsyncHandler;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;



@SARContextConfiguration(sarList="sample-esa")
public class DubboAsyncClientSampleTests extends BaseSARTest{
	
	static {
		System.setProperty("dubbo.service.sample-esa.hello.scope", "remote");
	}
	
	@ActionClient(name="sample-esa.hello")
	private IServiceClient hellowordHandler;
	
	
	/***
	 * 1、同步调用
	 */
	@Test
	public void testInvoke(){
		Object result=hellowordHandler.invoke(ServiceParams.newInstance().set("name", "zhangsan0"));
		logger.info("======================>time_0="+result);
	}
	
	/***
	 * 2、异步通知调用
	 * {@link DubboAsyncHandler#asyncInvoke(IServiceClient, ServiceParams)}
	 */
	@Test
	public void testAysncCall() throws Exception{
		long t1=System.currentTimeMillis();
		DubboAsyncHandler.asyncInvoke(hellowordHandler, ServiceParams.newInstance().set("name", "zhangsan1"));
		//异步通知调用无结果返回
		logger.info("======================>time_a="+(System.currentTimeMillis()-t1));
		//System.in.read();
	}
	
	

	/***
	 * 3、并行调用
	 * {@link DubboAsyncHandler#concurrentInvoke(IServiceClient, ServiceParams)}
	 */
	@Test
	public void testConcurrent() throws Exception{
		long t1=System.currentTimeMillis();
		//并发调用，获得Future
		DubboAsyncFuture futureA=DubboAsyncHandler.concurrentInvoke(hellowordHandler
				,ServiceParams.newInstance().set("name", "zhangsan"));
		DubboAsyncFuture futureB=DubboAsyncHandler.concurrentInvoke(hellowordHandler
				,ServiceParams.newInstance().set("name", "lisi"));
		//通过Future取得结果，如果请求A=5秒，请求B=3秒，则串行调用共需8秒，并行调用共需5秒
		logger.info("result1="+futureA.getResult());//此处线程会wait
		logger.info("result2="+futureB.getResult());
		logger.info("======================>time_b="+(System.currentTimeMillis()-t1));
	} 


	/***
	 * 4、同转异支持：异步限定等待时间调用
	 * {@link DubboAsyncHandler#concurrentInvoke(IServiceClient, ServiceParams)}
	 * {@link DubboAsyncFuture#getResultAllowTimeout}
	 * 
	 */
	@Test
	public void testConcurrent2() throws Exception{
		long t1=System.currentTimeMillis();
		DubboAsyncFuture future=DubboAsyncHandler.concurrentInvoke(hellowordHandler
				,ServiceParams.newInstance().set("name", "zhangsan4"));
		//当超过1秒钟，服务端没有成功响应,result3=null
		logger.info("result3="+future.getResultAllowTimeout(10000,TimeUnit.MILLISECONDS));
		logger.info("======================>time_c="+(System.currentTimeMillis()-t1));
		
	} 

	
	
}
