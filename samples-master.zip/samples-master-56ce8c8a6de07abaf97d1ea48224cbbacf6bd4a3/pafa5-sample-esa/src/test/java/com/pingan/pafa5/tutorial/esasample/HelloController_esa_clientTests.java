package com.pingan.pafa5.tutorial.esasample;

import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;


@SARContextConfiguration(sarList="sample-esa")
public class HelloController_esa_clientTests extends BaseSARTest{
	
	static {
		System.setProperty("dubbo.service.sample-esa.hello.scope", "remote");
		System.setProperty("dubbo.service.sample-esa.hello.actives", "2");//客户端并发限制
		System.setProperty("dubbo.service.sample-esa.hello.executes", "3");//服务端并发限制
		System.setProperty("dubbo.service.sample-esa.hello.timeout", "1000");//客户端超时控制
	} 

	@ActionClient(name="sample-esa.hello")
	private IServiceClient client;
	
	@Test
	public void test() throws Exception{
		List<Thread> ts=new ArrayList<Thread>();
		for(int i=0;i<5;i++){
			ts.add(new Thread(new Runnable() {
				
				@Override
				public void run() {
					ServiceResults result=client.invoke(
							ServiceParams.newInstance()
							.set("name", "nangua")
							);
					
					logger.info("result==========="+result);
				}
			}));
		
		}
		for(int i=0;i<3;i++){
			ts.get(i).start();
		}
		ts.get(3).start();
		System.in.read();
	}
}
