package com.pingan.pafa5.tutorial.esasample;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;


@SARContextConfiguration(sarList= "sample-esa", plugins = "jetty",appName="pafa5-samples")
public class Pafa5TestRunner extends BaseSARTest {


    @Test
    public void run() throws Throwable {
        System.in.read();
    }

}
