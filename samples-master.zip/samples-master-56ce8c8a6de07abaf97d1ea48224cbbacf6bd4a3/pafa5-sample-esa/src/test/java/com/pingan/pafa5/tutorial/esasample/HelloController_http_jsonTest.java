package com.pingan.pafa5.tutorial.esasample;

import java.util.HashMap;
import java.util.Map;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;

import com.alibaba.fastjson.JSONObject;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="sample-esa")
public class HelloController_http_jsonTest  extends BaseSARTest{

	
	

	@Test
	public void test2() throws Exception{
		MockHttpServletRequest request=this.createMockRequest("/esa/sample-esa.hello");
		Map params=new HashMap();
		params.put("name", "zhangsan");
		String json=this.toJson(params);
		logger.info("json="+json);
		this.forJSONParams(request, json);
		String resultString=this.handleWebRequest(request
				,this.createMockResponse());
		logger.info(resultString);
		JSONObject result=JSONObject.parseObject(resultString);
		Assert.assertEquals("Hello,zhangsan",result.getString("message"));
		Assert.assertEquals("0",result.getString("responseCode"));
	}
	
	
	
}
