package com.pingan.pafa5.sample.helloworld;

import com.pingan.pafa.papp.sar.annotations.SAR;

@SAR(webEnable=true,webPatterns="/hello/**")
public interface SARBoot {

}
