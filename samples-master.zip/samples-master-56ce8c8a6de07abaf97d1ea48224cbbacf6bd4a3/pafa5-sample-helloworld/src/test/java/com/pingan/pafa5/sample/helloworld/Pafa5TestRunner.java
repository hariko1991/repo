package com.pingan.pafa5.sample.helloworld;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;


@SARContextConfiguration(sarList= "sample-helloworld", plugins = "jetty")
public class Pafa5TestRunner extends BaseSARTest {


    @Test
    public void run() throws Throwable {
        System.in.read();
    }

}
