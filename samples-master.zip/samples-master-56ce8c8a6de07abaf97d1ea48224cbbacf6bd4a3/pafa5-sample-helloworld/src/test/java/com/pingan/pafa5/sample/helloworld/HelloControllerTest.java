package com.pingan.pafa5.sample.helloworld;


import org.junit.Assert;
import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList= "sample-helloworld")
public class HelloControllerTest extends BaseSARTest {

    @Test
    public void testHello() throws Exception {
        String result =
                this.handleWebRequest(
                        this.createMockRequest("/hello/say", "name=nangua"),
                        this.createMockResponse());

        logger.info(result);
        Assert.assertEquals(this.toMap(result).get("responseCode"), "0");
    }
}
