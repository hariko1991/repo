package com.pingan.pafa5.sample.rocketmq;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa5.support.mq.IMessageProducer;

@Controller
public class HelloController extends BaseController {
	
	@Autowired
	private IMessageProducer messageProducer;
	

    @ResponseBody
    @ESA("${sar.name}.say")
    @RequestMapping("/hello/say")
    public ResponseModel hello(@RequestParam("name") String name) {
        if (logger.isInfoEnabled()) {
            logger.info("name=" + name);
        }
        String msg = "Hello," + name;
		messageProducer.send(new InfoDTO(name));
		messageProducer.send(new InfoDTO(name+",kkkkk"));
        ResponseModel model = new ResponseModel();
        model.put("message", msg);
        return model;
    }


	public IMessageProducer getMessageProducer() {
		return messageProducer;
	}


	public void setMessageProducer(IMessageProducer messageProducer) {
		this.messageProducer = messageProducer;
	}

	
    
}
