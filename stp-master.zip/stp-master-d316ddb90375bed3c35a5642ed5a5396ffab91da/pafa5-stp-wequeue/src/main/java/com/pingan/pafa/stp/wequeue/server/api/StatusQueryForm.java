package com.pingan.pafa.stp.wequeue.server.api;

public class StatusQueryForm {

	private String queueName;
	
	
	private boolean doClear=false;
	
	private boolean includeReceiptQueue=true;



	public String getQueueName() {
		return queueName;
	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	public boolean isDoClear() {
		return doClear;
	}

	public void setDoClear(boolean doClear) {
		this.doClear = doClear;
	}

	public boolean isIncludeReceiptQueue() {
		return includeReceiptQueue;
	}

	public void setIncludeReceiptQueue(boolean includeReceiptQueue) {
		this.includeReceiptQueue = includeReceiptQueue;
	}
	
	
}
