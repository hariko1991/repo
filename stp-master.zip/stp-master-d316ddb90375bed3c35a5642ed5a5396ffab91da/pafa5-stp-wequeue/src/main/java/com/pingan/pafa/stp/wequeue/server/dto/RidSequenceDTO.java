package com.pingan.pafa.stp.wequeue.server.dto;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection="WequeueRidSequence")
public class RidSequenceDTO {
	
	@Id
	private String namespace;

	private Long ridSequence;

	public Long getRidSequence() {
		return ridSequence;
	}

	public void setRidSequence(Long ridSequence) {
		this.ridSequence = ridSequence;
	}

	public String getNamespace() {
		return namespace;
	}

	public void setNamespace(String namespace) {
		this.namespace = namespace;
	}

	

	
	
	
}
