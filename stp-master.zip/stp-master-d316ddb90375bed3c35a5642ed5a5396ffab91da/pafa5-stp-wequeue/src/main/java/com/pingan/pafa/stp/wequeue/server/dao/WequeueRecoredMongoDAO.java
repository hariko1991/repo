package com.pingan.pafa.stp.wequeue.server.dao;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa.stp.wequeue.server.dto.QueueRecoredDTO;

@Component("wequeueRecoredMongoDAO")
public class WequeueRecoredMongoDAO extends BaseMongoDAO<QueueRecoredDTO> implements WequeueRecoredDAO {
	
	@Autowired
	private WequeueRecoredMongoArchiveDAO archiveDAO;
	
	public void add(QueueRecoredDTO recoredDTO){
		recoredDTO.setCreatedDate(new Date());
		recoredDTO.setRealRetryTimes(0);
		recoredDTO.setArchivedFlag(0);
		recoredDTO.setStatus(QueueRecoredDTO.STATUS_NOTICED);
		recoredDTO.setCreatedBy(recoredDTO.getPublisherName());
		this._add(recoredDTO);
	}

	public boolean archiveLock(Long rid){
		return this._update(this.where("rid").is(rid).and("archivedFlag").is(0)
				, Update.update("archivedFlag", 1));
	}
	
	public boolean delByRid(Long rid){
		return this._removeById(rid);
	}
	
	public boolean archive(Long rid){
		QueueRecoredDTO dto=this._getById(rid);
		if(dto!=null){
			try{
				archiveDAO.archive(dto);
				return true;
			}catch(Exception ex){
				logger.error("Rid="+rid+" archived failured,cause:"+ex.getMessage(),ex);
			}
		}
		return false;
	}
	
	
	public Long getLeastRid(){
		List<Map> result=this._groupBy(this.groupOperation().min("rid").as("minRid"), null, Map.class);
		if(result!=null && result.size()>0){
			return Long.valueOf(result.get(0).get("minRid").toString());
		}else{
			return 0l;
		}
	}
	
	public boolean receipt(QueueRecoredDTO recoredDTO){ 
		return this._update(this.where("rid").is(recoredDTO.getRid()).and("status").in(0,1),
				Update.update("receiptIP", recoredDTO.getReceiptIP())
				.set("receiptDate", recoredDTO.getReceiptDate())
				.set("status", recoredDTO.getStatus())
				.set("receiptResponseCode", recoredDTO.getReceiptResponseCode())
				.set("receiptResponseMsg", recoredDTO.getReceiptResponseMsg())
				.set("clientReceiptDate", recoredDTO.getClientReceiptDate())
				.set("updatedDate", new Date())
				.set("updatedBy", "system")
		);
	}
	
	public boolean retry(Long rid,String queueName){
		return this._update(this.where("rid").is(rid).and("queueName").is(queueName).and("status").in(0,1),
				Update.update("lastRetryDate", new Date())
				.set("status", QueueRecoredDTO.STATUS_RETRIED)
				.inc("realRetryTimes", 1)
				.set("updatedDate", new Date())
				.set("updatedBy", "system")
		);
	}
	
	public List<QueueRecoredDTO> listByLeastRid(Long leastRid,int size,Integer archivedFlag){
		return this._list(this.where("rid").gte(leastRid).and("archivedFlag").is(archivedFlag),0,size);
	}
	
	
}
