package com.pingan.pafa.stp.wequeue.server.services;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.stp.wequeue.server.dao.RidGeneratorDAO;

@Component("ridServices")
public class RidServicesImpl extends BaseServices  implements RidServices{
	

	@Autowired
	@Qualifier("mongoRidGeneratorDAO")
	private RidGeneratorDAO ridGeneratorDAO;
	
	@Override
	@Transactional
	public long generateRid() {
		ridGeneratorDAO.add();
		long rid= ridGeneratorDAO.getLastId();
		if(this.logger.isInfoEnabled()){
			logger.info("Generator rid="+rid);
		}
		return rid;
	}
	
	

	@Override
	public boolean clearRids() {
		long maxId=ridGeneratorDAO.getMaxId();
		int rows=ridGeneratorDAO.clear(maxId);
		logger.info("Clear rids success,maxRid="+maxId+",count="+rows);
		return true;
	}



	@Override
	@Transactional
	public List<Long> generateRids(int size) {
		if(size<1){
			throw new java.lang.IllegalArgumentException("size<"+size+"> error");
		}
		List<Long> list=new ArrayList<Long>(size);
		for(int i=0;i<size;i++){
			ridGeneratorDAO.add();
			long rid= ridGeneratorDAO.getLastId();
			if(this.logger.isDebugEnabled()){
				logger.debug("Generator rid="+rid);
			}
			list.add(rid);
		}
		if(this.logger.isInfoEnabled()){
			logger.info("Generator rid list="+list);
		}
		
		
		
		return list;
	}



	public RidGeneratorDAO getRidGeneratorDAO() {
		return ridGeneratorDAO;
	}

	public void setRidGeneratorDAO(RidGeneratorDAO ridGeneratorDAO) {
		this.ridGeneratorDAO = ridGeneratorDAO;
	}

	
}
