package com.pingan.pafa.stp.wequeue.server;

import java.util.Set;

import com.pingan.pafa.redis.queue.RedisQueue;
import com.pingan.pafa.stp.wequeue.common.msg.WequeueConsumeMsg;
import com.pingan.pafa.stp.wequeue.common.msg.WequeuePushMsg;
import com.pingan.pafa.stp.wequeue.common.msg.WequeuePushResultMsg;
import com.pingan.pafa.stp.wequeue.common.msg.WequeueReceiptMsg;
import com.pingan.pafa.stp.wequeue.server.dto.WequeueConfigDTO;

public interface WequeueServer {

	WequeuePushResultMsg push(WequeuePushMsg msg);
	
	boolean retry(WequeuePushMsg msg);
	
	boolean receipt(WequeueReceiptMsg receiptMsg);
	
	RedisQueue<WequeueConsumeMsg> getQueue(String queueName);
	
	WequeueConfigDTO getQueueConfig(String queueName);
	
	WequeueConfigDTO getQueueConfig(String queueName,boolean required);
	
	 Set<String> getQueueNameSet();
}
