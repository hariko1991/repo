package com.pingan.pafa.stp.wequeue.server;

import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

import org.springframework.beans.FatalBeanException;

import com.pingan.pafa.redis.Redis;
import com.pingan.pafa.redis.queue.RedisQueue;
import com.pingan.pafa.stp.wequeue.common.msg.WequeueConsumeMsg;
import com.pingan.pafa.stp.wequeue.common.msg.WequeuePushMsg;
import com.pingan.pafa.stp.wequeue.server.config.WequeueConfigBean;
import com.pingan.pafa.stp.wequeue.server.dto.WequeueConfigDTO;

public class ConsumerRedisQueuesBean extends WequeueConfigBean{

	
	private Redis defRedis;
	
	private Map<String,RedisQueue<WequeueConsumeMsg>> listenersQueue=new ConcurrentHashMap<String, RedisQueue<WequeueConsumeMsg>>(128);


	public RedisQueue<WequeueConsumeMsg> getQueue(String queueName){
		RedisQueue<WequeueConsumeMsg> queue=listenersQueue.get(queueName);
		if(queue==null){
			queue=defRedis.loadQueue(queueName, WequeueConsumeMsg.class);
			listenersQueue.put(queueName, queue);
		}
		return queue;
	}
	
	public Set<String> getQueueNameSet(){
		Set<String> set= listenersQueue.keySet();
		return set;
	}
	
	protected void pushToRedisQueue(WequeueConfigDTO definition,WequeuePushMsg msg,boolean retryFlag){
		if(logger.isInfoEnabled()){
			logger.info("Push to  Queue <"+definition.getQueueName()+"> and rid=<"+msg.getRid()+">.");
		}
		RedisQueue<WequeueConsumeMsg> queue=getQueue(msg.getQueueName());
		//---------------------
		WequeueConsumeMsg consumeMsg=new WequeueConsumeMsg();
		consumeMsg.setQueueName(msg.getQueueName());
		consumeMsg.setBody(msg.getBody());
		consumeMsg.setRetryFlag(retryFlag);
		consumeMsg.setNoticeDate(System.currentTimeMillis());
		consumeMsg.setClientPushDate(msg.getClientPushDate());
		consumeMsg.setPublisherIp(msg.getPublisherIp());
		consumeMsg.setPublisherName(msg.getPublisherName());
		consumeMsg.setRid(msg.getRid());
		queue.push(consumeMsg);
		//----------------------------
	}
	
	

	@Override
	protected void onDestroy() throws Exception {
		
		listenersQueue.clear();
		listenersQueue=null;
	}

	@Override
	protected void init() throws Exception {
		super.init();
		if(defRedis==null){
			throw new FatalBeanException("defRedis required.");
		}
		if(logger.isInfoEnabled()){
			logger.info("defRedis="+defRedis);
		}
	}

	public Redis getDefRedis() {
		return defRedis;
	}

	public void setDefRedis(Redis defRedis) {
		this.defRedis = defRedis;
	}

	

	



	


	
	
	
	
}
