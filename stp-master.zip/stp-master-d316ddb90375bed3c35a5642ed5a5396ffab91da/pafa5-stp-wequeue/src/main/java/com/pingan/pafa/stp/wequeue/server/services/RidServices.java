package com.pingan.pafa.stp.wequeue.server.services;

import java.util.List;

public interface RidServices {

	long generateRid();
	
	List<Long> generateRids(int size);
	
	boolean clearRids();
}
