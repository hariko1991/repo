package com.pingan.pafa.stp.wequeue.server.job;

import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paic.pafa.biz.services.BaseServices;
import com.paic.pafa.job.TimerJob;
import com.pingan.pafa.redis.lock.RedisLock;
import com.pingan.pafa.stp.wequeue.server.dto.QueueRecoredDTO;
import com.pingan.pafa.stp.wequeue.server.services.WequeueServices;

@Component
public class ArchiveJob  extends BaseServices{

	@Autowired
	private WequeueServices wequeueServices;
	
	//批查询数量
	private int batchQuerySize=30;
	
	
	
	@Resource(name="retry_job_lock")
	private RedisLock lock;
	

	
	@TimerJob(maxConcurrent=1,repeatInterval="60000")
	public void execute()throws Exception{
		if(lock.tryLock()){
			try{
				doExecute();
			}finally{
				lock.unlock();
			}
		}
	}
	
	
	public void doExecute() throws Exception{
		Long leastRid=wequeueServices.getLeastRid();
		if(leastRid==null){
			logger.warn("********Data empty");
			return ;
		}
		
		List<QueueRecoredDTO> msgs=null;
		boolean continueFlag=true;
		while(continueFlag && (msgs=wequeueServices.listByLeastRid(leastRid,
				batchQuerySize,1))!=null  && msgs.size()>0){
			for(int i=0;i<msgs.size();i++){
				QueueRecoredDTO recored=msgs.get(i);
				//------------------------------------
				leastRid=recored.getRid()+1;
				boolean flag=wequeueServices.archive(recored.getQueueName(), recored.getRid());
				//------------------------
				if(logger.isInfoEnabled()){
					logger.info("Queue<"+recored.getQueueName()+"> rid="+recored.getRid()+" archived="+flag);
				}
				
			}
		}
	}
	
	
	
	

	public int getBatchQuerySize() {
		return batchQuerySize;
	}

	public void setBatchQuerySize(int batchQuerySize) {
		this.batchQuerySize = batchQuerySize;
	}





	public RedisLock getLock() {
		return lock;
	}


	public void setLock(RedisLock lock) {
		this.lock = lock;
	}


	
	
	
	
	
}
