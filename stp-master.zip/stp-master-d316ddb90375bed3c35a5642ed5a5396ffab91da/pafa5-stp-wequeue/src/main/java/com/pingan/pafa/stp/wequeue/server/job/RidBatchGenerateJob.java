package com.pingan.pafa.stp.wequeue.server.job;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paic.pafa.job.TimerJob;
import com.pingan.pafa.stp.wequeue.server.services.RidGenerator;

@Component
public class RidBatchGenerateJob {
	
	@Autowired
	private RidGenerator ridGenerator;
	
	@TimerJob(cronExpression="${job.ridBatchGen.cron}",maxConcurrent=1)
	public void exec() throws Exception{
		ridGenerator.batchGenerateJob();
	}

	public RidGenerator getRidGenerator() {
		return ridGenerator;
	}

	public void setRidGenerator(RidGenerator ridGenerator) {
		this.ridGenerator = ridGenerator;
	}

	
}
