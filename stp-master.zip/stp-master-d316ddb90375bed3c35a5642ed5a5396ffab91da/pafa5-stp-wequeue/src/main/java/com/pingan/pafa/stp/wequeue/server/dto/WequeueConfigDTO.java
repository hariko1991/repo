package com.pingan.pafa.stp.wequeue.server.dto;

import com.paic.pafa.biz.dto.BaseDTO;

/***
 * 
 * @author LIXINGNAN945
 *
 */
public class WequeueConfigDTO extends BaseDTO {
	
	public static final Integer STATUS_DEF=0;
	
	public static final Integer STATUS_STOP=1;
	
	/***/
	private static final long serialVersionUID = 1L;

	/**队列名*/
	private String queueName;
	
	
	/**队列拥有者,属主（组件名或系统名）*/
	private String ownerName;


	/**队列描述*/
	private String description;

	
	/**状态，1停止*/
	private Integer status;
	
	/**失败重试次数，0不重试*/
	private Integer retryTimes;
	
	/**重试间隔，单位：秒。0使用默认配置，默认10分钟(600秒)*/
	private Integer retryInterval;
	
	
	
	
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	
	
	
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getQueueName() {
		return queueName;
	}
	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	public Integer getRetryTimes() {
		return retryTimes;
	}
	public void setRetryTimes(Integer retryTimes) {
		this.retryTimes = retryTimes;
	}
	public Integer getRetryInterval() {
		return retryInterval;
	}
	public void setRetryInterval(Integer retryInterval) {
		this.retryInterval = retryInterval;
	}
	
	
}
