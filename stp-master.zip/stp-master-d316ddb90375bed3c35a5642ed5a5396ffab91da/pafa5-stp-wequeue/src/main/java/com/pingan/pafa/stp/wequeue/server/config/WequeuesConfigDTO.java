package com.pingan.pafa.stp.wequeue.server.config;

import java.util.List;

import com.pingan.pafa.stp.wequeue.server.dto.WequeueConfigDTO;


public class WequeuesConfigDTO {

	private List<WequeueConfigDTO> wequeues;

	public List<WequeueConfigDTO> getWequeues() {
		return wequeues;
	}

	public void setWequeues(List<WequeueConfigDTO> wequeues) {
		this.wequeues = wequeues;
	}

	public void setWequeue(List<WequeueConfigDTO> wequeues) {
		this.wequeues = wequeues;
	}
	
}
