package com.pingan.pafa.stp.wequeue.server.dao;

import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa.stp.wequeue.server.dto.RidSequenceDTO;

@Component("mongoRidGeneratorDAO")
public class RidGeneratorMongoDAO extends BaseMongoDAO<RidSequenceDTO>   implements RidGeneratorDAO{
	
	
	private static final long MIN_RID=10000000;
	
	
	@Override
	protected void init() throws Exception {
		if(this._getById("wequeueRid")==null){
			RidSequenceDTO dto=new RidSequenceDTO();
			dto.setNamespace("wequeueRid");
			dto.setRidSequence(MIN_RID);
			try{
				this._add(dto);
			}catch(Exception ex){
				//logger.error(ex.getMessage(),ex);
			}
		}
	}

	public void add(){
		
	}
	
	public long getLastId(){
		RidSequenceDTO id=this._getAndUpdate(this.where("namespace").is("wequeueRid")
				, Update.update("namespace","wequeueRid").inc("ridSequence", 1));
		return id.getRidSequence()+1;
	}
	
	public long getMaxId(){
		return this._get(this.where("namespace").is("wequeueRid")).getRidSequence();
	}
	
	public int clear(long maxId){
		return 0;
	}
	
	
}
