package com.pingan.pafa.stp.wequeue.server.dao;

import org.springframework.stereotype.Component;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa.stp.wequeue.server.dto.QueueRecoredDTO;

@Component
public class WequeueRecoredMongoArchiveDAO extends BaseMongoDAO<QueueRecoredDTO> {

	public WequeueRecoredMongoArchiveDAO(){
		this.setCollectionName("queueRecoredArchiveDTO");
	}
	
	public void archive(QueueRecoredDTO  dto){
		if(dto!=null){
			this._save(dto);
		}
	}
}
