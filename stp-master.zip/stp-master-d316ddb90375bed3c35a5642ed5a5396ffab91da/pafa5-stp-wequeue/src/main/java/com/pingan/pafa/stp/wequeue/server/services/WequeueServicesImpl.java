package com.pingan.pafa.stp.wequeue.server.services;

import java.util.Date;
import java.util.HashMap;
import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.stp.wequeue.common.msg.WequeuePushMsg;
import com.pingan.pafa.stp.wequeue.common.msg.WequeueReceiptMsg;
import com.pingan.pafa.stp.wequeue.server.dao.WequeueRecoredDAO;
import com.pingan.pafa.stp.wequeue.server.dto.QueueRecoredDTO;
import com.pingan.pafa.stp.wequeue.server.dto.WequeueConfigDTO;


@Component("eventServices")
public class WequeueServicesImpl extends BaseServices implements WequeueServices{
	
	protected Log logger=LogFactory.getLog(this.getClass());

	@Autowired
	@Qualifier("wequeueRecoredMongoDAO")
	private WequeueRecoredDAO wequeueRecoredDAO; 
	
	public boolean archiveLock(String queueName,Long rid){
		boolean flag=wequeueRecoredDAO.archiveLock(rid);
		logger.info("Queue<"+queueName+","+rid+"> archivedFlag="+flag);
		if(!flag){
			return false;
		}
		/*flag=wequeueRecoredDAO.archive(rid);
		if(flag){
			wequeueRecoredDAO.delByRid(rid);
			if(logger.isInfoEnabled()){
				logger.info("Queue<"+queueName+","+rid+"> archive="+flag);
			}
		}*/
		return flag;
	}

	
	@Transactional
	public boolean archive(String queueName,Long rid){
		boolean flag=wequeueRecoredDAO.archive(rid);
		if(flag){
			wequeueRecoredDAO.delByRid(rid);
			if(logger.isInfoEnabled()){
				logger.info("Queue<"+queueName+","+rid+"> archive="+flag);
			}
		}
		return flag;
	}
	
	public WequeuePushMsg toPushMsg(QueueRecoredDTO recored){
		WequeuePushMsg msg=new WequeuePushMsg();
		msg.setQueueName(recored.getQueueName());
		msg.setRid(recored.getRid());
		msg.setPublisherIp(recored.getPublisherIp());
		msg.setPublisherName(recored.getPublisherName());
		String json=recored.getJsonBody();
		//---------------------------------
		msg.setBody(JSONObject.parseObject(json, HashMap.class));
		Date date=recored.getClientPushDate();
		if(date!=null){
			msg.setClientPushDate(date.getTime());
		}
		return msg;
	}
	
	
	@Override
	public void addMsg(WequeuePushMsg msg,WequeueConfigDTO definition) {
		QueueRecoredDTO dto=new QueueRecoredDTO();
		dto.setQueueName(msg.getQueueName());
		//------------------------------------------------
		Object body=msg.getBody();
		if(body!=null){
			String jsonBody=JSONObject.toJSONString(body);
			if(logger.isInfoEnabled()){
				logger.info("JsonBody="+jsonBody);
			}
			dto.setJsonBody(jsonBody);
		}
		dto.setPublisherName(msg.getPublisherName());
		dto.setPublisherIp(msg.getPublisherIp());
		dto.setRid(msg.getRid());
		dto.setStatus(QueueRecoredDTO.STATUS_NOTICED);
		Long clientPushDate=msg.getClientPushDate();
		if(clientPushDate!=null){
			dto.setClientPushDate(new Date(clientPushDate));
		}
		//--------------
		dto.setCreatedBy(dto.getPublisherName());
		//----------
		dto.setMaxRetryTimes(definition.getRetryTimes());
		dto.setRetryInterval(definition.getRetryInterval());
		//------------
		wequeueRecoredDAO.add(dto);
		if(logger.isInfoEnabled()){
			logger.info("Recored for queue<"+msg.getQueueName()+"> success,rid="+msg.getRid());
		}
	}
	
	
	

	@Override
	public boolean receipt(WequeueReceiptMsg receiptMsg) {
		QueueRecoredDTO noticeDTO=new QueueRecoredDTO();
		noticeDTO.setQueueName(receiptMsg.getQueueName());
		noticeDTO.setRid(receiptMsg.getRid());
		noticeDTO.setReceiptDate(new Date());
		noticeDTO.setReceiptIP(receiptMsg.getReceiptClientIp());
		noticeDTO.setReceiptResponseCode(receiptMsg.getResponseCode());
		noticeDTO.setReceiptResponseMsg(receiptMsg.getResponseMsg());
		noticeDTO.setStatus(QueueRecoredDTO.STATUS_RECEIPTED);
		noticeDTO.setConsumerName(receiptMsg.getConsumerName());
		//
		if(receiptMsg.getClientReceiptDate()!=null){
			noticeDTO.setClientReceiptDate(new Date(receiptMsg.getClientReceiptDate()));
		}
		//--------------------------------------------------------
		Long rid=receiptMsg.getRid();
		String queueName=receiptMsg.getQueueName();
		boolean flag=wequeueRecoredDAO.receipt(noticeDTO);
		if(!flag){
			logger.warn("Notice recored status error: rid="+rid
					+",consumerName="+queueName);
		}
		return true;
	}


	@Override
	public Long getLeastRid() {
		Long rid= wequeueRecoredDAO.getLeastRid();
		if(logger.isInfoEnabled()){
			logger.info("getLeastRid="+rid);
		}
		return rid;
	}
 
	@Override
	public List<QueueRecoredDTO> listByLeastRid(Long leastRid, int size,Integer archivedFlag) {
		List<QueueRecoredDTO> datas= wequeueRecoredDAO.listByLeastRid(leastRid, size,archivedFlag);
		if(logger.isInfoEnabled()){
			logger.info("listByLeastRid size="+(datas==null?0:datas.size()));
		}
		return datas;
	}

	
	@Override
	public boolean retry( WequeuePushMsg msg) {
		return wequeueRecoredDAO.retry(msg.getRid(), msg.getQueueName());
	}

	

	
}
