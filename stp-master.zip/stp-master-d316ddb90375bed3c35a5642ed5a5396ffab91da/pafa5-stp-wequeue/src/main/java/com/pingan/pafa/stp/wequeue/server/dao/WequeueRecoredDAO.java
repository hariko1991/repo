package com.pingan.pafa.stp.wequeue.server.dao;

import java.util.List;

import com.pingan.pafa.stp.wequeue.server.dto.QueueRecoredDTO;

public interface WequeueRecoredDAO {

	void add(QueueRecoredDTO recoredDTO);
	
	boolean archiveLock(Long rid);
	
	boolean delByRid(Long rid);
	
	boolean archive(Long rid);
	
	Long getLeastRid();
	
	boolean receipt(QueueRecoredDTO recoredDTO);
	
	boolean retry(Long rid,String queueName);
	
	List<QueueRecoredDTO> listByLeastRid(Long leastRid,int size,Integer archivedFlag);
	
}
