package com.pingan.pafa.stp.wequeue.server.api;

import java.util.Set;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.ui.ModelMap;
import org.springframework.util.StringUtils;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.redis.queue.RedisQueue;
import com.pingan.pafa.stp.wequeue.common.Wequeue;
import com.pingan.pafa.stp.wequeue.common.msg.WequeueReceiptMsg;
import com.pingan.pafa.stp.wequeue.server.WequeueServer;

@Component
public class QueueStatusFacade extends BaseController{
	
	@Autowired
	private WequeueServer wequeueServer;
	
	@Resource(name="receipt_queue")
	private RedisQueue<WequeueReceiptMsg> receiptQueue;

	@ESA("stp_wequeue.query_status")
	public ModelMap statusQuery(StatusQueryForm form){
		ModelMap model=new ModelMap();
		model.put("responseCode", "0");
		String queueName=form.getQueueName();
		if(StringUtils.hasText(queueName)){
			if(form.isDoClear()){
				model.put("clearSuccess",doClear(queueName));
			}
			model.put(queueName, getQueueStatus(queueName));
		}else{
			Set<String> queueNames=wequeueServer.getQueueNameSet();
			for(String qn:queueNames){
				model.put(qn, getQueueStatus(qn));
			}
		}
		if(form.isIncludeReceiptQueue()){
			model.put(Wequeue.QUEUE_ID_DEF_RECEIPT, getReceiptQueueStatus());
		}
		return model;
	}
	
	protected boolean doClear(String queueName){
		try{
			if(logger.isWarnEnabled()){
				logger.warn("******Queue<"+queueName+">be cleared.");
			}
			wequeueServer.getQueue(queueName).clear();
			return true;
		}catch(Exception ex){
			logger.error("Queue<"+queueName+">clear error:"+ex.getMessage(),ex);
			return false;
		}
	}
	
	protected String getReceiptQueueStatus(){
		try{
			long size=this.getReceiptQueue().size();
			return Long.toString(size);
		}catch(Exception ex){
			logger.error("Receipt queue status error:"+ex.getMessage(),ex);
			return "status error";
		}
	}
	
	
	protected String getQueueStatus(String queueName){
		try{
			long size=wequeueServer.getQueue(queueName).size();
			return Long.toString(size);
		}catch(Exception ex){
			logger.error("Queue<"+queueName+"> queue status error:"+ex.getMessage(),ex);
			return "status error";
		}
	}

	public WequeueServer getWequeueServer() {
		return wequeueServer;
	}

	public void setWequeueServer(WequeueServer wequeueServer) {
		this.wequeueServer = wequeueServer;
	}

	public RedisQueue<WequeueReceiptMsg> getReceiptQueue() {
		return receiptQueue;
	}

	public void setReceiptQueue(RedisQueue<WequeueReceiptMsg> receiptQueue) {
		this.receiptQueue = receiptQueue;
	}

	
	
	
}
