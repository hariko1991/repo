package com.pingan.pafa.stp.wequeue.server.services;

import java.util.List;
import java.util.concurrent.ArrayBlockingQueue;

import javax.annotation.Resource;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.paic.pafa.biz.services.BaseServices;

@Component("ridGenerator")
public class RidGenerator extends BaseServices  implements InitializingBean{
	
	private ArrayBlockingQueue<Long> ridQueue;
	
	private boolean enableCache=true;
	
	@Value("${ridBatchGen.minCacheSize}")
	private int minCacheSize=50;
	
	@Value("${ridBatchGen.batchSize}")
	private int batchGenerateSize=20;

	@Resource(name="ridServices")
	private RidServices ridServices;
	
	public long generate() {
		if(enableCache){
			Long rid=ridQueue.poll();
			if(rid==null){
				 logger.warn("Cache queue is empty..");
				 return ridServices.generateRid();
			}else{
				return rid;
			}
		}else{
			return ridServices.generateRid();
		}
	}
	
	
	public void batchGenerateJob() throws Exception{
		while(ridQueue.size()<minCacheSize){
			List<Long> ids=ridServices.generateRids(batchGenerateSize);
			ridQueue.addAll(ids);
			//
			try{
				ridServices.clearRids();
			}catch(Exception ex){
				logger.error("Clear rid error,cause:"+ex.getMessage(),ex);
			}
		}
	}
	

	@Override
	public void afterPropertiesSet() throws Exception {
		if(minCacheSize<=0){
			throw new IllegalArgumentException("minCacheSize="+minCacheSize+" error.");
		}else{
			logger.info("minCacheSize="+minCacheSize);
		}
		if(batchGenerateSize<=0){
			throw new IllegalArgumentException("batchGenerateSize="+batchGenerateSize+" error.");
		}
		logger.info("batchGenerateSize="+batchGenerateSize);
		ridQueue=new ArrayBlockingQueue<Long>(minCacheSize+batchGenerateSize);
	}
	
	
	

}
