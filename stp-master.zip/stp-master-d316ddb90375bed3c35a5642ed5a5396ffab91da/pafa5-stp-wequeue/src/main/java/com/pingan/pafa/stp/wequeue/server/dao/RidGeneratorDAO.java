package com.pingan.pafa.stp.wequeue.server.dao;

public interface RidGeneratorDAO {

	void add();
	
	long getLastId();
	
	long getMaxId();
	
	int clear(long maxId);
	 
	 
}
