package com.pingan.pafa.stp.wequeue.server;

import com.pingan.pafa.redis.queue.ConsumeListener;
import com.pingan.pafa.stp.wequeue.common.msg.WequeueReceiptMsg;


public class ReceiptQueueConsumeListener  implements ConsumeListener<WequeueReceiptMsg> {

	private WequeueServer wequeueServer;
	
	@Override
	public void onReceiveMessages(WequeueReceiptMsg msg) {
		wequeueServer.receipt(msg);
	}

	public WequeueServer getWequeueServer() {
		return wequeueServer;
	}

	public void setWequeueServer(WequeueServer wequeueServer) {
		this.wequeueServer = wequeueServer;
	}

	

}
