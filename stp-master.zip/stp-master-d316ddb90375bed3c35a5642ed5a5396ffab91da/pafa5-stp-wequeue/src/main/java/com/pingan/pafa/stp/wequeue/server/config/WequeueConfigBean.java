package com.pingan.pafa.stp.wequeue.server.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.FatalBeanException;

import com.alibaba.fastjson.JSONObject;
import com.pingan.pafa.pizza.BaseConfigListener;
import com.pingan.pafa.pizza.Pizza;
import com.pingan.pafa.stp.wequeue.common.WequeueException;
import com.pingan.pafa.stp.wequeue.server.dto.WequeueConfigDTO;
import com.pingan.pafa.stp.wequeue.server.utils.Xml2JsonUtils;

public class WequeueConfigBean extends BaseConfigListener  {
	

	protected Log logger=LogFactory.getLog(this.getClass());

	private volatile Map<String,WequeueConfigDTO> queues;
	
	

	public WequeueConfigBean(){
		this.setConfigGroup(Pizza.GROUP_SAR);
		this.setConfigRequiredExists(true);
		this.setDynamicConfig(true);
		this.setLoadOnStatup(true);
	}

	@Override
	protected void onChanged(String configValue) {
		if(logger.isInfoEnabled()){
			logger.info("Parsing wequeue config on refreshed.");
		}
		parseConfig(configValue);
	}

	@Override
	protected void onStatupLoad(String configValue) {
		if(logger.isInfoEnabled()){
			logger.info("Parsing wequeue config on startup.");
		}
		parseConfig(configValue);
	}
	
	protected void parseConfig(String configValue){
		String json=new Xml2JsonUtils(configValue,"wequeue")
		.toJSONString();
		if(logger.isInfoEnabled()){
			logger.info("Wequeue config:\n"+json);
		}
		WequeuesConfigDTO data=null;
		try{
			data=JSONObject.parseObject(json, WequeuesConfigDTO.class);
		}catch(Exception ex){
			throw new FatalBeanException("Parse json to "+WequeuesConfigDTO.class.getName() +" error:\n"+json+"\n cause:"+ex.getMessage(),ex);
		}
		List<WequeueConfigDTO> queuesList=data.getWequeues();
		if(queuesList==null || queuesList.size()==0){
			logger.warn("Not defined any queue.");
			queues=new HashMap<String,WequeueConfigDTO>(0);
		}else{
			HashMap<String,WequeueConfigDTO> temp=new HashMap<String,WequeueConfigDTO>(queuesList.size());
			for(WequeueConfigDTO q: queuesList){
				temp.put(q.getQueueName(),q);
			}
			this.queues=temp;
		}
	}

	public WequeueConfigDTO getQueueConfig(String queueName,boolean required){
		if(queueName==null || queueName.length()==0){
			throw new WequeueException("QueueName is null.");
		}
		WequeueConfigDTO definition=queues.get(queueName);
		if(definition==null && required){
			throw new WequeueException("Queue<"+queueName+"> not found"); 
		}
		return definition;
	}
	
	public WequeueConfigDTO getQueueConfig(String queueName){
		return getQueueConfig(queueName,true);
	}
	
	
	
	protected void init()throws Exception{
		
	}
	
	@Override
	public final void destroy() throws Exception {
		super.destroy();
		onDestroy();
	}
	
	protected void onDestroy() throws Exception{
		
	}


	@Override
	public final void afterPropertiesSet() throws Exception {
		super.afterPropertiesSet();
		init();
	}
	
	
}
