package com.pingan.pafa.stp.wequeue.server.dto;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.paic.pafa.biz.dao.BasePO;


@Document(collection="WequeueRecored")
public class QueueRecoredDTO extends BasePO {

	
	
	public static final Integer STATUS_NOTICED=0;
	
	public static final Integer STATUS_RETRIED=1;
	
	public static final Integer STATUS_RECEIPTED=2;
	
	/**queue_msg_ID*/
	@Id
	private Long rid;
	
	
	private String queueName;
	
	private String publisherName;
	
	private String publisherIp;
	
	
	/**状态，0已创建，1已重试通知，2已回执'*/
	private Integer status;
	
	

	private Date clientPushDate;
	
	//--------------------------
	

	
	private Integer maxRetryTimes;
	
	private Integer retryInterval;
	
	private Integer realRetryTimes;
	

	private Date lastRetryDate;
	
	private Date receiptDate;
	
	private Date clientReceiptDate;
	
	private String receiptIP;
	
	private String receiptResponseCode;
	
	private String receiptResponseMsg;
	
	private String consumerName;
	
	private Integer archivedFlag;

	/**事件入参*/
	private String jsonBody;
	
	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}



	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	
	

	public String getQueueName() {
		return queueName;
	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	public String getPublisherName() {
		return publisherName;
	}

	public void setPublisherName(String publisherName) {
		this.publisherName = publisherName;
	}

	public String getPublisherIp() {
		return publisherIp;
	}

	public void setPublisherIp(String publisherIp) {
		this.publisherIp = publisherIp;
	}

	public Integer getMaxRetryTimes() {
		return maxRetryTimes;
	}

	public void setMaxRetryTimes(Integer maxRetryTimes) {
		this.maxRetryTimes = maxRetryTimes;
	}

	public Integer getRetryInterval() {
		return retryInterval;
	}

	public void setRetryInterval(Integer retryInterval) {
		this.retryInterval = retryInterval;
	}

	public Integer getRealRetryTimes() {
		return realRetryTimes;
	}

	public void setRealRetryTimes(Integer realRetryTimes) {
		this.realRetryTimes = realRetryTimes;
	}

	public Date getLastRetryDate() {
		return lastRetryDate;
	}

	public void setLastRetryDate(Date lastRetryDate) {
		this.lastRetryDate = lastRetryDate;
	}

	public Date getReceiptDate() {
		return receiptDate;
	}

	public void setReceiptDate(Date receiptDate) {
		this.receiptDate = receiptDate;
	}

	public Date getClientReceiptDate() {
		return clientReceiptDate;
	}

	public void setClientReceiptDate(Date clientReceiptDate) {
		this.clientReceiptDate = clientReceiptDate;
	}

	public String getReceiptIP() {
		return receiptIP;
	}

	public void setReceiptIP(String receiptIP) {
		this.receiptIP = receiptIP;
	}

	public String getReceiptResponseCode() {
		return receiptResponseCode;
	}

	public void setReceiptResponseCode(String receiptResponseCode) {
		this.receiptResponseCode = receiptResponseCode;
	}

	public String getReceiptResponseMsg() {
		return receiptResponseMsg;
	}

	public void setReceiptResponseMsg(String receiptResponseMsg) {
		this.receiptResponseMsg = receiptResponseMsg;
	}

	public String getJsonBody() {
		return jsonBody;
	}

	public void setJsonBody(String jsonBody) {
		this.jsonBody = jsonBody;
	}

	
	public Date getClientPushDate() {
		return clientPushDate;
	}

	public void setClientPushDate(Date clientPushDate) {
		this.clientPushDate = clientPushDate;
	}

	public String getConsumerName() {
		return consumerName;
	}

	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}

	public Integer getArchivedFlag() {
		return archivedFlag;
	}

	public void setArchivedFlag(Integer archivedFlag) {
		this.archivedFlag = archivedFlag;
	}

	
	
	
}
