package com.pingan.pafa.stp.wequeue.server.job;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.paic.pafa.biz.services.BaseServices;
import com.paic.pafa.job.TimerJob;
import com.pingan.pafa.redis.lock.RedisLock;
import com.pingan.pafa.stp.wequeue.common.msg.WequeuePushMsg;
import com.pingan.pafa.stp.wequeue.server.WequeueServer;
import com.pingan.pafa.stp.wequeue.server.dto.QueueRecoredDTO;
import com.pingan.pafa.stp.wequeue.server.dto.WequeueConfigDTO;
import com.pingan.pafa.stp.wequeue.server.services.WequeueServices;

@Component
public class RetryJob  extends BaseServices{

	@Autowired
	private WequeueServices wequeueServices;
	
	//批查询数量
	private int batchQuerySize=300;
	
	//相对截止时间
	@Value("${job.retry.checkDeadline}")
	private int checkDeadline=5*60*1000;
	
	//回执超时时间(12小时)
	@Value("${job.retry.receiptTimeout}")
	private int receiptTimeout=20*60*1000;
	
	@Resource(name="retry_job_lock")
	private RedisLock lock;
	
	@Autowired
	private WequeueServer wequeueServer;
	
	
	@TimerJob(maxConcurrent=1,cronExpression="${job.retry.cron}")
	public void execute()throws Exception{
		if(lock.tryLock()){
			try{
				doExecute();
			}finally{
				lock.unlock();
			}
		}
	}
	
	
	public void doExecute() throws Exception{
		Long leastRid=wequeueServices.getLeastRid();
		if(leastRid==null){
			logger.warn("********Data empty");
			return ;
		}
		Date date=new Date();
		SimpleDateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		if(logger.isInfoEnabled())
		{
			logger.info("Current time="+format.format(date));
		}
		long deadline=date.getTime()-checkDeadline;
		if(logger.isInfoEnabled())
		{
			logger.info("Deadline time="+format.format(new Date(deadline)));
		}
		List<QueueRecoredDTO> msgs=null;
		boolean continueFlag=true;
		while(continueFlag && (msgs=wequeueServices.listByLeastRid(leastRid,
				batchQuerySize,0))!=null  && msgs.size()>0){
			for(int i=0;i<msgs.size();i++){
				QueueRecoredDTO recored=msgs.get(i);
				//------------------------------------
				leastRid=recored.getRid()+1;
				//------------------------
				Date d=recored.getCreatedDate();
				//------------------------------------------------------
				if(d.getTime()>deadline){
					logger.warn("Rid<"+recored.getRid()+"> on Deadline.");
					continueFlag=false;
					break;
				}
				if(logger.isDebugEnabled()){
					logger.debug("Queue<"+recored.getQueueName()+"> rid="+recored.getRid()+" status="+QueueRecoredDTO.STATUS_NOTICED);
				}
				checkAndRetry(recored);
			}
		}
	}
	
	
	
	protected void checkAndRetry(QueueRecoredDTO recored){
		
		String queueName=recored.getQueueName();
		Long rid=recored.getRid();
		WequeueConfigDTO definition=wequeueServer.getQueueConfig(queueName, false);
		if(definition==null){
			if(wequeueServices.archiveLock(queueName, rid)){
				logger.warn("Queue<"+queueName+"> rid="+rid+" archived cause be deleted.");
			}
			return ;
		}
		if(recored.getStatus().equals(QueueRecoredDTO.STATUS_RECEIPTED))
		{
			if(wequeueServices.archiveLock(queueName, rid)){
				logger.info("Queue<"+queueName+"> rid="+rid+"  archived be  completed.");
			}
			return;
		}
		WequeuePushMsg request=wequeueServices.toPushMsg(recored);
		long curTime=System.currentTimeMillis();
		if(QueueRecoredDTO.STATUS_NOTICED.equals(recored.getStatus())){
			if(recored.getMaxRetryTimes()>0 
					&& checkRetryInterval(recored,recored.getCreatedDate(),curTime)){
				if(logger.isInfoEnabled()){
					logger.info("Retry for queue<"+queueName+"> rid="+rid);
				}
				wequeueServer.retry(request);
			}else if((recored.getCreatedDate().getTime()+receiptTimeout)<curTime){
				if(wequeueServices.archiveLock(queueName, rid)){
					logger.info("Queue<"+queueName+"> rid="+rid+"  archived cause receiptTimeout.");
				}
			}
		}else if(QueueRecoredDTO.STATUS_RETRIED.equals(recored.getStatus())){
			if(checkRetryInterval(recored,recored.getLastRetryDate(),curTime)){
				if(recored.getMaxRetryTimes().equals(recored.getRealRetryTimes())){
					if(wequeueServices.archiveLock(queueName, rid)){
						logger.info("Queue<"+queueName+"> rid="+rid+"  archived cause retryMaxTimes.");
					}
				}else{
					if(logger.isInfoEnabled()){
						logger.info("Retry for queue<"+queueName+"> rid="+rid);
					}
					wequeueServer.retry(request);
				}
			}
		}
	}
	
	
	
	protected boolean checkRetryInterval(QueueRecoredDTO recored,Date referDate,long curTime){
		return (referDate.getTime()+recored.getRetryInterval()*1000)<curTime;
	}

	

	public int getBatchQuerySize() {
		return batchQuerySize;
	}

	public void setBatchQuerySize(int batchQuerySize) {
		this.batchQuerySize = batchQuerySize;
	}




	public int getReceiptTimeout() {
		return receiptTimeout;
	}


	public void setReceiptTimeout(int receiptTimeout) {
		this.receiptTimeout = receiptTimeout;
	}


	public RedisLock getLock() {
		return lock;
	}


	public void setLock(RedisLock lock) {
		this.lock = lock;
	}


	public int getCheckDeadline() {
		return checkDeadline;
	}


	public void setCheckDeadline(int checkDeadline) {
		this.checkDeadline = checkDeadline;
	}
	
	
	
	
}
