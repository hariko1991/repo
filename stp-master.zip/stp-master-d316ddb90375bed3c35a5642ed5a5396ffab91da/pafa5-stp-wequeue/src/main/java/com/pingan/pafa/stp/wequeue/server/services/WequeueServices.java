package com.pingan.pafa.stp.wequeue.server.services;

import java.util.List;

import com.pingan.pafa.stp.wequeue.common.msg.WequeuePushMsg;
import com.pingan.pafa.stp.wequeue.common.msg.WequeueReceiptMsg;
import com.pingan.pafa.stp.wequeue.server.dto.QueueRecoredDTO;
import com.pingan.pafa.stp.wequeue.server.dto.WequeueConfigDTO;

public interface WequeueServices {
	
	boolean archiveLock(String queueName,Long rid);
	
	boolean archive(String queueName,Long rid);
	
	boolean receipt(WequeueReceiptMsg receiptMsg);

	boolean retry(WequeuePushMsg msg) ;
	
	void  addMsg(WequeuePushMsg msg,WequeueConfigDTO definition);
	
	Long getLeastRid();
	 
	List<QueueRecoredDTO> listByLeastRid(Long leastRid,int size,Integer archivedFlag);
	
	WequeuePushMsg toPushMsg(QueueRecoredDTO recored);
	
	
	
}
