package com.pingan.pafa.stp.wequeue.server;

import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.stp.wequeue.common.msg.WequeuePushMsg;
import com.pingan.pafa.stp.wequeue.common.msg.WequeuePushResultMsg;
import com.pingan.pafa.stp.wequeue.common.msg.WequeueReceiptMsg;
import com.pingan.pafa.stp.wequeue.server.dto.WequeueConfigDTO;
import com.pingan.pafa.stp.wequeue.server.services.RidGenerator;
import com.pingan.pafa.stp.wequeue.server.services.WequeueServices;

public class WequeueServerBean extends ConsumerRedisQueuesBean implements WequeueServer {
	
	@Autowired
	private RidGenerator ridGenerator;
	

	@Autowired
	private WequeueServices wequeueServices;
	
	
	@Override
	public WequeuePushResultMsg push(WequeuePushMsg msg) {
		String queueName=msg.getQueueName();
		if(logger.isInfoEnabled()){
			logger.info("Push to queue <"+queueName+"> msg="+msg);
		}
		WequeueConfigDTO definition=this.getQueueConfig(queueName,false);
		if(definition==null){
			return new WequeuePushResultMsg(WequeuePushResultMsg.CODE_QUEUE_NOT_FOUND
					,"Queue<"+queueName+"> not exists."); 
		}
		if(WequeueConfigDTO.STATUS_STOP.equals(definition.getStatus())){
			return new WequeuePushResultMsg(WequeuePushResultMsg.CODE_QUEUE_STOPED
					,"Queue<"+queueName+"> stoped."); 
		}
		//---------------------------------------
		Long rid=null;
		try{
			rid=ridGenerator.generate();
			msg.setRid(rid);
			wequeueServices.addMsg(msg,definition);
		}catch(Throwable th){
			logger.error("Msg for queue<"+queueName+"> to db error:"+th.getMessage(),th);
			return new WequeuePushResultMsg(WequeuePushResultMsg.CODE_DB_ERROR
					,"Recored to DB error."); 
		}
		this.pushToRedisQueue(definition, msg, false);
		WequeuePushResultMsg result= new WequeuePushResultMsg(WequeuePushResultMsg.CODE_SUCCESS
				,"success"); 
		result.setWequeueRid(rid);
		return result;
	}


	@Override
	public boolean retry(WequeuePushMsg msg) {
		String queueName=msg.getQueueName();
		try{
			WequeueConfigDTO definition=this.getQueueConfig(queueName);
			//
			if(WequeueConfigDTO.STATUS_STOP.equals(definition.getStatus())){
				logger.warn("Retry,queue="+queueName +" be stoped");
				return false;
			}
			boolean flag=wequeueServices.retry(msg);
			if(flag){
				pushToRedisQueue(definition,msg,true);
			}else{
				logger.warn("Retry,queue="+queueName+" status error.");
			}
			return flag;
		}catch(Throwable th){
			logger.error("RetryError,queue="+queueName+",rid="+msg.getRid()
					+",cause:"+th.getMessage(),th);
		}
		return false;
	}


	@Override
	public boolean receipt(WequeueReceiptMsg receiptMsg) {
		try{
			if(logger.isInfoEnabled()){
				logger.info("Receipted:"+ receiptMsg);
			}
			return wequeueServices.receipt(receiptMsg);
		}catch(Throwable th){
			logger.error("ReceiptError,queue="+receiptMsg.getQueueName()+",rid="+receiptMsg.getRid()+",cause:"+th.getMessage(),th);
			return false;
		}
	}


	

	
	

	
	


	public RidGenerator getRidGenerator() {
		return ridGenerator;
	}


	public void setRidGenerator(RidGenerator ridGenerator) {
		this.ridGenerator = ridGenerator;
	}


	public WequeueServices getWequeueServices() {
		return wequeueServices;
	}


	public void setWequeueServices(WequeueServices wequeueServices) {
		this.wequeueServices = wequeueServices;
	}


	

	
}
