package com.pingan.pafa.stp.wequeue.server.api;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.paic.pafa.app.biz.action.Action;
import com.paic.pafa.app.dto.ServiceRequest;
import com.paic.pafa.app.dto.ServiceResponse;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.stp.wequeue.common.Wequeue;
import com.pingan.pafa.stp.wequeue.common.msg.WequeuePushMsg;
import com.pingan.pafa.stp.wequeue.common.msg.WequeuePushResultMsg;
import com.pingan.pafa.stp.wequeue.server.WequeueServer;


@Component("WequeuePushFacade")
public class WequeuePushFacade implements Action {
	
	@Autowired
	private WequeueServer wequeueServer;
	@ESA("stp_wequeue.push")
	@Override
	public ServiceResponse perform(ServiceRequest request)
	{
		String queueName=(String)request.getParameter(Wequeue.PN_NAME);
		String publisherName=(String)request.getParameter(Wequeue.PN_PUBLISHER_NAME);
		String publisherIp=(String)request.getParameter(Wequeue.PN_PUBLISHER_IP);
		
		if(queueName==null || (queueName=queueName.trim()).length()==0){
			throw new IllegalArgumentException(Wequeue.PN_NAME+" required.");
		}
		if(publisherName==null || (publisherName=publisherName.trim()).length()==0){
			throw new IllegalArgumentException(Wequeue.PN_PUBLISHER_NAME+" required.");
		}
		if(publisherIp==null || (publisherIp=publisherIp.trim()).length()==0){
			throw new IllegalArgumentException(Wequeue.PN_PUBLISHER_IP+" required.");
		}
	
		Object body=request.getParameter(Wequeue.PN_BODY);
		if(body==null){
			throw new IllegalArgumentException(Wequeue.PN_BODY+" required.");
		}
		if(!(body instanceof Map<?,?>)){
			throw new IllegalArgumentException(Wequeue.PN_BODY+" not instanceof "+Map.class.getName());
		}
		Map<?,?> bodyMap=(Map<?,?>)body;
		//
		WequeuePushMsg msg=new WequeuePushMsg();
		msg.setQueueName(queueName);
		msg.setPublisherIp(publisherIp);
		msg.setPublisherName(publisherName);
		msg.setBody(bodyMap);
		msg.setClientPushDate((Long)request.getParameter(Wequeue.PN_PUSH_DATE));
		
		WequeuePushResultMsg resultMsg=wequeueServer.push(msg);
		//------------------------
		ServiceResponse response=new ServiceResponse();
		response.setResponseCode(resultMsg.getResponseCode());
		response.setResponseMsg(resultMsg.getResponseMsg());
		Map<Object,Object> model=new HashMap<Object,Object>();
		model.put(Wequeue.PN_RID, resultMsg.getWequeueRid());
		response.setModel(model);
		return response;
	}
	
	

	public WequeueServer getWequeueServer() {
		return wequeueServer;
	}

	public void setWequeueServer(WequeueServer wequeueServer) {
		this.wequeueServer = wequeueServer;
	}

	
	
	
}
