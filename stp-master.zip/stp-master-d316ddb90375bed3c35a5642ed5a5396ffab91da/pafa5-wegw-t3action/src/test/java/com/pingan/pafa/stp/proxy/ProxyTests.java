package com.pingan.pafa.stp.proxy;

import org.junit.Test;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList={"stp_proxy_t3action"},protocols={"dubbo"})
public class ProxyTests extends BaseSARTest{
	
	@ActionClient(name="nts_pims.fisheryInfoFetchAction")
	private IServiceClient test;
	
	
	@Test
	public void iz() throws Throwable{
		ServiceResults result=test.invoke(ServiceParams.newInstance().set("name", "zhangsan"));
		logger.info("result="+result);
	}
	
	

}
