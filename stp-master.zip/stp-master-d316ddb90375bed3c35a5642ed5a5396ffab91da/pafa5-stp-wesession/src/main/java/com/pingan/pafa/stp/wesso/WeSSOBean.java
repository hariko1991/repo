package com.pingan.pafa.stp.wesso;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.stp.wesession.id.HttpClientIpUtils;

public class WeSSOBean extends BaseServices implements WeSSO, InitializingBean, DisposableBean {

    private Object NOT_LOGIN_FLAG = new Object();
    
    
    private String appName;
  
    private WeSSOListener listener;
    
    private boolean enabled=true;
    
	@Override
    public void destroy() throws Exception {
    }
	
    public synchronized void afterPropertiesSet() throws Exception {
    	if(appName==null){
    		throw new NullPointerException("appName is null.");
    	}
    }
    
    
	@Override
	public boolean isEnabled() {
		return enabled;
	}

	
	@Override
	public UserPrincipal login(HttpServletRequest request,
			HttpServletResponse response, String user) {
		return login(request,response,new UserPrincipal(user));
	}

	@Override
    public UserPrincipal login(HttpServletRequest request, HttpServletResponse response, UserPrincipal principal) {
        String user=principal.getUser();
        if(user==null || (user=user.trim()).length()==0){
        	throw new NullPointerException("User is null.");
        }
        if(principal.getClientIp()==null){
        	principal.setClientIp(HttpClientIpUtils.getIp(request));
        }
        if(listener!=null){
	        try {
	              this.listener.onLogin(request,response,principal);
	        } catch (Exception ex) {
	            throw new WeSSOException("Listener onLogin  error for user<" + user + ">, cause:" + ex.getMessage(), ex);
	        }
        }
        if (logger.isInfoEnabled()) {
            logger.info("[SSO]User[" + user + "]logining.");
        }
        HttpSession session = request.getSession();
        UserPrincipal userPrincipal = createUserPrincipal(session, principal);
        request.setAttribute(ATTR_KEY_PRINCIAL, userPrincipal);
        //
        return userPrincipal;
    }

    public UserPrincipal getUserPrincipal(HttpServletRequest request, HttpServletResponse response) {
        Object up = request.getAttribute(ATTR_KEY_PRINCIAL);
        if (up != null) {
            if (up == NOT_LOGIN_FLAG) {
                return null;
            } else {
                return (UserPrincipal) up;
            }
        }
        // 取得用户凭证
        try {
        	HttpSession session=request.getSession(false);
        	UserPrincipal temp =null;
        	if(session!=null){
        		temp = getUserPrincipal(request,response,session);
        	}
            if (temp != null) {
                request.setAttribute(ATTR_KEY_PRINCIAL, temp);
            } else {
                request.setAttribute(ATTR_KEY_PRINCIAL, NOT_LOGIN_FLAG);
            }
            return temp;
        } catch (WeSSOException ex) {
            throw ex;
        } catch (Throwable ex) {
            throw new WeSSOException("getUserPrincipal error:" + ex.getMessage(), ex);
        }
    }
    
    

    /*public UserPrincipal getUserPrincipal(HttpSession session) {
        WeSSODatas data = getDatas(session);
        if (data != null) {
            return new UserPrincipal(session.getId(), data);
        } else if (this.plugin!=null) {
            String user=null;
			try {
				user = plugin.validate(loginTicket);
			} catch (Exception e) {
				logger.error("Plugin validate error,cause:"+e.getMessage(),e);
			}
            if (user != null) {
                return this.createUserPrincipal(loginTicket, user, null);
            }
        }
        return null;
    }*/
    
    

    public void logout(HttpServletRequest request, HttpServletResponse response) {
    	 if (logger.isInfoEnabled()) {
             logger.info("[SSO]logout ...");
         }
         request.setAttribute(ATTR_KEY_PRINCIAL, NOT_LOGIN_FLAG);
         HttpSession session=request.getSession(false);
         if(session!=null){
         	session.removeAttribute(ATTR_KEY_PRINCIAL);
         }
         if(listener!=null){
 	        try {
 	              this.listener.onLogout(request,response);
 	        } catch (Exception ex) {
 	           logger.error("Listener onLogout  error , cause:" + ex.getMessage(), ex);
 	        }
         }
    }

    
    
    protected UserPrincipal createUserPrincipal(HttpSession session,UserPrincipal principal) {
    	String user=principal.getUser();
        if(user==null || (user=user.trim()).length()==0){
        	throw new NullPointerException("User is null.");
        }
        long cur = System.currentTimeMillis();
        principal.setCreateTimestamp(cur);
        // 设置最后更新者的信息
        principal.setLastAccTime(cur);
        principal.setLastAppName(appName);
        // 保存到缓存
        if (logger.isInfoEnabled()) {
            logger.info("UserPrincipal<" + JSONObject.toJSONString(principal) + "> for session.");
        }
        String sessionId=session.getId();
        principal.setSessionId(sessionId);
        session.setAttribute(ATTR_KEY_PRINCIAL, principal);
        
        if (logger.isInfoEnabled()) {
            logger.info("[SSO]User[" +user + "]logined success.");
        }
        return principal;
    }
    
    

  

    
    protected UserPrincipal getUserPrincipal(HttpServletRequest request, HttpServletResponse response,HttpSession session) {
    	UserPrincipal principal  = (UserPrincipal)session.getAttribute(ATTR_KEY_PRINCIAL);
    	if(principal==null && listener!=null){
 	        try {
 	        	principal=this.listener.onTimeout(request,response);
 	        	if(principal!=null){
 	        		principal=this.createUserPrincipal(session, principal);
 	        	}
 	        } catch (Exception ex) {
 	           logger.error("Listener onTimeout  error , cause:" + ex.getMessage(), ex);
 	        }
        }	
       if (principal == null || principal.getUser() == null) {
    	   if(logger.isDebugEnabled()){
    		   logger.debug("[SSO]Not found UserPrincipal by session<" + session.getId() + ">.");
    	   }
        } 
        return principal;
    }

	public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}
    
    
    


   


	




}
