package com.pingan.pafa.stp.wesession.filter;

import java.io.IOException;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa.papp.web.filter.AbstractWebFilter;

/**
 * 登陆用户控制
 * @author EX-YANGSHENGXIANG001
 */
public class AuthorizeWebFilter extends AbstractWebFilter {

	private boolean enabled = true;

	private String errorResponseCode="900106";
	
	private String errorResponseMsg="User not logined or timeouted.";
	
	
	public AuthorizeWebFilter() {
		this.setOrder(-9999);
	}

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		if (isEnabled()) {
			if (authorize(httpRequest, (HttpServletResponse) response)) {
				chain.doFilter(httpRequest, response);
			}else{
				throw new ResponseCodeException(this.getErrorResponseCode(),this.getErrorResponseMsg());
			}
		} else {
			chain.doFilter(httpRequest, response);
		}
	}

	private boolean authorize(HttpServletRequest httpRequest,
			HttpServletResponse response) {
		String user=httpRequest.getRemoteUser();
		return user != null && user.trim().length()!=0;
	}

	public void init(FilterConfig config) throws ServletException {
		if (logger.isInfoEnabled()) {
			logger.info("AuthorizeWebFilter inited, and enabled="
					+ this.isEnabled());
		}
	}

	

	public void setEnabled(boolean enabled) {
		this.enabled = enabled;
	}

	public boolean isEnabled() {
		return enabled;
	}

	public String getErrorResponseCode() {
		return errorResponseCode;
	}

	public void setErrorResponseCode(String errorResponseCode) {
		this.errorResponseCode = errorResponseCode;
	}

	public String getErrorResponseMsg() {
		return errorResponseMsg;
	}

	public void setErrorResponseMsg(String errorResponseMsg) {
		this.errorResponseMsg = errorResponseMsg;
	}

	
}
