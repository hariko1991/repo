package com.pingan.pafa.stp.wesession.id;

import javax.servlet.http.HttpServletRequest;

public class HttpClientIpUtils {

//    private static Logger log = Logger.getLogger(HttpClientIpUtils.class);
    
	/**
	 * 获取客户端IP
	 * @param request
	 * @return 客户端IP地址
	 * 
	 */
	public static String getIp(HttpServletRequest request) {
		String ip = request.getHeader("x-forwarded-for");
//		if(ip!=null && ip.length()!=0 && log.isInfoEnabled()){
//			log.info("Geted ip="+ip+" from header[x-forwarded-for]");
//		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
//			if(ip!=null && ip.length()!=0 && log.isInfoEnabled()){
//				log.info("Geted ip="+ip+" from header[Proxy-Client-IP]");
//			}
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
//			if(ip!=null && ip.length()!=0 && log.isInfoEnabled()){
//				log.info("Geted ip="+ip+" from header[WL-Proxy-Client-IP]");
//			}
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
//			if(log.isInfoEnabled()){
//				log.info("Geted ip="+ip);
//			}
		}
		ip=getIp(ip);
		return ip;
	}
	
	private static String getIp(String ip) {
		//多层反向代理，有可能取到的ip类似这样：27.106.131.246, 127.0.0.1, 61.135.165.46
		if (ip != null && ip.indexOf(',') > 0) {
			String[] ipArray = ip.split(",");
//			log.info("ipArray=" + ip); // 多层反向代理ip地址,取最后一个ip返回
			ip = ipArray[ipArray.length - 1].trim();
		}
		return ip;
	}
}
