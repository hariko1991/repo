package com.pingan.pafa.stp.wesession;

import java.io.IOException;
import java.util.Properties;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.FatalBeanException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;

import com.pingan.pafa.common.utils.Pafa5ConfigUtils;
import com.pingan.pafa.redis.map.RedisMap;
import com.pingan.pafa.redis.map.RedisMapFactoryBean;
import com.pingan.pafa.stp.wesession.id.DefaultSessionIdSupportBean;
import com.pingan.pafa.stp.wesession.id.SessionIdSupport;

public class WesessionBean extends RedisMapFactoryBean<String,Object> implements WeSession,InitializingBean {

	private boolean isEnabled=true;
	
	private WeSessionConfig configure;
    
    private Resource configureResource;
    
    private Properties configureProperties;
    
    private SessionIdSupport sessionIdSupport;
    
    private static final String KEY_LAST_ACC_TIME="last_acc_time";

    
    
    protected Log logger=LogFactory.getLog(this.getClass());
	
    private static final String ATTR_KEY_WESESSION         = "PAFA5_WESESSION";
    
    public WesessionBean(){
    	this.setKeyClazz(String.class);
    	this.setValueClazz(Object.class);
    }
    
    @Override
	public UserSession getSession(HttpServletRequest request,
			HttpServletResponse response, boolean create) {
    	 Object session = request.getAttribute(ATTR_KEY_WESESSION);
         if (session != null) {
        	 return (UserSession) session;
         }
    	String sessionId= getId(request,response);
		boolean isNew=false;
		if(sessionId==null && create){
			sessionId=createId(request, response);
			isNew=true;
		}
		if(sessionId==null){
			return null;
		}
		RedisMap<String,Object> redisMap=this.get(configure.getSessionIdKeyName()+"."+sessionId);
		if(isNew){
			int expireTime=configure.getCacheExpiresTime();
			if(expireTime>0){
				redisMap.setExpiredTime(expireTime);
			}
			redisMap.put(KEY_LAST_ACC_TIME, Long.valueOf(System.currentTimeMillis()));
		}else{
			Long lastAccTime=(Long)redisMap.get(KEY_LAST_ACC_TIME);
			if(lastAccTime==null){
				if(create){
					sessionId=createId(request, response);
					isNew=true;
					redisMap=this.get(configure.getSessionIdKeyName()+"."+sessionId);
					//----------------------------------
					redisMap.put(KEY_LAST_ACC_TIME, Long.valueOf(System.currentTimeMillis()));
					int expireTime=configure.getCacheExpiresTime();
					if(expireTime>0){
						redisMap.setExpiredTime(expireTime);
					}
				}else{
					 if (configure.isDestoryCookieOnCacheExpired()) {
			                // 删除Cookie
			                this.sessionIdSupport.destory(request, response);
			         }
					 return null;
				}
			}else{
				int expireTime = configure.getCacheExpiresTime();
				if(configure.isRefreshExpiresTime() && configure.getCacheRefreshInterval()>0
						&& expireTime>0){
					long curTms=System.currentTimeMillis();
					if((curTms-lastAccTime)>(configure.getCacheRefreshInterval())){
						redisMap.put(KEY_LAST_ACC_TIME,new Long(curTms));
						
						redisMap.setExpiredTime(expireTime);
					}
				}
			}
		}
		UserSession userSession=new UserSessionImpl(redisMap,sessionId,isNew);
		request.setAttribute(ATTR_KEY_WESESSION, userSession);
		return userSession;
	}
    
    
    

	@Override
	public boolean destroySession(HttpServletRequest request,
			HttpServletResponse response, UserSession userSession) {
		if (userSession == null) {
			return false;
		}
		if (logger.isInfoEnabled()) {
			logger.info("[Wesession]destroy by sessionId<"
					+ userSession.getId() + ">..");
		}
		// 删除Cookie
		this.sessionIdSupport.destory(request, response);
		request.removeAttribute(ATTR_KEY_WESESSION);
		return userSession.destroy();
	}

	@Override
	public String getId(HttpServletRequest request, HttpServletResponse response) {
		return sessionIdSupport.get(request, response);
	}

	@Override
	public String createId(HttpServletRequest request,
			HttpServletResponse response) {
		return sessionIdSupport.create(request, response, null);
	}

	public synchronized void afterPropertiesSet() throws Exception {
    	Properties configProperties=this.getConfigureProperties();
		if(this.configureResource!=null){
			if(configProperties==null){
				configProperties=new Properties();
			}
			try {
				configProperties.load(configureResource.getInputStream());
			} catch (IOException e) {
				logger.error("Read Resource:"+configureResource+" error,cause:"+e.getMessage(),e);
			}
		}
		WeSessionConfig configure=this.getConfigure();
		if(configProperties!=null && configProperties.size()>0){
			if(configure==null ){
				configure=new WeSessionConfig();
				this.setConfigure(configure);
			}
			Pafa5ConfigUtils.bindBean(configProperties, configure);
		}
		if(configure==null){
			throw new java.lang.IllegalArgumentException("Configure be null.");
		}
        if (logger.isInfoEnabled()) {
            logger.info("[Wesession]configure=" + configure);
        }
        if (this.sessionIdSupport == null) {
        	sessionIdSupport = new DefaultSessionIdSupportBean(configure);
        }
        if(this.getRedis()==null){
			throw new FatalBeanException("redis is null");
		}
/*		if(this.getSerialization()==null){
			this.setSerialization(new JavaSerialization());
		}*/
    }
	
	@Override
	public boolean isEnabled() {
		return isEnabled;
	}

	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}

	public WeSessionConfig getConfigure() {
		return configure;
	}

	public void setConfigure(WeSessionConfig configure) {
		this.configure = configure;
	}

	public Resource getConfigureResource() {
		return configureResource;
	}

	public void setConfigureResource(Resource configureResource) {
		this.configureResource = configureResource;
	}

	public Properties getConfigureProperties() {
		return configureProperties;
	}

	public void setConfigureProperties(Properties configureProperties) {
		this.configureProperties = configureProperties;
	}

	public SessionIdSupport getSessionIdSupport() {
		return sessionIdSupport;
	}

	public void setSessionIdSupport(SessionIdSupport sessionIdSupport) {
		this.sessionIdSupport = sessionIdSupport;
	}
	
	
}
