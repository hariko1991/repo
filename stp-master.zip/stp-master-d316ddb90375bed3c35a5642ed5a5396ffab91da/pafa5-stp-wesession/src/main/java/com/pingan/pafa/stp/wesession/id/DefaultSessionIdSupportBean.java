package com.pingan.pafa.stp.wesession.id;

import java.util.Random;
import java.util.UUID;
import java.util.regex.Pattern;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.pingan.pafa.common.utils.PNetUtils;
import com.pingan.pafa.stp.wesession.WeSessionConfig;



public class DefaultSessionIdSupportBean   implements SessionIdSupport {
	
	private static Log logger=LogFactory.getLog(DefaultSessionIdSupportBean.class);
	
	private   Pattern ticketPattern;
	
	private WeSessionConfig configure;
	 
	private CookieUtils cookieUtils =new CookieUtils();
	
	private Random random=new Random();
	
	public DefaultSessionIdSupportBean(){}
	
	public DefaultSessionIdSupportBean(WeSessionConfig configure){
		this.setConfigure(configure);
	}
	
	@Override
	public String generateId() {
		String sessionId= createNewSessionId();
		if(logger.isDebugEnabled()){
			logger.debug("GenerateSessionId="+maskId(sessionId));
		}
		return sessionId;
	}
	
	

	@Override
	public String maskId(String sessionId) {
		return sessionId.substring(0,sessionId.length()-6)+"******";
	}

	protected String createNewSessionId(){
		char[] id=UUID.randomUUID().toString().toCharArray();
		StringBuilder sb=new StringBuilder(id.length);
		for(int i=0;i<id.length;i++){
			if(id[i]!='-'){
				sb.append(id[i]);
			}
		}
		String rstr=Integer.toHexString(random.nextInt(1000000));
		for(int i=0;i<(6-rstr.length());i++){
			sb.append('0');
		}
		sb.append(rstr);
		return "S"+sb;
	}
	
	public static void main(String args[]){
		DefaultSessionIdSupportBean i=new DefaultSessionIdSupportBean();
		String id=i.generateId();
		System.out.println(id);
		i.validateId(id);
	}
	
	
	protected String _create(HttpServletRequest request,HttpServletResponse response,String sessionId){
		if(sessionId==null){
			sessionId=createNewSessionId();
		}else{
			validateId(sessionId);
		}
		if(configure.isCookieEnable()){
			String cookieDomain=configure.getCookieDomain();
			if(cookieDomain!=null && configure.isCookieMainDomainEnable()){
				cookieDomain=getMainDomain(request.getRequestURL());
			}
			Cookie c=cookieUtils.createCookie(configure.getSessionIdKeyName(),sessionId,cookieDomain,configure.getCookiePath());
			response.addCookie(c);//将cookie添加到响应中
			if(logger.isInfoEnabled()){
				logger.info("Create cookie<"+configure.getSessionIdKeyName()+"> and sessionId="+maskId(sessionId));
			}
		}
		return sessionId;
	}
	
	public void validateId(String sessionId){
		if(!this.ticketPattern.matcher(sessionId).matches()){
			throw new java.lang.IllegalArgumentException("SessionId["+sessionId+"] format error.");
		}
	}
	
	@Override
	public String get(HttpServletRequest request,
			HttpServletResponse response, boolean isCreate) {
		String keyName=configure.getSessionIdKeyName();
		String id=cookieUtils.getCookieValue(request,keyName);
		if(id!=null && (id=id.trim()).length()>0){
			if(logger.isDebugEnabled()){
				logger.debug("Get sessionId by cookie="+keyName+",and id="+maskId(id));
			}
		}else{
			id=null;
		}
		//-----------------------------------------------------------------
		if(id==null){
			id=request.getHeader(keyName);
		}
		if(id!=null && (id=id.trim()).length()>0){
			if(logger.isDebugEnabled()){
				logger.debug("Get sessionId by header="+maskId(id));
			}
		}else{
			id=null;
		}
		//-----------------------------------------------------------------
		if(id==null && "POST".equalsIgnoreCase(request.getMethod())){
			String contentType=request.getContentType();
			contentType=(contentType==null?"":contentType.trim().toLowerCase());
			if(contentType.startsWith("application/x-www-form-urlencoded")){
				id=request.getParameter(keyName);
			}
		}
		if(id!=null && (id=id.trim()).length()>0){
			if(logger.isDebugEnabled()){
				logger.debug("Get sessionId by param="+maskId(id));
			}
		}else{
			id=null;
		}
		
		//------------------------------------------------------------------
		if(id==null && isCreate){
			id=this.create(request, response);
		}else{
			if(id!=null){
				validateId(id);
			}
		}
		return id;
	}


	



	
	public String create(HttpServletRequest request,
			HttpServletResponse response,String sessionId) {
		return this._create(request,response,sessionId);
	}

	
	public String create(HttpServletRequest request,
			HttpServletResponse response) {
		return this._create(request,response,null);
	}

	
	





	@Override
	public void destory(HttpServletRequest request,HttpServletResponse response) {
		if(!configure.isCookieEnable())return ;
		String keyName=configure.getSessionIdKeyName();
		if(logger.isInfoEnabled()){
			logger.info("Remove cookie<"+keyName+">");
		}
		String cookieDomain=configure.getCookieDomain();
		if(cookieDomain!=null && configure.isCookieMainDomainEnable()){
			cookieDomain=getMainDomain(request.getRequestURL());
		}
		response.addCookie(cookieUtils.deleteCookie(keyName, cookieDomain, configure.getCookiePath(), "0"));
	}


	@Override
	public String get(HttpServletRequest request,
			HttpServletResponse response) {
		return get(request,response,false);
	}


	protected  String getMainDomain(StringBuffer url){
		String domain=getDomain(url);
		//
		int idx=domain.indexOf('.');
		if(idx!=-1){
			if(PNetUtils.isValidLocalHost(domain) || PNetUtils.isValidIP(domain)){
				//如果是ip或者本机
				return null;
			}else{
				return domain.substring(idx);
			}
		}else{
			//没有点号，不处理
			return null;
		}
	}
	
	
	protected  String getDomain(StringBuffer url){
		for(int i=0;i<url.length();i++){
			char ch=url.charAt(i);
			if(ch=='\\'){
				url.setCharAt(i, '/');
			}
		}
		String temp=url.toString();
		int idx1=temp.indexOf("//");
		if(idx1==-1){
			idx1=0;
		}else{
			idx1=idx1+2;
		}
		//------------------------
		int idx2=temp.indexOf('/',idx1);
		String temp2= temp.substring(idx1, idx2);
		int idx3=temp2.indexOf(':');
		if(idx3!=-1){
			return temp2.substring(0, idx3).toLowerCase();
		}else{
			return temp2.toLowerCase();
		}
	}




	public CookieUtils getCookieUtils() {
		return cookieUtils;
	}

	public void setCookieUtils(CookieUtils cookieUtils) {
		this.cookieUtils = cookieUtils;
	}

	public WeSessionConfig getConfigure() {
		return configure;
	}

	public void setConfigure(WeSessionConfig configure) {
		this.configure = configure;
		ticketPattern=Pattern.compile(configure.getSessionIdPattern());
	}





	
	

}
