package com.pingan.pafa.stp.wesession.filter;

import java.io.IOException;
import java.security.Principal;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pingan.pafa.papp.web.filter.AbstractWebFilter;
import com.pingan.pafa.stp.wesession.WeSession;
import com.pingan.pafa.stp.wesso.UserPrincipal;
import com.pingan.pafa.stp.wesso.WeSSO;

public class WeSessionWebFilter extends AbstractWebFilter {
	
	private WeSSO wesso;
	
	private WeSession wesession;
	
	public WeSessionWebFilter(){ 
		this.setOrder(-99999);
	}
	

	public void doFilter(ServletRequest request, ServletResponse response,
			FilterChain chain) throws IOException, ServletException {
		HttpServletRequest httpRequest=(HttpServletRequest)request;
		HttpServletResponse httpResponse=(HttpServletResponse)response;
		WeSessionHttpRequestWrapper wrapperRequest=null;
		if(wesession.isEnabled()){
			httpRequest=wrapperRequest=new WeSessionHttpRequestWrapper(httpRequest,httpResponse,wesso,wesession);
		}
		Principal up=httpRequest.getUserPrincipal();
		if(up!=null){
			UserPrincipal.set(up);
		}
		try{
			chain.doFilter(httpRequest, response);
		}finally{
			if(up!=null)UserPrincipal.clear();
			if(wrapperRequest!=null)wrapperRequest.destory();
		}
	}

	public void init(FilterConfig config) throws ServletException {
		if (logger.isInfoEnabled()) {
			logger.info("WeSessionWebFilter inited...");
		}
	}


	public WeSSO getWesso() {
		return wesso;
	}


	public void setWesso(WeSSO wesso) {
		this.wesso = wesso;
	}


	public WeSession getWesession() {
		return wesession;
	}


	public void setWesession(WeSession wesession) {
		this.wesession = wesession;
	}

	
}
