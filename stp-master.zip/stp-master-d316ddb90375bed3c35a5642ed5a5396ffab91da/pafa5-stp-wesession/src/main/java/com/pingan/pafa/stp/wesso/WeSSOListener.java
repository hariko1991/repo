package com.pingan.pafa.stp.wesso;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface WeSSOListener {
	
	String onLogin(HttpServletRequest request, HttpServletResponse response,UserPrincipal principal) throws Exception;
	
	UserPrincipal onTimeout(HttpServletRequest request, HttpServletResponse response) throws Exception;
	
	void onLogout(HttpServletRequest request, HttpServletResponse response) throws Exception;
}
