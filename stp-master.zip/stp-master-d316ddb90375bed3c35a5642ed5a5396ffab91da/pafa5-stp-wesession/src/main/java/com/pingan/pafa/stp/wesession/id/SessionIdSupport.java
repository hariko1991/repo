package com.pingan.pafa.stp.wesession.id;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public interface  SessionIdSupport {
	
	String maskId(String sessionId);
	
	void validateId(String sessionId);

	String generateId();
	
	public  String get(HttpServletRequest request,
			HttpServletResponse response, boolean isCreate);

	
	public  String get(HttpServletRequest request,
			HttpServletResponse response);
	
	String create(HttpServletRequest request,
			HttpServletResponse response,String sessionId);
	

	public void destory(HttpServletRequest request,HttpServletResponse response);
	
	
	
}
