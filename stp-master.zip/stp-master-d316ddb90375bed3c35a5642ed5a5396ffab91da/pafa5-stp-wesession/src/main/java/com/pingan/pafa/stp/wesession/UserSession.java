package com.pingan.pafa.stp.wesession;

import javax.servlet.http.HttpSession;

public interface UserSession extends HttpSession {
	
	
	   Object getAttribute(String attrKey);
	  
	   void setAttribute(String attrKey,Object attrValue);
	   
	   void removeAttribute(String attrKey);
	   
	   boolean containsAttribute(String attrKey);
	   
	   //------------------------------------------------------------------------
	
	   boolean isInvalidate();
	   
	   String getId();
	   
	   boolean destroy();
}
