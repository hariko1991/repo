package com.pingan.pafa.stp.wesso;

import java.security.Principal;

public class UserPrincipal implements Principal,java.io.Serializable{
	
	private static ThreadLocal<Principal> local=new ThreadLocal<Principal>();
	
	public static Principal get(){
		return local.get();
	} 
	
	public static Principal get(boolean required){
		Principal up= local.get();
		if(up==null && required){
			throw new WeSSOException("Not found UserPrincipal in threadLocal, OR user logouted,OR user timeouted.");
		}
		return up;
	} 
	
	public static String getUserName(){
		Principal up=get();
		return up==null?null:up.getName();
	}
	
	public static void set(Principal userPrincipal){
		 local.set(userPrincipal);
	} 
	
	public static void clear(){
		 local.remove();
	} 

	private static final long serialVersionUID = 1L;
	
	

	private long createTimestamp; 
	
	private String sessionId;
	
	private String user;
	
	private  String lastAppName;
	
	private long lastAccTime;
	
	private String clientIp;
	
	public UserPrincipal(){}
	
	public UserPrincipal(String user){
		this.user=user;
	}
	
	@Override
	public String getName() {
		return user;
	}

	public boolean isInvalid(int expiresTime){
		long t2=createTimestamp+expiresTime*1000;
		return System.currentTimeMillis()>t2;
	}

	public String getUser() {
		return user;
	}
	
	

	@Override
	public String toString() {
		return "UserPrincipal@"+user;
	}

	public long getCreateTimestamp() {
		return createTimestamp;
	}

	public String getSessionId() {
		return sessionId;
	}

	
	

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}

	public String getLastAppName() {
		return lastAppName;
	}

	public void setLastAppName(String lastAppName) {
		this.lastAppName = lastAppName;
	}

	public long getLastAccTime() {
		return lastAccTime;
	}

	public void setLastAccTime(long lastAccTime) {
		this.lastAccTime = lastAccTime;
	}

	public String getClientIp() {
		return clientIp;
	}

	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}

	public void setCreateTimestamp(long createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	public void setUser(String user) {
		this.user = user;
	}
	
	
}
