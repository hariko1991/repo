package com.pingan.pafa.stp.wesession;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface WeSession  {

	 boolean isEnabled();
	 
	 String getId(HttpServletRequest request, HttpServletResponse response);
		
	 String createId(HttpServletRequest request,
				HttpServletResponse response);
	 
	 UserSession getSession(HttpServletRequest request,
				HttpServletResponse response,boolean create);
	 
	 boolean destroySession(HttpServletRequest request,
				HttpServletResponse response,UserSession session);
	 
	 
}
