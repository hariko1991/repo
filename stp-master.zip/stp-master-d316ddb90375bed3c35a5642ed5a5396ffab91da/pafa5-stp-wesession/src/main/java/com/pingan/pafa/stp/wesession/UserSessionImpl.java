package com.pingan.pafa.stp.wesession;

import java.util.Enumeration;
import java.util.Iterator;
import java.util.Set;

import javax.servlet.ServletContext;
import javax.servlet.http.HttpSession;
import javax.servlet.http.HttpSessionContext;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.pingan.pafa.redis.map.RedisMap;

public class UserSessionImpl implements UserSession,HttpSession{
	
	protected static Log logger=LogFactory.getLog(UserSessionImpl.class);
	
	
	private RedisMap<String,Object> attributes;
	
	private String sessionId;
	
	private boolean isNew;
	
	
	public UserSessionImpl(RedisMap<String,Object> attributes,String sessionId
			,boolean isNew){
		this.attributes=attributes;
		this.sessionId=sessionId;
		this.isNew=isNew;
	}

	@Override
	public Object getAttribute(String attrKey) {
		if(attrKey==null || (attrKey=attrKey.trim()).length()==0){
			throw new java.lang.IllegalArgumentException("attrKey requried.");
		}
		if(logger.isDebugEnabled()){
			logger.debug("GetAttribute<"+attrKey+"> by "+attributes.getId());
		}
		return attributes.get( attrKey);
	}

	@Override
	public void setAttribute(String attrKey, Object attrValue) {
		if(attrKey==null || (attrKey=attrKey.trim()).length()==0){
			throw new java.lang.IllegalArgumentException("attrKey requried.");
		}
		if(logger.isInfoEnabled()){
			logger.info("SetAttribute<"+attrKey+">...");
		}
		attributes.put(attrKey, attrValue);
	}

	@Override
	public void removeAttribute(String attrKey) {
		Object result=attributes.remove(attrKey);
		if(logger.isDebugEnabled()){
			logger.debug("removeAttribute<"+attrKey+">="+(result!=null)+" by "+attributes.getId());
		}
	}

	@Override
	public boolean containsAttribute(String attrKey) {
		boolean result=this.attributes.containsKey(attrKey);
		if(logger.isDebugEnabled()){
			logger.debug("containsAttribute<"+attrKey+">="+result+" by "+attributes.getId());
		}
		return result;
	}

	
	
	@Override
	public boolean destroy() {
		return this.attributes.destroy();
	}

	@Override
	public long getCreationTime() {
		throw new UnsupportedOperationException("Not support method:getCreationTime");
	}

	@Override
	public String getId() {
		return sessionId;
	}

	@Override
	public long getLastAccessedTime() {
		throw new UnsupportedOperationException("Not support method:getLastAccessedTime");
	}

	@Override
	public ServletContext getServletContext() {
		throw new UnsupportedOperationException("Not support method:getServletContext");
	}

	@Override
	public void setMaxInactiveInterval(int paramInt) {
		throw new UnsupportedOperationException("Not support method:setMaxInactiveInterval");
	}

	@Override
	public int getMaxInactiveInterval() {
		throw new UnsupportedOperationException("Not support method:getMaxInactiveInterval");
	}

	@Override
	public HttpSessionContext getSessionContext() {
		throw new UnsupportedOperationException("Not support method:getSessionContext");
	}

	@Override
	public Object getValue(String name) {
		throw new UnsupportedOperationException("Not support method:getValue");
	}

	@Override
	public Enumeration<String> getAttributeNames() {
		Set<String> names=attributes.keySet();
		if(names==null){
			return null;
		}
		final Iterator<String> i=names.iterator();
		Enumeration<String> e=new Enumeration<String>(){
			@Override
			public boolean hasMoreElements() {
				return i.hasNext();
			}

			@Override
			public String nextElement() {
				return i.next();
			}
		};
		return e;
	}

	@Override
	public String[] getValueNames() {
		throw new UnsupportedOperationException("Not support method:getValueNames");
	}

	@Override
	public void putValue(String name, Object value) {
		throw new UnsupportedOperationException("Not support method:putValue");
	}

	@Override
	public void removeValue(String name) {
		throw new UnsupportedOperationException("Not support method:removeValue");
	}
	
	private boolean invalidate;

	@Override
	public void invalidate() {
		invalidate=true;
	}

	public boolean isInvalidate() {
		return invalidate;
	}

	@Override
	public boolean isNew() {
		return isNew;
	}

	

	
}
