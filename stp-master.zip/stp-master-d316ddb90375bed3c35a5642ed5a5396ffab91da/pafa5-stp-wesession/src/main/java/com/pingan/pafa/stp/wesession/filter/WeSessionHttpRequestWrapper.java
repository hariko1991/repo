package com.pingan.pafa.stp.wesession.filter;

import java.io.IOException;
import java.security.Principal;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletRequestWrapper;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pingan.pafa.stp.wesession.UserSession;
import com.pingan.pafa.stp.wesession.WeSession;
import com.pingan.pafa.stp.wesso.UserPrincipal;
import com.pingan.pafa.stp.wesso.WeSSO;

public class WeSessionHttpRequestWrapper extends HttpServletRequestWrapper {
	
	private UserPrincipal userPrincipal;
	
	private WeSSO wesso;
	
	private WeSession wesession;
	
	private HttpServletResponse response;
	

	public WeSessionHttpRequestWrapper(HttpServletRequest request
			,HttpServletResponse response,WeSSO wesso,WeSession wesession){
		super(request);
		this.wesso=wesso;
		this.response=response;
		this.wesession=wesession;
	}

	@Override
	public boolean authenticate(HttpServletResponse response)
			throws IOException, ServletException {
		throw new  java.lang.UnsupportedOperationException("Not support method:authenticate");
	}

	@Override
	public String getAuthType() {
		throw new  java.lang.UnsupportedOperationException("Not support method:getAuthType");
	}

	@Override
	public String getRemoteUser() {
		Principal userPrincipal=getUserPrincipal();
		return userPrincipal==null?null:userPrincipal.getName();
	}
	
	private String sessionId;
	
	@Override
	public String getRequestedSessionId() {
		if(sessionId==null && wesession!=null){
			sessionId=wesession.getId((HttpServletRequest)getRequest(), response);
			if(sessionId==null){
				sessionId="";
			}
		}
		return sessionId==null?null:(sessionId.length()==0?null:sessionId);
	}

	@Override
	public Principal getUserPrincipal() {
		if(wesso!=null && wesso.isEnabled()){
			if(userPrincipal==null){
				String sessionId=getRequestedSessionId();
				if(sessionId!=null){
					userPrincipal=wesso.getUserPrincipal(this, response);
				}
			}
			return userPrincipal;
		}else{
			return super.getUserPrincipal();
		}
		
	}

	@Override
	public boolean isRequestedSessionIdFromCookie() {
		return false;
	}

	@Override
	public boolean isRequestedSessionIdFromURL() {
		return false;
	}

	@Override
	public boolean isRequestedSessionIdFromUrl() {
		return false;
	}

	@Override
	public boolean isRequestedSessionIdValid() {
		return true;
	}

	@Override
	public boolean isUserInRole(String role) {
		throw new  java.lang.UnsupportedOperationException("Not support method:isUserInRole");
	}

	@Override
	public void login(String username, String password) throws ServletException {
		throw new  java.lang.UnsupportedOperationException("Not support method:login");
	}

	@Override
	public void logout() throws ServletException {
		throw new  java.lang.UnsupportedOperationException("Not support method:logout");
	}

	@Override
	public HttpSession getSession() {
		return getSession(true);
	}
	
	private UserSession userSession;

	@Override
	public HttpSession getSession(boolean create) {
		if(userSession!=null){
			return (HttpSession)userSession;
		}
		if(wesession!=null && wesession.isEnabled()){
			userSession=wesession.getSession((HttpServletRequest)getRequest()
					, response, create);
			if(userSession!=null){
				this.sessionId=userSession.getId();
			}
		}
		return (HttpSession)userSession;
	}
	
	
	
	public void destory(){
		if(userSession!=null && userSession.isInvalidate()){
			this.wesession.destroySession((HttpServletRequest)getRequest(), response,userSession);
			if(wesso!=null && wesso.isEnabled()){
				this.wesso.logout((HttpServletRequest)getRequest(), response);
			}
		}
		this.userSession=null;
		this.wesession=null;
		this.response=null;
		this.wesso=null;
		this.userPrincipal=null;
	}
	
	
}
