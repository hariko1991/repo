package com.pingan.pafa.stp.wesession;


public class WeSessionConfig {

	
	/***
     * 默认的过期时间，24小时
     * @see #expiresTime
     */
    private static final int    DEFAULT_CACHE_EXPIRES_TIME  = 60 * 60;
    
	
	private String sessionIdKeyName="PAFA5-WESESSION";
	
	private boolean isEnabled=true;
	
	private boolean  cookieEnable=true;
	
	private boolean cookieMainDomainEnable;
	
	 private boolean  destoryCookieOnCacheExpired = true;

	
	private String cookieDomain;

	private String cookiePath;
	
	
	private boolean refreshExpiresTime=true;
	
	

	private String sessionIdPattern="^[\\w\\-\\.]{16,}$";
	
	
	private int cacheRefreshInterval=2000;


    /***
     * 缓存数据过期时间，单位秒
     */
    private int      cacheExpiresTime            = DEFAULT_CACHE_EXPIRES_TIME;
    
   
	
	

	public String getCookiePath() {
		return cookiePath;
	}

	public void setCookiePath(String cookiePath) {
		this.cookiePath = cookiePath;
	}

	

	public int getCacheExpiresTime() {
		return cacheExpiresTime;
	}

	public void setCacheExpiresTime(int cacheExpiresTime) {
		this.cacheExpiresTime = cacheExpiresTime;
	}

	@Override
	public String toString() {
	
		return "sessionIdKeyName="+sessionIdKeyName
				//+",appName="+appName
				+",cacheExpiresTime="+cacheExpiresTime
				+",refreshExpiresTime="+refreshExpiresTime
				+",cookieEnable="+cookieEnable
				+",cookieMainDomainEnable="+cookieMainDomainEnable
				+",cookiePath="+cookiePath
				+",destoryCookieOnCacheExpired="+destoryCookieOnCacheExpired
				+",cookieDomain="+cookieDomain
				+",sessionIdPattern="+sessionIdPattern;
	}

	public boolean isCookieEnable() {
		return cookieEnable;
	}

	public void setCookieEnable(boolean cookieEnable) {
		this.cookieEnable = cookieEnable;
	}

	public boolean isCookieMainDomainEnable() {
		return cookieMainDomainEnable;
	}

	public void setCookieMainDomainEnable(boolean cookieMainDomainEnable) {
		this.cookieMainDomainEnable = cookieMainDomainEnable;
	}

	/*public String getAppName() {
		return appName;
	}

	public void setAppName(String appName) {
		this.appName = appName;
	}*/


	public boolean isEnabled() {
		return isEnabled;
	}

	public void setEnabled(boolean isEnabled) {
		this.isEnabled = isEnabled;
	}

	public String getCookieDomain() {
		return cookieDomain;
	}

	public void setCookieDomain(String cookieDomain) {
		this.cookieDomain = cookieDomain;
	}

	public String getSessionIdKeyName() {
		return sessionIdKeyName;
	}

	public void setSessionIdKeyName(String sessionIdKeyName) {
		this.sessionIdKeyName = sessionIdKeyName;
	}

	public String getSessionIdPattern() {
		return sessionIdPattern;
	}

	public void setSessionIdPattern(String sessionIdPattern) {
		this.sessionIdPattern = sessionIdPattern;
	}

	public boolean isDestoryCookieOnCacheExpired() {
		return destoryCookieOnCacheExpired;
	}

	public void setDestoryCookieOnCacheExpired(boolean destoryCookieOnCacheExpired) {
		this.destoryCookieOnCacheExpired = destoryCookieOnCacheExpired;
	}

	public boolean isRefreshExpiresTime() {
		return refreshExpiresTime;
	}

	public void setRefreshExpiresTime(boolean refreshExpiresTime) {
		this.refreshExpiresTime = refreshExpiresTime;
	}

	public int getCacheRefreshInterval() {
		return cacheRefreshInterval;
	}

	public void setCacheRefreshInterval(int cacheRefreshInterval) {
		this.cacheRefreshInterval = cacheRefreshInterval;
	}

	
}
