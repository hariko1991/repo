package com.pingan.pafa.stp.wesession.filter;

import org.springframework.core.MethodParameter;
import org.springframework.web.bind.support.WebArgumentResolver;
import org.springframework.web.context.request.NativeWebRequest;

import com.paic.pafa.utils.MDCUtil;
import com.paic.pafa.web.session.Uid;
import com.pingan.pafa.papp.exception.ResponseCodeException;

public class UidArgumentResolver implements  WebArgumentResolver {
	
	private boolean  log4jContextEnable=false;
	
	private String errorResponseCode="900106";
	
	private String errorResponseMsg="User not logined or timeouted.";
	

	@Override
	public Object resolveArgument(MethodParameter methodParameter,
			NativeWebRequest webRequest) throws Exception {
		Uid annotation=methodParameter.getParameterAnnotation(Uid.class);
		if(annotation!=null){
			String uid= webRequest.getRemoteUser();
			if(uid!=null && (uid=uid.trim()).length()>0){
				if(log4jContextEnable){
					MDCUtil.peek().setUid(uid);
				}
			}else{
				uid=null;
			}
			if(uid==null && annotation.value()){
				throw new ResponseCodeException(this.getErrorResponseCode(),this.getErrorResponseMsg());
			}
			return uid;
		}
		return UNRESOLVED;
	}


	public boolean isLog4jContextEnable() {
		return log4jContextEnable;
	}


	public void setLog4jContextEnable(boolean log4jContextEnable) {
		this.log4jContextEnable = log4jContextEnable;
	}


	public String getErrorResponseCode() {
		return errorResponseCode;
	}


	public void setErrorResponseCode(String errorResponseCode) {
		this.errorResponseCode = errorResponseCode;
	}


	public String getErrorResponseMsg() {
		return errorResponseMsg;
	}


	public void setErrorResponseMsg(String errorResponseMsg) {
		this.errorResponseMsg = errorResponseMsg;
	}


	


}
