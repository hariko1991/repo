package com.pingan.pafa.stp.wesso;


public class WeSSOException  extends RuntimeException {
	
	private static final long serialVersionUID = 1L;
	
	public WeSSOException(String msg){
		super(msg);
	}
	public WeSSOException(String msg,Throwable ex){
		super(msg,ex);
	}
}
