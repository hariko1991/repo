package com.pingan.pafa.stp.wesso;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public interface WeSSO {
	
	
	 /**
     * 缓存HTTPSession使用的Key
     * */
    public static final String ATTR_KEY_PRINCIAL          = "WESSO_USER_PRINCIPAL";
    
    boolean isEnabled();
    
	void logout(HttpServletRequest request, HttpServletResponse response);
	
	UserPrincipal login(HttpServletRequest request, HttpServletResponse response,UserPrincipal principal);

	UserPrincipal login(HttpServletRequest request, HttpServletResponse response,String user);

	
	UserPrincipal getUserPrincipal(HttpServletRequest request, HttpServletResponse response);


}
