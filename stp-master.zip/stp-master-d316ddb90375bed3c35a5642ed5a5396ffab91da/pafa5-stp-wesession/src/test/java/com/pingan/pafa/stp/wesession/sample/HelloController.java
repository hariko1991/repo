package com.pingan.pafa.stp.wesession.sample;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.web.BaseController;

@Controller
public class HelloController extends BaseController {
	
	@ResponseBody
	@RequestMapping("/setName")
	public  ModelMap set(@RequestParam("name") String name,HttpSession session){
		//保存对象
		session.setAttribute("name", name);
		if(logger.isInfoEnabled()){
			//获取对象
			logger.info("name="+name);
			logger.info("sessionId="+session.getId());
		}
		ModelMap model=new ModelMap();
		model.put("responseCode", "0");
		return model;
	}

	@ResponseBody
	@RequestMapping("/getName")
	public  ModelMap hello(HttpSession session){
		String name=(String)session.getAttribute("name");
		if(logger.isInfoEnabled()){
			//获取对象
			logger.info("name="+name);
			logger.info("sessionId="+session.getId());
		}
		String msg="Hello,"+name;
		ModelMap model=new ModelMap();
		model.put("responseCode", "0");
		model.put("message", msg);
		return model;
	}

	
}
