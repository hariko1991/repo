package com.pingan.pafa.stp.wesso;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.junit.Assert;
import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa.stp.wesession.WeSession;
import com.pingan.pafa.stp.wesession.filter.WeSessionHttpRequestWrapper;

@SARContextConfiguration(sarList="wesso_sample")
public class WeSSOTests  extends BaseSARTest{
	
	@Resource(name="wesso")
	private WeSSO wesso;
	
	@Autowired
	private WeSession wesession;
	
	private static String sessionId;
	
	
	private String cookieName="PAFA5-WESESSION";
	
	@Test
	public void test1() throws Exception{
		
		MockHttpServletResponse response=this.createMockResponse();
		HttpServletRequest request=this.createMockRequest("request1");
		request=new WeSessionHttpRequestWrapper(request,response,wesso,wesession);
		wesso.login(request, response, "lixingnan945");
		Cookie cookie=response.getCookie(cookieName);
		sessionId=cookie.getValue();
		logger.info("sessionId="+sessionId);
	}
	
	@Test
	public void test2() throws Exception{
		MockHttpServletRequest mockRequest=this.createMockRequest("request2");
		mockRequest.addHeader(cookieName, sessionId);
		MockHttpServletResponse response=this.createMockResponse();
		HttpServletRequest request=new WeSessionHttpRequestWrapper(mockRequest,response,wesso,wesession);
		UserPrincipal up=wesso.getUserPrincipal(request,response);
		logger.info("UserPrincipal="+up);
		Assert.assertEquals(up.getSessionId(), sessionId);
		Assert.assertEquals(up.getName(), "lixingnan945");
	}
	
	@Test
	public void test3() throws Exception{
		MockHttpServletRequest mockRequest=this.createMockRequest("request3");
		mockRequest.addHeader(cookieName, sessionId);
		MockHttpServletResponse response=this.createMockResponse();
		HttpServletRequest request=new WeSessionHttpRequestWrapper(mockRequest,response,wesso,wesession);
		wesso.logout(request, response);
		UserPrincipal up=wesso.getUserPrincipal(request,response);
		logger.info("UserPrincipal="+up);
		Assert.assertNull(up);
	}
	
}
