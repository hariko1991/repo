package com.pingan.pafa.stp.wesession.sample;

import javax.servlet.http.Cookie;

import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="wesession_sample")
public class HelloControllerTests  extends BaseSARTest{
	
	private static String sessionId;
	
	
	private String cookieName="PAFA5-WESESSION";

	@Test
	public void test1() throws Exception{
		MockHttpServletResponse response=this.createMockResponse();
		String result=this.handleWebRequest(this.createMockRequest("/setName","name=nangua")
				,response);
		Cookie cookie=response.getCookie(cookieName);
		sessionId=cookie.getValue();
		logger.info("sessionId="+sessionId);
		logger.info(result);
	}
	
	@Test
	public void test2() throws Exception{
		MockHttpServletRequest mockRequest=this.createMockRequest("/getName");
		mockRequest.addHeader(cookieName, sessionId);
		String result=this.handleWebRequest(mockRequest
				,this.createMockResponse());
		logger.info(result);
	}
	
}
