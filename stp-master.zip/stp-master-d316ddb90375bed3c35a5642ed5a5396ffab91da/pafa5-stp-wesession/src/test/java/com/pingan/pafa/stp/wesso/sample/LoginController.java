package com.pingan.pafa.stp.wesso.sample;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.stp.wesso.WeSSO;

@Controller
public class LoginController extends BaseController {
	
	@Resource(name="wesso")
	private WeSSO wesso;
	
	@ResponseBody
	@RequestMapping("/login.do")
	public  ModelMap hello(@RequestParam("name") String name
			,HttpServletRequest request
			, HttpServletResponse response){
		if(logger.isInfoEnabled()){
			logger.info("name="+name);
		}
		//登陆
		wesso.login(request, response,name);
		ModelMap model=new ModelMap();
		model.put("responseCode", "0");
		model.put("user", name);
		return model;
	}

	public WeSSO getWesso() {
		return wesso;
	}

	public void setWesso(WeSSO wesso) {
		this.wesso = wesso;
	}
	
	
}
