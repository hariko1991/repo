package com.pingan.pafa.stp.wesession;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;



@SARContextConfiguration(sarList="wesession_sample",protocols="jetty")
public class SARTests extends BaseSARTest{

	@Test
	public void iz() throws Throwable{
		System.in.read();
	}
	
}
