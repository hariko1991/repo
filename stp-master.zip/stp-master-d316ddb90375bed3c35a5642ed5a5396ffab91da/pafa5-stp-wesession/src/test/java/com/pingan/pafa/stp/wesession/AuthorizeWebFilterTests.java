package com.pingan.pafa.stp.wesession;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="wesession_sample")
public class AuthorizeWebFilterTests extends BaseSARTest{

	
	@Test
	public void test1() throws Exception{
		String result=this.handleWebRequest(this.createMockRequest("/muser/test.do")
				,this.createMockResponse());
		logger.info(result);
	}
	
}
