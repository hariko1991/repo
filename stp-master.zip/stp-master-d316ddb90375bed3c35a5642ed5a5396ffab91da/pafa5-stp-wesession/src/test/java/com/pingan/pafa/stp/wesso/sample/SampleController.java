package com.pingan.pafa.stp.wesso.sample;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.web.BaseController;
import com.paic.pafa.web.session.Uid;
import com.pingan.pafa.stp.wesso.UserPrincipal;

@Controller
public class SampleController extends BaseController {
	
	@ResponseBody
	@RequestMapping("/sample.do")
	public  ModelMap hello(@Uid(true) String uid){
		if(logger.isInfoEnabled()){
			logger.info("user="+uid);
		}
		String msg="Hello,"+uid;
		ModelMap model=new ModelMap();
		model.put("responseCode", "0");
		model.put("message", msg);
		return model;
	}


	@ResponseBody
	@RequestMapping("/sample1.do")
	public  ModelMap hello1(HttpServletRequest request){
		String uid=request.getRemoteUser();
		if(logger.isInfoEnabled()){
			logger.info("name="+uid);
		}
		String msg="Hello,"+uid;
		ModelMap model=new ModelMap();
		model.put("responseCode", "0");
		model.put("message", msg);
		return model;
	}
	
	@ResponseBody
	@RequestMapping("/sample2.do")
	public  ModelMap hello2(){
		String uid=UserPrincipal.getUserName();
		if(logger.isInfoEnabled()){
			logger.info("name="+uid);
		}
		String msg="Hello,"+uid;
		ModelMap model=new ModelMap();
		model.put("responseCode", "0");
		model.put("message", msg);
		return model;
	}
	
}
