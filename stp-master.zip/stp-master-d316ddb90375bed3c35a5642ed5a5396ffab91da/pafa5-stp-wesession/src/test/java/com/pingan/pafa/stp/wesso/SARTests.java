package com.pingan.pafa.stp.wesso;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="wesso_sample",protocols="jetty")
public class SARTests  extends BaseSARTest{


	@Test
	public void test() throws Exception{
		System.in.read();
	}
}
