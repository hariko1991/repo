package com.pingan.pafa.stp.wefiles.httpclient_tests;

import java.io.ByteArrayOutputStream;
import java.io.File;

import javax.annotation.Resource;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa.stp.wefiles.WefileMeta;
import com.pingan.pafa.stp.wefiles.Wefiles;


@SARContextConfiguration(sarList="pafa_stp_wefiles_httpclient_tests")
public class WefilesHttpClientsTests extends BaseSARTest{
	
	
	@Resource(name="wefiles")
	private Wefiles wefiles;
	
	
	@Test
	public void test1() throws Exception{
		File file=new File(WefilesHttpClientsTests.class.getResource(WefilesHttpClientsTests.class.getSimpleName()+".class").toURI());
		logger.info("file="+file.getAbsolutePath());
		WefileMeta meta=wefiles.upload(new WefileMeta(file.getName(),"application/object-stream"),file);
		//
		ByteArrayOutputStream baos=new ByteArrayOutputStream();
		meta=wefiles.download(meta.getFileId(), baos);
		logger.info("meta="+meta);
		logger.info("fileSize="+baos.size());
	}
	
	@Test
	public void test2() throws Exception{
		File file=new File(WefilesHttpClientsTests.class.getResource(WefilesHttpClientsTests.class.getSimpleName()+".class").toURI());
		logger.info("file="+file.getAbsolutePath());
		WefileMeta meta=new WefileMeta(file.getName(),"application/object-stream");
		String fileName="test-"+System.currentTimeMillis();
		meta.setAliasName(fileName);
		meta.setNamespace("nts-stp");
		meta=wefiles.upload(meta,file);
		//
		ByteArrayOutputStream baos=new ByteArrayOutputStream();
		meta=wefiles.downloadByAlias("nts-stp", fileName, baos);
		logger.info("meta="+meta);
		logger.info("fileSize="+baos.size());
	}
	
}
