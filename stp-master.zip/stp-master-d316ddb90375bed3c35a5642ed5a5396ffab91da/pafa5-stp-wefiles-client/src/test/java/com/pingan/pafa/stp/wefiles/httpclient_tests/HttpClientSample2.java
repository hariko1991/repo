package com.pingan.pafa.stp.wefiles.httpclient_tests;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpException;
import org.apache.http.StatusLine;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;

import com.alibaba.fastjson.JSONObject;


public class HttpClientSample2{
	

	
	private String protocol="http";
	//开发：nts-stp-gw-int.paic.com.cn
	//nts-stp.paic.com.cn/nts-stp-stg1.paic.com.cn
	//localhost
	private String servers="localhost:8080";
	
	//开发=/nts_stp，测试/生产=
	private String contextPath="/nts_stp_def";
	
	
	private String downloadURI=contextPath+"/stp_wefiles.download?";
	
	private String uploadURI=contextPath+"/stp_wefiles.upload";


	private CloseableHttpClient httpClient;
	
	private RequestConfig requestConfig;
	
	public HttpClientSample2(){
		httpClient =HttpClients.createDefault();
		requestConfig=RequestConfig.custom().setSocketTimeout(60000).setConnectTimeout(5000).build();
	}

	protected String getServerURL(){
		return this.protocol+"://"+this.servers;
	}
	

	public static void main(String args[]) throws Throwable{
		test();
	}
	
	public static void test()throws Throwable{
		File f=new File(HttpClientSample2.class.getResource(HttpClientSample2.class.getSimpleName()+".class").toURI());
		System.out.println("f="+f.getAbsolutePath());
		
		HttpClientSample2 sample=new HttpClientSample2();
		FileInputStream fis=new FileInputStream(f);
		String namespace="pafa-stp";
		String aliasName="pass-"+System.currentTimeMillis();
		
		String fileId=sample.upload(f.getName(), "application/object-stream", 0, null, new BufferedInputStream(fis)
				,namespace,aliasName);
		System.out.println("fileId="+fileId);
		sample.download(namespace,aliasName);
	}
	
	public byte[] download(String namespace,String aliasName){
		String url=getServerURL()+downloadURI+"namespace="+namespace+"&aliasName="+aliasName;
		CloseableHttpResponse response=null;
		try {
			HttpGet request = new HttpGet(url);
			request.setConfig(this.requestConfig);
			 response = httpClient.execute(request);
			//
			StatusLine status = response.getStatusLine();
			if (status != null && status.getStatusCode() >= 300) {
				throw new HttpException(
						"Did not receive successful HTTP response: status code = "
								+ status.getStatusCode()
								+ ", status message = ["
								+ status.getReasonPhrase() + "]");
			}
			InputStream input = (response == null || response.getEntity() == null ? null : response.getEntity().getContent());
			try{
				return IOUtils.toByteArray(input);
			}finally{
				if(input!=null)
				input.close();
			}
		}catch(Exception ex){
			System.err.println("Http client upload file="+aliasName+"error,cause:"+ex.getMessage());
			ex.printStackTrace(System.err);
		}finally{
			try {
				if(response!=null)response.close();
			} catch (IOException e) {
			}
		}
		return null;
		
	}
	
	/***
	 * 文件上传
	 * @param fileName 文件名
	 * @param contentType
	 * @param expiredTime 过期时间，单位秒
	 * @param charset 字符集
	 * @param fileSize 文件大小
	 * @param input 输入流
	 * @return
	 */
	public  String upload(String fileName,String contentType,int expiredTime
			,String charset,InputStream input,String namespace,String aliasName){
		String url=getServerURL()+this.uploadURI;
		CloseableHttpResponse response=null;
		try {
			HttpPost request = new HttpPost(url);
			MultipartEntityBuilder builder=MultipartEntityBuilder.create();
			if(charset!=null && (charset=charset.trim()).length()>0){
				builder.addTextBody("charset", charset);
				builder.setCharset(Charset.forName(charset));
			}
			builder.addBinaryBody("file",input,ContentType.parse(contentType), fileName);
			builder.addTextBody("expiredTime", String.valueOf(expiredTime));
			builder.addTextBody("aliasName", aliasName);
			builder.addTextBody("namespace", namespace);
			HttpEntity entity =builder.build();
			request.setEntity(entity);
			request.setConfig(this.requestConfig);
			//
			 response = httpClient.execute(request);
			StatusLine status = response.getStatusLine();
			if (status != null && status.getStatusCode() >= 300) {
				throw new HttpException(
						"Did not receive successful HTTP response: status code = "
								+ status.getStatusCode()
								+ ", status message = ["
								+ status.getReasonPhrase() + "]");
			}
			InputStream is = (response == null || response.getEntity() == null ? null : response.getEntity().getContent());
			String json=null;
			if (is != null) {
				try{
					if(charset==null || charset.length()==0){
						charset=Charset.defaultCharset().name();
					}
					json=IOUtils.toString(is, charset);
				}finally{
					is.close();
				}
			}
			if(json==null || json.length()<3){
				throw new HttpException("http response content be null.");
			}
			JSONObject jsonObject=JSONObject.parseObject(json);
			if("0".equals(jsonObject.get("responseCode"))){
				String fileId=jsonObject.getString("fileId");
				return fileId;
			}else{
				throw new HttpException("Upload error,responseCode="+jsonObject.get("responseCode")
						+",responseMsg="+jsonObject.get("responseMsg"));
			}
		}catch(Exception ex){
			System.err.println("Http client upload file="+fileName+"error,cause:"+ex.getMessage());
			ex.printStackTrace(System.err);
		}finally{
			if(response!=null)
				try {
					response.close();
				} catch (IOException e) {
				}
		}
		return null;
	      
	}
	
}
