package com.pingan.pafa.stp.wefiles;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.nio.charset.Charset;
import java.nio.charset.UnsupportedCharsetException;
import java.util.UUID;
import java.util.regex.Pattern;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.io.IOUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.util.StringUtils;

public abstract class AbstractWefiles implements Wefiles {

    protected final Log logger = LogFactory.getLog(this.getClass());

    private int downloadBufferSize = 8 * 1024;

    private int uploadBufferSize = 8 * 1024;

    private static final String NAME_PATTERN_STRING = "^[\\w\\-]+$";

    private static final Pattern NAME_PATTERN = Pattern.compile(NAME_PATTERN_STRING);

    @Override
    public final WefileMeta upload(WefileMeta meta, byte[] fileContent) {
        if (meta == null) {
            throw new NullPointerException("meta be null");
        }
        if (fileContent == null) {
            throw new NullPointerException("fileContent be null");
        }
        meta.setFileSize(fileContent.length);
        return upload(meta, new ByteArrayInputStream(fileContent));
    }

    @Override
    public final WefileMeta upload(WefileMeta meta, String fileContent) {
        if (meta == null) {
            throw new NullPointerException("meta be null");
        }
        if (fileContent == null) {
            throw new NullPointerException("fileContent be null");
        }
        String charset = meta.getCharset();
        if (charset == null || (charset = charset.trim()).length() == 0) {
            charset = Charset.defaultCharset().name();
        }
        try {
            return upload(meta, fileContent.getBytes(charset));
        } catch (UnsupportedEncodingException e) {
            throw new IllegalArgumentException("Charset error:" + e.getMessage(), e);
        }
    }

    @Override
    public final WefileMeta upload(WefileMeta meta, File file) {
        meta.setFileName(file.getName());
        InputStream fis = null;
        try {
            fis = new FileInputStream(file);
        } catch (FileNotFoundException e) {
            throw new WefileException("Upload file<" + file.getAbsolutePath() + "> error:"
                    + e.getMessage() + "", e);
        }
        try {
            this.upload(meta, fis);
            return meta;
        } finally {
            try {
                fis.close();
            } catch (IOException e) {
                throw new WefileException("Upload file<" + file.getAbsolutePath() + "> error:"
                        + e.getMessage() + "", e);
            }
        }
    }

    @Override
    public final WefileMeta upload(WefileMeta meta, InputStream input) {
        if (input == null) {
            throw new NullPointerException("input be null");
        }
        try {
            WefileUploader uploader = createUploader(meta);
            try {
                uploader.setInputStream(input);

                OutputStream output = uploader.getOutput();
                if (output != null) {
                    IOUtils.copyLarge(input, output);
                }
            } finally {
                uploader.doFinally();
            }
            String fileId = meta.getFileId();
            if (!StringUtils.hasText(fileId)) {
                throw new NullPointerException("Upload failure, not found fileId in fileMeta.");
            }
            if (logger.isInfoEnabled()) {
                logger.info("Upload completed for file=" + meta);
            }
        } catch (WefileException e) {
            throw e;
        } catch (Exception ex) {
            throw new WefileException("Uploader=" + meta + " error:" + ex.getMessage(), ex);
        }
        return meta;
    }

    public final WefileUploader createUploader(WefileMeta meta) {
        if (meta == null) {
            throw new NullPointerException("meta be null");
        }
        if (!StringUtils.hasText(meta.getFileName())) {
            throw new NullPointerException("fileName be null");
        }
        if (!StringUtils.hasText(meta.getContentType())) {
            throw new NullPointerException("contentType be null");
        }
        int expiredTime = meta.getExpiredTime();
        if (expiredTime == 0) {
            meta.setExpiredTime(WefileMeta.DEF_EXPIRED_TIME);
        } else if (expiredTime < -1) {
            throw new IllegalArgumentException("expiredTime=" + expiredTime + " error.");
        }
        String charset = meta.getCharset();
        if (charset != null && (charset = charset.trim()).length() > 0) {
            try {
                Charset.forName(charset);
            } catch (UnsupportedCharsetException ex) {
                throw new IllegalArgumentException("charset=" + charset + " error.");
            }
            meta.setCharset(charset);
        }

        String namespace = meta.getNamespace();
        if (namespace != null && (namespace = namespace.trim()).length() > 0) {
            if (!NAME_PATTERN.matcher(namespace).matches()) {
                throw new IllegalArgumentException("namespace=" + namespace + " error.");
            }
            meta.setNamespace(namespace);
        }

        String aliasName = meta.getAliasName();
        if (aliasName != null && (aliasName = aliasName.trim()).length() > 0) {
            if (!NAME_PATTERN.matcher(aliasName).matches()) {
                throw new IllegalArgumentException("aliasName=" + aliasName + " error.");
            }
            meta.setAliasName(aliasName);
        }
        meta.setFileId(null);
        if (logger.isInfoEnabled()) {
            logger.info("Create file uploader =" + meta);
        }
        try {
            return new WefileUploaderWrapper(getUploader(meta), this.getUploadBufferSize());
        } catch (WefileException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new WefileException("Create file uploader=" + meta + " error:" + ex.getMessage(),
                    ex);
        }
    }

    protected abstract WefileUploader getUploader(WefileMeta meta) throws Exception;

    protected abstract WefileDownloader getDownloader(WefileMeta meta) throws Exception;

    @Override
    public final WefileMeta download(String fileId, OutputStream output) {
        return download(fileId, new DefWefileOutput(output));
    }

    @Override
    public final WefileMeta download(String fileId, final HttpServletResponse response) {
        return download(fileId, new HttpResponseWefileOutput(response));
    }

    @Override
    public WefileMeta downloadByAlias(String namespace, String aliasName,
            HttpServletResponse response) {
        return downloadByAlias(namespace, aliasName, new HttpResponseWefileOutput(response));
    }

    @Override
    public WefileMeta downloadByAlias(String namespace, String aliasName, OutputStream output) {
        if (namespace == null || (namespace = namespace.trim()).length() == 0) {
            throw new NullPointerException("namespace is null");
        }
        if (aliasName == null || (aliasName = aliasName.trim()).length() == 0) {
            throw new NullPointerException("aliasName is null");
        }
        WefileMeta meta = new WefileMeta();
        meta.setNamespace(namespace);
        meta.setAliasName(aliasName);
        
        return download(meta, new DefWefileOutput(output));
    }

    @Override
    public String downloadToString(String fileId) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream(this.getDownloadBufferSize());
        WefileMeta meta = this.download(fileId, baos);
        String charset = meta.getCharset();
        if (charset != null && charset.length() > 0) {
            try {
                return new String(baos.toByteArray(), charset);
            } catch (UnsupportedEncodingException e) {
                throw new WefileException("Download file=" + fileId + " error:" + e.getMessage(), e);
            }
        } else {
            return new String(baos.toByteArray());
        }
    }

    @Override
    public String downloadByAliasToString(String namespace, String aliasName) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream(this.getDownloadBufferSize());
        WefileMeta meta = this.downloadByAlias(namespace, aliasName, baos);
        String charset = meta.getCharset();
        if (charset != null && charset.length() > 0) {
            try {
                return new String(baos.toByteArray(), charset);
            } catch (UnsupportedEncodingException e) {
                throw new WefileException("Download file=" + namespace + "." + aliasName
                        + " error:" + e.getMessage(), e);
            }
        } else {
            return new String(baos.toByteArray());
        }
    }

    @Override
    public byte[] downloadToBytes(String fileId) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream(this.getDownloadBufferSize());
        this.download(fileId, baos);
        return baos.toByteArray();
    }

    @Override
    public byte[] downloadByAliasToBytes(String namespace, String aliasName) {
        ByteArrayOutputStream baos = new ByteArrayOutputStream(this.getDownloadBufferSize());
        this.downloadByAlias(namespace, aliasName, baos);
        return baos.toByteArray();
    }

    @Override
    public WefileMeta downloadByAlias(String namespace, String aliasName, File toFile) {
        if (toFile == null) {
            throw new NullPointerException("toFile is null.");
        }
        if (toFile.exists() || toFile.isDirectory()) {
            throw new IllegalArgumentException("ToFile=" + toFile.getAbsolutePath()
                    + " be existed or be directory.");
        }
        try {
            toFile.getParentFile().mkdirs();
            toFile.createNewFile();
        } catch (IOException e) {
            throw new IllegalArgumentException("ToFile=" + toFile.getAbsolutePath()
                    + " create failure,cause:" + e.getMessage());
        }
        BufferedOutputStream output = null;
        try {
            output = new BufferedOutputStream(new FileOutputStream(toFile));
            return downloadByAlias(namespace, aliasName, output);
        } catch (FileNotFoundException e) {
            throw new WefileException("Download file=" + namespace + "." + aliasName + " to local="
                    + toFile.getAbsolutePath() + " error:" + e.getMessage(), e);
        } finally {
            if (output != null) {
                try {
                    output.flush();
                    output.close();
                } catch (IOException e) {
                }
            }
        }
    }

    @Override
    public WefileMeta download(String fileId, File toFile) {
        if (toFile == null) {
            throw new NullPointerException("toFile is null.");
        }
        if (toFile.exists() || toFile.isDirectory()) {
            throw new IllegalArgumentException("ToFile=" + toFile.getAbsolutePath()
                    + " be existed or be directory.");
        }
        try {
            toFile.getParentFile().mkdirs();
            toFile.createNewFile();
        } catch (IOException e) {
            throw new IllegalArgumentException("ToFile=" + toFile.getAbsolutePath()
                    + " create failure,cause:" + e.getMessage());
        }
        BufferedOutputStream output = null;
        try {
            output = new BufferedOutputStream(new FileOutputStream(toFile));
            return download(fileId, output);
        } catch (FileNotFoundException e) {
            throw new WefileException("Download file=" + fileId + " to local="
                    + toFile.getAbsolutePath() + " error:" + e.getMessage(), e);
        } finally {
            if (output != null) {
                try {
                    output.flush();
                    output.close();
                } catch (IOException e) {
                }
            }
        }
    }

    protected final WefileDownloader createDownloader(WefileMeta meta) throws Exception {
        String fileId = meta.getFileId();
        if (fileId != null && !NAME_PATTERN.matcher(fileId).matches()) {
            throw new IllegalArgumentException("fileId=" + fileId + " format error.");
        }
        if (fileId == null) {
            String namespace = meta.getNamespace();
            if (namespace != null && (namespace = namespace.trim()).length() > 0) {
                if (!NAME_PATTERN.matcher(namespace).matches()) {
                    throw new IllegalArgumentException("namespace=" + namespace + " format error.");
                }
                meta.setNamespace(namespace);
            }
            // -------------------------------------
            String aliasName = meta.getAliasName();
            if (aliasName != null && (aliasName = aliasName.trim()).length() > 0) {
                if (!NAME_PATTERN.matcher(aliasName).matches()) {
                    throw new IllegalArgumentException("aliasName=" + aliasName + " format error.");
                }
                meta.setAliasName(aliasName);
            }
        }

        String fid = meta.resolveFileId();
        if (fid == null || (fid = fid.trim()).length() == 0) {
            throw new NullPointerException("fileId required.");
        }
        if (logger.isInfoEnabled()) {
            logger.info("Download file=" + fid);
        }
        WefileDownloader downloader = getDownloader(meta);
        if (downloader == null) {
            throw new FileNotFoundException("Not found file<" + fid + ">.");
        }
        return new WefileDownloaderWrapper(downloader, this.getDownloadBufferSize());
    }

    public final WefileMeta download(String fileId, WefileOutput output) {
        WefileMeta meta = new WefileMeta();
        meta.setFileId(fileId);
        return download(meta, output);
    }

    public final WefileMeta downloadByAlias(String namespace, String aliasName, WefileOutput output) {
        WefileMeta meta = new WefileMeta();
        meta.setAliasName(aliasName);
        meta.setNamespace(namespace);
        return download(meta, output);
    }

    public final WefileMeta download(WefileMeta meta, WefileOutput output) {
        try {
            if (output == null) {
                throw new java.lang.NullPointerException("output required.");
            }
            WefileDownloader downloader = createDownloader(meta);
      
            try {
                meta = downloader.getMeta();
                if (logger.isInfoEnabled()) {
                    logger.info("Download file,meta=" + meta);
                }
                
                output.handleMeta(meta);
                
                OutputStream outputStream = output.getOutputStream();
                if (outputStream == null) {
                    throw new NullPointerException("outputstream required.");
                }
                InputStream fis = downloader.getInputStream();
                if (fis != null) {
                    IOUtils.copyLarge(fis, outputStream);
                } else {
                    throw new NullPointerException("InputStream required.");
                }
            } finally {
                downloader.doFinally();
            }
            return meta;
        } catch (WefileException ex) {
            throw ex;
        } catch (Exception ex) {
            throw new WefileException("Download file:" + meta.resolveFileId() + " error:"
                    + ex.getMessage(), ex);
        }
    }

    protected String generateNewFileId() {
        char[] ticket = UUID.randomUUID().toString().toCharArray();
        StringBuilder sb = new StringBuilder(ticket.length);
        for (int i = 0; i < ticket.length; i++) {
            if (ticket[i] != '-') {
                sb.append(ticket[i]);
            }
        }
        String fileId = "F" + sb;
        if (logger.isInfoEnabled()) {
            logger.info("GenerateNewFileId=" + fileId);
        }
        return fileId;
    }

    public int getDownloadBufferSize() {
        return downloadBufferSize;
    }

    public void setDownloadBufferSize(int downloadBufferSize) {
        this.downloadBufferSize = downloadBufferSize;
    }

    public int getUploadBufferSize() {
        return uploadBufferSize;
    }

    public void setUploadBufferSize(int uploadBufferSize) {
        this.uploadBufferSize = uploadBufferSize;
    }

}
