package com.pingan.pafa.stp.wefiles.httpclient;

import com.pingan.pafa.exception.Pafa5Exception;

public class HttpClientFileException extends Pafa5Exception {

    private static final long serialVersionUID = -1174121651742312348L;

    public HttpClientFileException(String msg) {
        super(msg);
    }

    public HttpClientFileException(String msg, Throwable th) {
        super(msg, th);
    }

}
