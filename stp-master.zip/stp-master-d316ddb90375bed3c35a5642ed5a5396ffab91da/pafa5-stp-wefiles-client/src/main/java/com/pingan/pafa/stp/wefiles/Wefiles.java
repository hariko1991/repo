package com.pingan.pafa.stp.wefiles;

import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.http.HttpServletResponse;

public interface Wefiles {

	/**
	 * 上传文件
	 * @param meta 文件描述信息
	 * @param input 文件内容input
	 */
	public WefileMeta upload(WefileMeta meta,InputStream input);
	
	/**
	 * 上传文件
	 * @param meta 文件描述信息
	 * @param input 文件内容（bytes）
	 */
	public WefileMeta upload(WefileMeta meta,byte[] fileContent);
	
	/**
	 * 上传文件
	 * @param meta 文件描述信息
	 * @param input 文件内容（string）
	 */
	public WefileMeta upload(WefileMeta meta,String fileContent);
	
	/**
	 * 上传文件
	 * @param meta 文件描述信息
	 * @param file 本地文件
	 */
	public WefileMeta upload(WefileMeta meta,File file);
	
	/***
	 * 文件下载
	 * @param fileId 文件ID
	 * @param output 文件输出目标(outputStream)
	 * @return 文件描述信息
	 */
	public WefileMeta download(String fileId,OutputStream output) ;
	
	/**
	 * 
	 * @param namespace
	 * @param aliasName
	 * @param output
	 * @return
	 */
	public WefileMeta downloadByAlias(String namespace,String aliasName,OutputStream output) ;
	
	/***
	 * 文件下载
	 * @param fileId 文件ID
	 * @param toFile 文件输出目标文件
	 * @return 文件描述信息
	 */
	public WefileMeta download(String fileId,File  toFile) ;
	
	/**
	 * 
	 * @param namespace
	 * @param aliasName
	 * @param toFile
	 * @return
	 */
	public WefileMeta downloadByAlias(String namespace,String aliasName,File  toFile) ;
	
	/**
	 * 文件下载
	 * @param fileId 文件ID
	 * @return 文件内容(String)
	 */
	public String downloadToString(String fileId) ;
	
	/**
	 * 
	 * @param namespace
	 * @param aliasName
	 * @return
	 */
	public String downloadByAliasToString(String namespace,String aliasName) ;
	
	/**
	 * 文件下载
	 * @param fileId 文件ID
	 * @return 文件内容(Bytes)
	 */
	public byte[] downloadToBytes(String fileId) ;
	
	/**
	 * 
	 * @param namespace
	 * @param aliasName
	 * @return
	 */
	public byte[] downloadByAliasToBytes(String namespace,String aliasName) ;
	
	/**
	 * 文件下载内容，输出到HttpResponse
	 * @param fileId 文件ID
	 * @param response httpResponse
	 * @return 文件描述信息
	 */
	public WefileMeta download(String fileId,HttpServletResponse response);
	
	/**
	 * 
	 * @param namespace
	 * @param aliasName
	 * @param response
	 * @return
	 */
	public WefileMeta downloadByAlias(String namespace,String aliasName,HttpServletResponse response);
	
}
