package com.pingan.pafa.stp.wefiles;

import java.io.IOException;
import java.io.OutputStream;

public class BufferedOutputStream extends java.io.BufferedOutputStream {

    private int totalSize = 0;

    public BufferedOutputStream(OutputStream out) {
        super(out);
    }

    public BufferedOutputStream(OutputStream out, int bufferSize) {
        super(out, bufferSize);
    }

    @Override
    public synchronized void write(int b) throws IOException {
        super.write(b);
        totalSize++;
    }

    @Override
    public synchronized void write(byte[] b, int off, int len) throws IOException {
        super.write(b, off, len);
        totalSize += len;
    }

    public int getTotalSize() {
        return totalSize;
    }

}
