package com.pingan.pafa.stp.wefiles;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

public class WefileMeta implements java.io.Serializable {

    private static final long serialVersionUID = -8229298582010829025L;
    
    public static final int DEF_EXPIRED_TIME = 15 * 24 * 60 * 60; //15天

    // http content-type
    private String contentType;

    // 存储命名空间
    private String namespace;

    // 真实文件名
    private String fileName;

    // 文件ID
    private String fileId;

    // 文件别名
    private String aliasName;

    // 过期截止时间
    private Date expiredDate;

    // 过期时间，0使用默认值，-1永不过期，单位：秒
    private int expiredTime;

    // 文件大小，单位byte
    private int fileSize = -1;

    // 文本文件的字符编码
    private String charset;

    // 文件创建日期
    private Date createTime;

    public WefileMeta() {}

    public WefileMeta(String fileName, String contentType) {
        this.fileName = fileName;
        this.contentType = contentType;
    }

    public WefileMeta(String fileName, String contentType, int expiredTime) {
        this.fileName = fileName;
        this.contentType = contentType;
        setExpiredTime(expiredTime);
    }

    public String toString() {
        return "{"
                + "contentType="
                + contentType
                + ",filename="
                + fileName
                + ",fileId="
                + fileId
                + ",expiredDate="
                + (expiredDate == null ? null : new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                        .format(expiredDate))
                + ",createTime="
                + (createTime == null ? null : new SimpleDateFormat("yyyy-MM-dd HH:mm:ss")
                        .format(createTime)) + ",expiredTime=" + expiredTime + "s" + ",fileSize="
                + fileSize + ",charset=" + charset + ",namespace=" + namespace + ",aliasName="
                + this.aliasName + "}";
    }

    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileId() {
        return fileId;
    }

    public String resolveFileId() {
        String fid = this.fileId;
        if (fid == null) {
            if (namespace != null && aliasName != null) {
                fid = namespace + "." + aliasName;
            }
        }
        return fid;
    }

    public String resolveAliasId() {
        String aliasId = null;
        if (namespace != null && aliasName != null) {
            aliasId = namespace + "." + aliasName;
        }
        return aliasId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public Date getExpiredDate() {
        return expiredDate;
    }

    public void setExpiredDate(Date expiredDate) {
        this.expiredDate = expiredDate;
    }

    public int getExpiredTime() {
        return expiredTime;
    }

    public void setExpiredTime(int expiredTime) {
        if (expiredTime == 0) {
            expiredTime = DEF_EXPIRED_TIME;
        }
        this.expiredTime = expiredTime;
        if (expiredTime < -1) {
            throw new java.lang.IllegalArgumentException("expiredTime=" + expiredTime + " error");
        } else if (expiredTime > 0) {
            Calendar date = Calendar.getInstance();
            date.add(Calendar.SECOND, expiredTime);
            this.expiredDate = date.getTime();
        }
    }

    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

    public int getFileSize() {
        return fileSize;
    }

    public void setFileSize(int fileSize) {
        this.fileSize = fileSize;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getAliasName() {
        return aliasName;
    }

    public void setAliasName(String aliasName) {
        this.aliasName = aliasName;
    }

}
