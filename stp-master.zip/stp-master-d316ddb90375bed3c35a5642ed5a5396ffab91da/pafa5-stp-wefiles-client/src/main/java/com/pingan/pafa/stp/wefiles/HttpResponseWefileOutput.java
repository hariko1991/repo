package com.pingan.pafa.stp.wefiles;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.Date;

import javax.servlet.http.HttpServletResponse;

import org.springframework.util.StringUtils;

public  class HttpResponseWefileOutput implements WefileOutput {
	
	private HttpServletResponse response;
	
	private static final String HEADER_PRAGMA = "Pragma";

	private static final String HEADER_EXPIRES = "Expires";

	private static final String HEADER_CACHE_CONTROL = "Cache-Control";

	public HttpResponseWefileOutput(HttpServletResponse response){
		this.response=response;
	}

	@Override
	public void handleMeta(WefileMeta meta) {
		String contentType=meta.getContentType();
		if(contentType!=null){
			response.setContentType(contentType);
		}
		if(StringUtils.hasText(meta.getCharset())){
			response.setCharacterEncoding(meta.getCharset());
		}
		if(meta.getFileSize()>0){
			response.setContentLength(meta.getFileSize());
		}
		if(StringUtils.hasText(meta.getFileName())){
			String fileName=null;
			try {
				String charset=response.getCharacterEncoding();
				if(charset==null || (charset=charset.trim()).length()==0){
					charset="UTF-8";
				}
				fileName = URLEncoder.encode( meta.getFileName(),charset);
			} catch (UnsupportedEncodingException e) {
			}
			response.addHeader("Content-Disposition","attachment;filename=" + fileName);
		}
		response.setHeader("wefile-fileId", meta.getFileId());
		if(meta.getAliasName()!=null){
			response.setHeader("wefile-aliasName", meta.getAliasName());
			response.setHeader("wefile-namespace", meta.getNamespace());
		}
		//清理掉缓存控制的头
		response.setHeader(HEADER_PRAGMA, "disable");
		response.setHeader(HEADER_EXPIRES, "");
		response.setHeader(HEADER_CACHE_CONTROL,"private");
		//
		Date createTime=meta.getCreateTime();
		if(createTime!=null){
			response.setDateHeader("Last-Modified", createTime.getTime());
		}
	}

	@Override
	public OutputStream getOutputStream() {
		try {
			return response.getOutputStream();
		} catch (IOException e) {
			throw new WefileException("Get http output error:"+e.getMessage(),e);
		}
	}
	
}
