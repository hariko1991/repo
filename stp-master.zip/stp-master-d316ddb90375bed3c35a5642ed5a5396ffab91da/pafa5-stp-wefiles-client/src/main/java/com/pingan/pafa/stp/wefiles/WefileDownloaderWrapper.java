package com.pingan.pafa.stp.wefiles;

import java.io.InputStream;

final class WefileDownloaderWrapper implements WefileDownloader {

    private WefileDownloader target;

    private BufferedInputStream bufferInput;

    private int bufferSize;

    public WefileDownloaderWrapper(WefileDownloader target, int bufferSize) {
        this.target = target;
        this.bufferSize = bufferSize;
    }

    @Override
    public WefileMeta getMeta() {
        WefileMeta meta = target.getMeta();
        if (meta == null) {
            throw new java.lang.IllegalStateException("Not found meta by downloader=" + target);
        }
        return meta;
    }

    @Override
    public InputStream getInputStream() {
        InputStream input = target.getInputStream();
        if (input != null && bufferInput == null) {
            bufferInput = new BufferedInputStream(input, bufferSize);
        }
        if (bufferInput == null) {
            throw new NullPointerException("Inputstream is null.");
        }
        return bufferInput;
    }

    @Override
    public void doFinally() {
        WefileMeta meta = target.getMeta();
        if (bufferInput != null) {
            int totalSize = bufferInput.getTotalSize();
            if (meta.getFileSize() <= 0) {
                meta.setFileSize(totalSize);
            } else if (meta.getFileSize() != totalSize) {
                throw new IllegalStateException("Real file size<" + totalSize
                        + "> not eqauls for assert size<" + meta.getFileSize() + ">.");
            }
        }
        target.doFinally();
    }

}
