package com.pingan.pafa.stp.wefiles;

import java.io.OutputStream;

public class DefWefileOutput implements WefileOutput {

    private OutputStream output;

    public DefWefileOutput(OutputStream output) {
        if (output == null) {
            throw new java.lang.IllegalArgumentException("arg<output> required.");
        }
        this.output = output;
    }

    @Override
    public void handleMeta(WefileMeta meta) {

    }

    @Override
    public OutputStream getOutputStream() {
        return output;
    }

}
