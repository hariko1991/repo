package com.pingan.pafa.stp.wefiles;

import java.io.InputStream;

public interface WefileDownloader {

    public WefileMeta getMeta();

    public InputStream getInputStream();

    public void doFinally();

}
