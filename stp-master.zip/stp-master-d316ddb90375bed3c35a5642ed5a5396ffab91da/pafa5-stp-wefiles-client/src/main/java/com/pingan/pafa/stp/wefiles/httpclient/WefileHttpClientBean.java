package com.pingan.pafa.stp.wefiles.httpclient;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.Arrays;
import java.util.Random;
import java.util.concurrent.TimeUnit;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpException;
import org.apache.http.StatusLine;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.impl.conn.PoolingHttpClientConnectionManager;
import org.springframework.beans.FatalBeanException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;

import com.pingan.pafa.stp.wefiles.AbstractWefiles;
import com.pingan.pafa.stp.wefiles.WefileDownloader;
import com.pingan.pafa.stp.wefiles.WefileMeta;
import com.pingan.pafa.stp.wefiles.WefileUploader;

/**
 * 
 * @author ZHANGJIAWEI370
 *
 */
public class WefileHttpClientBean extends AbstractWefiles implements InitializingBean,
        DisposableBean {

    private static final String DEF_DOWNLOAD_URI = "/stp_wefiles.download";

    private static final String DEF_UPLOAD_URI = "/stp_wefiles.upload";

    private int connTimeout = 3000;

    private int connIdleTimeout = -1;

    private boolean connStaleCheck = true;

    private int readTimeout = 50000;

    private int maxConnsPerHost = 50;

    private String protocol = "http";

    private String[] servers;

    private String contextPath;

    private String downloadURI = DEF_DOWNLOAD_URI;

    private String uploadURI = DEF_UPLOAD_URI;

    protected final Log logger = LogFactory.getLog(getClass());

    private CloseableHttpClient httpClient;

    private PoolingHttpClientConnectionManager clientConnectionManager;

    private RequestConfig requestConfig;

    private Random _serversRandom = null;

    public WefileHttpClientBean() {}

    @Override
    public void afterPropertiesSet() throws Exception {
        clientConnectionManager =
                new PoolingHttpClientConnectionManager(this.connIdleTimeout,
                        TimeUnit.MILLISECONDS);
        clientConnectionManager.setDefaultMaxPerRoute(this.maxConnsPerHost);

        httpClient = HttpClients.custom().setConnectionManager(clientConnectionManager).build();
        requestConfig = RequestConfig.custom().setConnectTimeout(this.connTimeout)
                        .setSocketTimeout(this.readTimeout)
                        .setStaleConnectionCheckEnabled(isConnStaleCheck()).build();

        try {
            if (servers == null || servers.length == 0) {
                throw new NullPointerException("servers is null");
            }
            _serversRandom = new Random();
            for (int i = 0; i < servers.length; i++) {
                new URL(this.protocol + "://" + servers[i]);
            }
        } catch (MalformedURLException exception) {
            throw new FatalBeanException("Config serverURL<" + Arrays.toString(servers)
                    + "> not be URL", exception);
        }
    }

    public CloseableHttpClient getHttpClient() {
        return httpClient;
    }

    @Override
    protected WefileUploader getUploader(WefileMeta meta) throws Exception {
        String url = resolveServerURL() + this.uploadURI;
        HttpPost request = new HttpPost(url);
        request.setConfig(this.requestConfig);
        return new WefileHttpClientUploader(meta, request, this.getHttpClient());
    }

    protected String resolveServerURL() {
        int len = servers.length;
        String server = len == 1 ? this.servers[0] : this.servers[_serversRandom.nextInt(len)];
        return this.protocol + "://" + server + (this.contextPath == null ? "" : this.contextPath);
    }

    @Override
    protected WefileDownloader getDownloader(WefileMeta meta) throws Exception {
        String fileId = meta.getFileId();
        String url = null;
        if (fileId != null) {
            url = resolveServerURL() + downloadURI + "?fileId=" + fileId;
        } else {
            url = resolveServerURL() + downloadURI + "?namespace=" + meta.getNamespace()
                            + "&aliasName=" + meta.getAliasName();
        }
        HttpGet request = new HttpGet(url);
        request.setConfig(this.requestConfig);
        CloseableHttpResponse response = httpClient.execute(request);
        
        StatusLine status = response.getStatusLine();
        if (status != null && status.getStatusCode() >= 300) {
            throw new HttpException("Did not receive successful HTTP response: status code = "
                    + status.getStatusCode() + ", status message = [" + status.getReasonPhrase()
                    + "]");
        }
        return new WefileHttpClientDownloader(meta, response);
    }



    @Override
    public void destroy() throws Exception {
        clientConnectionManager.shutdown();
        httpClient.close();
    }

    public void setConnTimeout(int connTimeout) {
        this.connTimeout = connTimeout;
    }

    public void setConnIdleTimeout(int connIdleTimeout) {
        this.connIdleTimeout = connIdleTimeout;
    }

    public boolean isConnStaleCheck() {
        return connStaleCheck;
    }

    public void setConnStaleCheck(boolean connStaleCheck) {
        this.connStaleCheck = connStaleCheck;
    }

    public void setReadTimeout(int readTimeout) {
        this.readTimeout = readTimeout;
    }

    public void setMaxConnsPerHost(int maxConnsPerHost) {
        this.maxConnsPerHost = maxConnsPerHost;
    }

    public void setDownloadURI(String downloadURI) {
        this.downloadURI = downloadURI;
    }

    public void setUploadURI(String uploadURI) {
        this.uploadURI = uploadURI;
    }

    public void setServers(String... servers) {
        this.servers = servers;
    }

    public void setProtocol(String protocol) {
        this.protocol = protocol;
    }

    public void setContextPath(String contextPath) {
        this.contextPath = contextPath;
    }

}
