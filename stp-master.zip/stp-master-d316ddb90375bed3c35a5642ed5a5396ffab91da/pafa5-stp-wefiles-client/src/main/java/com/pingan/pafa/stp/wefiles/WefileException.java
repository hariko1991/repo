package com.pingan.pafa.stp.wefiles;

import com.pingan.pafa.exception.Pafa5Exception;

public class WefileException extends Pafa5Exception {

    private static final long serialVersionUID = -3716895841949420020L;

    public WefileException(String msg) {
        super(msg);
    }

    public WefileException(String msg, Throwable th) {
        super(msg, th);
    }

}
