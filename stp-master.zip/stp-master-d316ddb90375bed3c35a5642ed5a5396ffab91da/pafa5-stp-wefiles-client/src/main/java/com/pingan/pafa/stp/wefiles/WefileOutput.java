package com.pingan.pafa.stp.wefiles;

import java.io.OutputStream;

public interface WefileOutput {

	void handleMeta(WefileMeta meta);
	
	OutputStream getOutputStream();
}
