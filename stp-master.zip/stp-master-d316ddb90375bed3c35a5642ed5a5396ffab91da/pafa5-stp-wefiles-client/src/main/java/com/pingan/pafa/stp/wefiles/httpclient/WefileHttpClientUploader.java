package com.pingan.pafa.stp.wefiles.httpclient;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.charset.Charset;

import org.apache.commons.io.IOUtils;
import org.apache.http.HttpEntity;
import org.apache.http.HttpException;
import org.apache.http.StatusLine;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.mime.MultipartEntityBuilder;
import org.apache.http.impl.client.CloseableHttpClient;

import com.alibaba.fastjson.JSONObject;
import com.pingan.pafa.stp.wefiles.WefileMeta;
import com.pingan.pafa.stp.wefiles.WefileUploader;

public class WefileHttpClientUploader implements WefileUploader {
	

	private WefileMeta meta;
	
	private HttpPost httpPost;
	
	private CloseableHttpClient httpClient;
	
	public WefileHttpClientUploader(WefileMeta meta,HttpPost httpPost,CloseableHttpClient httpClient){
		this.meta=meta;
        this.httpClient=httpClient;
        this.httpPost=httpPost;
	}

	@Override
	public void setInputStream(InputStream input) {
	
		CloseableHttpResponse response =null;
		try {
			MultipartEntityBuilder builder=MultipartEntityBuilder.create();
			String charset=meta.getCharset();
			if(charset!=null && (charset=charset.trim()).length()>0){
				builder.addTextBody("charset", meta.getCharset());
				builder.setCharset(Charset.forName(charset));
			}
			builder.addBinaryBody("file",input,ContentType.parse(meta.getContentType()), meta.getFileName());
			builder.addTextBody("expiredTime", String.valueOf(meta.getExpiredTime()));
			//builder.addTextBody("fileSize", String.valueOf(meta.getFileSize()));
			
			if(meta.getNamespace()!=null){
				builder.addTextBody("namespace", meta.getNamespace());
			}
			if(meta.getAliasName()!=null){
				builder.addTextBody("aliasName", meta.getAliasName());
			}
			HttpEntity entity =builder.build();
			httpPost.setEntity(entity);
			//
			response = httpClient.execute(httpPost);
			//
			StatusLine status = response.getStatusLine();
			if (status != null && status.getStatusCode() >= 300) {
				throw new HttpException(
						"Did not receive successful HTTP response: status code = "
								+ status.getStatusCode()
								+ ", status message = ["
								+ status.getReasonPhrase() + "]");
			}
			InputStream is = (response == null || response.getEntity() == null ? null : response.getEntity().getContent());
			String json=null;
			if (is != null) {
				try{
					if(charset==null || charset.length()==0){
						charset=Charset.defaultCharset().name();
					}
					json=IOUtils.toString(is, charset);
				}finally{
					is.close();
				}
			}
			if(json==null || json.length()<3){
				throw new HttpException("http response content be null.");
			}
			JSONObject jsonObject=JSONObject.parseObject(json);
			if("0".equals(jsonObject.get("responseCode"))){
				meta.setFileId(jsonObject.getString("fileId"));
			}else{
				throw new HttpException("Upload error,responseCode="+jsonObject.get("responseCode")
						+",responseMsg="+jsonObject.get("responseMsg"));
			}
		}catch(Exception ex){
			throw new HttpClientFileException("Http client upload file="+meta+"error,cause:"+ex.getMessage(),ex);
		}finally{
			try {
				if(response!=null){
					response.close();
				}
			} catch (IOException e) {
				throw new HttpClientFileException("Http client upload file="+meta+"error,cause:"+e.getMessage(),e);
			}
		}
	      
	}

	@Override
	public OutputStream getOutput() {
		return null;
	}

	@Override
	public WefileMeta getMeta() {
		return meta;
	}

	@Override
	public void doFinally() {
		httpClient=null;
		httpPost=null;
	}

}
