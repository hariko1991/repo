package com.pingan.pafa.stp.wefiles.httpclient;

import java.io.IOException;
import java.io.InputStream;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.client.methods.CloseableHttpResponse;

import com.pingan.pafa.stp.wefiles.WefileDownloader;
import com.pingan.pafa.stp.wefiles.WefileMeta;

public class WefileHttpClientDownloader implements WefileDownloader{
	

	private InputStream input=null;
	
	private CloseableHttpResponse response;
	
	
	private WefileMeta meta=null;
	
	public WefileHttpClientDownloader(WefileMeta meta,CloseableHttpResponse response){
		this.meta=meta;
		this.response=response;
	}

	@Override
	public WefileMeta getMeta() {
		if(meta==null){
			meta=new WefileMeta();
		}
		if(meta.getFileId()==null){
			meta.setFileId(this.getFileId());
		}
		if(meta.getNamespace()==null){
			meta.setNamespace(this.getNamespace());
		}
		if(meta.getAliasName()==null){
			meta.setAliasName(this.getAliasName());
		}
		HttpEntity entity=response.getEntity();
		meta.setCharset(getCharset(entity));
		meta.setContentType(getContentType(entity));
		meta.setFileSize((int)entity.getContentLength());
		
		//
		meta.setFileName(getFileName());
		return meta;
	}
	
	protected String getCharset(HttpEntity entity){
		Header contentTypeHeader=entity.getContentType();
		if(contentTypeHeader!=null){
			String contentType=contentTypeHeader.getValue();
			if(contentType!=null && (contentType=contentType.trim()).length()>0){
				int idx=contentType.indexOf("charset=");
				if(idx>0){
					String charset=contentType.substring(idx+"charset=".length()).trim();
					if((charset=charset.trim()).length()>0){
						return charset;
					}
				}
				return contentType;
			}
		}
		return null;
	}
	
	protected String getContentType(HttpEntity entity){
		Header contentTypeHeader=entity.getContentType();
		if(contentTypeHeader!=null){
			String contentType=contentTypeHeader.getValue();
			if(contentType!=null && (contentType=contentType.trim()).length()>0){
				int idx=contentType.indexOf(';');
				if(idx>0){
					contentType=contentType.substring(0,idx).trim();
				}
				return contentType;
			}
		}
		return null;
	}
	
	protected String getFileId(){
		Header fileIdHeader=response.getLastHeader("wefile-fileId");
		if(fileIdHeader!=null){
			return fileIdHeader.getValue();
		}
		return null;
	}
	
	protected String getAliasName(){
		Header header=response.getLastHeader("wefile-aliasName");
		if(header!=null){
			return header.getValue();
		}
		return null;
	}
	
	protected String getNamespace(){
		Header header=response.getLastHeader("wefile-namespace");
		if(header!=null){
			return header.getValue();
		}
		return null;
	}
	protected String getFileName(){
		Header fileNameHeader=response.getLastHeader("Content-Disposition");
		if(fileNameHeader!=null){
			String disposition=fileNameHeader.getValue();
			if(disposition!=null && (disposition=disposition.trim()).length()!=0){
				int idx=disposition.indexOf("filename=");
				if(idx!=-1){
					String fileName=disposition.substring(idx+"filename=".length()).trim();
					if((fileName=fileName.trim()).length()>0){
						return fileName;
					}
				}
			}
		}
		return null;
	}
	/***
	 * Content-Disposition:attachment;filename=WefilesHttpClientsTests.class
Content-Length:2536
Content-Type:application/object-stream; charset=UTF-8
	 */

	@Override
	public InputStream getInputStream() {
		if(input==null){
			try {
				input=response.getEntity().getContent();
			} catch (IOException e) {
				throw new RuntimeException(e.getMessage(), e);
			}
		}
		return input;
	}

	@Override
	public void doFinally() {
		try {
			if(input!=null){
				input.close();
			}
			input=null;
		} catch (IOException e) {
		}
		try {
			if(response!=null){
				response.close();
			}
			response=null;
		} catch (IOException e) {
		}
	}
	
	
	

}
