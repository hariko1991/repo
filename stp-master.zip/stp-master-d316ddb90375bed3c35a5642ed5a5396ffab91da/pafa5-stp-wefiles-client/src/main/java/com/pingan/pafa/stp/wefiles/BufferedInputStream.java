package com.pingan.pafa.stp.wefiles;

import java.io.IOException;
import java.io.InputStream;

public class BufferedInputStream extends java.io.BufferedInputStream {

    private int totalSize = 0;

    public BufferedInputStream(InputStream out) {
        super(out);
    }

    public BufferedInputStream(InputStream out, int bufferSize) {
        super(out, bufferSize);
    }

    @Override
    public synchronized int read() throws IOException {
        int r = super.read();
        if (r > 0) {
            totalSize += r;
        }
        return r;
    }

    @Override
    public synchronized int read(byte[] b, int off, int len) throws IOException {
        int r = super.read(b, off, len);
        if (r > 0) {
            totalSize += r;
        }
        return r;
    }

    public int getTotalSize() {
        return totalSize;
    }

}
