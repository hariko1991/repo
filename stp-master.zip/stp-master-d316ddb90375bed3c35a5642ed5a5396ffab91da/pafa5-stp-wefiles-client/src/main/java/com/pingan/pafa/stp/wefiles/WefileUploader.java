package com.pingan.pafa.stp.wefiles;

import java.io.InputStream;
import java.io.OutputStream;

public interface WefileUploader {

    public OutputStream getOutput();

    public void setInputStream(InputStream input);

    public WefileMeta getMeta();

    public void doFinally();

}
