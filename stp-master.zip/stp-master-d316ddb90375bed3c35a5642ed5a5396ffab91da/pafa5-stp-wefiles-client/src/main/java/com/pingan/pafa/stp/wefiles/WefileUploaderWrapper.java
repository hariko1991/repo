package com.pingan.pafa.stp.wefiles;

import java.io.InputStream;
import java.io.OutputStream;

final class WefileUploaderWrapper implements WefileUploader {

    private WefileUploader target;

    private BufferedOutputStream bufferOutput;

    private BufferedInputStream bufferInput;

    private int bufferSize;

    public WefileUploaderWrapper(WefileUploader target, int bufferSize) {
        this.target = target;
        this.bufferSize = bufferSize;
    }

    @Override
    public OutputStream getOutput() {
        OutputStream output = target.getOutput();
        if (bufferOutput == null && output != null) {
            bufferOutput = new BufferedOutputStream(output, bufferSize);
        }
        return bufferOutput;
    }

    @Override
    public void setInputStream(InputStream input) {
        if (input != null && bufferInput == null) {
            bufferInput = new BufferedInputStream(input, bufferSize);
        }
        if (bufferInput == null) {
            throw new java.lang.IllegalArgumentException("input is null");
        }
        target.setInputStream(bufferInput);
    }

    @Override
    public WefileMeta getMeta() {
        return target.getMeta();
    }

    @Override
    public void doFinally() {
        try {
            WefileMeta meta = target.getMeta();
            int totalSize = 0;
            if (bufferOutput != null) {
                bufferOutput.flush();
                totalSize = bufferOutput.getTotalSize();
            } else if (bufferInput != null) {
                totalSize = bufferInput.getTotalSize();
            }
            if (totalSize > 0) {
                if (meta.getFileSize() <= 0) {
                    meta.setFileSize(totalSize);
                } else if (meta.getFileSize() != totalSize) {
                    throw new IllegalArgumentException("Real file size<" + totalSize
                            + "> not eqauls for assert size<" + meta.getFileSize() + ">.");
                }
            }
            target.doFinally();
        } catch (WefileException e) {
            throw e;
        } catch (Exception ex) {
            throw new WefileException("Uploader=" + target.getMeta() + " doFinally error:"
                    + ex.getMessage(), ex);
        }
    }

    @Override
    public boolean equals(Object obj) {
        return target.equals(obj);
    }

    @Override
    public int hashCode() {
        return target.hashCode();
    }

    @Override
    public String toString() {
        return target.toString();
    }

}
