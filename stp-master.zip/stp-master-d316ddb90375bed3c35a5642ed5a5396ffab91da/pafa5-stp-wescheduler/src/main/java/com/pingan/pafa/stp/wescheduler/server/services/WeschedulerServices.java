package com.pingan.pafa.stp.wescheduler.server.services;

import java.util.Date;
import java.util.List;

import com.pingan.pafa.stp.wescheduler.common.JobMeta;
import com.pingan.pafa.stp.wescheduler.common.TriggerReceiptMeta;
import com.pingan.pafa.stp.wescheduler.common.WeschedulerException;
import com.pingan.pafa.stp.wescheduler.server.po.JobInfoPO;
import com.pingan.pafa.stp.wescheduler.server.po.JobNodePO;
import com.pingan.pafa.stp.wescheduler.server.po.TriggerRecordPO;

public interface WeschedulerServices {

    List<JobMeta> listValidJobMetas();

    JobMeta getJobMeta(String jobId, boolean checkStatus);

    List<TriggerRecordPO> listTimeoutTriggers(int maxSize);

    TriggerRecordPO getTriggerResult(String triggerId);

    TriggerResult trigger(String jobId, Date nextTriggerTime, String triggerUser);
    
    long getTriggerIntervalLimit();

    boolean saveJobMeta(JobMeta meta);
    
    void checkJobExpression(String cronExpression,long repeatInterval)
    	throws WeschedulerException;

    void receipt(TriggerReceiptMeta meta);

    void forReceiptTimeout(String triggerId);

    JobInfoPO getInfo(String domainId, String group, String jobName);
    
    JobInfoPO getInfo(String jobId);

    List<JobNodePO> listNodes(String domainId, String group, String jobName);

    boolean stop(String jobId, String user);

    boolean recover(String jobId, String user);

    List<JobInfoPO> list(String domainId, String group, int limit, int page);

    List<TriggerRecordPO> listTriggerRecoreds(String domainId, String group, String jobName, int limitSize,
            int page);

    long countRecordsByJobId(String jobId);
    
}
