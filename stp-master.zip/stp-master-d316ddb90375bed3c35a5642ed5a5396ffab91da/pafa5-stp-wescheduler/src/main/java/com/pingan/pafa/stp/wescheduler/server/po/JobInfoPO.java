package com.pingan.pafa.stp.wescheduler.server.po;

import java.util.Date;

import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Wescheduler2JobInfo")
@CompoundIndexes({@CompoundIndex(name = "def_index", def = "{domainId : 1, group : 1,jobName:1}")})
public class JobInfoPO {

	@org.springframework.data.annotation.Id
    private String id;
    
    private String domainId;

    private String beanName;

    private String beanClass;

    private String methodName;

    private String jobName;

    private String group;

    private String cronExpression;
    
    private boolean cronInvalid;

    private int startDelay;

    private long repeatInterval = -1L;

    /** 0正常,1已过期，2暂停 */
    private int status = 0;

    private String updatedBy;

    private String updatedDate;
    
    private Date nextTriggerTime;

    private Date lastTriggerTime;

    private String triggerUser;

    private int executeCount;

    private Date lastExecuteTime;

    @Override
    public String toString() {
        return "JobInfoPO [id=" + id + ", domainId=" + domainId + ", beanName=" + beanName
                + ", beanClass=" + beanClass + ", methodName=" + methodName + ", jobName="
                + jobName + ", group=" + group + ", cronExpression=" + cronExpression
                + ", startDelay=" + startDelay + ", repeatInterval=" + repeatInterval + ", status="
                + status + ", updatedBy=" + updatedBy + ", updatedDate=" + updatedDate
                + ", nextTriggerTime=" + nextTriggerTime + ", lastTriggerTime=" + lastTriggerTime
                + ", triggerUser=" + triggerUser + ", executeCount=" + executeCount
                + ", lastExecuteTime=" + lastExecuteTime 
                + ", cronInvalid=" + cronInvalid 
                + "]";
    }
    

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDomainId() {
        return domainId;
    }

    public void setDomainId(String domainId) {
        this.domainId = domainId;
    }

    public String getBeanName() {
        return beanName;
    }

    public void setBeanName(String beanName) {
        this.beanName = beanName;
    }

    public String getBeanClass() {
        return beanClass;
    }

    public void setBeanClass(String beanClass) {
        this.beanClass = beanClass;
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getCronExpression() {
        return cronExpression;
    }

    public void setCronExpression(String cronExpression) {
        this.cronExpression = cronExpression;
    }

    public int getStartDelay() {
        return startDelay;
    }

    public void setStartDelay(int startDelay) {
        this.startDelay = startDelay;
    }

    public long getRepeatInterval() {
        return repeatInterval;
    }

    public void setRepeatInterval(long repeatInterval) {
        this.repeatInterval = repeatInterval;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(String updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Date getNextTriggerTime() {
        return nextTriggerTime;
    }

    public void setNextTriggerTime(Date nextTriggerTime) {
        this.nextTriggerTime = nextTriggerTime;
    }

    public Date getLastTriggerTime() {
        return lastTriggerTime;
    }

    public void setLastTriggerTime(Date lastTriggerTime) {
        this.lastTriggerTime = lastTriggerTime;
    }

    public String getTriggerUser() {
        return triggerUser;
    }

    public void setTriggerUser(String triggerUser) {
        this.triggerUser = triggerUser;
    }

    public int getExecuteCount() {
        return executeCount;
    }

    public void setExecuteCount(int executeCount) {
        this.executeCount = executeCount;
    }

    public Date getLastExecuteTime() {
        return lastExecuteTime;
    }

    public void setLastExecuteTime(Date lastExecuteTime) {
        this.lastExecuteTime = lastExecuteTime;
    }

	public boolean isCronInvalid() {
		return cronInvalid;
	}

	public void setCronInvalid(boolean cronInvalid) {
		this.cronInvalid = cronInvalid;
	}

	
    
    

}
