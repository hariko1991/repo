package com.pingan.pafa.stp.wescheduler.server.dao;

import java.util.Date;
import java.util.List;

import com.pingan.pafa.stp.wescheduler.server.po.JobInfoPO;

public interface JobInfoDAO {
	
	List<JobInfoPO> listAll();
	
	List<JobInfoPO> listByGroup(String domainId, String group, int skip, int limit);

	JobInfoPO get(String jobId);
	
	boolean exists(String jobId);

	void add(JobInfoPO po);
	
	void trigger(String jobId,Date curTriggerDate,Date nextTriggerDate,String triggerUser);
	
	void updateMeta(JobInfoPO po);
	
	void receipt(String jobId);
	
	void expired(String jobId);
	
	boolean stop(String jobId,String user);
	
	boolean recover(String jobId,String user);
	
}
