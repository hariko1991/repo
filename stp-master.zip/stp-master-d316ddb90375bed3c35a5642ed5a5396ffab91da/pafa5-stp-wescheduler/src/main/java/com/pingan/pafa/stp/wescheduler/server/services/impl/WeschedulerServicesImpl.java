package com.pingan.pafa.stp.wescheduler.server.services.impl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.quartz.CronExpression;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.stp.wescheduler.common.JobMeta;
import com.pingan.pafa.stp.wescheduler.common.TriggerReceiptMeta;
import com.pingan.pafa.stp.wescheduler.common.WeschedulerConstants.JobStatus;
import com.pingan.pafa.stp.wescheduler.common.WeschedulerConstants.TriggerReceiptStatus;
import com.pingan.pafa.stp.wescheduler.common.WeschedulerException;
import com.pingan.pafa.stp.wescheduler.server.dao.JobInfoDAO;
import com.pingan.pafa.stp.wescheduler.server.dao.JobLockDAO;
import com.pingan.pafa.stp.wescheduler.server.dao.JobNodeDAO;
import com.pingan.pafa.stp.wescheduler.server.dao.TriggerRecordDAO;
import com.pingan.pafa.stp.wescheduler.server.po.JobInfoPO;
import com.pingan.pafa.stp.wescheduler.server.po.JobNodePO;
import com.pingan.pafa.stp.wescheduler.server.po.TriggerRecordPO;
import com.pingan.pafa.stp.wescheduler.server.services.TriggerResult;
import com.pingan.pafa.stp.wescheduler.server.services.WeschedulerServices;

@Service
public class WeschedulerServicesImpl extends BaseServices implements WeschedulerServices {

    @Autowired
    private JobNodeDAO jobNodeDAO;

    @Autowired
    private JobInfoDAO jobInfoDAO;

    @Autowired
    private TriggerRecordDAO triggerRecordDAO;

    @Autowired
    private JobLockDAO jobLockDAO;

    @Value("${receipt.timeout}")
    private long receiptTimeout = 12 * 60 * 60 * 1000; //12小时

    @Value("${min.interval}")
    private long minInterval = 5 * 60 * 1000; //5分钟

    @Value("${lock.expired.time}")
    private int lockExpireTime = 3 * 60 * 1000; //3分钟

    @Override
    public List<JobNodePO> listNodes(String domainId, String group, String jobName) {
        String jobId = domainId + "." + group + "." + jobName;
        List<JobNodePO> pos = jobNodeDAO.list(jobId);
        return pos;
    }

    @Override
    public JobMeta getJobMeta(String jobId,boolean checkStatus) {
        JobInfoPO po = jobInfoDAO.get(jobId);
        if(po==null){
        	return null;
        }
        if(checkStatus && po.getStatus() != JobStatus.DEF){
        	return null;
        }
        JobMeta meta = new JobMeta();
        meta.setBeanClass(po.getBeanClass());
        meta.setBeanName(po.getBeanName());
        meta.setCronExpression(po.getCronExpression());
        meta.setDomainId(po.getDomainId());
        meta.setGroup(po.getGroup());
        meta.setId(po.getId());
        meta.setJobName(po.getJobName());
        meta.setMethodName(po.getMethodName());
        meta.setRepeatInterval(po.getRepeatInterval());
        meta.setStartDelay(po.getStartDelay());
        meta.setUpdatedBy(po.getUpdatedBy());
        return meta;
    }

    @Override
    public List<JobMeta> listValidJobMetas() {
        List<JobInfoPO> pos = jobInfoDAO.listAll();
        if (pos == null || pos.size() == 0) {
            return null;
        } else {
            List<JobMeta> metas = new ArrayList<JobMeta>();
            for (JobInfoPO po : pos) {
                // 可执行
                if (po.getStatus() != JobStatus.DEF) {
                    continue;
                }
                if(po.isCronInvalid()){
                	 continue;
                }
                JobMeta meta = new JobMeta();
                meta.setBeanClass(po.getBeanClass());
                meta.setBeanName(po.getBeanName());
                meta.setCronExpression(po.getCronExpression());
                meta.setDomainId(po.getDomainId());
                meta.setGroup(po.getGroup());
                meta.setId(po.getId());
                meta.setJobName(po.getJobName());
                meta.setMethodName(po.getMethodName());
                meta.setRepeatInterval(po.getRepeatInterval());
                meta.setStartDelay(po.getStartDelay());
                meta.setUpdatedBy(po.getUpdatedBy());
                metas.add(meta);
            }
            return metas;
        }
    }

    @Override
    public TriggerResult trigger(final String jobId, Date nextTriggerTime, String triggerUser) {
        JobInfoPO jobInfo = jobInfoDAO.get(jobId);
        if (jobInfo == null) {
            logger.warn("TriggerResult=1,Job:" + jobId + " Not found data from db.");
            return new TriggerResult(1, "调度失败，没有找到任务的描述数据。");
        }
        if (jobInfo.getStatus() != JobStatus.DEF) {
            logger.warn("TriggerResult=2,Job:" + jobId + " STATUS ERROR.");
            return new TriggerResult(2, "调度失败，任务已过期或暂停,状态=" + jobInfo.getStatus());
        }
        long curTimestamp = System.currentTimeMillis();
        if (minInterval > 0) {
            Date lastTriggerTime = jobInfo.getLastTriggerTime();
            if (lastTriggerTime != null) {
                if (lastTriggerTime.getTime() + minInterval > curTimestamp) {
                    String lastTriggerTimeString =
                            new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS").format(lastTriggerTime);
                    logger.warn("TriggerResult=3,Job:" + jobId + " lastTriggerTime="
                            + lastTriggerTimeString + ", and minInterval=" + minInterval);
                    return new TriggerResult(3, "调度失败，上次执行时间是" + lastTriggerTimeString
                            + "，而执行间隔最小限制是" + (minInterval / 1000) + "秒。");
                }
            }
        }
        if (jobLockDAO.lock(jobId, this.lockExpireTime)) {
            if (minInterval > 0) {
                long limitTimestamp =
                        curTimestamp
                                + (minInterval > lockExpireTime ? minInterval : lockExpireTime);
                if (nextTriggerTime.getTime() < limitTimestamp) {
                    nextTriggerTime = new Date(limitTimestamp);
                }
            }

            String triggerId = executeTrigger(jobId, nextTriggerTime, triggerUser);
            TriggerResult result = new TriggerResult();
            result.setGroup(jobInfo.getGroup());
            result.setJobName(jobInfo.getJobName());
            result.setDomainId(jobInfo.getDomainId());
            result.setTriggerId(triggerId);
            if (logger.isInfoEnabled()) {
                logger.info("TriggerResult=0,triggerId=" + triggerId);
            }
            return result;
        } else {
            logger.warn("TriggerResult=4,Job:" + jobId + " locked!");
            return new TriggerResult(4, "调度失败，任务正在执行或错误原因被锁定，请等待执行完成解锁或超时解锁。");
        }
    }

    @Override
	public long getTriggerIntervalLimit() {
		return minInterval;
	}

	protected String executeTrigger(String jobId, Date nextTriggerTime, String triggerUser) {
        if (logger.isInfoEnabled()) {
            logger.info("TriggeredJob:" + jobId + ",and nextTriggerTime=" + nextTriggerTime
                    + ",and triggerUser=" + triggerUser);
        }
        jobInfoDAO.trigger(jobId, new Date(), nextTriggerTime, triggerUser);
      
        TriggerRecordPO po = new TriggerRecordPO();
        po.setJobId(jobId);
        po.setTriggerDate(System.currentTimeMillis());
        po.setTriggerUser(triggerUser);
        po.setWeschedulerType(1);
        if (triggerUser != null && triggerUser.trim().length() > 0) {
            po.setWeschedulerType(2);
        } else {
            po.setWeschedulerType(1);
        }
        // 未收到回执
        po.setReceiptStatus(0);
        
        return triggerRecordDAO.add(po);
    }

    @Override
    public boolean stop(String jobId, String user) {
        if (logger.isInfoEnabled()) {
            logger.info("stop job=" + jobId + " by user:" + user);
        }
        return this.jobInfoDAO.stop(jobId, user);
    }

    @Override
    public boolean recover(String jobId, String user) {
        if (logger.isInfoEnabled()) {
            logger.info("recover job=" + jobId + " by user:" + user);
        }
        return this.jobInfoDAO.recover(jobId, user);
    }

    @Override
    public void forReceiptTimeout(String triggerId) {
        triggerRecordDAO.forTimeout(triggerId);
    }

    @Override
    public List<TriggerRecordPO> listTimeoutTriggers(int maxSize) {
        long timeDeadline = System.currentTimeMillis() - receiptTimeout;
        return triggerRecordDAO.listTimeouts(timeDeadline, maxSize);
    }

    @Override
    public void receipt(TriggerReceiptMeta meta) {
        int status = meta.getStatus();
        if (status == TriggerReceiptStatus.EXPIRED) {
            if (logger.isInfoEnabled()) {
                logger.info("Job:" + meta.getJobId() + " expired,cause by:"
                        + meta.getExecuteNodeIp());
            }
            jobInfoDAO.expired(meta.getJobId());
        } else {
            jobInfoDAO.receipt(meta.getJobId());
        }
        triggerRecordDAO.receipt(meta);
    }
    
    public void checkJobExpression(String cronExpression,long repeatInterval){
    	if(cronExpression==null){
    		cronExpression="";
    	}
    	 if (repeatInterval <= 0l) {
             repeatInterval = -1l;
         }
         if (cronExpression.length() == 0 && repeatInterval == -1l) {
             throw new WeschedulerException("任务调度配置为空。");
         }
         //---------------------------------------------
        if(cronExpression.length()>0){
        	CronExpression cron=null;
        	try {
        		cron=new CronExpression(cronExpression);
            } catch (Exception ex) {
               throw new WeschedulerException("任务调度配置表达式不正确：" + cronExpression);
            }
        	Date date1=cron.getNextValidTimeAfter(new Date());
        	if(date1==null){
        		 throw new WeschedulerException("任务调度配置表达式：" + cronExpression+"永不执行.");
        	}
        	Date date2=cron.getNextValidTimeAfter(date1);
        	long interval=(date2.getTime()-date1.getTime());
        	if((date2.getTime()-date1.getTime())<this.minInterval){
       		   throw new WeschedulerException("任务调度配置表达式："+cronExpression+"不正确，任务调度执行间隔：" 
       				   + interval+" 不能小于最小限制间隔："+minInterval);
        	}
        }else{
        	if(repeatInterval<this.minInterval){
        		 throw new WeschedulerException("任务调度执行间隔：" + repeatInterval+" 不能小于最小限制间隔："+minInterval);
        	}
        }
       
    }

	@Override
	public boolean saveJobMeta(JobMeta meta) {
		String jobId = meta.getId();
		if (jobId == null || jobId.length() == 0) {
			throw new NullPointerException("jobId is null");
		}
		//
		String cron = meta.getCronExpression();
		if (cron == null) {
			cron = "";
			meta.setCronExpression(cron);
		}
		boolean cronInvalid=false;
		try {
			checkJobExpression(meta.getCronExpression(), meta.getRepeatInterval());
		} catch (WeschedulerException ex) {
			logger.error("Job:" + jobId + " expression error,cause:" + ex.getMessage());
			cronInvalid=true;
		}
		JobInfoPO jobInfo = jobInfoDAO.get(jobId);
		boolean regFlag = true;
		if (jobInfo == null) {
			try {
				if (logger.isInfoEnabled()) {
					logger.info("Add job ：" + JSONObject.toJSONString(meta));
				}
				jobInfo = toPO(meta);
				if(cronInvalid){
					jobInfo.setCronInvalid(true);
					regFlag=false;
				}
				jobInfoDAO.add(jobInfo);
			} catch (Throwable ex) {
			}
		} else {
			if (cronInvalid || metaEquals(jobInfo, meta)) {
				regFlag = false;
			} else {
				if (logger.isInfoEnabled()) {
					logger.info("Update job meta：");
					logger.info("Old meta：" + JSONObject.toJSONString(jobInfo));
					logger.info("New meta：" + JSONObject.toJSONString(meta));
				}
				jobInfoDAO.updateMeta(toPO(meta));
			}
		}
		try {
			if (meta.getInstanceIp() != null) {
				logger.info("Job:" + meta.getId() + " save node:" + meta.getInstanceIp());
				jobNodeDAO.save(meta.getId(), meta.getInstanceIp());
			}
		} catch (Throwable ex) {
		}
		return regFlag;
	}

    public JobInfoPO toPO(JobMeta meta) {
        JobInfoPO po = new JobInfoPO();
        po.setBeanClass(meta.getBeanClass());
        po.setBeanName(meta.getBeanName());
        po.setCronExpression(meta.getCronExpression());
        po.setDomainId(meta.getDomainId());
        po.setGroup(meta.getGroup());
        po.setId(meta.getId());
        po.setJobName(meta.getJobName());
        po.setMethodName(meta.getMethodName());
        po.setRepeatInterval(meta.getRepeatInterval());
        po.setStartDelay(meta.getStartDelay());
        po.setUpdatedBy(meta.getUpdatedBy());
        return po;
    }

    public boolean metaEquals(JobInfoPO po, JobMeta meta) {
        return po.getBeanClass().equals(meta.getBeanClass())
                && po.getBeanName().equals(meta.getBeanName())
                && po.getMethodName().equals(meta.getMethodName())
                && po.getCronExpression().equals(meta.getCronExpression())
                && po.getStartDelay() == meta.getStartDelay()
                && po.getRepeatInterval() == meta.getRepeatInterval();
    }

    @Override
    public JobInfoPO getInfo(String domainId, String group, String jobName) {
        String jobId = domainId + "." + group + "." + jobName;
        if (logger.isInfoEnabled()) {
            logger.info("JobId=" + jobId);
        }
        return jobInfoDAO.get(jobId);
    }

    @Override
	public JobInfoPO getInfo(String jobId) {
    	 if (logger.isInfoEnabled()) {
             logger.info("JobId=" + jobId);
         }
         return jobInfoDAO.get(jobId);
	}

	@Override
    public TriggerRecordPO getTriggerResult(String triggerId) {
        return triggerRecordDAO.getById(triggerId);
    }

    @Override
    public List<TriggerRecordPO> listTriggerRecoreds(String domainId, String group, 
            String jobName, int limitSize, int page) {
        String jobId = domainId + "." + group + "." + jobName;
        if (logger.isInfoEnabled()) {
            logger.info("JobId=" + jobId);
        }
        if (limitSize < 1) {
            limitSize = 10;
        }
        if (page < 1) {
            page = 1;
        }
        return triggerRecordDAO.listByJobId(jobId, limitSize, page);
    }

    @Override
    public List<JobInfoPO> list(String domainId, String group, int limit, int page) {
        if (logger.isInfoEnabled()) {
            logger.info("List by domainId=" + domainId + " ,group=" + group);
        }
        int skip = (page - 1) * limit;
        return jobInfoDAO.listByGroup(domainId, group, skip, limit);
    }

    @Override
    public long countRecordsByJobId(String jobId) {
        return triggerRecordDAO.getCountByJobId(jobId);
    }

}
