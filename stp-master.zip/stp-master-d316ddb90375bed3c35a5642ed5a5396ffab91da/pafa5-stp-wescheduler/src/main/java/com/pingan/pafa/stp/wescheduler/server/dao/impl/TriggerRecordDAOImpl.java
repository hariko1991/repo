package com.pingan.pafa.stp.wescheduler.server.dao.impl;

import java.util.Date;
import java.util.List;

import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa.stp.wescheduler.common.TriggerReceiptMeta;
import com.pingan.pafa.stp.wescheduler.server.dao.TriggerRecordDAO;
import com.pingan.pafa.stp.wescheduler.server.po.TriggerRecordPO;


@Repository
public class TriggerRecordDAOImpl extends BaseMongoDAO<TriggerRecordPO> implements TriggerRecordDAO {

    @Override
    public String add(TriggerRecordPO po) {
        this._add(po);
        return po.getId();
    }

    @Override
    public TriggerRecordPO getById(String id) {
        return this._getById(id);
    }

    @Override
    public List<TriggerRecordPO> listByJobId(String jobId, int maxSize, int page) {
        int skip = (page - 1) * maxSize;
        return this._listAndDesc(this.where("jobId").is(jobId), skip, maxSize, "triggerDate");
    }

    @Override
    public long getCountByJobId(String jobId) {
        return this._count(where("jobId").is(jobId));
    }

    @Override
    public List<TriggerRecordPO> listTimeouts(long timeDeadline, int maxSize) {
        return this._list(this.where("triggerDate").lt(timeDeadline).and("receiptStatus").is(0), 0,
                maxSize);
    }

    @Override
    public void forTimeout(String triggerId) {
        Criteria where = this.where("id").is(triggerId);
        Update update = new Update();
        update.set("receiptStatus", 9).set("receiptDate", new Date());
        this._update(where, update);
    }

    @Override
    public void receipt(TriggerReceiptMeta meta) {
        Criteria where = this.where("id").is(meta.getTriggerId());
        Update update = new Update();
        update.set("executeNodeIp", meta.getExecuteNodeIp()).set("receiptStatus", meta.getStatus())
                .set("receiptMsg", meta.getMsg()).set("receiptDate", new Date())
                .set("logId", meta.getLogId()).set("costTime", meta.getCostTime());
        this._update(where, update);
    }
    
}
