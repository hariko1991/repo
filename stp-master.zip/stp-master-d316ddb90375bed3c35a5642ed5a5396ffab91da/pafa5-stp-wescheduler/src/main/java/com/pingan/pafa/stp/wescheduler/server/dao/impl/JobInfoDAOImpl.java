package com.pingan.pafa.stp.wescheduler.server.dao.impl;

import java.util.Date;
import java.util.List;

import org.apache.commons.lang.StringUtils;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa.stp.wescheduler.common.WeschedulerConstants.JobStatus;
import com.pingan.pafa.stp.wescheduler.server.dao.JobInfoDAO;
import com.pingan.pafa.stp.wescheduler.server.po.JobInfoPO;


@Repository
public class JobInfoDAOImpl extends BaseMongoDAO<JobInfoPO> implements JobInfoDAO {

    @Override
    public List<JobInfoPO> listAll() {
        return this._list(null);
    }

    @Override
    public List<JobInfoPO> listByGroup(String domainId, String group, int skip, int limit) {
        Criteria where = this.where("domainId").is(domainId);
        if (StringUtils.isNotBlank(group)) {
            where.and("group").is(group);
        }
        return this._list(where, skip, limit);
    }

    @Override
    public JobInfoPO get(String jobId) {
        return this._getById(jobId);
    }

    @Override
    public boolean exists(String jobId) {
        return this._exists(this.where("id").is(jobId));
    }

    @Override
    public void add(JobInfoPO po) {
        this._add(po);
    }

    @Override
    public void trigger(String jobId, Date curTriggerDate, Date nextTriggerDate, String triggerUser) {
        Criteria where = this.where("id").is(jobId);
        Update update = new Update();
        update.set("lastTriggerTime", curTriggerDate).set("nextTriggerTime", nextTriggerDate)
                .set("triggerUser", triggerUser);
        this._update(where, update);
    }

    @Override
    public void updateMeta(JobInfoPO po) {
        Criteria where = this.where("id").is(po.getId());
        Update update = new Update();
        if (po.getCronExpression() == null) {
            po.setCronExpression("");
        }
        update.set("cronExpression", po.getCronExpression()).set("startDelay", po.getStartDelay())
                .set("repeatInterval", po.getRepeatInterval()).set("beanName", po.getBeanName())
                .set("methodName", po.getMethodName()).set("beanClass", po.getBeanClass());       
        String user = po.getUpdatedBy();
        if (user != null && user.length() > 0) {
            update.set("updatedBy", user);
            update.set("updatedDate", new Date());
        }
        this._update(where, update);
    }

    @Override
    public void receipt(String jobId) {
        Criteria where = this.where("id").is(jobId);
        Update update = new Update();
        update.set("lastExecuteTime", new Date()).inc("executeCount", 1);
        this._update(where, update);
    }

    @Override
    public void expired(String jobId) {
        Criteria where = this.where("id").is(jobId);
        Update update = new Update();
        update.set("status", JobStatus.EXPIRED);
        this._update(where, update);
    }

    @Override
    public boolean stop(String jobId, String user) {
        Criteria where = this.where("id").is(jobId).and("status").is(JobStatus.DEF);
        Update update = new Update();
        update.set("status", JobStatus.STOP);
        update.set("updatedBy", user);
        update.set("updatedDate", new Date());
        return this._update(where, update);
    }

    @Override
    public boolean recover(String jobId, String user) {
        Criteria where = this.where("id").is(jobId).and("status").is(JobStatus.STOP);
        Update update = new Update();
        update.set("status", JobStatus.DEF);
        update.set("updatedBy", user);
        update.set("updatedDate", new Date());
        return this._update(where, update);
    }
    
}
