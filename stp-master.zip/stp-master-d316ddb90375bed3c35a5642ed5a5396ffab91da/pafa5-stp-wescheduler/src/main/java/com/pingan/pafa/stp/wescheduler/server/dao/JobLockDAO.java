package com.pingan.pafa.stp.wescheduler.server.dao;

public interface JobLockDAO {

	boolean lock(String jobId,int lockExpireTime);
	
	boolean unlock(String jobId);
	
}
