package com.pingan.pafa.stp.wescheduler.server.dao.impl;

import java.util.List;

import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa.stp.wescheduler.server.dao.JobNodeDAO;
import com.pingan.pafa.stp.wescheduler.server.po.JobNodePO;


@Repository
public class JobNodeDAOImpl extends BaseMongoDAO<JobNodePO> implements JobNodeDAO {

    @Override
    public boolean exists(String jobId, String instanceIp) {
        return this._exists(where("id").is(jobId + "." + instanceIp));
    }

    @Override
    public List<JobNodePO> list(String jobId) {
        return this._list(where("jobId").is(jobId));
    }

    @Override
    public void save(String jobId, String instanceIp) {
        save(new JobNodePO(jobId, instanceIp));
    }

    @Override
    public void save(JobNodePO po) {
        String id = po.getJobId() + "." + po.getInstanceIp();
        po.setId(id);
        _upsert(this.where("id").is(id), po);
    }

}
