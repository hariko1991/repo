package com.pingan.pafa.stp.wescheduler.server.dao;

import java.util.List;

import com.pingan.pafa.stp.wescheduler.common.TriggerReceiptMeta;
import com.pingan.pafa.stp.wescheduler.server.po.TriggerRecordPO;

public interface TriggerRecordDAO {

	String add(TriggerRecordPO po);
	
	TriggerRecordPO getById(String id);
	
	List<TriggerRecordPO> listByJobId(String jobId ,int maxSize,int page);
	
	long getCountByJobId(String jobId);
	
	List<TriggerRecordPO> listTimeouts(long timeDeadline,int maxSize);
	
	void forTimeout(String triggerId);
	
	void receipt(TriggerReceiptMeta meta);
	
}
