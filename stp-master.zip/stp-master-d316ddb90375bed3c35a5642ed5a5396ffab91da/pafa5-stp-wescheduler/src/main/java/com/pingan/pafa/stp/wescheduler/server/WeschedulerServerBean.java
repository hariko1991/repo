package com.pingan.pafa.stp.wescheduler.server;

import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;

import javax.annotation.PostConstruct;
import javax.annotation.PreDestroy;

import org.apache.commons.lang.StringUtils;
import org.quartz.Trigger;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.fastjson.JSONObject;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa.pizza.Pizza;
import com.pingan.pafa.pizza.PizzaListener;
import com.pingan.pafa.pizza.PizzaManager;
import com.pingan.pafa.pizza.PizzaPathListener;
import com.pingan.pafa.stp.wescheduler.common.JobMeta;
import com.pingan.pafa.stp.wescheduler.common.JobTriggerMeta;
import com.pingan.pafa.stp.wescheduler.common.TriggerReceiptMeta;
import com.pingan.pafa.stp.wescheduler.common.WeschedulerConstants;
import com.pingan.pafa.stp.wescheduler.common.WeschedulerConstants.TriggerReceiptStatus;
import com.pingan.pafa.stp.wescheduler.server.po.JobInfoPO;
import com.pingan.pafa.stp.wescheduler.server.po.TriggerRecordPO;
import com.pingan.pafa.stp.wescheduler.server.services.TriggerResult;
import com.pingan.pafa.stp.wescheduler.server.services.WeschedulerServices;

public class WeschedulerServerBean extends QuartzJobHandler implements WeschedulerServer {

    private String pizzaManagerURL;

    private PizzaManager pizza;
    

    private volatile ThreadPoolExecutor threadPoolExecutor;

    private int threadSize = 3;

    @Autowired
    private WeschedulerServices weschedulerServices;

    
    
    private  final  Map<String,Set<String>> regNodesMap=new ConcurrentHashMap<String,Set<String>>();
    
    private final Map<String,String> domainIds=new ConcurrentHashMap<String,String>();
    
    @PostConstruct
    public synchronized void init() throws Exception {
        if (logger.isInfoEnabled()) {
            logger.info("Wescheduler startup...");
        }
        PizzaManager pizza=null;
        if (StringUtils.isNotBlank(pizzaManagerURL)) {
            if (logger.isInfoEnabled()) {
                logger.info("pizzaManagerURL=" + pizzaManagerURL);
            }
            pizza = Pizza.getPizzaContext().createManager(pizzaManagerURL);
        } else {
        	pizza = Pizza.getManager();
        }
        this.pizza=pizza;
        //-------------------------------
        List<JobMeta> jobs = weschedulerServices.listValidJobMetas();
        if (jobs != null && jobs.size() > 0) {
            if (logger.isInfoEnabled()) {
                logger.info("Job registered count=" + jobs.size());
            }
            for (JobMeta meta : jobs) {
                try {
                    if (logger.isInfoEnabled()) {
                        logger.info("Init cache for job:" + JSONObject.toJSONString(meta));
                    }
                    this.registerQuartzJob(meta);
                } catch (Exception e) {
                    logger.error("stp-scheduler server init:register cached job error. jobMeta: "
                            + JSONObject.toJSONString(meta), e);
                }
            }
        }
        if (logger.isInfoEnabled()) {
            logger.info("ExecutorThreadPoolSize=" + threadSize);
        }
        if(threadSize>0){
        	threadPoolExecutor =
                new ThreadPoolExecutor(threadSize, threadSize, 0, TimeUnit.MILLISECONDS,
                        new SynchronousQueue<Runnable>());
        }
        //--------------------
        List<String> domainIds=pizza.listChildren(WeschedulerConstants.PIZZA_ROOT_PATH);
        if(domainIds!=null && domainIds.size()>0){
        	if (logger.isInfoEnabled()) {
                 logger.info("Registered domainIds=" + domainIds);
            }
        	for(String domainId:domainIds){
        		handleRegNodes(domainId,false);
        	}
        }
        //
        //pizza.setPathListener(WeschedulerConstants.PIZZA_ROOT_PATH, new RootPathListener());
        if (logger.isInfoEnabled()) {
            logger.info("Wescheduler startup completed.");
        }
    }
    
    class RootPathListener implements PizzaPathListener{
    	@Override
		public void pizzaPathChanged(String parentPath, List<String> childrenPaths) {
			if(childrenPaths!=null && childrenPaths.size()>0){
				for(String domainId:childrenPaths){
					if(domainIds.get(domainId)==null){
						String domainRegPath=WeschedulerConstants.PIZZA_ROOT_PATH+
				    			"/"+domainId+WeschedulerConstants.PIZZA_PATH_REG;
						domainIds.put(domainId, "1");
						//
						handleRegNodes(domainId,true);
						//
						DomainRegPathListener listener= new DomainRegPathListener(domainId);
						pizza.setPathListener(domainRegPath,listener);
						
					}
				}
			}
		}
    }
    
    protected synchronized void handleRegNodes(String domainId,boolean registerJob){
    	String domainRegPath=WeschedulerConstants.PIZZA_ROOT_PATH+
    			"/"+domainId+WeschedulerConstants.PIZZA_PATH_REG;
		List<String> nodeList=pizza.listChildren(domainRegPath);
		Set<String> regNodes=new HashSet<String>();
		regNodesMap.put(domainId, regNodes);
		if(nodeList!=null && nodeList.size()>0){
			regNodes.addAll(nodeList);
			if(logger.isInfoEnabled()){
				logger.info("Domain<"+domainId+"> regNodes:"+regNodes);
			}
			if(registerJob){
				for(String node:nodeList){
					String jobRegPath=domainRegPath+"/"+node;
					//pizza.setListener(path, new JobRegInfoChangedListener());
					String nodeJobInfo=pizza.get(jobRegPath);
					if (nodeJobInfo != null && nodeJobInfo.length()>6) {
						if(logger.isInfoEnabled()){
							logger.info("Job register by :"+jobRegPath+",and jobInfo: "+nodeJobInfo);
						}
						handleRegisterEvent(JSONObject.parseObject(nodeJobInfo, JobMeta.class));
	                }
				}
			}
			//----------------------------------------
		}
		DomainRegPathListener listener= new DomainRegPathListener(domainId);
		domainIds.put(domainId, "1");
		pizza.setPathListener(domainRegPath,listener);
    }
    
    
    
    class DomainRegPathListener implements PizzaPathListener{
    	
    	private String domainId;
    	
    	public DomainRegPathListener(String domainId){
    		this.domainId=domainId;
    	}
    	
    	@Override
		public void pizzaPathChanged(String parentPath, List<String> childrenPaths) {
			if(childrenPaths!=null && childrenPaths.size()>0){
				onRegNodesChanged(domainId,childrenPaths);
			}
		}
    }
    
    protected void onRegNodesChanged(String domainId, List<String> children){
    	Set<String> regNodes=regNodesMap.get(domainId);
		if(regNodes==null){
			regNodes=new HashSet<String>();
			regNodesMap.put(domainId, regNodes);
		}
		String domainRegPath=WeschedulerConstants.PIZZA_ROOT_PATH+
    			"/"+domainId+WeschedulerConstants.PIZZA_PATH_REG;
		PizzaManager pizza=this.pizza;
		for(String node:children){
			if(!regNodes.contains(node)){
				String jobRegPath=domainRegPath+"/"+node;
				String pizzaContent=pizza.get(jobRegPath);
				if (pizzaContent != null && pizzaContent.length()>6) {
					regNodes.add(node);
					handleRegisterEvent(JSONObject.parseObject(pizzaContent, JobMeta.class));
                    logger.info("Job register info from pizza: "+pizzaContent);
                   // pizza.setListener(jobRegPath, new JobRegInfoChangedListener());
                }
			}
		}
    }
   
    
    
   /* class JobRegInfoChangedListener implements PizzaListener{
    	 @Override
         public void handleConfigChange(String pizzaContent) {
             if (pizzaContent != null && pizzaContent.length()>6) {
                 onRegisterJob(JSONObject.parseObject(pizzaContent, JobMeta.class));
                 logger.info("Job register info from pizza: "+pizzaContent);
             }
         }
    }*/

    @PreDestroy
    public void destroy() {
        try {
            if (logger.isInfoEnabled()) {
                logger.info("Wescheduler shutdown.");
            }
            if (threadPoolExecutor != null) {
                threadPoolExecutor.shutdown();
                threadPoolExecutor = null;
            }
            PizzaManager pizza=this.pizza;
            if(pizza!=null){
            	//pizza.removePathListener(WeschedulerConstants.PIZZA_ROOT_PATH);
            	if(domainIds!=null && domainIds.size()>0){
            		for(String domainId:domainIds.keySet()){
            			String domainRegPath=WeschedulerConstants.PIZZA_ROOT_PATH+
            	    			"/"+domainId+WeschedulerConstants.PIZZA_PATH_REG;
            			pizza.removePathListener(domainRegPath);
            		}
            	}
            }
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    @Override
    public String trigger(String domainId, String group, String jobName, String triggerUser)
            throws ResponseCodeException {
        String jobId = domainId + "." + group + "." + jobName;
        Trigger trigger = this.getQuartzTrigger(jobId);
        if (trigger == null) {
            logger.error("Job:" + jobId + " not found quartz trigger.");
            throw new ResponseCodeException("21", "调度失败，调度器中没有找到任务:" + jobName + "的注册信息。");
        }
        return trigger(trigger, triggerUser);
    }

    @Override
    public String trigger(Trigger quartzTrigger, String triggerUser) throws ResponseCodeException {
        String jobId = quartzTrigger.getJobName();
        Date nextTriggerDate = quartzTrigger.getNextFireTime();
        TriggerResult result = weschedulerServices.trigger(jobId, nextTriggerDate, triggerUser);
        int resultCode = result.getCode();
        if (resultCode == 2) {
            if (logger.isInfoEnabled()) {
                logger.info("Trigger failure,job=" + jobId + " stoped or expired.");
            }
            this.removeJob(jobId);
        }
        String triggerId = result.getTriggerId();
        if (triggerId == null) {
            throw new ResponseCodeException("" + result.getCode(), result.getMsg());
        }
        //-----------------------------
        if (logger.isInfoEnabled()) {
            logger.info("Trigger job:" + jobId + ", and triggerId=" + triggerId + ",notify...");
        }
        JobTriggerMeta triggerMeta = new JobTriggerMeta(jobId, triggerId);
        String triggerPath=WeschedulerConstants.PIZZA_ROOT_PATH
        		+"/"+result.getDomainId()+WeschedulerConstants.PIZZA_PATH_TRIGGER
        		+"/"+result.getGroup()+"."+result.getJobName();
        // 触发job
        pizza.set(triggerPath,JSONObject.toJSONString(triggerMeta));
        // 监听结果
        String receiptPath=WeschedulerConstants.PIZZA_ROOT_PATH
        		+"/"+result.getDomainId()+WeschedulerConstants.PIZZA_PATH_RECEIPT+"/"+triggerId;
        pizza.setListener(receiptPath,new ReceiptListener());
        if (logger.isInfoEnabled()) {
            logger.info("Trigger job:" + jobId + ", and triggerId=" + triggerId
                    + ",completed notify.");
        }
        return triggerId;
    }
    
    class ReceiptListener implements PizzaListener{
    	 @Override
         public void handleConfigChange(String pizzaContent) {
             if (pizzaContent != null && pizzaContent.length()>6) {
                 onReceipt(JSONObject.parseObject(pizzaContent,
                         TriggerReceiptMeta.class));
             }
         }
    }

    protected void onReceipt(final TriggerReceiptMeta receipterMeta) {
        if (this.threadSize > 0) {
            threadPoolExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    handleReceipt(receipterMeta);
                }
            });
        } else {
            handleReceipt(receipterMeta);
        }
    }

    protected void handleReceipt(TriggerReceiptMeta receiptMeta) {
        if (logger.isInfoEnabled()) {
            logger.info("HandleReceipt=" + JSONObject.toJSONString(receiptMeta));
        }
        if (receiptMeta.getStatus() == 1) {
            // 竞锁回执，不处理
            return;
        }
        try {
            if (logger.isInfoEnabled()) {
                logger.info("Handle receipt for job:" + receiptMeta.getJobId()
                        + ",and triggerId=" + receiptMeta.getTriggerId() + " and status="
                        + receiptMeta.getStatus());
            }
            String triggerId = receiptMeta.getTriggerId();
            String receiptPath=WeschedulerConstants.PIZZA_ROOT_PATH
            		+"/"+receiptMeta.getDomainId()+WeschedulerConstants.PIZZA_PATH_RECEIPT+"/"+triggerId;
            pizza.removeListener(receiptPath);
            pizza.del(receiptPath);
            weschedulerServices.receipt(receiptMeta);
            //
            if (receiptMeta.getStatus() == TriggerReceiptStatus.EXPIRED) {
                removeJob(receiptMeta.getJobId());
            }
        } catch (Throwable ex) {
            logger.error("Handle receipt for job:" + receiptMeta.getJobId() + ",and triggerId="
                    + receiptMeta.getTriggerId() + " error,cause:" + ex.getMessage(), ex);
        }
    }

    public void removeJob(String jobId) {
        if (logger.isInfoEnabled()) {
            logger.info("Clean quartz job:" + jobId);
        }
        this.delQuartzJob(jobId);
    }

    @Override
    public void stopJob(String domainId, String group, String jobName, String user) {
        String jobId = domainId + "." + group + "." + jobName;
        weschedulerServices.stop(jobId, user);
        removeJob(jobId);
    }

    @Override
    public void recoverJob(String domainId, String group, String jobName, String user) {
        String jobId = domainId + "." + group + "." + jobName;
        if (weschedulerServices.recover(jobId, user)) {
            removeJob(jobId);
            JobMeta meta = weschedulerServices.getJobMeta(jobId,true);
            this.registerQuartzJob(meta);
        }
    }

    @Override
    public void cleanReceipts() {
        while (true) {
            List<TriggerRecordPO> recoreds = weschedulerServices.listTimeoutTriggers(30);
            if (recoreds != null && recoreds.size() > 0) {
                for (TriggerRecordPO recored : recoreds) {
                    String triggerId = recored.getId();
                    try {
                        if (logger.isInfoEnabled()) {
                            logger.info("Process timeout for job:" + recored.getJobId()
                                    + ", and triggerId=" + triggerId + "");
                        }
                        JobInfoPO info = weschedulerServices.getInfo(recored.getJobId());
                        if (info == null) {
                           continue;
                        }
                        String receiptPath=WeschedulerConstants.PIZZA_ROOT_PATH
                        		+"/"+info.getDomainId()+WeschedulerConstants.PIZZA_PATH_RECEIPT+"/"+triggerId;
                        pizza.removeListener(receiptPath);
                        pizza.del(receiptPath);
                        weschedulerServices.forReceiptTimeout(triggerId);
                    } catch (Throwable th) {
                        logger.error(
                                "Handle receipt timeout for job:" + recored.getJobId()
                                        + ", and triggerId=" + triggerId + " error,cause:"
                                        + th.getMessage(), th);
                    }
                }
            } else {
                break;
            }
        }
    }

    public void handleRegisterEvent(final JobMeta jobMeta) {
        if (this.threadSize > 0) {
            threadPoolExecutor.execute(new Runnable() {
                @Override
                public void run() {
                    registerJob(jobMeta);
                }
            });
        } else {
            registerJob(jobMeta);
        }
    }

    @Override
    public boolean configure(String domainId, String group, String jobName, String cronExpression,
            long repeatInterval, String configureUser) {
        String jobId = domainId + "." + group + "." + jobName;
        if (cronExpression == null) {
            cronExpression = "";
        }
        cronExpression = cronExpression.trim();
        if (repeatInterval <= 0l) {
            repeatInterval = -1l;
        }
        if (cronExpression.length() == 0 && repeatInterval == -1l) {
            throw new ResponseCodeException("5", "任务调度配置为空。");
        }
        //
        try {
        	weschedulerServices.checkJobExpression(cronExpression, repeatInterval);
        } catch (Exception ex) {
            throw new ResponseCodeException("4", ex.getMessage());
        }
        JobMeta meta = weschedulerServices.getJobMeta(jobId,false);
        if (meta == null) {
            throw new ResponseCodeException("3", "任务:" + jobId + "不存在。");
        }
        if (!(cronExpression.equals(meta.getCronExpression()) && repeatInterval == meta
                .getRepeatInterval())) {
            meta.setCronExpression(cronExpression);
            meta.setRepeatInterval(repeatInterval);
            meta.setUpdatedBy(configureUser);
            String rootPath=WeschedulerConstants.PIZZA_ROOT_PATH+"/"+domainId+WeschedulerConstants.PIZZA_PATH_REG;
            String regPath=rootPath
            		+"/"+group+"."+meta.getJobName()+"."+meta.getUpdatedBy();
            //--------------------------------
            pizza.set(regPath, JSONObject.toJSONString(meta),true);
            return true;
        };
        return false;
    }
    
   

    public void registerJob(JobMeta jobMeta) {
        try {
        	boolean regFlag=weschedulerServices.saveJobMeta(jobMeta);
        	if(regFlag){
        		 if (logger.isInfoEnabled()) {
                     logger.info("Registered Quartz job:" + jobMeta.getId());
                 }
                 this.registerQuartzJob(jobMeta);
        	}
        } catch (Throwable ex) {
            logger.error("Registered job:" + JSONObject.toJSONString(jobMeta) + " error,cause:"
                    + ex.getMessage(), ex);
        }
    }


    public void setPizzaManagerURL(String pizzaManagerURL) {
        this.pizzaManagerURL = pizzaManagerURL;
    }

    public void setThreadSize(int threadSize) {
        this.threadSize = threadSize;
    }

    public void setWeschedulerServices(WeschedulerServices weschedulerServices) {
        this.weschedulerServices = weschedulerServices;
    }

}
