package com.pingan.pafa.stp.wescheduler.server;

import org.quartz.Trigger;

/**
 * Wescheduler服务器端
 * @author ZHANGJIAWEI370
 * 
 */
public interface WeschedulerServer {

    /**
     * 配置任务
     * @param domainId
     * @param group
     * @param jobName
     * @param cronExpression
     * @param repeatInterval
     * @param configureUser
     * @return
     */
    public boolean configure(String domainId, String group, String jobName, String cronExpression,
            long repeatInterval, String configureUser);

    /**
     * 手动执行
     * @param quartzTrigger
     * @param triggerUser
     * @return
     */
    public String trigger(Trigger quartzTrigger, String triggerUser);

    /**
     * 手动执行
     * @param domainId
     * @param group
     * @param jobName
     * @param triggerUser
     * @return
     */
    public String trigger(String domainId, String group, String jobName, String triggerUser);

    /**
     * 停止任务
     * @param domainId
     * @param group
     * @param jobName
     * @param user
     */
    public void stopJob(String domainId, String group, String jobName, String user);

    /**
     * 恢复任务
     * @param domainId
     * @param group
     * @param jobName
     * @param user
     */
    public void recoverJob(String domainId, String group, String jobName, String user);

    /**
     * 清理
     */
    public void cleanReceipts();

}
