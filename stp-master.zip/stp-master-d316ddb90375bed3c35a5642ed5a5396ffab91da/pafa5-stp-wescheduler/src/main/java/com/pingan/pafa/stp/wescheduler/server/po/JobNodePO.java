package com.pingan.pafa.stp.wescheduler.server.po;

import java.util.Date;

import org.springframework.data.mongodb.core.index.CompoundIndex;
import org.springframework.data.mongodb.core.index.CompoundIndexes;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Wescheduler2JobNode")
@CompoundIndexes({@CompoundIndex(name = "def_index", def = "{jobId : 1, instanceIp : 1}")})
public class JobNodePO {

	@org.springframework.data.annotation.Id
    private String id;

    private String jobId;

    private String instanceIp;

    private Date lastActiveDate;

    public JobNodePO() {}

    public JobNodePO(String jobId, String instanceIp) {
        this.jobId = jobId;
        this.instanceIp = instanceIp;
        this.lastActiveDate = new Date();
    }

    @Override
    public String toString() {
        return "JobNodePO [id=" + id + ", jobId=" + jobId + ", instanceIp=" + instanceIp
                + ", lastActiveDate=" + lastActiveDate + "]";
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getInstanceIp() {
        return instanceIp;
    }

    public void setInstanceIp(String instanceIp) {
        this.instanceIp = instanceIp;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Date getLastActiveDate() {
        return lastActiveDate;
    }

    public void setLastActiveDate(Date lastActiveDate) {
        this.lastActiveDate = lastActiveDate;
    }

}
