package com.pingan.pafa.stp.wescheduler.server;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;
import org.quartz.SchedulerContext;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.springframework.context.ConfigurableApplicationContext;

import com.pingan.pafa.papp.exception.ResponseCodeException;

public class WeschedulerQuartzJob implements Job {

    private static Log logger = LogFactory.getLog(WeschedulerQuartzJob.class);

    public void execute(JobExecutionContext jobContext) throws JobExecutionException {
        ConfigurableApplicationContext applicationContext = null;
        try {
            SchedulerContext schedulerContext = jobContext.getScheduler().getContext();
            String key = (String) schedulerContext.get("spring_context_key");
            if (key != null) {
                applicationContext = (ConfigurableApplicationContext) schedulerContext.get(key);
            } else {
                throw new JobExecutionException(
                        "Not found ApplicationContext key in SchedulerContext ");
            }
        } catch (SchedulerException e) {
        }
        if (applicationContext == null) {
            throw new JobExecutionException("Not found ApplicationContext  in SchedulerContext ");
        }
        execute(applicationContext, jobContext.getTrigger());
    }

    public void execute(ConfigurableApplicationContext context, Trigger trigger) {
        if (context != null && context.isActive()) {
            try {
                context.getBean(WeschedulerServer.class).trigger(trigger, null);
            } catch (ResponseCodeException ex) {
                logger.warn("调度Job:" + trigger.getName() + "失败：" + ex.getResponseCode() + ","
                        + ex.getResponseMsg());
            } catch (Throwable ex) {
                logger.error("调度Job:" + trigger.getName() + "失败：" + ex.getMessage(), ex);
            }
        }
    }

}
