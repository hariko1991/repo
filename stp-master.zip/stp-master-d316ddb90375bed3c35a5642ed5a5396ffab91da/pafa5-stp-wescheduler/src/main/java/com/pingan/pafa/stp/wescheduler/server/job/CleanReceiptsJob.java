package com.pingan.pafa.stp.wescheduler.server.job;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.pingan.pafa.stp.wescheduler.server.WeschedulerServer;

@Component
public class CleanReceiptsJob {
	
	@Autowired
	private WeschedulerServer weschedulerServer;

	@Scheduled(fixedRateString="10000")
	public void execute(){
		weschedulerServer.cleanReceipts();
	}

	public void setWeschedulerServer(WeschedulerServer weschedulerServer) {
		this.weschedulerServer = weschedulerServer;
	}
	
}
