package com.pingan.pafa.stp.wescheduler.server.web;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.papp.esa.ResponseModel;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa.stp.wescheduler.server.WeschedulerServer;
import com.pingan.pafa.stp.wescheduler.server.po.JobInfoPO;
import com.pingan.pafa.stp.wescheduler.server.po.JobNodePO;
import com.pingan.pafa.stp.wescheduler.server.po.TriggerRecordPO;
import com.pingan.pafa.stp.wescheduler.server.services.WeschedulerServices;

@Controller
public class WeschedulerController extends BaseController {

    @Autowired
    private WeschedulerServices weschedulerServices;

    @Autowired
    private WeschedulerServer weschedulerServer;

    @ResponseBody
    @ESA("stp-wescheduler.get-info")
    public ResponseModel get(@RequestParam("domainId") String domainId, 
            @RequestParam("group") String group, @RequestParam("name") String jobName) {
        JobInfoPO info = weschedulerServices.getInfo(domainId, group, jobName);
        if (info != null) {
            ResponseModel model = new ResponseModel();
            model.put("jobInfo", info);
            List<JobNodePO> pos = weschedulerServices.listNodes(domainId, group, jobName);
            if (pos != null && pos.size() > 0) {
                List<ModelMap> nodes = new ArrayList<ModelMap>();
                for (JobNodePO po : pos) {
                    ModelMap map = new ModelMap();
                    map.put("instanceIp", po.getInstanceIp());
                    map.put("lastActiveDate", po.getLastActiveDate());
                    nodes.add(map);
                }
                model.put("jobNodes", nodes);
            }
            return model;
        } else {
            return new ResponseModel("1", "Job不存在！");
        }
    }

    @ResponseBody
    @ESA("stp-wescheduler.list")
    public ResponseModel list(@RequestParam(value = "domainId", defaultValue = "def") String domainId, 
            @RequestParam("group") String group, 
            @RequestParam(value = "limit", defaultValue = "30") int limit,
            @RequestParam(value = "page", defaultValue = "1") int page) {
        List<JobInfoPO> datas = weschedulerServices.list(domainId, group, limit, page);
        ResponseModel model = new ResponseModel();
        model.put("jobs", datas);
        model.put("jobSize", datas == null ? 0 : datas.size());
        return model;
    }

    @ResponseBody
    @ESA("stp-wescheduler.configure")
    public ResponseModel configure(
            @RequestParam("domainId") String domainId, @RequestParam("group") String group,
            @RequestParam("name") String jobName,
            @RequestParam(value = "cronExpression", required = false) String cronExpression,
            @RequestParam(value = "repeatInterval", defaultValue = "-1", required = false) int repeatInterval,
            @RequestParam("user") String configureUser) {
        boolean isChanged = false;
        try {
            isChanged =
                    weschedulerServer.configure(domainId, group, jobName, cronExpression, repeatInterval,
                            configureUser);
        } catch (ResponseCodeException ex) {
            return new ResponseModel(ex.getResponseCode(), ex.getResponseMsg());
        } catch (Throwable ex) {
            logger.error("Trigger failured,cause:" + ex.getMessage(), ex);
            return new ResponseModel("9", "配置失败，系统错误。");
        }
        if (isChanged) {
            return new ResponseModel("0", "配置完成。");
        } else {
            return new ResponseModel("1", "配置没有变化。");
        }
    }

    @ResponseBody
    @ESA("stp-wescheduler.manual-trigger")
    public ResponseModel manualTrigger(@RequestParam("domainId") String domainId, 
            @RequestParam("group") String group, @RequestParam("name") String jobName, 
            @RequestParam("user") String triggerUser) {
        if (logger.isInfoEnabled()) {
            logger.info("manualTrigger for job:" + jobName + ", and group:" + group + " by user:"
                    + triggerUser);
        }
        String triggerId = null;
        try {
            triggerId = weschedulerServer.trigger(domainId, group, jobName, triggerUser);
        } catch (ResponseCodeException ex) {
            return new ResponseModel(ex.getResponseCode(), ex.getResponseMsg());
        } catch (Throwable ex) {
            logger.error("Trigger failured,cause:" + ex.getMessage(), ex);
            return new ResponseModel("9", "调度失败，系统错误。");
        }
        if (logger.isInfoEnabled()) {
            logger.info("manualTrigger for job:" + jobName + ", and group:" + group + " completed.");
        }
        ResponseModel model = new ResponseModel("0", "调度成功。");
        model.put("triggerId", triggerId);
        return model;
    }

    @ResponseBody
    @ESA("stp-wescheduler.query-execute-result")
    public ResponseModel queryExecuteResult(@RequestParam("triggerId") String triggerId) {
        if (logger.isInfoEnabled()) {
            logger.info("queryExecuteResult for triggerId:" + triggerId + ".");
        }
        TriggerRecordPO recored = weschedulerServices.getTriggerResult(triggerId);
        if (recored != null) {
            String user = recored.getTriggerUser();
            if (user != null && user.trim().length() > 0) {
                recored.setWeschedulerType(2);
            } else {
                recored.setWeschedulerType(1);
            }
        }
        if (recored == null) {
            return new ResponseModel("1", "未找到对应的调度记录。");
        } else {
            ResponseModel model = new ResponseModel();
            model.put("recored", recored);
            return model;
        }
    }

    @ResponseBody
    @ESA("stp-wescheduler.query-trigger-recoreds")
    public ResponseModel queryTriggerRecoreds(@RequestParam("domainId") String domainId, 
            @RequestParam("group") String group, @RequestParam("name") String jobName, 
            @RequestParam(value = "limitSize", defaultValue = "10") int limitSize, 
            @RequestParam(value = "page", defaultValue = "1") int page) {
        if (limitSize < 0 || limitSize > 50) {
            limitSize = 10;
        }
        List<TriggerRecordPO> recoreds =
                weschedulerServices.listTriggerRecoreds(domainId, group, jobName, limitSize, page);
        if (recoreds != null && recoreds.size() > 0) {
            for (TriggerRecordPO po : recoreds) {
                String user = po.getTriggerUser();
                if (user != null && user.trim().length() > 0) {
                    po.setWeschedulerType(2);
                } else {
                    po.setWeschedulerType(1);
                }
            }
        }
        String jobId = domainId + "." + group + "." + jobName;
        long count = weschedulerServices.countRecordsByJobId(jobId);
        ResponseModel model = new ResponseModel();
        model.put("recoreds", recoreds);
        model.put("recoredSize", count);
        return model;
    }

    @ResponseBody
    @ESA("stp-wescheduler.stop")
    public ResponseModel stop(@RequestParam("domainId") String domainId, 
            @RequestParam("group") String group, @RequestParam("name") String jobName, 
            @RequestParam("user") String user) {
        if (logger.isInfoEnabled()) {
            logger.info("stop job:" + jobName + ", and group:" + group + " by user:" + user);
        }
        weschedulerServer.stopJob(domainId, group, jobName, user);
        return new ResponseModel("0", "停止调度成功。");
    }

    @ResponseBody
    @ESA("stp-wescheduler.recover")
    public ResponseModel recover(@RequestParam("domainId") String domainId, 
            @RequestParam("group") String group, @RequestParam("name") String jobName, 
            @RequestParam("user") String user) {
        if (logger.isInfoEnabled()) {
            logger.info("recover job:" + jobName + ", and group:" + group + " by user:" + user);
        }
        weschedulerServer.recoverJob(domainId, group, jobName, user);
        return new ResponseModel("0", "恢复调度成功。");
    }

    public void setWeschedulerServices(WeschedulerServices weschedulerServices) {
        this.weschedulerServices = weschedulerServices;
    }

}
