package com.pingan.pafa.stp.wescheduler.server.po;

import java.util.Date;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Wescheduler2JobLockInfo")
public class JobLockPO {

	@org.springframework.data.annotation.Id
    private String jobId;
    
    private long lockExpiredTimestamp;

    private Date updatedDate;

    @Override
    public String toString() {
        return "JobLockPO [jobId=" + jobId + ", lockExpiredTimestamp=" + lockExpiredTimestamp
                + ", updatedDate=" + updatedDate + "]";
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public long getLockExpiredTimestamp() {
        return lockExpiredTimestamp;
    }

    public void setLockExpiredTimestamp(long lockExpiredTimestamp) {
        this.lockExpiredTimestamp = lockExpiredTimestamp;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

}
