package com.pingan.pafa.stp.wescheduler.server.services;

public class TriggerResult {

    /** 1job不存在,2job已停止或已过期 */
    private int code;

    private String msg;

    private String group;

    private String jobName;
    
    private String domainId;

    private String triggerId;

    public TriggerResult() {}

    public TriggerResult(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getTriggerId() {
        return triggerId;
    }

    public void setTriggerId(String triggerId) {
        this.triggerId = triggerId;
    }

    public int getCode() {
        return code;
    }

    public void setCode(int code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

	public String getDomainId() {
		return domainId;
	}

	public void setDomainId(String domainId) {
		this.domainId = domainId;
	}

}
