package com.pingan.pafa.stp.wescheduler.server.po;

import java.util.Date;

import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Wescheduler2TriggerRecord")
public class TriggerRecordPO {

	@org.springframework.data.annotation.Id
    private String id;

    @Indexed
    private String jobId;

    @Indexed
    private long triggerDate;

    /***
     * 手动触发用户
     */
    private String triggerUser;

    private int weschedulerType;// 调度方式 1系统 2手动

    /** 执行节点 */
    private String executeNodeIp;

    /** 执行耗时 */
    private double costTime = -1d;

    /** 回执时间 */
    private Date receiptDate;

    /**
     * 回执状态 0:未执行 1:未执行(已通知) 9:未执行(回执超时) 2:执行成功 3:执行失败 4:执行失败(任务过期)
     * */
    private int receiptStatus;

    /** 回执信息 */
    private String receiptMsg;

    private String logId;

    @Override
    public String toString() {
        return "TriggerRecordPO [id=" + id + ", jobId=" + jobId + ", triggerDate=" + triggerDate
                + ", triggerUser=" + triggerUser + ", weschedulerType=" + weschedulerType
                + ", executeNodeIp=" + executeNodeIp + ", costTime=" + costTime + ", receiptDate="
                + receiptDate + ", receiptStatus=" + receiptStatus + ", receiptMsg=" + receiptMsg
                + ", logId=" + logId + "]";
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public long getTriggerDate() {
        return triggerDate;
    }

    public void setTriggerDate(long triggerDate) {
        this.triggerDate = triggerDate;
    }

    public String getExecuteNodeIp() {
        return executeNodeIp;
    }

    public void setExecuteNodeIp(String executeNodeIp) {
        this.executeNodeIp = executeNodeIp;
    }

    public double getCostTime() {
        return costTime;
    }

    public void setCostTime(double costTime) {
        this.costTime = costTime;
    }

    public Date getReceiptDate() {
        return receiptDate;
    }

    public void setReceiptDate(Date receiptDate) {
        this.receiptDate = receiptDate;
    }

    public int getReceiptStatus() {
        return receiptStatus;
    }

    public void setReceiptStatus(int receiptStatus) {
        this.receiptStatus = receiptStatus;
    }

    public String getReceiptMsg() {
        return receiptMsg;
    }

    public void setReceiptMsg(String receiptMsg) {
        this.receiptMsg = receiptMsg;
    }

    public String getLogId() {
        return logId;
    }

    public void setLogId(String logId) {
        this.logId = logId;
    }

    public String getTriggerUser() {
        return triggerUser;
    }

    public void setTriggerUser(String triggerUser) {
        this.triggerUser = triggerUser;
    }

    public int getWeschedulerType() {
        return weschedulerType;
    }

    public void setWeschedulerType(int weschedulerType) {
        this.weschedulerType = weschedulerType;
    }

}
