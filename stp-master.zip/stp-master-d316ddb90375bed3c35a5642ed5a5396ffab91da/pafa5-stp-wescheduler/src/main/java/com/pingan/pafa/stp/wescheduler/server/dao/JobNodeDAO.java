package com.pingan.pafa.stp.wescheduler.server.dao;

import java.util.List;

import com.pingan.pafa.stp.wescheduler.server.po.JobNodePO;

public interface JobNodeDAO {
	
	boolean exists(String jobId,String instanceIp);
	
	 List<JobNodePO> list(String jobId);
	
	void save(String jobId,String instanceIp);

	void save(JobNodePO po);
	
}
