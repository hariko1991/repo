package com.pingan.pafa.stp.wescheduler.server;

import java.util.Calendar;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.ObjectAlreadyExistsException;
import org.quartz.Scheduler;
import org.quartz.SchedulerException;
import org.quartz.Trigger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.quartz.CronTriggerBean;
import org.springframework.scheduling.quartz.JobDetailAwareTrigger;
import org.springframework.scheduling.quartz.SimpleTriggerBean;

import com.pingan.pafa.stp.wescheduler.common.JobMeta;
import com.pingan.pafa.stp.wescheduler.common.WeschedulerException;

public class QuartzJobHandler {

    protected Log logger = LogFactory.getLog(this.getClass());

    @Autowired
    private Scheduler scheduler;

    private final static String QUARTZ_GROUP = "WESCHEDULER";

    protected Trigger getQuartzTrigger(JobMeta jobMeta) throws Exception {
        JobDetail jobDetail =
                new JobDetail(jobMeta.getId(), QUARTZ_GROUP, WeschedulerQuartzJob.class);

        jobDetail.setVolatility(true);
        String cronExpression = jobMeta.getCronExpression();

        if (cronExpression != null && (cronExpression = cronExpression.trim()).length() > 0) {
            CronTriggerBean c = new CronTriggerBean();
            c.setBeanName(jobMeta.getId());
            int startDelay = jobMeta.getStartDelay();
            if (startDelay > 0) {
                Calendar statTime = Calendar.getInstance();
                statTime.add(Calendar.MILLISECOND, startDelay);
                c.setStartTime(statTime.getTime());
            }
            c.setJobDetail(jobDetail);
            c.setGroup(QUARTZ_GROUP);
            c.setCronExpression(cronExpression);
            c.afterPropertiesSet();
            return c;
        } else {
            SimpleTriggerBean c = new SimpleTriggerBean();
            c.setBeanName(jobMeta.getId());
            int startDelay = jobMeta.getStartDelay();
            if (startDelay > 0) {
                c.setStartDelay(startDelay);
            }
            long repeatInterval = jobMeta.getRepeatInterval();
            if (repeatInterval > 0) {
                c.setRepeatInterval(repeatInterval);
            }
            c.setGroup(QUARTZ_GROUP);
            c.setJobDetail(jobDetail);
            c.afterPropertiesSet();
            return c;
        }
    }

    protected void registerQuartzJob(JobMeta jobMeta) {
        try {
            Trigger quartzTrigger = getQuartzTrigger(jobMeta);
            registerQuartzJob(scheduler, quartzTrigger);
        } catch (Exception e) {
            throw new WeschedulerException("Register quartz job:" + jobMeta.getId()
                    + " error,cause:" + e.getMessage(), e);
        }
    }

    protected boolean checkQuartzJob(String jobId) {
        try {
            return (scheduler.getTrigger(jobId, QUARTZ_GROUP) != null);
        } catch (SchedulerException e) {
            throw new WeschedulerException("CheckExists quartz job:" + jobId + " error,cause:"
                    + e.getMessage(), e);
        }
    }

    protected void delQuartzJob(String jobId) {
        try {
            if (logger.isInfoEnabled()) {
                logger.info("Del quartz job:" + jobId);
            }
            if (scheduler.getTrigger(jobId, QUARTZ_GROUP) != null) {
                scheduler.deleteJob(jobId, QUARTZ_GROUP);
            }
        } catch (Exception e) {
            throw new WeschedulerException("Del quartz job:" + jobId + " error,cause:"
                    + e.getMessage(), e);
        }
    }

    protected void registerQuartzJob(Scheduler scheduler, Trigger trigger)
            throws SchedulerException {
        if (trigger instanceof CronTrigger && trigger.getFireTimeAfter(null) == null) {
            throw new WeschedulerException("cronExpression<"
                    + ((CronTrigger) trigger).getCronExpression() + "> will never fire.");
        }
        
        String jobId = trigger.getName();
        boolean triggerExists = (scheduler.getTrigger(jobId, QUARTZ_GROUP) != null);

        if (trigger instanceof JobDetailAwareTrigger) {
            JobDetail jobDetail = ((JobDetailAwareTrigger) trigger).getJobDetail();
            scheduler.addJob(jobDetail, true);
        }
        if (!triggerExists) {
            try {
                scheduler.scheduleJob(trigger);
            } catch (ObjectAlreadyExistsException ex) {
                scheduler.rescheduleJob(jobId, QUARTZ_GROUP, trigger);
            }
        } else {
            scheduler.rescheduleJob(jobId, QUARTZ_GROUP, trigger);
        }
    }

    public Trigger getQuartzTrigger(String jobId) {
        Trigger trigger = null;
        try {
            trigger = scheduler.getTrigger(jobId, QUARTZ_GROUP);
        } catch (SchedulerException e) {
            throw new WeschedulerException("Error, cause:" + e.getMessage(), e);
        }
        return trigger;
    }

    public void setScheduler(Scheduler scheduler) {
        this.scheduler = scheduler;
    }

}
