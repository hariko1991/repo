package com.pingan.pafa.stp.wescheduler.server.dao.impl;

import java.util.Date;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa.stp.wescheduler.server.dao.JobLockDAO;
import com.pingan.pafa.stp.wescheduler.server.po.JobLockPO;


@Repository
public class JobLockDAOImpl extends BaseMongoDAO<JobLockPO> implements JobLockDAO {
	
	private static final Log log = LogFactory.getLog(JobLockDAOImpl.class);

    @Override
    public boolean lock(String jobId, int lockExpireTime) {
        JobLockPO po = new JobLockPO();
        po.setJobId(jobId);
        Date cur = new Date();
        long curTimestamp = cur.getTime();
        po.setLockExpiredTimestamp(curTimestamp + lockExpireTime);
        po.setUpdatedDate(cur);
        boolean locked = false;
        try {
            locked =
                    this._upsert(
                            this.where("jobId").is(jobId).and("lockExpiredTimestamp")
                                    .lt(curTimestamp), po) != 0;
        } catch (Exception ex) {
        	log.error("lock job error , detail is : " + ex.getMessage());
        }
        return locked;
    }

    @Override
    public boolean unlock(String jobId) {
        return this._update(this.where("jobId").is(jobId),
                Update.update("lockExpiredTimestamp", 0l));
    }

}
