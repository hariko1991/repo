package com.pingan.pafa.stp.wescheduler_server;

import java.util.Date;

import org.quartz.CronExpression;

public class CronExpressionTests {

	public static void main(String args[]) throws Exception{
		
		String cronString="0/60 * * * * ?";
		CronExpression cron=new CronExpression(cronString);;
    	System.out.println(cron.getFinalFireTime());
    	Date cur=new Date();
    	System.out.println(cur);
    	Date d1=cron.getNextValidTimeAfter(cur);
    	System.out.println(d1);
    	Date d2=cron.getNextValidTimeAfter(d1);
    	System.out.println(d2);
    	Date d3=cron.getNextValidTimeAfter(d2);
    	System.out.println(d3);
    	Date d4=cron.getNextValidTimeAfter(d3);
    	System.out.println(d4);
	}
}
