package com.pingan.pafa.stp.proxy.amesb;

import org.junit.Test;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.ServiceResults;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList={"stp_amesb_proxy"})
public class AmesbProxyTests extends BaseSARTest{
	
	@ActionClient(name="amesb.bis_middle_RealTimeTransactionEsbServiceForCPC")
	private IServiceClient test;
	
	
	@Test
	public void iz() throws Throwable{
		ServiceResults result=test.invoke(ServiceParams.newInstance().set("name", "zhangsan"));
		logger.info("result="+result);
	}
	
}
