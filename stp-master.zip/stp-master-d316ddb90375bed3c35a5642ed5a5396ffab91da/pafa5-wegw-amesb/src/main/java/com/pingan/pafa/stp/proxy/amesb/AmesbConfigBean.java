package com.pingan.pafa.stp.proxy.amesb;

import java.io.File;
import java.lang.reflect.Method;

import org.apache.commons.io.FileUtils;
import org.springframework.beans.FatalBeanException;
import org.springframework.util.ClassUtils;

import com.pingan.pafa.pizza.BaseConfigListener;

/***
 * @deprecated
 * @author LIXINGNAN945
 *
 */
public class AmesbConfigBean extends  BaseConfigListener{

	
	public AmesbConfigBean(){
		this.setDynamicConfig(true);
	}
	
	@Override
	protected void onChanged(String configValue) {
		try {
			ClassLoader classloader=ClassUtils.getDefaultClassLoader();
			Thread.currentThread().setContextClassLoader(classloader);
			String root=classloader.getResource("").getFile();
			if(logger.isInfoEnabled()){
				logger.info("Classes directory="+root);
			}
			File file=new File(root+"/amesb_client.properties");
			if(file.exists())file.delete();
			file.createNewFile();
			FileUtils.writeStringToFile(file, configValue);
			//
			Class<?> AmesbConfigClass=ClassUtils.forName("com.paic.amesb.service.AmesbConfig",classloader);
			Method method=AmesbConfigClass.getMethod("getInstance", new Class<?>[]{});
			method.invoke(null, new Object[]{});
		} catch (Exception e) {
			throw new FatalBeanException("Amesb init failed,cause:"+e.getMessage(),e);
		}
	}

	@Override
	protected void onStatupLoad(String configValue) {
		onChanged(configValue);
	}

	
}
