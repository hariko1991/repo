package com.pingan.pafa.stp.proxy.amesb;

import java.rmi.RemoteException;
import java.util.HashMap;
import java.util.Map;
import com.paic.amesb.facade.Msg;
import com.paic.amesb.facade.Otc;
import com.paic.amesb.facade.send.SendFacade;
import com.paic.pafa.app.biz.ac.ApplicationController;
import com.paic.pafa.app.biz.ac.ApplicationControllerException;
import com.paic.pafa.app.dto.ServiceRequest;
import com.paic.pafa.app.dto.ServiceResponse;


@SuppressWarnings("unchecked")
public class AmesbProxyApplicationController implements ApplicationController {
	

	@Override
	public ServiceResponse handleRequest(ServiceRequest request)
			throws ApplicationControllerException, RemoteException {
		String amesbServiceURL=request.getRequestedServiceID();
		Msg msg=toAmesbMsg(request,amesbServiceURL);
		//
		Otc otc=SendFacade.synchroSend(msg);
		ServiceResponse response=this.toResponse(otc);
		return response;
	}
	
	protected ServiceResponse toResponse(Otc otc){
		if(otc==null){
			return null;
		}
		ServiceResponse response=new ServiceResponse();
		Map<Object,Object> datas=new HashMap<Object,Object>(otc.size());
		datas.putAll(otc);
		response.setModel(datas);
		return response;
	}
	
	protected Msg toAmesbMsg(ServiceRequest request,String amesbServiceURL) {
		Msg msg = new Msg();
		msg.setHandlerId("ServiceStrongAdapter");
		msg.setServiceURL(amesbServiceURL);
		Map<?, ?> params=request.getParameters();
		if(params!=null && params.size()>0){
			msg.putAll(params);
		}
		return msg;
	}

}
