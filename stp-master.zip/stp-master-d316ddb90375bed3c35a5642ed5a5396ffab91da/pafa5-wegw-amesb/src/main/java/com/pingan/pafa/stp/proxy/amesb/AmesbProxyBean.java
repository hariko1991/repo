package com.pingan.pafa.stp.proxy.amesb;

import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.app.biz.ac.ApplicationController;
import com.paic.pafa.app.biz.ac.ApplicationControllerException;
import com.paic.pafa.app.dto.ServiceRequest;
import com.paic.pafa.app.dto.ServiceResponse;
import com.pingan.pafa.papp.esa.ESADefinition;
import com.pingan.pafa.papp.esa.ESADispatcher;


public class AmesbProxyBean implements ESADispatcher {
	
	protected  Log logger=LogFactory.getLog(this.getClass());
	

	private Map<String,String> exportMapping;
	
	
	private Map<String,Properties> esaConfigs;
	
	
	private ApplicationController pafaAc;
	

	private boolean enableLog=true;
	
	
	
	@Override
	public ServiceResponse handleRequest(ServiceRequest request)
			throws ApplicationControllerException, RemoteException {
		String esaName=request.getRequestedServiceID();
		String amesbServiceURL=null;
		if(exportMapping!=null && exportMapping.size()>0){
			amesbServiceURL=exportMapping.get(esaName);
		}
		if(amesbServiceURL==null){
			amesbServiceURL=esaName;
		}
		if(logger.isInfoEnabled()){
			logger.info("Handle request<"+esaName+"> and amesbServiceId=<"+amesbServiceURL+">...");
		}
		//----------------------
		return _handleRequest(request,amesbServiceURL);
	}
	
	public   ServiceResponse _handleRequest(ServiceRequest request,String amesbServiceURL) throws ApplicationControllerException, RemoteException {
		long t1=System.nanoTime();
		try {
			if(this.isEnableLog() && logger.isDebugEnabled()){
				logger.debug("Handling AmesbService<"+amesbServiceURL+"> params="+JSONObject.toJSONString(request.getParameters()));
			}
			request.setRequestedServiceID(amesbServiceURL);
			ServiceResponse response=getPafaAc().handleRequest(request);
			Object m=(response==null?null:response.getModel());
			//------------------------------
			if(this.isEnableLog() && logger.isDebugEnabled()){
				logger.debug("Handled AmesbService<"+amesbServiceURL+">result="+(m==null?"{}":JSONObject.toJSONString(m))+".");
			}
			if(logger.isInfoEnabled()){
				logger.info("#"+(System.nanoTime()-t1)/1000/1000.0+"ms# Handled AmesbService<"+amesbServiceURL+"> completed.");
			}
			return response;
		} catch (Throwable e) {
			//------------
			if(logger.isErrorEnabled()){
				String message="#"+(System.nanoTime()-t1)/1000/1000.0+"ms# Handled AmesbService<"+amesbServiceURL+"> failed,params="
					+JSONObject.toJSONString(request.getParameters());
				logger.error(message);
			}
			if(e instanceof RuntimeException){
				throw (RuntimeException)e;
			}else if(e instanceof RemoteException){
				throw (RemoteException)e;
			}else if(e instanceof ApplicationControllerException){
				throw (ApplicationControllerException)e;
			}else{
				throw new ApplicationControllerException(e);
			}
		}
	}
	
	
	
	

	
	 
	public ApplicationController getPafaAc() {
		if(pafaAc==null){
			pafaAc=new AmesbProxyApplicationController();
		}
		return pafaAc;
	}

	public void setPafaAc(ApplicationController pafaAc) {
		this.pafaAc = pafaAc;
	}

	@Override
	public Collection<ESADefinition> resolveESADefinitions() {
		if(exportMapping!=null && exportMapping.size()>0){
			Set<String> esaNames= exportMapping.keySet();
			ArrayList<ESADefinition> definitions=new ArrayList<ESADefinition>(esaNames.size());
			for(String esaName:esaNames){
				if(esaName==null || esaName.length()==0){
					continue;
				}
				ESADefinition definition=new ESADefinition(esaName);
				if(this.esaConfigs!=null){
					definition.setProperties(esaConfigs.get(esaName));
				}
				definitions.add(definition);
			}
			return definitions;
		}
		return null;
	}


	

	public Map<String, String> getExportMapping() {
		return exportMapping;
	}

	public void setExportMapping(Map<String, String> exportMapping) {
		this.exportMapping = exportMapping;
	}

	

	public boolean isEnableLog() {
		return enableLog;
	}

	public void setEnableLog(boolean enableLog) {
		this.enableLog = enableLog;
	}

	public Map<String, Properties> getEsaConfigs() {
		return esaConfigs;
	}

	public void setEsaConfigs(Map<String, Properties> esaConfigs) {
		this.esaConfigs = esaConfigs;
	}
	
}
