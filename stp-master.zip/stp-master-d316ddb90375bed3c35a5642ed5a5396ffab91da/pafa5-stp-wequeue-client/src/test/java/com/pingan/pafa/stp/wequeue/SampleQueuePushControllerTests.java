package com.pingan.pafa.stp.wequeue;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;


@SARContextConfiguration(sarList={"stp_wequeue_sample"})
public class SampleQueuePushControllerTests extends BaseSARTest{

	@Test()
	public void test() throws Exception{
		String result=this.handleWebRequest(this.createMockRequest("/esa/stp_wequeue_sample.test","count=2")
				, this.createMockResponse());
		logger.info(result);
		System.in.read();
	}
	
}
