package com.pingan.pafa.stp.wequeue.client_sample;

import org.springframework.stereotype.Component;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.stp.wequeue.client.WequeueConsumer;
import com.pingan.pafa.stp.wequeue.client.WequeueMsgMeta;


@Component("sampleQueueConsumer")
public class SampleQueueConsumer extends BaseServices {
	
	//注明此方法为队列的消费者
	@WequeueConsumer
	public void listener(UserMsg form,WequeueMsgMeta meta) throws Exception{
		logger.info("******************************************meta="+meta);
		logger.info("******************************************body="+JSONObject.toJSONString(form));
		
	}
	
	
}
