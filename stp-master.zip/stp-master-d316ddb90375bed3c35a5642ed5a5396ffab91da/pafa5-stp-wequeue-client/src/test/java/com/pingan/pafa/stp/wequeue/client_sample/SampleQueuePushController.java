package com.pingan.pafa.stp.wequeue.client_sample;

import java.util.UUID;

import javax.annotation.Resource;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.stereotype.Component;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestParam;

import com.pingan.pafa.papp.ESA;
import com.pingan.pafa.stp.wequeue.client.WequeueClient;
import com.pingan.pafa.stp.wequeue.common.msg.WequeuePushResultMsg;

@Component
public class SampleQueuePushController   {
	
	private Log logger=LogFactory.getLog(this.getClass());
	
	@Resource(name="sampleQueueClient")
	private WequeueClient wequeueClient;

	@ESA("stp_wequeue_sample.test")
	public ModelMap triggerSample(@RequestParam(value="count",required=false) Integer count
			,@RequestParam(value="threadSize",required=false) Integer threadSize){
		if(threadSize!=null && threadSize>0){
			for(int i=0;i<threadSize;i++){
				Thread t=new Thread(new Executor(count));
				t.setName("wevent-threads-test-"+i);
				t.setDaemon(true);
				//----------------------------------
				t.start();
			}
		}else{
			new Executor(count).run();
		}
		ModelMap model=new ModelMap();
		model.put("responseCode","0");
		return model;
	}
	
	class Executor implements Runnable{
		
		private int count;
		
		public Executor(Integer count){
			if(count==null || count<=0)count=1;
			this.count=count;
		}

		@Override
		public void run() {
			for(int i=0;i<count;i++){
				ModelMap msgBody=new ModelMap();
				String fileId=UUID.randomUUID().toString().replaceAll("-", "");
				msgBody.put("userId", fileId);
				msgBody.put("name", System.currentTimeMillis()+(15*24*60*60*1000));
				msgBody.put("xxxx", "abc123");
				//消息体
				WequeuePushResultMsg result=wequeueClient.push(msgBody);
				if(logger.isInfoEnabled()){
					logger.info("************************************result="+result+",Thread="+Thread.currentThread().getId());
				}
			}
			
		}
		
	}

	public WequeueClient getWequeueClient() {
		return wequeueClient;
	}

	public void setWequeueClient(WequeueClient wequeueClient) {
		this.wequeueClient = wequeueClient;
	}

	
	
	
	

	
}
