package com.pingan.pafa.stp.wequeue.common.msg;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;


public class WequeueConsumeMsg implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String queueName;
	
	private String publisherName;
	
	private String publisherIp;
	
	private Long  rid;
	
	private Map<?,?> body;
	
	private Long clientPushDate;
	
	private Long noticeDate;
	
	private boolean retryFlag;
	
	

	@Override
	public String toString() {
		DateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		return "{queueName="+this.queueName+",publisherName="+publisherName+",publisherIp="+publisherIp+",rid="+rid
				+",clientPushDate="+(clientPushDate==null?"null":format.format(new Date(clientPushDate)))
				+",noticeDate="+(noticeDate==null?"null":format.format(new Date(noticeDate)))
				+",retryFlag="+retryFlag
				+"}";
				
	}

	

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}

	

	public Long getClientPushDate() {
		return clientPushDate;
	}



	public void setClientPushDate(Long clientPushDate) {
		this.clientPushDate = clientPushDate;
	}



	public Long getNoticeDate() {
		return noticeDate;
	}

	public void setNoticeDate(Long noticeDate) {
		this.noticeDate = noticeDate;
	}

	

	public boolean isRetryFlag() {
		return retryFlag;
	}

	public void setRetryFlag(boolean retryFlag) {
		this.retryFlag = retryFlag;
	}

	@Override
	protected WequeueConsumeMsg clone()  {
		try {
			return (WequeueConsumeMsg)super.clone();
		} catch (CloneNotSupportedException e) {
		}
		return null;
	}



	public String getQueueName() {
		return queueName;
	}



	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}



	public String getPublisherName() {
		return publisherName;
	}



	public void setPublisherName(String publisherName) {
		this.publisherName = publisherName;
	}



	public String getPublisherIp() {
		return publisherIp;
	}



	public void setPublisherIp(String publisherIp) {
		this.publisherIp = publisherIp;
	}



	public Map<?, ?> getBody() {
		return body;
	}



	public void setBody(Map<?, ?> body) {
		this.body = body;
	}

	
	
	
	
}
