package com.pingan.pafa.stp.wequeue.client;

import java.lang.reflect.Method;
import java.util.Date;
import java.util.Map;

import org.springframework.aop.support.AopUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.FatalBeanException;
import org.springframework.context.ConfigurableApplicationContext;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.app.biz.ac.ApplicationControllerException;
import com.paic.pafa.app.dto.ServiceRequest;
import com.paic.pafa.app.dto.ServiceResponse;
import com.paic.pafa.app.dto.SessionDTO;
import com.paic.pafa.utils.MDCData;
import com.paic.pafa.utils.MDCUtil;
import com.pingan.pafa.common.beans.map.BeanMapUtils;
import com.pingan.pafa.papp.esa.annotation.MethodESA;
import com.pingan.pafa.papp.esa.annotation.MethodESAFactory;
import com.pingan.pafa.stp.wequeue.common.Wequeue;
import com.pingan.pafa.stp.wequeue.common.msg.WequeueConsumeMsg;

public  class WequeueConsumeListenerFactory extends WequeueReceiptQueueBean {
	
	private BeanMapUtils beanMapUtils=new BeanMapUtils();
	
    private MethodESA methodESA;
	
	private String consumeListenerBeanName;
	
	
	protected MethodESA getESA() {
		if(methodESA==null){
			synchronized(this){
				if(methodESA==null){
					methodESA=findAnnotaion(this.consumeListenerBeanName);
				}
			}
		}
		return methodESA;
	}
 
	
	protected   ServiceResponse handleRequest(ServiceRequest request) throws Throwable {
		String queueName=request.getRequestedServiceID();
		if(logger.isInfoEnabled()){
			logger.info("Consume Queue<"+queueName+">...");
		}
		long t1=System.nanoTime();
		try {
			MethodESA  esa=getESA();
			//---------------------------------------------
			if(logger.isDebugEnabled()){
				logger.debug("Consume Queue<"+queueName+"> params="+JSONObject.toJSONString(request.getParameters()));
			}
			ServiceResponse response=esa.perform(request, (ConfigurableApplicationContext)this.getApplicationContext(), null,null);
			Object m=(response==null?null:response.getModel());
			//------------------------------
			if( logger.isDebugEnabled()){
				logger.debug("Consume Queue<"+queueName+">result="+(m==null?"{}":JSONObject.toJSONString(m))+".");
			}
			if(logger.isInfoEnabled()){
				logger.info("#"+(System.nanoTime()-t1)/1000/1000.0+"ms# Consume Queue<"+queueName+"> completed.");
			}
			return response;
		} catch (Throwable e) {
			//------------
			if(logger.isErrorEnabled()){
				String message="#"+(System.nanoTime()-t1)/1000/1000.0+"ms# Consume Queue<"+queueName+"> failed,params="
					+JSONObject.toJSONString(request.getParameters());
				logger.error(message);
				Throwable logEx=null;
				if(e instanceof ApplicationControllerException && e.getCause()!=null){
					logEx=e.getCause();
				}else{
					logEx=e;
				}
				logger.error(logEx.getMessage(),logEx);
			}
			throw e;
		}
	}

	



	
	@Override
	protected void init() throws Exception {
		super.init();
		if(consumeListenerBeanName==null){
			throw new FatalBeanException("consumeListenerBeanName required.");
		}
		if(!this.getApplicationContext().getAutowireCapableBeanFactory().containsBean(consumeListenerBeanName)){
			throw new FatalBeanException("Bean:"+consumeListenerBeanName+" not defined.");
		}
	}


	


	protected MethodESA findAnnotaion(String beanName)
			throws BeansException {
		Object bean=this.getApplicationContext().getBean(beanName);
		Class<?> targetClazz=AopUtils.getTargetClass(bean);
		Method[] methods=targetClazz.getDeclaredMethods();
		for(int i=0;i<methods.length;i++){
			Method method=methods[i];
			WequeueConsumer annotation=method.getAnnotation(WequeueConsumer.class);
			if(annotation!=null){
				MethodESA aa=new MethodESAFactory(beanName,beanName,method,targetClazz,beanMapUtils).getObject();
				if(logger.isInfoEnabled()){
					logger.info("Bean<"+aa.getBeanName()+"> method<"+aa.getBeanMethod().getName()+"> listenered.");
				}
				return aa;
			}
		}
		throw new FatalBeanException("Not found method annotation in bean<"+consumeListenerBeanName+"> class="+targetClazz.getName());
	}


	


	public String getConsumeListenerBeanName() {
		return consumeListenerBeanName;
	}


	public void setConsumeListenerBeanName(String consumeListenerBeanName) {
		this.consumeListenerBeanName = consumeListenerBeanName;
	}


	protected void doListener(WequeueConsumeMsg msg){
		try{
			MDCUtil.set(msg.getRid()+"",msg.getPublisherName());
			if(logger.isInfoEnabled()){
				logger.info("Listener  notice msg="+msg);
			}
			ServiceResponse response=this.handleRequest(toServicesRequest(msg));
			this.sendReceiptMsg(msg.getQueueName(), msg.getRid(),response);
			//--------------------------------
		}catch(Throwable ex){
			logger.error("Proccess msg error:"+msg+", cause :"+ex.getMessage(),ex);
			this.sendReceiptMsg(msg.getQueueName(), msg.getRid(),ex);
		}finally{
			MDCUtil.clear();
		}
	}
	
	protected void forMDC(ServiceRequest request){
		SessionDTO s=request.getSessionDTO();
		if(s!=null && s.getTxnId()!=null){
			
		}else{
			MDCData data=MDCUtil.peek();
			if(data.getRequestId()!=null){
				data.set(MDCData.KEY_REQUEST_ID,MDCUtil.generateRequestId());
			}
		}
	}
	@SuppressWarnings("rawtypes")
	protected ServiceRequest toServicesRequest(WequeueConsumeMsg noticeMsg){
		Map params=noticeMsg.getBody();
		ServiceRequest req=new ServiceRequest(noticeMsg.getQueueName(),params);
		//req.setRequestedServiceID(noticeMsg.getQueueName());
		//
		req.setParameter(Wequeue.PN_RID, noticeMsg.getRid());
		req.setParameter(Wequeue.PN_PUBLISHER_NAME, noticeMsg.getPublisherName());
		req.setParameter(Wequeue.PN_NAME, noticeMsg.getQueueName());
		req.setParameter(Wequeue.PN_PUBLISHER_IP, noticeMsg.getPublisherIp());
		req.setParameter(Wequeue.PN_RETRY_FLAG, noticeMsg.isRetryFlag());
		//---------------------
		Long date=noticeMsg.getClientPushDate();
		if(date!=null){
			req.setParameter(Wequeue.PN_PUSH_DATE, new Date(date));
		}
		date=noticeMsg.getNoticeDate();
		if(date!=null){
			req.setParameter(Wequeue.PN_NOTICE_DATE, new Date(date));
		}
		return req;
	}

}
