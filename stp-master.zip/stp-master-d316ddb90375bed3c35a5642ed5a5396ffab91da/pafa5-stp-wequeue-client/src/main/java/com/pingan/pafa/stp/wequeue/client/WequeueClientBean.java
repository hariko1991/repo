package com.pingan.pafa.stp.wequeue.client;

import java.util.HashMap;
import java.util.Map;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.FatalBeanException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.ui.ModelMap;

import com.paic.pafa.appclient.IServiceClient;
import com.paic.pafa.appclient.ServiceParams;
import com.paic.pafa.appclient.annotation.ActionClient;
import com.pingan.pafa.common.utils.PNetUtils;
import com.pingan.pafa.stp.wequeue.common.Wequeue;
import com.pingan.pafa.stp.wequeue.common.WequeueException;
import com.pingan.pafa.stp.wequeue.common.msg.WequeuePushResultMsg;

public class WequeueClientBean implements WequeueClient,InitializingBean{

	private Log logger=LogFactory.getLog(this.getClass());

	@ActionClient(name="stp_wequeue.push")
	private IServiceClient triggerClient;
	
	private String clientName;
	
	private String queueName;

	
	@Override
	public WequeuePushResultMsg push(ModelMap msgBody) {
		Map<Object, Object> body=new HashMap<Object,Object>();
		body.putAll(msgBody);
		return this.push(body);
	}


	@Override
	public WequeuePushResultMsg push(
			Map<Object, Object> msgBody) {
		ServiceParams sp=ServiceParams.newInstance()
				.set(Wequeue.PN_NAME, this.getQueueName())
				.set(Wequeue.PN_PUBLISHER_NAME, this.getClientName())
				.set(Wequeue.PN_PUBLISHER_IP, PNetUtils.getLocalHost())
				.set(Wequeue.PN_PUSH_DATE, System.currentTimeMillis());
		if(logger.isInfoEnabled()){
			logger.info("Push queue="+sp.getMap());
		}
		if(msgBody==null){
			throw new WequeueException("msgBody is null");
		}
		//-------
		if(logger.isDebugEnabled()){
			logger.debug("Msg body="+msgBody);
		}
		sp.put(Wequeue.PN_BODY, msgBody);
		return this.getTriggerClient().invoke(sp,WequeuePushResultMsg.class);
	}


	@Override
	public final void afterPropertiesSet() throws Exception {
		if(clientName==null){
			throw new FatalBeanException("clientName required.");
		}
		if(queueName==null){
			throw new FatalBeanException("queueName required.");
		}
	}
	
	


	public String getClientName() {
		return clientName;
	}





	public void setClientName(String clientName) {
		this.clientName = clientName;
	}





	public IServiceClient getTriggerClient() {
		return triggerClient;
	}


	public void setTriggerClient(IServiceClient triggerClient) {
		this.triggerClient = triggerClient;
	}





	public String getQueueName() {
		return queueName;
	}





	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	
}
