package com.pingan.pafa.stp.wequeue.common;

public class WequeueException  extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	public WequeueException(String msg){
		super(msg);
	}

	public WequeueException(String msg,Throwable th){
		super(msg,th);
	}

}
