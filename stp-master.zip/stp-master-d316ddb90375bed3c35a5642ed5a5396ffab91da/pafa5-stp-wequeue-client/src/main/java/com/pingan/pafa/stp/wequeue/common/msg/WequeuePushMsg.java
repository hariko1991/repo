package com.pingan.pafa.stp.wequeue.common.msg;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;


public class WequeuePushMsg implements java.io.Serializable{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private String queueName;
	
	private String publisherName;
	
	private String publisherIp;
	
	private Long clientPushDate;
	
	private Long rid;
	
	
	
	private Map<?,?> body;
	
	
	@Override
	public String toString() {
		DateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		return "{queueName="+this.queueName+",publisherName="+publisherName+",publisherIp="+publisherIp
				+",clientPushDate="+(clientPushDate==null?"null":format.format(new Date(clientPushDate)))
				+",rid="+rid
				+"}";
				
	}

	

	public Long getRid() {
		return rid;
	}

	public void setRid(Long rid) {
		this.rid = rid;
	}



	public String getQueueName() {
		return queueName;
	}



	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}


	


	public String getPublisherName() {
		return publisherName;
	}



	public void setPublisherName(String publisherName) {
		this.publisherName = publisherName;
	}



	public String getPublisherIp() {
		return publisherIp;
	}



	public void setPublisherIp(String publisherIp) {
		this.publisherIp = publisherIp;
	}



	public Long getClientPushDate() {
		return clientPushDate;
	}



	public void setClientPushDate(Long clientPushDate) {
		this.clientPushDate = clientPushDate;
	}



	public Map<?, ?> getBody() {
		return body;
	}



	public void setBody(Map<?, ?> body) {
		this.body = body;
	}

	
	
}
