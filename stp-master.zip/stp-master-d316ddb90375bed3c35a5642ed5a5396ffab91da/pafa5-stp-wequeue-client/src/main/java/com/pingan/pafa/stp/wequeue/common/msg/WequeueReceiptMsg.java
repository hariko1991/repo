package com.pingan.pafa.stp.wequeue.common.msg;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class WequeueReceiptMsg implements java.io.Serializable{
	
	public static final Integer RESULT_OK=0;
	
	public static final Integer RESULT_EXCEPTION=1;

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private Long rid;
	
	private String queueName;
	
	private Long clientReceiptDate;
	
	private String responseCode;
	
	private String responseMsg;
	
	private String receiptClientIp;
	
	private String consumerName;
	

	@Override
	public String toString() {
		DateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		return "{queueName="+this.queueName+",consumerName="+consumerName+",receiptClientIp="+receiptClientIp+",rid="+rid
				+",clientReceiptDate="+(clientReceiptDate==null?"null":format.format(new Date(clientReceiptDate)))
				+",responseCode="+responseCode
				+"}";
				
	}

	public Long getRid() {
		return rid;
	}


	public void setRid(Long rid) {
		this.rid = rid;
	}


	

	

	public String getConsumerName() {
		return consumerName;
	}

	public void setConsumerName(String consumerName) {
		this.consumerName = consumerName;
	}

	public String getResponseCode() {
		return responseCode;
	}


	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}


	
	public String getQueueName() {
		return queueName;
	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}

	public Long getClientReceiptDate() {
		return clientReceiptDate;
	}

	public void setClientReceiptDate(Long clientReceiptDate) {
		this.clientReceiptDate = clientReceiptDate;
	}

	public String getReceiptClientIp() {
		return receiptClientIp;
	}

	public void setReceiptClientIp(String receiptClientIp) {
		this.receiptClientIp = receiptClientIp;
	}

	public String getResponseMsg() {
		return responseMsg;
	}


	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}





	
	
	
}

