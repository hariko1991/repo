package com.pingan.pafa.stp.wequeue.common;

public interface Wequeue {
	
	public static final String PN_RID="wequeueRid";
	
	public static final String PN_BODY="wequeueBody";
	
	public static final String PN_NAME="wequeueName";
	
	public static final String PN_PUBLISHER_NAME="wequeuePublisherName";

	public static final String PN_PUBLISHER_IP="wequeuePublisherIp";
	
	
	public static final String PN_RETRY_FLAG="wequeueRetryFlag";
	
	public static final String PN_PUSH_DATE="wequeuePushDate";
	
	public static final String PN_NOTICE_DATE="wequeueNoticeDate";
	
	public static final String  QUEUE_ID_DEF_RECEIPT="Wequeue_Receipt_Queue";
	
	
	//public static final String  QUEUE_ID_SUFFIX="Wequeue.";
	

}
