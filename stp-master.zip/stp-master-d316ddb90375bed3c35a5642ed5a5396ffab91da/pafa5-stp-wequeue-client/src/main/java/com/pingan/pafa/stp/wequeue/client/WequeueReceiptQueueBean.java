package com.pingan.pafa.stp.wequeue.client;

import java.util.Map;

import com.paic.pafa.app.dto.ServiceResponse;
import com.pingan.pafa.common.utils.PNetUtils;
import com.pingan.pafa.papp.exception.ResponseCodeException;
import com.pingan.pafa.redis.queue.RedisQueue;
import com.pingan.pafa.stp.wequeue.common.Wequeue;
import com.pingan.pafa.stp.wequeue.common.msg.WequeueReceiptMsg;

public abstract class WequeueReceiptQueueBean extends AbstractWequeueConsumeListener {

	private RedisQueue<WequeueReceiptMsg> consumeReceiptQueue;
	
	private String  consumeReceiptQueueId;
	
	
	protected WequeueReceiptMsg newReceiptMsg(String queueName,Long rid,String responseCode,String responseMsg){
		WequeueReceiptMsg msg=new WequeueReceiptMsg();
		msg.setRid(rid);
		msg.setConsumerName(this.getClientName());
		msg.setClientReceiptDate(System.currentTimeMillis());
		msg.setResponseCode(responseCode);
		msg.setResponseMsg(responseMsg);
		msg.setQueueName(queueName);
		msg.setReceiptClientIp(PNetUtils.getLocalHost());
		return msg;
	}
	
	protected void sendReceiptMsg(String queueName,Long rid){
		WequeueReceiptMsg msg=newReceiptMsg(queueName,rid,null,null);
		sendReceiptMsg(msg);
	}
	
	protected void sendReceiptMsg(String queueName,Long rid,Throwable th){
		WequeueReceiptMsg msg=null;
		if(th instanceof ResponseCodeException){
			ResponseCodeException ex=(ResponseCodeException)th;
			msg=newReceiptMsg(queueName,rid,ex.getResponseCode(),ex.getResponseMsg());
		}else{
			msg=newReceiptMsg(queueName,rid,ResponseCodeException.ERROR_UNKNOW,th.getLocalizedMessage());
		}
		sendReceiptMsg(msg);
	}
	
	@SuppressWarnings("rawtypes")
	protected void sendReceiptMsg(String queueName,Long rid,ServiceResponse response){
		String responseCode=null;
		String responseMsg=null;
		if(response!=null && response.getModel()!=null ){
		
			Map model=response.getModel();
			responseCode=(String)model.get("responseCode");
			responseMsg=(String)model.get("responseMsg");
		}
		WequeueReceiptMsg msg=newReceiptMsg(queueName,rid,responseCode,responseMsg);
		sendReceiptMsg(msg);
	}
	
	protected void sendReceiptMsg(WequeueReceiptMsg msg){
		try{
			if(logger.isInfoEnabled()){
				logger.info("Push receipt msg  to queue<"+msg.getQueueName()+">,rid="+msg.getRid());
			}
			consumeReceiptQueue.push(msg);
		}catch(Throwable th){
			logger.warn("Push to receiptQueue error:"+th.getMessage(),th);
		}
	}

	@Override
	protected void init() throws Exception {
		super.init();
		
		if(consumeReceiptQueue==null){
			if(consumeReceiptQueueId==null){
				consumeReceiptQueueId=Wequeue.QUEUE_ID_DEF_RECEIPT;
			}
			consumeReceiptQueue=getRedis().loadQueue(consumeReceiptQueueId, WequeueReceiptMsg.class);
		}
		if(logger.isInfoEnabled()){
			logger.info("consumeReceiptQueue="+consumeReceiptQueue);
		}
	}

	public RedisQueue<WequeueReceiptMsg> getConsumeReceiptQueue() {
		return consumeReceiptQueue;
	}

	public void setConsumeReceiptQueue(
			RedisQueue<WequeueReceiptMsg> consumeReceiptQueue) {
		this.consumeReceiptQueue = consumeReceiptQueue;
	}

	public String getConsumeReceiptQueueId() {
		return consumeReceiptQueueId;
	}

	public void setConsumeReceiptQueueId(String consumeReceiptQueueId) {
		this.consumeReceiptQueueId = consumeReceiptQueueId;
	}

	
	
	
	
	
}
