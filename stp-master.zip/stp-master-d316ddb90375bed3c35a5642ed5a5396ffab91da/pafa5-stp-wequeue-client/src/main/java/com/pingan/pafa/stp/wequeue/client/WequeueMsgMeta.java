package com.pingan.pafa.stp.wequeue.client;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

public class WequeueMsgMeta {

	//消息ID
	private Long wequeueRid;
	
	//队列名
	private String wequeueName;
	
	//消息推送者
	private String wequeuePublisherName;
	
	//消息推送者IP
	private String wequeuePublisherIp;
	
	//是否是重试(补偿)
	private boolean wequeueRetryFlag;
	
	//消息推送时间
	private Date wequeuePushDate;
	
	//消息进入队列时间
	private Date wequeueNoticeDate;
	
	@Override
	public String toString() {
		DateFormat format=new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
		return "{queueName="+this.wequeueName+",publisherName="+wequeuePublisherName+",publisherIp="+wequeuePublisherIp+",rid="+wequeueRid
				+",pushDate="+(wequeuePushDate==null?"null":format.format(wequeuePushDate))
				+",noticeDate="+(wequeueNoticeDate==null?"null":format.format(wequeueNoticeDate))
				+",retryFlag="+wequeueRetryFlag
				+"}";
				
	}

	public Long getWequeueRid() {
		return wequeueRid;
	}

	public void setWequeueRid(Long wequeueRid) {
		this.wequeueRid = wequeueRid;
	}

	public String getWequeueName() {
		return wequeueName;
	}

	public void setWequeueName(String wequeueName) {
		this.wequeueName = wequeueName;
	}

	public String getWequeuePublisherName() {
		return wequeuePublisherName;
	}

	public void setWequeuePublisherName(String wequeuePublisherName) {
		this.wequeuePublisherName = wequeuePublisherName;
	}

	public String getWequeuePublisherIp() {
		return wequeuePublisherIp;
	}

	public void setWequeuePublisherIp(String wequeuePublisherIp) {
		this.wequeuePublisherIp = wequeuePublisherIp;
	}

	public boolean isWequeueRetryFlag() {
		return wequeueRetryFlag;
	}

	public void setWequeueRetryFlag(boolean wequeueRetryFlag) {
		this.wequeueRetryFlag = wequeueRetryFlag;
	}

	public Date getWequeuePushDate() {
		return wequeuePushDate;
	}

	public void setWequeuePushDate(Date wequeuePushDate) {
		this.wequeuePushDate = wequeuePushDate;
	}

	public Date getWequeueNoticeDate() {
		return wequeueNoticeDate;
	}

	public void setWequeueNoticeDate(Date wequeueNoticeDate) {
		this.wequeueNoticeDate = wequeueNoticeDate;
	}
	

	
	
}
