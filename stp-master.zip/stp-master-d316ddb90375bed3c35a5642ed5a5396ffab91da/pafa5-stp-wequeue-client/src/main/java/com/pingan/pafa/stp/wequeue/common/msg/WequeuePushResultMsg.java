package com.pingan.pafa.stp.wequeue.common.msg;



public class WequeuePushResultMsg implements java.io.Serializable{

	/***/
	private static final long serialVersionUID = 1L;

	//成功
	public static final String  CODE_SUCCESS="0";
	
	//队列不存在
	public static final String  CODE_QUEUE_NOT_FOUND="22001";
	
	//DB存储错误
	public static final String  CODE_DB_ERROR="22003";
	
	//队列已停止服务
	public static final String  CODE_QUEUE_STOPED="22004";
	
	//推送结果代号
	private String responseCode;
	
	//推送结果msg
	private String responseMsg;
	
	//消息ID
	private Long wequeueRid;
	
	public WequeuePushResultMsg(){
		
	}
	
	public WequeuePushResultMsg(String responseCode,String responseMsg){
		this.responseCode=responseCode;
		this.responseMsg=responseMsg;
	}
	

	@Override
	public String toString() {
		return "{responseCode="+this.responseCode+",responseMsg="+responseMsg+",rid="+wequeueRid
				+"}";
				
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMsg() {
		return responseMsg;
	}

	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}

	public Long getWequeueRid() {
		return wequeueRid;
	}

	public void setWequeueRid(Long wequeueRid) {
		this.wequeueRid = wequeueRid;
	}


	

	
	
	
}
