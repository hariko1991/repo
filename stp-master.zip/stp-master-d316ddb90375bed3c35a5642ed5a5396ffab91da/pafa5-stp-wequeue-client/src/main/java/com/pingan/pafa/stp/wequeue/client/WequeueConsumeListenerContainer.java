package com.pingan.pafa.stp.wequeue.client;

import com.pingan.pafa.redis.Redis;
import com.pingan.pafa.redis.queue.ConsumeListenerContainer;
import com.pingan.pafa.stp.wequeue.common.msg.WequeueConsumeMsg;

public class WequeueConsumeListenerContainer extends ConsumeListenerContainer<WequeueConsumeMsg>{
	
	private Redis redis;
	
	private String queueName;
	


	@Override
	public void afterPropertiesSet() throws Exception {
		this.setRedisQueue(this.getRedis().loadQueue(this.getQueueName(), WequeueConsumeMsg.class));
		super.afterPropertiesSet();
		
	}

	public Redis getRedis() {
		return redis;
	}

	public void setRedis(Redis redis) {
		this.redis = redis;
	}

	public String getQueueName() {
		return queueName;
	}

	public void setQueueName(String queueName) {
		this.queueName = queueName;
	}
	
	
}
