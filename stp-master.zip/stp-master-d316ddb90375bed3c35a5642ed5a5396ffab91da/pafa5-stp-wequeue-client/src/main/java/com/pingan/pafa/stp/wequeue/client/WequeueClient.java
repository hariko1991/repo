package com.pingan.pafa.stp.wequeue.client;

import java.util.Map;

import org.springframework.ui.ModelMap;

import com.pingan.pafa.stp.wequeue.common.msg.WequeuePushResultMsg;

public interface WequeueClient {

	/***
	 * 消息推送
	 * @param msgBody 消息体
	 * @return 消息推送结果
	 */
	WequeuePushResultMsg push(Map<Object,Object> msgBody);
	
	WequeuePushResultMsg push(ModelMap msgBody);
	
}
