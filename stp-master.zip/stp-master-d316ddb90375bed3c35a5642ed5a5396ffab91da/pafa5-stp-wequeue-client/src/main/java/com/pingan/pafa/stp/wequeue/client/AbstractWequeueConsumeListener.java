package com.pingan.pafa.stp.wequeue.client;



import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.FatalBeanException;
import org.springframework.beans.factory.BeanNameAware;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.support.ApplicationObjectSupport;

import com.pingan.pafa.redis.Redis;
import com.pingan.pafa.redis.queue.ConsumeListener;
import com.pingan.pafa.stp.wequeue.common.msg.WequeueConsumeMsg;



public abstract class AbstractWequeueConsumeListener extends ApplicationObjectSupport
		implements ConsumeListener<WequeueConsumeMsg>,InitializingBean,DisposableBean,BeanNameAware{

	protected Log logger=LogFactory.getLog(this.getClass());

	private String clientName;
	
	
	private Redis  redis;
	
	
	public void setClientName(String clientName) {
		this.clientName = clientName;
	}

	@Override
	public final void onReceiveMessages(WequeueConsumeMsg msg) {
		doListener(msg);
	}

	protected abstract void doListener(WequeueConsumeMsg msg);
	

	protected String getClientName(){
		return clientName;
	}
	
	
	
	

	@Override
	public final void destroy() throws Exception {
		onDestory();
	}

	
	@Override
	public final void afterPropertiesSet() throws Exception {
		if(clientName==null){
			throw new FatalBeanException("clientName required.");
		}
		if(redis==null){
			throw new FatalBeanException("redis required.");
		}
	
		init();
		if(logger.isInfoEnabled()){
			logger.info("clientName="+clientName);
			logger.info("redis="+redis);
		}
		//String queueFullName=Wequeue.QUEUE_ID_SUFFIX+queueName;
		//this.setRedisQueue(this.getRedis().loadQueue(queueFullName, WequeueConsumeMsg.class));
		
	}
	
	protected void onDestory() throws Exception{}


	protected void init() throws Exception{}




	public Redis getRedis() {
		return redis;
	}



	public void setRedis(Redis redis) {
		this.redis = redis;
	}
	
	protected String beanName;

	@Override
	public void setBeanName(String beanName) {
		this.beanName=beanName;
	}

	

	
}
