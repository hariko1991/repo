package com.pingan.pafa.front.proxy.testing;


public class HelloForm {

	private String name;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
}
