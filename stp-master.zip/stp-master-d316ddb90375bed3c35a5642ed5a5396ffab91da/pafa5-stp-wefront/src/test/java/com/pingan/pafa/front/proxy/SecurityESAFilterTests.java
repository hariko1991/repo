package com.pingan.pafa.front.proxy;

import java.util.Map;
import java.util.Random;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mock.web.MockHttpServletRequest;

import com.alibaba.druid.support.json.JSONUtils;
import com.paic.pafa.appclient.ServiceParams;
import com.pingan.pafa.front.proxy.util.RSAUtils;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;


@SARContextConfiguration(sarList="stp-front-esb-test")
public class SecurityESAFilterTests extends BaseSARTest{
	
	private static String token;
	
	private static String channel = "1001";
	
	@Value("${channel.security.privateKey}")
	private String privateKey;

	@Test
	public void apply_access_token() throws Exception{
		
		int random=9;
		long times=System.currentTimeMillis();
		
		String data = channel + ";" + random + ";" +times;
		logger.info("签名前：" + data);
		String sign = RSAUtils.sign(data.getBytes("UTF-8"), privateKey);
		System.out.println(sign);
		
		ServiceParams param = ServiceParams.newInstance();
		param.put("channel", channel);
		param.put("random", random+"");
		param.put("timestamp", times+"");
		param.put("sign", sign);
		MockHttpServletRequest request=this.createMockRequest("openapi/stp-front-esb.applyAccessToken");
		this.forJSONParams(request, this.toJson(param));
		
		String result = this.handleWebRequest(request ,this.createMockResponse());
		logger.info("result="+result);
		Map<String,String> resultMap = (Map<String, String>) JSONUtils.parse(result);
		if("0".equals(resultMap.get("responseCode"))){
			token = resultMap.get("accessToken");
			logger.info("token：="+token);
		}
	}
	
	@Test
	public void test_consume_access_token() throws Exception{
		String param="name=nangua&accessToken="+"xdfdasfdsfd"+"&channel="+channel;
		logger.info("param="+param);
		MockHttpServletRequest request=this.createMockRequest("api/stp-front-esb-test.hello",param);
		String result = this.handleWebRequest(request ,this.createMockResponse());
		logger.info("result="+result);
	}

}
