package com.pingan.pafa.front.proxy.testing;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;

import com.alibaba.fastjson.JSON;
import com.paic.pafa.web.BaseController;
import com.pingan.pafa.papp.ESA;

@Controller
public class SampleController extends BaseController {

	@ESA("stp-front-esb-test.hello")
	public ModelMap hello(HelloForm form){
		logger.info("form="+JSON.toJSONString(form));
		ModelMap model=new ModelMap();
		model.put("msg", "Hello,"+form.getName());
		model.put("responseCode", "0");
		return model;
	}
	
	
}
