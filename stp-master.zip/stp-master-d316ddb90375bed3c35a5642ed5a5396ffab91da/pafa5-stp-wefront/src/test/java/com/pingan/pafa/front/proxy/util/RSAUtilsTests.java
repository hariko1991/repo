package com.pingan.pafa.front.proxy.util;

import java.util.Map;

import com.pingan.pafa.front.proxy.util.RSAUtils;

public class RSAUtilsTests {

	public static void main(String args[]) throws Exception{
		Map<String,Object> map = RSAUtils.genKeyPair();
		System.out.println("publicKey："+RSAUtils.getPublicKey(map));
		System.out.println("privateKey："+RSAUtils.getPrivateKey(map));
	}
}
