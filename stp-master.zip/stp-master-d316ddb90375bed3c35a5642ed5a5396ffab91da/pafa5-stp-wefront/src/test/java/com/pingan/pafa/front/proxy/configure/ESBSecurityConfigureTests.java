package com.pingan.pafa.front.proxy.configure;

import org.junit.Test;
import org.springframework.beans.factory.annotation.Autowired;

import com.pingan.pafa.front.proxy.configure.ESBSecurityConfigure;
import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList="stp-front-esb-test")
public class ESBSecurityConfigureTests extends BaseSARTest{

	@Autowired
	private ESBSecurityConfigure $;
	
	@Test
	public void test(){
		
	}
}
