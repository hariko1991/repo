package com.pingan.pafa.front.proxy.util;

import java.util.Date;
import java.util.Map;

import com.pingan.pafa.front.proxy.util.RSAUtils;

/**
 * @author 作者 陈强 <br>
 * @version 创建时间：2015年5月22日 下午5:19:17 <br>
 *          <h1>类说明</h1>
 */
public class Test {
	public static void main(String[] args) throws Exception {
		String s = "123123";
		//Map<String, Object> keyMap = RSAUtils.genKeyPair();
		//String publicKey = RSAUtils.getPublicKey(keyMap);
		//String privateKey = RSAUtils.getPrivateKey(keyMap);
		//System.out.println("publicKey=" + publicKey);
		//System.out.println("privateKey=" + privateKey);

		/*
		 * byte[] jiami = RSAUtils.encryptByPrivateKey(s.getBytes("UTF-8"),
		 * privateKey); String plainTxt =new
		 * String(RSAUtils.decryptByPublicKey(jiami, publicKey));
		 * System.out.println(plainTxt);
		 * 
		 * byte[] encryptTextByPublicKey =
		 * RSAUtils.encryptByPublicKey(s.getBytes(), publicKey); String
		 * plainTxts =new
		 * String(RSAUtils.decryptByPrivateKey(encryptTextByPublicKey,
		 * privateKey)); System.out.println(plainTxts);
		 */
		/**
		 * 渠道id
		 */
		String chanelId = "1001";
		/**
		 * 6位随机数
		 */
		int random = nextInt();
		/**
		 * 时间戳
		 */
		long times = new Date().getTime();
		//System.out.println(times);
		//random = 123421;
		//times = 1434680312495L;
		String data = chanelId + ";" + random + ";" +times;
		//data = "paf_00000;166112;1432534647137";
		System.out.println("channel:" + chanelId);
		System.out.println("random:" + random);
		System.out.println("timestamp:" + times);
		//System.out.println("签名前：" + data);
		String privateKey = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCjH4+Eu6OTLvkmD9fj6CePxSF4yMCFhr/EeISw4z0fIsY1ip5+nG3PZQqRgqyRtflRorhVttpDn1ApdCFKMqXnlwjpPWY9xGxrZ365Io7yPcyYFMOi9WGnvSaFRxkVSvw8T2FoxLqfpReNJdjMHS9W5hQqmEUbo+qEqISj07YZXocAebuzEm6Eh+pwN46acnycIqNTkF3LLUBJ3hQlt5KwWTKlaHi6HO8uAhm5zWpusgIveA7lNqq2StuhVR0zSqSnGqvcTeUD6PuAescKmr7oDNz6z9oF3btDhFdFZPHG7mxyIUjb55OaVb7+S5rSfscDe578VlEQezTeQUEiMUIPAgMBAAECggEAbnkRWXM6dJN7aKuSKmcvY869vG848zUu6oA0XReIbW2/jsMyU8zdEXf8kE9PT99N2lu5O1N6vhFG2MwtP3LNqOpAvrU2aN5+Dr8os3kUFjqENPrbA6HrYQ5Y6Coecq015iJcdffF7BiCurTG/nVFejSXs8EsDGwWh4EZU1ouGT8zBta3oFwqFUFh8BREl9RW3Xfbkc67NS4cnIo9CWb/odfFPXKoP/C54Tr8HlX4KomjVBbDZFGmEagkP7x3k5oAbR+MZ5Q9NoAAonUZW+xmsagS55tH91ogUWgIhG6BP2z0BkIizDk/7U0T+kahk2RgvKvqZxT93XHCTVbmraEjAQKBgQDwJWXH3O3F+P9AZhTdQXpd7KCA1aqiWEiLgADFS3f5QMsIJZN1SzyWoLoL15VER5DklDTuU/NQBoKJ5S8dy4g2P36sf/66/kA9/dmgNuY+KNDsK6juQuKddK6UWwh9lRUUzGiVsv8elvtfyW7hoyGImPPFBSbHwU1dD3AM6MuC5QKBgQCt5G9S8Sk2YTNxdcwCfS+XStUMGlqs2FqLYhiXpRGWzP9zptLEBJqdG9Wir7okTeD9UdZHilAHnFIRRjQTPw1vp9cY+Y9eAlpZRiZAYlhjCtK1eLDj5vXP2jrw/IA6V/kpNY8ef09grCkVhS6DI+LxEyfVbSFLvaWhjJhs3INd4wKBgQCR/Ron6039GUcLPkOW0jRynuRgDgSilurbK2DMj/mKZHJJLJa9KpTVuTYA9vj+Pkd+Pf8Dl7OFxb9b1yDSiyXuXKFEerc/tEsXpJfFRzqnNSb1PAGBftXHBOUQuVqrBZOARleaEev4C68bZxhqQUKkiN9AucX+j6vZVAY5QthdZQKBgH54wyLO9UtwvIqLwzoYNHHT4kmwLTzDCm+PhBVe4AEOzcgej/Iy6wTTRrjRGA/peHale7SCexxd7C5WIe/RjwMjTkUC1OvpyC5f39g57tDyATgtNHI8+5EVxoKZEuXcMAJxysrCi0fjTuow+Bg3FIqDhRgsC+hbYUiyyfV7GCxDAoGAHik4PTWSKU/tAKtHw1o+AwzWDx3c4KAIcx/vW0I1iodwXtnRJfq0430FcagWot6+CMKWk2C8MuuFyhlJTcgzGTB+/RB3orRMfU14SlQMFzdu9xrV8KDkc4nMcl9jKauIcMqoy5Eil1LeEwO8tDvoqSzqOvx/SvpszYCgmV5cYNI=";
		String sign = RSAUtils.sign(data.getBytes("UTF-8"), privateKey);
		System.out.println("sign：" + sign);
		String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAox+PhLujky75Jg/X4+gnj8UheMjAhYa/xHiEsOM9HyLGNYqefpxtz2UKkYKskbX5UaK4VbbaQ59QKXQhSjKl55cI6T1mPcRsa2d+uSKO8j3MmBTDovVhp70mhUcZFUr8PE9haMS6n6UXjSXYzB0vVuYUKphFG6PqhKiEo9O2GV6HAHm7sxJuhIfqcDeOmnJ8nCKjU5Bdyy1ASd4UJbeSsFkypWh4uhzvLgIZuc1qbrICL3gO5TaqtkrboVUdM0qkpxqr3E3lA+j7gHrHCpq+6Azc+s/aBd27Q4RXRWTxxu5sciFI2+eTmlW+/kua0n7HA3ue/FZREHs03kFBIjFCDwIDAQAB";
		//System.out.println(RSAUtils.verify(data.getBytes("UTF-8"), publicKey, sign));
		
		//sign = "JySot3UKEfnuTCmRGfShL/d22GWUy4T3Bid/jg5mZL/obYhg+4OWVt2NIJ4cALLNuE9sksC1mJdP34AzvDaWIel8FC2hvCeEaQGX8Sb1UzkReYCXWeJoZCwy78h/wKT03uzRat7WO+eON8wJYj7//HrVitnyYqbIwCt6vC2HqxF/7poeAX/SbUKC8lktBoJ0Ldmk15gk0ORASmMdTfibxUpZ7hs0006r/QYaD2NMROe0+5pfR2X0hbX4kjEODWn9CTWidii1ZpMHtEOjcT2JkkevvRp5fVzl7pkaP3lnjO9D7hgdxhr7XQgxa6vcpbtnYHnv8lvW495jS7FuTQOgZw==";
		//sign = "JySot3UKEfnuTCmRGfShL/d22GWUy4T3Bid/jg5mZL/obYhg 4OWVt2NIJ4cALLNuE9sksC1mJdP34AzvDaWIel8FC2hvCeEaQGX8Sb1UzkReYCXWeJoZCwy78h/wKT03uzRat7WO eON8wJYj7//HrVitnyYqbIwCt6vC2HqxF/7poeAX/SbUKC8lktBoJ0Ldmk15gk0ORASmMdTfibxUpZ7hs0006r/QYaD2NMROe0 5pfR2X0hbX4kjEODWn9CTWidii1ZpMHtEOjcT2JkkevvRp5fVzl7pkaP3lnjO9D7hgdxhr7XQgxa6vcpbtnYHnv8lvW495jS7FuTQOgZw==";
	}

	public static int nextInt() {
		return (int)((Math.random()*9+1)*100000);
	}
}
