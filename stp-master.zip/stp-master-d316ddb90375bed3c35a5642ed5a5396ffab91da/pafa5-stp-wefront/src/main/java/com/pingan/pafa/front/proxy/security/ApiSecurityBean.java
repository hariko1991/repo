package com.pingan.pafa.front.proxy.security;


import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.paic.pafa.app.dto.ServiceRequest;
import com.pingan.pafa.front.proxy.SecurityResultCodes;
import com.pingan.pafa.front.proxy.configure.ChannelSecurityConfigure;
import com.pingan.pafa.front.proxy.configure.ESBSecurityConfigure;
import com.pingan.pafa.front.proxy.util.SHA1Utils;

public class ApiSecurityBean implements ESBSecurity{
	private Log logger = LogFactory.getLog(this.getClass());
	
	private ESBSecurityConfigure securityConfigure;
	
	private String sha1chars = "pafa5frontproxyforbank";
	
	@Override
	public AccessTokenApplyResult applyAccessToken(SignInfoForm info) {
		AccessTokenApplyResult applyResult = null;
		return applyResult;
	}

	@Override
	public AccessTokenApplyResult securityCheck(SecurityCheckForm checkForm,ServiceRequest request) {
		AccessTokenApplyResult applyResult = null;
		
		String channelId = checkForm.getChannel();
		//String accessToken = checkForm.getAccessToken();
		String esaName = checkForm.getEsaName();
		try {
			/*if(securityConfigure.isForbidden())
				return new AccessTokenApplyResult(SecurityResultCodes.CHANNEL_IS_CLOSE,"主账户正在发布重要版本，访问通道关闭");*/
			//获取不受限制的接口列表	
			if(securityConfigure.isWhitelist(esaName) ){
				return null;
			}
			
			//判断渠道ID参数是否有
			if(channelId==null||"".equals(channelId))
				return new AccessTokenApplyResult(SecurityResultCodes.CHANNEL_NOT_EXISTS,"参数:渠道号(channel)不能为空");
			//查询每个专业公司的安全配置情况
			ChannelSecurityConfigure configure = securityConfigure.getChannelConfigure(channelId);
			
			//渠道id权限，即每个专业公司的id
			if(configure==null)
				return new AccessTokenApplyResult(SecurityResultCodes.CHANNEL_NOT_EXISTS,"渠道号不存在");
			
			//判断是否开启ip限制
			if(configure.isLimitIpEnable()){
				if(!(configure.checkIp(checkForm.getClientIp()))){
					logger.warn("ClientIP="+checkForm.getClientIp()+" Limited by ipList="+configure.getLimitIps());
					return new AccessTokenApplyResult(SecurityResultCodes.CLENT_IP_NOT_AUTH,"客户端IP受限,IP限制列表="+configure.getLimitIps());
				}
			}
			
			boolean esaFlag = false;
			if(configure.isLimitEsaEnable())
			{
				//获取专业公司允许访问的接口列表
				Set<String> esas  = configure.getEsas();
				if(esas!=null && esas.contains(esaName)){
					esaFlag = true;
				}
			}
			else
			{
				esaFlag = true;
			}
			
			if(!esaFlag)
				return new AccessTokenApplyResult(SecurityResultCodes.ESA_NOT_AUTH,"接口:"+esaName+" 没有权限调用或不存在。");
			
			//令牌验证
			else{
				applyResult = tokenCheck(checkForm, configure);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			applyResult = new AccessTokenApplyResult(SecurityResultCodes.ACCESS_FAILE,"出现系统异常，原因："+e.getMessage());
		}
		return applyResult;
	}
	
	/**
	 * 用于令牌验证
	 * @param checkForm
	 * @param configure
	 * @return
	 */
	private AccessTokenApplyResult tokenCheck(SecurityCheckForm checkForm,ChannelSecurityConfigure configure){
		String tokenKey = configure.getTokenKey();
		String channelId = checkForm.getChannel();
		String accessToken = checkForm.getAccessToken();
		//判断token参数是否有
		if(accessToken==null||"".equals(accessToken))
			return new AccessTokenApplyResult(SecurityResultCodes.ACCESS_TOKEN_NOT_EXISTS,"accessToken令牌参数为空");
		
		String token = SHA1Utils.sign(accessToken + channelId + sha1chars);
		
		if(token != null)
		{
			if(!token.equals(tokenKey))
			{
				return new AccessTokenApplyResult(SecurityResultCodes.ACCESS_TOKEN_ERROR,"请求的令牌accessToken错误");
			}
		}
		return null;
	}
	
	/**
	 * 跨域验证
	 * @param esaName
	 * @param channelId
	 * @return
	 */
	@Override
	public AccessTokenApplyResult crossDomainCheck(String esaName,String channelId) {
		if(!securityConfigure.isCrossDomainEsaLists(esaName))
			return new AccessTokenApplyResult(SecurityResultCodes.REFUSE_CROSS_DOMAIN,"非法跨域访问，请确认ESA服务[" + esaName + "]是否开启跨域访问");
		return null;
	}
	
	
	public ESBSecurityConfigure getSecurityConfigure() {
		return securityConfigure;
	}

	public void setSecurityConfigure(ESBSecurityConfigure securityConfigure) {
		this.securityConfigure = securityConfigure;
	}

}
