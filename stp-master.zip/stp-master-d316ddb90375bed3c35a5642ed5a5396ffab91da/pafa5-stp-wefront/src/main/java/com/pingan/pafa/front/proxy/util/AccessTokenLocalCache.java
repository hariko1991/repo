package com.pingan.pafa.front.proxy.util;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import com.pingan.pafa.front.proxy.dto.AccessTokenCacheDTO;

/** 
 * @author 作者 陈强 <br>
 * @version 创建时间：2015年5月25日 下午2:58:30 <br>
 * <h1>类说明</h1>
 */
public class AccessTokenLocalCache {
	
	/**
	 * 本地token缓存
	 */
	private static Map<String,AccessTokenCacheDTO> accessTokenMapCache = new HashMap<String, AccessTokenCacheDTO>();

	/**
	 * 获取本地缓存
	 * @param key 获取的key
	 * @param expirestime 设置的过期时间，秒
	 * @return
	 */
	public static AccessTokenCacheDTO getAccessTokenMapCache(String key,long expirestime) {
		AccessTokenCacheDTO cache = accessTokenMapCache.get(key);
		if(cache!=null){
			long t = new Date().getTime();
			if(t - cache.getOperationTime() > expirestime*1000){
				cache = null;
				accessTokenMapCache.remove(key);
			}
		}
		return cache;
	}

	/**
	 * 设置本地缓存
	 * @param key
	 * @param accessToken
	 */
	public static void setAccessTokenMapCache(String key,AccessTokenCacheDTO accessToken) {
		accessTokenMapCache.put(key, accessToken);
	}

	
}
