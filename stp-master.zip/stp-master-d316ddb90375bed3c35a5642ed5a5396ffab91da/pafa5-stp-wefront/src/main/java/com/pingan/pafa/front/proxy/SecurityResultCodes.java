package com.pingan.pafa.front.proxy;

public class SecurityResultCodes {
	/**
	 * 成功
	 */
	public static final String ACCESS_SUCCESS = "0";
	/**
	 * 安全签名错误
	 */
	public static final String SIGN_ERROR="650601";
	
	/**
	 * 令牌已过期
	 */
	public static final String ACCESS_TOKEN_EXPIRED="650602";
	
	/**
	 * 渠道id不存在
	 */
	public static final String CHANNEL_NOT_EXISTS="650603";
	
	/**
	 * 客户端IP受限
	 */
	public static final String CLENT_IP_NOT_AUTH = "650604";
	
	/**
	 * 接口未授权，访问受限
	 */
	public static final String ESA_NOT_AUTH="650605";
	
	/**
	 * 时间戳/随机数/签名不存在
	 */
	public static final String TIMESTAMP_RANDOM_SIGN_NOT_EXISTS = "650606";
	
	/**
	 * 申请/验证token，出现异常
	 */
	public static final String ACCESS_FAILE = "650607";
	
	/**
	 * 请求的令牌错误
	 */
	public static final String ACCESS_TOKEN_ERROR="650608";
	
	/**
	 * 访问令牌为空
	 */
	public static final String ACCESS_TOKEN_NOT_EXISTS="650609";
	
	/**
	 * 时间戳错误，
	 */
	public static final String TIMES_TAMP_ERROR="650610";
	
	/**
	 * 全部通道关闭，发布版本
	 */
	public static final String CHANNEL_IS_CLOSE="650611";
	
	/**
	 * 非法跨域访问
	 */
	public static final String REFUSE_CROSS_DOMAIN="650612";
	
	/**
	 * 不合法的请求
	 */
	public static final String ILLEGAL_REQUEST="659999";
}
