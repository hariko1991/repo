package com.pingan.pafa.front.proxy.security;

public class SecurityCheckForm {

	/***
	 * 渠道ID
	 */
	private String channel;

	/**
	 * 访问令牌
	 */
	private String accessToken;

	/***
	 * 客户端IP
	 */
	private String clientIp;

	/***
	 * 访问esa name
	 */
	private String esaName;

	

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getClientIp() {
		return clientIp;
	}

	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}

	public String getEsaName() {
		return esaName;
	}

	public void setEsaName(String esaName) {
		this.esaName = esaName;
	}


}
