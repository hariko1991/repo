package com.pingan.pafa.front.proxy.security;

import java.util.Set;
import java.util.UUID;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

import com.paic.pafa.app.dto.ServiceRequest;
import com.pingan.pafa.front.proxy.SecurityResultCodes;
import com.pingan.pafa.front.proxy.configure.ChannelSecurityConfigure;
import com.pingan.pafa.front.proxy.configure.ESBSecurityConfigure;
import com.pingan.pafa.front.proxy.dto.AccessTokenCacheDTO;
import com.pingan.pafa.front.proxy.util.AccessTokenLocalCache;
import com.pingan.pafa.front.proxy.util.RSAUtils;
import com.pingan.pafa.redis.cache.RedisCache;

public class OpenApiSecurityBean implements ESBSecurity{
	private Log logger = LogFactory.getLog(this.getClass());
	
	private ESBSecurityConfigure securityConfigure;
	
	private RedisCache<AccessTokenCacheDTO> accessTokenCache;
	
	private long expirestime;
	
	@Override
	public AccessTokenApplyResult applyAccessToken(SignInfoForm info) {
		AccessTokenApplyResult applyResult = null;
		String channelId = info.getChannel();
		String random = info.getRandom();
		String timestamp = info.getTimestamp();
		String sign = info.getSign();
		
		long sysTime = System.currentTimeMillis();
		try {
			/*if(securityConfigure.isForbidden())
				return new AccessTokenApplyResult(SecurityResultCodes.CHANNEL_IS_CLOSE,"主账户正在发布重要版本，访问通道关闭");*/
			
			if(timestamp==null||"".equals(timestamp)||random==null||"".equals(random)||sign==null||"".equals(sign))
				return new AccessTokenApplyResult(SecurityResultCodes.TIMESTAMP_RANDOM_SIGN_NOT_EXISTS,"参数时间戳(timestamp)、随机数(random)、签名串(sign)都不能为空。");
			if(Long.parseLong(timestamp) - sysTime > (5*60*1000) || sysTime - Long.parseLong(timestamp) > (5*60*1000))
				return new AccessTokenApplyResult(SecurityResultCodes.TIMES_TAMP_ERROR,"时间戳(timestamp)错误。");
			
			sign = sign.replaceAll(" ", "+");
			
			if(channelId==null||"".equals(channelId))
				return new AccessTokenApplyResult(SecurityResultCodes.CHANNEL_NOT_EXISTS,"参数渠道号(channel)不能为空。");
			
			ChannelSecurityConfigure configure = securityConfigure.getChannelConfigure(channelId);
			
			//渠道id权限，即每个专业公司的id
			if(configure==null)
				return new AccessTokenApplyResult(SecurityResultCodes.CHANNEL_NOT_EXISTS,"渠道："+channelId+"不存在。");
			
			//判断是否开启ip限制
			if(configure.isLimitIpEnable()){
				if(!(configure.checkIp(info.getClientIp()))){
					logger.warn("ClientIP="+info.getClientIp()+" Limited by ipList="+configure.getLimitIps());
					return new AccessTokenApplyResult(SecurityResultCodes.CLENT_IP_NOT_AUTH,"客户端IP受限,IP限制列表="+configure.getLimitIps());
				}
			}
			String signbefore = channelId+";"+random+";"+timestamp;
			//校验签名串
			String publicKey = configure.getPublicKey();
			if(RSAUtils.verify(signbefore.getBytes("UTF-8"), publicKey, sign)){
				//通过,签名通过，申请TOKEN，UUID
				String tokenvalue = UUID.randomUUID().toString().replaceAll("-", "").toUpperCase();
				//------------------------------------------------------------------------------
				long expirestime1 = (expirestime+15*60);//顺延15分钟
				String key = channelId+"_"+tokenvalue;
				//--------------------------------------------------------------
				AccessTokenCacheDTO accTokenCache = new AccessTokenCacheDTO(tokenvalue,channelId,timestamp,random,expirestime1);
				//设置redis缓存，token
				accessTokenCache.set(key, accTokenCache, (int)expirestime1);
				//设置本地缓存，token
				AccessTokenLocalCache.setAccessTokenMapCache(key, accTokenCache);
				
				applyResult = new AccessTokenApplyResult(SecurityResultCodes.ACCESS_SUCCESS,tokenvalue,expirestime1);
				applyResult.setResponseMsg("成功");
			}else{
				//不通过，签名错误
				return new AccessTokenApplyResult(SecurityResultCodes.SIGN_ERROR,"签名验证失败。");
			}
		} catch (Exception e) {
			logger.error(""+e.getMessage(),e);
			applyResult = new AccessTokenApplyResult(SecurityResultCodes.ACCESS_FAILE,"出现系统异常，原因："+e.getMessage());
		}
		return applyResult;
	}

	@Override
	public AccessTokenApplyResult securityCheck(SecurityCheckForm checkForm,ServiceRequest request) {
		AccessTokenApplyResult applyResult = null;
		
		String channelId = checkForm.getChannel();
		//String accessToken = checkForm.getAccessToken();
		String esaName = checkForm.getEsaName();
		try {
			/*if(securityConfigure.isForbidden())
				return new AccessTokenApplyResult(SecurityResultCodes.CHANNEL_IS_CLOSE,"主账户正在发布重要版本，访问通道关闭");*/
			//获取不受限制的接口列表	
			if(securityConfigure.isWhitelist(esaName) ){
				return null;
			}
			
			//判断渠道ID参数是否有
			if(channelId==null||"".equals(channelId))
				return new AccessTokenApplyResult(SecurityResultCodes.CHANNEL_NOT_EXISTS,"参数:渠道号(channel)不能为空");
			//查询每个专业公司的安全配置情况
			ChannelSecurityConfigure configure = securityConfigure.getChannelConfigure(channelId);
			
			//渠道id权限，即每个专业公司的id
			if(configure==null)
				return new AccessTokenApplyResult(SecurityResultCodes.CHANNEL_NOT_EXISTS,"渠道号不存在");
			
			//判断是否开启ip限制
			if(configure.isLimitIpEnable()){
				if(!(configure.checkIp(checkForm.getClientIp()))){
					logger.warn("ClientIP="+checkForm.getClientIp()+" Limited by ipList="+configure.getLimitIps());
					return new AccessTokenApplyResult(SecurityResultCodes.CLENT_IP_NOT_AUTH,"客户端IP受限,IP限制列表="+configure.getLimitIps());
				}
			}
			
			boolean esaFlag = false;
			//获取专业公司允许访问的接口列表
			Set<String> esas  = configure.getEsas();
			if(esas!=null && esas.contains(esaName)){
				esaFlag = true;
			}
			if(!esaFlag)
				return new AccessTokenApplyResult(SecurityResultCodes.ESA_NOT_AUTH,"接口:"+esaName+" 没有权限调用或不存在。");
			//签名验证
			if(configure.isSignEnable()){
				applyResult = signCheck(request, configure);
			}
			//令牌验证
			else{
				applyResult = tokenCheck(checkForm, configure);
			}
		} catch (Exception e) {
			logger.error(e.getMessage(),e);
			applyResult = new AccessTokenApplyResult(SecurityResultCodes.ACCESS_FAILE,"出现系统异常，原因："+e.getMessage());
		}
		return applyResult;
	}
	
	private AccessTokenApplyResult signCheck(ServiceRequest request,ChannelSecurityConfigure configure) throws Exception{
		return new AccessTokenApplyResult(SecurityResultCodes.SIGN_ERROR,"签名验证方式尚不支持。");
	}
	
	/**
	 * 用于令牌验证
	 * @param checkForm
	 * @param configure
	 * @return
	 */
	private AccessTokenApplyResult tokenCheck(SecurityCheckForm checkForm,ChannelSecurityConfigure configure){
		String channelId = checkForm.getChannel();
		String accessToken = checkForm.getAccessToken();
		//判断token参数是否有
		if(accessToken==null||"".equals(accessToken))
			return new AccessTokenApplyResult(SecurityResultCodes.ACCESS_TOKEN_NOT_EXISTS,"accessToken令牌参数为空");
		//优先获取本地token缓存
		String key = channelId+"_"+accessToken;
		AccessTokenCacheDTO access = AccessTokenLocalCache.getAccessTokenMapCache(key,expirestime);
		//首先获取本地token缓存，如果不存在，则去获取redis的缓存
		if(access==null)
			access = accessTokenCache.get(key); 
		//再次判断token是否为空，如果空则表示已过期
		if(access==null)
			return new AccessTokenApplyResult(SecurityResultCodes.ACCESS_TOKEN_EXPIRED, "accessToken令牌已过期，请重新申请");
		//判断参数中的token与缓存的token是否一致
		if(!accessToken.equals(access.getAccessToken()))
			return new AccessTokenApplyResult(SecurityResultCodes.ACCESS_TOKEN_ERROR, "无效令牌，请重新申请");
		return null;
	}
	
	/**
	 * 跨域验证
	 * @param esaName
	 * @param channelId
	 * @return
	 */
	public AccessTokenApplyResult crossDomainCheck(String esaName,String channelId) {
		if(!securityConfigure.isCrossDomainEsaLists(esaName))
			return new AccessTokenApplyResult(SecurityResultCodes.REFUSE_CROSS_DOMAIN,"非法跨域访问，请确认该ESA服务是否开启跨域访问");
		return null;
	}
	
	
	
	public ESBSecurityConfigure getSecurityConfigure() {
		return securityConfigure;
	}

	public void setSecurityConfigure(ESBSecurityConfigure securityConfigure) {
		this.securityConfigure = securityConfigure;
	}

	public RedisCache<AccessTokenCacheDTO> getAccessTokenCache() {
		return accessTokenCache;
	}

	public void setAccessTokenCache(RedisCache<AccessTokenCacheDTO> accessTokenCache) {
		this.accessTokenCache = accessTokenCache;
	}

	public long getExpirestime() {
		return expirestime;
	}

	public void setExpirestime(long expirestime) {
		this.expirestime = expirestime;
	}

	
}
