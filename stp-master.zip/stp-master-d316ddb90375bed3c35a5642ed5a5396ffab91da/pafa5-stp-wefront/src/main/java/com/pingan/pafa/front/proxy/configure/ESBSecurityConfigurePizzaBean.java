package com.pingan.pafa.front.proxy.configure;

import java.io.InputStream;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.FatalBeanException;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.io.Resource;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.pingan.pafa.front.proxy.util.Xml2JsonUtils;
import com.pingan.pafa.pizza.classloader.PizzaURL;
import com.pingan.pafa.pizza.spring.PizzaResource;
import com.pingan.pafa.pizza.spring.PizzaResourceListener;

public class ESBSecurityConfigurePizzaBean  implements ESBSecurityConfigure
	,PizzaResourceListener,InitializingBean {

	protected Log logger = LogFactory.getLog(this.getClass());

	
	private volatile Set<String> esaWhitelists;
	
	private volatile Set<String> crossDomainEsaLists;

	private volatile Map<String, ChannelSecurityConfigure> channnelsMap;
	
	private volatile Resource configResource;

	public Set<String> getEsaWhitelists() {
		return esaWhitelists;
	}

	public void setEsaWhitelists(Set<String> esaWhitelists) {
		this.esaWhitelists = esaWhitelists;
	}

	public Map<String, ChannelSecurityConfigure> getChannnelsMap() {
		return channnelsMap;
	}

	public void setChannnelsMap(Map<String, ChannelSecurityConfigure> channnelsMap) {
		this.channnelsMap = channnelsMap;
	}

	protected void parseConfig(InputStream xmlContent) {
		String json = new Xml2JsonUtils(xmlContent, "channelSecurity", "esa","ip").toJSONString();
		if (logger.isInfoEnabled()) {
			logger.info("ESB Security configure:\n" + json);
		}
		JSONObject configureJson = null;
		try {
			configureJson = JSONObject.parseObject(json);
		} catch (Exception ex) {
			throw new FatalBeanException("Parse json  error:\n" + json
					+ "\n cause:" + ex.getMessage(), ex);
		}
		//this.isForbidden = forIsForbidden(configureJson);
		
		Set<String> esaWhitelists = forESAWhitelists(configureJson);
		
		Set<String> crossDomainEsaLists = forCrossDomainEsalists(configureJson);
		// -------------------------------------
		this.channnelsMap = forChannelsConfigure(configureJson);
		this.esaWhitelists = esaWhitelists;
		this.crossDomainEsaLists = crossDomainEsaLists;
	}

	
	@Override
	public void afterPropertiesSet() throws Exception {
		if(configResource==null){
			throw new FatalBeanException("configResource requried.");
		}
		InputStream content=configResource.getInputStream();
		if(content!=null){
			if (logger.isInfoEnabled()) {
				logger.info("Parsing security config on startup.");
			}
			this.parseConfig(content);
		}
	}

	private Set<String> forESAWhitelists(JSONObject configureJson) {
		JSONObject json = configureJson.getJSONObject("esaWhitelists");
		List<String> list = (List<String>) (json == null ? null : json.get("esa"));
		Set<String> esaWhitelists = new HashSet<String>();
		if (list != null) {
			esaWhitelists.addAll(list);
		}
		return esaWhitelists;
	}
	
	private Set<String> forCrossDomainEsalists(JSONObject configureJson) {
		JSONObject json = configureJson.getJSONObject("crossDomainEsaLists");
		List<String> list = (List<String>) (json == null ? null : json.get("esa"));
		Set<String> crossDomainEsaLists = new HashSet<String>();
		if (list != null) {
			crossDomainEsaLists.addAll(list);
		}
		return crossDomainEsaLists;
	}

	private Map<String, ChannelSecurityConfigure> forChannelsConfigure(JSONObject configureJson) {
		JSONArray arrays = configureJson.getJSONArray("channelSecurity");
		if (arrays == null || arrays.size() == 0) {
			return null;
		}
		String channelId = null;
		Map<String, ChannelSecurityConfigure> map = new HashMap<String, ChannelSecurityConfigure>();
		for (int i = 0; i < arrays.size(); i++) {
			JSONObject channelJson = arrays.getJSONObject(i);
			ChannelSecurityConfigure channelConfig = forChannelConfig(channelJson);
			channelId = channelConfig.getId();
			if(channelId!=null){
				String channelIds[] = channelId.split(",",-1);
				for (String id : channelIds) {
					channelConfig.setId(id);
					map.put(id, channelConfig);
				}
			}
		}
		return map;

	}

	private ChannelSecurityConfigure forChannelConfig(JSONObject channelJSON) {
		ChannelSecurityConfigure channelConfig = JSONObject.toJavaObject(channelJSON, ChannelSecurityConfigure.class);
		JSONObject json = channelJSON.getJSONObject("limitIpList");
		List<String> ipList = (List<String>) (json == null ? null : json.get("ip"));
		//
		if (ipList != null) {
			Set<String> limitIps = new HashSet<String>();
			limitIps.addAll(ipList);
			channelConfig.setLimitIps(limitIps);
		}
		json = channelJSON.getJSONObject("esaList");
		List<String> esaList = (List<String>) (json == null ? null : json.get("esa"));
		//
		if (esaList != null) {
			Set<String> limitEsas = new HashSet<String>();
			limitEsas.addAll(esaList);
			channelConfig.setEsas(limitEsas);
		}
		return channelConfig;
	}

	
	public ChannelSecurityConfigure getChannelConfigure(String channelId) {
		ChannelSecurityConfigure configure = (channnelsMap == null ? null : channnelsMap.get(channelId));
		/*
		 * if(configure==null){ throw new
		 * GenericBusinessException(SecurityResultCodes.CHANNEL_NOT_EXISTS
		 * ,"Channel="+channelId+" not exists."); }
		 */
		return configure;
	}

	

	@Override
	public boolean isWhitelist(String esaName) {
		return esaWhitelists!=null && esaWhitelists.contains(esaName);
	}
	@Override
	public boolean isCrossDomainEsaLists(String esaName) {
		return crossDomainEsaLists!=null && crossDomainEsaLists.contains(esaName);
	}

	@Override
	public void onChanged(PizzaURL pizzaURL, InputStream content) {
		if(content!=null){
			if (logger.isInfoEnabled()) {
				logger.info("Parsing security config on refreshed.");
			}
			this.parseConfig(content);
		}
	}


	@Override
	public PizzaURL getPizzaURL() {
		if(isListenEnable()){
			return ((PizzaResource)configResource).getPizzaURL();
		}
		return null;
	}

	@Override
	public boolean isListenEnable() {
		return configResource!=null && configResource instanceof PizzaResource;
	}

	public Resource getConfigResource() {
		return configResource;
	}

	public void setConfigResource(Resource configResource) {
		this.configResource = configResource;
	}

	public Set<String> getCrossDomainEsaLists() {
		return crossDomainEsaLists;
	}

	public void setCrossDomainEsaLists(Set<String> crossDomainEsaLists) {
		this.crossDomainEsaLists = crossDomainEsaLists;
	}

	
}
