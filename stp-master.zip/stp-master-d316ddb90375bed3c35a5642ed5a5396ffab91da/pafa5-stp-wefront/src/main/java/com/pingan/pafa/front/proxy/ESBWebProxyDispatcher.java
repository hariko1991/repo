package com.pingan.pafa.front.proxy;

import java.io.IOException;
import java.io.OutputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.paic.pafa.app.dto.ServiceRequest;
import com.pingan.pafa.front.proxy.security.ESBSecurity;
import com.pingan.pafa.papp.web.esa.ESAWebDispatcher;

public class ESBWebProxyDispatcher extends ESAWebDispatcher {
	private Logger log = LoggerFactory.getLogger(ESBWebProxyDispatcher.class);
	/**
	 * 过滤请求过来的ip地址，注意要防止代理ip
	 */
	@Override
	protected void initServiceRequest(ServiceRequest serviceRequest,
			HttpServletRequest httpRequest, HttpServletResponse httpResponse) {
		String requestIp = httpRequest.getParameter("clientIp");
		
		String clientIp = getClientIp(httpRequest);//httpRequest.getRemoteAddr();
		if(requestIp!=null&&!"".equals(requestIp)&&!requestIp.equals(clientIp)){
			serviceRequest.setParameter(ESBSecurity.KEY_CLIENT_IP, clientIp);
		}else {
			serviceRequest.setParameter(ESBSecurity.KEY_CLIENT_IP, clientIp);
		}
		String requestURI = httpRequest.getRequestURI();
		serviceRequest.setParameter(ESBSecurity.KEY_REQUEST_URI,requestURI);
	}

	/**
	 * 在很多应用下都可能有需要将用户的真实IP记录下来，这时就要获得用户的真实IP地址，在JSP里，获取客户端的IP地
	 * 址的方法是：request.getRemoteAddr()，这种方法在大部分情况下都是有效的。但是在通过了Apache,Squid等
	 * 反向代理软件就不能获取到客户端的真实IP地址了。
	 * 但是在转发请求的HTTP头信息中，增加了X－FORWARDED－FOR信息。用以跟踪原有的客户端IP地址和原来客户端请求的服务器地址。
	 * 
	 * @param request
	 * @return
	 */
	public String getClientIp(HttpServletRequest request) {
		String ip = request.getHeader("x-forwarded-for");
		if (log.isDebugEnabled()) 
			log.debug("x-forwarded-for = {}", ip);
		
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("Proxy-Client-IP");
			if (log.isDebugEnabled()) {
				log.debug("Proxy-Client-IP = {}", ip);
			}
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getHeader("WL-Proxy-Client-IP");
			if (log.isDebugEnabled()) {
				log.debug("WL-Proxy-Client-IP = {}", ip);
			}
		}
		if (ip == null || ip.length() == 0 || "unknown".equalsIgnoreCase(ip)) {
			ip = request.getRemoteAddr();
			if (log.isDebugEnabled()) {
				log.debug("RemoteAddr-IP = {}", ip);
			}
		}
		if (StringUtils.isNotBlank(ip)) {
			ip = ip.split(",")[0];
		}
		return ip;
	}
	
	@Override
	protected void outputHttpResponse(byte[] jsonDatas,HttpServletResponse response) throws IOException{
//		response.setContentType("text/html;charset="+response.getCharacterEncoding());
		response.setContentType("application/json;charset="+response.getCharacterEncoding());
		response.setContentLength(-1);
		//
		if(jsonDatas!=null){
			OutputStream out=response.getOutputStream();
			out.write(jsonDatas);
			out.flush();
		}else{
			logger.warn("Response model is null.");
		}
	}

}
