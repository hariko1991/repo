package com.pingan.pafa.front.proxy;

import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.paic.pafa.app.dto.ServiceRequest;
import com.paic.pafa.app.dto.ServiceResponse;
import com.pingan.pafa.front.proxy.security.AccessTokenApplyResult;
import com.pingan.pafa.front.proxy.security.ESBSecurity;
import com.pingan.pafa.front.proxy.security.SecurityCheckForm;
import com.pingan.pafa.front.proxy.security.SignInfoForm;
import com.pingan.pafa.papp.esa.filter.AbstractESAFilter;
import com.pingan.pafa.papp.esa.filter.ESAFilterChain;

public class SecurityESAFilter extends AbstractESAFilter{
	private Logger log = LoggerFactory.getLogger(SecurityESAFilter.class);
	
	private ESBSecurity apiSecurity;
	
	private ESBSecurity openapiSecurity;
	
	private boolean apiSecurityEnable=true;
	
	private boolean openapiSecurityEnable=true;
	
	public SecurityESAFilter(){
		this.setFiltAll(true);
	}

	@Override
	public ServiceResponse doFilter(ServiceRequest request, ESAFilterChain chain) throws Throwable {
		String esaName=request.getRequestedServiceID();
		String requestURI = (String)request.getParameter("requestURI");
		log.info(">>>>>>>>>>>>>>request parameters: " + request.getParameters());
		if(requestURI != null && (requestURI.contains("/api/")))
		{
			//内网F5调用
			if(apiSecurityEnable){
				String channelId = (String)request.getParameter("channel");
				SecurityCheckForm form = new SecurityCheckForm();
				form.setChannel(channelId);
				form.setEsaName(esaName);
				form.setAccessToken((String)request.getParameter("accessToken"));
				form.setClientIp((String)request.getParameter(ESBSecurity.KEY_CLIENT_IP));
				AccessTokenApplyResult result = apiSecurity.securityCheck(form,request);
				if(result!=null){
					ServiceResponse response = new ServiceResponse(new HashMap<Object,Object>());
					response.setResponseCode(result.getResponseCode());
					response.setResponseMsg(result.getResponseMsg());
					return response;
				}
			}
		}
		else if(requestURI.contains("/copsf/bank/hook/"))
		{
//			log.info("安全认证通过，调用ESA服务：" + esaName);
		}
		else if(requestURI.contains("/openapi/"))
		{
			//首次进来需要验证申请token，
			if(esaName.equals("stp-front-esb.applyAccessToken")){
				String channelId = (String)request.getParameter("channel");
				SignInfoForm infoForm=new SignInfoForm();
				infoForm.setClientIp((String)request.getParameter(ESBSecurity.KEY_CLIENT_IP));
				infoForm.setChannel(channelId);
				infoForm.setRandom((String)request.getParameter("random"));
				infoForm.setTimestamp((String)request.getParameter("timestamp"));
				infoForm.setSign((String)request.getParameter("sign"));
				
				AccessTokenApplyResult result = openapiSecurity.applyAccessToken(infoForm);
				Map<Object,Object> model=new HashMap<Object,Object>();
				model.put("accessToken", result.getAccessToken());
				model.put("expireTime", result.getExpireTime());
				ServiceResponse response = new ServiceResponse(model);
				response.setResponseCode(result.getResponseCode());
				response.setResponseMsg(result.getResponseMsg());
				return response;
			}else if(openapiSecurityEnable){
				String channelId = (String)request.getParameter("channel");
				SecurityCheckForm form = new SecurityCheckForm();
				form.setChannel(channelId);
				form.setEsaName(esaName);
				form.setAccessToken((String)request.getParameter("accessToken"));
				form.setClientIp((String)request.getParameter(ESBSecurity.KEY_CLIENT_IP));
				AccessTokenApplyResult result = openapiSecurity.securityCheck(form,request);
				if(result!=null){
					ServiceResponse response = new ServiceResponse(new HashMap<Object,Object>());
					response.setResponseCode(result.getResponseCode());
					response.setResponseMsg(result.getResponseMsg());
					return response;
				}
			}
		}
		else
		{
			ServiceResponse response = new ServiceResponse(new HashMap<Object,Object>());
			response.setResponseCode(SecurityResultCodes.ILLEGAL_REQUEST);
			response.setResponseMsg("不合法的请求");
			return response;
		}
		log.info("安全认证通过，调用ESA服务：" + esaName);
		
		return chain.doFilter(request);
	}
	
	public ESBSecurity getApiSecurity() {
		return apiSecurity;
	}

	public void setApiSecurity(ESBSecurity apiSecurity) {
		this.apiSecurity = apiSecurity;
	}

	public boolean isApiSecurityEnable() {
		return apiSecurityEnable;
	}

	public void setApiSecurityEnable(boolean apiSecurityEnable) {
		this.apiSecurityEnable = apiSecurityEnable;
	}

	public boolean isOpenapiSecurityEnable() {
		return openapiSecurityEnable;
	}

	public void setOpenapiSecurityEnable(boolean openapiSecurityEnable) {
		this.openapiSecurityEnable = openapiSecurityEnable;
	}

	public ESBSecurity getOpenapiSecurity() {
		return openapiSecurity;
	}

	public void setOpenapiSecurity(ESBSecurity openapiSecurity) {
		this.openapiSecurity = openapiSecurity;
	}
}
