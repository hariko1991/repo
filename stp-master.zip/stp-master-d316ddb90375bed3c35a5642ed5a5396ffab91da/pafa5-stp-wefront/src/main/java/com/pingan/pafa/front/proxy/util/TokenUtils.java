package com.pingan.pafa.front.proxy.util;

import java.util.UUID;

public class TokenUtils {
	private static String sha1chars = "pafa5frontproxyforbank";

	public static void main(String[] args) {
		String channel = "1002";
		String token = createToken(channel);
		System.out.println(token);
		System.out.println(SHA1Utils.sign(token + channel + sha1chars));
	}
	
	public static String createToken(String channel)
	{
		String token = UUID.randomUUID().toString().replaceAll("-", "").toUpperCase();
		return token;
	}
}
