package com.pingan.pafa.front.proxy.filter;

import java.security.InvalidKeyException;
import java.security.Key;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.NoSuchAlgorithmException;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.util.Arrays;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;

/***
 * @deprecated
 * @author LIXINGNAN945
 *
 */
public abstract class SecurityUtil {

	// public static final String DES = "DES";
	public static final String DSA = "DSA";
	public static final String UTF8 = "UTF8";
	public static final String AES = "AES";

	// public static final String DESARITHMETIC = "DES/ECB/PKCS5Padding";
	public static final String DSASIGN = "SHA1withDSA";

	/**
	 * 
	 * @param keyMaterial
	 *            构建AES密钥的字符串
	 * @return SecretKey AES加密用的密钥
	 * @throws RuntimeException
	 * @see
	 * @since pafa4.0.8
	 */
	public static SecretKey generateSecretKey(String keyMaterial) {
		return new javax.crypto.spec.SecretKeySpec(keyMaterial.getBytes(), AES);
		
	}

	public static KeyPair makeKeyPair() {
		KeyPairGenerator keyGen;
		try {
			keyGen = KeyPairGenerator.getInstance(DSA);
			keyGen.initialize(1024);
			KeyPair key = keyGen.generateKeyPair();
			return key;
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException("没有DSA算法,详细信息: " + e.getMessage());
		}

	}

	/**
	 * 使用AES进行加密
	 * 
	 * @param
	 * @return
	 * @throws
	 * @see
	 * @since pafa4.0.8
	 */
	public static String encryptMessage(String message, Key key) {
		String result = message;
		Cipher c1;
		try {
			c1 = Cipher.getInstance(AES);
			c1.init(Cipher.ENCRYPT_MODE, key);
			byte[] cipherByte = c1.doFinal(result.getBytes());
			result = toHexString(cipherByte);
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException("没有AES算法,详细信息: " + e.getMessage());
		} catch (NoSuchPaddingException e) {
			throw new RuntimeException("没有PKCS5Padding,详细信息: " + e.getMessage());
		} catch (InvalidKeyException e) {
			throw new RuntimeException("InvalidKey,详细信息: " + e.getMessage());
		} catch (IllegalStateException e) {
			throw new RuntimeException("IllegalState,详细信息: " + e.getMessage());
		} catch (IllegalBlockSizeException e) {
			throw new RuntimeException("IllegalBlockSize,详细信息: "
					+ e.getMessage());
		} catch (BadPaddingException e) {
			throw new RuntimeException("BadPadding,详细信息: " + e.getMessage());
		}
		return result;
		

	}

	/**
	 * 使用AES进行解密
	 * 
	 * @param
	 * @return
	 * @throws
	 * @see
	 * @since pafa4.0.8
	 */
	public static String decryptMessage(String encrypetMessage, Key key) {
		String result = encrypetMessage;
		Cipher c1;
		try {
			c1 = Cipher.getInstance(AES);
			c1.init(Cipher.DECRYPT_MODE, key);
			byte[] clearByte = c1.doFinal(toBytes(encrypetMessage));
			result = new String(clearByte);
		} catch (NoSuchAlgorithmException e) {
			throw new RuntimeException("没有AES算法,详细信息: " + e.getMessage());
		} catch (NoSuchPaddingException e) {
			throw new RuntimeException("没有PKCS5Padding,详细信息: " + e.getMessage());
		} catch (InvalidKeyException e) {
			throw new RuntimeException("InvalidKey,详细信息: " + e.getMessage());
		} catch (IllegalStateException e) {
			throw new RuntimeException("IllegalState,详细信息: " + e.getMessage());
		} catch (IllegalBlockSizeException e) {
			throw new RuntimeException("IllegalBlockSize,详细信息: "
					+ e.getMessage());
		} catch (BadPaddingException e) {
			throw new RuntimeException("BadPadding,详细信息: " + e.getMessage());
		}
		return result;

	}

	public static String signMessage(String message, PrivateKey key)
			throws Exception {
		byte[] messageByte = message.getBytes(UTF8);
		Signature sig = Signature.getInstance(DSASIGN);
		sig.initSign(key);
		sig.update(messageByte);
		byte[] signature = sig.sign();
		return toHexString(signature);

	}

	public static boolean verifySign(String message, String sign, PublicKey key) {
		try {
			byte[] messageByte = message.getBytes(UTF8);
			byte[] signByte = toBytes(sign);
			//
			// verify the signature with the public key
			Signature sig = Signature.getInstance(DSASIGN);
			sig.initVerify(key);
			sig.update(messageByte);

			if (sig.verify(signByte)) {
				return true;
			} else {
				return false;
			}
		} catch (Exception se) {
			return false;
		}

	}

	public static boolean keysEqual(Key key1, Key key2) {
		if (key1.equals(key2)) {
			return true;
		}
		if (Arrays.equals(key1.getEncoded(), key2.getEncoded())) {
			return true;
		}

		return false;
	}

	
	public static String toHexString(byte[] b) {
		StringBuffer sb = new StringBuffer(b.length * 2);
		for (int i = 0; i < b.length; i++) {
			sb.append(HEXCHAR[(b[i] & 0xf0) >>> 4]);
			sb.append(HEXCHAR[b[i] & 0x0f]);
		}
		return sb.toString();
	}

	
	public static final byte[] toBytes(String s) {
		byte[] bytes;
		bytes = new byte[s.length() / 2];
		for (int i = 0; i < bytes.length; i++) {
			bytes[i] = (byte) Integer.parseInt(s.substring(2 * i, 2 * i + 2),
					16);
		}
		return bytes;
	}

	private static char[] HEXCHAR = { '0', '1', '2', '3', '4', '5', '6', '7',
			'8', '9', 'a', 'b', 'c', 'd', 'e', 'f' };


	public static String outputfilter(String value) {
		if (value == null) {
			return null;
		}
		StringBuffer result = new StringBuffer(value.length());
		for (int i = 0; i < value.length(); ++i) {
			switch (value.charAt(i)) {
			case '<':
				result.append("&lt;");
				break;
			case '>':
				result.append("&gt;");
				break;
			case '"':
				result.append("&quot;");
				break;
			case '\'':
				result.append("&#39;");
				break;
			case '%':
				result.append("&#37;");
				break;
			case ';':
				result.append("&#59;");
				break;
			case '(':
				result.append("&#40;");
				break;
			case ')':
				result.append("&#41;");
				break;
			case '&':
				result.append("&amp;");
				break;
			case '+':
				result.append("&#43;");
				break;
			default:
				result.append(value.charAt(i));
				break;
			}
		}
		return result.toString();
	}

	public static String fixHttpRS(String str) {
		if (str == null) {
			return null;
		}
		String str_temp = str;

		while (true) {
			if ((str_temp.indexOf("CR") == -1)
					&& (str_temp.indexOf("%0d") == -1)
					&& (str_temp.indexOf("\r") == -1)
					&& (str_temp.indexOf("LF") == -1)
					&& (str_temp.indexOf("%0a") == -1)
					&& (str_temp.indexOf("\n") == -1)) {
				break;
			}
			if (str_temp.indexOf("CR") != -1) {
				str_temp = str_temp.replaceAll("CR", "");
			}
			if (str_temp.indexOf("%0d") != -1) {
				str_temp = str_temp.replaceAll("%0d", "");
			}
			if (str_temp.indexOf("\r") != -1) {
				str_temp = str_temp.replaceAll("\r", "");
			}
			if (str_temp.indexOf("LF") != -1) {
				str_temp = str_temp.replaceAll("LF", "");
			}
			if (str_temp.indexOf("%0a") != -1) {
				str_temp = str_temp.replaceAll("%0a", "");
			}
			if (str_temp.indexOf("\n") != -1) {
				str_temp = str_temp.replaceAll("\n", "");
			}
		}

		return str_temp.toString();
	}

	public static String sqlfilter(String value) {
		if (value == null) {
			return null;
		}
		StringBuffer result = new StringBuffer(value.length());
		for (int i = 0; i < value.length(); ++i) {
			switch (value.charAt(i)) {
			case '\'':
				result.append("0x20");
				break;
			case '#':
				result.append("0x20");
				break;
			case '"':
				result.append("0x20");
				break;
			case '/':
				result.append("0x20");
				break;
			case '$':
				result.append("0x20");
				break;
			default:
				result.append(value.charAt(i));
				break;
			}
		}
		return result.toString();
	}
}
