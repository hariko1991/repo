package com.pingan.pafa.front.proxy.security;

public class SignInfoForm {
	/**
	 * 客户端ip
	 */
	private String clientIp;
	/***
	 * 渠道ID
	 */
	private String channel;
	
	/**RSA签名串,base64密码*/
	private String sign;
	
	/**客户端签名时间*/
	private String timestamp;
	
	/**客户端签名随机数*/
	private String random;
	
	public SignInfoForm(){}
	
	public SignInfoForm(String clientIp,String channel,String timestamp,String random){
		this.clientIp = clientIp;
		this.channel=channel;
		this.timestamp=timestamp;
		this.random=random;
	}

	public String getClientIp() {
		return clientIp;
	}

	public void setClientIp(String clientIp) {
		this.clientIp = clientIp;
	}

	

	public String getSign() {
		return sign;
	}

	public void setSign(String sign) {
		this.sign = sign;
	}

	public String getChannel() {
		return channel;
	}

	public void setChannel(String channel) {
		this.channel = channel;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getRandom() {
		return random;
	}

	public void setRandom(String random) {
		this.random = random;
	}
}
