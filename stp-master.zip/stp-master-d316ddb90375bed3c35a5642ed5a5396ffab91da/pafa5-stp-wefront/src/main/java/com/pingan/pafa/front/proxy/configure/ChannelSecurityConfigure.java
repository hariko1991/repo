package com.pingan.pafa.front.proxy.configure;

import java.util.Set;

public class ChannelSecurityConfigure {
	
	private String id;
	private String name;
	private boolean signEnable;
	private boolean tokenEnable;
	private String publicKey;
	private boolean limitIpEnable;
	private Set<String> limitIps;
	private String tokenKey;
	private boolean limitEsaEnable;
	private Set<String> esas;
	private boolean crossDomainEnable;
	private Set<String> crossEsas;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isSignEnable() {
		return signEnable;
	}

	public void setSignEnable(boolean signEnable) {
		this.signEnable = signEnable;
	}

	public boolean isTokenEnable() {
		return tokenEnable;
	}

	public void setTokenEnable(boolean tokenEnable) {
		this.tokenEnable = tokenEnable;
	}

	public String getPublicKey() {
		return publicKey;
	}

	public void setPublicKey(String publicKey) {
		this.publicKey = publicKey;
	}

	public boolean isLimitIpEnable() {
		return limitIpEnable;
	}

	public void setLimitIpEnable(boolean limitIpEnable) {
		this.limitIpEnable = limitIpEnable;
	}

	public Set<String> getLimitIps() {
		return limitIps;
	}

	public void setLimitIps(Set<String> limitIps) {
		this.limitIps = limitIps;
	}

	public Set<String> getEsas() {
		return esas;
	}

	public void setEsas(Set<String> esas) {
		this.esas = esas;
	}
	
	public boolean checkIp(String ip){
		if(this.limitIpEnable && this.limitIps!=null && this.limitIps.size()>0){
			if(ip==null){
				return false;
			}else if(!limitIps.contains(ip)){
				return false;
			}
		}
		return true;
	}

	public String getTokenKey() {
		return tokenKey;
	}

	public void setTokenKey(String tokenKey) {
		this.tokenKey = tokenKey;
	}

	public boolean isLimitEsaEnable() {
		return limitEsaEnable;
	}

	public void setLimitEsaEnable(boolean limitEsaEnable) {
		this.limitEsaEnable = limitEsaEnable;
	}

	public boolean isCrossDomainEnable() {
		return crossDomainEnable;
	}

	public void setCrossDomainEnable(boolean crossDomainEnable) {
		this.crossDomainEnable = crossDomainEnable;
	}

	public Set<String> getCrossEsas() {
		return crossEsas;
	}

	public void setCrossEsas(Set<String> crossEsas) {
		this.crossEsas = crossEsas;
	}

}
