package com.pingan.pafa.front.proxy.security;

import com.paic.pafa.app.dto.ServiceRequest;


public interface ESBSecurity {
	
	public static final String KEY_CLIENT_IP="clientIp";
	
	public final String KEY_REQUEST_URI = "requestURI";
	
	public static final String KEY_CHANNEL_ID="channel";
	
	
	public static final String KEY_ACCESS_TOKEN="accessToken";

	/**
	 * 申请令牌TOKEN
	 * @param info
	 * @return
	 */
	public AccessTokenApplyResult applyAccessToken(SignInfoForm info);
	
	/**
	 * 验证token是否过期
	 * @param checkForm
	 * @throws GenericBusinessException
	 */
	public AccessTokenApplyResult securityCheck(SecurityCheckForm checkForm,ServiceRequest request) ;
	
	/**
	 * 跨域验证
	 * @param esaName
	 * @param channelId
	 * @return
	 */
	public AccessTokenApplyResult crossDomainCheck(String esaName,String channelId);
	
	
}
