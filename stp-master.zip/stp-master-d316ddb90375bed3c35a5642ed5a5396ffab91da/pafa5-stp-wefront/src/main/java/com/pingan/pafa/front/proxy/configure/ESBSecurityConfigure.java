package com.pingan.pafa.front.proxy.configure;


public interface ESBSecurityConfigure {

	/**
	 * 获取配置文件中每个专业公司的配置
	 * @param channelId
	 * @return
	 */
	public ChannelSecurityConfigure getChannelConfigure(String channelId);
	
	
	boolean isWhitelist(String esaName);
	
	boolean isCrossDomainEsaLists(String esaName);
	  
	  
}
