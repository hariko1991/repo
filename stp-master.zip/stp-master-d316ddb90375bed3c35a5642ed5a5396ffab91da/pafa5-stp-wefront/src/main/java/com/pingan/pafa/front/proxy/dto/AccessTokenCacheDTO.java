package com.pingan.pafa.front.proxy.dto;

import java.util.Date;

public class AccessTokenCacheDTO implements java.io.Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
	 * 访问令牌
	 */
	private String accessToken;
	
	/***
	 * 渠道ID
	 */
	private String channelId;
	
	/**客户端签名时间*/
	private String timestamp;
	
	/**客户端签名随机数*/
	private String random;
	
	/**过期时间，单位：秒 */
	private long expiredTime;
	
	private long operationTime;

	public AccessTokenCacheDTO(){}
	
	public AccessTokenCacheDTO(String accessToken,String channelId,String timestamp,String random,long expiredTime){
		this.accessToken = accessToken;
		this.channelId = channelId;
		this.timestamp = timestamp;
		this.random = random;
		this.expiredTime = expiredTime;
		this.operationTime = new Date().getTime();
	}
	
	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public String getChannelId() {
		return channelId;
	}

	public void setChannelId(String channelId) {
		this.channelId = channelId;
	}

	public String getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(String timestamp) {
		this.timestamp = timestamp;
	}

	public String getRandom() {
		return random;
	}

	public void setRandom(String random) {
		this.random = random;
	}

	public long getExpiredTime() {
		return expiredTime;
	}

	public void setExpiredTime(long expiredTime) {
		this.expiredTime = expiredTime;
	}

	public long getOperationTime() {
		return operationTime;
	}

	public void setOperationTime(long operationTime) {
		this.operationTime = operationTime;
	}
	
	
}
