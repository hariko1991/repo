package com.pingan.pafa.front.proxy.filter;

import java.io.IOException;
import java.io.OutputStream;
import java.io.UnsupportedEncodingException;
import java.util.List;
import java.util.regex.Pattern;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.InitializingBean;
import org.springframework.core.Ordered;
import org.springframework.util.CollectionUtils;

import com.paic.pafa.web.util.WebCommonUtils;
import com.pingan.pafa.front.proxy.security.AccessTokenApplyResult;
import com.pingan.pafa.front.proxy.security.ESBSecurity;
import com.pingan.pafa.papp.web.filter.WebFilter;

/**
 * 跨域JSONP支持
 * @author HOUSHANGZHI377
 *
 */
@SuppressWarnings("deprecation")
public class JsonpSupportFilter extends WebCommonUtils implements WebFilter,Ordered,InitializingBean {

	private ESBSecurity apiSecurity;
	
	private ESBSecurity openapiSecurity;
	
	private boolean apiSecurityEnable=true;
	
	private boolean openapiSecurityEnable=true;

	private String callbackParameterName = "callback";

	private boolean enable = true;

	private String defaultPattern = "^\\w+$";

	private Pattern callBackPattern = null;
	
	private int order = -99999;
	
	private List<String> patterns;

	public JsonpSupportFilter() {
		this.setPattern("/**");
	}
	
	@Override
	public void afterPropertiesSet() throws Exception {
		this.callBackPattern = Pattern.compile(defaultPattern);
	}

	@Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) 
	{
		String params = null;
		HttpServletRequest httpRequest = (HttpServletRequest) request;
		HttpServletResponse httpResponse = (HttpServletResponse) response;
		String requestURI = httpRequest.getRequestURI();
		ESBSecurity handler = null;
	
		if (enable && (params = httpRequest.getParameter(callbackParameterName)) != null && (params = params.trim()).length() > 0)
		{
			if ((!this.isDisableRequestLog()) && logger.isInfoEnabled()) 
			{
				logger.info("do Jsonp filter...");
			}
			String esaName = null;
			if(requestURI.contains("/openapi/"))
			{
				esaName = requestURI.substring(requestURI.indexOf("/openapi") + 9);
				handler =  openapiSecurity;
			}
			else if(requestURI.contains("/api/"))
			{
				esaName = requestURI.substring(requestURI.indexOf("/api") + 5);
				handler = apiSecurity;
			}
			if(esaName != null)
			{
				String channelId = (String)httpRequest.getParameter("channel");

				AccessTokenApplyResult result = handler.crossDomainCheck(esaName,channelId);
				if(result != null)
				{   //非法请求
					logger.error("cross domain failed: code[" + result.getResponseCode() + "], message:[" + result.getResponseMsg() + "]");
					OutputStream out = null;
					try {
						response.setContentType("application/json;charset="+response.getCharacterEncoding());
						out = response.getOutputStream();
						out.write(SecurityUtil.outputfilter(params).getBytes("UTF-8"));
						out.write("(".getBytes("UTF-8"));
						out.write(("{\"responseCode\":\"" + result.getResponseCode() + "\",").getBytes("utf-8"));
						out.write(("\"responseMsg\":\"" + result.getResponseMsg() + "\"}").getBytes("utf-8"));
						out.write(")".getBytes("UTF-8"));
						out.flush();
					} catch (UnsupportedEncodingException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
					finally 
					{
						try {
							if(out != null)
							{
								out.close();
							}
						} catch (Exception e)
						{
							logger.error("close stream failed:" + e.getMessage());
						}
					}
					
				}
				else
				{
					//合法请求
					// 防止跨网站脚本的攻击
					if (callBackPattern.matcher(params).matches()) 
					{
						OutputStream out = null;
						try
						{
							out = response.getOutputStream();
							out.write(SecurityUtil.outputfilter(params).getBytes("UTF-8"));
							out.write("(".getBytes("UTF-8"));
							chain.doFilter(request, response);
						} 
						catch (Exception e) 
						{
							logger.error("error when call esa service:" + e.getMessage());
						} 
						finally 
						{
							try {
								out.write(")".getBytes("UTF-8"));
								out.flush();
								out.close();
							} catch (Exception e)
							{
								logger.error("error when add jsonp suffix:" + e.getMessage());
							}
						}

					} else 
					{
						logger.error("*****************jsonp callback function name must be matched by" + callBackPattern + "********************");
					}
				}
			}

		}
		else
		{
			if ((!this.isDisableRequestLog()) && logger.isInfoEnabled()) 
			{
				logger.info("Jump Jsonp filter...");
			}
			try
			{
				chain.doFilter(httpRequest, httpResponse);
			} catch (IOException e) {
				e.printStackTrace();
			} catch (ServletException e) {
				e.printStackTrace();
			}
		}

	}

	public boolean isOpenapiSecurityEnable() {
		return openapiSecurityEnable;
	}

	public void setOpenapiSecurityEnable(boolean openapiSecurityEnable) {
		this.openapiSecurityEnable = openapiSecurityEnable;
	}

	public ESBSecurity getOpenapiSecurity() {
		return openapiSecurity;
	}

	public void setOpenapiSecurity(ESBSecurity openapiSecurity) {
		this.openapiSecurity = openapiSecurity;
	}

	@Override
	public void destroy() {

	}

	@Override
	public void init(FilterConfig arg0) throws ServletException {

	}

	@Override
	public int getOrder() {
		return order;
	}
	public void setOrder(int order) {
		this.order = order;
	}
	
	
	public void setPatterns(List<String> patterns) {
		this.patterns = patterns;
	}
	
	public void setPattern(String pattern) {
		this.patterns = CollectionUtils.arrayToList(new String[]{pattern});
	}

	@Override
	public List<String> getPatterns() {
		return patterns;
	}

	public ESBSecurity getApiSecurity() {
		return apiSecurity;
	}

	public void setApiSecurity(ESBSecurity apiSecurity) {
		this.apiSecurity = apiSecurity;
	}

	public boolean isApiSecurityEnable() {
		return apiSecurityEnable;
	}

	public void setApiSecurityEnable(boolean apiSecurityEnable) {
		this.apiSecurityEnable = apiSecurityEnable;
	}
}
