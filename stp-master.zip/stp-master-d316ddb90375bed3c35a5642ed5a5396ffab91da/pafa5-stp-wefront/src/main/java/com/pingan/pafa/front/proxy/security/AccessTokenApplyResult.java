package com.pingan.pafa.front.proxy.security;


public class AccessTokenApplyResult {
	
	private String responseCode="0";
	
	private String responseMsg;

	private String accessToken;
	
	private Long expireTime;
	
	
	public AccessTokenApplyResult(String code){
		this.responseCode=code;
	}
	
	public AccessTokenApplyResult(String code,String message){
		this.responseCode=code;
		this.responseMsg=message;
	}
	
	public AccessTokenApplyResult(String code,String accessToken,long expireTime){
		this.responseCode=code;
		this.accessToken=accessToken;
		this.expireTime=System.currentTimeMillis()+(expireTime*1000);
	}

	public String getAccessToken() {
		return accessToken;
	}

	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}

	public Long getExpireTime() {
		return expireTime;
	}

	public void setExpireTime(Long expireTime) {
		this.expireTime = expireTime;
	}

	public String getResponseCode() {
		return responseCode;
	}

	public void setResponseCode(String responseCode) {
		this.responseCode = responseCode;
	}

	public String getResponseMsg() {
		return responseMsg;
	}

	public void setResponseMsg(String responseMsg) {
		this.responseMsg = responseMsg;
	}

	
	
}
