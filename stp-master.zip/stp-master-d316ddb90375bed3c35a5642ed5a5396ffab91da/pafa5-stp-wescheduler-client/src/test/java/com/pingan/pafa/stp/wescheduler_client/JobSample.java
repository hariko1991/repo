package com.pingan.pafa.stp.wescheduler_client;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.paic.pafa.biz.services.BaseServices;
import com.pingan.pafa.stp.wescheduler.client.WeschedulerName;

@Component
public class JobSample extends BaseServices {

    @Scheduled(cron = "0/60 * * * * ?")
    @WeschedulerName("testjob")
    public void test1() {
        logger.info("Runner test1 .....");
    }
    
    @Scheduled(fixedRate=70000)
    @WeschedulerName("test2job")
    public void test2() {
        logger.info("Runner test2 .....");
    }
    
    
}
