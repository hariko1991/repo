package com.pingan.pafa.stp.wescheduler_client;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList = "wescheduler-client")
public class WeschedulerClientTest extends BaseSARTest {

    @Test
    public void test() throws Exception {
        System.in.read();
    }

}
