package com.pingan.pafa.stp.wescheduler.common;

public interface WeschedulerConstants {

    public static final String PIZZA_ROOT_PATH = "/wescheduler";

    public static final String PIZZA_PATH_TRIGGER = "/triggers";

    public static final String PIZZA_PATH_REG = "/reg";
    
    public static final String PIZZA_PATH_RECEIPT = "/receipt";


    /**
     * 定时任务状态
     */
    public class JobStatus {
        public static final int DEF = 0;// 正常
        public static final int EXPIRED = 1;// 过期
        public static final int STOP = 2;// 停止
    }

    /**
     * 触发回执状态
     */
    public class TriggerReceiptStatus {
        public static final int LOCKED = 1; // 已竞锁
        public static final int OK = 2; // 已正常完成
        public static final int ERROR = 3; // 未完成，发生错误
        public static final int EXPIRED = 4; // 任务已过期，需要停止
    }
    
}
