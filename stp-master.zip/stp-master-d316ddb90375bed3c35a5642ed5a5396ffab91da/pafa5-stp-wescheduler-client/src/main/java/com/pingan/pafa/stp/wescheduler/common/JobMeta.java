package com.pingan.pafa.stp.wescheduler.common;

/***
 * 任务描述信息
 * 
 * @author LIXINGNAN945
 * 
 */
public class JobMeta implements java.io.Serializable {

    private static final long serialVersionUID = 2472328968963631802L;

    /** 任务BeanName */
    private String beanName;

    /** 任务BeanClass */
    private String beanClass;

    /** 任务方法 */
    private String methodName;

    /** JobName */
    private String jobName;

    /** JobId = domainId+"."+group+"."+jobName */
    private String id;
    
    /** 所属领域 */
    private String domainId;

    /** Job分组，命名空间，默认为组件名(sarName) */
    private String group;

    /** Job cron 表达式 */
    private String cronExpression;

    /** Job 启动延时 */
    private int startDelay;

    /** Job 重复执行间隔。与cronExpression为二选一。 */
    private long repeatInterval = -1L;

    /** 节点IP */
    private String instanceIp;

    /** 操作者 */
    private String updatedBy;

    @Override
    public String toString() {
        return "JobMeta [beanName=" + beanName + ", beanClass=" + beanClass + ", methodName="
                + methodName + ", jobName=" + jobName + ", id=" + id + ", domainId=" + domainId
                + ", group=" + group + ", cronExpression=" + cronExpression + ", startDelay="
                + startDelay + ", repeatInterval=" + repeatInterval + ", instanceIp=" + instanceIp
                + ", updatedBy=" + updatedBy + "]";
    }

    public String getBeanName() {
        return beanName;
    }

    public void setBeanName(String beanName) {
        this.beanName = beanName;
    }

    public String getBeanClass() {
        return beanClass;
    }

    public void setBeanClass(String beanClass) {
        this.beanClass = beanClass;
    }

    public String getMethodName() {
        return methodName;
    }

    public void setMethodName(String methodName) {
        this.methodName = methodName;
    }

    public String getJobName() {
        return jobName;
    }

    public void setJobName(String jobName) {
        this.jobName = jobName;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDomainId() {
        return domainId;
    }

    public void setDomainId(String domainId) {
        this.domainId = domainId;
    }

    public String getGroup() {
        return group;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public String getCronExpression() {
        return cronExpression;
    }

    public void setCronExpression(String cronExpression) {
        this.cronExpression = cronExpression;
    }

    public int getStartDelay() {
        return startDelay;
    }

    public void setStartDelay(int startDelay) {
        this.startDelay = startDelay;
    }

    public long getRepeatInterval() {
        return repeatInterval;
    }

    public void setRepeatInterval(long repeatInterval) {
        this.repeatInterval = repeatInterval;
    }

    public String getInstanceIp() {
        return instanceIp;
    }

    public void setInstanceIp(String instanceIp) {
        this.instanceIp = instanceIp;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public static long getSerialversionuid() {
        return serialVersionUID;
    }

}
