package com.pingan.pafa.stp.wescheduler.client;

/**
 * Wescheduler客户端
 * @author ZHANGJIAWEI370
 * 
 */
public interface WeschedulerClient {

    /**
     * 注册定时任务
     * @param confg
     */
    public void registerJob(JobClientConfig confg);

    /**
     * 是否可用
     * @return
     */
    public boolean isEnabled();

}
