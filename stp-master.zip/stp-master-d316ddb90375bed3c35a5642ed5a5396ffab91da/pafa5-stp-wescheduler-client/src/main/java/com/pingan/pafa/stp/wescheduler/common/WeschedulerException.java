package com.pingan.pafa.stp.wescheduler.common;

import com.pingan.pafa.exception.Pafa5Exception;

public class WeschedulerException extends Pafa5Exception {

    private static final long serialVersionUID = 7942178016650160562L;

    public WeschedulerException(String msg) {
        super(msg);
    }

    public WeschedulerException(String msg, Throwable th) {
        super(msg, th);
    }

}
