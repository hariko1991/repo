package com.pingan.pafa.stp.wescheduler.client;

import java.lang.reflect.Method;

import com.alibaba.fastjson.JSONObject;
import com.pingan.pafa.stp.wescheduler.common.JobMeta;

public class JobClientConfig extends JobMeta {

    private static final long serialVersionUID = 2198918636835399641L;

    private transient Method method;
    
    public Method getMethod() {
        return method;
    }

    public void setMethod(Method method) {
        this.method = method;
    }

    public String toJSONString() {
        return JSONObject.toJSONString(this);
    }

	
    
}
