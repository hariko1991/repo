package com.pingan.pafa.stp.wescheduler.client;

import java.util.Collection;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.SynchronousQueue;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;

import org.apache.commons.lang.StringUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.beans.BeansException;
import org.springframework.beans.FatalBeanException;
import org.springframework.beans.factory.DisposableBean;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.ApplicationContextAware;
import org.springframework.context.ConfigurableApplicationContext;

import com.alibaba.fastjson.JSONObject;
import com.paic.pafa.utils.MDCUtil;
import com.pingan.pafa.common.utils.PNetUtils;
import com.pingan.pafa.pizza.Pizza;
import com.pingan.pafa.pizza.PizzaListener;
import com.pingan.pafa.pizza.PizzaManager;
import com.pingan.pafa.stp.wescheduler.common.JobTriggerMeta;
import com.pingan.pafa.stp.wescheduler.common.TriggerReceiptMeta;
import com.pingan.pafa.stp.wescheduler.common.WeschedulerConstants;
import com.pingan.pafa.stp.wescheduler.common.WeschedulerConstants.TriggerReceiptStatus;
import com.pingan.pafa.stp.wescheduler.common.WeschedulerException;

public class WeschedulerClientBean implements WeschedulerClient, ApplicationContextAware,
        InitializingBean, DisposableBean {

    protected Log logger = LogFactory.getLog(WeschedulerClientBean.class);

    private String domainId;    //领域ID

    private String group;         //组件ID
    
    private volatile ThreadPoolExecutor threadPoolExecutor;

    private int threadSize = 3;

    private volatile PizzaManager pizza;

    private String pizzaManagerURL;

    private volatile boolean enabled = true;

    private volatile boolean isShutdowned = false;
    
    private String rootPath;

    private final Lock lock = new ReentrantLock();

    private ApplicationContext applicationContext;

    private volatile Map<String, JobClientConfig> jobConfigs =
            new ConcurrentHashMap<String, JobClientConfig>();

    @Override
    public void afterPropertiesSet() throws Exception {
    	if(domainId==null){
    		domainId = Pizza.getDomainId();
    	}
    	if(domainId==null){
    		domainId="def";
    	}
        if (StringUtils.isBlank(domainId)) {
            throw new FatalBeanException("domainId required.");
        }
        if (StringUtils.isBlank(group)) {
            throw new FatalBeanException("group required.");
        }
        rootPath=WeschedulerConstants.PIZZA_ROOT_PATH+"/"+domainId;
        //---------------------------------
        if (logger.isInfoEnabled()) {
            logger.info("WeschedulerClient inited,enabled=" + this.isEnabled()+",domainId="+domainId+",group="+group+".");
        }
        if (this.isEnabled()) {
            if (StringUtils.isNotBlank(pizzaManagerURL)) {
                this.pizza = Pizza.getPizzaContext().createManager(pizzaManagerURL);
            } else {
                this.pizza = Pizza.getManager();
            }
        }
    }

    @Override
    public synchronized void registerJob(JobClientConfig config) {
    	if(!this.isEnabled() || this.isShutdowned){
    		return ;
    	}
        String id = domainId + "." + group + "." + config.getJobName();
        config.setId(id);
        config.setDomainId(domainId);
        config.setGroup(group);
        config.setInstanceIp(PNetUtils.getLocalHost());
        if (jobConfigs.containsKey(id)) {
            throw new WeschedulerException("Job:" + id + " define repeated.");
        }
        jobConfigs.put(id, config);
        PizzaManager pizza=this.pizza;
        String rootPath=this.getRootPath();
        //------
        String regPath=rootPath+WeschedulerConstants.PIZZA_PATH_REG
        		+"/"+group+"."+config.getJobName()+"."+config.getInstanceIp();
        String configJson=config.toJSONString();
        if(logger.isInfoEnabled()){
        	 logger.info("Register job： " + regPath+",config="+configJson);
        }
        pizza.set(regPath,configJson,true);
        //---------------
        String triggerPath=rootPath+WeschedulerConstants.PIZZA_PATH_TRIGGER
        		+"/"+group+"."+config.getJobName();
        pizza.setListener(triggerPath,new TriggerPizzaListener());
    }
    
    
    class TriggerPizzaListener implements PizzaListener{
    	 public void handleConfigChange(String triggerMetaString) {
             if (triggerMetaString == null || triggerMetaString.length() == 0) {
                 return;
             }
             JobTriggerMeta triggerMeta =
                     JSONObject.parseObject(triggerMetaString, JobTriggerMeta.class);
             executeTriggerEvent(triggerMeta);
         }
    }

    protected void executeTriggerEvent(final JobTriggerMeta triggerMeta) {
        if (isShutdowned) {
            return;
        }
        PizzaManager pizza=this.pizza;
        String rootPath=this.getRootPath();
        String jobId = triggerMeta.getJobId();
        String triggerId = triggerMeta.getTriggerId();
        String domainId=this.getDomainId();
        String receiptPath=rootPath
        		+WeschedulerConstants.PIZZA_PATH_RECEIPT+"/"+triggerId;
        //
        final JobClientConfig config = this.jobConfigs.get(jobId);
        if (config == null) {
            logger.warn("Not found job defined for " + jobId);
            // 清理掉过期的JOB
            
            TriggerReceiptMeta receipt =
                    new TriggerReceiptMeta(triggerId, TriggerReceiptStatus.EXPIRED);
            receipt.setJobId(jobId);
            receipt.setDomainId(domainId);
            pizza.add(receiptPath, JSONObject.toJSONString(receipt),true);
            return;
        }
        TriggerReceiptMeta receipt =
                new TriggerReceiptMeta(triggerId, TriggerReceiptStatus.LOCKED);
        receipt.setJobId(jobId);
        receipt.setDomainId(domainId);
        // 竞权
        boolean isLocked =
        		pizza.add(receiptPath,JSONObject.toJSONString(receipt),true);
        if (!isLocked) {
            logger.info("Not seized  lock for job:" + jobId + " by triggerId:" + triggerId);
            return;
        }
        if (threadPoolExecutor == null) {
            try {
                lock.lock();
                if (threadPoolExecutor == null) {
                    threadPoolExecutor =
                            new ThreadPoolExecutor(threadSize, threadSize, 0,
                                    TimeUnit.MILLISECONDS, new SynchronousQueue<Runnable>());
                }
            } finally {
                lock.unlock();
            }
        }
        threadPoolExecutor.execute(new Runnable() {
            @Override
            public void run() {
                triggerJob(config, triggerMeta);
            }
        });
    }

    protected void triggerJob(JobClientConfig jobConfig, JobTriggerMeta triggerMeta) {
        if (isShutdowned) {
            return;
        }
        String logId = MDCUtil.generateRequestId();
        MDCUtil.set(logId);
        long t1 = System.nanoTime();
        String triggerId = triggerMeta.getTriggerId();
        String jobId = jobConfig.getId();
        PizzaManager pizza=this.pizza;
        String rootPath=this.rootPath;
        ConfigurableApplicationContext context =
                (ConfigurableApplicationContext) applicationContext;
        if (context == null || !context.isActive()) {
            return;
        }
        String receiptPath=rootPath+WeschedulerConstants.PIZZA_PATH_RECEIPT+"/"+
                triggerMeta.getTriggerId();
        try {
            if (logger.isInfoEnabled()) {
                logger.info("Execute job[" + jobConfig.getJobName() + "] and triggerId="
                        + triggerId);
            }
            Object bean = context.getBean(jobConfig.getBeanName());
            jobConfig.getMethod().invoke(bean, new Object[0]);
            double costTime = (System.nanoTime() - t1) / 1000 / 1000.0;
            if (logger.isInfoEnabled()) {
                logger.info("Execute job[" + jobConfig.getJobName() + "]completed,time=" + "#"
                        + costTime + "ms# and  triggerId=" + triggerMeta.getTriggerId());
            }
            try {
                TriggerReceiptMeta receipt =
                        new TriggerReceiptMeta(triggerId, TriggerReceiptStatus.OK);
                receipt.setCostTime(costTime);
                receipt.setJobId(jobId);
                receipt.setLogId(logId);
                receipt.setDomainId(domainId);
                pizza.set(receiptPath, JSONObject.toJSONString(receipt),true);
            } catch (Throwable ex) {
            }
        } catch (Exception ex) {
            double costTime = (System.nanoTime() - t1) / 1000 / 1000.0;
            TriggerReceiptMeta receipt =
                    new TriggerReceiptMeta(triggerId, TriggerReceiptStatus.ERROR, ex.getMessage());
            receipt.setCostTime(costTime);
            receipt.setJobId(jobId);
            receipt.setLogId(logId);
            receipt.setDomainId(domainId);
            pizza.set(receiptPath,JSONObject.toJSONString(receipt));
            if (logger.isErrorEnabled()) {
                logger.error("#" + costTime + "ms#Execute job[" + jobConfig.getJobName()
                        + "] error:" + ex.getMessage(), ex);
            }
        } finally {
            MDCUtil.clear();
        }
    }

    @Override
    public synchronized void destroy() {
    	if(isShutdowned){
    		return ;
    	}
        try {
            isShutdowned = true;
            PizzaManager pizza=this.pizza;
            if (this.enabled && pizza != null) {
            	Collection<JobClientConfig> configSet=jobConfigs.values();
            	for(JobClientConfig config:configSet){
            		String triggerPath=rootPath+WeschedulerConstants.PIZZA_PATH_TRIGGER
            	        		+"/"+group+"."+config.getJobName();
            		pizza.removeListener(triggerPath);
            	}
            }
            this.applicationContext = null;
            if (threadPoolExecutor != null) {
                threadPoolExecutor.shutdown();
                threadPoolExecutor = null;
            }
            if (pizzaManagerURL != null && pizzaManagerURL.length() > 0) {
            	pizza.shutdown();
            }
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
    }

    @Override
    public final void setApplicationContext(ApplicationContext applicationContext)
            throws BeansException {
        this.applicationContext = applicationContext;
    }

    public void setGroup(String group) {
        this.group = group;
    }

    public void setThreadSize(int threadSize) {
        this.threadSize = threadSize;
    }

    public void setPizzaManagerURL(String pizzaManagerURL) {
        this.pizzaManagerURL = pizzaManagerURL;
    }

    @Override
    public boolean isEnabled() {
        return this.enabled;
    }

    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }

	public String getRootPath() {
		return rootPath;
	}

	public void setRootPath(String rootPath) {
		this.rootPath = rootPath;
	}

	public String getDomainId() {
		return domainId;
	}

	public void setDomainId(String domainId) {
		this.domainId = domainId;
	}

    
}
