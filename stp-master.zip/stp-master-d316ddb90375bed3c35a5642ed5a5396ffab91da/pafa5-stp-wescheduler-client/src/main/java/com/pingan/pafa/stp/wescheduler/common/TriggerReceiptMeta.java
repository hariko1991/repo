package com.pingan.pafa.stp.wescheduler.common;

import com.pingan.pafa.common.utils.PNetUtils;

/***
 * 触发回执
 * 
 * @author LIXINGNAN945
 * 
 */
public class TriggerReceiptMeta {

    /** 回执状态 */
    private int status;

    /** 触发动作ID */
    private String triggerId;
    
    private String domainId;

    private String jobId;

    /** 结果msg */
    private String msg;

    /** 触发时间 */
    private long timestamp;

    /** 执行节点ID */
    private String executeNodeIp;

    /** 日志记录ID */
    private String logId;

    /** Job执行耗时 */
    private double costTime;

    public TriggerReceiptMeta() {}

    public TriggerReceiptMeta(String triggerId, int status) {
        this.triggerId = triggerId;
        this.status = status;
        this.timestamp = System.currentTimeMillis();
        this.executeNodeIp = PNetUtils.getLocalHost();
    }
    
    public TriggerReceiptMeta(String triggerId, int status, String msg) {
        this.triggerId = triggerId;
        this.status = status;
        this.timestamp = System.currentTimeMillis();
        this.executeNodeIp = PNetUtils.getLocalHost();
        this.msg = msg;
    }

    @Override
    public String toString() {
        return "TriggerReceipterMeta [status=" + status + ", triggerId=" + triggerId + ", jobId="
                + jobId + ", msg=" + msg + ", timestamp=" + timestamp + ", executeNodeIp="
                + executeNodeIp + ", logId=" + logId + ", costTime=" + costTime + "]";
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public long getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }

    public double getCostTime() {
        return costTime;
    }

    public void setCostTime(double costTime) {
        this.costTime = costTime;
    }

    public String getTriggerId() {
        return triggerId;
    }

    public void setTriggerId(String triggerId) {
        this.triggerId = triggerId;
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getExecuteNodeIp() {
        return executeNodeIp;
    }

    public void setExecuteNodeIp(String executeNodeIp) {
        this.executeNodeIp = executeNodeIp;
    }

    public String getLogId() {
        return logId;
    }

    public void setLogId(String logId) {
        this.logId = logId;
    }

	public String getDomainId() {
		return domainId;
	}

	public void setDomainId(String domainId) {
		this.domainId = domainId;
	}

    
}
