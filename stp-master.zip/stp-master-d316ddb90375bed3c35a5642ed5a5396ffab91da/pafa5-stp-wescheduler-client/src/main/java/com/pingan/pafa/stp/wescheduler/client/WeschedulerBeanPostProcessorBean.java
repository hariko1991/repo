package com.pingan.pafa.stp.wescheduler.client;

import java.lang.reflect.Method;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.aop.support.AopUtils;
import org.springframework.beans.BeansException;
import org.springframework.beans.factory.BeanCreationException;
import org.springframework.beans.factory.config.BeanPostProcessor;
import org.springframework.beans.factory.support.BeanDefinitionValidationException;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ApplicationObjectSupport;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.util.ClassUtils;
import org.springframework.util.StringUtils;

public class WeschedulerBeanPostProcessorBean extends ApplicationObjectSupport implements
        BeanPostProcessor {

    private Log logger = LogFactory.getLog(WeschedulerBeanPostProcessorBean.class);

    private WeschedulerClient weschedulerClient;

    @Override
    public Object postProcessAfterInitialization(Object bean, String beanName)
            throws BeansException {
        return bean;
    }

    private static Method getInterfaceMethod(Method m, Class<?> targetClazz) {
        Class<?>[] interfaces = ClassUtils.getAllInterfacesForClass(targetClazz);
        if (interfaces == null)
            return null;
        for (Class<?> intf : interfaces) {
            Method temp = ClassUtils.getMethodIfAvailable(intf, m.getName(), m.getParameterTypes());
            if (temp != null)
                return temp;
        }
        return null;
    }

    protected Object resolveDefaultValue(String value) {
        ConfigurableApplicationContext applicationContext =
                (ConfigurableApplicationContext) this.getApplicationContext();
        if (applicationContext != null) {
            return applicationContext.getBeanFactory().resolveEmbeddedValue(value);
        }
        return value;
    }

    protected JobClientConfig parseAnnotation(Scheduled annotation, Class<?> targetClazz,
            Method method, String beanName) {
        JobClientConfig config = new JobClientConfig();
        config.setMethodName(method.getName());
        config.setBeanName(beanName);
        config.setBeanClass(targetClazz.getName());
        config.setMethod(method);

        WeschedulerName nameAnnotation = method.getAnnotation(WeschedulerName.class);
        if (nameAnnotation == null) {
            throw new BeanDefinitionValidationException("Bean[" + beanName
                    + "]Scheduled job method[" + method.getName() + "] not find annotation:"
                    + WeschedulerName.class.getName());
        }
        String name = nameAnnotation.value();
        if ((name = name.trim()).length() == 0) {
            throw new BeanDefinitionValidationException("Bean[" + beanName
                    + "]Scheduled job method[" + method.getName() + "] annotation:"
                    + WeschedulerName.class.getName() + " config error.");
        }
        config.setJobName(name);
        
        String cronExpression = null;
        if (cronExpression == null && annotation.cron().length() > 0) {
            cronExpression = annotation.cron();
        }
        if (StringUtils.hasText(cronExpression)) {
            cronExpression = (String) resolveDefaultValue(cronExpression);
            if (logger.isInfoEnabled()) {
                logger.info("Add Scheduled[" + name + "] in bean<" + beanName + ">method<"
                        + method.getName() + ">,and config=" + annotation);
            }
            config.setCronExpression(cronExpression);
        } else {
            String repeatInterval = annotation.fixedRateString();
            if ((repeatInterval = repeatInterval.trim()).length() == 0
                    && annotation.fixedRate() > 0) {
                repeatInterval = "" + annotation.fixedRate();
            }
            if (repeatInterval.length() == 0) {
                repeatInterval = annotation.fixedDelayString();
                if ((repeatInterval = repeatInterval.trim()).length() == 0
                        && annotation.fixedDelay() > 0) {
                    repeatInterval = "" + annotation.fixedDelay();
                }
            }
            if ((repeatInterval = repeatInterval.trim()).length() != 0) {
                repeatInterval = (String) resolveDefaultValue(repeatInterval);
                long repeatIntervalLong = 0;
                try {
                    repeatIntervalLong = Long.parseLong(repeatInterval);
                } catch (NumberFormatException ex) {
                    throw new BeanDefinitionValidationException("Bean[" + beanName
                            + "]Scheduled job method[" + method.getName() + "] fixedRate["
                            + annotation.fixedRateString() + "]not be long value.");
                }
                config.setRepeatInterval(repeatIntervalLong);
                if (logger.isInfoEnabled()) {
                    logger.info("Add Scheduled Job[" + name + "] in bean<" + beanName + ">method<"
                            + method.getName() + ">,and config=" + annotation);
                }
            } else {
                throw new BeanDefinitionValidationException("Bean[" + beanName
                        + "]Scheduled job method[" + method.getName()
                        + "] not set fixedRate or cron.");
            }
        }
        if (annotation.initialDelay() > 0) {
            config.setStartDelay((int) annotation.initialDelay());
        } else if (annotation.initialDelayString().length() > 0) {
            String initialDelayStr = (String) resolveDefaultValue(annotation.initialDelayString());
            try {
                int startDelay = Integer.parseInt(initialDelayStr);
                config.setStartDelay(startDelay);
            } catch (NumberFormatException ex) {
                throw new BeanDefinitionValidationException("Bean[" + beanName
                        + "]Scheduled job method[" + method.getName() + "] initialDelayString["
                        + annotation.fixedRateString() + "]not be int value.");
            }
        }
        return config;
    }

    @Override
    public Object postProcessBeforeInitialization(Object bean, String beanName)
            throws BeansException {
        if (weschedulerClient.isEnabled()) {
            Class<?> targetClazz = AopUtils.getTargetClass(bean);
            Method[] methods = targetClazz.getDeclaredMethods();
            for (int i = 0; i < methods.length; i++) {
                Method method = methods[i];
                Scheduled sanno = method.getAnnotation(Scheduled.class);
                if (sanno != null) {
                    checkJobMethod(method, beanName, bean, targetClazz);
                    JobClientConfig config = parseAnnotation(sanno, targetClazz, method, beanName);
                    try {
                        this.weschedulerClient.registerJob(config);
                    } catch (Exception e) {
                        throw new BeanCreationException(e.getMessage(), e);
                    }
                }
            }
        }
        return bean;
    }

    protected void checkJobMethod(Method method, String beanName, Object bean, Class<?> targetClazz) {
        if (method.getParameterTypes().length != 0) {
            throw new BeanDefinitionValidationException("Bean[" + beanName + "]timer job method["
                    + method.getName() + "] can't has any paramters.");
        }
        if (AopUtils.isJdkDynamicProxy(bean)) {
            Method interfaceMethod = getInterfaceMethod(method, targetClazz);
            if (interfaceMethod != null) {
                method = interfaceMethod;
            } else {
                throw new BeanDefinitionValidationException(
                        "Jdk Dynamic Proxy be created for Bean[" + beanName + "], so Job method["
                                + method.getName() + "] required defined in interfaces.");
            }
        } else {
            if ((method.getModifiers() & 1) == 0) {
                throw new BeanDefinitionValidationException("Bean[" + beanName
                        + "]timer job method[" + method.getName() + "] required be public.");
            }
        }
    }
    
    public void setWeschedulerClient(WeschedulerClient weschedulerClient) {
        this.weschedulerClient = weschedulerClient;
    }

}
