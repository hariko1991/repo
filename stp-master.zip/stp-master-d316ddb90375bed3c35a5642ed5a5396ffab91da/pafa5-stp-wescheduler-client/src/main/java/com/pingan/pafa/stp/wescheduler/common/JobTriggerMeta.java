package com.pingan.pafa.stp.wescheduler.common;

/**
 * job触发信息
 * */
public class JobTriggerMeta {

    /** jobId */
    private String jobId;

    /** 触发动作ID */
    private String triggerId;

    /** 触发时间 */
    private long triggerTime;

    public JobTriggerMeta() {}

    public JobTriggerMeta(String jobId, String triggerId) {
        this.jobId = jobId;
        this.triggerId = triggerId;
        this.triggerTime = System.currentTimeMillis();
    }

    @Override
    public String toString() {
        return "JobTriggerMeta [jobId=" + jobId + ", triggerId=" + triggerId + ", triggerTime="
                + triggerTime + "]";
    }

    public String getJobId() {
        return jobId;
    }

    public void setJobId(String jobId) {
        this.jobId = jobId;
    }

    public String getTriggerId() {
        return triggerId;
    }

    public void setTriggerId(String triggerId) {
        this.triggerId = triggerId;
    }

    public long getTriggerTime() {
        return triggerTime;
    }

    public void setTriggerTime(long triggerTime) {
        this.triggerTime = triggerTime;
    }

}
