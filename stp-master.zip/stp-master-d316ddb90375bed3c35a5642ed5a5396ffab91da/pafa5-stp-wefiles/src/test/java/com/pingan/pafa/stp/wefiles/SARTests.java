package com.pingan.pafa.stp.wefiles;

import org.junit.Test;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;

@SARContextConfiguration(sarList = {"pafa_stp_wefiles"}, protocols = {"jetty"})
public class SARTests extends BaseSARTest {

    @Test
    public void iz() throws Throwable {
        System.in.read();
    }

}
