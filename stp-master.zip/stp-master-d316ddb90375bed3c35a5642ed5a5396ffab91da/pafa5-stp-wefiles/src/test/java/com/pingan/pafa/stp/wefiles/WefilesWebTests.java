package com.pingan.pafa.stp.wefiles;

import java.io.File;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa.stp.wefiles.WefileMeta;
import com.pingan.pafa.stp.wefiles.Wefiles;


@SARContextConfiguration(sarList={"pafa_stp_wefiles_web","pafa_stp_wefiles"},protocols={"jetty"})
public class WefilesWebTests extends BaseSARTest{

	@Resource(name="wefiles")
	private Wefiles wefiles;
	
	@Test
	public void test1() throws Throwable{
		File f=new File(this.getClass().getResource(this.getClass().getSimpleName()+".class").toURI());
		System.out.println("f="+f.getAbsolutePath());
		WefileMeta meta=wefiles.upload(new WefileMeta(f.getName(),"application/object-stream"),f);
		//
		MockHttpServletRequest request=this.createMockRequest("stp_wefiles.download/"+meta.getFileId());
		MockHttpServletResponse response=this.createMockResponse();
		this.handleWebRequest(request, response);
		logger.info("response.length="+response.getContentLength());
		logger.info("response.contentType="+response.getContentType());
		logger.info("response.Content-Disposition="+response.getHeader("Content-Disposition"));
	}
	/*
	@Test
	public void test2() throws Throwable{
		File f=new File(this.getClass().getResource(this.getClass().getSimpleName()+".class").toURI());
		System.out.println("f="+f.getAbsolutePath());
		WefileMeta meta=new WefileMeta(f.getName(),"application/object-stream");
		meta.setNamespace("pafa-stp");
		meta.setAliasName("stp_policy_2004121314");
		 meta=wefiles.upload(meta,f);
		//
		MockHttpServletRequest request=this.createMockRequest("stp_wefiles.download","namespace=pafa-stp&aliasName=stp_policy_2004121314");
		MockHttpServletResponse response=this.createMockResponse();
		this.handleWebRequest(request, response);
		logger.info("response.length="+response.getContentLength());
		logger.info("response.contentType="+response.getContentType());
		logger.info("response.Content-Disposition="+response.getHeader("Content-Disposition"));
	}*/
}
