package com.pingan.pafa.stp.wefiles.web;

import java.io.File;

import javax.annotation.Resource;

import org.junit.Test;
import org.springframework.mock.web.MockHttpServletRequest;
import org.springframework.mock.web.MockHttpServletResponse;

import com.pingan.pafa.papp.test.BaseSARTest;
import com.pingan.pafa.papp.test.SARContextConfiguration;
import com.pingan.pafa.stp.wefiles.WefileMeta;
import com.pingan.pafa.stp.wefiles.Wefiles;


@SARContextConfiguration(sarList="pafa_stp_wefiles")
public class DownloadControllerTests extends BaseSARTest{
	
	
	@Resource(name="wefiles")
	private Wefiles wefiles;
	
	
	@Test
	public void test1() throws Exception{
		File f=new File(this.getClass().getResource(this.getClass().getSimpleName()+".class").toURI());
		System.out.println("f="+f.getAbsolutePath());
		WefileMeta meta=wefiles.upload(new WefileMeta(f.getName(),"application/object-stream"),f);
		//
		MockHttpServletRequest request=this.createMockRequest("stp_wefiles.download/"+meta.getFileId());
		MockHttpServletResponse response=this.createMockResponse();
		this.handleWebRequest(request, response);
		logger.info("response.length="+response.getContentLength());
		logger.info("response.contentType="+response.getContentType());
		logger.info("response.Content-Disposition="+response.getHeader("Content-Disposition"));
		
	}
	
	
}
