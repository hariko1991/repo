package com.pingan.pafa.stp.wefiles.nas;

import com.pingan.pafa.exception.Pafa5Exception;

public class NasFileException extends Pafa5Exception {

    private static final long serialVersionUID = -8809479905473404351L;

    public NasFileException(String msg) {
        super(msg);
    }

    public NasFileException(String msg, Throwable th) {
        super(msg, th);
    }

}
