package com.pingan.pafa.stp.wefiles.nas.dao;

import com.pingan.pafa.stp.wefiles.nas.dto.FileMetaDTO;

public interface FileMetaDAO {

    public FileMetaDTO get(String fileId);

    public FileMetaDTO getByAlias(String aliasId);

    public boolean add(FileMetaDTO metaDTO);

    public boolean update(FileMetaDTO metaDTO);

}
