package com.pingan.pafa.stp.wefiles.nas.services.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.pingan.pafa.stp.wefiles.nas.dao.FileMetaDAO;
import com.pingan.pafa.stp.wefiles.nas.dto.FileMetaDTO;
import com.pingan.pafa.stp.wefiles.nas.services.FileMetaServices;

@Service("fileMetaServices")
public class FileMetaServicesImpl implements FileMetaServices {

    @Autowired
    private FileMetaDAO fileMetaDAO;

    @Override
    public FileMetaDTO get(String fileId) {
        return fileMetaDAO.get(fileId);
    }

    @Override
    public FileMetaDTO getByAliasId(String aliasId) {
        return fileMetaDAO.getByAlias(aliasId);
    }

    @Override
    public boolean add(FileMetaDTO metaDTO) {
        metaDTO.setStatus(0);
        return fileMetaDAO.add(metaDTO);
    }

    @Override
    public boolean update(FileMetaDTO metaDTO) {
        return fileMetaDAO.update(metaDTO);
    }

    public void setFileMetaDAO(FileMetaDAO fileMetaDAO) {
        this.fileMetaDAO = fileMetaDAO;
    }

}
