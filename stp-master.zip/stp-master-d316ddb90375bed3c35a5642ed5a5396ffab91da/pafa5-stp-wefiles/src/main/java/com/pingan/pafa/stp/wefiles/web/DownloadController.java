package com.pingan.pafa.stp.wefiles.web;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.stp.wefiles.Wefiles;

@Controller
public class DownloadController extends BaseController {

    @Autowired
    @Qualifier("wefiles")
    private Wefiles wefiles;

    @Value("${wefiles.download.enable}")
    private boolean downloadEnable;
    
    @RequestMapping("stp_wefiles.download/{fileId}")
    public ModelMap download(@PathVariable("fileId") String fileId, HttpServletRequest request,
            HttpServletResponse response) throws IOException {
        return download2(null, null, fileId, response);
    }

    @RequestMapping("stp_wefiles.download")
    public ModelMap download2(
            @RequestParam(value = "namespace", required = false) String namespace, 
            @RequestParam(value = "aliasName", required = false) String aliasName, 
            @RequestParam(value = "fileId", required = false) String fileId, 
            HttpServletResponse response) throws IOException {
        if (!downloadEnable) {
            throw new IOException("downloadEnable=false.");
        }
        
        if (StringUtils.isBlank(namespace) && StringUtils.isBlank(aliasName) 
                && StringUtils.isBlank(fileId)) {
            throw new IOException("downloadEnable=false.");
        }

        try {
            if (fileId == null) {
                wefiles.downloadByAlias(namespace, aliasName, response);
            } else {
                wefiles.download(fileId, response);
            }
        } catch (Exception ex) {
            logger.error(ex.getMessage(), ex);
        }
        return null;
    }  

    public void setWefiles(Wefiles wefiles) {
        this.wefiles = wefiles;
    }

    public void setDownloadEnable(boolean downloadEnable) {
        this.downloadEnable = downloadEnable;
    }

}
