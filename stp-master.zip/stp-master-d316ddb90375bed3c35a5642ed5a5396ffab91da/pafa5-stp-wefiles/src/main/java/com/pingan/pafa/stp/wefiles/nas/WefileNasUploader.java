package com.pingan.pafa.stp.wefiles.nas;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import com.pingan.pafa.stp.wefiles.WefileMeta;
import com.pingan.pafa.stp.wefiles.WefileUploader;
import com.pingan.pafa.stp.wefiles.nas.dto.FileMetaDTO;
import com.pingan.pafa.stp.wefiles.nas.services.FileMetaServices;

public class WefileNasUploader implements WefileUploader {
	
	private File persistFile;
	
	private WefileMeta meta;
	
	private OutputStream output;
	
	private FileMetaServices fileMetaServices;
	
	private String realNasPath;
	
	public WefileNasUploader(WefileMeta meta,File persistFile
			,FileMetaServices fileMetaServices
			,String realNasPath){
		this.persistFile=persistFile;
		this.meta=meta;
		this.fileMetaServices=fileMetaServices;
		this.realNasPath=realNasPath;
	}

	@Override
	public OutputStream getOutput() {
		if(output==null){
			try {
				output=new FileOutputStream(persistFile);
			} catch (FileNotFoundException e) {
				throw new NasFileException("Upload file="+meta+" error,cause:"+e.getMessage(),e);
			}
		}
		return output;
	}

	@Override
	public void setInputStream(InputStream input) {
	}

	@Override
	public WefileMeta getMeta() {
		return meta;
	}

	@Override
	public void doFinally() {
		if(output!=null){
			try {
				output.flush();
				output.close();
			} catch (IOException e) {
				throw new NasFileException("IOException:"+e.getMessage(),e);
			}
			fileMetaServices.add(new FileMetaDTO(meta,this.realNasPath,true));
		}
	}

}
