package com.pingan.pafa.stp.wefiles.web;

import java.io.IOException;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.commons.CommonsMultipartFile;

import com.paic.pafa.web.BaseController;
import com.pingan.pafa.stp.wefiles.WefileMeta;
import com.pingan.pafa.stp.wefiles.Wefiles;

@Controller
public class UploadController extends BaseController {

    @Autowired
    @Qualifier("wefiles")
    private Wefiles wefiles;

    @Value("${wefiles.upload.enable}")
    private boolean uploadEnable;

    @RequestMapping("stp_wefiles.upload")
    @ResponseBody
    public ModelMap upload(UploadForm form, HttpServletRequest request, HttpServletResponse response)
            throws IOException {
        if (!uploadEnable) {
            throw new IOException("uploadEnable=false");
        }
        CommonsMultipartFile file = form.getFile();
        if (file == null) {
            throw new IOException("file is null. not selected file.");
        }

        WefileMeta meta = new WefileMeta(file.getOriginalFilename(), file.getContentType());
        meta.setCharset(form.getCharset());
        meta.setExpiredTime(form.getExpiredTime());
        meta.setFileSize((int) file.getSize());
        meta.setNamespace(form.getNamespace());
        meta.setAliasName(form.getAliasName());
        if (logger.isInfoEnabled()) {
            logger.info("Upload meta=" + meta);
        }
        wefiles.upload(meta, file.getInputStream());

        ModelMap modelMap = new ModelMap();
        modelMap.put("responseCode", "0");
        modelMap.put("fileId", meta.getFileId());
        return modelMap;
    }

    public void setWefiles(Wefiles wefiles) {
        this.wefiles = wefiles;
    }

}
