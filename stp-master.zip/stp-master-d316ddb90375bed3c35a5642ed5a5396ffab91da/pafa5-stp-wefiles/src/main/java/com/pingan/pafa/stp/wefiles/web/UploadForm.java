package com.pingan.pafa.stp.wefiles.web;

import org.springframework.web.multipart.commons.CommonsMultipartFile;

public class UploadForm {

    private CommonsMultipartFile file;

    private int expiredTime;

    private String charset;

    private String namespace;

    private String aliasName;
    
    @Override
    public String toString() {
        return "UploadForm [file=" + file + ", expiredTime=" + expiredTime + ", charset=" + charset
                + ", namespace=" + namespace + ", aliasName=" + aliasName + "]";
    }

    public CommonsMultipartFile getFile() {
        return file;
    }

    public void setFile(CommonsMultipartFile file) {
        this.file = file;
    }

    public int getExpiredTime() {
        return expiredTime;
    }

    public void setExpiredTime(int expiredTime) {
        this.expiredTime = expiredTime;
    }

    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public String getAliasName() {
        return aliasName;
    }

    public void setAliasName(String aliasName) {
        this.aliasName = aliasName;
    }

}
