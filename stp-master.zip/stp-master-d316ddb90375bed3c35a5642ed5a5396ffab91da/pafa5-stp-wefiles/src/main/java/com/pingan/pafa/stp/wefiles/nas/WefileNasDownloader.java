package com.pingan.pafa.stp.wefiles.nas;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;

import com.pingan.pafa.stp.wefiles.WefileDownloader;
import com.pingan.pafa.stp.wefiles.WefileMeta;
import com.pingan.pafa.stp.wefiles.nas.dto.FileMetaDTO;

public class WefileNasDownloader implements WefileDownloader {

    private FileMetaDTO metaDTO;

    private File persistFile;

    private WefileMeta meta;

    private InputStream input;

    public WefileNasDownloader(FileMetaDTO metaDTO, File persistFile) {
        this.metaDTO = metaDTO;
        this.persistFile = persistFile;
    }

    @Override
    public WefileMeta getMeta() {
        if (meta == null) {
            meta = metaDTO.toWefileMeta();
        }
        return meta;
    }

    @Override
    public InputStream getInputStream() {
        if (input == null) {
            try {
                input = new FileInputStream(persistFile);
            } catch (FileNotFoundException e) {
                throw new NasFileException("File=" + persistFile.getAbsolutePath() + " Not found");
            }
        }
        return input;
    }

    @Override
    public void doFinally() {
        if (input == null) {
            try {
                input.close();
            } catch (IOException e) {
            }
        }
    }

}
