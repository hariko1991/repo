package com.pingan.pafa.stp.wefiles.nas;

import java.io.File;
import java.io.IOException;
import java.util.Calendar;
import java.util.Date;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.InitializingBean;

import com.pingan.pafa.stp.wefiles.AbstractWefiles;
import com.pingan.pafa.stp.wefiles.WefileDownloader;
import com.pingan.pafa.stp.wefiles.WefileMeta;
import com.pingan.pafa.stp.wefiles.WefileUploader;
import com.pingan.pafa.stp.wefiles.nas.dto.FileMetaDTO;
import com.pingan.pafa.stp.wefiles.nas.services.FileMetaServices;


public class WefilesNasBean extends AbstractWefiles implements InitializingBean {

    private String rootPath;

    private File root;

    private static final String DEF_NAMESPACE = "def";

    private FileMetaServices fileMetaServices;

    @Override
    public void afterPropertiesSet() throws Exception {
        if (StringUtils.isBlank(rootPath)) {
            throw new java.lang.IllegalArgumentException("rootPath required.");
        }
        root = new File(rootPath);
        if (!root.exists()) {
            root.mkdirs();
        }
        if (!root.exists()) {
            throw new java.lang.IllegalArgumentException("rootPath=" + rootPath
                    + " error. not exists.");
        } else if (!root.isDirectory()) {
            throw new java.lang.IllegalArgumentException("rootPath=" + rootPath
                    + " error. not be directory.");
        } else {
            logger.info("rootPath=" + rootPath);
        }
    }

    protected String getNasPath(WefileMeta meta) {
        String namespace = meta.getNamespace();
        if (namespace == null || (namespace = namespace.trim()).length() == 0) {
            namespace = DEF_NAMESPACE;
            meta.setNamespace(namespace);
        }
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH) + 1;
        int date = calendar.get(Calendar.DATE);
        return "/" + namespace + "/" + year + "/" + (month > 9 ? month : ("0" + month)) + "/"
                + date + "/" + meta.getFileId();
    }

    @Override
    protected WefileUploader getUploader(WefileMeta meta) {
        String aliasId = meta.resolveAliasId();
        if (aliasId != null) {
            if (fileMetaServices.getByAliasId(aliasId) != null) {
                throw new NasFileException("Alias fileId=" + aliasId + " be exists.");
            }
        }
        String fileId = generateNewFileId();
        meta.setFileId(fileId);
        meta.setCreateTime(new Date());
        
        String realNasPath = this.getNasPath(meta);
        if (logger.isInfoEnabled()) {
            logger.info("realNasPath=" + realNasPath);
        }
        File persistFile = new File(this.root, realNasPath);
        persistFile.getParentFile().mkdirs();

        try {
            if (persistFile.createNewFile()) {
                return new WefileNasUploader(meta, persistFile, fileMetaServices, realNasPath);
            } else {
                throw new NasFileException("File<" + meta.getFileId() + "> "
                        + persistFile.getAbsolutePath() + " exists .");
            }
        } catch (IOException e) {
            throw new NasFileException("Create File<" + meta.getFileId() + "> "
                    + persistFile.getAbsolutePath() + " error:" + e.getMessage(), e);
        }
    }

    @Override
    protected WefileDownloader getDownloader(WefileMeta meta) throws Exception {
        String fileId = meta.resolveAliasId();
        FileMetaDTO metaDTO = null;
        if (fileId != null) {
            metaDTO = fileMetaServices.getByAliasId(fileId);
        } else {
            fileId = meta.getFileId();
            metaDTO = fileMetaServices.get(fileId);
        }
        if (metaDTO == null) {
            throw new NasFileException("Not found file meta in DB,fileId=" + fileId);
        }
        File persistFile = new File(this.root, metaDTO.getRealNasPath());
        if (!persistFile.exists()) {
            throw new NasFileException("Not found file in NAS,fileId=" + fileId);
        }
        return new WefileNasDownloader(metaDTO, persistFile);
    }

    public void setFileMetaServices(FileMetaServices fileMetaServices) {
        this.fileMetaServices = fileMetaServices;
    }

    public void setRootPath(String rootPath) {
        this.rootPath = rootPath;
    }

}
