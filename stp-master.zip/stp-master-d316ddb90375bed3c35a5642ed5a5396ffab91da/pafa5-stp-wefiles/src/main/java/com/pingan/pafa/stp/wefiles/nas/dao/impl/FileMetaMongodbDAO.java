package com.pingan.pafa.stp.wefiles.nas.dao.impl;

import org.springframework.stereotype.Repository;

import com.pingan.pafa.mongodb.BaseMongoDAO;
import com.pingan.pafa.stp.wefiles.nas.dao.FileMetaDAO;
import com.pingan.pafa.stp.wefiles.nas.dto.FileMetaDTO;


@Repository
public class FileMetaMongodbDAO extends BaseMongoDAO<FileMetaDTO> implements FileMetaDAO {

    @Override
    public boolean add(FileMetaDTO metaDTO) {
        this._add(metaDTO);
        return true;
    }

    @Override
    public FileMetaDTO getByAlias(String aliasId) {
        return this._getByProperty("aliasId", aliasId);
    }

    @Override
    public FileMetaDTO get(String fileId) {
        return this._getById(fileId);
    }

    @Override
    public boolean update(FileMetaDTO metaDTO) {
        return this._updateById(metaDTO.getFileId(), metaDTO);
    }

}
