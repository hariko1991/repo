package com.pingan.pafa.stp.wefiles.nas.dto;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.index.Indexed;
import org.springframework.data.mongodb.core.mapping.Document;

import com.paic.pafa.biz.dao.BasePO;
import com.pingan.pafa.stp.wefiles.WefileMeta;

/***
 * @author LIXINGNAN945
 * 
 */
@Document(collection = "WefileMetaInfo")
public class FileMetaDTO extends BasePO {

    // http content-type
    private String contentType;

    // 真实文件名
    private String fileName;

    // 文件ID
    @Id
    private String fileId;

    // 过期截止时间
    private Date expiredDate;

    // 过期时间，0使用默认值，-1永不过期
    private int expiredTime;

    // 文件大小，单位byte
    private int fileSize = -1;

    // 文件状态 0 正常，1已删除，2删除失败
    private Integer status;

    // 文本文件的字符编码
    private String charset;

    private String realNasPath;

    private String namespace;

    private String aliasName;

    @Indexed
    private String aliasId;

    public FileMetaDTO() {}

    public FileMetaDTO(WefileMeta meta, String realNasPath, boolean beFinally) {
        this.setCharset(meta.getCharset());
        this.setContentType(meta.getContentType());
        this.setCreatedDate(meta.getCreateTime());
        this.setExpiredDate(meta.getExpiredDate());
        this.setExpiredTime(meta.getExpiredTime());
        this.setFileId(meta.getFileId());
        this.setFileName(meta.getFileName());
        this.setRealNasPath(realNasPath);
        this.setNamespace(meta.getNamespace());
        this.setAliasName(meta.getAliasName());
        if (beFinally) {
            this.setAliasId(meta.resolveAliasId());
            this.setFileSize(meta.getFileSize());
        }
    }


    public WefileMeta toWefileMeta() {
        WefileMeta meta = new WefileMeta();
        meta.setCharset(this.getCharset());
        meta.setContentType(this.getContentType());
        meta.setCreateTime(this.getCreatedDate());
        meta.setExpiredDate(this.getExpiredDate());
        meta.setExpiredTime(this.getExpiredTime());
        meta.setFileId(this.getFileId());
        meta.setFileName(this.getFileName());
        meta.setFileSize(this.getFileSize());
        meta.setNamespace(this.getNamespace());
        meta.setAliasName(this.getAliasName());
        return meta;
    }


    public String getContentType() {
        return contentType;
    }

    public void setContentType(String contentType) {
        this.contentType = contentType;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public String getFileId() {
        return fileId;
    }

    public void setFileId(String fileId) {
        this.fileId = fileId;
    }

    public Date getExpiredDate() {
        return expiredDate;
    }

    public void setExpiredDate(Date expiredDate) {
        this.expiredDate = expiredDate;
    }

    public int getExpiredTime() {
        return expiredTime;
    }

    public void setExpiredTime(int expiredTime) {
        this.expiredTime = expiredTime;
    }

    public int getFileSize() {
        return fileSize;
    }

    public void setFileSize(int fileSize) {
        this.fileSize = fileSize;
    }

    public String getCharset() {
        return charset;
    }

    public void setCharset(String charset) {
        this.charset = charset;
    }

    public String getRealNasPath() {
        return realNasPath;
    }

    public void setRealNasPath(String realNasPath) {
        this.realNasPath = realNasPath;
    }

    public String getNamespace() {
        return namespace;
    }

    public void setNamespace(String namespace) {
        this.namespace = namespace;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public String getAliasId() {
        return aliasId;
    }

    public void setAliasId(String aliasId) {
        this.aliasId = aliasId;
    }

    public String getAliasName() {
        return aliasName;
    }

    public void setAliasName(String aliasName) {
        this.aliasName = aliasName;
    }

}
