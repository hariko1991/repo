package com.pingan.pafa.stp.wefiles.nas.services;

import com.pingan.pafa.stp.wefiles.nas.dto.FileMetaDTO;

public interface FileMetaServices {

    public FileMetaDTO get(String fileId);

    public FileMetaDTO getByAliasId(String aliasId);

    public boolean add(FileMetaDTO metaDTO);

    public boolean update(FileMetaDTO metaDTO);
}
